"""DeerMem backend configuration (parsed from ``MemoryConfig.backend_config``).

DeerMem-private config lives here, NOT on the shared ``MemoryConfig`` (which
only carries host-shared fields: ``enabled`` / ``injection_enabled`` /
``manager_class`` / ``backend_config``). The factory passes ``backend_config``
(a dict) to ``DeerMem.__init__``, which parses it into a ``DeerMemConfig``.
Defaults let DeerMem run with zero ``backend_config``.

Field names mirror the pre-abstraction ``MemoryConfig`` private fields so the
migration is a pure move (config.yaml ``memory.<field>`` ->
``memory.backend_config.<field>``). ``model`` is a nested ``DeerMemModelConfig``
(provider/model/api_key/base_url/temperature) consumed by ``core/llm.py``;
``should_keep_hidden_message`` is an optional host-injected hook (None =
DeerMem default); tracing is via the base ``MemoryManager.callbacks`` field
(``on_memory_llm_call`` before the LLM call), not a DeerMemConfig slot.
"""

from __future__ import annotations

import logging
import math
from pathlib import Path
from typing import Any, Literal

from pydantic import BaseModel, Field, model_validator

logger = logging.getLogger(__name__)


class DeerMemModelConfig(BaseModel):
    """DeerMem's memory-update LLM config (langchain ``init_chat_model`` params)."""

    provider: str | None = Field(
        default=None,
        description="langchain model_provider, e.g. 'openai' (default when None). DeepSeek/other OpenAI-compatible gateways use 'openai' + base_url.",
    )
    model: str | None = Field(
        default=None,
        description="Model name. None = no LLM configured (non-LLM ops still work; an update raises).",
    )
    api_key: str | None = Field(default=None, description="API key (or rely on the provider's env var).")
    base_url: str | None = Field(default=None, description="Override base URL (e.g. an OpenAI-compatible gateway).")
    temperature: float | None = Field(default=None, description="Sampling temperature.")


class DeerMemConfig(BaseModel):
    """DeerMem-private configuration (self-contained, host-agnostic)."""

    # ── Storage ──────────────────────────────────────────────────────────
    storage_path: str = Field(
        default="",
        description=("DeerMem data root. Empty = default (``$DEERMEM_DATA_DIR`` or ``~/.deermem/``); per-user memory at ``{root}/users/{user_id}/memory.json``. Any value (absolute or relative) is used as the root directory."),
    )
    storage_class: str = Field(
        default="",
        description="Dotted class path for an alternative storage provider; empty (default) = FileMemoryStorage (no importlib, portable).",
    )
    strict_user_scope: bool = Field(
        default=False,
        description="Require user_id for every storage scope. False preserves no-auth and legacy callers.",
    )
    manifest_filename: str = Field(
        default="memory.json",
        description="User-global summary JSON filename. Kept under this name for config compatibility; must be a plain .json filename.",
    )
    file_lock_timeout_seconds: int = Field(
        default=10,
        ge=1,
        le=120,
        description="Maximum wait for the per-scope cross-process advisory file lock.",
    )
    retrieval_adapter: str = Field(
        default="fts5",
        description="Retrieval adapter factory: 'fts5' (default), an empty string to disable, or a dotted factory receiving DeerMemConfig and implementing RetrievalPort.",
    )
    fact_dedup_enabled: bool = Field(
        default=False,
        description=(
            "Opt-in deterministic near-duplicate gate for NEW facts (issue "
            "#5252). When true, a proposed new fact whose bounded "
            "token-Jaccard similarity to an existing fact in the same "
            "user/agent scope AND category reaches "
            "fact_dedup_similarity_threshold merges into that fact instead "
            "of being appended: the existing id/content/createdAt are kept, "
            "confidence is raised to max(old, new), and source is refreshed "
            "only when confidence increases. Correction replacements and "
            "proposed removal targets are excluded from near-dedup. "
            "False preserves the legacy behavior exactly."
        ),
    )
    fact_dedup_similarity_threshold: float = Field(
        default=0.7,
        ge=0.5,
        le=1.0,
        description=("Minimum bounded token-Jaccard similarity for the write-side near-duplicate merge gate. Used only when fact_dedup_enabled is true."),
    )
    # ── Queue ────────────────────────────────────────────────────────────
    debounce_seconds: int = Field(
        default=30,
        ge=1,
        le=300,
        description="Seconds to wait before processing queued updates (debounce).",
    )
    queue_max_depth: int = Field(
        default=1000,
        ge=0,
        description=("Backpressure cap on pending items. 0 = unlimited. When the cap is reached, new non-signal updates are rejected (QueueFull); signal updates are always admitted so important memories are never shed."),
    )
    # ── Facts ────────────────────────────────────────────────────────────
    max_facts: int = Field(default=100, ge=10, le=500, description="Maximum number of facts to store.")
    fact_eviction_policy: Literal["confidence", "hybrid-v1"] = Field(
        default="confidence",
        description=("Capacity-eviction policy. 'confidence' preserves the historical behavior; 'hybrid-v1' combines confidence, explicit-confirmation freshness, and query-driven access heat with bounded correction slots."),
    )
    fact_eviction_shadow_enabled: bool = Field(
        default=False,
        description=("When true, also compute hybrid-v1 during confidence-policy trims and include its disagreement in the metadata-only eviction audit."),
    )
    eviction_confidence_weight: float = Field(default=0.65, ge=0.0, le=1.0)
    eviction_confirmation_weight: float = Field(default=0.25, ge=0.0, le=1.0)
    eviction_access_weight: float = Field(default=0.10, ge=0.0, le=1.0)
    eviction_confirmation_half_life_days: int = Field(default=90, ge=1, le=3650)
    eviction_access_half_life_days: int = Field(default=30, ge=1, le=3650)
    eviction_correction_reserved_fraction: float = Field(default=0.10, ge=0.0, le=1.0)
    eviction_correction_reserved_max: int = Field(default=10, ge=0, le=100)
    eviction_audit_max_entries: int = Field(
        default=200,
        ge=0,
        le=10000,
        description="Maximum metadata-only capacity-eviction audit events per user/agent scope; 0 disables the audit.",
    )
    fact_confidence_threshold: float = Field(
        default=0.7,
        ge=0.0,
        le=1.0,
        description="Minimum confidence threshold for storing facts.",
    )
    # ── Injection ────────────────────────────────────────────────────────
    max_injection_tokens: int = Field(
        default=2000,
        ge=100,
        le=8000,
        description="Maximum tokens to use for memory injection.",
    )
    token_counting: Literal["tiktoken", "char"] = Field(
        default="tiktoken",
        description=("Token counting strategy for memory-injection budgeting. 'tiktoken' is accurate but may download BPE data on first use; 'char' is network-free CJK-aware estimation."),
    )
    guaranteed_categories: list[str] = Field(
        default_factory=lambda: ["correction"],
        description="Fact categories always injected regardless of the regular token budget.",
    )
    guaranteed_token_budget: int = Field(
        default=500,
        ge=50,
        le=2000,
        description="Token ceiling for guaranteed-category facts.",
    )
    # ── Staleness review ─────────────────────────────────────────────────
    staleness_review_enabled: bool = Field(
        default=True,
        description="Enable staleness review for aged facts.",
    )
    staleness_age_days: int = Field(
        default=90,
        ge=30,
        le=365,
        description="Facts older than this become staleness-review candidates.",
    )
    staleness_min_candidates: int = Field(
        default=3,
        ge=1,
        le=50,
        description="Minimum stale facts required to trigger a review cycle.",
    )
    staleness_max_removals_per_cycle: int = Field(
        default=10,
        ge=1,
        le=50,
        description="Maximum facts the staleness review can remove per cycle.",
    )
    staleness_protected_categories: list[str] = Field(
        default_factory=lambda: ["correction"],
        description="Fact categories exempt from staleness review.",
    )
    staleness_max_lifetime_multiplier: float = Field(
        default=20.0,
        ge=1.0,
        le=100.0,
        description=(
            "Creation-time cap multiplier for a fact's LLM-assigned "
            "expected_valid_days. When a new fact is stored, its "
            "expected_valid_days is clamped to "
            "staleness_age_days * staleness_max_lifetime_multiplier so the "
            "model cannot set an initial lifetime so long that the fact is "
            "never re-evaluated. Default 20.0 (90 x 20 = 1800 d ~= 5 years) "
            "is generous enough to support the 'very stable' prompt tier "
            "(core skills, native language) without needing multiple review "
            "cycles to escape the cap. Lifetime extensions (staleFactsToExtend) "
            "are subject to staleness_max_extension_days instead."
        ),
    )
    staleness_max_extension_days: int = Field(
        default=3650,
        ge=90,
        le=36500,
        description=(
            "Absolute upper bound (in days) on expected_valid_days after a "
            "lifetime extension (staleFactsToExtend). Applied at write time "
            "during staleness review: new_evd = min(days_since + extend_by, "
            "staleness_max_extension_days). Separate from the creation-time "
            "multiplier cap because extensions are deliberate recalibration "
            "decisions and are not subject to the staleness_age_days scale. "
            "The ceiling prevents a single LLM misfire from permanently "
            "deferring a fact or causing timedelta overflow on the next "
            "candidate-selection pass. Default 3650 (10 years)."
        ),
    )
    # ── Memory consolidation ────────────────────────────────────────────
    consolidation_enabled: bool = Field(
        default=False,
        description=(
            "Enable memory consolidation. When enabled, the LLM reviews "
            "fragmented fact categories during the normal memory-update call "
            "(same invocation - no extra API call) and decides whether groups "
            "of related facts can be synthesized into a single richer fact. "
            "Defaults to False because consolidation is lossy (source content "
            "is not preserved, only consolidatedFrom IDs). Opt in explicitly "
            "once the memory-file backup / audit story is in place."
        ),
    )
    consolidation_min_facts: int = Field(
        default=8,
        ge=3,
        le=30,
        description=("Minimum number of facts in a single category to trigger consolidation review. Below this threshold the overhead of surfacing the group is not justified."),
    )
    consolidation_max_groups_per_cycle: int = Field(
        default=3,
        ge=1,
        le=10,
        description=("Maximum number of consolidation groups the LLM can merge in a single update cycle. Prevents over-consolidation."),
    )
    consolidation_max_sources: int = Field(
        default=8,
        ge=2,
        le=20,
        description=("Maximum number of source facts per consolidation group. Prevents the LLM from merging too many facts into one and losing important details."),
    )
    # ── Extraction quality callback (post-invoke observability) ─────────
    extraction_callback: Any = Field(
        default=None,
        description=(
            "Optional ``callback(metrics)`` invoked AFTER the extraction LLM "
            "call (token usage, facts passing/rejected by the confidence "
            "filter, rejection rate, prompt version). The host injects a "
            "Langfuse-based callback to emit an extraction span; None = no "
            "post-invoke observability. Set programmatically (not from YAML)."
        ),
    )
    # ── Watermark cache (in-memory, bounded LRU) ─────────────────────────
    watermark_max_keys: int = Field(
        default=4096,
        ge=0,
        description=(
            "Soft cap on the in-memory conversation-watermark cache (one entry "
            "per distinct thread/user/agent). The cache is a bounded LRU: when "
            "over capacity the least-recently-used entry is dropped, and a "
            "dropped key re-extracts one batch on that thread's next turn (the "
            "same as a restart). 0 = unbounded."
        ),
    )
    # ── Message processing (externalized patterns / prompts) ──
    patterns_dir: str | None = Field(
        default=None,
        description=("Directory with correction.yaml / reinforcement.yaml overriding the bundled signal-detection patterns. None (default) = bundled core/message_patterns/. When set explicitly, both files must exist."),
    )
    prompts_dir: str | None = Field(
        default=None,
        description=("Directory with custom memory-extraction prompt templates (memory_update.chat.yaml, staleness_review.yaml, consolidation.yaml, fact_extraction.yaml). None (default) = bundled core/prompts/."),
    )
    # ── LLM (structured model sub-config consumed by core/llm.py build_llm) ──
    model: DeerMemModelConfig = Field(
        default_factory=DeerMemModelConfig,
        description=(
            "Memory-update LLM config (provider/model/api_key/base_url/temperature). "
            "Empty = the host factory injects its default chat model as ``host_llm`` "
            "(zero-config UX, mirrors pre-abstraction ``model_name: null``); "
            "when ``host_llm`` is also absent (standalone DeerMem) an update raises "
            "but non-LLM ops still work."
        ),
    )
    # ── Hooks (optional host-injected callables; None = DeerMem defaults) ──
    # Tracing is via the base ``MemoryManager.callbacks`` field
    # (``on_memory_llm_call`` before the LLM call), not a DeerMemConfig slot.
    should_keep_hidden_message: Any = Field(
        default=None,
        description=("Optional ``hook(additional_kwargs) -> bool``; when set, ``hide_from_ui`` messages are kept if it returns True. None = skip all ``hide_from_ui`` (host-agnostic safe default). Set programmatically."),
    )
    host_llm: Any = Field(
        default=None,
        description=(
            "Host-injected pre-built chat model for memory extraction (zero-config "
            "UX). The deer-flow factory injects its default model here when "
            "``model`` is empty, mirroring pre-abstraction ``model_name: null`` -> "
            "app default. Takes precedence over ``build_llm(model)``. None = build "
            "from ``model`` (or no LLM when ``model`` is also empty). Set "
            "programmatically (an instance cannot come from YAML)."
        ),
    )
    trace_context_manager: Any = Field(
        default=None,
        description=(
            "Host-injected context-manager callable ``cm(trace_id)`` that binds "
            "``trace_id`` into the host request-trace ContextVar for the memory-"
            "update worker thread (Timer / executor), restoring structured-log "
            "trace correlation. None = no binding (DeerMem standalone; trace_id "
            "still reaches ``on_memory_llm_call`` and the log message text). Set "
            "programmatically."
        ),
    )

    @model_validator(mode="after")
    def _check_storage_path_is_directory(self) -> DeerMemConfig:
        """DeerMem treats ``storage_path`` as a root DIRECTORY (per-user memory
        under ``{storage_path}/users/{uid}/memory.json``). A file-style value
        (e.g. a leftover ``.json`` from the pre-abstraction file-path semantics)
        would make ``FileMemoryStorage.save``'s ``mkdir(parents=True)`` raise
        ``NotADirectoryError`` (caught as OSError -> silent write failure). Fail
        loud at construction instead (memory is persistent state -- a wrong root
        is a data-integrity footgun). Lives here (not the host factory) so it
        fires even when DeerMem is built standalone / bypassing the factory.
        Empty storage_path (zero-config -> host injects a dir) is allowed.
        """
        if self.storage_path:
            resolved = Path(self.storage_path)
            if resolved.is_file():
                raise ValueError(
                    f"memory.backend_config.storage_path={self.storage_path!r} "
                    f"resolves to an existing file {resolved}; DeerMem treats "
                    f"storage_path as a root DIRECTORY (per-user memory under "
                    f"{{storage_path}}/users/{{uid}}/memory.json). Point it at a directory."
                )
        weight_sum = self.eviction_confidence_weight + self.eviction_confirmation_weight + self.eviction_access_weight
        if not math.isclose(weight_sum, 1.0, rel_tol=0.0, abs_tol=1e-9):
            raise ValueError("DeerMem eviction weights must sum to 1.0")
        return self

    @classmethod
    def from_backend_config(cls, backend_config: dict[str, Any] | None) -> DeerMemConfig:
        """Parse a ``backend_config`` dict.

        Unknown keys are ignored (forward-compat) but logged at WARNING so a
        typo (e.g. ``storage_pat`` missing the ``h``) does not silently fall
        back to the default and write memory to an unintended location --
        mirrors the host layer's ``load_memory_config_from_dict`` warning.

        ``None`` values are dropped so they fall back to the field default:
        YAML renders an empty key (``model:`` with only commented children, as
        shipped in ``config.example.yaml``) as ``None``, which non-Optional
        fields like ``model`` would otherwise reject even though omitting the
        key entirely is valid.
        """
        if not backend_config:
            return cls()
        backend_config = dict(backend_config)
        known = {k: v for k, v in backend_config.items() if k in cls.model_fields and v is not None}
        unknown = sorted(k for k in backend_config if k not in cls.model_fields)
        if unknown:
            logger.warning(
                "Unknown backend_config keys ignored by DeerMem; check for typos: %s",
                unknown,
            )
        return cls(**known)
