# 《生产项目代码分析报告》— DeepSeek Harness (dsh) v0.2.1-alpha.1

> 分析对象：`dsh-v0.2.1-alpha.1/` 目录（DeepSeek AI 开源的 DeepSeek Harness monorepo 源码快照）
> 报告生成日期：2026-10-08 ｜ 分析方式：只读源码分析（未修改任何代码）
> 结论依据：所有具体实现均引用 `文件路径:行号`；无法从代码确证的意图已标注「推断」

---

## 读者须知与阅读地图

本报告面向**从未接触过本项目的开发人员**。项目是一个约 **210 个 npm 子包、2,787 个生产源文件、约 47.4 万行代码** 的大型 pnpm monorepo，无法在单份文档内对每个文件做同深度的函数级展开。因此本报告采用「两层结构」：

- **正文（第 1~4、6~10 章）**：对架构、全部模块组与核心链路做人工深读分析——覆盖每个包的职责、关键文件、关键函数的完整实现逻辑；
- **附录 A（第 5 章）**：由脚本对**全部 2,787 个纳入范围的生产源文件**逐一提取「路径 / 行数 / 导出符号 / import 依赖」生成的完整清单总表，按包分组，包头上附职责说明，保证零遗漏。

### 术语表（项目特有概念，首次出现前必读）

| 术语 | 解释 |
|---|---|
| **dsh / Harness** | DeepSeek Harness 的命令名与产品名：一个让 LLM 在真实工作区里执行任务的 agent harness（外壳） |
| **Cordis** | 底层插件框架（vendored 于 `vendor/`）。插件向共享 `Context` 贡献服务、类型化事件与可逆 effect；没有可打补丁的特权内核（docs/architecture.md:9-13） |
| **插件 (plugin)** | 一个向 `ctx` 贡献能力的 Cordis 组件。dsh 中**一切皆插件**：模型适配器、工具注册表、会话日志、agent 循环本身都是插件 |
| **`ctx` / Service** | Cordis 上下文与服务。`ctx.<key>`（如 `ctx.sessions`、`ctx.tools`）是服务的访问键；服务用 `declare module '@deepseek-ai/cordis'` 声明合并扩展 |
| **能力缝 (capability seam)** | 一个可替换能力的完整三元组：**Service Definition**（声明接口与 `ctx` 键）、**Service Provider**（实现）、**Consumer**（使用，通常是模型工具）。例：`dsh-shell`（定义）+ `dsh-bash-local/sandbox`（实现）+ `dsh-tool-bash`（消费者）（docs/glossary.md:9） |
| **Profile** | 存于 Harness home（`$DSH_HOME`，默认 `~/.dsh`）的命名组合：列出所叠 bundle、持有用户 `cordis.patch.yml`。出厂模板：`web/headless/sdk/sdk-minimal/acp` |
| **Bundle** | Cordis 配置行与所挂代码的**分发格式**（`package.json` 的 `dsh.bundle.patch` 字段指向 patch 文件），保证其插入内容仍可被上层 patch 覆盖。`dsh-base` 是共享首层 |
| **Session** | 一次持久会话 = **追加式事件日志**（append-only `SessionEvent` log）。模型可见的一切必须可由日志重建（"Model-visible means logged"） |
| **turn / step / round** | **turn**=一次被接纳输入的排空（含 0..n 个 step）；**step**=一次模型请求+其引发的工具执行；**round**=外层策略迭代（如 goal round、Ralph round）（docs/glossary.md:36-39） |
| **Agent / AgentLoop** | `Agent` 是接口+活注册表（`ctx.agents`）；`agent-loop` 是实现该接口的默认驱动（`ctx.agentLoop`），核心类 `ReactLoopAgent` |
| **surface（消息面）** | Session 内带 `surfaceOp` 标记的有序消息投影面；`deriveMessages()` 由它派生模型历史，而非直接读日志 |
| **投影 (projection)** | 对已提交会话事件的增量纯折叠（`ctx.sessionProjections`），读侧状态的统一来源 |
| **waterfall** | Cordis 链式事件语义：监听器**必须调用 `next()`** 委托下家，否则短路整链（AGENTS.md:135） |
| **scope（作用域）** | 每 agent 的注册单元：贡献（工具/prompt 段/变量/限制）分全局与 scoped 两级；agent 自身的对象即 scope key（docs/glossary.md:13-14） |
| **PTC** | "Prompt-to-Code" 执行模式：模型只见 `run_code` 传输工具，其余工具调用序列化为代码在沙箱 Node 运行时执行 |
| **Typert** | 自研的"类型图 RPC"系统：Host 以 `@Remote` 装饰器暴露类型化方法，浏览器客户端按生成工件做类型化调用（`packages/typert`） |
| **Ralph loop** | 一种前台 fresh-agent 工作流策略：每轮新建子会话攻一个不可变目标，跨轮靠共享工作区+有界 handoff 传递状态（docs/glossary.md:43-45） |
| **Harness home** | `$DSH_HOME`（默认 `~/.dsh`）：profile、凭证、设置、技能、会话数据所在地 |

### 分批输出计划（按规约给出；因本报告以单文件一次性交付，各批内容已顺序编入本文档对应部分）

| 批次 | 覆盖模块/目录 | 覆盖章节 | 涉及文件数 | 状态 |
|---|---|---|---|---|
| 1 | 全局总览（apps/、packages/、native/、python/、scripts/） | 第 1~3 章 + 第 5 章清单层 + 本计划 | 全部 2,787（清单层） | ✅ 已完成（本文档 §1~§3、附录 A） |
| 2 | 基础层：util/、typert/、storage/、credentials/、identity/、settings/、telemetry/、workspace/ | 第 4 章（4.1~4.2） | ~90 | ✅ 已完成 |
| 3 | 数据面：core/session、session/*、llm/*、attachment/、spill/、compaction/、context/、document/ | 第 4 章（4.3） | ~250 | ✅ 已完成 |
| 4 | 核心驱动与工具面：core/其余、fs/、shell/、subprocess/、sandbox/、ssh/、terminal/、lsp/、mcp/、web/、browser-use/、computer-use/、deliverables/、interaction/、ptc-runtime/ | 第 4 章（4.4~4.5） | ~230 | ✅ 已完成 |
| 5 | 编排与扩展：subagent/、workflow/、jobs/、todo/、plan/、goal/、schedule/、skill/、extensions/、hooks/、guard/、webhook/、feedback/、acp/ | 第 4 章（4.6） | ~140 | ✅ 已完成 |
| 6 | 宿主与客户端：boot/、host/、bundle/、preset/、sdk/、api/、client/、apps/*、experimental/、native/、python/、scripts 关键脚本 | 第 4 章（4.7~4.11） | ~2,050 | ✅ 已完成 |
| 7 | 横切与收尾：关键函数深解、端到端调用链、横切机制、外部依赖、上手路径、自检 | 第 6~10 章 + 收尾 | 跨模块 | ✅ 已完成 |

> 说明：批次 6 文件数含 `packages/client`（60 个 UI 子包，按包级+关键文件深挖）与 `experimental/`（24 个实验包，按包概览+3 个深挖样例）；这两组内部以「包」为分析单元，包内全部文件见附录 A 清单。计划未发生变更。

---

# 第 1 章 项目概述

## 1.1 项目用途与业务背景

DeepSeek Harness（`dsh`）是 DeepSeek AI 开源的 **agent harness**：一个把 LLM（默认 DeepSeek 模型）接入真实工作区的运行外壳——模型在沙箱化文件系统/子进程/浏览器等能力上执行多步任务，人类通过 Web UI / 桌面应用 / CLI / SDK 观察与干预（README.md:1-27）。

业务形态从代码即可归纳：

- **多表面产品**：`apps/cli`（`dsh` 命令）、`apps/web`（浏览器前端）、`apps/desktop`（Electron 桌面）、`packages/sdk`（JSON-RPC SDK，含 Python 绑定 `python/sdk`）、ACP 自动化协议服务端——五个表面共用同一插件内核；
- **代码 agent 能力面**：`tool-bash/tool-fs/tool-web/tool-terminal/tool-lsp` 等模型可调用工具（约 40+ 个），子代理、工作流、定时任务、计划模式、目标驱动等编排原语；
- **工程定位**："everything is a plugin"——连 agent 循环、会话日志、模型适配器都是可从配置替换的插件（docs/architecture.md:11-13）。README 引用了 Cordis 的时空可组合性论文（arXiv:2608.25512）作为设计基础。

## 1.2 技术栈清单

| 层 | 技术 | 版本/位置 | 说明 |
|---|---|---|---|
| 语言 | TypeScript（`strict: true`，ESM-only） | typescript ^6.0.3（根 package.json:258） | 全仓 `"type": "module"`；相对导入用 `.ts` 后缀（AGENTS.md:131） |
| 语言（辅） | Python / C | `python/sdk*`、`native/system` | Python SDK 客户端；C 原生 addon（landlock 执行器 + flock） |
| 运行时 | Node.js | `^22.19.0 \|\| >=24.0.0`（package.json:9） | 源码启动走 `node --import tsx/esm`（package.json:198） |
| 包管理 | pnpm workspaces | pnpm@11.7.0 | workspaces: `vendor/*`、`packages/*/*`、`native/system`、`apps/*`、`website`（package.json:11-18） |
| 核心框架 | Cordis（vendored） | `vendor/` 内 pinned 源码副本，rescope 为 `@deepseek-ai/cordis` | 插件上下文/服务/事件/fiber；dsh 包以 peer 依赖声明它（AGENTS.md:130） |
| 构建 | tsc project references + tsdown + Vite 8 | `tsconfig.host.json`/`tsconfig.client.json`/`tsdown.config.ts`/apps/web/vite.config.ts | Host/Client 双编译面；构建脚本 `scripts/build.ts` |
| 测试 | Vitest 4（含 e2e/snapshot/bench/web 多配置） | 根目录 9 个 vitest 配置 | 排除范围，不展开 |
| 桌面 | Electron + electron-builder | apps/desktop | 自定义 `dsh-app://` 协议、代码签名 |
| 前端 UI | React + zustand(vanilla)+immer + CSS Modules | packages/client | 无组件库/Tailwind（docs/web-styling.md） |
| LLM 传输 | Anthropic 兼容 Messages API（SSE 流） | packages/llm/llm-deepseek | 官方 DeepSeek 直连；另有 pi-ai 适配器 |
| 关键依赖 | zod、Schemastery（配置 schema）、ws、node-pty、zstd（会话压缩）、better-sqlite3 类 SQLite、@octokit/webhooks（签名）、@modelcontextprotocol/sdk、OpenTelemetry | 各子包 | 详见第 9 章 |

## 1.3 如何运行

**从 npm 运行**（README.md:19-27）：

```sh
npx @deepseek-ai/dsh web        # 启动 Web UI，默认 http://127.0.0.1:3080 并自动开浏览器
```

**从源码运行**（README.md:29-41）：

```sh
pnpm install && pnpm run build && pnpm dsh web
# 常用：pnpm dsh --profile headless "task"（一次性任务，需 DEEPSEEK_API_KEY）
# 开发：pnpm run dev:web（构建+服务+改码重建 client bundle 一条龙）
```

- **入口文件**：`apps/cli/src/bin.ts`（`runCli`，bin.ts:26）；npm bin 与 tsx 源码启动都指向它；
- **环境配置**：`loadLayeredEnv('dsh')` 分层 `.env`（继承环境 > 调用目录 `.env` > `$DSH_HOME/.env`，app-boot index.ts:235-256）；关键变量 `DSH_HOME`、`DEEPSEEK_API_KEY`、`DEEPSEEK_BASE_URL`、`DSH_TELEMETRY_DISABLED`；
- **profile 选择**：`dsh --profile <name>` 或缩写 `dsh <name>`（web/headless/sdk/sdk-minimal/acp）；`dsh plugin` 是插件管理子命令；
- **配置体系**：整棵插件树都是 YAML patch 层（bundle → profile `cordis.patch.yml` → home 级 patch → `--patch` overlays），`dsh --profile web --dump-config` 可打印最终组合树（docs/architecture.md:33-39）。

---

# 第 2 章 整体架构

## 2.1 架构风格与分层

一句话：**基于 Cordis 的"全插件"单体 monorepo，双面（Host/Client）编译，多表面（CLI/Web/Desktop/SDK/ACP）共享同一内核，一切能力以"能力缝"三元组解耦，一切持久状态以"追加式会话日志"为唯一事实源。**

```text
┌─────────────────────────── 应用表面层 (apps/) ───────────────────────────┐
│ apps/cli (@deepseek-ai/dsh)      dsh 命令：profile/plugin/dump-config    │
│ apps/web   (web-frontend)        Vite 构建壳 → dist 由 webserver 投递    │
│ apps/desktop (Electron)          壳进程 + dsh-app:// 协议 + 签名更新      │
│ apps/desktop-host                Electron 以 Node 模式拉起的私有 Host     │
└──────────────────────────────────┬───────────────────────────────────────┘
                                   │ 复用 runProfile 装配管线
┌──────────────────────────────────▼───────────────────────────────────────┐
│ 组合层 (packages/bundle + $DSH_HOME/profiles)                             │
│ profile = bundle 层叠：[dsh-base] + [web-app|headless|sdk-app|acp-app]    │
│           （sdk-minimal 为独立完整树）                                     │
│ 每层是 cordis.patch.yml 行集合；上层 patch 可按 id 替换任意行              │
└──────────────────────────────────┬───────────────────────────────────────┘
                                   │ 行引用插件包
┌──────────────────────────────────▼───────────────────────────────────────┐
│ 宿主服务层 (packages/host + api)                                           │
│ webserver / frontend-static / directory-picker / open-in-app /            │
│ plugin-inventory / product-telemetry                                      │
│ api/*: Typert Remote 网关 + session/job/terminal/workspace/settings/      │
│        account 控制器（BFF）                                              │
├───────────────────────────────────────────────────────────────────────────┤
│ 客户端层 (packages/client，~60 包，仅浏览器)                               │
│ 内核: web boot / modules(懒CJS模块表) / connection(RPC) / store / locale  │
│ 骨架: ui-renderer / ui-slots / ui-primitives / ui-theme / ui-layout       │
│ 业务: ui-chat / ui-conversation / ui-tool / ui-settings* / ui-sidebar* …  │
├───────────────────────────────────────────────────────────────────────────┤
│ 编排层 (subagent / workflow / jobs / todo / plan / goal / schedule /      │
│         skill / extensions(cordis 动态装载) / hooks / guard / webhook /   │
│         feedback / acp / experimental(agent-team 等))                     │
├───────────────────────────────────────────────────────────────────────────┤
│ 工具与 IO 能力缝 (Consumer=tool-*，Definition 见各 seam 包)                │
│ fs(-local/-sandbox/-ssh) / shell(bash/pwsh × local/sandbox) /             │
│ subprocess(-local/-ssh/-win32) / sandbox(-local/-windows-acl/-ssh) /      │
│ terminal / lsp / mcp / web(search/fetch) / browser-use / computer-use /   │
│ ptc-runtime / deliverables / interaction(approval/questions/commands)     │
├───────────────────────────────────────────────────────────────────────────┤
│ 核心驱动层 (packages/core)                                                 │
│ agent(注册表+发起者) / agent-loop(默认驱动) / session(事件日志+surface) /  │
│ system-prompt / tools(注册表+守卫管线) / scope / session-projection       │
├───────────────────────────────────────────────────────────────────────────┤
│ 数据与模型层                                                               │
│ llm(词汇表+Runtime+deepseek/pi-ai 适配器) / session-persistence(-jsonl) / │
│ session-format(v0→v4 迁移链) / compaction / storage(json/sqlite) /        │
│ attachment / spill / context / session-query(-sqlite)                     │
├───────────────────────────────────────────────────────────────────────────┤
│ 基础层 (util 16 包零依赖 / typert 类型图RPC / boot(app-boot/cmdline/hmr) / │
│         preset(agent-preset-registry) / settings / credentials / identity │
│         / telemetry / workspace)                                          │
├───────────────────────────────────────────────────────────────────────────┤
│ vendor/cordis（vendored 框架）  native/system（C addon）  python/sdk       │
└───────────────────────────────────────────────────────────────────────────┘
```

（排除范围目录已省略：`vendor/` 明细、`docs/`、`website/`、`.agents/`、`benchmarks/`、`packages/test-support/`、各 `tests/`、`snapshots/`）

## 2.2 模块依赖关系（主干）

依赖铁律（packages/README.md:100）：**扩展插件只依赖 Service Definition，永不依赖具体 Provider**；`dsh-agent-loop` 本身可替换，UI/hook/工具插件只面向 `dsh-agent`。

```text
vendor/cordis ──────────────────────────────────────────────┐
util/*（零依赖底座：brand/values/home-paths/atomic-write/…）│
        │                                                   │
        ▼                                                   ▼
typert/protocol ──► typert/registry ◄── typert/loader       cordis Context
        │                                                   │
        ▼                                                   │
llm ─► session(core) ─► scope ─► agent ─► agent-loop ◄───────┘
  │        │    ▲          │        │
  │        │    └──────────┤        ├──► tools（守卫执行管线）──► 各 tool-* 消费者
  │        ▼               ▼        ├──► system-prompt（段落/变量/工具 schema 组装）
  │  session-persistence ──► session-persistence-jsonl（zstd+generation）
  │  session-format v0→v4 迁移链（只被 persistence-jsonl 引用）
  │
  ├──► llm-deepseek（+api-key/account 两个凭据源、wire 扩展注册表）
  ├──► compaction-basic/image-offload/tool-result-pruner（消费 token-meter）
  ├──► token-meter / llm-retry
  ▼
fs/shell/subprocess/sandbox/terminal/lsp/web…（能力缝：Definition+Provider）
  ▲                                    ▲
  └── tool-fs/tool-bash/…（Consumer）   └── ssh 包族一次性替换四个缝=远端执行世界

subagent（编排中枢）─► workflow-ptc ─► tool-workflow/tool-ralph
jobs-local ─► tool-jobs；goal+goal-round-driver+tool-goal；schedule+tool-schedule
skill+skill-filesystem+tool-skill；plan-mode；extensions(tool-cordis 动态装载)

boot/app-boot（profile/bundle/patch 解析）─► CLI/桌面/SDK 全部表面
host/webserver ◄─ client/connection（一包两侧：Host 半边+浏览器半边）
api/gateway（Typert Remote over /api + WS 多路流）─► api/*-controller ─► client/ui-*
bundle/base+web-app+…（把上述一切组装为 profile 行）
```

## 2.3 核心数据流：一次 Web 对话请求的完整路径

以「用户在 Web UI 发一条消息」为例（细节与行号见第 7 章端到端调用链）：

1. **输入**：浏览器 composer（`ui-conversation`）→ `ctx.remote`（Typert 生成方法）→ HTTP POST `/api/<namespace>/<method>`（connection 信封）→ api-gateway 分派 → `api-session-controller` 的 Remote 方法 → `agent.followup()` / `agents.create()`；
2. **入队**：`ReactLoopAgent` 的持久 inbox（session 投影）追加待处理输入，唤醒驱动；
3. **turn/step 循环**（agent-loop/src/agent.ts）：`preStep`（认领输入+组装系统提示+`agent/pre-step` waterfall）→ `step/start` 落日志 → `prepareRequest`（`agent/request` waterfall + `llm.prepareCall` 绑定适配器）→ `buildRequest`（canonical header 比较、工具增删 developer 消息、`session.deriveMessages()` 冻结历史）→ `llm.stream()`（`llm/stream` waterfall → DeepSeek SSE 翻译为 StreamChunk）；
4. **流式结算**：`AssistantStreamAttempt` 聚合块 → `assistant/message`（或失败 `assistant/attempt`）追加进 Session 日志；浏览器侧同时经 `agent/assistant-stream` 活事件→ Web Session-follow 适配器增量渲染；
5. **工具执行**：`tool/call` 落日志 → `tools/pre-execute`（hooks/权限/沙箱）→ 单调守卫 →（ask 时）`ctx.approval` 人工审批 → `tools/execute`（超时/重试环绕）→ 工具体（如 bash→shell→subprocess→sandbox；fs 写→`fs/write-intent` 门）→ `tools/post-execute` → `finalizeContent` → `tool/result` 冻结落日志；
6. **持久化**：Session 写句柄（`SessionPersistence`/JSONL 后端）批量 zstd 压缩追加 `session.v4.jsonl.zstd`；`session/flush` 是耐久屏障；
7. **读侧**：`sessionProjections`（turnBoundary/inbox/todos/goal…）增量折叠供 Host 消费；浏览器经 packed Remote `follow`/`page` 流 + Conversation 节点状态机渲染；
8. **收敛**：无新输入且工具不再欠请求 → `agent/turn-stopping` → `turn/end` → agent 回 idle；UI 呈现最终消息与交付物。

**控制流要点**：插件树在 boot 时由 patch 层装配（第 7 章 7.1）；运行期的一切扩展通过三类事件挂接——**会话事件**（持久事实）、**agent 事件**（活状态）、**能力事件**（fs/*、tools/* 等策略缝）（docs/architecture.md:74-80）。


---

# 第 3 章 目录结构详解

格式：`目录路径 → 职责说明 → 包含哪些关键内容`。文件数为纳入范围的生产源文件数（与附录 A 一致；`vendor/`、`docs/`、`website/`、`.agents/`、`benchmarks/`、`packages/test-support/`、各包 `tests/` 为排除范围，仅在有助理解时提及）。

## 3.1 仓库根

```text
dsh-v0.2.1-alpha.1/
├── apps/               四个应用表面（CLI/Web 前端/Electron 桌面/桌面私有宿主）
├── packages/           ~200 个 @deepseek-ai/dsh-* 工作区包，按 53 个能力组分层
├── native/             C 原生 addon（landlock 沙箱执行器 + flock 文件锁）
├── python/             Python SDK（client + runtime wheel 打包）
├── scripts/            构建编排与 CI 门禁脚本（159 个生产 ts/mjs 文件）
├── benchmarks/         性能门禁（排除范围）
├── docs/               架构文档（理解参考，非分析对象）
├── website/            VitePress 文档站投影（排除范围）
├── vendor/             vendored Cordis 框架（排除范围，peer 依赖 @deepseek-ai/cordis）
├── patches/            外部依赖补丁（pnpm patchedDependencies）
├── snapshots/          快照测试资产（排除范围）
├── tsconfig.{host,client}.json / tsconfig.base.*.json   Host/Client 双编译面 project references
├── tsdown.config.ts    运行时 bundle 配置（构建行为纳入分析，见 §9.2）
├── vitest.*.config.ts  9 个测试配置（排除范围）
├── package.json        根工作区清单（205 个 scripts；见 §1.2-1.3）
├── pnpm-workspace.yaml / Makefile / lefthook.yml / .gitlab-ci.yml
└── README/AGENTS/CONTRIBUTING/SAFETY/BRAND_GUIDELINES(.zh/.i18n.yaml)  双语文档组
```

- 根 `package.json` → 定义 workspaces、`dsh`/`start:web`/`dev:web` 等 205 个脚本、构建工具链依赖（package.json:11-18, 19-204）；
- `tsconfig.host.json` / `tsconfig.client.json` → Host/Client 两个编译程序的 solution 根；`verify-application-entrypoints` 等门禁保证只有 `dsh` profile 能启动 Node 应用（AGENTS.md:13, 47）。

## 3.2 apps/（4 个应用，~190 个生产文件）

| 目录 | 包名 | 职责 | 关键内容 |
|---|---|---|---|
| `apps/cli`（10 文件） | `@deepseek-ai/dsh` | `dsh` 命令行入口与 profile 启动器 | `src/bin.ts`（runCli 四模式分发）、`args.ts`（Commander pass-through 语法）、`profile-boot.ts`（runProfile 装配管道）、`plugin.ts`（dsh plugin 子命令）、`process-shutdown.ts`、`startup-diagnostics.ts`、`dump-config*.ts`、`sdk-source.cordis.patch.yml`（源码启动补丁） |
| `apps/web`（6 文件） | `@deepseek-ai/dsh-web-frontend` | 纯 Vite 构建壳，产出 dist 交给宿主 webserver | `src/main.ts`（浏览器入口，desktop 场景 IPC 握手）、`src/preview.ts`（WebWorker Host 预览 bootstrap）、`vite.config.ts`（双入口、vendor 手工分块、Cordis Loader 浏览器化） |
| `apps/desktop`（158 文件） | `@deepseek-ai/dsh-desktop` | Electron 桌面壳：窗口/自定义协议/更新/托盘/签名 | `src/main.ts`（主进程：`dsh-app://` 协议、请求代持凭证）、`host-process.ts`（spawn Node 模式 desktop-host）、`backend-controller.ts`、10 个 preload-*（contextBridge）、`update-*`/`mandatory-update-*`、`electron-builder.config.mjs`、`scripts/electron-builder-config.mjs`（签名/asar/packaging） |
| `apps/desktop-host`（9 文件） | `@deepseek-ai/dsh-desktop-host`（私有） | Electron 拉起的真正 dsh Web Host | `src/index.ts`（复用 runProfile 启 web profile，`--port 0` 不开浏览器，IPC 回传 authenticatedUrl+injections）、`cli.ts`（安装内 CLI）、`office-engine.ts`、`platform-session.ts`、`update-tasks.ts` |

## 3.3 packages/（53 个能力组，~200 包）

按依赖方向自底向上（各组内子包的完整清单见第 4 章对应节与附录 A）：

| 组目录（文件数） | 职责 | 关键内容 |
|---|---|---|
| `packages/util`（31 文件，16 包） | 零依赖底座原语 | `brand`（名义类型 `Branded<B>`）、`values`（跨 realm JSON 判定）、`home-paths`（`$DSH_HOME`）、`atomic-write`（原子写+文件锁）、`http-proxy`、`native-command`（无 shell 直启宿主命令）、`workspace-path`、`timeout`、`deque`、`lazy-require` 等 |
| `packages/typert`（30 文件，4 包） | 类型图 RPC 系统 | `protocol`（`@Remote` 契约/InvocationDescriptor）、`generator`（TS 源→类型工件发射）、`registry`（运行时注册表，`ctx.typert`）、`loader`（按 Cordis Loader 条目自动导入包的 `./typert` 导出） |
| `packages/boot`（42 文件，5 包） | 应用启动装配 | `app-boot`（profile/bundle/patch/boot/审计，1,067 行 index.ts）、`cmdline`（`ctx.cmdlineArgs/appExit/appReady`）、`hmr`（模块+配置热重载）、`plugin-manager`（profile 插件管理，pnpm 转发）、`config-editor`（活配置表单） |
| `packages/core`（48 文件，7 包） | 产品 API 主干 | `session`（事件日志+surface，`ctx.sessions`）、`agent`（注册表+发起者归因，`ctx.agents`）、`agent-loop`（默认驱动，`ctx.agentLoop`）、`tools`（注册表+守卫管线，`ctx.tools`）、`system-prompt`（`ctx.systemPrompt`）、`scope`（作用域原语）、`agent-default-model`/`agent-tool-presentation` |
| `packages/llm`（84 文件，9 包） | 模型能力族 | `llm`（中立词汇表+`ctx.llm` Runtime+`llm/stream` waterfall）、`llm-deepseek`（官方适配器：SSE 翻译/Files API/thinking 重放）、`llm-deepseek-api-key`/`-account`（凭据源）、`deepseek-llm-api-extensions`（wire 扩展注册表）、`llm-pi-ai`、`llm-retry`、`token-meter` |
| `packages/session`（116 文件，21 包） | 持久会话数据面 | `session-format`（v0→v4 相邻迁移链）、`session-format-catalog`、4 个 `session-format-v*-to-v*` 迁移包、`session-persistence`（缝）、`session-persistence-jsonl`（zstd 分帧+generation 发布）、`session-projection(-cache)`、`session-query(-sqlite)`、`session-title` 族、`session-stats`、`session-telemetry(-otel)`、`session-log-deepseek`、`session-checkpoint-policy`、`session-turn-outline`、`session-log-export` |
| `packages/fs`（29 文件，6 包） | 文件系统能力缝 | `fs`（`ctx.fs` 定义+`fs/write-intent`等事件）、`fs-local`（realpath targetKey+FIFO 锁）、`fs-observation-policy`（先读后写审批）、`fs-sandbox`（可写根围栏）、`tool-fs`（read/write/edit/read_image）、`tool-fs-search`（glob/grep，ripgrep 子进程）、`tool-str-replace-editor` |
| `packages/shell`（27 文件，9 包） | 命令执行能力缝 | `shell`（`ctx.shell`，request/spec split 模板）、`bash-local`/`pwsh-local`、`bash-sandbox`/`pwsh-sandbox`、`shell-env`、`tool-bash(-persistent)`、`tool-pwsh(-persistent)` |
| `packages/subprocess`（35 文件，3 包） | 子进程基座 | `subprocess`（`ctx.subprocess`：spawn/spawnTerminal/环境清洗）、`subprocess-local`（进程树收容：Linux systemd scope / Windows Job Object / PGID fallback）、`win32-process`（FFI） |
| `packages/sandbox`（26 文件，5 包） | 进程围栏 | `sandbox`（`ctx.sandbox.confine` 缝，fail-closed）、`sandbox-local`（bwrap/landlock/seatbelt/windows-acl 平台链）、`sandbox-policy`（`ctx.sandboxPolicy` 唯一策略源+升级编舞）、`sandbox-windows-acl`（受限 token+DACL） |
| `packages/ssh`（13 文件，5 包） | 远端执行世界 | `ssh`（master 复用+远端 Node helper JSON-RPC）、`subprocess-ssh`、`fs-ssh`、`sandbox-ssh`——四缝齐换即整体迁移 |
| `packages/terminal`（12 文件，3 包） | 持久 PTY | `terminal`（`ctx.terminals` owner 作用域注册表）、`terminal-bash`（PTY+OSC 133 提示符标记）、`tool-terminal`（terminal_open/send/read/signal） |
| `packages/lsp`（16 文件，3 包） | 语言服务器 | `lsp`（`ctx.lsp` 扩展名路由）、`lsp-stdio`（懒启动单飞实例）、`tool-lsp` |
| `packages/mcp`（8 文件，2 包） | 外部 MCP 工具桥 | `mcp-client`（stdio/http 连接监督+`mcp__<server>__<tool>` 桥接）、`mcp-resources`（资源三工具） |
| `packages/web`（22 文件，7 包） | Web 能力缝 | `web`（`ctx.web` search/fetch 运行时）、`web-fetch-http`（SSRF 防护+同源重定向）、`web-search-deepseek/exa/perplexity`、`tool-web`（web_fetch/web_search） |
| `packages/browser-use`/`computer-use`（4 文件，2 包） | 排他命名注册槽 | `BrowserUseRegistry`/`ComputerUseRegistry`；实现路线在 `experimental/` |
| `packages/ptc-runtime`（18 文件，2 包） | PTC 执行 | `ptc-runtime`（`ctx.ptcRuntime` 缝）、`ptc-runtime-node`（worker-thread 沙箱实现） |
| `packages/context`（28 文件，6 包） | 模型可见请求上下文 | `agent-instructions`（AGENTS.md 类文件）、`time-context`、`tmux-context`、`file-reference(-local)`（@文件 引用）、`session-reference`（@会话 召回） |
| `packages/compaction`（19 文件，5 包） | 上下文压缩 | `compaction`（`ctx.compaction` 缝）、`compaction-basic`（区间选择+前缀缓存友好摘要）、`compaction-image-offload`、`compaction-tool-result-pruner`、`command-compact`（/compact 命令） |
| `packages/subagent`（73 文件，10 包） | 委托 agent 缝 | `subagent`（`ctx.subagents` provider 注册表+continuable 编排）、`in-process-driver`、`spawn/fork-in-process`、`subagent-acp/claude-code/codex/dsh-sdk`（跨产品 provider）、`tool-subagent(-control)` |
| `packages/workflow`（20 文件，4 包） | 工作流 | `workflow`（`ctx.workflowEngine` 缝）、`workflow-ptc`（沙箱脚本引擎+guest DSL）、`tool-workflow`、`tool-ralph`（Ralph 循环） |
| `packages/jobs`（11 文件，3 包） | 后台任务 | `jobs`（`ctx.jobs` 契约：ring 输出/first-wins）、`jobs-local`、`tool-jobs`（job_output/list/kill） |
| `packages/todo`/`plan`/`goal`/`schedule`（22 文件，9 包） | 任务状态四件套 | `tool-todo`（todo_write）、`plan-mode`（logged planning+exit_plan_mode）、`goal`+`goal-round-driver`+`tool-goal`+`command-goal`（同会话目标）、`schedule`+`tool-schedule`（定时 follow-up） |
| `packages/skill`（7 文件，5 包） | 技能加载 | `skill`（`ctx.skills` 分层作用域发现）、`skill-filesystem`（`.dsh/skills` 等六层根）、`tool-skill`、`skill-badge`、`skill-office` |
| `packages/extensions`（42 文件，4 包） | 运行时自修改 | `cordis-host-runner`（`ctx.dynamicCordisRunner`：VM 求值+专用 fiber 组动态挂插件）、`cordis-client-runner`、`tool-cordis`（cordis_inspect_* 工具，8.9K 行）、`ui-cordis` |
| `packages/hooks`（12 文件，3 包） | CC/Codex 桥 | `hook-protocol`（JSON stdin 执行/解码）、`hooks-claude-code`（SessionStart/PreToolUse/Stop 等事件映射）、`hooks-codex` |
| `packages/guard`（2 文件，2 包） | 循环卫生守卫 | `repeat-tool-reminder`（连击提醒）、`timeout-policy`（tools/execute 超时） |
| `packages/webhook`（8 文件，2 包） | webhook ingress | `webhook`（`ctx.webhookRuntime`：fire-and-forget 规则+Workspace Session 创建）、`webhook-github`（HMAC 验签，202 立返） |
| `packages/feedback`（4 文件，2 包） | 人类反馈 | `command-feedback`（/feedback，`feedback/record` 事件）、`message-feedback`（消息级评分，冷路径直写） |
| `packages/interaction`（15 文件，5 包） | 人工协作面 | `user-approval`（`ctx.approval`，开放 turn 内一次性询问）、`user-questions`（`ctx.userQuestions` waterfall）、`tool-ask-user`、`commands`（`ctx.commands` 斜杠命令）、`permission-presets`（沙箱模式+审批策略捆绑预设） |
| `packages/deliverables`（10 文件，2 包） | turn 交付物 | `tool-present`（present 工具+`deliverables/presented` 事件）、`workspace-changes`（turn 级 git 变更摘要/diff，`ctx.workspaceChanges`） |
| `packages/spill`（9 文件，3 包） | 输出溢出 | `spill`（`ctx.spillStore` 缝）、`spill-local`（文件实现）、`spill-policy`（工具结果 token 预算裁剪） |
| `packages/attachment`（15 文件，2 包） | 二进制附件 | `attachment`（`ctx.attachments`：批量校验/限额/verbatim 拒绝）、`attachment-local`（内容寻址存储+sharp 归一化） |
| `packages/document`（6 文件，1 包） | Office 转 PDF | `office-to-pdf`（`ctx.officeToPdf`：LibreOffice kit+并发/字节限额+内容寻址缓存） |
| `packages/storage`（17 文件，4 包） | 非会话 KV 存储 | `storage`（Backend/KvFacet 缝+命名注册）、`storage-domain`（单域单写链）、`storage-json`、`storage-sqlite` |
| `packages/credentials`（15 文件，5 包） | 凭证/授权 | `credentials`（ref+record 双键空间缝）、`credentials-local`（`.credentials.yaml` 分层+0600）、`authorization`（人类对话式授权缝）、`deepseek-account`（账号抽象）、`deepseek-account-platform`（PKCE 平台实现） |
| `packages/identity`（1 文件） | 匿名身份 | `anonymous-user-id`（`$DSH_HOME/.anonymous-user-id` 裸 UUID） |
| `packages/settings`（4 文件，1 包） | 用户设置 | `settings`（`ctx.settings` 表单投影+volatile 编辑+乐观并发） |
| `packages/workspace`（5 文件，1 包） | 工作区实体 | `workspace`（`ctx.workspaceRegistry`：两阶段写+串行队列+归档/置顶） |
| `packages/telemetry`（5 文件，1 包） | 遥测通道 | `otel`（`ctx.otel`：事件通道+授权会话日志通道，OTLP JSON/HTTP） |
| `packages/host`（32 文件，8 包） | GUI 宿主服务 | `webserver`（`ctx.webServer`）、`frontend-static`、`directory-picker{,-auto,-browse,-native}`、`open-in-app`、`plugin-inventory`、`product-telemetry-otel` |
| `packages/api`（111 文件，9 包） | 远程 BFF | `gateway`（Typert Remote 网关+WS 多路流）、`session-controller`（35 文件最大）、`job/terminal/workspace/settings/account-controller`、`workspace-files`、`remotes`（客户端远端聚合） |
| `packages/client`（1,048 文件，~60 包） | 浏览器半边 | 内核（web/modules/connection/store/locale/hmr/shortcuts/file-upload/resources/product-analytics）、骨架（ui-renderer/ui-slots/ui-primitives/ui-theme/ui-layout/ui-dockkit/ui-session）、对话（ui-conversation 13K 行/ui-chat 12.5K 行/ui-tool/ui-trajectory 9.4K 行）、业务呈现（ui-approval/plan/goal/jobs/schedule/subagent/deliverables…）、侧栏与设置（ui-sidebar*/ui-settings*）——完整分组见 §4.9 |
| `packages/bundle`（7 文件，6 包） | profile 组合层 | `base`（529 行 patch 插 ~90 行核心）、`web-app`（叠 web 层+禁宿主面 per-agent 工具+4 preset）、`headless`、`sdk-app`、`acp-app`、`sdk-minimal`（独立完整树） |
| `packages/preset`（19 文件，3 包） | agent 组合 | `agent-preset-registry`（`ctx.agentPresets`：preset 作用域装载）、`agent-preset`（出厂 preset+插件开发模板）、`persona` |
| `packages/sdk`（14 文件，3 包） | 进程外 SDK | `protocol`（JSON-RPC 类型+transport peer）、`server`（stdio 服务端：事件转发/initialize/prompt/shutdown）、`client`（TS 客户端：拉起 `dsh --profile sdk`） |
| `packages/acp`（7 文件，1 包） | ACP 自动化 | `acp`（Agent Client Protocol JSON-RPC stdio 服务端） |
| `packages/experimental`（424 文件，24 包） | 实验区 | agent-team 四件套、浏览器/computer-use 五+二路线、语音输入五件套、inspector（16.7K 行 CDP hub）、claude-code-mods（4.2K 行）、webworker-runtime/packer（13.4K 行）、auto-review、ptc-runtime-python、speech-to-text(-sensevoice)——详见 §4.11 |
| `packages/test-support`（排除） | 测试基础设施 | testkits/replay/mock server |
| `packages/`（53 个组 README） | 组级包地图 | `packages/README.md` 的权威分组表（packages/README.md:29-84） |

## 3.4 native/ 与 python/ 与 scripts/

| 目录 | 职责 | 关键内容 |
|---|---|---|
| `native/system`（16 文件） | `@deepseek-ai/node-addon-system` | C 源码：`packages/entry/src/main.c`（`landlock-run` 静态 musl 可执行）、`flock.c`（Node-API v8 addon）；`scripts/build.ts` 直接 spawn musl-gcc/cc（无 node-gyp）；JS 入口 `packages/entry/src/index.ts`（`launcherPath()/grantArgs()/probe()`、`tryLockExclusive()`）；平台 prebuilds 经 npm optionalDistributions 分发 |
| `python/sdk`（6 文件） | Python SDK 客户端 | `client.py`（同步换行分隔 JSON-RPC 2.0 over stdio，reader 线程三分发）、`api.py`（`DeepSeekHarness` 高层 API：initialize/Session.run）、`runtime.py`（bundled runtime 解析） |
| `python/sdk-runtime`（4 文件） | runtime wheel 打包 | `hatch_build.py`（wheel-only，校验 exe+ripgrep+office kit payload）、`__init__.py`（生产=单文件 Node exe；dev=deploy closure） |
| `scripts/`（159 文件） | 构建与门禁 | 行为关键：`build.ts`（全仓编排）、`dev-web.ts`（三 watcher+启动一条龙）、`primary-runtime/prepare.ts`（锁定可重定位解释器）、`release/{pack,publish,bump,verify}.ts`、`build-exe-for-python-sdk.ts`；其余 ~60 个 `verify-*` 门禁 + `gen-*` 生成器 + `persistence-*` + `translation-*`（CI 性质，归类不逐个展开） |


---

# 第 4 章 核心模块详解（报告主体）

> 本章按依赖方向自底向上分 9 节，对应批次计划 2~6。每节内：**模块职责 → 文件组成 → 关键类/函数解析 → 对外接口**。行号引用基于源码实读。

## 4.1 基础层：util / typert / storage / credentials / identity / settings / workspace / telemetry

### 4.1.1 packages/util（16 个零依赖子包）

**模块职责**：全仓共享的底层原语库，不注册任何产品服务/事件（packages/util/README.md:12）。是依赖图的叶子。

**文件组成**：每包基本单文件 `src/index.ts`；较大者 `native-command`（8 文件）、`http-proxy`（3 文件）。

**关键内容**：
- `brand`（40 行）：`Branded<B>` 名义类型构造器——跨包 id 一律 branded string，禁裸 `string`（AGENTS.md:143）。
- `values`（976 行）：`snapshotJsonValue` 单遍"读-验-拷贝"，`hasIntrinsicConstructor`（index.ts:18-29）用 `Function.prototype.toString` 对比构造器防跨 realm 伪造——被 Session.append 与 webhook 复用为无损 JSON 快照的唯一实现。
- `home-paths`：`resolveDshHome()` 解析顺序 `$DSH_HOME` > `~/.dsh`，是 identity/credentials/profile 的共同地基。
- `atomic-write`（269 行）：`writeFileAtomic`（临时文件+rename）与 `withFileLock`（native flock 跨进程锁，Linux 用 `native/system` 的 addon）。
- `http-proxy`：`installProxyFromEnvironment(snapshot, log)` 在任何插件装载前让 Node fetch 遵循 `.env` 声明的代理（profile-boot.ts:249-252 的注释解释了为什么必须启动期做）。
- `native-command`：无 shell 直启宿主命令（打开目录/URL/文件）、Linux `.desktop` 解析。
- 其余：`timeout`（deadline 信号融合）、`deque`、`chunked-list`、`output-retention`（输出保留策略）、`workspace-path`（浏览器安全的 file-address）、`code-language`、`package-manifest`、`lazy-require`、`time`、`crypto`（UUID v4）、`launch-environment`（启动环境快照类型）。

**对外接口**：纯函数库；无 ctx 键。

### 4.1.2 packages/typert（类型图 RPC，4 包）

**模块职责**：让浏览器客户端以**类型化方法调用**访问 Host 能力：Host 侧 `@Remote` 装饰器声明方法 → generator 生成类型工件 → 浏览器侧生成 `remote.<namespace>.<method>()`（packages/typert/README.md:12）。

**文件组成与关键实现**：
- `protocol/src/types.ts`：`TypertRemoteMap`（:42，声明合并的远端契约表）、`RemoteResult<T>`（:76，`{ok:true,value}|{ok:false,error}`）、`RemoteStream<Out,In>`（:93）、`InvocationDescriptor`（:318，含 wire 参数名/strict codec/scope 投影）。
- `generator/src/index.ts:8-16`：`WorkspaceAnalyzer`（TS 源分析）+ `FaceModelEmitter`（反射/schema/Remote 工件发射）+ `cordis-catalog`，经 `tsdown-plugin.ts` 挂进构建。
- `registry/src/service.ts`：`TyperTRegistry extends Service`（:447，`ctx.typert`）。内部五张 store：schemas（懒物化 Zod，`materializeSchema` :642 用 `record.value ??= record.create()` 缓存）、packages、local/remote DescriptorStore（端点+id 双索引，重复注册即抛 :121-136）、LookupStore（Host 对象查找 :250-262）、ContextStore。全部经 `ctx.effect` 注册保证 fiber 卸载回收（:500-521）。`validateInvocation`（:661-723）是 RPC 端点契约运行时守卫。
- `loader/src/index.ts`：`inject=['typert','loader']`（:45），监听 `internal/plugin` 事件按 Loader 条目增量扫描（:438-449）；发现包导出 `./typert`（`TYPERT_HOST_EXPORT` :40）即 import 并 `validateTypertManifest`（:89）后注册。激活期失败聚合抛错，稳态期单包失败仅记日志（:458-463）。

**对外接口**：`ctx.typert`（注册表）；`TypertRemoteService` 基类（业务服务继承后即可被 Remote 调用）；`@Remote`/`@RemoteScope` 装饰器。

### 4.1.3 packages/storage（非会话 KV，4 包）

**模块职责**：会话日志之外的结构化持久化（设置、workspace、schedule、投影缓存等）。
- `storage/src/backend.ts:17-133`：`StorageBackend`/`KvFacet`/`KvUnit` 抽象；`registry.ts:14-62` 命名后端注册表。
- `storage-domain/src/domain.ts`：`DomainImpl` 单域单写链——先耐久写、再改内存、后发 `domain/changed`（:140-200）；`KvTable.get/put/delete/update`（:42-90）。
- `storage-json`：文件后端（atomic 临时文件写、single-unit/per-record-unit 布局）；`storage-sqlite`：SQLite 后端（session-query FTS5 与 projection-cache 使用）。

### 4.1.4 packages/credentials（5 包）+ identity + settings + workspace + telemetry

**credentials**：
- `credentials/src/index.ts:170`：`CredentialProvider extends Service`（`ctx.credentials`）。双键空间：`CredentialRef`（POSIX 环境变量名，:29）与 `CredentialKey`（`<scope>/<id>`，:69）。抽象方法两半：ref 半 `resolve/describe/set/unset`（:183-209）+ record 半 `readRecord/.../modifyRecord`（:217-256）；`modifyRecord` 是唯一写路径（读-改-写串行化，支撑 token 轮换 :247-250）。
- `credentials-local`（910 行）：分层 `继承环境(只读) > $DSH_HOME/.credentials.yaml(可写) > cwd/.env > $DSH_HOME/.env`（index.ts:5-10）；`assertOwnerOnly`（:127）POSIX 拒绝 group/other 可读；30s 跨进程写锁；0600 原子写。
- `authorization`（`ctx.authorization`）："凭证需要与人对话才能获得"的授权对话缝——`AuthorizationFlow`（:125）与每 key 同时仅一次尝试的 InFlight（:191）。
- `deepseek-account`（抽象 `ctx.deepseekAccount`）+ `deepseek-account-platform`（PKCE 实现，`platformOrigin` 默认 `https://platform.deepseek.com`，index.ts:53）。

**identity/anonymous-user-id**（101 行）：`getOrCreateAnonymousUserId()`（index.ts:68）——`$DSH_HOME/.anonymous-user-id` 裸 UUID 行；并发首发用 `flag:'wx'` 独占，败者重读采纳胜者（:79-96）；绝不来自主机名/git remote。

**settings**（707 行）：`SettingsForms extends Service`（`ctx.settings`，index.ts:223）。把各插件 Schemastery Config schema 投影为表单；三个写路径语义分明——`update`（merge）/`replace`（重置 volatile 再覆盖）/`mutate`（路径级 ops，专为调用方只持有脱敏视图设计，:73-80 注释）；`SettingsConflictError` 乐观并发（:45-64）。

**workspace**（1,412 行）：`WorkspaceRegistry extends Service`（`ctx.workspaceRegistry`，index.ts:170）。核心是**串行变更队列 + 两阶段写**：`enqueueOperation`（:886-895）把所有写串成 promise tail 且每次先 `recoverPendingMutation`（:634，按 pendingMutation 标记决定补删或报不一致）——崩溃可恢复；按 canonical cwd 归属 Session（`indexHeader` :804）；归档/置顶是注册表全局集合且互斥。

**telemetry/otel**（450 行）：`ctx.otel` 仅工厂（index.ts:13-31）。两条通道：`createEventReporter`（计数式产品事件，"never a prompt, response, credential, or file contents"，event-log.ts:20）与 `createSessionLogReporter`（**授权上传的**会话日志，单条 4MB 字节上限，超限整条拒绝不截断，session-log.ts:13,98-100）；传输为 OTLP JSON over HTTP（transport.ts:12-36）。

## 4.2 数据与模型面：core/session、session/*、llm/*、attachment、spill、compaction、context、document

### 4.2.1 packages/core/session — 追加式会话事件日志（最核心数据结构）

**模块职责**：会话=事件日志。`Session` 内存对象维护 log 与派生面；`SessionStore`（`ctx.sessions`）是注册表与事务入口。事件经 `dsh-scope` 的 Scoped carrier 做 agent 作用域过滤。

**文件组成**（10 文件）：`index.ts`（Session+SessionStore，1,324 行）、`types.ts`（SessionEventMap/SessionSeq/Header）、`surface.ts`（消息面折叠，679 行）、`repair.ts`（中断修复）、`fork.ts`（fork seed）、`request-header.ts`（EpochHeader 折叠）、`preparation.ts`（SessionPreparation using 事务）、`tool-history.ts`、`seq-ranges.ts`、`known-event-types.ts`。

**关键函数解析**：

**`Session.append(type, data)`（index.ts:718-769）**
- 签名：`append(type: E, data: SessionEventMap[E])` → 无返回（同步提交）。
- 实现：① `snapshotJsonValue(data)` 单遍完成"验证+深拷贝"（:728，防 getter 在验证与序列化间返回不同值）；② 组装 `deepFreeze({type, seq: log.length, time, data, surfaceOp?, sourceEventSeqs?})`（:740）——**seq=log.length 的连续性是全系统契约**（:677）；③ `validateSessionEventData` + `surfaceManager.validateNext`（:747-748）；④ `appending` 标志防重入（:737）；⑤ push 后通知观察者发布 `session/event`（:757-761，逐监听者容错）。
- 副作用：内存 log 追加 + 事件广播（持久化后端在 append 钩子中缓冲）。

**`deriveMessages()`（index.ts:856-877）— 模型历史的唯一来源**
- 实现：遍历 `surface.nodes`（有序可见消息 seq 列表）逐个 `deriveEventMessage`；缓存按 `surface.contentGeneration` 失效——`replace`（压缩）或投影变更则全量重建（:860-864），纯尾部增长时 O(新增节点)（:865-874）；空内容 assistant（max-tokens 步骤）派生为 null 不入 transcript（:871-873）。
- 设计意图（架构文档 docs/architecture.md:123-127）：模型可见的一切可由日志重建；消息历史不是日志而是投影。

**`SurfaceManager`（surface.ts:612-679）**：增量折叠 `surfaceOp` 标记；`replace` 计划做节点区间 splice 并 `replaceGeneration++/contentGeneration++`（:569-572）；`foldSurface`（:594-609）提供全量重放（seed/restore 与活 append 走同一 `planSurfaceEvent` 转移）。

**增量折叠游标**：`requestHeader()`（:784-794）、`requestContext()`（:805-813）、`toolHistory()`（:825-829）都用 `xxx`FoldSeq 游标只消费新事件——`request/header` 事件 reason ∈ initial/resume/change/series（types.ts:273）是"换模型/换工具集"的日志载体。

**`SessionStore` 事务三段式**：`prepare`（:1014-1057，构造不发布）→ `enter`（:1081-1115，装 append 钩子+入表）→ `announce`（:1136-1164，emit `session/created`，同步 throw 回滚）。`fork`（:1251-1269）：按 seq 边界切前缀 + `buildForkSeed` 合成 forked-closers。`flush`（:1190-1207）：唯一耐久屏障入口，awaited-parallel 触发 `session/flush`。

**`repair.ts`**：`interruptedTurnClosers`（:209）扫描开放的尾部 turn，为未应答 tool-call 补合成错误结果（`ToolCallRecovery` :105-198 区分 `TOOL_NOT_STARTED/TOOL_OUTCOME_UNKNOWN`，文案引导模型按幂等性决定是否重试）+ 补 `step/end`、`turn/end`——resume 时由 agent-loop 调用（agent-loop/src/index.ts:855-856）。

**对外接口**：`ctx.sessions`；`Session`（append/deriveMessages/requestHeader/fork...）；`SessionEventMap`（merge 可扩展：turn/*、step/*、user|developer|system|assistant/message、assistant/attempt、tool/call|result、request/header|context、agent/inbox/*、todo/write、goal/* 等约 30 种）；`SESSION_FORMAT_VERSION=4`（types.ts:89）。

### 4.2.2 packages/session 卫星包（21 包）

**持久化缝与 JSONL 后端**：
- `session-persistence/src/index.ts:135-202`：抽象 `SessionPersistence extends Service`（`ctx.sessionPersistence`）。接口：`create(header,opts)→SessionHandle`（:150）、`open(id,'read'|'write')`（:165，write 原子单写者）、`flush()`（:178 全局耐久屏障）、`stat(id)→Snapshot{header,revision,eventCount,sizeBytes}`（:194，revision 为不透明变化令牌）、`list()`（:201）。`handle.ts:59-117` 定义 `SessionHandle`（read/append/flush/close；append best-effort、flush 才承诺崩溃存活）。
- `session-persistence-jsonl`（14 文件，5,005 行）——物理实现：
  - **zstd 分帧**（zstd.ts:48-156）：`scanZstdFrames` 手写 Zstandard 帧结构扫描（magic 0xFD2FB528/FHD/块头/可选 checksum），不完整尾帧返回 `tornStart`；`compressZstdFrame` 每批独立可解+开 checksum（:111）；`decompressZstdPrefix` 用 `ZSTD_e_flush` 恢复撕裂帧中已到达明文（:154）。
  - **容器布局**：header 独占第一帧（index.ts:77-81），之后每个 append 批次一帧（:1302-1305）。读路径 `readZstdPrefix`（:939-1022）每 500ms `scheduler.yield()` 让出事件循环（:74,971-975）；写路径先 `truncateTornTail`→repair 再重写（:889-893,1365）；append 失败回滚到原 size 防重复 seq（:1324-1352）。
  - **generation 选择与发布**：目录 `<root>/<projectDir>/<encodedSessionId>/log.v<N>.jsonl[.zstd]`；`resolveGenerationInDirectory`（:1447-1483）取数值最高代；旧代打开不立即迁移，**write open 才**在 worker 中 `verifyCurrentGenerationInWorker` 验证后以 `link()+unlink()`（POSIX，防 TOCTOU 覆盖）独占发布新代（generation.ts:122-127；index.ts:692-714,1195-1235）——"已提交的代永不重命名/替换/删除"（AGENTS.md:7）。
- **格式迁移链**：`session-format`（`CompiledSessionFormatChain` 强制相邻 vN→vN+1 无缺口，chain.ts:41-87）+ `session-format-catalog`（汇总 v0→v4 + 终验，current.ts:38-52）+ 4 个迁移包（各 `package.json` 声明 `sessionFormatMigration:{from,to}`）。后端构造时校验 catalog 版本==SESSION_FORMAT_VERSION（jsonl index.ts:273-277）。

**读侧投影框架 `session-projection`（740 行）**：`ctx.sessionProjections`（index.ts:30-34）；`ProjectionDefinition`（:48-93）= key+stateSchema+`init/apply` 纯同步折叠+可选 wire view+`stateVersion`。`SessionProjectionRegistry`（:199）订阅 `session/event` 惰性 drive（:657-704，apply 后按 `Object.is` 判引用变化再决定通知）；`snapshot()`（:338）一致切面；`checkpoint/restoreFloor/viewCheckpoint/restore`（:396/425/448/495/552）构成持久化缓存读梯（0-IO viewCheckpoint → checkpoint+尾部重放 restore）。配套 `session-projection-cache` 把 checkpoint 落在 storage。

**其余卫星**：`session-query`（`ctx.sessionQuery`：live 优先精确读/过滤/trace + `SessionCorpus` 游标分页，index.ts:85-100）、`session-query-sqlite`（FTS5 全文后端）、`tool-session-query`（模型侧会话查询工具）、`session-title` 族（唯一 provider 缝+LLM 策略×2+`session-title-llm` 基类）、`session-stats`、`session-turn-outline`、`session-log-export`（归档导出）、`session-telemetry(-otel)`、`session-log-deepseek`（授权日志上传）、`session-checkpoint-policy`。

### 4.2.3 packages/llm（9 包）— 模型词汇表与适配器缝

**`dsh-llm`（13 文件，4,016 行）**：
- `types.ts`：provider 中立词汇表——`StreamChunk` 七种（block-start/text-delta/reasoning-delta/tool-call-delta/block-end/usage/finish，:452-464）；`GenerateOptions`（:511-553，含 `toolHistory`、`purpose:'compaction'|'session-title'`）；`ReplayEnvelope`（:430）；`ContentBlockMap`（:137，merge 可扩展：text/reasoning/image/file/tool-call/tool-addition/tool-removal）。
- `index.ts`：`ctx.llm: LlmRuntime`（:57-60）；`llm/stream` waterfall（:75）；抽象类 `LlmAdapter`（:208-291，唯一必须实现 `stream(options)`）；`LlmRuntime` 持 adapters/directory/discoveries 三张 Map（:343-348）。

**关键函数 `LlmRuntime.prepareCall(config, signal?)`（index.ts:929-976）**
- 签名：`(config: LlmCallConfig, signal?) → Promise<PreparedLlmCall>`。
- 实现：取 registration → `adapter.prepareCall()` 捕获"模型元数据+单代 dispatch"二元组（:929-931）→ `normalizeModelInfo` 校验脱离（:932）→ `resolveCallWithInfo` 校验 reasoningEffort 并物化默认 maxTokens（:885-919）→ `deepFreeze(structuredClone(...))` 得不可变 config/context/adapterDefaults（:934-945）。返回冻结句柄：`stream(options)` **只能派发一次**且 config 必须逐字段相等否则 `INVALID_PREPARED_CALL`（:957-966）；派发走 `streamWithRegistration` 把 registration 绑进 waterfall（:968-973）——防止 HMR 把 A 代能力与 B 代端点拼接。
- 调用关系：agent-loop 的 `prepareRequest`（agent.ts:547-596）调用它绑定路由。

**`adapterStream`（index.ts:1026-1115）最终边界**：① 请求投影——`projectFilesToText`（文件永不原生发给 provider，:1060-1062）、text-only 模型 `projectImagesForTextModel`（:1063-1067）、`projectToolUpdates` 按模型能力裁剪工具增删（:1069）；② `forAdapter` 剥离非本适配器持有的 replayState（:985-999）；③ 迭代器任何 throw 归一为终态 `finish{error|aborted}` chunk（:1082-1099），消费者/中间件异常保持抛出。

**`BlockAssembler`（assembler.ts:38-208）**：`push()` 按 index 维护 PartialBlock，容忍无 block-start/end 的纯 delta 协议；`assembled()`（:135-150）实现"单一 keep/drop 决策"——`finish.kind==='max-tokens'` 时丢弃无法安全执行的 tool-call 块并同步修剪 ReplayEnvelope.blocks；`interruptedBlocks()`（:169）只保留非空前缀；`message(source)` 产出冻结 assistant 消息（:205）。

**`dsh-llm-deepseek`（25 文件，2,830 行）— 官方适配器**：
- `adapter.ts`：`DeepSeekAdapter.prepareCall` 捕获 connection 快照并闭包绑定 `generate(options, connection)`（:43-46）；`generate`（:51-73）用 `AbortSignal.any` 合并消费者信号+本地 controller，套 `idleWatchdog` 流空闲超时（`MESSAGES_IDLE`→`TIMEOUT`，:54,63）。
- `request()`（:75-159）主流程：`prepareImages` 解析图片版本 → `resolveAuth` → RequestFiles 循环（先试 Files API `prepareFileIds`，`FileResolutionFailure` 则 inline 重试 :93-100）→ `serialize()` 组 body → `prepareRequestExtensions` 注入 wire 扩展（:106-112，失败降级）→ 按内容决定 `anthropic-beta` 头（:114-119）→ 直接 `fetch(baseURL/messages)`（带 `anthropic-version: 2023-06-01`、`x-deepseek-harness-session-id`、compaction 加 `x-deepseek-harness-compact:1`，:120-131）→ 非 2xx 先问 `files.retry(detail)` 换 file_id 重试（:140）→ 成功 `extensions.accept()` 两段式提交 → `yield* translate(parseSse(...))`（:145-147）。
- `translate.ts:104-166`：SSE 状态机（message_start/content_block_*/message_delta/message_stop）；wire index 重映射为紧凑 block index（:124）；`thinking→reasoning` 保留 `signature` 进重放（:52-53）；stop_reason 映射（end_turn/stop_sequence→stop、tool_use→tool-calls、max_tokens→max-tokens，:90-97）；终止时校验 tool JSON（max-tokens 除外 :151-158）、发 usage 与带 replayState 的 finish（:159-161）；流提前结束抛 `STREAM_CLOSED`（:165）。
- `deepseek-llm-api-extensions`：`ctx.deepseekLlmApiExtensions` 顶层请求字段独占注册表，`prepare` 产出冻结 JSON+可选 `accept()` 回调，`acceptAll` 用 allSettled 聚合失败（index.ts:41-48）——与适配器"一次准备-接受事务"配合。
- 凭据源两包：`llm-deepseek-api-key`（credentials ref → DEEPSEEK_API_KEY）、`llm-deepseek-account`（平台账号 token）。搜索 provider `web-search-deepseek` 也走 Anthropic 兼容 `/messages`+服务端 `web_search_20250305` 工具。

**其余**：`llm-pi-ai`（pi-ai 库适配，多 provider）、`llm-retry`（`agent/request-error` 决定重试）、`token-meter`（`ctx` 计量 surface token，供压缩决策）、`plugin-package-inventory-deepseek`（模型能力清单）。

### 4.2.4 attachment / spill / document / context / compaction

**attachment（2 包）**：`ctx.attachments: AttachmentStore`——`saveImages` 批量先全验后存（index.ts:98-105）、`admitPromptContent` 上传图→durable ref（:114）、`saveFile` 逐字节 verbatim 默认拒绝（:188-194）、`validateImageBatch` 数量/字节/mediaType 限额（:77-91）；`attachment-local` 内容寻址 file-store+sharp 归一化。

**spill（3 包）**：`ctx.spillStore` 仅 `saveText(input)→SpillRef`（spill/src/index.ts:45-56，locator+检索指引，无保留策略）；`spill-policy` 挂 `tools/post-execute` 按预算裁剪工具结果——图片用 `ctx.llm.imageRequestPricing` 精确定价（index.ts:57-75），超限文本 spill 到磁盘、内联留 `[...]` 摘要与可恢复地址。

**document/office-to-pdf**：`ctx.officeToPdf`（index.ts:26）LibreOffice kit 转换器+并发/字节/DPI 限额（:31-60）+内容寻址 PDF 缓存与队列。桌面/文档预览共用。

**context（6 包）— 模型可见请求上下文注入器**：`agent-instructions`（AGENTS.md 类指令文件的 digest/render/state，1,838 行）、`time-context`（当前时间注入 prompt 变量）、`tmux-context`、`file-reference(-local)`（`@文件` 引用文法+搜索展开）、`session-reference`（`@会话` 召回，注入 `recall` form 上下文，986 行）。

**compaction（5 包）— 上下文压缩**：
- `compaction`（缝）：抽象 `CompactionEngine.compactIfNeeded(agent, trigger, signal)`，trigger∈pressure|context-overflow（index.ts:88-140）；`compaction/summary-error` waterfall。
- `compaction-basic`（默认实现）**区间选择算法**（region.ts:117-155）：① 校验 token-meter 表面==当前 surface（:126-129）；② 跳过 surface 节点 0 的 system head（:131）；③ 自尾向前累计 token 直到保留预算 `retainTokens`（:135-141）；④ `toolPairingBalancedBefore` 回退避免拆开 assistant tool-call/tool-result 对（:143-148）。**事务**：同步写 `compaction/start` 持久锁 → 异步摘要 → 表面稳定性复验（`SurfaceChangedError` :77）→ `compaction/end`+替换 user checkpoint。**摘要器** `summarizeWithLlm`（summarizer.ts:120）刻意**重放原对话前缀**（system/tools/消息原样 :79-84）+固定 8 节模板指令作最后一条 user 消息（:32-67）——辅助调用即"最后一次路由请求的真前缀"，**命中 provider KV 前缀缓存**；输出包 `<compacted-summary>` 标签落盘并附审计包（:87-107）。
- `compaction-image-offload`（响应 `IMAGE_OFFLOAD_REQUIRED`）、`compaction-tool-result-pruner`、`command-compact`（/compact 命令）。


## 4.3 核心驱动与工具 IO 面：core 其余 + fs/shell/subprocess/sandbox/ssh/terminal/lsp/mcp/web/…

### 4.3.1 packages/core/scope — 作用域原语

**模块职责**：每 agent 注册单元的底层机制（library，无 ctx 键）。
- `createScope`（index.ts:137-147）：`ctx.plugin(noop)` 建 fiber + `ctx.extend({[kScope]:key})`；
- `scopeTarget`（:170-185）：构造事件分发 carrier——未打标监听者全局可见，打标监听者匹配 key 或其祖先（事件沿链上行）；
- `bindScopeParent`（:72-82）：一次性绑定+环检测；
- `store.ts` 的 `ScopedLayers/NamedEntries/AnonymousEntries` 是 tools 与 system-prompt 分层注册（全局层+作用域链，同名遮蔽 shadowing）的地基。
**被依赖**：agent（agent scope）、tools、session、SDK server、skill、preset registry 等。

### 4.3.2 packages/core/agent — Agent 注册表与发起者归因

**模块职责**：`Agent` 接口 + 活注册表 + 进程内因果归因。
- `ctx.agents: AgentRegistry`（index.ts:245）；`AgentFactory` 接口（:171-203，`createAgent/resume`）由 agent-loop 实现并 `setFactory`（:358-374）注册——**UI/hook/工具只依赖此接口，loop 可整体替换**。
- **AsyncLocalStorage 双槽** `initiators/initiatorRuns`（:248-249）：`currentInitiator/requireInitiator/withInitiator/withoutInitiator`（:295-344）实现"谁发起了这次工作"的进程内归因——schedule/goal-round 等自动驱动用 `withoutInitiator`，webhook 等用 with 标注来源。
- typert lookups（:257-269）：session/agent 双注册，SDK/ACP 用字符串 id 解析活对象。
- 其余文件：`dispatch.ts`（`agentEvents` 融合分发器+`assembleContextFor`）、`model-selection.ts`（`installModelSelection`，headless 用）、`archive-admission.ts`（turn 运行中拒绝归档）、`projection.ts`（TurnBoundaryProjection 类型）。

### 4.3.3 packages/core/agent-loop — 默认驱动（系统心脏）

**模块职责**：实现 `Agent` 接口的 turn/step 状态机；创建/恢复/拆除 agent 生命周期事务；注册 turnBoundary 与 inbox 两个共享投影。

**文件组成**（7 文件）：`index.ts`（工厂与生命周期，893 行）、`agent.ts`（`ReactLoopAgent` 主循环，688 行）、`tool-calls.ts`（并行调度器）、`inbox.ts`（持久 inbox 投影）、`runtime-context.ts`（system prompt/runtime-context 两条 surface 消息投影决策）、`assistant-stream.ts`（流式 attempt 结算）、`constants.ts`。

**服务声明**：`AgentLoop extends Service implements AgentFactory`，`static inject = ['agents','sessions','llm','tools','systemPrompt','sessionProjections']`（index.ts:330-331）。

**关键类解析 — `ReactLoopAgent`（agent.ts:98）**：

**Phase 状态机**（:42-50）：`idle{lastTurn}` | `maintenance{abort,wakeRequested}` | `running{abort,turn,step,wakeRequested}`；`setPhase` 发布 `agent/status`（:145-152）。

**唤醒 `wakeDriver`（:214-235）**：idle 则建 running phase 并 `loopCtx.agents.withInitiator(this, () => this.kick())`（:234，发起者归因边界）；maintenance/已中止活动则锁存 `wakeRequested` 供收敛后重放。

**驱动 `kick`（:252-265）**：`while (await this.turn()) {}`；finally 回 idle 并重放锁存唤醒。

**`turn()`（:296-396）核心循环**：
1. append `turn/start`（:305）；
2. 内层 `while(true)`：
   - `preStep(target, {turn,step})`（:267-286）= `inbox.claim` 认领输入 + `systemPrompt.assemble` + `runtimeContext.project` + `agent/pre-step` **waterfall**（监听器可 reject → turn 以 blocked 结束；可改写认领消息；可声明 `startsRequestSeries`）；
   - append `step/start`（:329）；
   - 注册 `ToolCallRecovery` 观察者（:331-334）——step 抛错时补齐 pending tool/result（:344-352）；
   - `stepEnd = await this.step(decision)`（:338），max-tokens 粘性（:341）；
   - finally 必 append `step/end`（:356）；
   - `turnEnds && inbox 无 next-step 输入` → `agent/turn-stopping` serial 事件后 break（:359-363），否则 `target='next-step'` 继续；
3. finally append `turn/end{reason}`（:385）；
4. inbox 仍有 pending 且非异常 → 换新 AbortController 继续下一 turn（:390-395）。

**`step(decision)`（:398-544）**：
- `prepareRequest`（:547-596）：以持久 header 为基线、剥掉 adapter 默认值（`requestProposal` :64-70）→ `agent/request` waterfall 供改写 → `llm.prepareCall` 绑定适配器（取消时既不提交 system 也不提交 users）；
- `buildRequest`（:599-687）：canonicalHeader 比较——首请求记 `request/header{reason:initial|resume}`、变化记 `change`、新系列记 `series`（:618-634）；工具集差异附加 `developer/message`（tool-addition/removal，:635-648）；`request/context` 记录路由元数据（:660-666）；最后 `session.deriveMessages()` 深冻结为请求消息（:671-677）；
- **流式**：`AssistantStreamAttempt` 逐 chunk push（:440-443）；中断也把前缀结算为 `assistant/message{interrupted:true}`（:448-477）；错误经 `agent/request-error` waterfall 决定 retry（:494-509）；
- 无 tool-call → `completed`；有则 `executeToolCalls`，`concludesTurn` 传播（:530-538）。

**工具并行调度 `executeToolCalls`（tool-calls.ts:60-102）**：按 `ctx.tools.executionMode` 分组——exclusive 成屏障、parallel 进有界滚动池；`runGroup`（:122-247）走 ToolRuntime 的调度器三段 `prepare→dispatch→finalize/finish`；`commitReady` 只按模型序提交相邻就绪槽（:147-161）；abort 时已启动调用排干并提交、未启动调用补 `tool/call + tool/result(ABORTED_BEFORE_DISPATCH)` 合成对（:238-243,250-260）——**保证日志重放永远平衡**。

**工厂事务（index.ts）**：
- `prepare`（:479-640）建立 memoized 反向拆除 dispose：停机 → 排干并关闭会话写句柄 → 退注册表 → 解 scope；三源 abort 融合（caller signal/owner fiber/factory teardown，:507-515）。
- `create/createAgent`（:652/:714）与 `resume/resumeWith`（:807-890）：resume 先 `persistence.open(id,'write')` 抢写权 → 冷读全量 → `interruptedTurnClosers` 修复 → seed 构造 Session → setup→commit→publish。
- 构造器注册 `turnBoundary`（:46-95）与 `inbox`（inbox.ts:27-65）投影；提供 prompt 变量 `provider/model/cwd`（:370-372）；按 config 启动声明式 agent（:374-404，launcher 可用 `CONFIGURED_AGENT_IDENTITIES_KEY`（:266）覆写身份——webhook/桌面用）。

**对外接口**：`ctx.agentLoop`（AgentLoop）；`Agent`（followup/inject/cancel/whenIdle/status...）；`agent/*` 事件族（created/disposed/status/error/pre-step/request/request-error/turn-stopping/assistant-stream/inbox/*）。

### 4.3.4 packages/core/tools — 工具注册表与守卫执行管线

**模块职责**：`ctx.tools: ToolRuntime`（index.ts:807）——作用域工具注册表 + 六段守卫执行管线 + PTC 传输工具。

**事件**（:137-210）：`tools/pre-execute`（waterfall：allow/deny/cancel/ask）、`tools/execute`（around：超时/重试/指标）、`tools/post-execute`（accept/block）、`tools/result`（emit，冻结终态）、`tools/change`（注册变动）、`tools/ptc-dispatch-log`。

**关键函数解析**：

**`register(definition)`（:1063-1088）**：强制 `output {schema, render, presentationMeta?}`（:213-219）——**工具只返回规范化 JSON 值**，渲染为模型内容由 `output.render` 完成（UI 卡片由 presentationMeta）；保留名 `run_code` 拒绝（:1080-1082）；注册经 `ScopedLayers.effect`，变更触发 `tools/change`（:833-836）。

**作用域视图 `view()`（:1178-1219）**：祖先链层+全局层构成继承面；`restrict`（:1097-1124）对**继承面**求交（allow/deny 编译集合，:1200），本层自有注册豁免（:1204-1209，保住子代理结构化输出机器）；`modeFor`（:922-933）沿链取最近 `presentAs` 声明（preset 按 agent 选择 PTC/native，:974-1002）。

**执行管线 `execute → prepareExecution → dispatch → finalize`**：
1. `createExecution`（:1391-1481）：物化并深冻结参数、分配 token、处理 **PTC 塌缩**（非 native scope 下其它工具调用被替换为"改走 run_code"的明确指引 final-result，:1401-1474）；
2. `tools/pre-execute` waterfall → `ask` 经 `serviceAsk`（:1727-1768）接可选 `ctx.approval`（无服务/无 agent **降级为 deny**，fail-closed）；
3. **单调守卫** `guardReason`（:1145-1154）：守卫只能把调用变 deny，不能翻案 allow（:1519）；
4. **dispatch**（:1601-1631）：`tools/execute` around waterfall 包裹 `dispatchToolBody`（:1564-1592，caller 信号与 wrapper 信号熔断 `fuseToolSignals` :1928，不放弃已启动 promise）；
5. **finalize**（:1641-1659）：`projectContent` 投影 → `postExecute`（:1781-1820，accept 可换 content/value、block 变 isError+feedback）→ `finishScheduledExecution`（:1669-1684）：`finalizeContent`（必经最后一步）→ `materializeFinalResult`（:1886-1901 无损快照+深冻结）→ `notifyResult`（emit `tools/result`）。
- 成功值校验 `createSuccessResult`（:1832-1862）按 `output.schema`；取消语义：未启动= `ABORTED_BEFORE_DISPATCH`，已启动=排干后 `ABORTED`（:1550-1557）。
- **调度器切面**：`TOOL_RUNTIME_SCHEDULER` symbol（:480）暴露 prepare/dispatch/finalize/finish 四段（:816-821），专供 agent-loop 并行调度器在重叠 dispatch 时保持 pre/post 策略的模型序。

**PTC 模式**（ptc.ts + index.ts:876-914）：`mode:'ptc'` 时模型只见 `run_code` 工具+生成的 TS/Python SDK prompt 段；模型直呼其它工具在 `collapses`（:1351-1353）拒绝为 UNKNOWN_TOOL。

**对外接口**：`ctx.tools.register/restrict/presentAs/executionMode/execute`；`defineTool` 声明式 API（schema.ts）；`ToolDefinition`（name/description/parameters/output/execute/presentCall/presentResult/timeoutMs?/isConcurrencySafe?）。

### 4.3.5 packages/core/system-prompt — 提示组装

`ctx.systemPrompt`（index.ts）：有序 section/context/工具 schema/变量注册表。`SECTION_ORDERS` 常量表（:125-159，HARNESS_IDENTITY -1000 → PERSONA_SUFFIX 10200）+ `getSectionOrder`；`system-prompt/assemble` waterfall（:31）与 `change`（:37）；`renderPrompt`（:279-284）严格 `{{variable}}` 插值（未知引用抛错）；`toolOrder` 配置含 `<unlisted-tools>` 保留位（:191,215-229）；scoped 层允许 preset 覆盖 persona（:179-182）。

### 4.3.6 packages/fs — 文件系统能力缝（先读后写审批的发源地）

**Service Definition**：`FileSystem extends Service(ctx,'fs')`（fs/src/index.ts:87）。抽象方法：`resolve(path,opts)→FsTarget`（:132）、`stat/lstat/readText/streamText/readBytes/readByteRange/listDir`（:157-252）、`writeText(target,content,expected?,signal?,sandboxPolicy?)`（:266）、`editText(target,edit,expected?,...)`（:287）、`watch`（:100）、能力事实 `get sandboxMode()`（:119）。三个事件（:59-77）：`fs/write-intent`（waterfall 单槽）、`fs/edit-intent`（waterfall 版本守卫）、`fs/observed`（emit 同步记账）。`FsTargetKey/FsVersion` 为 branded token（types.ts:16,35）；13 个稳定错误码 `FS_*`（:175）。

**`LocalFileSystem`（fs-local/src/index.ts:68）**：以 realpath 为 targetKey（fsio.ts:161，缺失文件 realpath 最近存在祖先+后缀）；**每 targetKey 一把 FIFO tail-promise 锁**（index.ts:104,118）使"读→守卫→写"临界区串行；`writeText`（:202）锁内 probe→版本 CAS（`FS_STALE_VERSION/FS_NOT_OBSERVED`）→读 diff 基线（上限 10MiB）→`writeFileAtomic`→回传 before/after（LF 归一化）。

**`fs-observation-policy`（审批核心，纯事件插件）**：`ObservedStateGate`（index.ts:21）`WeakMap<owner(session), Map<targetKey,FsObservation>>` 记录权威观察；`writeIntent`（:65）未见过/确认 absent ⇒ `createIfAbsent`，见过 ⇒ `replaceIfVersion`；`editIntent`（:78）未读过直接抛 `FS_NOT_OBSERVED`（"edit requires reading first"）；apply 占用两个 waterfall 单槽且不调 `next()`，并在 `fs/observed`（:127）同步落账——**这就是"先读后写"审批的实现位置**（在 `tools/pre-execute` 之下、tool body 之内）。

**`fs-sandbox`（:55）**：`SandboxedFileSystem extends LocalFileSystem`，仅覆写两个 mutation：`checkedTarget`（:122）在 workspace-write 下**重新 resolve**（防 TOCTOU 符号链接调包）并要求落在 `writableRoots(policy)` 内否则 `FS_SANDBOX_DENIED`；read-only 一律拒绝；danger-full-access 放行；读直通。

**工具层 `tool-fs`**：read/write/edit/read_image；`write.ts:119` 先 `ctx.waterfall('fs/write-intent',target,exec)` 拿意图再 `ctx.fs.writeText`（:122），成功后 `ctx.emit('fs/observed',...)`（:129）；`sandbox.ts:37 FsSandboxController` 由 `ctx.fs.sandboxMode` 决定是否投放 `sandbox_permissions/justification` schema 字段（:59），`resolvePolicy`（:87）先校验升级参数再经 `approveEscalation`（ctx.approval）换一次性宽模式。配套 `tool-fs-search`（glob/grep，基于 ripgrep 子进程）与 `tool-str-replace-editor`（字面替换编辑）。

### 4.3.7 packages/shell — 命令执行（request/spec split 模板）

**Seam**：`ShellExecutor`（shell/src/index.ts:64）两个抽象方法即 split 模式：`resolve(request):ShellExecSpec`（:84，把松散 `ShellExecRequest` **显式化**为带默认与上限的 spec——"显式 > 隐式"规约的模板，AGENTS.md:140）与 `execute(spec):Promise<ShellExecution>`（:93）。`ShellExecution`（types.ts:226）=活的 `ShellProcess`+按需 memoize 的 `result()`（done 永不 reject，spawn 失败折算为 killed+stderr 说明）。

**`LocalBashExecutor`（bash-local/src/index.ts:97，inject ['subprocess']）**：`resolve`（:120）用 `clampTimeout` 填默认（timeoutMs 默认 120s、上限 600s）；env 层序 `ENV_OVERRIDES(NO_COLOR/TERM=dumb/PAGER=cat) < spec.env < spec.dshEnv`（:172）；`executeArgv`（:201）——`deadline()` 融合超时与调用方取消做**首因分类** timedOut/aborted（:216-221），同步 spawn 异常折算为 killed 形状（:255-276），`readOutput`（:342）消费式读并把 stderr 以 `[stderr]` 段合并。

**`SandboxBashExecutor`（bash-sandbox:45）**：`resolve`（:85）盖章每调用 policy；`execute`（:89）在 prepare 阶段调 `ctx.sandbox.confine(['bash','-c',command],policy)`（:100,187）；`onProcessDone`（:158）用每次 wrap 保留的 denialSignatures/runnerFailureRules 分类"策略拒绝 vs runner 故障"，前台 runner 故障抛 `SandboxUnavailableError`（fail-closed）。pwsh 双包对偶。

**工具层 `tool-bash`**：注册 `bash` 工具（:374）；有 JobRegistry 时每次调用注册为 job（:275），等待超时可"promote"为后台 job 而非击杀（:347-359）；escalation 走 `approveEscalation`（:237-257）。另有 bash/pwsh 的 persistent 变体（走 terminal）。

### 4.3.8 packages/subprocess — 子进程基座（防僵尸/防逃逸）

**Seam**：`SubprocessRuntime`（subprocess/src/index.ts:117）：`resolveExecutable`（:133，绝对路径校验、裸名走清洗后 PATH）、`terminalEnvironment`（:144）、`spawn(spec):SubprocessHandle`（**同步**返回活句柄，:153）、`spawnTerminal`（:162，唯一非管道原语，PTY）。包级 `SENSITIVE_ENV_PATTERN=/KEY|PASSWORD|SECRET|TOKEN/i`（:47）与 `scrubbedParentEnv()`（:66）：子进程基础环境剥离凭据形与全部 `DSH_*`，再叠加代理路由。

**`LocalSubprocessRuntime`（subprocess-local:59，4,833 行）**：`live/terminals/controlChannels` 三集合（:61-65）；`process.prependListener('exit')`（:78）保证宿主退出同步终杀。**进程树收容** `selectContainmentMode`（:213）：Linux systemd scope/私有 bootstrap（linux-scope.ts）、Windows Job Object（windows-job.ts，FFI 见 win32-process）、都不可用才 fallback（detached PGID+taskkill；`fallbackOwner` :202 以 `process.kill(-pid,0)` 轮询存活）——**句柄在整个受管 range 退出后才从 live 集释放**（:207-209）。`bindManagedProcess`（spawn.ts:267）：collect 流经 `OutputCollector`（内存尾保留+spill 文件溢出）、stdin 批量写（:384）、`done`（:389）等 direct 结局后再等输出流排干；`terminateWithReason`（:357）SIGTERM→graceMs→SIGKILL 阶梯。`spawnTerminal`（:264）懒加载 node-pty，Linux 先 `prepareLinuxTerminalScope`。

### 4.3.9 packages/sandbox — 进程围栏

- `SandboxProvider.confine(argv,policy):Promise<ConfinedArgv>`（sandbox/src/index.ts:159,177）——把**精确 argv** 包成受限 argv，返回 enforcement(full/partial)/denialSignatures/runnerFailureRules（:96-117）；无法收容抛 `SandboxUnavailableError`（:132，**fail-closed 禁止静默直通**）。
- `LocalSandboxProvider`（sandbox-local:252）按平台链选择（`PLATFORM_CHAINS` :160）：Linux `bwrap→landlock`（三 probe 功能探测仲裁 :69-92）、macOS `seatbelt`(sandbox-exec)、Windows `windows-acl`（受限 token+DACL：workspace 级 `workspaceWriteSid` 常驻 ACE+每会话随机私有 temp `tempWriteSid`，materializeAclGrant :403、dispose 撤销 :465；因 NTFS 硬链接/读不限宣布 partial :188）。
- **策略之家** `sandbox-policy:110 SandboxPolicyService`（`ctx.sandboxPolicy`，默认 read-only :113）：`resolve`（:164）优先级"已批准显式模式 > 会话 `sandbox/mode` 投影 > 部署默认"；`escalation.ts` 定义跨 bash/fs 共享升级编舞（`WIDER_MODES` :28、`validateEscalationArgs` :51、`approveEscalation` 先审批后执行）。

### 4.3.10 packages/ssh — 远端执行世界（五包齐换）

`SshConnection`（ssh/src/index.ts:47，`ctx.ssh`）：`start()`（:258）以 `ssh -T -M -S <ctl>` 建复用 master；启动远端 Node helper（版本匹配+SHA-256 摘要校验 :280-281，不符拒绝）；JSON-RPC（protocol.ts `SshRpcPeer`）；lease 心跳（:284）丢失触发远端自清理；`connectStream`（:131）走 `-O forward -L` 独立 socket 转发+能力认证。`subprocess-ssh:229`、`fs-ssh`、`sandbox-ssh` 把四个缝映射为 helper RPC——**fs/shell/subprocess/sandbox+sandboxPolicy 换成 SSH 实现即整体迁移"执行世界"**，模型侧工具不动（subprocess/src/index.ts:95-97 的契约注释明确"可执行路径与文件系统 provider 共享同一执行世界"）。

### 4.3.11 packages/terminal — 持久 PTY

`TerminalSessionService`（terminal/src/index.ts:105，`ctx.terminals`）：**owner（精确 Agent 实例）作用域注册表**——spawn（:154，名字预占+预约/回滚 :350-384）、`startSend`（:243）排他交互发送、`read`（:263）有界回滚分页、signal/kill/list；`expectOwned`（:387）拒绝 FOREIGN_SESSION；owner 失活即 `disposeOwned`（:323）。后端 `terminal-bash:184`：spawn 解析会话沙箱策略（:204）→ danger-full-access 外必须 `ctx.sandbox.confine`（:100-108）→ `ctx.subprocess.spawnTerminal` → `startupSession`（:114，bash 靠 `PROMPT_COMMAND` 注入 OSC `133;D;$?` 提示符标记 :86）；`ensureSandboxModeFence`（:37）禁止 PTY 存活时切换沙箱模式。`session.ts:237 LocalPtySession`：headless 终端仿真+`TerminalSanitizer`（剥 CSI/OSC）+`BoundedTextBuffer` 有界回滚；`startSend`（:328）以提示符就绪/超时/退出三种 waitReason 结算。`tool-terminal` 注册 terminal_open/send/read/signal。

### 4.3.12 packages/lsp / mcp / web / browser-use / computer-use / ptc-runtime / deliverables / interaction

**lsp（3 包）**：`Lsp`（lsp/src/index.ts:82，`ctx.lsp`）provider 注册表+按文件扩展名路由（冲突抛 `LSP_CONFLICT` :90）；`query`（:143）只暴露 goToDefinition/findReferences/goToImplementation/hover 四操作（无 JSON-RPC 逃生口）。`lsp-stdio`：命名服务器表，每 provider 每 workspace 懒启动单飞实例；源码经 `ctx.fs` 读、进程经 `ctx.subprocess` 起——与本地/SSH 世界共用。`tool-lsp` 暴露模型侧查询工具。

**mcp（2 包）**：`mcp-client:154` 每实例连一台 MCP server（stdio 子进程或 streamable-http）；`startConnection`（:181）是 supervisor——断线 500ms→30s 指数退避、单次预算 10 次，超限注销全部工具；代际关闭 5s 上限防子进程重叠。**工具桥**（tools.ts）：`publicToolName`（:81）生成 `mcp__<server>__<raw>`（64 字符约束，非法/截断追加 12 位 SHA-256 防碰撞）；`syncTools`（:113）两阶段（先整代构建、再旧代 dispose/新代注册，冲突回滚"全有或全无"）。`mcp-resources` 额外注册资源三工具。

**web（7 包）**：`WebRuntime`（web/src/index.ts:74，`ctx.web`）search/fetch **调用时**经 `resolveProvider`（:172）选 provider（零可用/多可用分别抛错，不依赖注册顺序）。`web-fetch-http:39 HttpFetchProvider.fetch`：融合 deadline；`followAndRead`（:66）只跟**同源**重定向（:94，跨域抛 `WEB_REDIRECT_BLOCKED` 且取消 body）；目标经 network.js 解析**钉定公网 IP（SSRF 防护）**；无 cookie/凭据。search 三 provider：deepseek（Anthropic 兼容+服务端 web_search 工具）、exa、perplexity。`tool-web` 注册 `web_fetch`/`web_search`。

**browser-use / computer-use（本体 2+2 文件）**：只是**排他命名注册槽**——`BrowserUseRegistry.register(name)`（browser-use/src/index.ts:35，二次注册即抛）。实现路线在 experimental（§4.9.2）。

**ptc-runtime（2 包）**：`ctx.ptcRuntime`（ptc-runtime/src/index.ts:104-151）：抽象 `resolve(request):PtcRunSpec`+`run(spec)`；契约——程序结果（含错误）全部以 result 字段返回、仅契约误用才 reject；跨后端保留名集合（:42-89）。`ptc-runtime-node`：Node worker-thread 实现（launch/process/json-wire/output-ledger），承载 PTC 工具与 workflow-ptc 的沙箱执行。

**deliverables（2 包）**：`tool-present`——`present` 工具声明既有文件为交付物：execute 内要求开放 turn 边界，逐文件 `ctx.fs.lstat/resolve/stat` 校验，把投递挂到 pending WeakMap，`tools/result` 观察者确认非 isError 后 append `deliverables/presented` 会话事件。`workspace-changes:94`：每有 cwd 的会话建 `TurnRecorder`（recorder.ts:107），监听 turn/start|tool/result|turn/end 与 `tools/pre-execute`（写工具前置快照），经 `GitRunner`（git.ts，走 ctx.subprocess）产出 turn 级变更摘要与 numstat diff，`ctx.provide('workspaceChanges')`（:118）暴露查询。

**interaction（5 包）— 人工协作面**：
- `user-approval`（`ctx.approval`，index.ts:150）：`request(req)`（:215）要求**开放 turn 内**调用（:217-232 审计）；`decide`（:267）先判 `never` 策略（:275），再 `ctx.waterfall('approval/request',...)`（:281）委托 UI answerer——**无 answerer/异常/非法返回一律 `unavailable`，fail-closed**（:288-291）；abort 竞速返回 cancelled。
- `user-questions`（`ctx.userQuestions`，TypertRemoteService）：`ask`（:287）校验 intent 后走作用域化 waterfall（:324-330），无 answerer 抛 NO_PROVIDER；`askTimed`（:240-269）超时返回 `{pending:true}` 供 timed ask_user 续等。
- `tool-ask-user`（`ask_user_question` 工具）、`commands`（`ctx.commands` 斜杠命令注册/解析/分发，不经模型 turn）、`permission-presets`（把 sandbox-mode 与 approval-policy 两旋钮捆成用户预设，切换落 `permission/preset` 事件）。


## 4.4 编排与扩展：subagent / workflow / jobs / todo / plan / goal / schedule / skill / extensions / hooks / guard / webhook / feedback / acp

### 4.4.1 packages/subagent — 委托 agent 缝（编排中枢）

**模块职责**：把"派生子 agent"做成可选能力位；与 bash 不同**多 provider 共存**，按名注册于 `ctx.subagents`（subagent/src/index.ts:137-174 声明 + 4 个 `subagent/*` 事件）。

**核心签名**：`registerProvider(p: SubagentProvider)`（:510）、`start(name, request)`（:557）、`startContinuable(spec):Promise<{childId,messageId}>`（:259）、`sendMessage(sender, targetId, content, options)`（:277）、`interrupt(targetSessionId, authority)`（:326）、`listChildren/listDescendants`（:372/:391）、`@Remote('prompt')/('interruptByParent')`（:413/:480）。

**关键实现**：
- **能力 fail-loud**：`assertCapabilities`（:642-658）在 start 前逐项比对 `agentOptions/outputSchema/depthLimit/toolFilter/persona`，缺失抛 `SubagentError('UNSUPPORTED_CAPABILITY')`。
- **一次性子代理**（in-process-driver/src/index.ts:104-152）：首个 await 前同步 `captureDelegatedPolicyOverrides`（child-agent.ts:249——捕获沙箱覆盖+把 approval 钉死 `never`）→ `ctx.agents.create({sessionId, parentAgent, meta, seed?, agentOptions, signal, setup})`；setup 内 `applyChildComposition`（child-agent.ts:200-219：join 父 preset、注入 `subagent:delegation` 上下文、影子 persona、`tools.restrict()`）+ `attachStructuredRuntime`（outputSchema 强制捕获工具）+ `attachDescriptorAppend`（:81-91，借 `agent/pre-step` 在首次请求前把 descriptor 写进子日志）。`drivePublishedRun`（:158-209）桥接 abort→child.cancel；`followup` 提交 prompt；`whenIdle` 后 `readResult`（:212-238）把 turn 结束原因映射 completed/max-tokens/aborted/refusal/error。
- **provider 家族**：`spawn-in-process`（全新 agent，`inheritsParentContext=false`）、`fork-in-process`（以父日志到最后一个 `turn/end` 的平衡前缀作 seed，`inheritsParentContext=true`，fork-in-process:71-90）、`subagent-acp/claude-code/codex`（跨产品 CLI 桥）、`subagent-dsh-sdk`（SDK 子进程）。
- **continuable 子代理**（continuation.ts:104-192）：预留 childId → 快照 descriptor+策略 → `prepareContinuable` 拿 provider 的 detached spec → `ChildLock.run` 临界区内 `activations.materialize`（创建/冷恢复统一入口，continuation-activation.ts:109-131）→ 提交首条 prompt；任何失败回滚。`sendMessage`（:204-234）按"驻留 Activation 指向父=发给父，否则必须父发给直接子"做邻接授权；settled 时向父投递 `subagent-settled` 通知。
- **目录**：`listChildren` 走父 Session 的 `subagentCatalog` 投影（catalog.ts:125），**不加载子代理对象**。

**模型工具**：`subagent`（tool-subagent）、`send_message`/`interrupt_agent`/`list_agents`（tool-subagent-control）。

### 4.4.2 packages/workflow — 工作流执行

- `workflow`（缝）：`ctx.workflowEngine.start(request):WorkflowRun`（workflow/src/index.ts:157-187）；事件 `workflow/start|phase|log|agent-start|agent-end|end`（:42-90）；`WorkflowError{fatal}` 定义组合子纪律——**致命错误整体终止，普通子代理失败仅把该项记 null**（:130-148）。
- `workflow-ptc`（引擎）：`start`（index.ts:133-188）同步校验（meta/`vm.Script` 仅 parse :54-64/provider/总量上限）后构造 run。**执行模型**：脚本在沙箱 Node PTC 子进程运行，宿主只注入 `workflowHost` 绑定（host.ts:175-186）；`startChild`（:197-220）调 `ctx.subagents.start`——每个 `agent()` 调用=一个一次性子代理；`drive`（:273-305）finally 统一 dispose、为存活 agent 合成 cancelled 结束。guest DSL（guest-source.ts）提供 `agent/pipeline/parallel/phase/log/args`：pipeline 无栅栏逐项流水、parallel 全屏障；限额：并发 `min(16,cores-2)`、总 agent 1000、单次 items 4096（index.ts:32-43）。
- `tool-workflow`（`workflow` 工具）：前台 await result；`run_in_background` 注册为 `ctx.jobs` 的 `kind:'workflow'` job（:262-313），cancel→run.cancel；顶层 run/agent 事件镜像为 Session 日志事件（`createWorkflowRecorder` :93-151）。`tool-ralph`：Ralph 循环（每轮 fresh 子会话+有界 handoff）。

### 4.4.3 packages/jobs — 后台任务

`ctx.jobs: JobRegistry`（jobs/src/index.ts:85-193）：`start(spec):JobId`（`<kind>-N`）、list/get/read/readAt/kill/wait/remove。**契约**：owner 按 SessionId 授权、first-wins 结算、每 job 一个有界输出 ring（模型消费 cursor 与观察者绝对 offset 互不干扰）。`jobs-local`（:128-）：`TrackedJob`（:76-116）持 ring/cursor/pump/spillPaths；默认每 owner 10 并发、live ring 256KB（:33-43）。`tool-jobs`：`job_output`（带 wait/timeout 有界等待）、`job_list`、`job_kill`；完成通知——busy owner `owner.inject(message)`，idle owner 在 wakeup 模式下开新回合，`maxConsecutiveWakes` 抑制自激链（:211,:295,:307）。

### 4.4.4 todo / plan / goal / schedule — 任务状态四件套

- **todo**：`todo_write` 整表替换（tool-todo/src/index.ts:135-211），校验唯一/非空；`session.append('todo/write')`+`todos` 投影（last-write-wins，turn/start 清空 :123-134）。
- **plan**：`ctx.planMode: PlanModeController`（plan-mode/src/index.ts:175）。Logged planning：`plan/mode` 事件+`plan` 投影（:136-168）；`set()`（:418-438）回合外立即 append、回合内 pending 到下一次被接受的 `agent/pre-step` 提交（:196-213）；`plan:policy` prompt section 按激活态渲染；`/plan` 命令+常驻 `exit_plan_mode` 工具（:277-365，经 `userQuestions.ask` 出 Approve/Keep-planning 审查）。
- **goal**：`ctx.goals: GoalService`（goal/src/index.ts:240）。**事件溯源+CAS**：`goal/change` 全快照事件、`goal` 投影严格重放（:146-169，首个非法事件进 failure）；create/edit/pause/resume/complete/block 全部 `expectCurrent(ref)` 比对 revision（:456-466）；**activation（armed/disarmed）是进程本地状态**，不进持久重放（:609-626）——resume/fork 后需人类经 `/goal` 或模型工具再授权。`tool-goal` 注册 get/create/update_goal（:195-342）；`goal-round-driver` 监听 agent 状态事件，agent 空闲且 armed 时 `agent.followup` 注入下一轮提示（goal-round-driver/src/index.ts:192,:246-364）。
- **schedule**：`ctx.schedule: ScheduleService`（schedule/src/index.ts:99）。持久域 tasks 表（:125-138）；selector 六选一（at/after/every/daily/weekly/cron）；委托子 Session 拒绝绑定（:410-417）。**定时机制** `ScheduleRuntime`（runtime.ts:20-166）：`requestDrive` 在 `agents.withoutInitiator` 内串行 drive——扫描到期、`sessionController.resolveAgent` 冷恢复目标 agent、同 Session 的 recurring 任务**合并为一条批次消息** followup（:119-123）、`sessions.flush` 确认持久后才置 inactive/推进下次 occurrence、`setTimeout(unref)` 到最近义务（:161）。`tool-schedule` 注册 schedule_create/list/delete/update。

### 4.4.5 packages/skill — 技能加载

`ctx.skills: SkillRegistry`（skill/src/index.ts:356）。**分层作用域发现**：`ScopedLayers<SkillLayer>`（:362-365），读时 global 层+scope 链，近层同名整体覆盖，层内按 `rank→providerOrder→localOrder`（:807-811）；`collect`（:519-549）带 revision 双检重试+LRU（默认 128）。**Provider** `skill-filesystem`（:250-258,:676-687）按六层根发现 bundle（`<dir>/SKILL.md`）与扁平 md：`.dsh/skills`(project) > `.agents/skills`(project) > custom > `~/.dsh/skills` > `~/.agents/skills` > bundled。`tool-skill`（:82-161）按可见性注入目录 prompt section，并在 `agent/pre-step` 把用户显式调用的技能正文作为 instructions 注入（:165-203）。

### 4.4.6 packages/extensions — 运行时自修改

`cordis-host-runner`（`ctx.dynamicCordisRunner`，index.ts:85-131）：`define(request)`（:159-210）登记不可变 Package（host/client 代码字符串+precheck）；`run(agent, pluginId, packageId, mode)`（:256-）发起激活——client 包需审批（`ApprovalRequestId`+`cordis/request-run` 事件）；宿主半 `startHost`（:892-924）：`createSandbox(pluginId,{handle})` 提供带守卫的 `harness.defineTool/harness.handle`（guard.ts 做 schema 白名单+教学式错误），`evaluateHostCode`（VM，`vmTimeoutMs` 默认 5s）求值后要求返回 Plugin 函数或 `{apply(ctx)}`，`startHostHalf` 在专用 fiber 组 `'cordis-dynamic'`（:1244）挂载——**即运行时动态装载 Cordis 插件**；`retract`→新 run 支持版本切换；`undefine`（:218）撤销并停 run。`tool-cordis`（8,858 行）注册只读发现工具 `cordis_inspect_list/query`；`cordis-client-runner` 提供客户端半与 remote 桥；`ui-cordis` 提供面板/卡片。

### 4.4.7 packages/hooks — Claude Code/Codex 桥接

`hook-protocol`：`runHook(bash, hook, options, now)`（runner.ts:67-106）把 JSON payload 写 stdin、经 `ctx.shell` 执行（凭证清洗/进程组取消/超时默认 600s），exitCode/信号死亡/基础设施故障统一解码为 `HookOutput`，**永不抛出**。`hooks-claude-code`（index.ts:48）：加载 `hooks.json`，事件映射——`agent/created`→SessionStart（:209）、`agent/pre-step`→UserPromptSubmit（:225）、`tools/pre-execute`→PreToolUse（:244）、`tools/post-execute`→PostToolUse（:253）、`agent/turn-stopping`→Stop（:276）、`subagent/start|end`→SubagentStart/Stop（:287/:297）。hooks-codex 同构。

### 4.4.8 packages/guard / webhook / feedback / acp

- **guard**：`repeat-tool-reminder`——`observe`（:196-214）在 `tools/post-execute` 以"工具名+深排序参数"为链 key，连击阈值 [3,5,8] 时注入 gentle→detailed 提醒；`agent/pre-step` 见用户消息即清链（:236-239）。`timeout-policy`（timeout-policy/src/index.ts:55-81）——协作式超时：`tools/execute` 水口读取工具 `timeoutMs`，临时替换 exec.signal；仅当**自己的**计时器触发才写结构化 `TOOL_TIMEOUT` isError 结果（避免误吞外层 deadline）。
- **webhook**：`ctx.webhookRuntime`（webhook/src/index.ts:58）。`dispatch(delivery)`（:126）**fire-and-forget**：`snapshotDelivery`（:39 校验+无损快照+deepFreeze）→ 匹配规则各起一次受控调用 `startInvocation`（:136）→ 非 null 则建 Session；**无投递库/队列/重试/去重**。Workspace Session 创建（session.ts:117 `createWebhookSession`）：校验 → 权限/agent 预设 resolve → `ctx.workspaceRegistry.create` → `ctx.agents.create`（sessionId=`webhook-<uuid>`，setup 挂 preset+首次请求头前强制模型选择的 `agent/request` 拦截）→ `followup` 注入 prompt。`webhook-github`（handler.ts:82-129）：仅 POST/JSON/限长/HMAC 验签（401）/必取 delivery 头 → `dispatch` → **202 立即返回**。
- **feedback**：`command-feedback`（/feedback → log-only `feedback/record` 事件）；`message-feedback`（`ctx.messageFeedback`）消息级评分/备注——**冷路径不构造 Session/Agent**：冷 Session 直接开 write 句柄 append+flush（index.ts:246-279）；`ifVersion` 乐观并发。
- **acp**：基于 `@agentclientprotocol/sdk` 的 JSON-RPC **stdio** 服务端（inject `[agents,llm,sessionPersistence,sessions]`），只服务可信程序化客户端：标准配置、MCP 挂载、prompt 内容、提交型语义更新、取消、一次性权限决定（对接 approval waterfall）。

## 4.5 宿主服务与 API/SDK：boot / host / api / sdk / preset

### 4.5.1 packages/boot — 应用启动装配（5 包）

**`app-boot`（21 文件，4,993 行）**：profile 发现/初始化、bundle 层叠、patch 解析、Cordis Loader 驱动、启动审计、fail-loud、分层 .env。
- **`boot()`（index.ts:973-1039）**：`new Context()` → 挂 diagnostics logger（:983-990）→ `ctx.plugin(Loader)`（:1002）→ prepare host 钩子（:1003）→ `mountRootInclude`（:1005——把 Include 注册为 `cordis:include` builtin、以固定 id `'include'` 建根条目）→ `ctx.get('loader')?.await()` 等树沉降（:1011）→ `auditStartupEntries`（:1013）。失败 dispose 后抛带最深 cause 链的错误。
- **启动审计**：`requiredStartupEntryIds`（:747-755）= agent-loop/webserver/modules/connection/headless-runner/acp/sdk-jsonrpc-server——失活抛 `StartupError`；其余失活仅警告。
- **patch 层序 `readProfilePatches`（profile-context.ts:63-75）**：bundle 层（`dsh.profile.bundles` 顺序）→ profile `cordis.patch.yml` → **home 级** `$DSH_HOME/cordis.patch.yml`（机器级偏好，高于 profile 层）→ `--patch` overlays → 遥测开关 patch（`DSH_TELEMETRY_DISABLED` 非空即禁 session-telemetry-otel 行）。全部层摊平为一个 patch 列表交给 include 一次 `applyEntryPatches`。
- **profile 加载 `loadProfile`（profile.ts:781-798）**：缺且有模板则 `initProfile`（:254-273 写 manifest+空 patch 模板+pnpm workspace）；逐 bundle `resolveBundleDir`（:706-717，**双锚解析：安装锚优先、profile 锚次之**——保证 dsh-base 永远来自当前安装）；不兼容 bundle 记入 skippedBundles 不阻塞。
- **运行时解析 `createRuntimeResolution`（:441-474）**：BFS 安装包依赖图（含 peerDeps）产出冻结表，供 `PluginPackages`（`ctx.pluginPackages`）装到 Node ESM/CJS 解析拦截层与 Worker。
- **HMR 重组合 `reconcileProfilePatches`（index.ts:274-303)**：根 entry `update({config:{...patches}})` → await 旧 fiber → 只对新引入失败抛错 → emit `app-boot/config-reload`。
- **`installFailLoud`（:680-729）**：unhandledRejection/uncaughtException → 单条 `inspect(err)` stderr+exit(1)；**`loadLayeredEnv`（:235-256）**：双层先全部校验再应用；`BOOTSTRAP_NAMES/PREFIXES`（:133-157）拒绝 `.env` 设置进程/网络引导变量。

**其余四包**：`cmdline`（`ctx.cmdlineArgs/appExit/appReady`——启动器事实注入，`provideCmdline` 冻结参数快照，index.ts:55-89）；`hmr`（串行化模块热替换+配置热重载，直接复用 app-boot 的 reconcile）；`plugin-manager`（profile 插件/包管理：pnpm 转发、registry 回退链、`writePluginEnabled` 启停即改 patch 行、受保护模块集防自毁 index.ts:66-76）；`config-editor`（活配置表单，经 profile patch 持久化）。

### 4.5.2 packages/host — GUI 宿主服务（8 包）

`webserver`（`ctx.webServer`，webserver/src/index.ts:22-36）：node:http 路由/升级注册、可选 gzip（过滤 SSE/multipart）、`webserver/index-inject` 注入事件——**不知 harness 概念、不服务文件**（dist 归 frontend-static 组成方）；`frontend-static`（前端 dist fallback 席位）；`directory-picker{,-auto,-browse,-native}`（工作区目录选择：auto 按 bind/SSH/显示探测选型，native 含 win32 原生对话框 worker）；`open-in-app`（"Open In..."宿主应用解析）；`plugin-inventory`（Loader 条目只读投影）；`product-telemetry-otel`（桌面产品遥测）。

### 4.5.3 packages/api — 远程 BFF（9 包）

- **`gateway`（`@deepseek-ai/dsh-api-gateway`，12 文件，5,236 行）**：Host 侧 `ctx.inject(['connection'])` 后 `connection.rpc.intercept('/api', claimsEndpoint, dispatchRpc)`（gateway/src/index.ts:233-239）——所有 `namespace/method` 形态端点分派到 `@Remote` 装饰方法；WebSocket 升级路由交给 `RemoteStreamMuxServer.handleUpgrade`（:240-273）；`$events` 内部流（:495-560+）：客户端订阅、Host 事件以 `RemoteEventInvocationFrame` 下发、waterfall 结果经专用端点 unary 回传（:430-452）。
- **`stream-server.ts:43-110` `RemoteStreamMuxServer`**：`ws` noServer+心跳 Ping（默认 2s，missed 2 次 terminate）；每连接管理逻辑流（open/item/end/cancel 帧）；上行 inbox 字节上限（默认 256KiB）。
- **控制器族**：`session-controller`（35 文件，8,382 行：冷读/prompt/fork/rename/模型目录 `buildModelCatalog`/归档门/分页搜索）、`job-controller`、`terminal-controller`、`workspace-controller`、`workspace-files`、`settings-controller`、`account-controller`、`remotes`（客户端远端聚合）。

### 4.5.4 packages/sdk — 进程外 SDK（3 包）+ preset（3 包）

- **sdk**：`protocol`（JSON-RPC 类型+`JsonRpcTransportPeer`）；`server`——`HarnessSdkJsonRpcServer`（server/src/server.ts:75-130）：构造即订阅 `session/event→notify session.event`、`agent/status→session.status`、`session/created→subagent.started`（仅带 parentSession 的）、`subagent/end→subagent.finished`（用 `carrierKeyOf` 从 Scoped carrier 还原父代理 :55-57,111-129）；`initialize`（:137-171）未注册 deepseek 适配器时**兜底挂载** `ctx.plugin(LlmDeepSeek)`（:152-155）；`prompt`（:178-195）getOrCreate session 后 `agent.followup()`，图片块先经 attachment 落储再引用化。stdio transport。`client`（TS）：`launch.ts` 拉起 `dsh --profile sdk` 子进程。
- **preset**：`agent-preset-registry`（`ctx.agentPresets`，src/index.ts:52-72）——`register`（:81-101）→ `activate`（:103-122）：`createScope(owner,key)` 建 preset 作用域+`mountPreset` 在其中装载 YAML 声明的子树（Loader entry 列表），形成 `Generation{scope,key,mount,users}`；会话绑定时把 agent scope `bindScopeParent` 到 preset key（:46-49）——**"agent 代理面"机制：preset 子树的注册沿作用域链下继承给其下所有 agent**。`agent-preset`（出厂 preset 集合+cordis 插件开发 SKILL 模板——其 package.json 名为 `@local/my-decoration`，是模板示例包）；`persona`（persona 模板）。

## 4.6 组合层与应用入口：bundle / apps/cli / apps/web

### 4.6.1 packages/bundle — profile 组合层（6 包）

**装配契约**：bundle 包 `package.json` 声明 `dsh.bundle.patch`（单文件或有序列表）；profile manifest 声明 `dsh.profile.bundles`；根配置是空数组、**整树皆 patch**（profile-boot.ts:81-85 每次启动重写空根防 Loader 写回固化）。

- **`base`（529 行 cordis.patch.yml）**：一次 insert 约 90 行核心（llm/session/agent/agent-loop/tools/system-prompt/fs-sandbox/sandbox-policy/approval/permission-presets/session-persistence-jsonl/storage 三件套/subagent 双后端/ptc-runtime/tool-*/web/workflow/telemetry…）；`!!js` 表达式驱动条件禁用（如 plugin-manager/hmr `disabled: !!js "!ctx.get('profileContext')"`，:22/:30）；依赖约 90 个 dsh 包（package.json:36-130）。**profile 模板路由**（app-boot/src/profile.ts:179-195）：`web→[base,web-app]`、`headless→[base,headless]`、`sdk→[base,sdk-app]`、`acp→[base,acp-app]`、`sdk-minimal→[sdk-minimal]`。
- **`web-app`**：叠 base 上——改写 persona（:16-21）；插 web 层（webserver/connection/modules/api-* 控制器/schedule/client-ui-* 约 80 行）；**把宿主面 per-agent 工具行全部 `disabled:true`**（:465-574，长注释解释"为什么禁而不删"与宿主面/代理面所有权）——代理面移交 agent preset；尾插 `agent-preset-registry`（default: standard，:579-584）。`src/startup.ts` 解析 web 旗标发布 `webStartup`；`presets/{standard,ptc,minimal,cordis}.patch.yml` 四个出厂 preset。
- **`headless`**：一次性 runner——`startup.ts`（:78-121）解析 task/--json/--session-id；`index.ts`（:35-39）创建/采纳 Agent→驱动到静默→stderr 流 reasoning→flush→stdout 最终文本或 NDJSON→exit。
- **`sdk-app`/`acp-app`**：分别插 sdk-jsonrpc-server / acp 行；`sdk-minimal`：**不叠 base 的独立完整树**（显式最小内核，供打包 carrier 瘦身）。

### 4.6.2 apps/cli — `dsh` 命令（10 文件）

**命令分发链**（bin.ts:26-74）：
1. `runCli`（:26）→ `parseDshArgs(process.argv.slice(2), version, manageDesktopProfile)`（:29）；
2. `parseDshArgs`（args.ts:146）用 Commander `passThroughOptions+enablePositionalOptions+allowUnknownOption` 构建"首 token 即边界"语法——第一个不认识的 token 之后全部属于被启动 app（args.ts:159-167）；`dsh web` 缩写展开为 `['--profile',...argv]`（:201-204）；`plugin` 是唯一子命令（:187-199）；
3. 四种 invocation mode（:21-61）：`profile`/`plugin`/`dump-config`/`dump-config-schema`，bin.ts switch 懒加载路由；`StartupError` → `reportStartupFailure` + exit(1)（bin.ts:44-47）。

**`runProfile`（profile-boot.ts:244-326）装配管道**：`installProxyFromEnvironment`（:249）→ `composeProfile`（:197：prepareProfile 重写空根配置 :171 → `createRuntimeResolution` :206）→ 信号处理（SIGTERM→0、SIGINT→130，:280-281）→ `installFailLoud`（:282）→ `boot('dsh', rootConfig, readProfilePatches(...), prepare)`（:296）：prepare 内 `ctx.provide('profileContext')`、启动环境快照（:301）、`ctx.plugin(PluginPackages,{resolution})`（:302）、`provideCmdline`（:307）；boot 成功且 fiber ACTIVE 才 `appReady.commit()`（:314-318）。

### 4.6.3 apps/web — Vite 构建壳（6 文件）

`src/main.ts:17-37` 浏览器入口：`new AppWebEntry(el)`；desktop 场景等主进程 `desktop.ready()` 回放 injections 后 resolve boot 门。`vite.config.ts`：双入口（index+bootstrap）；manualChunks 手工 vendor（katex/shiki/micromark，全 React-free）；把 vendored Cordis Loader 的 `node:module` 浏览器化并 define 伪装 `process.versions.node='0.0.0'`（:246-259）；`rejectStandaloneServe` 禁止独立 `vite serve`（:46-54）。`src/preview.ts`：WebWorker Host 预览 bootstrap（实验 webworker-runtime）。

## 4.7 客户端 UI 族：packages/client（~60 包，1,048 文件）

**模块职责**：dsh Web GUI 的"浏览器半边"（packages/client/README.md）。

**分组与代表包**：

| 分组 | 包（ctx 键） | 职责 |
|---|---|---|
| 内核 | `web`（boot 内核）、`modules`（`ctx.clientModules`）、`connection`（`ctx.connection`）、`store`、`locale`（`ctx.locale`）、`hmr`、`shortcuts`、`file-upload`（`ctx.fileUpload`）、`resources`（`ctx.resources`）、`product-analytics` | 浏览器端 Cordis Loader 装配、懒 CJS 模块表、RPC、状态原语、i18n |
| 渲染骨架 | `ui-renderer`（`ctx.uiRenderer`/`ctx.slots`）、`ui-slots`、`ui-primitives`（88 文件）、`ui-theme`、`ui-layout`、`ui-dockkit`、`ui-session` | Slot 注册表→React 挂载、共享控件、`--dsw-*` 主题刻度 |
| 会话/对话 | `ui-conversation`（72 文件/13K 行）、`ui-chat`（92 文件/12.5K 行）、`ui-tool`（40 文件）、`ui-trajectory`（31 文件/9.4K 行）、`ui-approval`、`ui-user-questions`、`ui-plan`、`ui-goal`、`ui-jobs`、`ui-schedule`、`ui-subagent`、`ui-workflow-run`、`ui-deliverables`、`ui-attachment`、`ui-reference`、`ui-input-trigger`、`ui-skill`、`ui-commands`、`ui-model-selection`、`ui-agent-preset`、`ui-permission-presets`、`ui-message-feedback` | 各业务呈现 |
| 导航壳 | `ui-sidebar{,-right,-files,-browser,-documentpreview,-terminal}` | 侧栏（documentpreview 79 文件） |
| 设置 | `ui-settings`（宿主）+ general/models/plugins/plugin-inventory/session-log/shell/agent-loop/subagent/web-search/account 各分节 + `ui-plugin-manager` | 设置页族 |

**启动链**：`client/web/src/boot.ts:23-123` `AppWebEntry.run()`——等 `__DSH_BOOT_READY__` 门（:57）→ 读 `window.__ModuleLoader__` 门面（:59-62）→ `moduleLoader.create({boot:win.__DSH_BOOT__, staticModules:getStaticModules()})` → `prefetchImmediateTier()`（:116-122）→ `bootClient(...)` → `mountClient(ctx,container)`。`boot-client.ts:36-57`：`ctx.plugin(Loader)`、`modules.entries.start(loader,manifest)`、`loader.await()`、`assertEntriesActive()`（:66-89 审计 pending 列缺失服务）。`modules/src/client/system.ts:95+` `ClientModuleSystem`：懒 CommonJS 模块表；bundle 以同源外部 classic script 加载（:16-29），URL 带 `?rev=`（:32-37）。

**插槽系统（核心抽象 #1）**：`ui-slots/src/index.ts:25-47` 四个声明合并表：`SlotMap`/`SlotFactoryMap`/`LocaleNamespaceMap`/`ResourceProtocolMap`；:100-104 `SlotKind='single'|'list'|'keyed'|'chain'` × `SlotScope='root'|'session-maybe'|'session'`；类型化 `t` 函数（:54-98，注册站点缺键/多键是**编译错误**）。`ui-renderer/src/client/bind.ts:21-27` `bindSnapshotSelector()` 是**全客户端栈唯一 hook 构造器**（`useSyncExternalStoreWithSelector`）；`app.tsx:19-22` 整棵 UI 树只来自一次 `ctx.slots.renderSlot('root',{})`；SlotRegistry（registry.ts）做影子胜出选举（crash 可 abdicate 退位）。

**Conversation 引擎（核心抽象 #2）**：`ui-conversation/src/client/contract/conversation.ts:203-263` `ConversationNodeDefinition<State>`——每业务包独立注册的"事件→节点"状态机：`match(event)`（抽取稳定身份+start/update 角色）、`start/update`、`publication()`（发布节奏）、`buildViewNode()`；`:278-323` 每视图目标的增量构建器（replace/apply/groupInput/publish）。`ui-chat/src/client/conversation-nodes/` 是 Chat 目标的实现组（assistant/message/tool/turn-process/turn-tail/command/compaction/retry/inbox/fallback）。`ui-tool/src/client/contract/slots.ts:26-30` `'tool.call.toolview'` keyed slot 按 wire 工具名分派（keyed 注册占用即替换，未认领落通用行）——**加一个工具的 UI 卡片=注册一个 keyed slot**（docs/architecture.md:158）。

**状态管理三段式**：`store`（zustand vanilla+immer 裸 observable）→ `api/*-controller/client` React-free 业务模型（`ClientSessions→SessionManager→Session`）→ `ui-session` 转标准源 hook（`SessionProvider` 允许并发子树绑不同 Session）。

**i18n**：`locale/src/client/index.ts:41-48` 声明合并命名空间；内置 en/zh 双语字典（键集一致，FALLBACK_LOCALE='en'）；**Client UI 文案 locale-owned**——产品文本必须走类型化字典与 `t`，`verify-client-ui-i18n` 门禁拒绝硬编码（AGENTS.md:154）。

## 4.8 桌面应用：apps/desktop + apps/desktop-host

**Electron 主进程**（apps/desktop/src/main.ts）：
- `dsh-app://` 特权协议（:132-142）；`createWindow()`（:206-238）webPreferences 全锁（nodeIntegration:false/contextIsolation:true/sandbox:true）；
- `protocol.handle(SCHEME)`（:662-677）：`dsh-app://app/` 静态资源直接服务打包的 web dist，**其余全部 forwardWebRequest 转发给已认证 Host**；
- `webRequest.onBeforeSendHeaders`（:710-721）改写 WebSocket 握手：注入主进程持有的 cookie——**渲染进程自己永远不持有 Host cookie**；
- `host-process.ts:186-235` `DesktopHostProcess.start()`：spawn **同一 Electron 可执行文件的 Node 模式**（ELECTRON_RUN_AS_NODE）跑 desktop-host；IPC 事件 ready/fatal/platform-session/shutdown-complete/update-tasks/quit-inspection（:8-37 严格校验）。

**desktop-host**（src/index.ts:18-105）：复用与 CLI 完全相同的 `runProfile` 管 web profile（`--no-open --port 0`）；就绪后 `ctx.connection.authenticatedUrl()` 生成带进程 token 的 URL，`process.send({type:'ready',url,injections})`（:103-104）回传 Electron；插件安装用 Electron-as-Node 跑内置 pnpm。

**签名打包**（scripts/electron-builder-config.mjs:46-150+）：asar+asarUnpack（.node/ripgrep/libreoffice-kit）；Windows EV 代码签名（token/证书/signtool+NSIS）；macOS 签名+notarize+事后验证；electronFuses 保留 runAsNode（Node 模式子进程所需）。

## 4.9 实验区与多语言载体

### 4.9.1 packages/experimental（24 包，424 文件）

组规则（README.md:12）：全部 `@deepseek-ai/dsh-experimental-*` 发布，**正式产品不得依赖**。速览：Agent Teams 四件套（`agent-team` ctx.agentTeams + tool-agent-team 九工具 + client-ui + profile）、浏览器路线五包（playwright-mcp/chrome-devtools-mcp/stagehand-native + browser-use-runtime 公共底座 + browser-use 注册槽）、computer-use 两包（cua-driver mcp/native）、语音输入五件套（speech-to-text→sensevoice→api→client-ui→bundle）、审查一包（auto-review）、调试三包（inspector 16.7K 行/session-inspector/inspector-profile）、mods 两包（claude-code-mods 4.2K 行+client-ui）、worker 两包（webworker-runtime 13.4K 行/packer）、ptc-runtime-python。

**深挖样例**：
- **`agent-team`**：`ctx.agentTeams`（index.ts:56）建立在 subagent continuable 之上——`TeamRoster`（spawn 即 `startContinuable`）、`TeamMailbox`（先在 Lead 日志持久消息、目标 inbox 落盘后才 checkpoint delivered——queued-minus-delivered 即恢复邮箱）、`TeamTaskBoard`（`task-<n>` 单调 id、revision CAS、blockedBy 无环校验）；限额 maxMembers 16/maxTasks 256（:41-45）。
- **`browser-use-runtime`**：`SessionResources<T>`（src/index.ts:60）——浏览器资源归属"精确的活 Agent 激活"，**永不转移给 resume 出的 Session**（README:50）；`entry()` 懒获取（失败 acquisition 自行回滚后删除登记 :172-175）；`run()` 用 `AbortSignal.any` 融合调用方取消与 owner 处置，Per-Session 串行、跨 Session 并行（:107-132）；`mcp.ts:98 mountSessionMcp` 在 `agent/created` 内串行连接 provider MCP 并先于首个模型请求完成工具发现。
- **`inspector`**（210 文件）：跨 realm CDP hub——Host 插件起**专用 Worker** 持全部 CDP 状态；Client 经带随机 subprotocol token 的 WSS `/ingest` 直连；DevTools 前端（官方 chrome-devtools-frontend 源码自编译）由 Host 镜像服务；Cordis Context/Fiber 树投影为 Elements 面板；安全模型仅 127.0.0.1 绑定+ingest token。

### 4.9.2 native/system — C addon（16 文件）

两个工件：`landlock-run`（静态 musl 可执行，packages/entry/src/main.c）与 `flock`（Node-API v8 addon，flock.c，`flock(LOCK_EX|LOCK_NB)` 于 napi_async_work :55-59）。构建无 node-gyp——`scripts/build.ts` 直接 spawn musl-gcc（静态 `-Os -static -s`）或 cc（:54-71）；平台 prebuilds 经 npm optionalDistributions 分发，**消费者从不编译原生码**。JS API（packages/entry/src/index.ts）：`launcherPath()`（:69-83）、`grantArgs()`（:94-99）、`probe()` 功能性探测返回 full/partial/unusable（:116-127——`--probe` 在子进程内真实执行最大 ruleset 而非查版本号）；`tryLockExclusive(fd)`（flock.ts:46，懒加载 addon）。被 atomic-write（文件锁）与 Linux 沙箱（landlock）使用。

### 4.9.3 python/ — Python SDK（10 文件）

- `python/sdk/client.py:39` `HarnessClient`：**同步、换行分隔 JSON-RPC 2.0 over stdio**；后台 reader 线程三分发（带 id+method→服务端反向请求如权限询问；带 id→唤醒 waiter；仅 method→Notification）；`subscribe_session_notifications` 用 `subagent.started` 维护会话树归属过滤（:492-536）；关闭序列 shutdown→关 stdin→terminate→kill（:94-131）。
- `api.py:49` `DeepSeekHarness`（默认 provider `deepseek-official`/model `deepseek-v4-flash`）：`Session.run(input)`（:139-189）订阅会话树通知、等 `agent/inbox/spliced` 收据、收集到 idle、提取 final_response 与 finish_reason。
- **启动**：默认从 `deepseek_harness_runtime.resolve_bundled_launch_args()` 取 exe，拼 `[*base,'--profile','sdk',...]`；**强制显式 DSH_HOME**（client.py:475-479）。
- `python/sdk-runtime`：wheel-only 打包（hatch_build.py:61-121）——生产=单文件 Node exe（`deepseek-harness-sdk-runtime-<plat>-<arch>`，目标机免装 Node）+ripgrep sidecar+office kit；dev=完整 deploy closure（`DSH_RUNTIME_MODE=node`）。

### 4.9.4 scripts/ 关键构建脚本

`build.ts`（52 行：校验 Node 类型剥离→native→lib→web 顺序）；`dev-web.ts`（410 行：完整 build→三 watcher（tsc/tsdown/vite）→`dsh web`，任何 watcher 退出即整环 exit 1）；`primary-runtime/prepare.ts`（锁定可重定位解释器：python-build-standalone CPython+Node/pnpm+office 资产，URL+sha256 锁定）；`release/{pack,publish,bump,verify}.ts`（family=dsh|vendor 的 tarball/registry 发布，瞬态码重试）；`build-exe-for-python-sdk.ts`（Python 载体构建）。其余 ~250 个脚本为 verify-*/gen-*/persistence-*/translation-* CI 门禁（归类不展开）。


---

# 第 5 章 文件清单总表（完整清单见附录 A）

第 5 章的完整内容即**附录 A**（由脚本对全部纳入范围文件自动提取生成）：**2,787 个生产源文件、474,243 行**，按 324 个包分组，每包附职责说明，每文件列出路径/行数/导出符号/import 依赖。正文中与此章相关的导读：

- 排除说明：`vendor/`（外部框架 vendored 副本）、`packages/test-support/`（测试基础设施）、各包 `tests/` 与 `*.test|spec|bench|e2e|expected|snapshot.*`、`.d.ts`、`benchmarks/`、`website/`、`docs/`、`.agents/`、`.claude/`、`.github/`、`snapshots/`、9 个根 vitest 配置均不在清单中；
- 纳入的"配置类"文件：各 bundle 的 `cordis.patch.yml` 与 profile 模板（承载运行逻辑的组合配置，已在 §4.6 分析）、根 `tsdown.config.ts`、`packages/tsdown.worker.ts`、`packages/client/tsdown.client.ts`、`apps/web/vite.config.ts`、`apps/desktop` 打包配置；
- 规模分布（前十二大包）：client/ui-conversation 13,013 行 ＞ ui-chat 12,547 ＞ extensions/tool-cordis 8,858 ＞ api/session-controller 8,382 ＞ extensions/cordis-client-runner 7,821 ＞ client/ui-primitives 12,986 ＞ experimental/webworker-runtime 13,364 ＞ experimental/inspector 16,689 ＞ core/tools 5,679 ＞ subagent 5,148 ＞ session-persistence-jsonl 5,005 ＞ boot/app-boot 4,993。

---

# 第 6 章 关键函数深度解析

> 覆盖核心业务链路的六个代表函数，逐段解读实现逻辑。行号与代码均为实读摘录（节选处标注省略）。

## 6.1 `runCli` — 命令行入口分发（apps/cli/src/bin.ts:26-78）

```ts
export async function runCli(options: RunCliOptions = {}): Promise<void> {
  const version = getDshRuntimeVersion()
  const { manageDesktopProfile, ...profileOptions } = options
  const invocation = parseDshArgs(process.argv.slice(2), version, manageDesktopProfile)

  switch (invocation.mode) {
    case 'profile': {
      const { runProfile } = await import('./profile-boot.ts')
      try {
        await runProfile({
          environment: loadLayeredEnv('dsh'),
          profile: invocation.profile,
          fromDefaultProfile: invocation.fromDefaultProfile,
          patchFiles: invocation.patches,
          args: invocation.args,
          ...profileOptions,
        })
      } catch (error) {
        if (!(error instanceof StartupError)) throw error
        await reportStartupFailure(error, { home: resolveDshHome(), version, profile: invocation.profile })
        process.exit(1)
      }
      break
    }
    case 'plugin': { /* ... dsh plugin 子命令：pnpm 转发 ... */ }
    case 'dump-config': { /* ... 免启动打印组合树 ... */ }
    case 'dump-config-schema': { /* ... 打印 JSON Schema ... */ }
  }
}
if (import.meta.main) { await runCli() }
```

**逐段解读**：
1. `parseDshArgs`（args.ts:146）以 Commander `passThroughOptions+enablePositionalOptions+allowUnknownOption` 实现"首 token 即边界"：`dsh web --foo` 中 `web` 展开为 `--profile web`（args.ts:201-204），`--foo` 及之后内容不被启动器消费，原样进入 `invocation.args`——**启动器只解析自己拥有的旗标**，其余交给插件树内注入的 app 插件（经 `ctx.cmdlineArgs`）。
2. 四模式懒加载路由（`await import`）：profile 启动 / plugin 管理 / 两个 dump 诊断。`dump-config` 是理解组合层的第一工具（打印整棵 patch 后的插件树）。
3. 错误分级：只有 `StartupError`（app-boot 审计抛出，见 §4.5.1）走友好诊断报告+exit(1)；其余异常原样上抛（由 `installFailLoud` 兜底单行打印）。

## 6.2 `runProfile` — profile 装配管道（apps/cli/src/profile-boot.ts:244-326）

```ts
export async function runProfile(options: RunProfileOptions): Promise<{ ctx: Context; shutdown: ProcessShutdown }> {
  const disposeProxy = await installProxyFromEnvironment(options.environment, /* log */)
  // ... memoized dispose：fiber.dispose() + disposeProxy，聚合失败 ...
  const composed = await composeProfile(options.profile, options.patchFiles, options.fromDefaultProfile, options.resolvedProfile)
  const appReady = createAppReady()
  const shutdown = createProcessShutdown(dispose)
  process.on('SIGTERM', () => shutdown.interrupt(0))
  process.on('SIGINT', () => shutdown.interrupt(130))
  installFailLoud(NAME, process, async () => { await app.current?.fiber.dispose() })

  const rootConfig = join(composed.profile.dir, PROFILE_ROOT_FILENAME)
  const ctx = await boot(NAME, rootConfig, readProfilePatches(NAME, profileContext, composed.profile), async (hostCtx) => {
    app.current = hostCtx
    hostCtx.provide('profileContext', profileContext)
    hostCtx.provide(DSH_LAUNCH_ENVIRONMENT_KEY, options.environment)   // 不可变启动快照
    await hostCtx.plugin(PluginPackages, { resolution: composed.resolution })
    provideCmdline(hostCtx, { args: options.args, exit: code => void shutdown.shutdown(code), ready: appReady.service })
  })
  app.current = ctx
  if (!signalShutdown.signal.aborted && ctx.fiber.state === FiberState.ACTIVE && ctx.get('loader') !== undefined) {
    appReady.commit()
  }
  return { ctx, shutdown }
}
```

**逐段解读**：
1. **代理先行**（:249-252）：Node fetch 默认无视代理环境变量，且 `NODE_USE_ENV_PROXY` 在进程启动时采样——所以必须从启动器快照装载代理，且要发生在任何插件 import 之前。
2. `composeProfile`（:197-209）→ `prepareProfile`（:167-173）**每次重写空根配置** `cordis.yml="[]"`（:171）：整棵树都是 patch；防止 vendored Loader 的写回（插件自卸载时持久化当前树）把组合行固化进根文件，否则下次启动会重复叠加 bundle 插入行。
3. 信号语义：SIGTERM=监督者常规停止→exit 0；SIGINT=用户中断→exit 130（:280-281）；启动窗口内信号同样触发拆除（"插入的 provider 可能在兄弟行完成挂载前发布"，:275-279 注释）。
4. `boot()` 的 prepare 回调按序提供：profileContext（patch 层序事实）→ 启动环境快照 → `PluginPackages`（运行时包解析拦截）→ cmdline 三件套。**顺序即契约**：任何配置树条目挂载时这些 ctx 值必须已就位。
5. `appReady.commit()` 的三重条件（未中止/fiber ACTIVE/loader 存在）保证就绪信号只在完整启动后提交——桌面/Web 用它决定何时开窗/开浏览器。

## 6.3 `ReactLoopAgent.turn()` — turn/step 主循环（packages/core/agent-loop/src/agent.ts:296-396）

```ts
private async turn(): Promise<boolean> {
  /* ... phase 校验 + signal.throwIfAborted() ... */
  const turn = phase.turn + 1
  try { this.session.append('turn/start', { turn }) } catch (error) { this.throwError(error) }
  phase.turn = turn
  let turnEnds: TurnEndReason | null = null
  let target: InboxTarget = 'next-turn'
  try {
    while (true) {
      signal.throwIfAborted()
      const step = phase.step + 1
      const decision = await this.preStep(target, { turn, step })          // ① 认领输入+组装+waterfall
      if (decision.kind === 'reject') { turnEnds = { kind: 'blocked' }; return false }
      if (turnEnds && decision.messages.length === 0) break
      if (phase.step === 0 && decision.messages.length === 0) {             // ② 空 turn 不花模型调用
        turnEnds = { kind: 'completed' }; return false
      }
      this.session.append('step/start', { turn, step })                     // ③
      const toolRecovery = new ToolCallRecovery()
      const stopRecovery = this.ctx.on('session/event', (_s, event) => { if (_s === this.session) toolRecovery.observe(event) })
      try {
        const stepEnd = await this.step(decision)                           // ④ 一次模型请求+工具
        if (turnEnds === null || turnEnds.kind !== 'max-tokens') turnEnds = stepEnd   // ⑤ 粘性
      } catch (error) {
        for (const event of toolRecovery.results()) {                       // ⑥ 失败补齐 tool/result
          this.session.append('tool/result', event.data, { surfaceOp: 'append', /* ... */ })
        }
        throw error
      } finally {
        stopRecovery()
        this.session.append('step/end', { turn, step })                     // ⑦ 必闭合
      }
      if (turnEnds && this.inbox.nextStep.length === 0) {
        await this.dispatch.serial('agent/turn-stopping', { turn, signal }) // ⑧ 停止前事件（无 next）
      }
      if (turnEnds && this.inbox.nextStep.length === 0) break
      target = 'next-step'                                                  // ⑨ 工具欠新请求→下一 step
    }
  } catch (error) {
    const cause = abortedCancelCause(signal)
    if (cause !== undefined) { turnEnds = { kind: 'aborted', reason: cause }; throw error }
    turnEnds = { kind: 'error', error: /* 结构化 LlmError/UNKNOWN */ }
    this.throwError(error)
  } finally {
    this.session.append('turn/end', { turn, reason: turnEnds! })            // ⑩ 无论成败必闭合 turn
  }
  if (!this.inbox.hasPending) return false
  phase.abort = new AbortController()                                       // ⑪ 新回合新取消域
  phase.wakeRequested = false
  phase.step = 0
  return true
}
```

**逐段解读**：
- ① `preStep` 是输入的**唯一裁决点**：`agent/pre-step` waterfall 监听器可 reject（→blocked）或改写认领消息、声明 `startsRequestSeries`；空的首个 claim 关闭 turn 但**不产生 step**（②，"花费 no model call"）。
- ③⑦⑩ **结构化闭合保证**：`step/start`/`step/end`/`turn/end` 三层事件无论正常/异常/取消路径都会落日志——这是日志重放与中断修复（repair.ts）能工作的前提。
- ⑥ `ToolCallRecovery` 观察本 step 已落日志的 `tool/call`，异常时为无结果者补合成 `tool/result`（区分未启动/结果未知两种文案）——保证 call/result 事件对永远平衡。
- ⑤ max-tokens 粘性：一旦某 step 触顶，后续正常完成的 step 不得把 turn 结果降级回 completed。
- ⑧ `agent/turn-stopping` 是 serial 事件（无 `next()`），是停止策略（如 goal wrapup）的挂点；`inbox.nextStep` 非空说明工具结果又欠一次请求→⑨ 继续 step。
- ⑪ 返回 true→`kick()` 的 `while (await this.turn())` 继续下一 turn，且换新 AbortController（旧锁存唤醒失效，由活驱动自己认领队列）。

## 6.4 `Session.append` — 事件日志写入（packages/core/session/src/index.ts:718-769）

```ts
append<T extends SessionEventType>(type: T, data: SessionEventMap[T], ...opts): SessionEvent<T> {
  const surfaceOpts: SurfaceIntent | undefined = opts[0]
  const surfaceMetadata = { /* sourceEventSeqs / surfaceOp 透传 */ }
  const dataSnapshot = snapshotJsonValue(data)                    // ① 单遍验证+拷贝
  if (dataSnapshot === undefined) throw new Error(`session event "${type}" carries non-JSON-serializable data`)
  const surfaceMetadataSnapshot = snapshotJsonValue(surfaceMetadata)
  if (surfaceMetadataSnapshot === undefined) throw new Error(/* ... */)
  const entry = attachments.get(this)
  if (entry?.appending) throw new Error('session append cannot reenter while another append is being published')  // ② 防重入
  const event = deepFreeze({
    type,
    seq: SessionSeq(this.log.length),                             // ③ seq = log.length 连续性契约
    time: Date.now(),
    data: dataSnapshot,
    /* surfaceMetadata */
  })
  validateSessionEventData(event, `session event "${type}" at seq ${event.seq}`)   // ④ 结构校验
  this.surfaceManager.validateNext(event)                         // ⑤ surface 前置校验
  if (entry !== undefined) entry.appending = true
  try {
    let callbacks: SessionCallback[] | undefined
    if (entry !== undefined) callbacks = collectSessionCallbacks(entry.emitCtx, [entry.carrier, 'session/event', this, event])
    this.log.push(event)                                          // ⑥ 提交
    this.eventsSnapshot = undefined
    if (callbacks !== undefined) invokeContainedSessionObservers(/* 逐监听者容错广播 */)  // ⑦
    return event
  } finally {
    entry.appending = false
    if (entry.detachRequested && !entry.announcing) entry.detach()
  }
}
```

**逐段解读**：
- ① `snapshotJsonValue`（dsh-util-values）一遍遍历同时完成 JSON 可序列化验证与深拷贝——注释（:712-716）说明动机：**事件日志是持久事实源，坏事件必须在 append 处失败**而不是后端 flush 时；单遍也防 getter 在"验证"与"存储"两次读取间变值。
- ③ `seq = log.length`：全局连续、无空洞——持久化、投影、fork、重放全部依赖它。
- ② append 重入防护：防止 `session/event` 监听器同步再 append 造成事件交错。
- ⑤ surface 校验先行：消息类事件必须带 `surfaceOp`（append/replace）与 `sourceEventSeqs`，非法转移在此拒绝（types.ts:462-477 契约）。
- ⑥⑦ 先 push 后广播：监听者异常被"遏制"（contained）不影响日志本身；持久化后端在 emitCtx 钩子内缓冲追加，flush 才承诺耐久。

## 6.5 `LlmRuntime.prepareCall` — 请求准备与单发冻结（packages/llm/llm/src/index.ts:929-976）

```ts
async prepareCall(config: LlmCallConfig, signal?: AbortSignal): Promise<PreparedLlmCall> {
  const registration = this.registration(config.provider)
  const adapterCall = await registration.adapter.prepareCall(config.provider, config.model, signal)  // ① 适配器能力快照
  const modelInfo = this.normalizeModelInfo(registration, config.model, adapterCall.model)          // ② 校验/脱离
  const resolved = this.resolveCallWithInfo(config, modelInfo)                                       // ③ 物化默认
  const resolvedConfig = deepFreeze(structuredClone(resolved.config))                                // ④ 冻结
  const context = resolved.context === undefined ? undefined : deepFreeze(structuredClone(resolved.context))
  const adapterDefaults = deepFreeze<LlmCallConfigAdapterDefaults>({ /* 记录哪些默认是物化的 */ })
  let dispatched = false
  return Object.freeze({
    config: resolvedConfig, retryPolicy: registration.retryPolicy, /* context/modelInfo 能力面 ... */
    stream: (options: GenerateOptions): AsyncIterable<StreamChunk> => {
      if (dispatched) throw new LlmError('a prepared LLM call can only be dispatched once', 'INVALID_PREPARED_CALL')
      if (!callConfigEquals(options, resolvedConfig)) {
        throw new LlmError('prepared LLM call config changed before adapter dispatch', 'INVALID_PREPARED_CALL')
      }
      dispatched = true
      return this.streamWithRegistration(options, { registration, config: resolvedConfig, modelInfo, dispatch: options => adapterCall.stream(options) })
    },
  })
}
```

**逐段解读**：
- ①-③：`agent/request` waterfall 改写后的 config 在此**解析为完全显式**：适配器提供的模型元数据（上下文窗/推理档位/工具更新能力）被校验并"脱离"（不保留对适配器可变状态的引用），reasoningEffort/maxTokens 默认值物化并记录在 `adapterDefaults`（供日志头比较时剔除默认差异）。
- ④ `deepFreeze(structuredClone(...))`：prepared call 是不可变证据；agent-loop 用"冻结同一性"重试（重试不重新组装、直接复用同一 prepared 请求）。
- `stream` 闭包的**单发约束**：dispatched 标志+全等校验（`callConfigEquals` 逐字段），违反即 `INVALID_PREPARED_CALL`——防止"准备时 A 路由、派发时 B 请求"的竞态；`streamWithRegistration` 把 registration 绑进 `llm/stream` waterfall，HMR 换代后旧 prepared call 派发会因 registration 已失效而拒绝，**绝不把 A 代能力与 B 代端点拼接**。

## 6.6 `selectCompactableRange` — 压缩区间选择（packages/compaction/compaction-basic/src/region.ts:117-155）

```ts
export function selectCompactableRange(session, measurement, retainTokens): { start: SessionSeq; end: SessionSeq } | null {
  const pricedNodes = measurement.nodes
  if (pricedNodes.length === 0) return null
  const surfaceNodes = session.surface.nodes
  if (surfaceNodes.length !== pricedNodes.length
    || surfaceNodes.some((seq, index) => seq !== pricedNodes[index]?.seq)) {
    throw new Error('compaction: token-meter surface does not match the current session surface')   // ① 一致性闸
  }
  const firstIdx = systemHead(session, surfaceNodes[0]!) === undefined ? 0 : 1                        // ② 跳过 system 头
  let accumulated = 0
  let keepFromIdx = pricedNodes.length
  for (let index = pricedNodes.length - 1; index >= 0; index -= 1) {                                  // ③ 自尾向前
    accumulated += pricedNodes[index]!.tokens
    keepFromIdx = index
    if (accumulated >= retainTokens) break
  }
  if (keepFromIdx <= firstIdx) return null
  while (keepFromIdx > firstIdx) {                                                                    // ④ 配对回退
    if (toolPairingBalancedBefore(session, surfaceNodes[keepFromIdx]!)) break
    keepFromIdx -= 1
  }
  if (keepFromIdx <= firstIdx) return null
  const first = surfaceNodes[firstIdx]!
  const cutoff = surfaceNodes[keepFromIdx - 1]!
  return { start: first, end: cutoff }
}
```

**逐段解读**：
- ① **一致性闸**：token 计量必须与当前 surface 完全同构（seq 逐位相等），否则抛错而非静默压缩错区间——"misconfiguration fails loud" 的体现。
- ② surface 节点 0 若是 system 头则永不入压缩区间（系统提示经 surface 节点机制单独管理，见架构文档 system-prompt-as-surface-node 决策）。
- ③ 保留预算算法：从最新消息向前累计 token，累计达 `retainTokens` 处即为保留边界——保证最近上下文逐字保留。
- ④ **配对回退**：边界若落在 assistant(tool-call) 与 tool(result) 之间，向前回退到配对平衡处——拆开会导致日志重放时出现无应答的 tool-call（模型请求非法）。
- 返回 `[first..cutoff]` 区间后由压缩事务接手（§4.2.4）：`compaction/start` 持久锁 → LLM 摘要（重放原前缀命中 provider KV 缓存）→ 表面稳定性复验 → `compaction/end` + checkpoint 替换消息。

## 6.7 其它关键函数速查（详见第 4 章对应节）

| 函数 | 位置 | 一句话实现要点 |
|---|---|---|
| `executeToolCalls`/`runGroup` | agent-loop/src/tool-calls.ts:60-247 | exclusive 屏障+parallel 滚动池；`commitReady` 按模型序提交相邻就绪槽；abort 补合成 ABORTED_BEFORE_DISPATCH 对 |
| `ToolRuntime.prepareExecution` | core/tools/src/index.ts:1493-1539 | pre-execute waterfall→ask→approval→单调守卫→dispatch 的编排序列 |
| `ObservedStateGate` | fs-observation-policy/src/index.ts:21-127 | WeakMap 权威观察账本，占 write-intent/edit-intent 单槽实现先读后写 |
| `resolve`（shell） | bash-local/src/index.ts:120 | request→spec 显式化模板：clampTimeout 填默认与上限 |
| `scanZstdFrames` | session-persistence-jsonl/src/zstd.ts:48-104 | 手写 Zstandard 帧结构扫描，撕裂尾帧返回 tornStart |
| `publishStoredMigration` | session-persistence-jsonl/src/generation.ts:122-127 | worker 验证后 link()+unlink() 独占发布新代（防 TOCTOU） |
| `DeepSeekAdapter.request` | llm-deepseek/src/adapter.ts:75-159 | Files API 降级重试、wire 扩展两段式提交、SSE translate |
| `startContinuable` | subagent/src/continuation.ts:104-192 | childId 预留→快照→ChildLock 临界区 materialize→失败回滚 |
| `bindSnapshotSelector` | client/ui-renderer/src/client/bind.ts:21-27 | 全客户端唯一 hook 构造器（uSES+selector） |
| `mountPreset`（activate） | agent-preset-registry/src/index.ts:103-122 | createScope+装载 YAML 子树+bindScopeParent 到 agent scope |


---

# 第 7 章 端到端调用链分析

## 7.1 启动链：`dsh web` 从命令到插件树

```text
用户: dsh web
 └─ apps/cli/src/bin.ts:76 runCli()
     └─ args.ts:146 parseDshArgs → 'web' 展开为 --profile web → mode='profile'
 └─ apps/cli/src/profile-boot.ts:244 runProfile()
     ├─ dsh-http-proxy installProxyFromEnvironment(启动快照)            [任何插件 import 前]
     ├─ composeProfile → prepareProfile                                  [重写空根 cordis.yml="[]"]
     │   └─ boot/app-boot/src/profile.ts:781 loadProfile('dsh','web',INSTALL_ANCHOR)
     │       ├─ PROFILE_TEMPLATES: web → bundles=[dsh-base, dsh-web-app]  (profile.ts:179-195)
     │       └─ loadProfileDirectory: 逐 bundle 读 dsh.bundle.patch (双锚解析 profile.ts:706-717)
     ├─ createRuntimeResolution (profile.ts:441-474)                     [冻结包解析表]
     ├─ app-boot/src/index.ts:973 boot('dsh', rootConfig, readProfilePatches(...), prepare)
     │   ├─ ctx.plugin(Loader) → mountRootInclude (index.ts:539-586)
     │   │   └─ include.applyEntryPatches: base patch(约90行) → web-app patch(约80行) → home patch → --patch
     │   ├─ 行挂载：dsh-llm/dsh-session/dsh-agent/dsh-agent-loop/dsh-tools… （base 层）
     │   │           dsh-host-webserver/dsh-client-connection/dsh-api-* /client-ui-*（web-app 层）
     │   ├─ prepare 回调: profileContext / 启动快照 / PluginPackages / provideCmdline
     │   └─ loader.await() → auditStartupEntries (index.ts:1013; 必需 id 失活→StartupError)
     └─ web-app/src/startup.ts: 解析 --port/--no-open → webStartup 服务 → 开浏览器 http://127.0.0.1:3080
浏览器: index.html → main.ts → AppWebEntry.run() (client/web/src/boot.ts:23)
 └─ __ModuleLoader__ 门面 + __DSH_BOOT__(WebBootGraph) → bootClient → mountClient → slots.renderSlot('root')
```

## 7.2 主调用链：一次「用户发消息 → 模型回复 → 工具执行 → 落盘 → UI 呈现」

文件+函数级完整链（行号见第 4/6 章）：

```text
① 输入   ui-conversation composer
          └─ ctx.remote.<sessionController 方法>()                    [Typert 生成方法]
             └─ client/connection/src/client/rpc.ts:34 createWebConnectionRpc.call()
                POST /api/sessionController/prompt  (ClientRequest 信封)
          └─ Host: host/webserver → client/connection rpc-host admit → api/gateway/src/index.ts:233 dispatchRpc
             └─ api/session-controller Remote 方法 → agent.followup()/agents.create()
② 入队   core/agent-loop/src/inbox.ts inbox 投影记录待处理输入
          └─ agent.ts:214 wakeDriver → withInitiator(this, kick)
③ 回合   agent.ts:296 turn() ── 逐段解读见 §6.3
          ├─ :267 preStep: inbox.claim + systemPrompt.assemble + agent/pre-step waterfall
          ├─ :329 session.append('step/start')
④ 请求   agent.ts:547 prepareRequest: agent/request waterfall → llm/index.ts:929 prepareCall (§6.5)
          └─ agent.ts:599 buildRequest: request/header(首次/变更/新系列) + deriveMessages() 冻结历史
⑤ 流式   agent.ts:436 preparedCall.stream(request) → llm/stream waterfall
          └─ llm-deepseek/src/adapter.ts:75 request(): fetch(baseURL/messages) SSE
             └─ translate.ts:104 SSE→StreamChunk（reasoning 保留 signature / tool JSON 校验）
          └─ agent-loop/src/assistant-stream.ts: BlockAssembler 聚合 → session.append('assistant/message')
          └─ [并行支线] agent/assistant-stream 活事件 → api gateway $events → 浏览器 WS → ui-chat 增量渲染
⑥ 工具   assistant message 含 tool-call → tool-calls.ts:60 executeToolCalls
          └─ session.append('tool/call') → core/tools/src/index.ts:1493 prepareExecution
             ├─ tools/pre-execute waterfall（hooks/权限/沙箱）
             ├─ ask → serviceAsk → ctx.approval (user-approval/src/index.ts:215; UI 经 waterfall 应答)
             ├─ 单调守卫 guardReason → dispatch(tools/execute around) → 工具体
             │    例 bash: tool-bash → shell/bash-{local|sandbox} → subprocess-local spawn → sandbox confine
             │    例 写文件: tool-fs write.ts:119 → fs/write-intent waterfall(观察策略裁断)
             │              → fs-local writeText(锁内版本 CAS+原子写) → fs/observed 记账
             └─ postExecute → finalizeContent → session.append('tool/result')
⑦ 落盘   session-persistence-jsonl: append 钩子缓冲 → 批次 zstd 帧追加 log.v4.jsonl.zstd
          └─ flush 语义屏障 (SessionStore.flush → session/flush)
⑧ 读侧   Host: sessionProjections 增量折叠(turnBoundary/inbox/todos/goal…)
          浏览器: packed Remote follow/page 流 → SessionEventLikeEntry 窗口
          └─ ui-conversation ConversationNodeDefinition 状态机 → chat/trajectory 视图快照
          └─ ui-tool 'tool.call.toolview' keyed slot 按 Tool 名分派卡片
⑨ 收敛   turnEnds 且 inbox.nextStep 空 → agent/turn-stopping serial → session.append('turn/end')
          └─ agent 回 idle (agent/status) → UI 呈现最终消息/deliverables
```

**时序图（文字版）**：

```text
浏览器            webserver/gateway      session-controller   agent-loop          llm/adapter        tools/fs/shell      session(JSONL)
  │ prompt RPC ───────►│                        │                 │                   │                  │                  │
  │                    │ dispatchRpc ───────────►│ followup() ────►│ inbox+wake        │                  │                  │
  │                    │                        │                 │ turn/start ────────────────────────────────────────────────►│
  │                    │                        │                 │ preStep(agent/pre-step)             │                  │
  │                    │                        │                 │ step/start ───────────────────────────────────────────────►│
  │                    │                        │                 │ prepareCall ─────►│ 冻结请求          │                  │
  │                    │                        │                 │ stream ──────────►│ fetch SSE         │                  │
  │◄─ WS stream chunks ────────────────────────────────────────────┤ assistant/message ───────────────────────────────────────►│
  │                    │                        │                 │ tool/call ─────────────────────────────────────────────►│
  │◄─ approval ask ────│                        │                 │ pre-execute→ask   │                  │                  │
  │─ approve ─────────►│                        │                 │ execute ────────────────────────────►│ 工具体执行         │
  │                    │                        │                 │ tool/result ────────────────────────────────────────────►│
  │                    │                        │                 │ (欠请求→下一 step；否则 turn-stopping)   │                  │
  │                    │                        │                 │ turn/end ────────────────────────────────────────────────►│
  │◄─ follow/page 流: 事件窗口 → Conversation 节点 → Slot → React 渲染                                                            │
```

## 7.3 次级链路速览

- **headless**：`dsh --profile headless "task"` → base+headless bundle → headless/src/index.ts:35 创建 Agent → 驱动到静默 → stdout 文本/NDJSON → exit（无 server）。
- **Python SDK**：`DeepSeekHarness()` → 拉起 `dsh --profile sdk` 子进程 → stdio JSON-RPC → `prompt` → 订阅会话树通知 → 等 idle → 提取 final_response（api.py:139-228）。
- **webhook**：GitHub POST → webhook-github handler（验签）→ `webhookRuntime.dispatch`（fire-and-forget）→ 规则匹配 → `createWebhookSession`（workspace+preset+permission）→ `followup(prompt)` → 与主链路 ③ 起汇合。
- **桌面**：Electron main → spawn desktop-host（Node 模式）→ runProfile(web) → IPC ready{authenticatedUrl,injections} → 渲染页 `dsh-app://app/` → 此后与 Web 同链路（主进程代持 cookie）。

---

# 第 8 章 横切机制说明

| 机制 | 实现位置与方式 |
|---|---|
| **错误处理体系** | 分层 fail-loud：① 启动期 `installFailLoud`（app-boot index.ts:680-729，unhandled→单行 inspect+exit 1）；② 启动审计 `StartupError`（必需条目失活，:926-940）；③ 结构化业务错误——branded 错误码（FS_*/WEB_PROVIDER_*/TOOL_TIMEOUT 等），LLM 错误统一 `LlmError{failure}`；④ 事件监听器"遏制"（contained，session/event 逐监听器容错）；⑤ 工具管线错误归一为 isError 结果（materializeFinalResult 把管线异常快照成结果）；⑥ 空 catch 必须命名错误与原因（AGENTS.md:148） |
| **日志（log）体系** | Cordis `ctx.logger`；启动诊断收集（boot 的 diagnostics logger）；`errorChain` 因果链文本化（dsh-llm）；渲染进程 console tail（desktop crash-report）；无独立日志框架——持久"日志"指会话事件日志本身 |
| **配置管理（多环境）** | 整树皆 patch：bundle 层（dsh.profile.bundles 顺序）→ profile `cordis.patch.yml` → home 级 `cordis.patch.yml` → `--patch` overlays → 遥测开关；`dsh --dump-config`/`--dump-config-schema` 自省；`!!js` 表达式惰性求值（仅 plugin config 与 disabled）；volatile 配置（如 maxParallelToolCalls）可热改；分层 `.env`（loadLayeredEnv，拒设引导变量）；配置错误"fail loud at load"（AGENTS.md:142） |
| **权限/安全控制** | ① 沙箱三模式（read-only 默认/workspace-write/danger-full-access）+ 平台后端（bwrap/landlock/seatbelt/windows-acl）+ 升级审批（先批后执行）；② fs 先读后写审批（fs-observation-policy）+ 版本 CAS + TOCTOU 重解析；③ 审批缝 fail-closed（无 answerer 即 deny）；④ 子进程环境凭据清洗（SENSITIVE_ENV_PATTERN）；⑤ Web fetch SSRF 防护（公网 IP 钉定+同源重定向）；⑥ 连接信任：回环默认+trustedHosts 显式、进程 token→HMAC cookie；⑦ 桌面：contextBridge 最小面+主进程代持 cookie+IPC 白名单；⑧ 遥测"never a prompt/response/credential"；⑨ 凭证文件 0600+owner-only 校验 |
| **并发/异步模式** | ① Cordis fiber 生命周期（注册即 effect，卸载逆序拆除）；② AbortSignal 融合（caller+wrapper+factory 三源，raceAbort/fuseToolSignals）；③ 每键 FIFO 锁（fs targetKey）与 promise tail 串行（workspace/subagent ChildLock）；④ 工具并行：exclusive 屏障+有界滚动池+模型序提交；⑤ 两阶段写+pending 标记恢复（workspace/storage-domain）；⑥ 进程树收容（systemd scope/Job Object）+ SIGTERM→SIGKILL 阶梯；⑦ AsyncLocalStorage 发起者归因 |
| **缓存** | deriveMessages 的 contentGeneration 失效缓存；投影 checkpoint 读梯（viewCheckpoint→restore）；冷读 LRU（JSONL 后端仅 2 条）；office-to-pdf 内容寻址缓存；技能 collect LRU(128)+revision 双检；**摘要请求的 provider KV 前缀缓存命中**（compaction 重放原前缀）；registry 懒物化 schema 缓存 |
| **定时任务** | schedule 包：持久域+六种 selector；`setTimeout(unref)` 到最近义务；flush 确认后才推进 occurrence；同 Session recurring 合并批次消息（runtime.ts:119-123）；jobs 包的后台任务 ring/通知唤醒是另一机制 |
| **HMR/热重载** | dsh-hmr：模块热替换+profile 配置热重载（reconcileProfilePatches：entry.update→await 旧 fiber→只对新失败抛错）；client-hmr 浏览器插件热替换；LlmRuntime 的代际换路（prepareCall 绑 registration 防跨代拼接） |
| **国际化** | 类型化字典（LocaleNamespaceMap 声明合并，缺键编译错误）；en/zh 内置；locale-owned UI 文案门禁 |

---

# 第 9 章 外部依赖说明

主要第三方依赖（按重要性；"替代关键实现"指替换该依赖时需要重写的核心点）：

| 依赖 | 用途 | 在哪些文件/包中使用 | 替代关键实现 |
|---|---|---|---|
| **@deepseek-ai/cordis（vendored Cordis）** | 插件框架：Context/Service/事件/fiber/Loader | 全部 dsh 包（peer 依赖）；vendor/ 内 pinned 源码 | 不可替换——整个"一切皆插件"建立其上 |
| **zod** + **@deepseek-ai/schemastery（vendored）** | 运行时校验与配置 schema | tools（参数校验）、agent-loop（Config）、session-projection（stateSchema）、typert（wire codec） | 两套并存：schemastery 朝 Cordis 配置兼容，zod 朝 JSON Schema/TS 推导 |
| **ws** | WebSocket 服务端/客户端 | api/gateway（RemoteStreamMux）、experimental/inspector | 心跳/多路逻辑流封装 |
| **node-pty** | PTY 终端 | terminal-bash（spawnTerminal） | 平台终端仿真与 OSC 标记解析 |
| **zstd（napi）** | 会话日志压缩 | session-persistence-jsonl | 帧扫描/撕裂恢复/前缀解压全自研（zstd.ts） |
| **SQLite（node）** | KV 与 FTS5 全文检索 | storage-sqlite、session-query-sqlite | SCHEMA_VERSION 单调迁移 |
| **@octokit/webhooks** | GitHub 签名验证 | webhook-github | HMAC 验签封装 |
| **@modelcontextprotocol/sdk** | MCP 客户端协议 | mcp-client、experimental 浏览器/桌面 provider | 工具桥 mcp__server__tool 自研 |
| **OpenTelemetry（API/SDK）** | 遥测通道 | telemetry/otel、session-telemetry-otel、host/product-telemetry-otel | OTLP JSON/HTTP 序列化自管（含字节预算） |
| **@agentclientprotocol/sdk** | ACP 协议 | packages/acp | — |
| **sharp** | 图片归一化 | attachment-local | 压缩限制器 |
| **ripgrep（sidecar 二进制）** | 文件搜索 | tool-fs-search、python runtime 打包 | — |
| **LibreOffice（kit）** | Office 转 PDF | office-to-pdf、desktop、python runtime | 并发/字节/DPI 限额与缓存自研 |
| **react / react-dom 19** | UI 渲染 | packages/client 全族 | 唯一绑定点 bindSnapshotSelector（uSES） |
| **zustand(vanilla)+immer** | 裸 observable 状态 | client/store | rafBatch/selector 中间件自研 |
| **electron / electron-builder / electron-updater** | 桌面壳与分发 | apps/desktop | dsh-app:// 协议、签名链、更新日志自研 |
| **vite 8** | 前端构建 | apps/web | manualChunks/Cordis Loader 浏览器化补丁自研 |
| **tsc(project refs)+tsdown** | Host/Client 双面构建 | 根 tsconfig.*.json、各包 | scripts/build.ts 编排 |
| **Commander** | CLI 解析 | apps/cli、cmdline、headless/web startup | pass-through 语法自研 |
| **vm（Node 内建）** | 动态插件/工作流脚本求值 | cordis-host-runner（evaluateHostCode）、workflow-ptc | 超时+守卫+专用 fiber 组 |
| **koffi（FFI）** | Win32 API | win32-process、sandbox-windows-acl、terminal（懒加载模式） | Job Object/DACL/原生对话框 |

---

# 第 10 章 新人上手路径

## 10.1 建议阅读顺序（由浅入深）

1. `README.md` → `docs/architecture.md`（架构总纲，必读）→ `docs/glossary.md`（术语）；
2. 入口链实读：`apps/cli/src/bin.ts` → `args.ts` → `profile-boot.ts` → `packages/boot/app-boot/src/index.ts`（boot/audit）→ `profile.ts`（profile/bundle）；
3. 组合层：`packages/bundle/base/cordis.patch.yml`（认脸 ~90 行核心行）→ `web-app/cordis.patch.yml` → 跑 `dsh --profile web --dump-config` 对照；
4. 核心数据面：`packages/core/session/src/index.ts`（append/deriveMessages）→ `types.ts`（SessionEventMap）→ `packages/session/session-persistence-jsonl`；
5. 核心驱动：`packages/core/agent-loop/src/agent.ts`（turn/step）→ `tool-calls.ts` → `packages/core/tools/src/index.ts`（执行管线）；
6. 模型面：`packages/llm/llm/src/index.ts`（prepareCall/stream）→ `llm-deepseek/src/adapter.ts`+`translate.ts`；
7. 一个完整能力缝样例：`packages/shell`（shell→bash-local→tool-bash）+ `docs/tool-execution-pipeline.md`；
8. 客户端：`packages/client/ui-slots` → `ui-renderer/src/client/bind.ts` → `ui-conversation` 契约 → `ui-chat` 一个 conversation-node；
9. 按需：subagent/continuation、compaction、api/gateway+connection（Typert RPC）、preset 机制。

## 10.2 常见修改需求的切入点

| 需求 | 切入点 |
|---|---|
| **加一个模型接口** | 新建 `packages/llm/llm-<name>` 实现 `LlmAdapter.stream`（参考 llm-pi-ai）；在 bundle patch 加行注册 `ctx.llm.registerAdapter`（docs/architecture.md:145） |
| **加一个模型工具** | 新建 `packages/<组>/tool-<name>`：`defineTool({name, description, parameters, output:{schema,render}, execute})` 注册 `ctx.tools`；工具自述 section 进 systemPrompt；**UI 卡片**另在 client 注册 `'tool.call.toolview'` keyed slot（key=工具名）；cookbook：docs/cookbook/adding-a-tool.md |
| **加一个 CLI/页面设置项** | 设置项=插件 Config 字段（schemastery/zod schema 即表单）；Client 卡片在 `packages/client/ui-settings-*` 注册 slot；新页面/面板=新 ui-* 包 |
| **加一个定时任务类能力** | 挂 `ctx.schedule`（模型工具 schedule_* 已有）；自定义周期逻辑参考 `schedule/src/runtime.ts` 的 drive 模式 |
| **改 agent 循环行为** | 优先挂事件（agent/pre-step、agent/request、tools/*、agent/turn-stopping）；**改 loop 本体必须同步更新 docs/architecture.md**（AGENTS.md:137） |
| **换执行世界（远端/沙箱）** | 实现 fs+subprocess+shell(+sandbox) 的 provider 并在 patch 中换行（参考 packages/ssh 五包） |
| **加会话持久字段** | 扩展 SessionEventMap（merge 声明合并）；新事件需考虑格式迁移链与 SESSION_FORMAT_VERSION（AGENTS.md:7,133） |
| **加子代理 provider** | 实现 `SubagentProvider`（name/capabilities/start[/prepareContinuable]）注册 `ctx.subagents` |

## 10.3 隐性约定与易踩坑点

1. **waterfall 必须调 `next()`**：返回而不委托=短路整链（AGENTS.md:135）——写 tools/pre-execute、agent/request 监听时最常见事故。
2. **注册即 effect**：一切贡献走 `ctx.effect()/ctx.on()`，registry 的 `register()` 返回 disposer；直接改全局状态会在插件卸载时泄漏。
3. **模型可见=已落日志**：任何要进模型请求的新输入必须有会话事件承载，否则破坏"日志重建一切"。
4. **seq 连续性与 call/result 配对**：手工 append 事件时 tool/call 必有 tool/result（用 ToolCallRecovery 思路）；消息事件必带 surfaceOp/sourceEventSeqs。
5. **依赖方向铁律**：扩展插件只 import Service Definition 包（dsh-agent 而非 dsh-agent-loop；dsh-fs 而非 dsh-fs-local）——CI 有包依赖门禁。
6. **ESM-only + .ts 后缀相对导入**：跨包用包名、本地导入带 `.ts`；dsh 源码启动走 tsx ESM hook，模块不能是 CJS-only。
7. **Host/Client 双编译面**：包同时含两端代码时用 face 专属叶子 tsconfig；`dsh.client` 字段声明浏览器注入。
8. **fail-closed 默认**：审批无应答=deny；沙箱不可用=拒绝执行；远端 helper 摘要不符=拒绝。
9. **snapshot 测试是行为契约**：模型/用户可见变更必须更新 keyless 快照（AGENTS.md:155-158）；测试描述行为而非正确性。
10. **Windows 注意**：subprocess 用 Job Object、沙箱用 ACL（partial 语义）、flock 无对应物用既有锁；`check:windows-wine` 仅诊断已知失败时用。
11. **只经 `dsh` profile 启动应用**：包 bin/直挂插件树都被 `verify-application-entrypoints` 拒绝（AGENTS.md:13）。
12. **文档随代码走**：README/JSDoc/双语/目录生成物（module-graph、config-catalog 等）有同步门禁（`pnpm run doc-sync`）。

---

# 收尾：报告总目录与自检

## A. 全报告总目录（章节 ↔ 批次对照）

| 章节 | 内容 | 所在批次（本文档内位置） |
|---|---|---|
| 读者须知/术语表/批次计划 | — | 批次 1（文档头部） |
| 第 1 章 项目概述 | §1 | 批次 1 |
| 第 2 章 整体架构 | §2 | 批次 1 |
| 第 3 章 目录结构详解 | §3 | 批次 1 |
| 第 4.1~4.2 节 基础层/数据与模型面 | §4.1-4.2 | 批次 2-3 |
| 第 4.3 节 核心驱动与工具 IO 面 | §4.3 | 批次 4 |
| 第 4.4 节 编排与扩展 | §4.4 | 批次 5 |
| 第 4.5~4.9 节 宿主/API/组合入口/客户端/桌面/实验区 | §4.5-4.9 | 批次 6 |
| 第 5 章 文件清单总表（附录 A 完整清单） | 附录 A | 批次 1（清单层） |
| 第 6 章 关键函数深度解析 | §6 | 批次 7 |
| 第 7 章 端到端调用链 | §7 | 批次 7 |
| 第 8 章 横切机制 | §8 | 批次 7 |
| 第 9 章 外部依赖 | §9 | 批次 7 |
| 第 10 章 新人上手路径 | §10 | 批次 7 |

## B. 完成度自检表

| 检查项 | 结果 |
|---|---|
| 生产源文件清单完整性 | ✅ 附录 A 覆盖 2,787 个文件（脚本全量扫描，剔除规则见 §5 排除说明）；包级职责覆盖全部 324 个清单节（其中 318 个有人工职责映射，标注 ◆ 的极少数为命名推断） |
| 全部 53 个包组逐一分析 | ✅ §3.3 + §4.1-4.9 |
| 核心链路函数级深解 | ✅ 入口/装配/turn/step/append/prepareCall/压缩区间 六段带代码逐段解读（§6）+ 十函数速查表 |
| 端到端调用链交叉验证 | ✅ 启动链与主链路均经人工实读核验（bin.ts/profile-boot.ts/agent-loop index.ts+agent.ts 全文节选）与六路并行源码勘察互证 |
| 排除范围遵守 | ✅ 未分析 vendor/、test-support、tests、docs 正文、website、.agents、benchmarks、CI 配置 |
| 与实际代码一致 | ✅ 所有关键结论附 文件:行号；引用代码为实读摘录 |

**覆盖深度分级说明**（因规模产生的、已在读者须知声明的取舍）：`packages/client`（60 UI 包）与 `packages/experimental`（24 实验包）以"包"为深挖单元（职责+核心机制+代表文件行号），包内全部文件的逐文件职责由附录 A 清单+导出符号承载；其余 ~140 个包均有第 4 章的函数级分析。

## C. 存疑与待确认清单（分析中标注的推断项）

1. **（推断）** `packages/preset/agent-preset` 的包名 `@local/my-decoration`（packages.md 第 207 行）判断为 cordis 插件开发 SKILL 的示例/模板包而非产品包——依据是其 3 个文件/57 行的体量与 `packages/preset/agent-preset/skills/` 模板目录并存；未见文档明说。
2. **（推断）** base bundle 默认模型 `deepseek-official/deepseek-flash`（宿主核心勘察引 base cordis.patch.yml:82-87）与 Python SDK 默认 `deepseek-v4-flash`（api.py:22-23）不一致——推断为不同表面的默认值演进未同步，或 flash 即 v4-flash 的别名；未从代码确证。
3. **（推断）** `scripts/` 中约 250 个 verify-*/gen-* 脚本归类为"CI 门禁/生成器、不改变日常构建产物语义"——依据命名与 package.json scripts 挂载方式归纳，未逐个展开核实。
4. **（推断）** 附录 A 中"导出概要/主要依赖"由正则静态提取，对非标准导出写法（如 re-export、动态导出）可能不完整；行数为物理行数（含注释与空行）。
5. **（存疑）** `native/system` 的 `flock` addon 在 Windows 无对应物（README:31 用"Harness 既有锁实现"）——Windows 下 atomic-write 的跨进程锁具体退化行为未深挖。
6. **（存疑）** agent-team、webworker-runtime、inspector 等实验包的内部实现只做了架构级概览（体量所限）；其包内文件级细节请以附录 A 清单为索引入口。
7. **（事实说明）** 探索时发现根目录存在 `tsdown.worker.ts`、`packages/client/tsdown.client.ts` 等构建辅助源文件，已纳入清单并在 §5 说明；它们属于"构建脚本中影响代码行为的部分"的边界情形，按纳入处理。


---

# 附录 A：全部生产源文件完整清单（第 5 章正文所引）

> 生成方式：脚本静态扫描 + 导出符号/依赖正则提取（详见第 5 章正文说明）。共 **2,787 个文件 / 474,243 行 / 324 个包**。表中"导出概要"最多列 8 项导出符号；"主要依赖"为该文件 import 的包名（最多列 5 项，跨包相对导入不计）。



#### apps/cli — @deepseek-ai/dsh@0.2.1-alpha.1（10 文件 / 1083 行）

职责：`dsh` 命令行入口：profile/plugin/dump-config 四模式分发与 runProfile 装配管道


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| apps/cli/config/examples/github-review/github-ready-review-rule.mjs | 66 | apply, name, inject, Config | @deepseek-ai/schemastery, @deepseek-ai/dsh-webhook |
| apps/cli/src/args.ts | 213 | parseDshArgs, DshInvocation | commander |
| apps/cli/src/bin.ts | 79 | runCli, RunCliOptions | @deepseek-ai/dsh-app-boot, @deepseek-ai/dsh-home-paths |
| apps/cli/src/dump-config-schema.ts | 49 | runDumpConfigSchema | @deepseek-ai/dsh-app-boot |
| apps/cli/src/dump-config.ts | 77 | runDumpConfig, collectConfigDumpLayers | node:fs, node:path, @deepseek-ai/dsh-app-boot |
| apps/cli/src/plugin.ts | 108 | runPlugin | @deepseek-ai/dsh-plugin-manager, @deepseek-ai/dsh-app-boot, @deepseek-ai/dsh-atomic-write, node:fs, node:path |
| apps/cli/src/process-shutdown.ts | 78 | createProcessShutdown, PROCESS_SHUTDOWN_TIMEOUT_MS, ProcessShutdown | — |
| apps/cli/src/profile-boot.ts | 327 | homePatchPath, initializeProfileFromDefault, prepareProfile, runProfile, INSTALL_ANCHOR, PROFILE_ROOT_FILENAME, ResolvedProfileRuntime, RunProfileOptions | node:fs, node:path, node:url, @deepseek-ai/cordis, @deepseek-ai/cordis-plugin-include |
| apps/cli/src/startup-diagnostics.ts | 69 | reportStartupFailure | node:crypto, node:fs, node:path, node:util, @deepseek-ai/dsh-app-boot |
| apps/cli/tsdown.config.ts | 17 | defineConfig | tsdown |

#### apps/desktop — @deepseek-ai/dsh-desktop@0.2.1-alpha.1（158 文件 / 17397 行）

职责：Electron 桌面壳：窗口/`dsh-app://` 协议/更新/托盘/签名打包；主进程代持 Host 凭证


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| apps/desktop/electron-builder.config.mjs | 6 | createElectronBuilderConfig | — |
| apps/desktop/renderer/mandatory-update-frame.js | 43 | — | — |
| apps/desktop/renderer/mandatory-update.js | 115 | — | — |
| apps/desktop/renderer/update-dialog.js | 58 | — | — |
| apps/desktop/scripts/build-installed-update-worker.mjs | 30 | — | node:fs, node:path, electron-builder |
| apps/desktop/scripts/cos-operation.ts | 45 | cosOperation | node:http, node:https, cos-nodejs-sdk-v5 |
| apps/desktop/scripts/desktop-auto-update-environment.mjs | 177 | resolveDesktopAutoUpdateEnvironment, resolveDesktopAutoUpdateTarget, desktopBuildRecordFilename, desktopUpdateMetadataFilename, resolveDesktopAutoUpdateConfig, resolveDesktopUploadConfig, DESKTOP_AUTO_UPDATE_ENV | semver |
| apps/desktop/scripts/desktop-build-commit.mjs | 58 | readDesktopBuildCommit, resolveDesktopBuildCommit, desktopBuildCommitEnvironment, DESKTOP_BUILD_COMMIT_ENV, DESKTOP_BUILD_DIRTY_ENV | node:child_process |
| apps/desktop/scripts/desktop-build-paths.mjs | 108 | resolveDesktopBuildTarget, desktopTargetBuildPaths, desktopTargetPlatform, resolveDesktopTargetBuildPaths, developmentRuntimeDirectory | node:path |
| apps/desktop/scripts/desktop-build-version-discovery.ts | 157 | desktopBuildDateSegment, suggestDesktopBuildVersion, DesktopBuildVersionSuggestionOptions | node:fs, semver |
| apps/desktop/scripts/desktop-build-version.mjs | 101 | validateDesktopBuildVersion, resolveDesktopBuildVersion, desktopBuildVersionPrefix, DESKTOP_BUILD_VERSION_ENV | semver |
| apps/desktop/scripts/desktop-bundle-imports.mjs | 91 | importPackageName, isBareSpecifier, unpackagedImports, packagedImportsPlugin | node:module, node:path, tsdown |
| apps/desktop/scripts/desktop-cos.ts | 55 | createDesktopCos, DESKTOP_COS_REGION, DesktopCosCredentials | cos-nodejs-sdk-v5 |
| apps/desktop/scripts/desktop-package-environment.mjs | 114 | loadDesktopPackageEnvironment, validateDesktopPackageEnvironment | node:fs, node:path, node:url, node:util |
| apps/desktop/scripts/desktop-policy-environment.mjs | 45 | resolveDesktopPolicyEnvironment | — |
| apps/desktop/scripts/desktop-release-environment.mjs | 122 | resolveNpmRegistry, resolveDesktopAppId, resolveMacOSSigningEnvironment, resolveMacOSNotarizationEnvironment, DESKTOP_APP_ID_ENV, MACOS_SIGNING_IDENTITY_ENV, MACOS_TEAM_ID_ENV, NPM_REGISTRY_ENV | — |
| apps/desktop/scripts/desktop-release-tag.ts | 81 | desktopReleaseTag, tagDesktopRelease, DesktopReleaseTagResult | node:child_process |
| apps/desktop/scripts/desktop-toolchain-preflight.ts | 103 | probeDesktopToolchain, requireDesktopToolchain, DesktopToolchainProbeFailure | node:child_process, node:fs, node:os, node:path, node:util |
| apps/desktop/scripts/desktop-upload-plan.ts | 296 | createDesktopUploadPlan, DesktopUploadArtifact, DesktopUploadPlan, DesktopUploadPlanOptions | node:crypto, node:fs, node:path, js-yaml, semver |
| apps/desktop/scripts/desktop-upload-run.ts | 127 | uploadDesktopRelease | node:crypto, node:fs, node:path, node:stream, cos-nodejs-sdk-v5 |
| apps/desktop/scripts/dev.ts | 131 | — | node:child_process, node:fs, node:module, node:path, node:util |
| apps/desktop/scripts/development-app.ts | 85 | prepareDevelopmentApp, developmentLauncher, DevelopmentAppOptions | node:child_process, node:crypto, node:fs, node:path |
| apps/desktop/scripts/development-project.ts | 170 | prepareDevelopmentProject, DevelopmentProjectOptions | node:fs, node:path |
| apps/desktop/scripts/electron-builder-config.mjs | 252 | createElectronBuilderConfig | node:crypto, node:fs, node:path, node:url, node:child_process |
| apps/desktop/scripts/flock-entry.ts | 95 | createFlockEntryLoader, loadFlockEntry, FlockEntryLoaderSteps | node:child_process, node:events, node:fs, node:module, node:path |
| apps/desktop/scripts/installed-update-builder.ts | 40 | createInstalledUpdateBuilderConfig | node:path |
| apps/desktop/scripts/installed-update-cos.ts | 113 | createInstalledUpdateCos | node:fs, node:crypto, node:stream |
| apps/desktop/scripts/installed-update-distribution.ts | 75 | planInstalledUpdateDistribution, InstalledUpdateBinary, InstalledUpdateDistribution | node:crypto, node:fs, node:path, js-yaml |
| apps/desktop/scripts/installed-update-identity.mjs | 28 | configureInstalledUpdateIdentity | node:fs, node:path |
| apps/desktop/scripts/installed-update-package-content.ts | 126 | verifyInstalledUpdatePackageContent | node:crypto, node:fs, node:module, node:path, js-yaml |
| apps/desktop/scripts/installed-update-packaging.ts | 123 | assertInstalledUpdateSigningClear, installedUpdatePackagingEnvironment, packageInstalledUpdate, InstalledUpdateSigningHoldError | node:crypto, node:child_process, node:fs, node:os, node:path |
| apps/desktop/scripts/installed-update-publication.ts | 218 | verifiedInstalledUpdateDistribution, executeInstalledUpdatePublication, InstalledUpdateRemoteObject, InstalledUpdatePublicationStore, InstalledUpdatePublicationAction | node:fs, node:path |
| apps/desktop/scripts/installed-update-qualification.ts | 279 | createInstalledUpdateRun, readInstalledUpdateRun, inspectInstalledUpdateJournals, collectInstalledUpdateJournals, InstalledUpdateSource, InstalledUpdateRun, InstalledUpdateObservation, InstalledUpdateEvidence | node:crypto, node:fs, node:path, semver |
| apps/desktop/scripts/installed-update-signature.mjs | 78 | installedUpdateFileHash, verifyInstalledUpdateSignature | node:child_process, node:crypto, node:fs, node:module, node:path |
| apps/desktop/scripts/logged-notarytool.mjs | 84 | runLoggedNotarytool | node:child_process, node:path, node:url, node:util |
| apps/desktop/scripts/macos-app-update-config.mjs | 92 | resolveMacOSAppUpdateFeed, createMacOSAppUpdateConfig, writeMacOSAppUpdateConfig, verifyMacOSAppUpdateConfig | node:fs, node:path, js-yaml |
| apps/desktop/scripts/macos-cache-policy.ts | 62 | macOSCachePolicy | node:child_process, node:crypto, node:fs, node:os, node:path |
| apps/desktop/scripts/macos-notarization-proxy.ts | 224 | restoreMacOSNotarizationProxy, withMacOSNotarizationProxy | node:child_process, node:fs, node:net, node:os, node:path |
| apps/desktop/scripts/macos-package-settings.mjs | 48 | resolveMacOSPackageSettings, macOSDownloadEnvironment | — |
| apps/desktop/scripts/macos-runtime.ts | 70 | signMacOSRuntime | node:crypto, node:fs, node:path |
| apps/desktop/scripts/macos-signature-cache.ts | 122 | cachedMacOSSignature, pruneMacOSSignatureCache, MacOSCachedSigner | node:crypto, node:fs, node:path |
| apps/desktop/scripts/macos-signing-keychain.mjs | 86 | withMacOSSigningKeychain | node:child_process, node:crypto, node:fs, node:os, node:path |
| apps/desktop/scripts/manage-windows-signature-cache.mjs | 29 | — | node:util |
| apps/desktop/scripts/notarize-macos-disk-images.mjs | 31 | notarizeMacOSDiskImageArtifact | node:fs |
| apps/desktop/scripts/notarize-macos.mjs | 16 | notarizeMacOS | node:url, @electron/notarize |
| apps/desktop/scripts/package-installed-update.ts | 31 | — | node:readline, node:process |
| apps/desktop/scripts/package-macos.ts | 136 | packageMacOSArtifacts, DesktopPrepackagedArtifact, MacOSArtifactRequest, MacOSArtifactOperations | node:child_process, node:fs, node:path, node:util |
| apps/desktop/scripts/package-target.ts | 504 | withoutWindowsSigningEnvironment, desktopElectronBuilderEnvironment, withoutDesktopUploadCredentials, resolveDesktopPackageTarget, parseDesktopPackageInvocation, desktopElectronBuilderArguments, packageTarget, DesktopPackageTargetName …等9项 | node:child_process, node:fs, node:util, node:path |
| apps/desktop/scripts/packaging-run.mjs | 181 | recordPackagingEvent, failPackagingRun, packagingOutputRedactor, createPackagingRun | node:crypto, node:child_process, node:fs, node:path, node:string_decoder |
| apps/desktop/scripts/packaging-step.mjs | 50 | packagingStep, packagingErrorDetails | node:crypto |
| apps/desktop/scripts/prepare-cli.ts | 18 | prepareDesktopCli | node:fs, node:path |
| apps/desktop/scripts/prepare-command-link.ts | 22 | prepareCommandLink | node:child_process, node:fs, node:path |
| apps/desktop/scripts/prepare-dsh.ts | 184 | — | node:child_process, node:fs, node:os, node:path |
| apps/desktop/scripts/prepare-installed-update-application.ts | 95 | prepareInstalledUpdateApplication, verifyInstalledUpdateApplication | node:crypto, node:fs, node:path |
| apps/desktop/scripts/prepare-installed-update-bootstrap.ts | 30 | prepareInstalledUpdateBootstrap | node:fs, node:path, electron |
| apps/desktop/scripts/prepare-installed-update-network.ts | 63 | prepareInstalledUpdateNetwork | node:fs, node:path |
| apps/desktop/scripts/prepare-installed-update-runtime.ts | 72 | prepareInstalledUpdateRuntime | node:crypto, node:fs, node:path |
| apps/desktop/scripts/prepare-installed-update.ts | 61 | — | node:child_process, node:fs, node:path |
| apps/desktop/scripts/prepare-package-set.ts | 179 | selectDesktopPackageClosure, assertDesktopHostPackageFiles, prepareDesktopPackageSet, PackedDesktopPackage | node:crypto, node:fs, node:path, node:util, js-yaml |
| apps/desktop/scripts/prepare-primary-runtime.ts | 36 | preparePrimaryRuntime, smokePrimaryRuntime | node:fs, node:path |
| apps/desktop/scripts/prepare-runtime-manifests.ts | 27 | prepareRuntimeManifests | node:fs, node:path, node:module |
| apps/desktop/scripts/prepare-runtime.ts | 68 | — | node:child_process, node:fs, node:module, node:path, node:util |
| apps/desktop/scripts/publish-installed-update.ts | 41 | — | node:util, node:readline, node:process |
| apps/desktop/scripts/render-tray-icon.ts | 124 | packIco, unpackIco, renderTrayIconEntries, TRAY_ICON_SIZES, TRAY_ICON_PATHS, IcoEntry | node:fs, node:path, node:url, sharp |
| apps/desktop/scripts/runtime-file-policy.ts | 45 | desktopRuntimeFileExclusion | — |
| apps/desktop/scripts/sign-primary-runtime.ts | 97 | signWindowsPrimaryRuntime, signWindowsDesktopRuntime | node:crypto, node:fs, node:path |
| apps/desktop/scripts/smoke-packaged-runtime.ts | 24 | — | node:path, node:util |
| apps/desktop/scripts/smoke-prepared-runtime.ts | 41 | smokePreparedRuntime | node:child_process, node:fs, node:os, node:path, node:util |
| apps/desktop/scripts/smoke-runtime.ts | 140 | smokeDesktopRuntime, apply | node:fs, node:os, node:path, node:child_process, node:util |
| apps/desktop/scripts/test-host-updates.ts | 55 | — | node:child_process, node:fs, node:path, node:url |
| apps/desktop/scripts/test-local-updater.mjs | 39 | — | node:child_process, node:fs, node:os, node:path, node:url |
| apps/desktop/scripts/test-signed-updates.mjs | 73 | — | node:assert, node:child_process, node:fs, node:path, node:url |
| apps/desktop/scripts/test-windows-installer.mjs | 126 | — | node:child_process, node:crypto, node:fs, node:module, node:path |
| apps/desktop/scripts/test-windows-update-signature.mjs | 81 | — | node:assert, node:crypto, node:fs, node:module, node:path |
| apps/desktop/scripts/test-workspace-updates.ts | 82 | — | node:child_process, node:crypto, node:fs, node:module, node:path |
| apps/desktop/scripts/upload-target.ts | 130 | resolveCredentialUploadEnvironment, uploadDesktopTarget | node:path, node:util |
| apps/desktop/scripts/verify-installed-update-package.ts | 126 | validateInstalledUpdateArchivePaths, verifyInstalledUpdatePackage | node:child_process, node:fs, node:path, node:util |
| apps/desktop/scripts/verify-macos-signature.mjs | 205 | assertMacOSSignatureDetails, assertMacOSRuntimeSignatureDetails, signMacOSRuntimeCode, verifyMacOSRuntimeCode, verifyMacOSSignature, verifyMacOSNotarizedApplication, verifyMacOSDiskImage, verifyMacOSSignatureAfterSign | node:child_process, node:path |
| apps/desktop/scripts/verify-runtime-archive.ts | 54 | verifyRuntimeArchive | node:crypto, node:fs, node:path, app-builder-lib |
| apps/desktop/scripts/windows-asar-unpack.mjs | 71 | prepareWindowsAsarUnpack, verifyWindowsAsarUnpack | node:fs, node:path, app-builder-lib |
| apps/desktop/scripts/windows-directory-installer.mjs | 99 | directoryInstallSection, directoryInstallerExits, installWindowsDirectoryInstaller, directoryUninstaller | node:fs, node:module, node:path, app-builder-lib |
| apps/desktop/scripts/windows-package-settings.mjs | 15 | resolveWindowsPackageSettings | — |
| apps/desktop/scripts/windows-runtime-signature.mjs | 166 | inspectWindowsRuntimeSignature, preserveWindowsRuntimeSignature, windowsRuntimeCode, signWindowsCode, verifyWindowsCode | node:child_process, node:fs, node:path, node:util |
| apps/desktop/scripts/windows-sign.mjs | 327 | scrubWindowsSigningEnvironment, resolveWindowsUpdatePublisher, createRedactedWindowsSigningError, buildWindowsSigningEnvironment, createWindowsTokenSigner, repairDanglingAuthenticodeDirectory, installWindowsNsisBootstrapSigner | node:child_process, node:crypto, node:fs, node:path, node:url |
| apps/desktop/scripts/windows-signature-batch.mjs | 58 | parseSignatureRows, inspectSignaturesBatched | node:child_process, node:util |
| apps/desktop/scripts/windows-signature-cache-directory.mjs | 39 | resolveWindowsSignatureCacheDirectory, prepareWindowsSignatureCacheDirectory | node:child_process, node:os, node:fs, node:path, node:util |
| apps/desktop/scripts/windows-signature-cache.mjs | 221 | signatureCacheIdentity, migrateSignatureCache, maintainSignatureCache, createCachedSigner | node:crypto, node:fs, node:path |
| apps/desktop/scripts/windows-signing-preflight.ts | 99 | preflightWindowsSigning | node:child_process, node:crypto, node:fs, node:os, node:path |
| apps/desktop/scripts/windows-signing-stage.mjs | 63 | withWindowsSigningStage | node:fs, node:os, node:path, node:timers, koffi |
| apps/desktop/scripts/windows-signing-state.mjs | 50 | beginWindowsSigningAttempt | node:fs, node:os, node:path, node:crypto |
| apps/desktop/scripts/windows-timestamp.mjs | 108 | normalizeWindowsSignature, completeWindowsSignature | node:crypto, node:child_process, node:util, node:fs, node:path |
| apps/desktop/src/account-backend.ts | 135 | accountView, desktopAccountBackend, AccountInvoke, DesktopAccountBackend | node:crypto, ws, @deepseek-ai/dsh-api-gateway, @deepseek-ai/dsh-deepseek-account |
| apps/desktop/src/backend-controller.ts | 158 | DesktopBackendController, DesktopBackendState, DesktopBackendHost | — |
| apps/desktop/src/background-notice.ts | 57 | DesktopBackgroundNotice, DesktopBackgroundNoticeOptions | node:fs, node:path, electron |
| apps/desktop/src/browser-guests.ts | 171 | DesktopBrowserGuests | node:crypto, electron, @deepseek-ai/dsh-client-ui-sidebar-browser |
| apps/desktop/src/client-metadata.ts | 30 | desktopClientVersion, desktopClientMetadata | @deepseek-ai/dsh-deepseek-account |
| apps/desktop/src/client/welcome.tsx | 26 | — | @deepseek-ai/dsh-client-ui-theme, react-dom |
| apps/desktop/src/client/WelcomePage.tsx | 226 | Welcome | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-deepseek-account |
| apps/desktop/src/command-installation.ts | 269 | inspectFileCommand, installFileCommand, removeFileCommand, CommandInstallationError, FileCommandInstallation, CommandInspection | node:crypto, node:child_process, node:fs, node:path, node:util |
| apps/desktop/src/command-management.ts | 240 | presentCommandManagement, DesktopCommandManager, CommandPresentation, CommandManagerOptions | node:child_process, node:path, node:os, node:util, electron |
| apps/desktop/src/command-manager-entry.ts | 47 | — | node:child_process, node:path, node:url |
| apps/desktop/src/core-package-set.ts | 184 | parseDesktopCorePackageSet, readDesktopCorePackageSet, desktopCorePackageSpec, desktopCorePackageOverrides, desktopDshPackageSpec, verifyDesktopCorePackageSet, verifyDesktopCoreLockfile, DESKTOP_PACKAGE_SET_FILE …等13项 | node:crypto, node:fs, node:path |
| apps/desktop/src/crash-report.ts | 185 | crashReportFileName, renderCrashReport, writeCrashReport, pruneCrashReports, RendererConsoleTail, CRASH_REPORT_PREFIX, CRASH_REPORTS_RETAINED, RENDERER_CONSOLE_MAX_BYTES …等13项 | node:fs, node:path, node:util |
| apps/desktop/src/device-info.ts | 35 | readDeviceInfo | node:os |
| apps/desktop/src/directory-picker.ts | 31 | installDesktopDirectoryPicker | electron |
| apps/desktop/src/duration-env.ts | 17 | resolveDurationMs | — |
| apps/desktop/src/fatal-recovery.ts | 121 | DesktopFatalRecovery, CRASH_REPORT_WAIT_MS | electron |
| apps/desktop/src/host-process.ts | 323 | DesktopHostUncleanExitError, DesktopHostFatalError, DesktopHostProcess, QUIT_INSPECTION_DEADLINE_MS, DesktopQuitInspection, DesktopHostReady | node:child_process, node:path, @deepseek-ai/dsh-deepseek-account |
| apps/desktop/src/host-protocol.ts | 5 | DESKTOP_HOST_PROTOCOL_VERSION | — |
| apps/desktop/src/ipc.ts | 105 | assertDesktopSender, DESKTOP_IPC, SCHEME, DesktopUpdatePreparationFailureKind, DesktopUpdateState, DesktopUpdateFailureKind, DesktopUpdatePresentation, DshDesktopProductApi | @deepseek-ai/dsh-client-shortcuts, electron, @deepseek-ai/dsh-client-ui-sidebar-browser |
| apps/desktop/src/keybindings.ts | 28 | desktopKeybindings | node:fs, node:path, @deepseek-ai/dsh-atomic-write, @deepseek-ai/dsh-client-shortcuts |
| apps/desktop/src/keyboard.ts | 262 | installDesktopShortcuts | electron, @deepseek-ai/dsh-client-shortcuts, @deepseek-ai/dsh-client-ui-sidebar-browser |
| apps/desktop/src/locale.ts | 396 | resolveDesktopLocale, resolveDesktopStartupLocale, formatDesktopMessage, desktopUpdateReadyConfirmation, en, zh, DesktopMessages, DesktopLocale | — |
| apps/desktop/src/login-shell-environment.ts | 186 | resolveDesktopLoginShellConfig, loginShellCandidates, parseLoginShellOutput, mergeLoginShellEnvironment, readDesktopLoginShellEnvironment, DesktopLoginShellConfig, DesktopLoginShellFailure, DesktopLoginShellResult …等9项 | node:child_process, node:os, node:stream |
| apps/desktop/src/main.ts | 1350 | — | @deepseek-ai/dsh-client-product-analytics, node:fs, node:path, node:url, electron |
| apps/desktop/src/mandatory-update-ipc.ts | 5 | MANDATORY_IPC | — |
| apps/desktop/src/mandatory-update-policy.ts | 235 | resolveDesktopPolicyConfig, desktopPolicyPage, DesktopMandatoryUpdatePolicy, DesktopPolicyIdentity, DesktopPolicyConfig, DesktopPolicyState | semver, @deepseek-ai/dsh-deepseek-account |
| apps/desktop/src/mandatory-update-window.ts | 313 | DesktopMandatoryUpdateWindow, MandatoryUpdateAction, MandatoryUpdateView, MandatoryUpdateApi, MandatoryUpdateWindowOptions | electron |
| apps/desktop/src/microphone-permissions.ts | 32 | installMicrophonePermissions | electron |
| apps/desktop/src/node-environment.ts | 19 | desktopNodeEnvironment | node:path |
| apps/desktop/src/owned-directory.ts | 27 | removeOwnedDirectory | node:fs, node:path |
| apps/desktop/src/paths.ts | 23 | resolveDesktopPaths, DesktopPaths | node:path, @deepseek-ai/dsh-home-paths |
| apps/desktop/src/platform-ipc.ts | 13 | PLATFORM_IPC, PlatformLocale | — |
| apps/desktop/src/platform-view.ts | 269 | platformBounds, DesktopPlatformView, PlatformBounds | node:events, node:crypto, electron, @deepseek-ai/dsh-deepseek-account |
| apps/desktop/src/policy-test-auth.ts | 160 | DesktopPolicyTestAuth, DesktopPolicyLoginResult | node:crypto, electron |
| apps/desktop/src/preload-app.ts | 108 | — | @deepseek-ai/dsh-client-shortcuts, electron |
| apps/desktop/src/preload-browser.ts | 33 | createDesktopBrowserBridge | electron, @deepseek-ai/dsh-client-ui-sidebar-browser |
| apps/desktop/src/preload-mandatory-overlay.ts | 86 | installMandatoryUpdateOverlay | electron |
| apps/desktop/src/preload-mandatory.ts | 17 | — | electron |
| apps/desktop/src/preload-menu.ts | 114 | installWindowsMenu | electron |
| apps/desktop/src/preload-platform-account.ts | 46 | — | electron |
| apps/desktop/src/preload-platform.ts | 34 | markDocumentPlatform, syncWindowFullscreen | electron |
| apps/desktop/src/preload-theme.ts | 35 | syncNativeTheme | electron |
| apps/desktop/src/preload-update-dialog.ts | 15 | — | electron |
| apps/desktop/src/preload-welcome.ts | 30 | — | @deepseek-ai/dsh-deepseek-account, electron |
| apps/desktop/src/preload-windows.ts | 63 | syncWindowsAppearance | electron |
| apps/desktop/src/project-manager.ts | 177 | createRuntimeProjectMetadata, createDevelopmentProjectMetadata, createPluginProfile, DesktopProjectManager | node:fs, node:path, @deepseek-ai/dsh-app-boot |
| apps/desktop/src/quit-confirmation.ts | 97 | resolveDesktopQuitPrompt, DesktopQuitConfirmation, DesktopQuitPrompt, DesktopQuitConfirmationOptions | electron |
| apps/desktop/src/release.ts | 36 | parseDesktopRelease, DesktopRelease | semver |
| apps/desktop/src/runtime-tree.ts | 215 | runtimePath, inventoryDesktopRuntime, writeDesktopRuntime, readDesktopRuntime, verifyDesktopRuntime, DESKTOP_RUNTIME_FILE, DesktopSharedPackage, DesktopRuntimeFile …等9项 | node:crypto, node:fs, node:path, node:util, semver |
| apps/desktop/src/single-instance.ts | 27 | claimDesktopSingleInstance, DesktopSingleInstanceApplication | — |
| apps/desktop/src/startup-error.ts | 14 | desktopErrorState | — |
| apps/desktop/src/tray.ts | 49 | DesktopTray, DesktopTrayOptions | electron |
| apps/desktop/src/update-attention.ts | 75 | DesktopUpdateAttention | electron |
| apps/desktop/src/update-coordinator.ts | 197 | DesktopUpdateCoordinator | node:fs, node:path, electron, electron-updater, semver |
| apps/desktop/src/update-dialog.ts | 150 | DesktopUpdateDialog, UPDATE_DIALOG_IPC, UpdateDialogView, UpdateDialogOptions, UpdateDialogApi | electron |
| apps/desktop/src/update-error.ts | 13 | DesktopUpdatePreparationError | — |
| apps/desktop/src/update-http-executor.ts | 54 | DesktopUpdateHttpExecutor | electron-updater, electron |
| apps/desktop/src/update-journal.ts | 75 | desktopUpdateJournalState, DesktopUpdateJournal, DesktopUpdateJournalAction | node:crypto, node:fs, node:path |
| apps/desktop/src/update-overlay.ts | 64 | DesktopUpdateOverlays | electron |
| apps/desktop/src/update-presentation.ts | 52 | desktopUpdateErrorSummary, presentDesktopUpdate | — |
| apps/desktop/src/update-schedule.ts | 106 | resolveDesktopUpdateScheduleConfig, DesktopUpdateSchedule, DesktopUpdateScheduleConfig | — |
| apps/desktop/src/web-document.ts | 94 | serveWebDocument, authenticateWebHost, forwardWebRequest | node:fs, node:path |
| apps/desktop/src/welcome-api.ts | 76 | needsWelcome, WELCOME_IPC, WelcomeSaveResult, WelcomeNotice, WelcomeOperations, WelcomeApi, WelcomeAuthentication | @deepseek-ai/dsh-deepseek-account, @deepseek-ai/dsh-client-product-analytics |
| apps/desktop/src/welcome-backend.ts | 151 | connectDesktopWelcome, WelcomeState, DesktopWelcomeBackend | @deepseek-ai/dsh-client-product-analytics, node:crypto |
| apps/desktop/src/welcome-window.ts | 133 | welcomeWindowOptions, openWelcomeWindow | @deepseek-ai/dsh-deepseek-account, node:path, node:url, electron |
| apps/desktop/src/windows-layout.ts | 5 | WINDOWS_TITLEBAR_HEIGHT | — |
| apps/desktop/tsdown.config.ts | 108 | defineConfig | tsdown, vite, node:url, node:fs |

#### apps/desktop-host — @deepseek-ai/dsh-desktop-host@0.2.1-alpha.1（9 文件 / 427 行）

职责：Electron 以 Node 模式拉起的私有 dsh Web Host：复用 runProfile，IPC 回传 authenticatedUrl


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| apps/desktop-host/src/cli.ts | 37 | runDesktopCli | node:path, @deepseek-ai/dsh |
| apps/desktop-host/src/index.ts | 123 | — | node:path, node:util, @deepseek-ai/dsh-app-boot, @deepseek-ai/dsh, @deepseek-ai/dsh-client-connection |
| apps/desktop-host/src/office-engine.ts | 49 | runtimeArchivePath, installOfficeEngineResolution | node:module, node:fs, node:path, node:url |
| apps/desktop-host/src/office.ts | 39 | apply, name, Config | node:fs, node:path, node:url, @deepseek-ai/cordis, @deepseek-ai/dsh-skill-office |
| apps/desktop-host/src/platform-session.ts | 37 | installPlatformSessionPublisher | @deepseek-ai/cordis, @deepseek-ai/dsh-deepseek-account |
| apps/desktop-host/src/quit-inspection.ts | 41 | installDesktopQuitInspection, DesktopQuitInspection | @deepseek-ai/cordis, @deepseek-ai/dsh-workspace, @deepseek-ai/dsh-schedule |
| apps/desktop-host/src/update-tasks.ts | 63 | hasDesktopActiveTasks, installDesktopUpdateTaskControl | @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-jobs, @deepseek-ai/dsh-client-connection |
| apps/desktop-host/src/windows-cli-signals.ts | 24 | installWindowsCliSignals | koffi |
| apps/desktop-host/tsdown.config.ts | 14 | defineConfig | tsdown |

#### apps/web — @deepseek-ai/dsh-web-frontend@0.2.1-alpha.1（6 文件 / 672 行）

职责：Vite 构建壳：产出浏览器 dist（含 desktop 场景 IPC 握手与 WebWorker 预览入口）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| apps/web/product-isolation.ts | 106 | browserDependencyAnalysis, productWebBundleIsolation | vite |
| apps/web/src/main.ts | 41 | — | @deepseek-ai/dsh-client-ui-theme, @deepseek-ai/dsh-client-web |
| apps/web/src/node-module-stub.ts | 13 | createRequire, LoadHookContext | — |
| apps/web/src/preview.ts | 15 | — | @deepseek-ai/dsh-experimental-webworker-runtime |
| apps/web/stress-tests/reasoning-chunks.stress.ts | 236 | — | playwright, vitest, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-agent-default-model |
| apps/web/vite.config.ts | 261 | defineConfig | node:fs, node:path, node:url, vite, @vitejs/plugin-react |

#### native/system — @deepseek-ai/node-addon-system-workspace@0.1.2（14 文件 / 1154 行）

职责：node-addon-system workspace：构建编排（musl-gcc/cc 直调）与平台 prebuild 分发


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| native/system/scripts/assemble-prebuilds.mjs | 55 | — | node:fs, node:path |
| native/system/scripts/build-test-oracle.mjs | 24 | — | node:fs, node:path, node:url, node:child_process |
| native/system/scripts/build.ts | 93 | — | node:child_process, node:fs, node:path, node:util |
| native/system/scripts/bump-release.mjs | 92 | — | node:fs, node:path, node:child_process |
| native/system/scripts/commit-release.mjs | 43 | — | node:path, node:child_process |
| native/system/scripts/github-matrix.mjs | 70 | — | node:path |
| native/system/scripts/pack-release.mjs | 123 | — | node:fs, node:os, node:path, node:child_process |
| native/system/scripts/publish-release.mjs | 166 | — | node:fs, node:path, node:crypto, node:child_process, node:timers |
| native/system/scripts/repo.mjs | 123 | readJson, platformDirs, entryDirs, packageDirs, verifyPlatformBinaries, root | node:fs, node:path, node:url |
| native/system/scripts/verify-entry-lib.mjs | 29 | — | node:fs, node:path |
| native/system/scripts/verify-launcher-binary.mjs | 31 | — | node:path |
| native/system/scripts/verify-packed-install.mjs | 239 | — | node:crypto, node:fs, node:os, node:path, node:child_process |
| native/system/scripts/verify-release.mjs | 55 | — | node:path |
| native/system/test/link-platform.mjs | 11 | — | node:fs, node:path, node:url |

#### native/system/packages/entry — @deepseek-ai/node-addon-system@0.1.2（2 文件 / 186 行）

职责：C 原生 addon 的 JS 入口：landlock-run 启动器路径/参数/probe + flock 独占锁


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| native/system/packages/entry/src/flock.ts | 58 | tryLockExclusive | node:module, node:path, node:util |
| native/system/packages/entry/src/index.ts | 128 | launcherPath, grantArgs, probe, LAUNCHER_BIN, LAUNCHER_FAILURE_EXIT, LandlockEnforcement, LauncherGrants | node:child_process, node:module, node:path, node:url |

#### packages — packages（1 文件 / 14 行）

职责：packages/tsdown.worker.ts：tsdown worker bundle 的 profile 横幅注入（构建辅助）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/tsdown.worker.ts | 14 | profileWorkerBanner | @deepseek-ai/dsh-app-boot |

#### packages/acp/acp — @deepseek-ai/dsh-acp@0.2.1-alpha.1（7 文件 / 1830 行）

职责：ACP（Agent Client Protocol）JSON-RPC stdio 服务端：automation-only 表面


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/acp/acp/src/codec.ts | 36 | turnEndToStopReason | @agentclientprotocol/sdk, @deepseek-ai/dsh-session |
| packages/acp/acp/src/content.ts | 238 | supportsAcpImagePrompts, admitAcpPrompt, assistantBlockToAcp, AcpContentError, AcpContentFailureKind | @agentclientprotocol/sdk, @deepseek-ai/cordis, @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-llm |
| packages/acp/acp/src/index.ts | 537 | apply, name, inject, Config, AcpConfig | @deepseek-ai/cordis, node:buffer, node:crypto, node:fs, node:path |
| packages/acp/acp/src/mcp.ts | 144 | mountAcpMcpServers, AcpMcpConfigError | @deepseek-ai/cordis, node:crypto, node:http, node:path, @agentclientprotocol/sdk |
| packages/acp/acp/src/model-control.ts | 238 | AcpModelConfigError, AcpModelControl | @deepseek-ai/cordis, @agentclientprotocol/sdk, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-llm |
| packages/acp/acp/src/session.ts | 525 | AcpSession, CreateAcpSessionOptions, ResumeAcpSessionOptions | @deepseek-ai/cordis, @agentclientprotocol/sdk, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session |
| packages/acp/acp/src/updates.ts | 112 | assistantUpdates, toolCallUpdate, toolResultUpdate | @deepseek-ai/cordis, @agentclientprotocol/sdk, @deepseek-ai/dsh-session, @deepseek-ai/dsh-token-meter |

#### packages/api/account-controller — @deepseek-ai/dsh-api-account-controller@0.2.1-alpha.1（2 文件 / 125 行）

职责：账号 Remote API（deepseek-account 桥）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/api/account-controller/src/index.ts | 122 | AccountController | @deepseek-ai/cordis, @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-deepseek-account, @deepseek-ai/dsh-agent |
| packages/api/account-controller/src/types.ts | 3 | — | @deepseek-ai/dsh-deepseek-account |

#### packages/api/gateway — @deepseek-ai/dsh-api-gateway@0.2.1-alpha.1（12 文件 / 5236 行）

职责：Typert Remote 网关：/api 分派 + WS RemoteStreamMux 多路流 + $events


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/api/gateway/src/client/index.ts | 883 | apply, carrierFailure, cancelledFailure, isRemoteFailure, inject, ClientRemote, RemoteHostFacts | @deepseek-ai/cordis, @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-client-connection |
| packages/api/gateway/src/client/journal-stream.ts | 581 | RemoteJournalStream, RemoteJournalFrame, RemoteJournalChange, RemoteStreamFactory, RemoteJournalStreamOptions | @deepseek-ai/dsh-typert-protocol |
| packages/api/gateway/src/client/remote-events.ts | 342 | ClientRemoteEvents, RemoteEventStreamOpener | @deepseek-ai/cordis, @deepseek-ai/dsh-client-connection, @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-util-crypto |
| packages/api/gateway/src/client/remote-stream.ts | 228 | RemoteStream, RemoteStreamItem, RemoteStreamOptions | @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-client-connection |
| packages/api/gateway/src/client/snapshot-stream.ts | 95 | RemoteSnapshotStream, RemoteSnapshotStreamOptions | @deepseek-ai/dsh-typert-protocol |
| packages/api/gateway/src/client/stream-client.ts | 481 | RemoteStreamCarrierError, RemoteStreamMuxClient, ClientUplinkQueue | @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-deque, @deepseek-ai/dsh-util-crypto |
| packages/api/gateway/src/index.ts | 1576 | TypertGatewayError, TypertGatewayService, Config | node:crypto, @deepseek-ai/cordis, @deepseek-ai/dsh-client-connection, @deepseek-ai/dsh-deque, @deepseek-ai/dsh-host-webserver |
| packages/api/gateway/src/remote-error-codes.ts | 38 | TypertGatewayFaultDetails | — |
| packages/api/gateway/src/stream-protocol.ts | 382 | parseRemoteEventResult, projectRemoteEventRequest, projectRemoteEventRejection, restoreRemoteEventRejection, isRemoteEventId, isRemoteEventClientId, isRemoteEventAgentId, parseRemoteStreamClientMessage …等29项 | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-typert-protocol |
| packages/api/gateway/src/stream-server.ts | 445 | rejectRemoteStreamUpgrade, RemoteStreamMuxServer, RemoteStreamOpener, RemoteStreamFailureMapper | node:http, node:stream, @deepseek-ai/dsh-deque, @deepseek-ai/dsh-typert-protocol, ws |
| packages/api/gateway/src/types.ts | 181 | InvokeRemoteRequest, TypertRemoteEventFrame, TypertRemoteEventContext, TypertRemoteEventOutcome, TypertRemoteEventInvocation, TypertRemoteEventDispatch, TypertRemoteEventSource, TypertGatewayWireStream …等10项 | @deepseek-ai/cordis, @deepseek-ai/dsh-typert-protocol |
| packages/api/gateway/tsdown.config.ts | 4 | clientBundle | — |

#### packages/api/job-controller — @deepseek-ai/dsh-api-job-controller@0.2.1-alpha.1（9 文件 / 1010 行）

职责：后台任务 Remote API


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/api/job-controller/src/client/index.ts | 37 | apply, inject | @deepseek-ai/cordis |
| packages/api/job-controller/src/client/model.ts | 217 | ClientJobsModel, ObservedJob, JobsSnapshot, JobsSource | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-jobs, @deepseek-ai/dsh-session |
| packages/api/job-controller/src/client/service.ts | 278 | ClientJobs, JobRemote, JobsRemote, IJobs | @deepseek-ai/cordis, @deepseek-ai/dsh-api-gateway, @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-jobs, @deepseek-ai/dsh-session |
| packages/api/job-controller/src/index.ts | 131 | JobController, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-jobs, @deepseek-ai/dsh-typert-protocol |
| packages/api/job-controller/src/observe.ts | 133 | observeJobOutput, ObserveJobOptions | @deepseek-ai/dsh-jobs |
| packages/api/job-controller/src/rows.ts | 54 | streamJobRows, RowsOptions | @deepseek-ai/dsh-jobs |
| packages/api/job-controller/src/types.ts | 91 | JobListRequest, JobListFrame, JobKillRequest, JobKillValue, JobFollowRequest, JobFollowFrame | @deepseek-ai/dsh-jobs, @deepseek-ai/dsh-session |
| packages/api/job-controller/src/wake.ts | 61 | sleep, OutputWaiter | — |
| packages/api/job-controller/tsdown.config.ts | 8 | clientBundle | — |

#### packages/api/remotes — @deepseek-ai/dsh-api-remotes@0.2.1-alpha.1（5 文件 / 447 行）

职责：客户端远端聚合（client face 的 remote 入口集合）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/api/remotes/src/client/index.ts | 201 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-client-product-analytics, @deepseek-ai/dsh-agent-preset-registry, @deepseek-ai/dsh-user-questions, @deepseek-ai/dsh-commands |
| packages/api/remotes/src/index.ts | 169 | apply, inject | node:os, @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-api-gateway, @deepseek-ai/dsh-deque |
| packages/api/remotes/src/remote-events.ts | 49 | API_REMOTE_FORWARDED_EVENTS | @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-deepseek-account, @deepseek-ai/dsh-permission-presets, @deepseek-ai/dsh-plugin-manager, @deepseek-ai/dsh-schedule |
| packages/api/remotes/src/types.ts | 20 | ApiRemoteForwardedEvent | — |
| packages/api/remotes/tsdown.config.ts | 8 | clientBundle | — |

#### packages/api/session-controller — @deepseek-ai/dsh-api-session-controller@0.2.1-alpha.1（35 文件 / 8382 行）

职责：会话 Remote API（35 文件：冷读/prompt/fork/模型目录/归档门）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/api/session-controller/src/agent.ts | 537 | hasApiSessionSubagentOwner, apiSessionSubagentOwnershipError, inspectApiSession, ApiSessionNotFound, ApiSessionSubagentOwnership, ApiSessionCwdConflict, ApiSessionPresetConflict, ApiSessionAgentController …等10项 | node:fs, @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-agent-default-model, @deepseek-ai/dsh-agent-preset-registry |
| packages/api/session-controller/src/archived-session-gate.ts | 57 | underArchivedSession, ArchivedSessionGate | @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-session, @deepseek-ai/dsh-workspace |
| packages/api/session-controller/src/assistant-stream.ts | 103 | SessionAssistantStreamAccumulator | @deepseek-ai/dsh-agent, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session, @deepseek-ai/dsh-util-values |
| packages/api/session-controller/src/catalog.ts | 117 | buildModelCatalog, modelAvailable, hasProviderApiKey | @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-credentials, @deepseek-ai/dsh-settings, @deepseek-ai/dsh-llm, @deepseek-ai/cordis |
| packages/api/session-controller/src/client/contract/events.ts | 206 | MutableSessionEventSource, AssistantLiveChunkEvent, SessionEventLike, SessionEventLikeEntry, SessionLiveEventEntry, SessionAssistantSettlementEntry, SessionTransientEventEntry, SessionEventChange …等10项 | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session |
| packages/api/session-controller/src/client/contract/session.ts | 156 | PendingSubmissionRetirement, BeginSubmissionInput, SubmissionHandle, ProjectionsFace, ISession, SessionFace | @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session, @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-client-store |
| packages/api/session-controller/src/client/contract/sessions.ts | 164 | SessionTarget, SessionReference, SessionRetainOptions, SessionRetainInfo, ISessions | @deepseek-ai/cordis, @deepseek-ai/dsh-subagent, @deepseek-ai/dsh-session, @deepseek-ai/dsh-workspace, @deepseek-ai/dsh-typert-protocol |
| packages/api/session-controller/src/client/contract/snapshot.ts | 92 | PendingSubmissionImage, PendingSubmissionImageAttachment, PendingSubmissionFileAttachment, PendingSubmissionAttachment, PendingSubmissionPlacement, PendingSubmission, OpenState, PromptError …等9项 | @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-session, @deepseek-ai/dsh-subagent, @deepseek-ai/dsh-typert-protocol |
| packages/api/session-controller/src/client/index.ts | 150 | apply, inject, SessionReferenceSourceMap, SessionReferenceSource | @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-client-connection, @deepseek-ai/dsh-client-file-upload, @deepseek-ai/dsh-typert-protocol |
| packages/api/session-controller/src/client/ordered-baseline.ts | 44 | mergeOrderedBaseline | — |
| packages/api/session-controller/src/client/scope.ts | 77 | createScope, scopeOf, scopeIdentityOf, AgentContext, AgentScopeHandle | @deepseek-ai/cordis, @deepseek-ai/dsh-api-gateway, @deepseek-ai/dsh-session, @deepseek-ai/dsh-typert-protocol |
| packages/api/session-controller/src/client/session-wire-event.ts | 47 | assertSessionWireEvent | @deepseek-ai/dsh-session |
| packages/api/session-controller/src/client/sessions/assistant-stream.ts | 230 | ClientAssistantStream, ClientAssistantStreamResult | @deepseek-ai/dsh-llm |
| packages/api/session-controller/src/client/sessions/history-records.ts | 36 | historyEntries, historyRecordFirstSeq, historyRecordLastSeq | — |
| packages/api/session-controller/src/client/sessions/lineage.ts | 86 | flattenLineage, TitledSessionSummary, SessionListEntry | @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-projection |
| packages/api/session-controller/src/client/sessions/manager.ts | 854 | SessionManager, SessionListPhase, SessionSearchResultItem, SessionListSnapshot, SessionProjectionSnapshot | @deepseek-ai/dsh-subagent, @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-projection, @deepseek-ai/dsh-workspace, @deepseek-ai/dsh-api-gateway |
| packages/api/session-controller/src/client/sessions/notifier.ts | 98 | Notifier | @deepseek-ai/dsh-client-store |
| packages/api/session-controller/src/client/sessions/projection-store.ts | 245 | ProjectionValueStore, UseProjection, ProjectionsBaseline | @deepseek-ai/dsh-session-projection, @deepseek-ai/dsh-session, @deepseek-ai/dsh-client-store |
| packages/api/session-controller/src/client/sessions/remotes.ts | 47 | SessionCommandsRemote, SessionSubagentsRemote, SessionRemotes | @deepseek-ai/dsh-api-gateway, @deepseek-ai/dsh-commands, @deepseek-ai/dsh-session, @deepseek-ai/dsh-subagent, @deepseek-ai/dsh-typert-protocol |
| packages/api/session-controller/src/client/sessions/service.ts | 711 | SessionCreateError, SessionForkError, ClientSessions, SessionSummary, SessionListState, SessionBinding | @deepseek-ai/cordis, @deepseek-ai/dsh-subagent, @deepseek-ai/dsh-session, @deepseek-ai/dsh-util-workspace-path, @deepseek-ai/dsh-workspace |
| packages/api/session-controller/src/client/sessions/session.ts | 942 | Session, PAGE_MESSAGES, JUMP_PAGE_MESSAGES, SessionOptions | @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-util-crypto, @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-subagent |
| packages/api/session-controller/src/client/time-zone.ts | 15 | resolvedClientTimeZone | — |
| packages/api/session-controller/src/client/transport.ts | 247 | createSessionControlStream, SessionEventStream, ClientSessionPageRequest, SessionRemote, SessionJournalChange, SessionControlStream, SessionControlStreamOptions, SessionEventStreamOptions | @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-api-gateway |
| packages/api/session-controller/src/commands.ts | 692 | SessionCommandController | node:crypto, @deepseek-ai/cordis, @deepseek-ai/dsh-brand, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-attachment |
| packages/api/session-controller/src/control.ts | 122 | SessionControlController | @deepseek-ai/cordis, @deepseek-ai/dsh-deque, @deepseek-ai/dsh-session, @deepseek-ai/dsh-util-values |
| packages/api/session-controller/src/file-references.ts | 43 | SessionFileReferences | @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-file-reference, @deepseek-ai/dsh-typert-protocol |
| packages/api/session-controller/src/history.ts | 446 | SessionHistoryController | @deepseek-ai/cordis, @deepseek-ai/dsh-deque, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-query |
| packages/api/session-controller/src/index.ts | 536 | SessionController, Config, SessionControllerInternals | node:os, node:path, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-fs, @deepseek-ai/cordis |
| packages/api/session-controller/src/list.ts | 362 | applySessionListMetadata, truncateUnicodeCodePoints, ApiSessionList | node:perf_hooks, node:timers, @deepseek-ai/cordis, @deepseek-ai/dsh-agent-preset-registry, @deepseek-ai/dsh-attachment |
| packages/api/session-controller/src/media-references.ts | 78 | SessionMediaReferences | node:path, @deepseek-ai/cordis, @deepseek-ai/dsh-client-connection, @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-fs |
| packages/api/session-controller/src/model-selection-projection.ts | 84 | installModelSelectionProjection | @deepseek-ai/cordis, @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-projection, zod |
| packages/api/session-controller/src/remote-events.ts | 15 | — | — |
| packages/api/session-controller/src/skill-catalog.ts | 108 | SessionSkillCatalog | @deepseek-ai/cordis, @deepseek-ai/dsh-agent-preset-registry, @deepseek-ai/dsh-session-query, @deepseek-ai/dsh-skill, @deepseek-ai/dsh-scope |
| packages/api/session-controller/src/types.ts | 627 | SESSION_SEARCH_RESULT_LIMIT, SESSION_SEARCH_SNIPPET_MAX_CODE_POINTS, SessionListMetadata, SessionProjectionHints, SessionProjectionBaseline, SessionProjectionValues, PromptContentPart, ModelSelection …等65项 | @deepseek-ai/dsh-native-command, @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-brand, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session |
| packages/api/session-controller/tsdown.config.ts | 8 | clientBundle | — |

#### packages/api/settings-controller — @deepseek-ai/dsh-api-settings-controller@0.2.1-alpha.1（3 文件 / 462 行）

职责：设置/凭据 Remote API


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/api/settings-controller/src/credentials.ts | 156 | CredentialsController | @deepseek-ai/cordis, @deepseek-ai/dsh-credentials, @deepseek-ai/dsh-typert-protocol, zod |
| packages/api/settings-controller/src/index.ts | 271 | SettingsController, SettingsControllerInternals | @deepseek-ai/cordis, @deepseek-ai/dsh-native-command, @deepseek-ai/dsh-settings, @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-util-values |
| packages/api/settings-controller/src/types.ts | 35 | SettingsDocumentOpenValue | — |

#### packages/api/terminal-controller — @deepseek-ai/dsh-api-terminal-controller@0.2.1-alpha.1（13 文件 / 1764 行）

职责：终端 Remote API


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/api/terminal-controller/src/client/bindings.ts | 64 | TerminalBindings | @deepseek-ai/dsh-session |
| packages/api/terminal-controller/src/client/close-requests.ts | 74 | TerminalCloseRequests, TerminalCloseRequest | @deepseek-ai/dsh-session |
| packages/api/terminal-controller/src/client/index.ts | 244 | apply, ClientTerminals, inject, TerminalLaunchShells, TerminalCloseFailure | @deepseek-ai/cordis, @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-session, @deepseek-ai/dsh-api-gateway, @deepseek-ai/dsh-client-store |
| packages/api/terminal-controller/src/client/model.ts | 340 | TerminalView, TerminalRemote, TerminalViewIssue, TerminalRenderFrame, TerminalViewState | @deepseek-ai/dsh-util-crypto, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-api-gateway, @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-session |
| packages/api/terminal-controller/src/client/retention.ts | 77 | TerminalWindowHold | @deepseek-ai/dsh-api-gateway, @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-session |
| packages/api/terminal-controller/src/client/shell-preference.ts | 21 | preferredShell, rememberShell | — |
| packages/api/terminal-controller/src/index.ts | 380 | TerminalController, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-session, @deepseek-ai/dsh-sandbox-policy |
| packages/api/terminal-controller/src/retention.ts | 133 | TerminalRetention, TerminalRetentionPolicy | @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-subprocess |
| packages/api/terminal-controller/src/shells.ts | 67 | resolveShell, discoverShells | @deepseek-ai/dsh-subprocess |
| packages/api/terminal-controller/src/stream.ts | 76 | TerminalFollower | @deepseek-ai/dsh-deque |
| packages/api/terminal-controller/src/terminal.ts | 209 | BrowserTerminal | @deepseek-ai/dsh-typert-protocol, @xterm/headless, @xterm/addon-serialize, @deepseek-ai/dsh-subprocess, @deepseek-ai/dsh-lazy-require |
| packages/api/terminal-controller/src/types.ts | 71 | WebTerminalId, TerminalAttachmentId, TerminalRetentionFrame, TerminalShell, TerminalEnvironment, WebTerminalInfo, TerminalCreateRequest, TerminalFrame | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-typert-protocol |
| packages/api/terminal-controller/tsdown.config.ts | 8 | clientBundle | — |

#### packages/api/workspace-controller — @deepseek-ai/dsh-api-workspace-controller@0.2.1-alpha.1（11 文件 / 1899 行）

职责：工作区 Remote API


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/api/workspace-controller/src/client/index.ts | 126 | apply, createWorkspaceStateStream, inject, WorkspaceStateStream, WorkspaceStateStreamOptions | @deepseek-ai/cordis, @deepseek-ai/dsh-api-gateway |
| packages/api/workspace-controller/src/client/model.ts | 468 | ClientWorkspaceModel, WorkspaceRemote, WorkspaceListPhase, WorkspaceSnapshot, WorkspaceFollowSink | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-api-gateway, @deepseek-ai/dsh-typert-protocol |
| packages/api/workspace-controller/src/client/service.ts | 192 | WorkspaceCreateError, WorkspaceArchiveError, WorkspaceController, WorkspaceSource, IWorkspaces | @deepseek-ai/cordis, @deepseek-ai/dsh-session, @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-workspace |
| packages/api/workspace-controller/src/commands.ts | 253 | WorkspaceCommands | @deepseek-ai/cordis, @deepseek-ai/dsh-workspace, @deepseek-ai/dsh-typert-protocol |
| packages/api/workspace-controller/src/default-directory.ts | 79 | validateDocumentsDirectory, defaultWorkspaceDirectory | node:os, node:path, @deepseek-ai/dsh-native-command |
| packages/api/workspace-controller/src/default-workspace.ts | 31 | workspaceDisplayTitle, DEFAULT_WORKSPACE_DIRECTORY | — |
| packages/api/workspace-controller/src/directory-picker.ts | 175 | DirectoryPickerController | @deepseek-ai/cordis, zod, @deepseek-ai/dsh-host-directory-picker, @deepseek-ai/dsh-typert-protocol |
| packages/api/workspace-controller/src/feed.ts | 194 | workspaceView, WorkspaceFeed | @deepseek-ai/cordis, @deepseek-ai/dsh-deque, @deepseek-ai/dsh-storage-domain, @deepseek-ai/dsh-workspace |
| packages/api/workspace-controller/src/index.ts | 201 | WorkspaceController, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-typert-protocol |
| packages/api/workspace-controller/src/types.ts | 172 | WorkspaceView, WorkspaceCreateRequest, WorkspaceCreateValue, WorkspaceRenameRequest, WorkspaceValue, WorkspaceDeleteRequest, WorkspaceDeleteValue, WorkspaceInsertBeforeRequest …等19项 | @deepseek-ai/dsh-session, @deepseek-ai/dsh-workspace, @deepseek-ai/dsh-host-directory-picker |
| packages/api/workspace-controller/tsdown.config.ts | 8 | clientBundle | — |

#### packages/api/workspace-files — @deepseek-ai/dsh-api-workspace-files@0.2.1-alpha.1（9 文件 / 1401 行）

职责：工作区文件 Remote API（含上传/预览）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/api/workspace-files/src/changes.ts | 163 | WorkspaceChangeFeed | @deepseek-ai/cordis, @deepseek-ai/dsh-deque, @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-fs |
| packages/api/workspace-files/src/client/change-feed.ts | 294 | ChangeFeed | @deepseek-ai/dsh-session |
| packages/api/workspace-files/src/client/index.ts | 36 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-api-gateway, @deepseek-ai/dsh-client-resources |
| packages/api/workspace-files/src/client/provider.ts | 155 | createFileResourceProvider | @deepseek-ai/dsh-client-resources, @deepseek-ai/dsh-session, @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-util-workspace-path |
| packages/api/workspace-files/src/client/remote.ts | 51 | SupervisedStreamItem, SupervisedStream, SupervisedStreamOptions, WorkspaceFilesNamespace, WorkspaceFilesRemote | @deepseek-ai/dsh-api-gateway |
| packages/api/workspace-files/src/client/types.ts | 51 | WorkspaceFileParams, WorkspaceFileEdit, WorkspaceFileNotice | @deepseek-ai/dsh-client-resources |
| packages/api/workspace-files/src/index.ts | 466 | WorkspaceFiles, WorkspaceFileScope, Config | node:path, @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-fs, @deepseek-ai/dsh-sandbox-policy |
| packages/api/workspace-files/src/types.ts | 177 | WorkspaceFileStat, WorkspaceFileRange, WorkspaceFileText, WorkspaceByteRange, WorkspaceByteReadOptions, WorkspaceFileBytes, WorkspaceDirectoryEntry, WorkspaceDirectoryListing …等10项 | @deepseek-ai/dsh-typert-protocol |
| packages/api/workspace-files/tsdown.config.ts | 8 | clientBundle | — |

#### packages/attachment/attachment — @deepseek-ai/dsh-attachment@0.2.1-alpha.1（6 文件 / 683 行）

职责：附件 Service Definition（ctx.attachments）：批量校验/限额/verbatim 拒绝


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/attachment/attachment/src/admission.ts | 75 | admitEncodedImages, admitEncodedFile | node:buffer |
| packages/attachment/attachment/src/brand.ts | 28 | AttachmentId, ImageVariantId | @deepseek-ai/dsh-brand |
| packages/attachment/attachment/src/error.ts | 87 | isAttachmentError, isImageAdmissionError, AttachmentError, ImageAdmissionErrorCode, AttachmentErrorCode | — |
| packages/attachment/attachment/src/index.ts | 266 | AttachmentStore | @deepseek-ai/cordis |
| packages/attachment/attachment/src/request-projection.ts | 63 | requestImageDimensions, longEdgeDimensions, ProjectedDimensions | — |
| packages/attachment/attachment/src/types.ts | 164 | ImageMediaType, ImageAttachmentRef, FileAttachmentRef, EncodedFileAttachment, SaveFileAttachment, SaveFileStreamAttachment, ImageAttachmentLimits, EncodedImageAttachment …等15项 | — |

#### packages/attachment/attachment-local — @deepseek-ai/dsh-attachment-local@0.2.1-alpha.1（9 文件 / 1561 行）

职责：本地附件实现：内容寻址 file-store + sharp 图片归一化


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/attachment/attachment-local/src/compression-limiter.ts | 53 | compressionFailure, CompressionLimiter | — |
| packages/attachment/attachment-local/src/encoding.ts | 84 | encodingLadder, encodeFirstWithinLimit, isExhaustedEncoding, IMAGE_ENCODING_QUALITIES, WEBP_ENCODING_EFFORT, EncodedImage, EncodedCandidate, ExhaustedEncoding | sharp |
| packages/attachment/attachment-local/src/file-store.ts | 182 | fileLeafName, storedFilePath, saveFileVerbatim, saveFileStreamVerbatim, readFileStreamVerbatim | node:crypto, node:fs, node:path, @deepseek-ai/dsh-attachment |
| packages/attachment/attachment-local/src/image.ts | 134 | encodedAlphaIsCompatible, probeImage, detectImage, DetectedImage, DecodedImageLimits | sharp, @deepseek-ai/dsh-attachment |
| packages/attachment/attachment-local/src/index.ts | 292 | LocalAttachmentStore, DEFAULT_MAX_IMAGE_BYTES, DEFAULT_MAX_IMAGES_PER_MESSAGE, DEFAULT_MAX_MESSAGE_IMAGE_BYTES, DEFAULT_MAX_IMAGE_PIXELS, DEFAULT_MAX_IMAGE_DIMENSION, DEFAULT_NORMALIZED_IMAGE_MAX_PIXELS, DEFAULT_NORMALIZED_IMAGE_MAX_DIMENSION …等12项 | node:path, @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-home-paths |
| packages/attachment/attachment-local/src/normalization.ts | 138 | canPassThroughNormalization, normalizeImage, NormalizationPolicy, NormalizedImage | sharp, @deepseek-ai/dsh-attachment |
| packages/attachment/attachment-local/src/request-image.ts | 211 | requestImageVariantId, readRequestImageFile, REQUEST_IMAGE_TRANSFORM_VERSION | node:crypto, node:fs, node:path, sharp, @deepseek-ai/dsh-attachment |
| packages/attachment/attachment-local/src/sharp.ts | 8 | requireSharp | sharp, @deepseek-ai/dsh-lazy-require |
| packages/attachment/attachment-local/src/store.ts | 459 | normalizedImagePath, validateImageFile, prepareImageFile, commitPreparedImageFile, publishImmutableObject, publishImmutableObjectStream, publishImmutableAlias, saveImageFile …等11项 | node:crypto, node:fs, node:path, @deepseek-ai/dsh-attachment |

#### packages/boot/app-boot — @deepseek-ai/dsh-app-boot@0.2.1-alpha.1（21 文件 / 4993 行）

职责：应用启动装配核心：profile/bundle/patch 解析、Cordis Loader 驱动、启动审计、fail-loud、分层 .env


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/boot/app-boot/src/compatibility-preflight.ts | 188 | prepareProfileEntries, prepareProfilePatches | node:fs, node:module, node:path, node:url, @deepseek-ai/cordis |
| packages/boot/app-boot/src/config-schema/collect.ts | 250 | collectConfigSchemas | node:fs, node:path, node:url, js-yaml, @deepseek-ai/cordis-plugin-loader |
| packages/boot/app-boot/src/config-schema/document.ts | 170 | buildConfigSchemaDocument | — |
| packages/boot/app-boot/src/config-schema/index.ts | 37 | generateConfigSchema | @deepseek-ai/cordis-plugin-include |
| packages/boot/app-boot/src/config-schema/native.ts | 17 | isNativeConfigSchema | — |
| packages/boot/app-boot/src/config-schema/pattern.ts | 63 | createPatternCheck | @eslint-community/regexpp |
| packages/boot/app-boot/src/config-schema/projector.ts | 456 | createConfigProjector, LOADER_EXPRESSION_SCHEMA, ConfigProjection | ajv |
| packages/boot/app-boot/src/config-schema/types.ts | 96 | ConfigJsonSchema, ConfigJsonSchemaObject, ConfigSchemaDiagnostic, ConfigSchemaEntry, ConfigSchemaDump, NativeConfigSchema, CollectedConfigEntry | — |
| packages/boot/app-boot/src/index.ts | 1068 | resolveConfigPath, loadEnv, loadLayeredEnv, reconcileProfilePatches, loadOptionalPatches, loadOverlayPatches, renderConfigDump, mountRootInclude …等18项 | node:url, node:fs, node:util, node:path, js-yaml |
| packages/boot/app-boot/src/package-meta.ts | 200 | resolvePluginResource, readPluginMeta | node:fs, node:path, node:url, @deepseek-ai/cordis-plugin-loader, @deepseek-ai/dsh-package-manifest |
| packages/boot/app-boot/src/plugin-compatibility.ts | 104 | getDshRuntimeVersion, evaluatePluginCompatibility, pluginCompatibilityWarning, PluginCompatibility | node:fs, node:url, semver |
| packages/boot/app-boot/src/profile-compatibility.ts | 142 | isExactPluginVersion, validatePluginVersionExemption, readProfileCompatibility, readProfileVersionExemptions, setProfileVersionExemption, PROFILE_COMPATIBILITY_FILENAME, ProfileCompatibility | node:fs, node:path, semver, @deepseek-ai/dsh-atomic-write |
| packages/boot/app-boot/src/profile-context.ts | 76 | resolveTelemetryPatch, readProfilePatches, ProfilePnpmInvocation, ProfileContext | node:path, @deepseek-ai/cordis-plugin-include |
| packages/boot/app-boot/src/profile-plugins.ts | 128 | readProfilePlugins, writeProfileBundles, reconcileProfilePlugins, ProfilePluginLocation, ProfilePluginDependency, ProfilePluginInventory, ProfilePluginReconciliation | node:path |
| packages/boot/app-boot/src/profile-resolution/legacy-links.ts | 21 | realModuleDirectory | node:fs |
| packages/boot/app-boot/src/profile-resolution/resolver.ts | 934 | barePackageName, installRuntimeInterception, registerWorkerResolution, RuntimeInterception | node:fs, node:module, node:path, node:url, node:worker_threads |
| packages/boot/app-boot/src/profile-resolution/service.ts | 144 | PluginPackages, PluginPackage, PluginPackagesConfig | node:fs, node:module, node:path, @deepseek-ai/cordis, @deepseek-ai/dsh-package-manifest |
| packages/boot/app-boot/src/profile-resolution/worker-bootstrap.ts | 13 | — | node:worker_threads |
| packages/boot/app-boot/src/profile-sanitize.ts | 35 | sanitizeProfile | node:fs, node:path |
| packages/boot/app-boot/src/profile.ts | 816 | bundlePatchFiles, bundlePatchPaths, reportSkippedBundles, resolveProfileDir, initProfile, removeLinkProjections, createRuntimeResolution, readProfileManifest …等28项 | node:module, node:fs, node:path, @deepseek-ai/cordis-plugin-loader, @deepseek-ai/cordis-plugin-include |
| packages/boot/app-boot/tsdown.config.ts | 35 | defineConfig | tsdown |

#### packages/boot/cmdline — @deepseek-ai/dsh-cmdline@0.2.1-alpha.1（1 文件 / 240 行）

职责：启动器事实注入（ctx.cmdlineArgs/appExit/appReady）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/boot/cmdline/src/index.ts | 240 | provideCmdline, exitOnStdinEnd, parseCmdline, internals, CmdlineArgs, AppExit, AppReady, CmdlineHost …等9项 | commander, @deepseek-ai/cordis |

#### packages/boot/config-editor — @deepseek-ai/dsh-config-editor@0.2.1-alpha.1（1 文件 / 158 行）

职责：活配置表单（Live Config forms）：经 profile patch 持久化


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/boot/config-editor/src/index.ts | 158 | ConfigEditor | node:fs, node:path, node:util, @deepseek-ai/cordis, @deepseek-ai/cordis-plugin-include |

#### packages/boot/hmr — @deepseek-ai/dsh-hmr@0.2.1-alpha.1（4 文件 / 1207 行）

职责：模块热替换 + profile 配置热重载（ctx.hmr）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/boot/hmr/src/error.ts | 42 | handleError | @deepseek-ai/cordis, esbuild, @babel/code-frame, node:fs |
| packages/boot/hmr/src/index.ts | 741 | HmrConfig, Reload, Config, Hmr | node:assert, node:async_hooks, @deepseek-ai/cordis, @deepseek-ai/cordis-plugin-loader, @deepseek-ai/cordis-plugin-include |
| packages/boot/hmr/src/package-manifest.ts | 331 | PackageManifests | node:buffer, node:fs, node:module, node:path, node:url |
| packages/boot/hmr/src/watch-config.ts | 93 | watchConfig | node:path, node:fs, chokidar, @deepseek-ai/cordis |

#### packages/boot/plugin-manager — @deepseek-ai/dsh-plugin-manager@0.2.1-alpha.1（12 文件 / 2373 行）

职责：profile 插件/包管理器：pnpm 转发、启停即改 patch 行、防自毁保护


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/boot/plugin-manager/src/build-approval.ts | 51 | readPendingBuilds, approveBuilds | node:fs, node:path, yaml, @deepseek-ai/dsh-atomic-write |
| packages/boot/plugin-manager/src/failure.ts | 30 | incompatiblePlugin, ManagementFailure | @deepseek-ai/dsh-app-boot |
| packages/boot/plugin-manager/src/github-connection.ts | 69 | checkGithubConnection, GithubConnectionOptions | node:fs, node:path, execa, @deepseek-ai/dsh-subprocess |
| packages/boot/plugin-manager/src/index.ts | 833 | PluginManager, Config | node:crypto, node:fs, node:path, node:url, @deepseek-ai/dsh-atomic-write |
| packages/boot/plugin-manager/src/install-failure.ts | 45 | classifyInstallFailure, InstallFailureFacts | — |
| packages/boot/plugin-manager/src/install-spec.ts | 124 | parseInstallSpec, dependencySpec, InvalidInstallSpecError, ParsedInstallSpec | node:os, node:path |
| packages/boot/plugin-manager/src/operations.ts | 641 | anchorPathSpec, bundleManifest, saveManifest, runProfilePnpm, runPluginCommand, readProfileRegistry, registryArguments, viewProfilePackage …等12项 | node:events, node:fs, node:path, execa, @deepseek-ai/cordis-plugin-loader |
| packages/boot/plugin-manager/src/patch.ts | 44 | writePluginEnabled | node:fs, yaml, @deepseek-ai/dsh-app-boot, @deepseek-ai/dsh-atomic-write |
| packages/boot/plugin-manager/src/registry.ts | 99 | normalizeRegistry, registryPlan, attributeFailure, OFFICIAL_NPM_REGISTRY, NPMMIRROR_REGISTRY, REGISTRY_URL | — |
| packages/boot/plugin-manager/src/run-tree.ts | 78 | leadsOwnGroup, treeAlive, awaitTreeGone, RunTree, RunTreeInternals | — |
| packages/boot/plugin-manager/src/tools.ts | 93 | apply, inject | @deepseek-ai/dsh-util-values, @deepseek-ai/cordis, @deepseek-ai/dsh-sandbox-policy, @deepseek-ai/dsh-user-approval, @deepseek-ai/dsh-sandbox |
| packages/boot/plugin-manager/src/types.ts | 266 | ReadOnlyReason, IncompatiblePlugin, ManagementError, PluginInfo, BundleRowInfo, BundleInfo, Registry, PluginRegistries …等21项 | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-package-manifest, @deepseek-ai/dsh-host-plugin-inventory |

#### packages/browser-use/browser-use — @deepseek-ai/dsh-browser-use@0.2.1-alpha.1（2 文件 / 65 行）

职责：浏览器能力排他命名注册槽（BrowserUseRegistry）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/browser-use/browser-use/src/brand.ts | 16 | BrowserUseProviderName | @deepseek-ai/dsh-brand |
| packages/browser-use/browser-use/src/index.ts | 49 | BrowserUseRegistry | @deepseek-ai/cordis |

#### packages/bundle/acp-app — @deepseek-ai/dsh-acp-app@0.2.1-alpha.1（1 文件 / 49 行）

职责：ACP profile bundle：在 base 上叠 acp 服务端行


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/bundle/acp-app/src/index.ts | 49 | apply, name, inject, ACP_APP_STARTUP_SERVICE | commander, @deepseek-ai/cordis, @deepseek-ai/dsh-cmdline |

#### packages/bundle/base — @deepseek-ai/dsh-base@0.2.1-alpha.1（1 文件 / 10 行）

职责：共享首层 bundle：529 行 patch 插入约 90 行核心（模型/工具/持久化/沙箱/审批）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/bundle/base/src/index.ts | 10 | — | — |

#### packages/bundle/headless — @deepseek-ai/dsh-headless@0.2.1-alpha.1（5 文件 / 893 行）

职责：headless bundle：一次性任务 runner（stderr 流 reasoning、stdout 结果/NDJSON）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/bundle/headless/src/index.ts | 401 | apply, name, inject, Config | node:crypto, @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-brand, @deepseek-ai/dsh-agent |
| packages/bundle/headless/src/json-stream.ts | 333 | boundJsonLine, projectJsonRun, MAX_STRING_BYTES, MAX_EVENT_BYTES, JsonSink, JsonProjectionOptions, JsonProjection | @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session |
| packages/bundle/headless/src/runner-internals.ts | 22 | internals | — |
| packages/bundle/headless/src/startup-internals.ts | 15 | internals | — |
| packages/bundle/headless/src/startup.ts | 122 | apply, name, inject, HEADLESS_STARTUP_SERVICE, HeadlessStartupValues | commander, @deepseek-ai/cordis, @deepseek-ai/dsh-cmdline |

#### packages/bundle/sdk-app — @deepseek-ai/dsh-sdk-app@0.2.1-alpha.1（1 文件 / 63 行）

职责：SDK profile bundle：在 base 上叠 JSON-RPC 服务端行


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/bundle/sdk-app/src/index.ts | 63 | apply, name, inject, SDK_APP_STARTUP_SERVICE, Config | commander, @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-cmdline |

#### packages/bundle/sdk-minimal — @deepseek-ai/dsh-sdk-minimal@0.2.1-alpha.1（1 文件 / 10 行）

职责：独立完整最小树 bundle（不叠 base）：供打包 carrier 瘦身


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/bundle/sdk-minimal/src/index.ts | 10 | — | — |

#### packages/bundle/web-app — @deepseek-ai/dsh-web-app@0.2.1-alpha.1（3 文件 / 469 行）

职责：Web profile bundle：叠 web 层、禁宿主面 per-agent 工具、注入 4 个出厂 preset


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/bundle/web-app/src/index.ts | 321 | resolveLanTrust, apply, name, inject, Config, internals, WebRuntimeValues | node:child_process, node:module, node:path, node:os, node:url |
| packages/bundle/web-app/src/public-url.ts | 40 | parsePublicUrl | — |
| packages/bundle/web-app/src/startup.ts | 108 | apply, name, inject, WEB_STARTUP_SERVICE, WebStartupValues | commander, @deepseek-ai/cordis, @deepseek-ai/dsh-cmdline |

#### packages/client/connection — @deepseek-ai/dsh-client-connection@0.2.1-alpha.1（17 文件 / 2384 行）

职责：浏览器↔Host RPC 一包两侧：/api HTTP 载波 + browser-auth + 重连控制器（ctx.connection）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/connection/src/api-path.ts | 8 | API_PATH | — |
| packages/client/connection/src/api-request-trust.ts | 119 | assertTrustedAuthority, isTrustedApiRequest | — |
| packages/client/connection/src/browser-auth.ts | 312 | BrowserAuth | node:crypto, @deepseek-ai/dsh-credentials |
| packages/client/connection/src/client/api.ts | 26 | resultOf | @deepseek-ai/dsh-session, @deepseek-ai/dsh-llm |
| packages/client/connection/src/client/connection.ts | 324 | ConnectionController, ConnectionHostInfo, ConnectionGeneration, ConnectionState, ConnectionSinks, ConnectionGenerationSource | — |
| packages/client/connection/src/client/index.ts | 327 | installConnection, apply, inject, ConnectionGenerationState, ConnectionStateSource, ClientTransportHooks, ConnectionLocation, ConnectionInstallOptions …等10项 | @deepseek-ai/cordis |
| packages/client/connection/src/client/random-uuid.ts | 15 | randomUuid | — |
| packages/client/connection/src/client/rpc.ts | 184 | createWebConnectionRpc, RpcFetch, RpcStreamOpen | — |
| packages/client/connection/src/http-bridge.ts | 125 | bridge, DEFAULT_MAX_REQUEST_BODY_BYTES | node:http, node:stream |
| packages/client/connection/src/index.ts | 164 | apply, name, inject, Config, ConnectionConfig | @deepseek-ai/cordis, node:http, @deepseek-ai/schemastery, @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-credentials |
| packages/client/connection/src/loopback-hostname.ts | 19 | isLoopbackHostname | — |
| packages/client/connection/src/operator-peer.ts | 34 | OperatorPeer | node:crypto, @deepseek-ai/cordis, @deepseek-ai/dsh-scope, @deepseek-ai/dsh-typert-protocol |
| packages/client/connection/src/recovery-config.ts | 45 | resolveConnectionConfig, ConnectionRecoveryConfigSchema, ConnectionRecoveryConfig | @deepseek-ai/schemastery |
| packages/client/connection/src/rpc-host.ts | 332 | HostConnectionService | @deepseek-ai/cordis, @deepseek-ai/dsh-host-webserver, @deepseek-ai/dsh-typert-protocol |
| packages/client/connection/src/rpc-schema.ts | 54 | rpcResultSchema, rpcIdSchema, rpcErrorSchema, clientRequestSchema, serverResponseSchema, rpcMessageSchema | zod |
| packages/client/connection/src/rpc.ts | 292 | RpcId, transportError, ConnectionRpcFailure, ConnectionRpcResult, ConnectionRpcAttachment, ConnectionRpcHandlerResult, RpcResult, RpcRequest …等27项 | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-typert-protocol |
| packages/client/connection/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/file-upload — @deepseek-ai/dsh-client-file-upload@0.2.1-alpha.1（8 文件 / 789 行）

职责：页面线程外 Blob/字节流上传（ctx.fileUpload）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/file-upload/src/client/contract.ts | 34 | FileUploadBody, FileUploadProgress, FileUploadService | @deepseek-ai/dsh-session, @deepseek-ai/dsh-typert-protocol |
| packages/client/file-upload/src/client/index.ts | 27 | apply, inject | @deepseek-ai/cordis |
| packages/client/file-upload/src/client/runtime.ts | 339 | fileUploadWorker, FileUploadRuntime | @deepseek-ai/cordis, @deepseek-ai/dsh-util-crypto, @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-session |
| packages/client/file-upload/src/http-route.ts | 82 | handleFileUploadHttp | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-session, @deepseek-ai/dsh-typert-protocol |
| packages/client/file-upload/src/index.ts | 257 | FileUploads, AgentResolver, PromptFileBinding | node:crypto, @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-client-connection |
| packages/client/file-upload/src/protocol.ts | 9 | FILE_UPLOAD_PATH, FILE_UPLOAD_ROUTE | — |
| packages/client/file-upload/src/types.ts | 37 | EncodedFileUploadRequest, FileUploadValue, FileUploadReceiptId, FileUploadFetch, ClientFileUploadHooks | @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-brand |
| packages/client/file-upload/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/hmr — @deepseek-ai/dsh-client-hmr@0.2.1-alpha.1（4 文件 / 312 行）

职责：开发期 client 插件热替换


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/hmr/src/client/index.ts | 48 | apply, name, inject | @deepseek-ai/cordis |
| packages/client/hmr/src/events.ts | 51 | parsePluginsEventFrame, EVENTS_ENDPOINT, EVENTS_ROUTE, PluginsEventFrame, PluginsEventParseResult | @deepseek-ai/dsh-client-modules |
| packages/client/hmr/src/index.ts | 209 | apply, name, inject, Config | node:fs, node:http, @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-client-modules |
| packages/client/hmr/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/locale — @deepseek-ai/dsh-client-locale@0.2.1-alpha.1（11 文件 / 964 行）

职责：本地化偏好与字典（ctx.locale），en/zh 内置


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/locale/src/client/bootstrap.ts | 32 | parseLocaleBootstrap, LocaleBootstrap, LocaleBridge | — |
| packages/client/locale/src/client/index.ts | 624 | apply, LocaleRuntime, FALLBACK_LOCALE, COMMON_NS, SETTINGS_NS, inject, LocaleDict, LanguageRegistration …等10项 | @deepseek-ai/cordis, @deepseek-ai/dsh-package-manifest, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-settings, @deepseek-ai/dsh-client-ui-renderer |
| packages/client/locale/src/client/LanguageRow.tsx | 68 | LanguageRow, LanguageRowInjected, LanguageRowComponentProps | react, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-settings |
| packages/client/locale/src/client/settings-store.ts | 48 | createLanguageRowStore, LanguageOptionRow, LanguageRowState | @deepseek-ai/dsh-client-store |
| packages/client/locale/src/index.ts | 33 | apply, Config | @deepseek-ai/dsh-settings, @deepseek-ai/cordis, @deepseek-ai/schemastery |
| packages/client/locale/src/locale-settings.ts | 36 | LOCALE_SETTINGS_NAMESPACE, LOCALE_PREFERENCE_FIELD, LOCALE_ID_PATTERN, LOCALE_IDS, LocaleSettingsFields, LocaleSettingsSchema, BuiltInLocaleId, LocaleId …等9项 | @deepseek-ai/schemastery |
| packages/client/locale/src/locales/en.ts | 47 | en | — |
| packages/client/locale/src/locales/index.ts | 9 | — | — |
| packages/client/locale/src/locales/settings.ts | 15 | zh, en, SettingsLocaleKey | — |
| packages/client/locale/src/locales/zh.ts | 48 | zh, CommonKey | — |
| packages/client/locale/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/modules — @deepseek-ai/dsh-client-modules@0.2.1-alpha.1（7 文件 / 2448 行）

职责：浏览器端懒 CJS 模块系统 + bundle 传输（ctx.clientModules）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/modules/src/client/entries.ts | 248 | ClientEntries, ClientEntryState | @deepseek-ai/cordis, @deepseek-ai/cordis-plugin-loader, @deepseek-ai/dsh-client-store |
| packages/client/modules/src/client/entry-lifecycle.ts | 29 | tearDownEntryFiber, removeOwnedStyles | @deepseek-ai/cordis-plugin-loader |
| packages/client/modules/src/client/index.ts | 68 | createClientModuleSystem, apply, inject | @deepseek-ai/cordis, @deepseek-ai/cordis-plugin-loader |
| packages/client/modules/src/client/manifest.ts | 449 | optionalStringArray, parseDshClient, exactPackageSpecifier, stripClientSuffix, parseBootManifest, WebBootEntry, WebBootBatchPhase, WebBootBatch …等21项 | @deepseek-ai/cordis, @deepseek-ai/dsh-package-manifest |
| packages/client/modules/src/client/system.ts | 487 | ClientModuleSystem | ${spec} |
| packages/client/modules/src/index.ts | 1160 | orderByModuleGraph, bootInjections, ClientModuleRegistry, ClientArtifactBaseline | node:crypto, node:fs, node:http, node:module, node:path |
| packages/client/modules/tsdown.config.ts | 7 | clientBundle | — |

#### packages/client/product-analytics — @deepseek-ai/dsh-client-product-analytics@0.2.1-alpha.1（4 文件 / 229 行）

职责：客户端产品遥测


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/product-analytics/src/client/index.ts | 61 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-api-gateway |
| packages/client/product-analytics/src/events.ts | 62 | ProductEventMap, OnboardingPage, ProductEvent, TrackProductEvent | @deepseek-ai/dsh-session, @deepseek-ai/dsh-llm |
| packages/client/product-analytics/src/index.ts | 102 | Config, ProductAnalytics | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-host-product-telemetry-otel, @deepseek-ai/dsh-deepseek-account |
| packages/client/product-analytics/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/resources — @deepseek-ai/dsh-client-resources@0.2.1-alpha.1（5 文件 / 379 行）

职责：dsh-resource:// 资源协议注册表 + useResource（ctx.resources）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/resources/src/client/contract.ts | 116 | ResourceProtocol, ResourceStatus, ResourceSnapshot, UseResource, ResourceOpenContext, ResourceProvider, Resources | @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-slots |
| packages/client/resources/src/client/index.ts | 42 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-renderer, @deepseek-ai/dsh-client-ui-slots |
| packages/client/resources/src/client/resources.ts | 212 | protocolOf, ResourceRegistry, RESOURCE_SCHEME | @deepseek-ai/cordis, @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-client-store |
| packages/client/resources/src/index.ts | 5 | apply | — |
| packages/client/resources/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/shortcuts — @deepseek-ai/dsh-client-shortcuts@0.2.1-alpha.1（14 文件 / 1266 行）

职责：键盘命令注册


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/shortcuts/src/binding.ts | 113 | normalizeBinding, bindingKey, presentBinding, isWebBindingAllowed, ShortcutCommandId, ShortcutPlatform, ShortcutRuntime, ShortcutProfile …等11项 | @deepseek-ai/dsh-brand |
| packages/client/shortcuts/src/client/dom.ts | 117 | detectEnvironment, installKeyboard | @deepseek-ai/dsh-client-ui-primitives |
| packages/client/shortcuts/src/client/index.ts | 160 | ShortcutsService | @deepseek-ai/cordis, @deepseek-ai/dsh-client-locale |
| packages/client/shortcuts/src/client/native.ts | 46 | installNativeKeyboard | @deepseek-ai/dsh-client-ui-primitives |
| packages/client/shortcuts/src/client/registry.ts | 181 | ShortcutRegistry | @deepseek-ai/dsh-client-store |
| packages/client/shortcuts/src/client/storage.ts | 41 | webShortcutStorage, desktopShortcutStorage, SHORTCUT_STORAGE_KEY | — |
| packages/client/shortcuts/src/client/types.ts | 139 | ShortcutRegion, ShortcutContext, ShortcutResolution, ShortcutCommand, ShortcutCatalogEntry, ShortcutGesture, ShortcutFixedInput, ShortcutFixedCommand …等10项 | @deepseek-ai/dsh-client-store |
| packages/client/shortcuts/src/config.ts | 14 | Config | @deepseek-ai/schemastery |
| packages/client/shortcuts/src/configuration.ts | 245 | parseBinding, parseShortcutDocument, bindingIssue, resolveShortcutDefault, effectiveShortcuts, overlappingBindings, editShortcutDocument, parseShortcutEdit …等14项 | @deepseek-ai/dsh-util-values |
| packages/client/shortcuts/src/index.ts | 21 | apply | @deepseek-ai/cordis, @deepseek-ai/dsh-host-webserver |
| packages/client/shortcuts/src/native.ts | 30 | DesktopShortcutInput, DesktopKeyboardApi | — |
| packages/client/shortcuts/src/persistence.ts | 145 | initialShortcutConfig, ShortcutPersistence, ShortcutRevision, ShortcutConfigSnapshot, ShortcutSaveResult, ShortcutStorage, DesktopShortcutsApi | @deepseek-ai/dsh-util-crypto, @deepseek-ai/dsh-brand |
| packages/client/shortcuts/src/protocol.ts | 6 | — | — |
| packages/client/shortcuts/tsdown.config.ts | 8 | clientBundle | — |

#### packages/client/store — @deepseek-ai/dsh-client-store@0.2.1-alpha.1（3 文件 / 402 行）

职责：React-free observable/snapshot-store 原语（zustand vanilla+immer）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/store/src/contract.ts | 144 | ObservableSnapshot, SnapshotSelectorHook, MaybeSnapshotSelectorHook, ActionsDecl, BakedActions, StoreSpec, StoreInstance, StoreHandle …等14项 | — |
| packages/client/store/src/index.ts | 251 | notifySubscribers, shallowEqual, createSnapshotStore, defineStore, SnapshotStore, EngineStoreInstance, EngineStoreHandle | zustand, immer |
| packages/client/store/tsdown.config.ts | 7 | staticLinked | — |

#### packages/client/tsdown.client.ts — packages/client/tsdown.client.ts（1 文件 / 734 行）

职责：client face 的 tsdown bundle 配置（构建辅助）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/tsdown.client.ts | 734 | clientBundle, staticLinked, isStaticLinkedConfig, clientLibrary, clientOnly, requestedExternals, INLINE_SAFE, $ | node:fs, node:module, node:path, node:url, tsdown |

#### packages/client/ui-agent-preset — @deepseek-ai/dsh-client-ui-agent-preset@0.2.1-alpha.1（13 文件 / 1810 行）

职责：agent preset 选择/管理 UI


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-agent-preset/src/client/AgentPresetLabel.tsx | 69 | AgentPresetLabel, AgentPresetLabelInjected, AgentPresetLabelProps | react, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-agent-preset/src/client/AgentPresetSeat.tsx | 222 | AgentPresetSeat, AgentPresetSeatInjected, AgentPresetSeatProps | react, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-agent-preset/src/client/AgentPresetSection.tsx | 177 | AgentPresetSection, AgentPresetSectionInjected, AgentPresetSectionProps | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-agent-preset/src/client/CreatePluginMenuItem.tsx | 51 | CreatePluginMenuItem, CreatePluginMenuItemInjected | react, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-plugin-manager, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-agent-preset/src/client/guide-locales.ts | 153 | guideEn, guideZh, PresetGuideKey | — |
| packages/client/ui-agent-preset/src/client/index.ts | 276 | apply, inject | @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-session, @deepseek-ai/dsh-util-values, @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-api-remotes |
| packages/client/ui-agent-preset/src/client/locales.ts | 128 | en, zh, AgentPresetSettingsKey | @deepseek-ai/dsh-agent-preset-registry |
| packages/client/ui-agent-preset/src/client/PresetGuideDialog.tsx | 161 | presetGuide, trapPresetReaderTab, PresetGuideDialog, PresetGuidePage | react, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-agent-preset/src/client/seat-store.ts | 256 | AgentPresetSeatController, AgentPresetSeatState, AgentPresetStage | @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-agent-preset-registry |
| packages/client/ui-agent-preset/src/client/section-store.ts | 123 | AgentPresetSectionController, PresetView, AgentPresetSectionState | @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-agent-preset-registry |
| packages/client/ui-agent-preset/src/client/settings-store.ts | 180 | writeDefaultPreset, requiresCodingTools, readRoster, beginRosterRead, presetOptions, AgentPresetSettingsController, AGENT_PRESET_SETTINGS_NS, AgentPresetOption …等11项 | @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-agent-preset-registry |
| packages/client/ui-agent-preset/src/index.ts | 10 | apply | — |
| packages/client/ui-agent-preset/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-approval — @deepseek-ai/dsh-client-ui-approval@0.2.1-alpha.1（6 文件 / 424 行）

职责：审批交互 UI（answerer 接 approval waterfall）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-approval/src/client/ApprovalPanel.tsx | 89 | ApprovalPanel | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-approval/src/client/contract/slots.ts | 195 | PendingApproval, ApprovalDetailOwnerProps, ApprovalPresentationRequest, ApprovalDecision, ApprovalInteractionKind, ApprovalInjected, ApprovalComposerProps | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-approval/src/client/index.ts | 108 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-client-ui-renderer |
| packages/client/ui-approval/src/client/locales.ts | 23 | zh, en, ApprovalKey | — |
| packages/client/ui-approval/src/index.ts | 5 | apply | — |
| packages/client/ui-approval/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-attachment — @deepseek-ai/dsh-client-ui-attachment@0.2.1-alpha.1（11 文件 / 867 行）

职责：附件呈现（图片/文件卡）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-attachment/src/AttachmentRail.tsx | 172 | AttachmentRail, AttachmentRailItem, AttachmentRailLabels | react, clsx, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-attachment/src/client/ComposerAttachments.tsx | 109 | ComposerAttachments | react, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-attachment/src/client/drop-events.ts | 88 | installDocumentDropEvents | @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-attachment/src/client/index.ts | 35 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-chat, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-client-ui-renderer, @deepseek-ai/dsh-client-ui-tool |
| packages/client/ui-attachment/src/client/labels.ts | 80 | lightboxLabels, messageImageLabels, dropOverlayLabels, fileCardLabels, attachmentRailLabels | @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-attachment/src/client/MessageImages.tsx | 18 | MessageImages | @deepseek-ai/dsh-client-ui-chat |
| packages/client/ui-attachment/src/DropOverlay.tsx | 78 | DropOverlay, DropOverlayLabels | react-dom |
| packages/client/ui-attachment/src/FileCard.tsx | 82 | FileCard, FileCardLabels, FileCardState | @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-attachment/src/index.ts | 5 | apply | — |
| packages/client/ui-attachment/src/MessageImage.tsx | 193 | MessageImage, ImageGallery, ImageLoader, MessageImageSpec, MessageImageLabels | react, @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-attachment/tsdown.config.ts | 7 | clientBundle | — |

#### packages/client/ui-brand-official — @deepseek-ai/dsh-client-ui-brand-official@0.2.1-alpha.1（4 文件 / 56 行）

职责：官方品牌外观注入


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-brand-official/src/client/Brand.tsx | 20 | OfficialBrandMark, OfficialBrandName | @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-sidebar |
| packages/client/ui-brand-official/src/client/index.ts | 24 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-renderer, @deepseek-ai/dsh-client-ui-sidebar |
| packages/client/ui-brand-official/src/index.ts | 8 | apply | — |
| packages/client/ui-brand-official/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-chat — @deepseek-ai/dsh-client-ui-chat@0.2.1-alpha.1（92 文件 / 12537 行）

职责：Chat 视图：conversation-nodes 定义组 + 渲染层 + 滚动 hooks


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-chat/src/chat-settings.ts | 69 | CHAT_SETTINGS_NAMESPACE, TRANSCRIPT_VIEW_FIELD, TRANSCRIPT_VIEW_MODES, LEGACY_TRANSCRIPT_VIEW_MODE, LEGACY_EXPANDED_TRANSCRIPT_VIEW_MODE, DEFAULT_TRANSCRIPT_VIEW_MODE, PERFORMANCE_USAGE_MODES, DEFAULT_PERFORMANCE_USAGE …等15项 | @deepseek-ai/schemastery |
| packages/client/ui-chat/src/client/apply.ts | 299 | apply, inject | @deepseek-ai/dsh-client-product-analytics, @deepseek-ai/cordis, @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-api-session-controller |
| packages/client/ui-chat/src/client/chat/ApprovalCommand.tsx | 41 | commandOf, ApprovalCommand | @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-approval |
| packages/client/ui-chat/src/client/chat/AssistantMarkdown.tsx | 164 | localPathMediaUrl, AssistantMarkdown, AssistantMarkdownProps | react, @deepseek-ai/dsh-util-workspace-path, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-chat/src/client/chat/AssistantNodeView.tsx | 48 | AssistantNodeView | react, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-chat/src/client/chat/ChatGroupSeat.tsx | 192 | ChatGroupSeat | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-chat/src/client/chat/ChatNodeSeat.tsx | 175 | ChatNodeSeat | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-chat/src/client/chat/ChatView.tsx | 338 | ChatView | react, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-chat/src/client/chat/CommandNodeView.tsx | 41 | CommandNodeView, ManualCompactionNodeView | react, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-chat/src/client/chat/CompactionCommandCard.tsx | 27 | CompactionCommandCard | — |
| packages/client/ui-chat/src/client/chat/CompactionItem.tsx | 77 | CompactionItem | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-chat/src/client/chat/ContextBody.tsx | 593 | OpaqueBody, InstructionsBody, CatalogBody, SnapshotBody, NoticeBody, RelayBody, RecallBody, contextBody | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-chat/src/client/chat/ContextInjectionRow.tsx | 95 | ContextInjectionRow, ContextInjectionRowProps | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-chat/src/client/chat/GenericCommandCard.tsx | 76 | GenericCommandCard, GenericCommandCardProps | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-chat/src/client/chat/message-chrome.ts | 101 | startOfLocalDay, msUntilNextLocalMidnight, formatRunDuration, formatTokensPerSecond, formatMessageClock, LIVE_RUN_CLOCK_INTERVAL_MS, ClockTranslate, RunDurationTranslate …等9项 | @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-chat/src/client/chat/MessageIconActions.tsx | 116 | MessageIconActions, MessageIconActionsProps | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-chat/src/client/chat/MessageItem.tsx | 393 | PendingSteeringBubble, PendingSubmissionBubble, UserMessageNodeView, ContextMessageNodeView, CompactionNodeView, RetryNodeView, TurnErrorNodeView, TurnMaxTokensNodeView …等9项 | react, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-chat/src/client/chat/QuotaNoticeHost.tsx | 28 | QuotaNoticeHost | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-chat/src/client/chat/ReasoningRow.tsx | 103 | ReasoningRow | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-chat/src/client/chat/register-node-renderers.ts | 77 | registerChatNodeRenderers | @deepseek-ai/cordis, @deepseek-ai/dsh-client-store |
| packages/client/ui-chat/src/client/chat/render-entry.ts | 17 | chatRenderKey | @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-util-values |
| packages/client/ui-chat/src/client/chat/RunningStatus.tsx | 42 | RunningStatus | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-chat/src/client/chat/RunningWhaleTail.tsx | 20 | RunningWhaleTail | — |
| packages/client/ui-chat/src/client/chat/searchable-hidden.ts | 32 | useSearchableHidden | react |
| packages/client/ui-chat/src/client/chat/stat-dialog.ts | 77 | useStatDialog, MEASURE_STYLE, StatDialogSeat | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-chat/src/client/chat/StatsPills.tsx | 335 | deriveStats, formatDuration, cacheHitPercent, billedInputTokens, ActivityPill, UsagePill, StatPillProps | react, react-dom, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-chat/src/client/chat/step-process.ts | 29 | processTitle | — |
| packages/client/ui-chat/src/client/chat/SystemPromptRow.tsx | 51 | SystemPromptRow, SystemPromptNodeView, SystemPromptRowProps | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-chat/src/client/chat/token-format.ts | 99 | formatTokens, formatExactTokens, formatCacheHitPercent | — |
| packages/client/ui-chat/src/client/chat/turn-assistant.ts | 11 | assistantText | — |
| packages/client/ui-chat/src/client/chat/turn-rail-items.ts | 90 | mergeTurnRailItems, TurnRailItem | @deepseek-ai/dsh-session-turn-outline, @deepseek-ai/dsh-session |
| packages/client/ui-chat/src/client/chat/turn-trigger.ts | 72 | turnTriggerDetails, TurnTriggerIcon | — |
| packages/client/ui-chat/src/client/chat/TurnNavigator.tsx | 296 | TurnNavigator, TurnNavigatorHandle | react, @tanstack/react-virtual |
| packages/client/ui-chat/src/client/chat/TurnProcessNodeView.tsx | 62 | TurnProcessNodeView | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-chat/src/client/chat/TurnTailNodeView.tsx | 81 | TurnTailNodeView | react, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-chat/src/client/chat/TurnTriggerNodeView.tsx | 51 | TurnTriggerNodeView | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-chat/src/client/chat/TurnUsagePanel.tsx | 111 | TurnUsagePanel, TurnUsagePanelProps | react-dom, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-chat/src/client/chat/use-calendar-day.ts | 26 | useCalendarDay | react |
| packages/client/ui-chat/src/client/chat/use-chat-navigation.ts | 207 | useChatNavigation, ChatNavigation, ChatNavigationInput | react, @deepseek-ai/dsh-session |
| packages/client/ui-chat/src/client/chat/use-chat-reading.ts | 230 | useChatReading, ChatReading, ChatReadingState, ReadingSample | react |
| packages/client/ui-chat/src/client/chat/use-chat-scroll.ts | 139 | useChatScroll, ChatScrollInput | react |
| packages/client/ui-chat/src/client/chat/use-chat-viewport.ts | 474 | useChatViewport, ChatViewport, ViewportScroll, ViewportLanding | react |
| packages/client/ui-chat/src/client/chat/use-disclosure.ts | 36 | useDisclosure, bindDisclosure | react, @deepseek-ai/dsh-client-store |
| packages/client/ui-chat/src/client/chat/use-process-scroll.ts | 89 | useProcessScroll | react |
| packages/client/ui-chat/src/client/chat/use-scroll-follow.ts | 174 | scrollMetrics, useScrollFollow, ScrollFollow, ViewportMetrics | react |
| packages/client/ui-chat/src/client/chat/use-turn-data.ts | 24 | useTurnDataValue | react, @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-chat/src/client/contract/assistant-content.ts | 16 | hasAssistantReplyContent | @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-chat/src/client/contract/chat-nodes.ts | 128 | isSettledTool, isRunningTool, ChatConversationViewNode, ChatNodeDataMap, ChatNodeKind, ChatNode, AssistantChatData, FinalAssistantChatData …等15项 | @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-chat/src/client/contract/chat-visibility.ts | 17 | isVisibleChatNode | — |
| packages/client/ui-chat/src/client/contract/process-groups.ts | 26 | ProcessActivity, ProcessActivitySummary, ProcessGroupData | — |
| packages/client/ui-chat/src/client/contract/slots.ts | 332 | UseChat, UseChatNode, UseChatNodeProcess, UsePresentation, OpenFileOptions, TurnTailOwnerProps, AssistantActionOwnerProps, QuotaNoticeCode …等29项 | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-store |
| packages/client/ui-chat/src/client/contract/snapshot.ts | 161 | EMPTY_CHAT_SNAPSHOT, ChatNodeSource, ChatNodeProcessSource, ChatNodeStore, TurnNavigationItem, ChatTurnNavigationIndex, ChatLocationNodeIndex, ChatTurnProcessPresentation …等10项 | @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-client-store |
| packages/client/ui-chat/src/client/contract/store.ts | 16 | ToolCallId, TurnProcessViewEntry, ChatStoreState | — |
| packages/client/ui-chat/src/client/contract/turn-metrics.ts | 44 | assistantStepReading, StepReading | @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-chat/src/client/contract/turn-process.ts | 75 | sameTurnProcessSpec, isSubagentDelegationTool, turnProcessAlwaysOpen, TURN_PROCESS_INDEPENDENT_KINDS, TurnProcessSpec | — |
| packages/client/ui-chat/src/client/conversation-nodes/assistant.ts | 374 | registerAssistantConversationNode, assistantDefinition | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-llm-retry, @deepseek-ai/dsh-session |
| packages/client/ui-chat/src/client/conversation-nodes/chat-snapshot-builder.ts | 1216 | orderedVisibleChatNodes, registerChatConversationView, SkillNameProjector, ChatSnapshotBuilder, chatViewDefinition | @deepseek-ai/cordis, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-chat/src/client/conversation-nodes/command.ts | 228 | updateCompactionState, registerCommandConversationNode, commandDefinition | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-compaction, @deepseek-ai/dsh-commands, @deepseek-ai/dsh-session |
| packages/client/ui-chat/src/client/conversation-nodes/common.ts | 70 | contextLocation, chatNode, coordinate, CHAT_SYNTHETIC_SEQ_OFFSETS | @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-chat/src/client/conversation-nodes/compaction.ts | 66 | registerCompactionConversationNode, compactionDefinition | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-compaction |
| packages/client/ui-chat/src/client/conversation-nodes/event-projection.ts | 180 | contextForm, contextProducer, sessionRecallLabels, skillInvocationName, toAssistantBlocks, toAssistantBlock, emptyAssistantBlock, displayFailure …等10项 | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-chat/src/client/conversation-nodes/fallback.ts | 42 | registerUnknownConversationFallback, unknownFallbackDefinition | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-session |
| packages/client/ui-chat/src/client/conversation-nodes/inbox.ts | 144 | registerInboxConversationNodes, nextStepInboxDefinition, nextTurnInboxDefinition, InboxState | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-chat/src/client/conversation-nodes/message.ts | 144 | registerMessageConversationNode, messageDefinition, developerMessageDefinition | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-session |
| packages/client/ui-chat/src/client/conversation-nodes/process-activity.ts | 168 | processActivity | @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-chat/src/client/conversation-nodes/process-groups.ts | 323 | ProcessState, processGroupDefinition | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-chat/src/client/conversation-nodes/register.ts | 39 | registerConversationNodes | @deepseek-ai/cordis |
| packages/client/ui-chat/src/client/conversation-nodes/request-prompt.ts | 164 | systemMessageDefinition, requestPromptDefinition, registerRequestPromptConversationNode | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-chat/src/client/conversation-nodes/retry.ts | 98 | registerRetryConversationNode, retryDefinition, RetryState | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-llm-retry |
| packages/client/ui-chat/src/client/conversation-nodes/tool.ts | 370 | registerToolConversationNode, toolDefinition | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-session, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-util-values |
| packages/client/ui-chat/src/client/conversation-nodes/turn-error.ts | 105 | registerTurnErrorConversationNode, turnErrorDefinition | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-chat/src/client/conversation-nodes/turn-max-tokens.ts | 83 | registerTurnMaxTokensConversationNode, turnMaxTokensDefinition | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-chat/src/client/conversation-nodes/turn-navigation.ts | 98 | sameTurnNavigationItem, turnNavigationItem | — |
| packages/client/ui-chat/src/client/conversation-nodes/turn-process-presentation.ts | 146 | ChatTurnProcessProjector | — |
| packages/client/ui-chat/src/client/conversation-nodes/turn-process.ts | 324 | registerTurnProcess, turnProcessDefinition | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-llm-retry, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-tools |
| packages/client/ui-chat/src/client/conversation-nodes/turn-tail.ts | 165 | registerTurnTailConversationNode, turnTailDefinition | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-llm-retry, @deepseek-ai/dsh-session, @deepseek-ai/dsh-token-meter |
| packages/client/ui-chat/src/client/index.ts | 65 | ChatNodeDataMap | @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-chat/src/client/locale.ts | 388 | NS, zh, en, ChatKey | — |
| packages/client/ui-chat/src/client/markdown-labels.ts | 17 | markdownLabels | @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-chat/src/client/model/conversation-context.ts | 25 | ConversationContextOriginKind, ConversationContext | @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-chat/src/client/model/steering-history.ts | 65 | SteeringHistory | @deepseek-ai/dsh-session, @deepseek-ai/dsh-agent |
| packages/client/ui-chat/src/client/model/tool-call-tree.ts | 205 | ToolCallTree, MAX_TOOL_CALL_TREE_DEPTH | @deepseek-ai/dsh-session, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-util-values |
| packages/client/ui-chat/src/client/performance-usage.ts | 35 | PerformanceUsagePolicy | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-settings |
| packages/client/ui-chat/src/client/presentation-policy.ts | 79 | presentationPolicyFor, derivePresentationPolicy, ChatPresentationPolicy | @deepseek-ai/dsh-client-store |
| packages/client/ui-chat/src/client/settings/LinkOpeningRow.tsx | 48 | LinkOpeningRow, LinkOpeningRowInjected, LinkOpeningRowProps | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-chat/src/client/settings/PerformanceUsageRow.tsx | 47 | PerformanceUsageRow, PerformanceUsageRowInjected, PerformanceUsageRowProps | @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-chat/src/client/settings/PreferenceRow.tsx | 60 | PreferenceRow | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-chat/src/client/settings/TranscriptViewRow.tsx | 50 | TranscriptViewRow, TranscriptViewRowInjected, TranscriptViewRowProps | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-chat/src/client/stores.ts | 48 | storedTurnProcessEntry, createChatStore | @deepseek-ai/dsh-client-store |
| packages/client/ui-chat/src/client/transcript-view.ts | 52 | TranscriptViewPolicy | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-settings |
| packages/client/ui-chat/src/index.ts | 40 | apply, Config | @deepseek-ai/dsh-settings, @deepseek-ai/cordis, @deepseek-ai/schemastery |
| packages/client/ui-chat/tsdown.config.ts | 23 | — | node:fs, node:url |

#### packages/client/ui-commands — @deepseek-ai/dsh-client-ui-commands@0.2.1-alpha.1（12 文件 / 1712 行）

职责：斜杠命令 UI（命令面板）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-commands/src/client/contract.ts | 151 | SelectConfirmation, SelectOptionGroup, PopupSearchMode, SelectOption, PopupSearchLabels, PopupSelectSpec, ActionSpec, CommandUiSpec …等11项 | react, @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-input-trigger, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-commands/src/client/directory.ts | 186 | CommandDirectory, DirectoryStatus, FetchCommands | @deepseek-ai/dsh-commands, @deepseek-ai/dsh-session |
| packages/client/ui-commands/src/client/index.ts | 77 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-renderer |
| packages/client/ui-commands/src/client/locales.ts | 74 | zh, en, CommandKey | — |
| packages/client/ui-commands/src/client/option-groups.ts | 25 | groupOptions | — |
| packages/client/ui-commands/src/client/popup.ts | 332 | filterOptions, PopupSelectController, TokenSegment, PopupSpec, PopupSelectDeps, PopupState | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-input-trigger, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-commands/src/client/PopupSelectView.tsx | 213 | PopupSelectView, PopupSelectInjected, PopupSelectViewProps | @deepseek-ai/dsh-client-ui-primitives, react, clsx, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-commands/src/client/presentation.ts | 87 | builtinRowFace, sectionRows, MenuSection | react, @deepseek-ai/dsh-client-ui-input-trigger, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-commands |
| packages/client/ui-commands/src/client/resolution.ts | 60 | builtinCommandName, claimToken, resolveCommand, BuiltinCommandName | @deepseek-ai/dsh-commands, @deepseek-ai/dsh-client-locale |
| packages/client/ui-commands/src/client/service.ts | 492 | CommandUiRuntime | @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-commands, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-session |
| packages/client/ui-commands/src/index.ts | 11 | apply | — |
| packages/client/ui-commands/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-conversation — @deepseek-ai/dsh-client-ui-conversation@0.2.1-alpha.1（72 文件 / 13013 行）

职责：Conversation 引擎：节点定义/视图构建器 + composer 输入面


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-conversation/src/client/apply.ts | 554 | apply, inject, Config | @deepseek-ai/dsh-client-product-analytics, @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-conversation/src/client/context-occupancy.ts | 26 | contextOccupancy, ContextOccupancy | @deepseek-ai/dsh-token-meter |
| packages/client/ui-conversation/src/client/contract/composer-blocks.ts | 30 | ComposerBlock, ComposerBlocks | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-session |
| packages/client/ui-conversation/src/client/contract/composer-submission.ts | 28 | InputSubmitMode, ComposerSubmitGesture, MessageSubmissionState, MessageSubmission | @deepseek-ai/dsh-session |
| packages/client/ui-conversation/src/client/contract/context-producer.ts | 32 | ContextRole, ContextProducerView, KnownContextForm | — |
| packages/client/ui-conversation/src/client/contract/conversation.ts | 334 | conversationContextKey, ConversationMatchResult, ConversationTurnDataMap, ConversationStepDataMap, ConversationLocationDataSource, ConversationLocationDataStore, ConversationLocationData, StepLocation …等26项 | @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-session |
| packages/client/ui-conversation/src/client/contract/draft-editor.ts | 121 | TokenSpan, ReferenceInsert, DraftReference, DraftSnapshot, DraftInput, ArbitrateKey, ArbitrateOutcome, ComposerKeyboard …等10项 | lexical |
| packages/client/ui-conversation/src/client/contract/groups.ts | 135 | NodeKey, GroupKey, NodeReference, GroupReference, RenderEntry, GroupSnapshot, GroupUpdate, NodeChange …等15项 | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-client-store |
| packages/client/ui-conversation/src/client/contract/input.ts | 355 | SubmitAttachment, DraftAttachmentSerializationResult, SubmitOutcome, CommandClaim, PickOutcome, BeginCommandRequest, InsertReferenceRequest, ConsumeTokenRequest …等24项 | @deepseek-ai/cordis, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-brand |
| packages/client/ui-conversation/src/client/contract/records.ts | 316 | AssistantRequestConfig, AssistantProviderMetadataView, AssistantBlock, UserMessageNode, AssistantTiming, AssistantMessageNode, SteeringMessageNode, ContextMessageNode …等22项 | @deepseek-ai/dsh-commands, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-llm-retry, @deepseek-ai/dsh-tool-todo |
| packages/client/ui-conversation/src/client/contract/request-inspection.ts | 182 | inspectRequestPrompt, ConversationPromptSnapshot, SystemPromptNode, RequestPromptChange, RequestPromptInspection, RequestPromptInspector, RequestView, RequestInspectionSnapshot | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session |
| packages/client/ui-conversation/src/client/contract/slots.ts | 524 | ComposerAttachment, ComposerImageAttachment, ComposerFileAttachment, DraftFileUpload, DraftFileUploads, ComposerAttachmentsOwnerProps, MessageImageSource, MessageImageLoader …等42项 | react, @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-client-file-upload, @deepseek-ai/dsh-api-workspace-controller |
| packages/client/ui-conversation/src/client/contract/snapshot.ts | 35 | conversationPhase, EMPTY_CONVERSATION_SNAPSHOT, ConversationSnapshot, ConversationPhase | @deepseek-ai/dsh-api-session-controller |
| packages/client/ui-conversation/src/client/contract/system-prompt.ts | 86 | inspectSystemPrompt, SystemPromptState, SystemPromptInspector | @deepseek-ai/dsh-session |
| packages/client/ui-conversation/src/client/contract/views.ts | 27 | ViewTab, ConversationViewRequest, ConversationStoreState | — |
| packages/client/ui-conversation/src/client/conversation/assembler.ts | 1079 | ConversationNodeAssembler, ConversationEventDefinitions, ConversationViewDefinitions, ConversationGroupDefinitions | @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-llm |
| packages/client/ui-conversation/src/client/conversation/assembly.ts | 331 | UiConversation, ConversationBinding | @deepseek-ai/cordis, @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-session, @deepseek-ai/dsh-util-values |
| packages/client/ui-conversation/src/client/conversation/definition-registry.ts | 69 | ConversationDefinitionRegistry | @deepseek-ai/cordis, @deepseek-ai/dsh-client-store |
| packages/client/ui-conversation/src/client/conversation/event-registry.ts | 118 | ConversationEventRegistry, ConversationEventRoute | — |
| packages/client/ui-conversation/src/client/conversation/group-registry.ts | 49 | ConversationGroupRegistry | @deepseek-ai/cordis |
| packages/client/ui-conversation/src/client/conversation/group-store.ts | 230 | ConversationGroupStore | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-util-values |
| packages/client/ui-conversation/src/client/conversation/historical-images.ts | 182 | HistoricalImageCache | @deepseek-ai/cordis, @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-session, @deepseek-ai/dsh-util-crypto |
| packages/client/ui-conversation/src/client/conversation/location-index.ts | 656 | ConversationLocationIndex, ConversationLocationDataChange | @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-session |
| packages/client/ui-conversation/src/client/conversation/view-registry.ts | 21 | ConversationViewRegistry | — |
| packages/client/ui-conversation/src/client/draft.ts | 83 | resolveDraftInput, parseStoredDraft, snapshotDraft | zod |
| packages/client/ui-conversation/src/client/image-labels.ts | 60 | imageSizeText, attachmentErrorText | @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-conversation/src/client/index.ts | 90 | — | — |
| packages/client/ui-conversation/src/client/input/blocks.ts | 45 | ComposerBlockRegistry | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-session |
| packages/client/ui-conversation/src/client/input/decorations.ts | 71 | scanTextRefs, TextRefRange | — |
| packages/client/ui-conversation/src/client/input/editor/chip-node.tsx | 215 | $createReferenceChipNode, $isReferenceChipNode, ReferenceChipNode, SerializedReferenceChipNode | react, lexical |
| packages/client/ui-conversation/src/client/input/editor/claim-decor.ts | 69 | registerClaimDecoration, refreshClaimDecoration | lexical |
| packages/client/ui-conversation/src/client/input/editor/ComposerContentEditable.tsx | 51 | ComposerContentEditable, ComposerContentEditableProps | react, lexical |
| packages/client/ui-conversation/src/client/input/editor/DecoratorPortals.tsx | 42 | DecoratorPortals, DecoratorPortalsProps | react, react-dom, lexical |
| packages/client/ui-conversation/src/client/input/editor/DraftEditor.tsx | 64 | DraftEditor, DraftEditorProps | react, lexical, clsx |
| packages/client/ui-conversation/src/client/input/editor/keymap.ts | 188 | registerComposerKeymap, ComposerKeymapHandlers | lexical, @lexical/utils |
| packages/client/ui-conversation/src/client/input/editor/projection.ts | 231 | $composerLayout, detectOffsetOfClipboardOffset, $detectOffsetOfPoint, $projectComposer, ATOMIC_CHAR, ComposerSegment, ComposerLayout, EditorProjection | lexical |
| packages/client/ui-conversation/src/client/input/editor/reference-activation.ts | 34 | registerReferenceActivation | lexical |
| packages/client/ui-conversation/src/client/input/editor/ReferenceChip.tsx | 37 | ReferenceChip, ReferenceChipProps | clsx, react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-conversation/src/client/input/editor/runtime.ts | 352 | DraftEditorRuntime | @deepseek-ai/dsh-client-store, lexical, @lexical/plain-text, @lexical/history, @lexical/utils |
| packages/client/ui-conversation/src/client/input/editor/span-map.ts | 120 | $selectDetectSpan, $replaceDetectSpanWithText, $replaceDetectSpanWithNodes, DetectSpan | lexical |
| packages/client/ui-conversation/src/client/input/editor/text-ref.ts | 117 | registerTextRefDecoration, rescanTextRefs, TextRefNode, SerializedTextRefNode | clsx, lexical, @lexical/text, @lexical/utils |
| packages/client/ui-conversation/src/client/input/editor/view-binding.ts | 156 | revealDraftSelection, focusDraftEditor, installDraftWheel, installDraftFilePicker, installDraftKeymap, keepDraftFocus | react, lexical |
| packages/client/ui-conversation/src/client/input/facade.ts | 903 | SessionInputShell, PopupDismissFace, SessionInputDeps | @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-client-store, lexical |
| packages/client/ui-conversation/src/client/input/hub.ts | 293 | InputHub | @deepseek-ai/dsh-client-product-analytics, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-plan-mode, @deepseek-ai/dsh-goal, @deepseek-ai/cordis |
| packages/client/ui-conversation/src/client/input/machine.ts | 244 | SubmitMachine, SubmitSnapshot | — |
| packages/client/ui-conversation/src/client/input/submission-analytics.ts | 22 | reportMessageSubmission | @deepseek-ai/cordis, @deepseek-ai/dsh-client-product-analytics |
| packages/client/ui-conversation/src/client/input/submission-policy.ts | 87 | resolveSubmitMode, ComposerSubmissionPolicy | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-settings |
| packages/client/ui-conversation/src/client/locales.ts | 760 | NS, zh, en, ConversationKey | — |
| packages/client/ui-conversation/src/client/queue/QueueDock.tsx | 412 | QueueDock, queueDockEntry, QueueDockInjected, QueueDockProps | @deepseek-ai/cordis, react, @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-session |
| packages/client/ui-conversation/src/client/service.ts | 609 | isImageMediaType, UnsupportedImageMediaTypeError, ConversationController, IConversation | @deepseek-ai/cordis, @deepseek-ai/dsh-util-crypto, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-client-file-upload, @deepseek-ai/dsh-session |
| packages/client/ui-conversation/src/client/settings/EnterBehaviorRow.tsx | 77 | EnterBehaviorRow, EnterBehaviorRowInjected, EnterBehaviorRowProps | react, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-conversation/src/client/skeleton/ContextMeter.tsx | 181 | ContextMeter, ContextMeterProps | react, react-dom, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-token-meter, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-conversation/src/client/skeleton/control-row-layout.ts | 40 | observeControlRow | — |
| packages/client/ui-conversation/src/client/skeleton/ConversationContent.tsx | 205 | ConversationContent | react, clsx, @deepseek-ai/dsh-workspace, @deepseek-ai/dsh-api-workspace-controller |
| packages/client/ui-conversation/src/client/skeleton/ConversationHeader.tsx | 28 | ConversationHeader | clsx |
| packages/client/ui-conversation/src/client/skeleton/ConversationMainPanel.tsx | 58 | ConversationMainPanel | — |
| packages/client/ui-conversation/src/client/skeleton/ConversationPanel.tsx | 13 | ConversationPanel | @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-conversation/src/client/skeleton/ConversationRoot.tsx | 14 | ConversationRoot, ConversationRootProps | — |
| packages/client/ui-conversation/src/client/skeleton/ConversationSession.tsx | 171 | ConversationSessionHeader, ConversationSession, ConversationSessionProps, ConversationSessionHeaderProps | clsx, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-session |
| packages/client/ui-conversation/src/client/skeleton/ConversationWidthControls.tsx | 183 | ConversationWidthControls | react |
| packages/client/ui-conversation/src/client/skeleton/DefaultConversationViews.tsx | 45 | DefaultConversationViews | react |
| packages/client/ui-conversation/src/client/skeleton/EmptyHero.tsx | 166 | workspaceLabel, WorkspaceChip, HeroShell, HeroShellProps | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-util-workspace-path |
| packages/client/ui-conversation/src/client/skeleton/InputBar.tsx | 508 | InputBar, InputBarProps | react, clsx, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-plan-mode, @deepseek-ai/dsh-goal |
| packages/client/ui-conversation/src/client/skeleton/safari.ts | 43 | isSafariBrowser, repairSafariTextareaLayout, BrowserIdentity | — |
| packages/client/ui-conversation/src/client/skeleton/TodoPanel.tsx | 120 | TodoPanel, TodoDock, todoDockEntry, TodoPanelProps, TodoDockProps | react, @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-tool-todo, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-conversation/src/client/stop-sequence.ts | 53 | StopSequence, StopTarget | @deepseek-ai/dsh-session |
| packages/client/ui-conversation/src/client/stop-shortcut.ts | 66 | installStopShortcut | @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-client-shortcuts, @deepseek-ai/dsh-client-ui-session, @deepseek-ai/dsh-session, @deepseek-ai/dsh-client-store |
| packages/client/ui-conversation/src/client/stores.ts | 75 | createConversationStore, readConversationDraft, readConversationViewPreference | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-session |
| packages/client/ui-conversation/src/client/view-selection.ts | 22 | resolveActiveView, DEFAULT_VIEW_ID, TRAJECTORY_VIEW_ID | — |
| packages/client/ui-conversation/src/index.ts | 33 | apply, Config | @deepseek-ai/dsh-settings, @deepseek-ai/cordis, @deepseek-ai/schemastery |
| packages/client/ui-conversation/src/submission-settings.ts | 33 | CONVERSATION_SETTINGS_NAMESPACE, BUSY_ENTER_FIELD, BUSY_ENTER_BEHAVIORS, DEFAULT_BUSY_ENTER_BEHAVIOR, ConversationSettingsFields, ConversationSettingsSchema, BusyEnterBehavior, ConversationSettings | @deepseek-ai/schemastery |
| packages/client/ui-conversation/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-deliverables — @deepseek-ai/dsh-client-ui-deliverables@0.2.1-alpha.1（21 文件 / 2289 行）

职责：turn 交付物呈现


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-deliverables/src/changes.ts | 166 | isChangedFile, isChangesSummary, isChangesDiff, isChangesEvent, changesSummaryUrl, changesDiffUrl, changedFileUrl, changesReviewAddress …等19项 | @deepseek-ai/dsh-session, @deepseek-ai/dsh-workspace-changes |
| packages/client/ui-deliverables/src/client/ChangedFiles.tsx | 123 | ChangedFiles | react, @deepseek-ai/dsh-util-workspace-path, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-deliverables/src/client/changes-diff.ts | 39 | ChangesDiffStore, ChangesDiffState | @deepseek-ai/dsh-session |
| packages/client/ui-deliverables/src/client/changes-summary.ts | 34 | ChangesSummaryStore, ChangesSummaryState | @deepseek-ai/dsh-session |
| packages/client/ui-deliverables/src/client/Deliverables.tsx | 130 | selectDeliverables, DeliverablesTail, Deliverables, DeliverablesInjected | react, @deepseek-ai/dsh-client-ui-chat, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-store |
| packages/client/ui-deliverables/src/client/file-actions.ts | 28 | — | — |
| packages/client/ui-deliverables/src/client/FileDiff.tsx | 259 | hunkRows, splitRows, renderedHunks, FileDiff, MAX_RENDERED_LINES, DiffRow, SplitRow | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-workspace-changes |
| packages/client/ui-deliverables/src/client/host-read-store.ts | 82 | HostReadStore, HostReadPolicy | @deepseek-ai/dsh-client-store |
| packages/client/ui-deliverables/src/client/index.ts | 114 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-connection, @deepseek-ai/dsh-client-ui-chat, @deepseek-ai/dsh-client-locale |
| packages/client/ui-deliverables/src/client/locales.ts | 136 | NS, zh, en, DeliverablesKey | — |
| packages/client/ui-deliverables/src/client/present-open.ts | 153 | PresentedOpenController, PRESENTED_SUCCESS_HOLD_MS, PRESENTED_SUCCESS_FADE_MS, PresentedOpenFailure, PresentedOpenPhase | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-session |
| packages/client/ui-deliverables/src/client/PresentedFileCard.tsx | 59 | PresentedFileCard | react, @deepseek-ai/dsh-util-workspace-path, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-deliverables/src/client/PresentRow.tsx | 60 | PresentRow | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-tool, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-deliverables/src/client/review-definition.ts | 51 | changesReviewDefinition, CHANGES_REVIEW_KIND, CHANGES_REVIEW_ID, ChangesReviewParams | @deepseek-ai/dsh-client-ui-sidebar-right, @deepseek-ai/dsh-client-locale |
| packages/client/ui-deliverables/src/client/review-store.ts | 93 | createReviewStore, ReviewTabState, ReviewState | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-dockkit |
| packages/client/ui-deliverables/src/client/ReviewTab.tsx | 161 | ReviewTab, ReviewInjected, ReviewTabProps | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-util-workspace-path |
| packages/client/ui-deliverables/src/client/turn-deliverables.ts | 284 | producedForClosing, selectProducedFiles, changesForClosing, presentedForClosing, producedFileMentions, deliverablesDefinition, PresentedPath, ChangesTurnData …等9项 | @deepseek-ai/dsh-session, @deepseek-ai/dsh-client-ui-chat, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-tool-present |
| packages/client/ui-deliverables/src/index.ts | 37 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-system-prompt, @deepseek-ai/dsh-workspace-changes |
| packages/client/ui-deliverables/src/present-open.ts | 188 | registerPresentOpen | @deepseek-ai/cordis, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-api-workspace-files, @deepseek-ai/dsh-fs, @deepseek-ai/dsh-sandbox-policy |
| packages/client/ui-deliverables/src/presented.ts | 88 | isPresentedHost, isPresentedFile, presentedFileUrl, isPresentedData, basename, PRESENT_OPEN_PATH, PRESENT_HOST_PATH, PRESENT_OPEN_ROUTE …等11项 | @deepseek-ai/dsh-tool-present, @deepseek-ai/dsh-session, @deepseek-ai/dsh-llm |
| packages/client/ui-deliverables/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-directory-picker-browse — @deepseek-ai/dsh-client-ui-directory-picker-browse@0.2.1-alpha.1（5 文件 / 1208 行）

职责：浏览式目录选择 UI


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-directory-picker-browse/src/client/DirectoryBrowser.tsx | 1053 | DirectoryBrowser, DirectoryBrowserProps | react, clsx, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-locale |
| packages/client/ui-directory-picker-browse/src/client/flow.ts | 44 | BrowseDirectoryFlow, BrowseFlowInjected | react, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-workspace |
| packages/client/ui-directory-picker-browse/src/client/index.ts | 96 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-workspace, @deepseek-ai/dsh-client-ui-renderer |
| packages/client/ui-directory-picker-browse/src/index.ts | 11 | apply | — |
| packages/client/ui-directory-picker-browse/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-directory-picker-native — @deepseek-ai/dsh-client-ui-directory-picker-native@0.2.1-alpha.1（4 文件 / 120 行）

职责：原生目录选择 UI 桥


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-directory-picker-native/src/client/flow.ts | 66 | NativeDirectoryFlow, NativeFlowInjected | react, @deepseek-ai/dsh-client-ui-workspace |
| packages/client/ui-directory-picker-native/src/client/index.ts | 39 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-workspace, @deepseek-ai/dsh-client-ui-renderer |
| packages/client/ui-directory-picker-native/src/index.ts | 11 | apply | — |
| packages/client/ui-directory-picker-native/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-dockkit — @deepseek-ai/dsh-client-ui-dockkit@0.2.1-alpha.1（22 文件 / 4168 行）

职责：停靠布局操作与组件


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-dockkit/src/components/DockSurface.tsx | 317 | DockSurface, DockLayout, DockSurfaceProps, DockLayoutProps | react |
| packages/client/ui-dockkit/src/components/FloatLayer.tsx | 194 | useFloatGestures, FloatHeader, FloatLayer, FloatLayerProps | react, clsx, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-dockkit/src/components/measure.ts | 130 | paneElements, measurePaneFits, fitOf, sameFits | — |
| packages/client/ui-dockkit/src/components/PaneTree.tsx | 61 | PaneTree, SizePreview, PaneTreeProps | react, clsx |
| packages/client/ui-dockkit/src/components/pointer.ts | 111 | capturePointer, followPointer, useGesture, PointerFollowers, GestureFollowers, BeginGesture | react |
| packages/client/ui-dockkit/src/components/render.ts | 49 | SplitBlock, PaneCallbacks | react |
| packages/client/ui-dockkit/src/components/TabLayout.tsx | 158 | TabLayout, TabRetention | react, clsx |
| packages/client/ui-dockkit/src/components/TabMenu.tsx | 128 | TabMenu, TabMenuProps | @deepseek-ai/dsh-client-ui-primitives, react, react-dom |
| packages/client/ui-dockkit/src/components/TabPanel.tsx | 447 | TabStrip, PaneDropHints, TabPanel, TabPanelProps | react, clsx, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-dockkit/src/components/TabTitle.tsx | 38 | TabTitle | react |
| packages/client/ui-dockkit/src/contract/adapter.ts | 106 | DockLabels, TabRenderer, TabMenuExtras, DockIntents | react |
| packages/client/ui-dockkit/src/contract/types.ts | 202 | PaneId, SplitId, NodeId, TabId, SplitAxis, SplitDirection, DockZone, DockMode …等19项 | @deepseek-ai/dsh-brand |
| packages/client/ui-dockkit/src/engine/constraints.ts | 105 | dockPaneCount, canSplit, zoneAt, zoneSplit, clampSizes, MAX_DOCK_PANES, MIN_PANE_FRACTION, FLOAT_DEFAULT_SIZE …等11项 | — |
| packages/client/ui-dockkit/src/engine/controller.ts | 316 | DockController, DockSnapshot, DockControllerOptions | — |
| packages/client/ui-dockkit/src/engine/geometry.ts | 222 | containsPoint, zoneInRect, insertionIndex, halvesFit, passedThreshold, dividerSizes, movedRect, resizedRect …等17项 | — |
| packages/client/ui-dockkit/src/engine/initial.ts | 74 | createIdMinter, createInitialState, IdMinter, TabFactory | — |
| packages/client/ui-dockkit/src/engine/operations.ts | 465 | applyOp, replay | — |
| packages/client/ui-dockkit/src/engine/planner.ts | 399 | findPaneContentTab, findContentTab, activeDockPaneId, planSetExpanded, planSetMode, planSplitPane, planAddTab, planOpenContent …等18项 | — |
| packages/client/ui-dockkit/src/engine/sequence.ts | 244 | isFocusOp, canStepBack, canStepForward, recordedOps, record, stepBack, stepForward, Sequencer …等12项 | — |
| packages/client/ui-dockkit/src/engine/tree.ts | 324 | assertNever, getNode, getPane, getSplit, getTab, floatRect, floatIndex, onlyTabId …等23项 | — |
| packages/client/ui-dockkit/src/index.ts | 71 | — | — |
| packages/client/ui-dockkit/tsdown.config.ts | 7 | staticLinked | — |

#### packages/client/ui-goal — @deepseek-ai/dsh-client-ui-goal@0.2.1-alpha.1（9 文件 / 728 行）

职责：目标面板 UI


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-goal/src/client/activation-source.ts | 143 | createGoalActivationSource, GoalActivationDeps | @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-goal |
| packages/client/ui-goal/src/client/goal-command-input.ts | 75 | goalCommandText, GOAL_COMMAND, goalCommandInputDefinition, GoalCommandInputData | @deepseek-ai/dsh-session, @deepseek-ai/dsh-commands, @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-goal/src/client/GoalBar.tsx | 207 | GoalBar, GoalDock, GoalBarProps, GoalDockProps | react, @deepseek-ai/dsh-goal, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-goal/src/client/GoalCommandInputView.tsx | 42 | GoalCommandInputView | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-goal/src/client/index.ts | 146 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-session, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-api-session-controller |
| packages/client/ui-goal/src/client/locales.ts | 37 | zh, en, GoalKey | — |
| packages/client/ui-goal/src/client/slots.ts | 64 | GoalLocalFailure, GoalActionResult, GoalActivationSnapshot, GoalActivationInjected, GoalBarActions, GoalBarInjected | @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-goal |
| packages/client/ui-goal/src/index.ts | 10 | apply | — |
| packages/client/ui-goal/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-input-trigger — @deepseek-ai/dsh-client-ui-input-trigger@0.2.1-alpha.1（13 文件 / 1740 行）

职责：输入触发器（@引用等）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-input-trigger/src/client/contract.ts | 26 | InputTriggerServiceContract | @deepseek-ai/cordis |
| packages/client/ui-input-trigger/src/client/controller.ts | 644 | InputTriggerController, SourceRoster, InputTriggerControllerDeps | @deepseek-ai/cordis, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-session |
| packages/client/ui-input-trigger/src/client/index.ts | 88 | apply, inject | @deepseek-ai/dsh-client-locale, @deepseek-ai/cordis, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-client-ui-renderer, @deepseek-ai/dsh-client-ui-session |
| packages/client/ui-input-trigger/src/client/locales.ts | 35 | zh, en, MenuKey | — |
| packages/client/ui-input-trigger/src/client/MenuView.tsx | 223 | MenuView, MenuViewProps | @deepseek-ai/dsh-client-ui-primitives, react, clsx, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-input-trigger/src/client/service.ts | 121 | InputTriggerService | @deepseek-ai/cordis, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-util-values, @deepseek-ai/dsh-client-locale |
| packages/client/ui-input-trigger/src/client/slots.ts | 36 | MenuViewInjected | @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-client-store |
| packages/client/ui-input-trigger/src/core/contract.ts | 65 | TriggerHit, DetectTrigger, MenuState, MenuEvent, MenuReduce, ExactMatch | @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-input-trigger/src/core/detect.ts | 77 | detectTrigger | @deepseek-ai/dsh-file-reference |
| packages/client/ui-input-trigger/src/core/menu.ts | 170 | seedGroups, MENU_CLOSED, menuReduce, exactMatch | — |
| packages/client/ui-input-trigger/src/index.ts | 10 | apply | — |
| packages/client/ui-input-trigger/src/types.ts | 241 | ClientSessionContext, TriggerChar, TriggerPosition, PickVia, PickAction, InputTriggerCandidateIcon, InputTriggerCandidate, InputTriggerCrumb …等15项 | react, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-session |
| packages/client/ui-input-trigger/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-jobs — @deepseek-ai/dsh-client-ui-jobs@0.2.1-alpha.1（5 文件 / 722 行）

职责：后台任务 UI


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-jobs/src/client/index.ts | 54 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-jobs, @deepseek-ai/dsh-api-job-controller, @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-renderer |
| packages/client/ui-jobs/src/client/JobListAction.tsx | 560 | JobListAction, JobListInjected, JobListActionProps | react, @deepseek-ai/dsh-api-job-controller, @deepseek-ai/dsh-session, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-jobs/src/client/locales.ts | 94 | NS, zh, en, JobKey | — |
| packages/client/ui-jobs/src/index.ts | 10 | apply | — |
| packages/client/ui-jobs/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-layout — @deepseek-ai/dsh-client-ui-layout@0.2.1-alpha.1（10 文件 / 981 行）

职责：主应用区域排布 + 主题快照应用


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-layout/src/client/AppFrame.tsx | 308 | AppFrame, AppFrameProps | react, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-layout/src/client/columns.ts | 60 | clampWidth, computeColumns, CENTER_MIN, SIDEBAR_MIN, SIDEBAR_MAX, SIDEBAR_DEFAULT, SIDEBAR_COLLAPSED, SIDEBAR_AUTO_COLLAPSE …等12项 | — |
| packages/client/ui-layout/src/client/DocumentTitle.tsx | 30 | DocumentTitle, DocumentTitleProps | react, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-layout/src/client/index.ts | 228 | apply, inject, UsePanelInfo, SidebarOwnerProps, RightbarOwnerProps | @deepseek-ai/cordis, @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-renderer, @deepseek-ai/dsh-client-ui-session, @deepseek-ai/dsh-client-ui-theme |
| packages/client/ui-layout/src/client/service.ts | 107 | LayoutController, MainPanelId, PanelInfo, PanelActions, ILayout | @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-brand |
| packages/client/ui-layout/src/client/shortcut-locales.ts | 5 | zh, en | — |
| packages/client/ui-layout/src/client/stores.ts | 147 | createLayoutStore | @deepseek-ai/dsh-client-store |
| packages/client/ui-layout/src/client/theme-presenter.ts | 87 | ThemePresenter, DARK_ATTRIBUTE, THEME_SOURCE_ATTRIBUTE, CONTENT_FONT_SIZE_VARIABLE | @deepseek-ai/dsh-client-ui-theme |
| packages/client/ui-layout/src/index.ts | 5 | apply | — |
| packages/client/ui-layout/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-message-feedback — @deepseek-ai/dsh-client-ui-message-feedback@0.2.1-alpha.1（10 文件 / 1043 行）

职责：消息评分/备注 UI


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-message-feedback/src/client/controller.ts | 312 | describe, MessageFeedbackController, MessageFeedbackStatus, MessageFeedbackView, MessageFeedbackActionFailure, MessageFeedbackActionResult | @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-session, @deepseek-ai/dsh-command-feedback, @deepseek-ai/dsh-message-feedback |
| packages/client/ui-message-feedback/src/client/dialog.ts | 137 | FeedbackDialogController, FeedbackDialogTarget, FeedbackDialogState, FeedbackSubmit | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-command-feedback, @deepseek-ai/dsh-message-feedback |
| packages/client/ui-message-feedback/src/client/FeedbackDialog.tsx | 129 | FeedbackDialog | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-command-feedback |
| packages/client/ui-message-feedback/src/client/index.ts | 143 | apply, inject, FeedbackUi | @deepseek-ai/cordis, @deepseek-ai/dsh-session, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-client-ui-commands |
| packages/client/ui-message-feedback/src/client/locales.ts | 60 | zh, en, MessageFeedbackKey | — |
| packages/client/ui-message-feedback/src/client/MessageFeedbackActions.tsx | 116 | MessageFeedbackActions | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-message-feedback |
| packages/client/ui-message-feedback/src/client/slots.ts | 85 | MessageFeedbackInjected, MessageFeedbackActionProps, FeedbackDialogInjected, FeedbackDialogProps | @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-message-feedback |
| packages/client/ui-message-feedback/src/client/surface.ts | 47 | FeedbackSurface | @deepseek-ai/cordis, @deepseek-ai/dsh-session, @deepseek-ai/dsh-command-feedback |
| packages/client/ui-message-feedback/src/index.ts | 10 | apply | — |
| packages/client/ui-message-feedback/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-model-selection — @deepseek-ai/dsh-client-ui-model-selection@0.2.1-alpha.1（10 文件 / 1370 行）

职责：模型选择 UI


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-model-selection/src/client/catalog.ts | 108 | ModelCatalogDirectory, ModelCatalogState | @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-store |
| packages/client/ui-model-selection/src/client/directory.ts | 200 | ModelDirectory, ModelDirectoryState | @deepseek-ai/dsh-client-product-analytics, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-client-store |
| packages/client/ui-model-selection/src/client/index.ts | 192 | apply, inject | @deepseek-ai/dsh-api-session-controller, @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-commands, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-client-locale |
| packages/client/ui-model-selection/src/client/locales.ts | 67 | zh, en, ModelKey | — |
| packages/client/ui-model-selection/src/client/ModelSelect.tsx | 657 | ModelSelect | @deepseek-ai/dsh-client-ui-primitives, react, react-dom, clsx, @deepseek-ai/dsh-api-remotes |
| packages/client/ui-model-selection/src/client/provider-order.ts | 13 | orderModelProviders | — |
| packages/client/ui-model-selection/src/client/service.ts | 92 | ModelDirectoryResolver | @deepseek-ai/dsh-client-product-analytics, @deepseek-ai/cordis, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-session, @deepseek-ai/dsh-util-values |
| packages/client/ui-model-selection/src/client/slots.ts | 27 | ModelSelectInjected | @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-store |
| packages/client/ui-model-selection/src/index.ts | 10 | apply | — |
| packages/client/ui-model-selection/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-open-in-app — @deepseek-ai/dsh-client-ui-open-in-app@0.2.1-alpha.1（14 文件 / 935 行）

职责：Open In... UI


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-open-in-app/src/client/applications.ts | 41 | APP_LABEL_KEY | — |
| packages/client/ui-open-in-app/src/client/controller.ts | 112 | OpenInAppController, OpenInAppLaunchState | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-host-open-in-app |
| packages/client/ui-open-in-app/src/client/file-applications.ts | 74 | useFileApplications | react, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-api-session-controller |
| packages/client/ui-open-in-app/src/client/FileRouteAction.tsx | 38 | FileRouteAction | @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-deliverables, @deepseek-ai/dsh-native-command, @deepseek-ai/dsh-api-session-controller |
| packages/client/ui-open-in-app/src/client/index.ts | 136 | apply, inject | react, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-shortcuts, @deepseek-ai/cordis, @deepseek-ai/dsh-client-locale |
| packages/client/ui-open-in-app/src/client/locales.ts | 82 | NS, zh, en, OpenInAppKey | — |
| packages/client/ui-open-in-app/src/client/open-failure-toast.tsx | 27 | useOpenFailureToast | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-open-in-app/src/client/open-path.ts | 97 | OpenInAppPathController, OpenInAppPathAction, OpenInAppPathFailure, OpenInAppPathRemote | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-api-session-controller |
| packages/client/ui-open-in-app/src/client/OpenInAppAction.tsx | 63 | OpenInAppAction, OpenInAppActionInjected, OpenInAppActionProps | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-shortcuts |
| packages/client/ui-open-in-app/src/client/OpenPathAction.tsx | 67 | FileOpenTarget, OpenPathAction, OpenPathInjected, OpenPathActionProps | react, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-sidebar-documentpreview |
| packages/client/ui-open-in-app/src/client/OpenPathEmptyAction.tsx | 22 | OpenPathEmptyAction, OpenPathEmptyActionProps | react, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-sidebar-documentpreview |
| packages/client/ui-open-in-app/src/client/OpenTargetButton.tsx | 161 | useOpenTargetGesture, OpenTargetButton, OpenTargetApplication, OpenTargetOperation, OpenTargetButtonProps | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-shortcuts, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-open-in-app/src/index.ts | 11 | apply | — |
| packages/client/ui-open-in-app/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-permission-presets — @deepseek-ai/dsh-client-ui-permission-presets@0.2.1-alpha.1（9 文件 / 1066 行）

职责：权限预设切换 UI


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-permission-presets/src/client/catalog.ts | 159 | PermissionCatalogDirectory, PermissionCatalogState | @deepseek-ai/cordis, @deepseek-ai/dsh-client-connection, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-permission-presets |
| packages/client/ui-permission-presets/src/client/index.ts | 193 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-permission-presets, @deepseek-ai/dsh-client-connection |
| packages/client/ui-permission-presets/src/client/locales.ts | 85 | PERMISSION_ACCESS_NS, zh, en, accessZh, accessEn, PermissionSettingsKey, PermissionAccessKey | — |
| packages/client/ui-permission-presets/src/client/PermissionRow.tsx | 136 | PermissionRow, PermissionRowInjected, PermissionRowProps | react, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-permission-presets/src/client/PermissionSelect.tsx | 216 | PermissionSelect, PermissionSelectInjected, PermissionSelectProps | react, clsx, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-permission-presets |
| packages/client/ui-permission-presets/src/client/presentation.ts | 55 | displayPresetName, displayPermissionPreset, FULL_ACCESS_PRESET, AUTO_REVIEW_PRESET, PermissionPresetLabelKey | — |
| packages/client/ui-permission-presets/src/client/settings-store.ts | 208 | permissionDefaultOf, PermissionPresetSettingsController, PERMISSION_SETTINGS_NS, PermissionDefaultOption, PermissionSettingsState | @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-settings, @deepseek-ai/dsh-permission-presets |
| packages/client/ui-permission-presets/src/index.ts | 10 | apply | — |
| packages/client/ui-permission-presets/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-plan — @deepseek-ai/dsh-client-ui-plan@0.2.1-alpha.1（13 文件 / 682 行）

职责：计划模式 UI


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-plan/src/client/failure-line.ts | 20 | planFailureLine | @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-client-locale |
| packages/client/ui-plan/src/client/index.ts | 130 | apply, inject, PlanChipInjected | @deepseek-ai/dsh-api-remotes, @deepseek-ai/cordis, @deepseek-ai/dsh-session, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-client-locale |
| packages/client/ui-plan/src/client/locales.ts | 47 | zh, en, PlanKey | — |
| packages/client/ui-plan/src/client/plan-definition.ts | 35 | planDefinition | @deepseek-ai/dsh-tools, @deepseek-ai/dsh-client-ui-chat, @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-plan/src/client/plan-resource.ts | 83 | planResourceProvider | @deepseek-ai/cordis, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-client-resources, @deepseek-ai/dsh-typert-protocol |
| packages/client/ui-plan/src/client/plan.ts | 87 | submittedPlan, planAddress, parsePlanAddress, PlanDocument, SubmittedPlan, PlanAddress | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session, @deepseek-ai/dsh-api-session-controller |
| packages/client/ui-plan/src/client/PlanCard.tsx | 84 | PlanCards, PlanReviewOpen, PlanOpenInjected, PlanCardsInjected, PlanReviewOpenInjected | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-llm |
| packages/client/ui-plan/src/client/PlanModeControl.tsx | 71 | PlanChip, PlanChipProps | react, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-plan/src/client/PlanPreview.tsx | 55 | PlanPreview, PlanTitle | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-sidebar-right |
| packages/client/ui-plan/src/client/review-preview.ts | 30 | reviewPreviewAddress, isReviewPreviewAddress | @deepseek-ai/dsh-session |
| packages/client/ui-plan/src/client/review-store.ts | 24 | createPlanReviewStore | @deepseek-ai/dsh-client-store |
| packages/client/ui-plan/src/index.ts | 12 | apply | — |
| packages/client/ui-plan/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-plugin-manager — @deepseek-ai/dsh-client-ui-plugin-manager@0.2.1-alpha.1（13 文件 / 3873 行）

职责：插件管理页 UI（安装/启停）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-plugin-manager/src/client/config-ledger.ts | 78 | rowConfigKey, configLedgerSource, OfficialItem, ConfigLedger | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-plugin-manager/src/client/index.ts | 150 | apply, NS, PANEL_ID, inject | @deepseek-ai/dsh-client-product-analytics, @deepseek-ai/dsh-client-locale, @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-layout, @deepseek-ai/dsh-client-ui-sidebar |
| packages/client/ui-plugin-manager/src/client/locales.ts | 412 | INSTALL_GIT_EXAMPLE, INSTALL_PATH_EXAMPLE, zh, en, PluginManagerLocaleKey | — |
| packages/client/ui-plugin-manager/src/client/manager-store.ts | 1179 | registryKey, offeredRegistries, isInstallPending, githubRecoveryRegistry, asksMirror, rowKey, packageView, sortPackages …等21项 | @deepseek-ai/dsh-client-product-analytics, @deepseek-ai/dsh-util-crypto, @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-plugin-manager |
| packages/client/ui-plugin-manager/src/client/navigation-store.ts | 26 | createNavigationStore | @deepseek-ai/dsh-client-store |
| packages/client/ui-plugin-manager/src/client/PluginManagerPage.tsx | 1570 | PluginManagerPage, PluginManagerPageProps | react, react-dom, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-plugin-manager/src/client/PluginRefreshToast.tsx | 33 | PluginRefreshToast, PluginRefreshToastFace, PluginRefreshToastProps | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-plugin-manager/src/client/PluginsPanelIcon.tsx | 16 | PluginsPanelIcon | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-sidebar |
| packages/client/ui-plugin-manager/src/client/presentation.ts | 165 | registryText, managementText, shortName, packageText, rowText, noticeText, Translate | @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-plugin-manager/src/client/sanitize-install-input.ts | 14 | sanitizeInstallInput | — |
| packages/client/ui-plugin-manager/src/client/slot-contract.ts | 139 | PluginConfigViewProps, PluginRowRef, PluginPackageRef, PluginsSubject, PluginDetailProps, PluginActivationOwnerProps, PluginAddActionsProps, ConfigPageForm | @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-settings |
| packages/client/ui-plugin-manager/src/index.ts | 87 | Config, PluginRegistryProbe | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-timeout, @deepseek-ai/dsh-typert-protocol |
| packages/client/ui-plugin-manager/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-primitives — @deepseek-ai/dsh-client-ui-primitives@0.2.1-alpha.1（88 文件 / 12986 行）

职责：共享 React 控件/图标/内容渲染器（88 文件）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-primitives/src/ansi.ts | 448 | parseAnsiLines, AnsiSpan, AnsiLine | anser, react |
| packages/client/ui-primitives/src/BrandWordmark.tsx | 60 | BrandWordmark, BrandWordmarkProps | — |
| packages/client/ui-primitives/src/Button.tsx | 37 | Button, ButtonVariant | react, clsx |
| packages/client/ui-primitives/src/Checkbox.tsx | 32 | Checkbox | clsx |
| packages/client/ui-primitives/src/clipboard.ts | 48 | writeClipboard | — |
| packages/client/ui-primitives/src/code-file-icon-artwork.ts | 61 | CODE_FILE_ICON_ID_TOKEN, CODE_FILE_ARTWORK | — |
| packages/client/ui-primitives/src/code-file-types.ts | 339 | isCodeFileType, isLinkCodeExtension, classifyCodeFileType, CODE_FILE_TYPES, CodeFileType, FileTypeProjectContext | — |
| packages/client/ui-primitives/src/code-highlighting.ts | 26 | useCodeHighlighter, CodeHighlighter | react, @deepseek-ai/dsh-util-code-language |
| packages/client/ui-primitives/src/CodeFileIcon.tsx | 29 | CodeFileIcon | react |
| packages/client/ui-primitives/src/CodeToolbar.tsx | 63 | CodeToolbar, CodeToolbarLabels | — |
| packages/client/ui-primitives/src/ConfigField.tsx | 54 | ConfigField, ConfigFieldProps | react |
| packages/client/ui-primitives/src/ConnectionIndicator.tsx | 104 | ConnectionIndicator, ConnectionIndicatorState | react |
| packages/client/ui-primitives/src/darwin-desktop.ts | 12 | isDarwinDesktop | — |
| packages/client/ui-primitives/src/DiffBlock.tsx | 222 | diffTotals, DiffBlock, DEFAULT_DIFF_MAX_LINES, DiffHunk, DiffBlockProps, DiffBlockLabels | react, clsx, diff |
| packages/client/ui-primitives/src/DisclosureRow.tsx | 119 | DisclosureRow, DisclosureRowProps | react, clsx |
| packages/client/ui-primitives/src/file-size.ts | 17 | fileSizeText | — |
| packages/client/ui-primitives/src/FileTypeIcon.tsx | 284 | fileExtension, classifyFileType, FileTypeIcon, FileType, FileTypeKind, FileTypeIconProps | react, clsx |
| packages/client/ui-primitives/src/FishLogo.tsx | 29 | FishLogo, FISH_LOGO_VIEWBOX, FISH_LOGO_PATH | — |
| packages/client/ui-primitives/src/focus.ts | 30 | focusWithoutRing | — |
| packages/client/ui-primitives/src/FoldToggle.tsx | 34 | FoldToggle | — |
| packages/client/ui-primitives/src/guide-artwork.tsx | 33 | GuideArtworkBrowser, GuideArtworkFiles | — |
| packages/client/ui-primitives/src/head-tail-cap.ts | 28 | headTailCap, HeadTailCap | — |
| packages/client/ui-primitives/src/HoverCard.tsx | 295 | HoverCard | react, clsx, react-dom |
| packages/client/ui-primitives/src/icons/index.tsx | 1659 | SHIELD_OUTLINE_PATH, ICON_REGULAR_STROKE, ICON_MEDIUM_STROKE, IconNewChatOutlineRegular, IconNewChatOutlineMedium, IconSearchOutlineRegular, IconSearchOutlineMedium, IconGlobeOutlineRegular …等191项 | react |
| packages/client/ui-primitives/src/icons/props.ts | 9 | IconProps | — |
| packages/client/ui-primitives/src/icons/shared-artwork.tsx | 85 | NewChatOutlineArtwork, ChatLinesOutlineArtwork, GlobeOutlineArtwork, CodeBracketsArtwork, BrowseOutlineArtwork, FolderCloseArtwork | — |
| packages/client/ui-primitives/src/ImageLightbox.tsx | 66 | ImageLightbox, ImageLightboxLabels | react, react-dom |
| packages/client/ui-primitives/src/ImagePreview.tsx | 37 | ImagePreview | react |
| packages/client/ui-primitives/src/index.ts | 116 | — | — |
| packages/client/ui-primitives/src/InlineEditor.tsx | 70 | InlineEditor | react, clsx |
| packages/client/ui-primitives/src/input-modality.ts | 60 | pointerModality, INPUT_MODALITY, INPUT_MODALITY_ATTRIBUTE | — |
| packages/client/ui-primitives/src/Input.tsx | 25 | Input | react, clsx |
| packages/client/ui-primitives/src/JsonTree.tsx | 851 | JsonTree, JsonTreeLabels, JsonTreeProps | clsx, react |
| packages/client/ui-primitives/src/keyboard-composition.ts | 37 | observeComposition | — |
| packages/client/ui-primitives/src/LinkIcon.tsx | 119 | classifyLinkPath, LinkIconRegular, LinkIconMedium, LinkIconKind, LinkIconProps | react |
| packages/client/ui-primitives/src/markdown/cjkFriendlyStrong.ts | 84 | cjkFriendlyStrong | micromark-core-commonmark, micromark-util-character, micromark-util-classify-character, micromark-util-symbol, micromark-util-types |
| packages/client/ui-primitives/src/markdown/CodeBlock.tsx | 213 | CodeBlock, CodeBlockProps | react, clsx |
| packages/client/ui-primitives/src/markdown/file-link.ts | 33 | parseFileLink | — |
| packages/client/ui-primitives/src/markdown/highlight.ts | 601 | grammarForHint, supportsHighlighting, subscribeGrammarLoaded, grammarLoadCount, highlightToHtml, highlightLines, StreamingHighlightSession, HighlightSpan …等9项 | shiki, @shikijs/langs, react |
| packages/client/ui-primitives/src/markdown/incremental.ts | 361 | IncrementalMarkdownParser, PositionedBlock, IncrementalBlocks | mdast |
| packages/client/ui-primitives/src/markdown/JsonBlock.tsx | 37 | JsonBlock | react |
| packages/client/ui-primitives/src/markdown/katex.tsx | 91 | renderTexToReact | react, katex |
| packages/client/ui-primitives/src/markdown/local-image-syntax.ts | 30 | recoverLocalImages | mdast |
| packages/client/ui-primitives/src/markdown/MarkdownDelegate.tsx | 63 | MarkdownDelegateProvider, useMarkdownDelegate, MarkdownExternalLinkHandler, MarkdownDelegate, MarkdownDelegateProviderProps | react |
| packages/client/ui-primitives/src/markdown/MarkdownText.tsx | 200 | MarkdownText | react, clsx, katex |
| packages/client/ui-primitives/src/markdown/mathCompatibility.ts | 350 | mathCompatibility | micromark-factory-space, micromark-extension-math, micromark-util-character, micromark-util-symbol, micromark-util-types |
| packages/client/ui-primitives/src/markdown/parse.ts | 46 | parseGfm, parseGfmWithMath | mdast, mdast-util-from-markdown, mdast-util-gfm, mdast-util-math, micromark-extension-gfm |
| packages/client/ui-primitives/src/markdown/plain-text.ts | 122 | extractMarkdownPlainText, MarkdownPlainTextMode, MarkdownPlainTextOptions | — |
| packages/client/ui-primitives/src/markdown/render.tsx | 761 | createReferenceTargets, collectReferenceTargets, renderBlocks, wrapBlockChildren, renderFootnoteSection, MarkdownCodeLabels, MarkdownLabels, ReferenceTargets …等11项 | react, clsx, mdast, mdast-util-math, micromark-util-sanitize-uri |
| packages/client/ui-primitives/src/markdown/useViewportHighlighting.ts | 73 | useViewportHighlighting | react |
| packages/client/ui-primitives/src/Menu.tsx | 565 | MenuItemButton, Menu, MenuItem, MenuSeparator, MenuLabel, MenuEntry, MenuItemButtonProps | react, react-dom, clsx |
| packages/client/ui-primitives/src/MenuGroup.tsx | 104 | MenuGroup, observeStickyMenuGroups | react |
| packages/client/ui-primitives/src/MenuSurface.tsx | 47 | MenuSurface, MenuSurfaceProps | react, react-dom, clsx |
| packages/client/ui-primitives/src/Modal.tsx | 92 | Modal | react, react-dom, clsx |
| packages/client/ui-primitives/src/overlay-top-margin.ts | 14 | overlayTopMargin | — |
| packages/client/ui-primitives/src/PathLabel.tsx | 42 | PathLabel | react, clsx, @deepseek-ai/dsh-util-workspace-path |
| packages/client/ui-primitives/src/PermissionIcon.tsx | 93 | PermissionIconReadOnlyRegular, PermissionIconReadOnlyMedium, PermissionIconWorkspaceWriteRegular, PermissionIconWorkspaceWriteMedium, PermissionIconFullAccessRegular, PermissionIconFullAccessMedium | react |
| packages/client/ui-primitives/src/Pill.tsx | 37 | Pill | react, clsx |
| packages/client/ui-primitives/src/plugin-artwork.tsx | 111 | PluginArtworkTerminal, PluginArtworkLoop, PluginArtworkSubagent, PluginArtworkSearch, PluginArtworkDefault | react |
| packages/client/ui-primitives/src/pointer-grace.ts | 48 | usePointerGrace, POINTER_GRACE_MS, PointerGrace | react |
| packages/client/ui-primitives/src/rank-by-name.ts | 94 | rankByName | — |
| packages/client/ui-primitives/src/ReadBlock.tsx | 152 | ReadBlock, DEFAULT_READ_MAX_LINES, ReadBlockLine, ReadBlockProps, ReadBlockLabels | react, clsx |
| packages/client/ui-primitives/src/ReferenceIcon.tsx | 50 | ReferenceIconRegular, ReferenceIconMedium, ReferenceIconKind, ReferenceIconProps | react |
| packages/client/ui-primitives/src/relative-time.ts | 37 | relativeTime, RelativeTimeUnit, RelativeTime | — |
| packages/client/ui-primitives/src/RiskConfirmation.tsx | 84 | RiskConfirmation, RiskConfirmationProps | — |
| packages/client/ui-primitives/src/SearchBlock.tsx | 282 | SearchBlock, DEFAULT_SEARCH_MAX_LINES, SearchBlockLineMatch, SearchFileGroup, SearchBlockLabels, SearchMatchesBlockProps, SearchPathsBlockProps, SearchBlockProps | react, clsx |
| packages/client/ui-primitives/src/SegmentedControl.tsx | 141 | SegmentedControl, SegmentedControlOption | react, clsx |
| packages/client/ui-primitives/src/SegmentedTabs.tsx | 82 | SegmentedTabs, SegmentedTab | react, clsx |
| packages/client/ui-primitives/src/settings-form/fields.tsx | 152 | SettingsValueField, SettingsSecretField, SettingsFieldProps | react |
| packages/client/ui-primitives/src/settings-form/form-model.ts | 394 | settingsNumberField, settingsTextField, SettingsFormModel, SettingsFormScopeSnapshot, SettingsFormPathOp, SettingsFormScope, SettingsFieldWrite, SettingsFieldSpec …等12项 | @deepseek-ai/dsh-client-store |
| packages/client/ui-primitives/src/settings-form/SettingsForm.tsx | 75 | SettingsForm, SettingsFormLabels, SettingsFormProps | react |
| packages/client/ui-primitives/src/ShortcutKeys.tsx | 13 | ShortcutKeys | clsx |
| packages/client/ui-primitives/src/SiteGlyph.tsx | 150 | siteGlyph | react, simple-icons |
| packages/client/ui-primitives/src/StateDot.tsx | 78 | StateDot, StateDotState | clsx |
| packages/client/ui-primitives/src/Switch.tsx | 43 | Switch | clsx |
| packages/client/ui-primitives/src/Tag.tsx | 43 | Tag, TagTone | react, clsx |
| packages/client/ui-primitives/src/TerminalBlock.tsx | 284 | TerminalBlock, DEFAULT_TERMINAL_MAX_LINES, TerminalBlockLabels, TerminalBlockProps | react, clsx |
| packages/client/ui-primitives/src/TextShimmer.tsx | 59 | TextShimmer, TextShimmerProps | react, clsx |
| packages/client/ui-primitives/src/Toast.tsx | 102 | Toast | react, react-dom |
| packages/client/ui-primitives/src/Tooltip.tsx | 256 | Tooltip, TooltipSuppression, TooltipSide | react, react-dom |
| packages/client/ui-primitives/src/use-copy-feedback.ts | 32 | useCopyFeedback, CopyFeedback | react |
| packages/client/ui-primitives/src/useAnchoredMaxHeight.ts | 46 | useAnchoredMaxHeight | react |
| packages/client/ui-primitives/src/useAnchoredPosition.ts | 87 | useAnchoredPosition, AnchoredPositionOptions | react |
| packages/client/ui-primitives/src/useDismissOnOutsidePointer.ts | 35 | useDismissOnOutsidePointer | react |
| packages/client/ui-primitives/src/useModalLayer.ts | 98 | closeTopModal, isBehindModal, useModalLayer, modalSelector | react |
| packages/client/ui-primitives/src/user-text.tsx | 157 | projectUserText, UserTextReferences | react, clsx |
| packages/client/ui-primitives/src/WebBlock.tsx | 197 | WebBlock, WebSourceView, WebSearchBlockProps, WebFetchBlockProps, WebBlockProps, WebBlockLabels | clsx |
| packages/client/ui-primitives/tsdown.config.ts | 7 | staticLinked | — |

#### packages/client/ui-reference — @deepseek-ai/dsh-client-ui-reference@0.2.1-alpha.1（4 文件 / 346 行）

职责：@引用 呈现


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-reference/src/client/index.ts | 279 | apply, inject | @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-sidebar-right, @deepseek-ai/cordis, @deepseek-ai/dsh-api-session-controller |
| packages/client/ui-reference/src/client/locales.ts | 53 | NS, zh, en, ReferenceKey | @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-reference/src/index.ts | 10 | apply | — |
| packages/client/ui-reference/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-renderer — @deepseek-ai/dsh-client-ui-renderer@0.2.1-alpha.1（9 文件 / 2429 行）

职责：Slot 注册表→React 挂载（ctx.uiRenderer/ctx.slots；唯一 hook 构造器）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-renderer/src/client/app.tsx | 23 | buildRenderApp, AssemblyDeps | react, @deepseek-ai/cordis |
| packages/client/ui-renderer/src/client/bind.ts | 28 | bindSnapshotSelector | use-sync-external-store, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-renderer/src/client/bindings.tsx | 174 | useHost, useRootBinding, useScopeBinding, ScopeBindingProvider, observableHook, maybeObservableHook, keyedObservableHook, RootStandardProvider …等11项 | react, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-renderer/src/client/errors.ts | 5 | SlotAssemblyError | — |
| packages/client/ui-renderer/src/client/index.ts | 99 | apply, inject, UiRendererService | react, react-dom, @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-renderer/src/client/registry.ts | 765 | SlotRegistry, RootOwnerProps | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-renderer/src/client/scoped-slots.tsx | 1326 | createSlotRenderer | react, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-renderer/src/index.ts | 5 | apply | — |
| packages/client/ui-renderer/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-schedule — @deepseek-ai/dsh-client-ui-schedule@0.2.1-alpha.1（37 文件 / 7487 行）

职责：定时任务 UI


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-schedule/src/client/CalendarIcon.tsx | 36 | IconCalendarOutlineRegular, CalendarIconProps | react |
| packages/client/ui-schedule/src/client/catalog-source.ts | 192 | createCatalogSource, CatalogDeleteOutcome, CatalogSnapshot, CatalogDependencies, CatalogInjected | @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-schedule |
| packages/client/ui-schedule/src/client/CatalogFeedback.tsx | 48 | CatalogFeedback, CatalogFeedbackProps | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-schedule/src/client/ClockPicker.tsx | 216 | ClockPicker, ClockPickerProps | react, clsx, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-schedule/src/client/DatePicker.tsx | 227 | DatePicker, DatePickerProps | react, clsx, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-schedule/src/client/definition.ts | 54 | scheduleTaskDefinition, scheduleTaskParams, SCHEDULE_TASK_ID, SCHEDULE_TASK_KIND | @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-sidebar-right, @deepseek-ai/dsh-schedule, @deepseek-ai/dsh-session |
| packages/client/ui-schedule/src/client/DeleteToast.tsx | 89 | createDeleteToastSource, ScheduleDeleteToast, DeleteToastState, DeleteToastSource, ScheduleDeleteToastProps | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-layout |
| packages/client/ui-schedule/src/client/DeliveryHistory.tsx | 184 | DeliveryHistory, DeliveryHistoryInjected | react, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-schedule |
| packages/client/ui-schedule/src/client/frequency-locales.ts | 128 | frequencyZh, frequencyEn | — |
| packages/client/ui-schedule/src/client/index.ts | 246 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-client-ui-renderer, @deepseek-ai/dsh-client-ui-session |
| packages/client/ui-schedule/src/client/locales.ts | 54 | NS, zh, en, ScheduleCatalogKey | — |
| packages/client/ui-schedule/src/client/PickerPopover.tsx | 60 | PickerPopover, PickerPopoverProps | react, react-dom, clsx, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-schedule/src/client/recent-time-zones.ts | 47 | loadRecentTimeZones, rememberTimeZone | — |
| packages/client/ui-schedule/src/client/relative-clock.ts | 37 | useRelativeClock, RELATIVE_CLOCK_PERIOD_MS | react |
| packages/client/ui-schedule/src/client/schedule-create-card.ts | 154 | narrowScheduleRecord, scheduleCreateCardModel, ScheduleCreateCardModel | @deepseek-ai/dsh-schedule, @deepseek-ai/dsh-client-ui-tool |
| packages/client/ui-schedule/src/client/schedule-format.ts | 457 | taskName, formatWeekdays, zoneLabel, zoneName, zoneChoices, recordTimeZone, formatScheduleFrequency, formatScheduleNextRun …等18项 | @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-schedule, @deepseek-ai/dsh-util-values |
| packages/client/ui-schedule/src/client/schedule-turn.ts | 174 | scheduleTasksForClosing, selectScheduleTasks, SCHEDULE_CREATE_TOOL, scheduleTurnDefinition, ScheduleCreatedTask, ScheduleTurnData, ScheduleTurnOwner | @deepseek-ai/dsh-session, @deepseek-ai/dsh-util-values, @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-schedule/src/client/ScheduleCatalogAction.tsx | 201 | ScheduleCatalogAction, ScheduleCatalogActionProps | react, react-dom, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-schedule/src/client/ScheduleCreateCard.tsx | 87 | ScheduleCreateCard, ScheduleCreateCardInjected, ScheduleCreateCardProps, ScheduleCreateCardInput | @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-tool, @deepseek-ai/dsh-schedule |
| packages/client/ui-schedule/src/client/ScheduleTaskTab.tsx | 138 | ScheduleTaskTab, ScheduleTaskCatalogInjected, ScheduleTaskBindingInjected, ScheduleTaskTabInjected, ScheduleTaskTabProps | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-schedule |
| packages/client/ui-schedule/src/client/ScheduleTaskTabTitle.tsx | 40 | ScheduleTaskTabTitle, ScheduleTaskTabTitleProps | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-schedule/src/client/ScheduleTurnCard.tsx | 118 | ScheduleTurnCard, ScheduleTurnCardInjected, ScheduleTurnCardProps | react, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-schedule |
| packages/client/ui-schedule/src/client/session-link.ts | 55 | sessionLinkState, sessionLabel, SessionLinkState, SessionLabel | @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-api-workspace-controller, @deepseek-ai/dsh-session |
| packages/client/ui-schedule/src/client/session-schedule-state.ts | 112 | createSessionScheduleSource, selectSessionScheduleFacts, useSessionScheduleFacts, SessionScheduleSourceFactory, SessionScheduleCatalogHook, SessionScheduleCatalogObservable, SessionScheduleFacts | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-schedule, @deepseek-ai/dsh-session |
| packages/client/ui-schedule/src/client/SessionScheduleHover.tsx | 78 | SessionScheduleHover, SESSION_HOVER_TASK_LIMIT, SessionScheduleHoverInjected, SessionScheduleHoverProps | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-workspace |
| packages/client/ui-schedule/src/client/SessionScheduleMark.tsx | 60 | SessionScheduleMark, SessionScheduleMarkInjected, SessionScheduleMarkProps | @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-workspace |
| packages/client/ui-schedule/src/client/task-cron.ts | 597 | parseCronExpression, cronPreview, recognizeCronShape, cronShapeExpression, CronDescriptionKey, CronDescriptionTranslator, CronField, ParsedCron …等9项 | @deepseek-ai/dsh-util-values, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-schedule/src/client/task-manager-locales.ts | 286 | en, zh, TaskManagerKey | — |
| packages/client/ui-schedule/src/client/task-tab-bindings.ts | 224 | TaskTabBindings, TaskTabPage, TaskTabTarget, TaskTabLiveIds | @deepseek-ai/dsh-session, @deepseek-ai/dsh-schedule |
| packages/client/ui-schedule/src/client/task-tab-target.ts | 61 | useTaskTabTarget, TaskTabSource, TaskTabTargetResolution | react, @deepseek-ai/dsh-client-ui-sidebar-right, @deepseek-ai/dsh-session |
| packages/client/ui-schedule/src/client/task-timing.ts | 205 | timingSnapshot, draftZone, zonedWallClock, timingDraft, slashDate, secondPrecision, timingError, TaskTimingInjected …等9项 | @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-schedule, @deepseek-ai/dsh-util-values |
| packages/client/ui-schedule/src/client/TaskDetail.tsx | 2232 | useTaskDetail, TaskDetail, mergeRuleDraft, TaskDetailTab, TaskDetailInjected, TaskDetailProps, TaskDetailController | @deepseek-ai/dsh-util-values, react, clsx, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-schedule/src/client/TaskManagerIcon.tsx | 17 | TaskManagerIcon | @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-sidebar |
| packages/client/ui-schedule/src/client/TaskManagerPage.tsx | 214 | TaskManagerPage, TaskManagerInjected, TaskManagerPageProps | react, clsx, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-layout |
| packages/client/ui-schedule/src/client/TaskMenu.tsx | 347 | TaskMenu, TaskMenuItem, TaskMenuSeparator, TaskMenuLabel, TaskMenuEntry, TaskMenuProps | react, react-dom, clsx, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-schedule/src/index.ts | 8 | apply | — |
| packages/client/ui-schedule/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-session — @deepseek-ai/dsh-client-ui-session@0.2.1-alpha.1（4 文件 / 735 行）

职责：Session 模型→标准 Slot 源适配（useSessions 族）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-session/src/client/index.ts | 706 | apply, UiSession, inject, UseSessions, SessionSnapshotSelector, UseSession, SessionPendingInteractionBase, SessionPendingInteractionMap …等16项 | @deepseek-ai/cordis, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-session, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-store |
| packages/client/ui-session/src/client/session-provider.tsx | 20 | renderSessionArea | react, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-session/src/index.ts | 5 | apply | — |
| packages/client/ui-session/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-settings — @deepseek-ai/dsh-client-ui-settings@0.2.1-alpha.1（10 文件 / 1093 行）

职责：设置宿主（表单框架）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-settings/src/client/config-form-types.ts | 78 | ConfigFormSnapshot, ConfigForm | @deepseek-ai/dsh-api-remotes |
| packages/client/ui-settings/src/client/config-form.ts | 338 | ConfigFormController, ConfigForms | @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-util-values, @deepseek-ai/dsh-settings |
| packages/client/ui-settings/src/client/contract/slots.ts | 156 | SettingsGeneralItemOwnerProps, SettingsPluginsTabOwnerProps, SettingsTriggerOwnerProps, SettingsHeaderOwnerProps, SettingsSectionOwnerProps, SettingsOnboardingOwnerProps, SettingsLauncherOwnerProps | @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-settings/src/client/developer-tools.ts | 43 | DeveloperToolsPreference | @deepseek-ai/dsh-client-store |
| packages/client/ui-settings/src/client/index.ts | 55 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-settings |
| packages/client/ui-settings/src/client/schema.ts | 159 | SettingsSchemaService, SchemaNode | @deepseek-ai/cordis, @deepseek-ai/schemastery |
| packages/client/ui-settings/src/client/settings-mirror.ts | 214 | SettingsDescribeMirror, SettingsDescribeView, SettingsMirrorSnapshot, SettingsDescribeFace | @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-store |
| packages/client/ui-settings/src/developer-tools-settings.ts | 20 | DEVELOPER_TOOLS_NAMESPACE, DeveloperToolsSettingsFields, DeveloperToolsSettingsSchema, DeveloperToolsSettings | @deepseek-ai/schemastery |
| packages/client/ui-settings/src/index.ts | 26 | apply, Config | @deepseek-ai/dsh-settings, @deepseek-ai/cordis, @deepseek-ai/schemastery |
| packages/client/ui-settings/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-settings-account — @deepseek-ai/dsh-client-ui-settings-account@0.2.1-alpha.1（39 文件 / 2715 行）

职责：账号设置分节


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-settings-account/src/client/account-refresh.ts | 16 | refreshAfterReturn | — |
| packages/client/ui-settings-account/src/client/AccountAvatar.tsx | 17 | AccountAvatar | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-account/src/client/AccountMenu.tsx | 92 | AccountMenu, AccountMenuProps | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-settings-account/src/client/AccountNotice.tsx | 119 | AccountNoticeCard | react, react-dom, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-account/src/client/AccountOnboarding.tsx | 19 | AccountOnboarding | react, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-settings-models |
| packages/client/ui-settings-account/src/client/AccountPlatformHost.tsx | 34 | AccountPlatformHost, AccountPlatformHostInjected, AccountPlatformHostProps | @deepseek-ai/dsh-client-ui-layout, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-settings-account/src/client/AccountQuotaNotice.tsx | 82 | AccountQuotaNotice, AccountQuotaNoticeInjected | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-chat |
| packages/client/ui-settings-account/src/client/AccountSection.tsx | 216 | AccountSection, AccountSnapshot, AccountSectionInjected, AccountSectionProps | big.js, react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-deepseek-account, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-settings-account/src/client/authorize-url.ts | 15 | authorizeUrlWithTheme | — |
| packages/client/ui-settings-account/src/client/bonus-notices.ts | 271 | createBonusNoticeController, BonusNotice, BonusNoticeTiming, BonusNoticeControllerOptions, BonusNoticeController | @deepseek-ai/dsh-deepseek-account |
| packages/client/ui-settings-account/src/client/client-metadata.ts | 25 | accountClientMetadata | @deepseek-ai/dsh-deepseek-account |
| packages/client/ui-settings-account/src/client/contact-url.ts | 41 | contactUrl | @deepseek-ai/dsh-deepseek-account |
| packages/client/ui-settings-account/src/client/DesktopOnboarding.tsx | 126 | DesktopOnboarding | @deepseek-ai/dsh-client-product-analytics, react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-account/src/client/DesktopOnboardingEntry.tsx | 61 | DesktopOnboardingEntry, DesktopOnboardingInjected | react, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-layout |
| packages/client/ui-settings-account/src/client/formatBalance.ts | 22 | formatBalance | big.js |
| packages/client/ui-settings-account/src/client/index.ts | 306 | apply, inject | @deepseek-ai/dsh-client-product-analytics, @deepseek-ai/dsh-client-ui-chat, @deepseek-ai/cordis, @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-settings |
| packages/client/ui-settings-account/src/client/locales.ts | 74 | en, zh, AccountKey | — |
| packages/client/ui-settings-account/src/client/locales/onboarding.ts | 86 | onboardingCopy, onboardingEnglishCopy | — |
| packages/client/ui-settings-account/src/client/LogoutIcon.tsx | 11 | LogoutIcon | — |
| packages/client/ui-settings-account/src/client/onboarding-balance.ts | 13 | hasOnboardingCredit | big.js |
| packages/client/ui-settings-account/src/client/onboarding-contract.ts | 38 | DesktopOnboardingState, OnboardingChange, DesktopOnboardingProps | @deepseek-ai/dsh-client-product-analytics |
| packages/client/ui-settings-account/src/client/onboarding-credentials.ts | 14 | readOnboardingApiKeyPresence | — |
| packages/client/ui-settings-account/src/client/onboarding-state.ts | 247 | DesktopOnboardingController | @deepseek-ai/dsh-client-ui-chat, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-settings |
| packages/client/ui-settings-account/src/client/OnboardingConfirmation.tsx | 36 | OnboardingConfirmation, OnboardingConfirmationKind | @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-account/src/client/OnboardingCreditStep.tsx | 35 | OnboardingCreditStep | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-account/src/client/OnboardingIllustration.tsx | 11 | OnboardingIllustration | — |
| packages/client/ui-settings-account/src/client/OnboardingProcessStep.tsx | 56 | OnboardingProcessStep | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-account/src/client/OnboardingPurposeStep.tsx | 66 | OnboardingPurposeStep | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-account/src/client/OnboardingSurface.tsx | 43 | OnboardingSurface | react, react-dom |
| packages/client/ui-settings-account/src/client/OnboardingWelcomeStep.tsx | 29 | OnboardingWelcomeStep | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-account/src/client/overlay-inert.ts | 24 | acquireOverlayInert | — |
| packages/client/ui-settings-account/src/client/platform-pages.ts | 96 | createPlatformPages, PlatformPage, PlatformPageClaim, PlatformPageExit, PlatformPages | @deepseek-ai/dsh-client-store |
| packages/client/ui-settings-account/src/client/PlatformOverlay.tsx | 88 | PlatformOverlay, PlatformBridge | react, react-dom, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-account/src/client/SignInDialog.tsx | 90 | SignInDialog | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-deepseek-account |
| packages/client/ui-settings-account/src/client/SignOutDialog.tsx | 42 | SignOutDialog | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-account/src/contact-config.ts | 26 | ContactConfigFields, ContactConfig, CONTACT_CONFIG_GLOBAL | @deepseek-ai/schemastery |
| packages/client/ui-settings-account/src/index.ts | 57 | apply, Config | @deepseek-ai/cordis, @deepseek-ai/dsh-host-webserver, @deepseek-ai/dsh-settings, @deepseek-ai/schemastery |
| packages/client/ui-settings-account/src/onboarding-settings.ts | 44 | DESKTOP_ONBOARDING_NAMESPACE, OnboardingSettingsFields, OnboardingSettingsSchema, OnboardingStep, OnboardingPurpose, OnboardingProcess, OnboardingProgress, OnboardingSettings | @deepseek-ai/schemastery |
| packages/client/ui-settings-account/tsdown.config.ts | 27 | $ | node:fs, node:path, node:url |

#### packages/client/ui-settings-agent-loop — @deepseek-ai/dsh-client-ui-settings-agent-loop@0.2.1-alpha.1（6 文件 / 223 行）

职责：agent-loop 设置分节


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-settings-agent-loop/src/client/agent-loop-card-controller.ts | 64 | AgentLoopCardController, AGENT_LOOP_NS, AgentLoopSettings, AgentLoopCardState, AgentLoopCardFace | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-agent-loop/src/client/AgentLoopCard.tsx | 42 | AgentLoopCard, AgentLoopCardProps | @deepseek-ai/dsh-client-ui-plugin-manager, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-settings-agent-loop/src/client/index.ts | 51 | apply, NS, inject | @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-settings, @deepseek-ai/dsh-client-ui-plugin-manager, @deepseek-ai/dsh-client-ui-renderer, @deepseek-ai/cordis |
| packages/client/ui-settings-agent-loop/src/client/locales.ts | 51 | formLabels, en, zh, AgentLoopSettingsLocaleKey | @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-agent-loop/src/index.ts | 11 | apply | — |
| packages/client/ui-settings-agent-loop/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-settings-general — @deepseek-ai/dsh-client-ui-settings-general@0.2.1-alpha.1（16 文件 / 1183 行）

职责：通用设置分节


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-settings-general/src/client/chrome.tsx | 51 | TriggerContent, HeaderContent, CloseLabel, TriggerContentProps, HeaderContentProps, CloseLabelProps | @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-settings-general/src/client/CurrentVersionRow.tsx | 15 | CurrentVersionRow | @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-settings-general/src/client/desktop-update-source.ts | 44 | DesktopUpdateSource | @deepseek-ai/dsh-client-store |
| packages/client/ui-settings-general/src/client/DesktopUpdateIndicator.tsx | 101 | DesktopUpdateIndicator, DesktopUpdateBadge | @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-settings-general/src/client/DeveloperToolsRow.tsx | 38 | DeveloperToolsRow, DeveloperToolsRowInjected | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-settings-general/src/client/GeneralSection.tsx | 21 | GeneralSection, GeneralSectionComponentProps | @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-settings-general/src/client/index.ts | 240 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-connection, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-general/src/client/locales.ts | 81 | zh, en, SettingsKey | — |
| packages/client/ui-settings-general/src/client/settings-document-store.ts | 101 | SettingsDocumentStore, SettingsDocumentState | @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-settings |
| packages/client/ui-settings-general/src/client/SettingsDocumentAction.tsx | 52 | SettingsDocumentAction, SettingsDocumentActionInjected, SettingsDocumentActionProps | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-settings-general/src/client/SettingsRoot.tsx | 267 | SettingsRoot | react, react-dom, clsx, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-general/src/client/shell-contract.ts | 80 | SettingsSectionRow, SettingsOnboardingStep, SettingsRootInjected, SettingsRootComponentProps | @deepseek-ai/dsh-client-connection, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-sidebar, @deepseek-ai/dsh-client-ui-settings, @deepseek-ai/dsh-client-store |
| packages/client/ui-settings-general/src/client/shell-store.ts | 27 | createSettingsShellStore | @deepseek-ai/dsh-client-store |
| packages/client/ui-settings-general/src/index.ts | 25 | apply, Config | @deepseek-ai/dsh-settings, @deepseek-ai/cordis, @deepseek-ai/schemastery |
| packages/client/ui-settings-general/src/types.ts | 36 | DesktopUpdateFailureKind, DesktopUpdatePresentation, DesktopUpdateBridge, DesktopUpdateView | — |
| packages/client/ui-settings-general/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-settings-models — @deepseek-ai/dsh-client-ui-settings-models@0.2.1-alpha.1（24 文件 / 4087 行）

职责：模型设置分节


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-settings-models/src/client/apiKey.ts | 59 | apiKeyFailure, ApiKeyFailureKey | — |
| packages/client/ui-settings-models/src/client/CustomProviderCard.tsx | 321 | CustomProviderCard, CustomProviderCardProps | react, @deepseek-ai/dsh-util-values |
| packages/client/ui-settings-models/src/client/DeepSeekModelsEditor.tsx | 308 | parseCapacity, formatCapacity, modelDrafts, validateDeepSeekModels, DeepSeekModelsEditor, DeepSeekModelDraft, DeepSeekModelsValidationFailure, DeepSeekModelsEditorProps | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-models/src/client/DeepSeekOnboardingDialog.tsx | 138 | DeepSeekOnboardingDialog, DeepSeekOnboardingInjected, DeepSeekOnboardingDialogProps | @deepseek-ai/dsh-client-product-analytics, react, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-settings-models/src/client/EditorFooter.tsx | 68 | EditorFooter, EditorFooterProps | react |
| packages/client/ui-settings-models/src/client/index.ts | 163 | refreshIfLoaded, apply, inject | @deepseek-ai/dsh-client-product-analytics, @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-settings, @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-renderer |
| packages/client/ui-settings-models/src/client/locales.ts | 239 | en, zh, ModelsKey | — |
| packages/client/ui-settings-models/src/client/ModelInputTypes.tsx | 62 | ModelInputTypes | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-models/src/client/ModelListEditor.tsx | 462 | ModelListEditor, ModelDraft, ProbeTarget, ModelListEditorProps | react, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-models/src/client/ModelRow.tsx | 115 | ModelRow | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-models/src/client/ModelsSection.tsx | 705 | removeProviderProfile, needsSetup, providerTargetLabel, providerCopy, ModelsSection, ModelsSectionInjected, ModelsSectionProps, ProviderIdentity | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-api-remotes |
| packages/client/ui-settings-models/src/client/OnboardingModal.tsx | 53 | OnboardingModal | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-models/src/client/operations.ts | 110 | createModelsOperations, SettingsWriteOutcome, ModelDiscoveryOutcome, ModelsOperations | @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes |
| packages/client/ui-settings-models/src/client/protocol-label.ts | 28 | protocolLabel | — |
| packages/client/ui-settings-models/src/client/ProviderEditor.tsx | 540 | pathOps, ProviderEditor, ProviderEditorProps | react, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-util-values |
| packages/client/ui-settings-models/src/client/schema-operations.ts | 27 | createSettingsSchemaOperations, SettingsSchemaOperations | @deepseek-ai/dsh-client-ui-settings |
| packages/client/ui-settings-models/src/client/slot-contract.ts | 59 | ProviderCardExtrasOwnerProps, ModelsFooterOwnerProps | @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-settings-models/src/client/store.ts | 354 | joinProviderDirectory, deriveKeyRef, protocolChoices, providerUsable, onboardingReadiness, ModelsSettingsStore, ProviderDirectoryEntry, ProviderRow …等10项 | @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-settings |
| packages/client/ui-settings-models/src/client/welcome-store.ts | 141 | decodeWelcomeSection, WelcomeNoticeStore, WelcomeNoticeState, WelcomeSection | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-settings |
| packages/client/ui-settings-models/src/client/WelcomeNotice.tsx | 78 | WelcomeNotice, WelcomeNoticeInjected, WelcomeNoticeProps | react, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-models/src/index.ts | 23 | apply | @deepseek-ai/cordis, @deepseek-ai/dsh-host-webserver |
| packages/client/ui-settings-models/src/onboarding-config.ts | 18 | Config, ONBOARDING_CONFIG_GLOBAL | @deepseek-ai/schemastery |
| packages/client/ui-settings-models/src/onboarding-copy.ts | 12 | WELCOME_NOTICE_SETTINGS_NAMESPACE, WELCOME_NOTICE_ACK_FIELD, WELCOME_NOTICE_VERSION | — |
| packages/client/ui-settings-models/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-settings-plugin-inventory — @deepseek-ai/dsh-client-ui-settings-plugin-inventory@0.2.1-alpha.1（5 文件 / 770 行）

职责：插件清单设置分节


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-settings-plugin-inventory/src/client/index.ts | 65 | apply, NS, inject | @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-modules, @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-settings, @deepseek-ai/dsh-client-ui-renderer |
| packages/client/ui-settings-plugin-inventory/src/client/locales.ts | 93 | zh, en, PluginInventoryLocaleKey | — |
| packages/client/ui-settings-plugin-inventory/src/client/PluginInventorySettingsTab.tsx | 603 | PluginInventorySettingsTab, PluginInventorySettingsTabInjected, PluginInventorySettingsTabProps | react, @deepseek-ai/dsh-client-modules, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-package-manifest |
| packages/client/ui-settings-plugin-inventory/src/index.ts | 5 | apply | — |
| packages/client/ui-settings-plugin-inventory/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-settings-plugins — @deepseek-ai/dsh-client-ui-settings-plugins@0.2.1-alpha.1（5 文件 / 252 行）

职责：插件设置分节


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-settings-plugins/src/client/index.ts | 86 | apply, inject | @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-settings, @deepseek-ai/dsh-client-ui-renderer, @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-settings-plugins/src/client/locales.ts | 23 | en, zh, PluginsSettingsLocaleKey | — |
| packages/client/ui-settings-plugins/src/client/PluginsSettingsSection.tsx | 127 | PluginsSettingsSection, PluginsSettingsTabEntry, PluginsSettingsSectionInjected, PluginsSettingsSectionProps | react, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-settings-plugins/src/index.ts | 12 | apply | — |
| packages/client/ui-settings-plugins/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-settings-session-log — @deepseek-ai/dsh-client-ui-settings-session-log@0.2.1-alpha.1（6 文件 / 169 行）

职责：会话日志上传设置分节


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-settings-session-log/src/client/index.ts | 42 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-settings, @deepseek-ai/dsh-client-ui-layout, @deepseek-ai/dsh-client-ui-renderer |
| packages/client/ui-settings-session-log/src/client/locales.ts | 16 | en, zh | — |
| packages/client/ui-settings-session-log/src/client/upload-preference.ts | 51 | UploadPreference, UploadSettings, UploadMutation | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-settings |
| packages/client/ui-settings-session-log/src/client/UploadRow.tsx | 51 | UploadRow, UploadToast, UploadInjected | @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-settings, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-settings-session-log/src/index.ts | 5 | apply | — |
| packages/client/ui-settings-session-log/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-settings-shell — @deepseek-ai/dsh-client-ui-settings-shell@0.2.1-alpha.1（6 文件 / 249 行）

职责：shell 设置分节


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-settings-shell/src/client/index.ts | 54 | apply, NS, inject | @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-settings, @deepseek-ai/dsh-client-ui-plugin-manager, @deepseek-ai/dsh-client-ui-renderer, @deepseek-ai/cordis |
| packages/client/ui-settings-shell/src/client/locales.ts | 56 | formLabels, en, zh, ShellSettingsLocaleKey | @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-shell/src/client/shell-card-controller.ts | 68 | ShellCardController, BASH_NS, PWSH_NS, ShellSettings, ShellCardState, ShellCardFace | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-shell/src/client/ShellCard.tsx | 56 | ShellCard, ShellCardProps | @deepseek-ai/dsh-client-ui-plugin-manager, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-settings-shell/src/index.ts | 11 | apply | — |
| packages/client/ui-settings-shell/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-settings-subagent — @deepseek-ai/dsh-client-ui-settings-subagent@0.2.1-alpha.1（10 文件 / 964 行）

职责：子代理设置分节


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-settings-subagent/src/client/index.ts | 94 | apply, NS, SUBAGENT_NS, inject | @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-settings, @deepseek-ai/dsh-client-ui-plugin-manager, @deepseek-ai/dsh-client-ui-renderer, @deepseek-ai/dsh-api-remotes |
| packages/client/ui-settings-subagent/src/client/locales.ts | 110 | formLabels, en, zh, SubagentSettingsLocaleKey | @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-subagent/src/client/subagent-card-controller.ts | 80 | subagentCardShell, subagentCardFace, SubagentCardFace | @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-subagent/src/client/subagent-limits-card-controller.ts | 67 | SubagentLimitsCardController, SubagentLimitsSettings, SubagentLimitsCardState, SubagentLimitsCardFace | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-subagent/src/client/subagent-model-selection-card-controller.ts | 357 | subagentModelKey, subagentModelCandidates, SubagentModelSelectionCardController, SUBAGENT_MODEL_SELECTION_NS, AllowedSubagentModel, SubagentModelSelectionSettings, SubagentModelCandidate, SubagentModelSelectionCardState …等9项 | @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-subagent/src/client/SubagentCard.tsx | 53 | SubagentCard, SubagentCardProps | react, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-plugin-manager, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-subagent/src/client/SubagentLimitsFields.tsx | 58 | SubagentLimitsFields, SubagentLimitsFieldsProps | @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-subagent/src/client/SubagentModelSelectionFields.tsx | 129 | SubagentModelSelectionFields, SubagentModelSelectionFieldsProps | @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-settings-subagent/src/index.ts | 12 | apply | — |
| packages/client/ui-settings-subagent/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-settings-web-search — @deepseek-ai/dsh-client-ui-settings-web-search@0.2.1-alpha.1（6 文件 / 406 行）

职责：web 搜索设置分节


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-settings-web-search/src/client/index.ts | 61 | apply, NS, inject | @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-settings, @deepseek-ai/dsh-client-ui-plugin-manager, @deepseek-ai/dsh-client-ui-renderer, @deepseek-ai/dsh-api-remotes |
| packages/client/ui-settings-web-search/src/client/locales.ts | 65 | formLabels, en, zh, WebSearchSettingsLocaleKey | @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-web-search/src/client/web-search-card-controller.ts | 191 | WebSearchCardController, WEB_SEARCH_NS, WebSearchSettings, WebSearchCardState, WebSearchCardFace | @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-settings-web-search/src/client/WebSearchCard.tsx | 73 | WebSearchCard, WebSearchCardProps | @deepseek-ai/dsh-client-ui-plugin-manager, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-settings-web-search/src/index.ts | 12 | apply | — |
| packages/client/ui-settings-web-search/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-shortcuts — @deepseek-ai/dsh-client-ui-shortcuts@0.2.1-alpha.1（10 文件 / 647 行）

职责：快捷键参考 UI


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-shortcuts/src/client/Editor.tsx | 182 | ShortcutEditor | react, clsx, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-shortcuts, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-shortcuts/src/client/feedback.ts | 33 | shortcutReadFailure, shortcutFailure | @deepseek-ai/dsh-client-shortcuts, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-shortcuts/src/client/fixed.ts | 18 | fixedCommands | @deepseek-ai/dsh-client-shortcuts, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-shortcuts/src/client/Icons.tsx | 17 | ShortcutIcon | — |
| packages/client/ui-shortcuts/src/client/index.ts | 73 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-client-shortcuts, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-renderer |
| packages/client/ui-shortcuts/src/client/locales.ts | 71 | zh, en | — |
| packages/client/ui-shortcuts/src/client/Reference.tsx | 223 | ShortcutsRow, ShortcutReference, ReferenceInjected | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-shortcuts |
| packages/client/ui-shortcuts/src/client/store.ts | 21 | createShortcutsStore | @deepseek-ai/dsh-client-store |
| packages/client/ui-shortcuts/src/index.ts | 5 | apply | — |
| packages/client/ui-shortcuts/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-sidebar — @deepseek-ai/dsh-client-ui-sidebar@0.2.1-alpha.1（7 文件 / 654 行）

职责：左侧栏（会话列表）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-sidebar/src/client/contract/slots.ts | 149 | SidebarBrandMarkOwnerProps, SidebarBrandNameOwnerProps, SidebarPanelIconOwnerProps, SidebarPanelMetadata, SidebarSectionOwnerProps, SidebarSettingsOwnerProps, SidebarFooterActionOwnerProps, SidebarRootInjected …等9项 | @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-api-workspace-controller, @deepseek-ai/dsh-client-shortcuts, @deepseek-ai/dsh-client-ui-layout |
| packages/client/ui-sidebar/src/client/HeaderLeadingControls.tsx | 56 | HeaderLeadingControls, HeaderLeadingControlsProps | @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-layout |
| packages/client/ui-sidebar/src/client/index.ts | 101 | apply, inject | @deepseek-ai/dsh-client-product-analytics, @deepseek-ai/cordis, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-layout |
| packages/client/ui-sidebar/src/client/locales.ts | 23 | zh, en, SidebarKey | — |
| packages/client/ui-sidebar/src/client/SidebarRoot.tsx | 316 | SidebarRoot | react, clsx, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-sidebar/src/index.ts | 5 | apply | — |
| packages/client/ui-sidebar/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-sidebar-browser — @deepseek-ai/dsh-client-ui-sidebar-browser@0.2.1-alpha.1（23 文件 / 1656 行）

职责：内嵌浏览器侧栏


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-sidebar-browser/src/client/browser/BrowserController.ts | 268 | createBrowserControllers, BrowserController, BrowserControllerState, BrowserControllerOptions, BrowserMountRequest, BrowserInjected | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-dockkit, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-sidebar-browser/src/client/browser/BrowserFrame.ts | 52 | emptyBrowserFrame, BrowserLoadError, BrowserFrameState, BrowserSandboxControl, BrowserFrame | @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-sidebar-browser/src/client/browser/BrowserNavigation.ts | 144 | BrowserNavigation, MAX_BROWSER_HISTORY | — |
| packages/client/ui-sidebar-browser/src/client/browser/BrowserPage.ts | 21 | BrowserPageOptions, BrowserPage, BrowserPageFactory | — |
| packages/client/ui-sidebar-browser/src/client/browser/BrowserPersistence.ts | 45 | currentBrowserTarget, browserAddressCheckpoint, BrowserHistoryEntry, BrowserNavigationStatus, BrowserFailure, BrowserTabState | — |
| packages/client/ui-sidebar-browser/src/client/browser/IframeImpl.ts | 105 | IframeImpl | @deepseek-ai/dsh-client-store |
| packages/client/ui-sidebar-browser/src/client/browser/store.ts | 39 | createBrowserStore, BrowserState, BrowserStore | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-dockkit |
| packages/client/ui-sidebar-browser/src/client/browser/url.ts | 46 | parseBrowserAddress, MAX_BROWSER_URL_LENGTH, BrowserTarget, BrowserAddressFailure, BrowserAddressResult | — |
| packages/client/ui-sidebar-browser/src/client/definition.tsx | 28 | browserDefinition, BROWSER_KIND, BROWSER_ID | @deepseek-ai/dsh-client-shortcuts, @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-sidebar-right |
| packages/client/ui-sidebar-browser/src/client/electron/ElectronWebViewImpl.ts | 272 | ElectronWebViewImpl | @deepseek-ai/dsh-client-store |
| packages/client/ui-sidebar-browser/src/client/electron/ElectronWebviewPresentation.ts | 95 | ElectronWebviewPresentation, WebviewElement, ElectronPresentationEvents | — |
| packages/client/ui-sidebar-browser/src/client/electron/pages.ts | 23 | createElectronPage | — |
| packages/client/ui-sidebar-browser/src/client/electron/workspace.ts | 34 | browserWorkspace | @deepseek-ai/dsh-api-workspace-controller |
| packages/client/ui-sidebar-browser/src/client/index.ts | 106 | apply, inject | @deepseek-ai/dsh-client-shortcuts, @deepseek-ai/cordis, @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-renderer, @deepseek-ai/dsh-client-ui-session |
| packages/client/ui-sidebar-browser/src/client/locales.ts | 70 | zh, en, SidebarBrowserKey | — |
| packages/client/ui-sidebar-browser/src/client/pages.ts | 20 | createIframePage | — |
| packages/client/ui-sidebar-browser/src/client/view/BrowserBody.tsx | 134 | BrowserBody, BrowserBodyProps | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-sidebar-browser/src/client/view/BrowserPresentation.ts | 10 | BrowserPresentation | — |
| packages/client/ui-sidebar-browser/src/client/view/BrowserTitle.tsx | 18 | BrowserTitle, BrowserTitleProps | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-sidebar-browser/src/client/view/IframePresentation.ts | 89 | IframePresentation, WEB_BROWSER_SANDBOX, IframePresentationEvents | — |
| packages/client/ui-sidebar-browser/src/index.ts | 5 | apply | — |
| packages/client/ui-sidebar-browser/src/types.ts | 28 | DesktopBrowserLeaseId, DesktopBrowserReservation, DesktopBrowserOpenRequest, DesktopBrowserBridge | @deepseek-ai/dsh-brand |
| packages/client/ui-sidebar-browser/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-sidebar-documentpreview — @deepseek-ai/dsh-client-ui-sidebar-documentpreview@0.2.1-alpha.1（79 文件 / 5541 行）

职责：文档预览侧栏（office-to-pdf 集成）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-sidebar-documentpreview/src/client/code/CodeBody.tsx | 36 | CodeBody, CodeBodyProps | react, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-util-workspace-path |
| packages/client/ui-sidebar-documentpreview/src/client/code/index.ts | 27 | apply | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-sidebar-documentpreview/src/client/code/locales.ts | 24 | zh, en | @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-sidebar-documentpreview/src/client/definition.ts | 55 | basenameOf, textDefinition, TEXTPREVIEW_KIND, TEXTPREVIEW_ID | @deepseek-ai/dsh-client-ui-sidebar-right, @deepseek-ai/dsh-util-workspace-path |
| packages/client/ui-sidebar-documentpreview/src/client/document/contract.ts | 108 | documentTabInfoFactory, DocumentTextPage, DocumentContent, DocumentBodyOwner, DocumentPreviewProps | @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-sidebar-right, react |
| packages/client/ui-sidebar-documentpreview/src/client/document/registry.ts | 129 | matchingDocumentPreviews, binaryDocumentPath, DocumentPreviewRegistry, DocumentLoadMode, DocumentPreviewDefinition | @deepseek-ai/dsh-client-store |
| packages/client/ui-sidebar-documentpreview/src/client/document/resource-group.ts | 51 | ResourceGroup | @deepseek-ai/dsh-client-resources, @deepseek-ai/dsh-api-workspace-files |
| packages/client/ui-sidebar-documentpreview/src/client/document/suffix.ts | 37 | normalizeSuffix, documentFileName, matchedSuffixLength | — |
| packages/client/ui-sidebar-documentpreview/src/client/document/tab-lifetime.ts | 25 | retainDocumentTabs | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-dockkit |
| packages/client/ui-sidebar-documentpreview/src/client/document/unviewable.ts | 38 | unviewableBinaryPath | — |
| packages/client/ui-sidebar-documentpreview/src/client/excel/convert.ts | 22 | convertExcel | — |
| packages/client/ui-sidebar-documentpreview/src/client/excel/delimited.ts | 45 | convertDelimited | papaparse, @fortune-sheet/core |
| packages/client/ui-sidebar-documentpreview/src/client/excel/error.ts | 9 | ExcelPreviewError | — |
| packages/client/ui-sidebar-documentpreview/src/client/excel/excel.tsx | 69 | ExcelBody | react, @fortune-sheet/react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-sidebar-documentpreview/src/client/excel/format.ts | 17 | excelFormat, ExcelFormat | — |
| packages/client/ui-sidebar-documentpreview/src/client/excel/index.ts | 25 | apply | @deepseek-ai/cordis |
| packages/client/ui-sidebar-documentpreview/src/client/excel/LazyExcelBody.tsx | 30 | LazyExcelBody, ExcelBodyProps, LoadedExcelBodyProps | react, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-sidebar-documentpreview/src/client/excel/locales.ts | 34 | zh, en, ExcelPreviewKey | — |
| packages/client/ui-sidebar-documentpreview/src/client/excel/model.ts | 50 | initialSelection, formatCell, EXCEL_UNSUPPORTED_FEATURES, ExcelLimits, ExcelUnsupportedFeature, ExcelPreview | @fortune-sheet/core |
| packages/client/ui-sidebar-documentpreview/src/client/excel/parse.ts | 71 | parseExcel | — |
| packages/client/ui-sidebar-documentpreview/src/client/excel/worker.ts | 13 | — | — |
| packages/client/ui-sidebar-documentpreview/src/client/excel/xls.ts | 100 | convertXls, mapXlsWorkbook | xlsx, @fortune-sheet/core |
| packages/client/ui-sidebar-documentpreview/src/client/excel/xlsx-archive.ts | 111 | XlsxPreviewArchive | fflate, fast-xml-parser |
| packages/client/ui-sidebar-documentpreview/src/client/excel/xlsx.ts | 238 | convertXlsx | exceljs, @fortune-sheet/core, fast-xml-parser |
| packages/client/ui-sidebar-documentpreview/src/client/face.ts | 224 | textFace, TextInjected | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-dockkit, @deepseek-ai/dsh-session, @deepseek-ai/dsh-client-resources |
| packages/client/ui-sidebar-documentpreview/src/client/failure-line.ts | 58 | failureLine, emptyFailureRecourse, EmptyFailureRecourse | @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-locale |
| packages/client/ui-sidebar-documentpreview/src/client/html/basic-document.ts | 23 | createBasicHtmlDocument | dompurify |
| packages/client/ui-sidebar-documentpreview/src/client/html/bootstrap.ts | 49 | createHtmlDocument, HtmlAsset, HtmlBundle | — |
| packages/client/ui-sidebar-documentpreview/src/client/html/bytes.ts | 27 | decodeText, encodeText | — |
| packages/client/ui-sidebar-documentpreview/src/client/html/HtmlBody.tsx | 104 | HtmlBody, HtmlBodyProps, HtmlBodyInjected | react, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-store |
| packages/client/ui-sidebar-documentpreview/src/client/html/index.ts | 44 | htmlBodyDefinition, apply, HTML_BODY_ID | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-settings |
| packages/client/ui-sidebar-documentpreview/src/client/html/locales.ts | 26 | zh, en, HtmlPreviewKey | — |
| packages/client/ui-sidebar-documentpreview/src/client/html/pack.ts | 73 | packHtml, ReadHtmlRelative | — |
| packages/client/ui-sidebar-documentpreview/src/client/html/read-relative.ts | 52 | createReadHtmlRelative, ReadHtmlRelated | @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-util-workspace-path |
| packages/client/ui-sidebar-documentpreview/src/client/image/ImageBody.tsx | 135 | imageMediaType, ImageBody, ImageBodyProps | react, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-util-workspace-path |
| packages/client/ui-sidebar-documentpreview/src/client/image/index.ts | 55 | imageBodyDefinition, apply, IMAGE_BODY_ID, IMAGE_EXTENSIONS, BINARY_IMAGE_EXTENSIONS | @deepseek-ai/cordis, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-session |
| packages/client/ui-sidebar-documentpreview/src/client/image/locales.ts | 32 | zh, en, ImagePreviewKey | — |
| packages/client/ui-sidebar-documentpreview/src/client/index.ts | 131 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-resources, @deepseek-ai/dsh-client-ui-renderer |
| packages/client/ui-sidebar-documentpreview/src/client/LoadingIndicator.tsx | 20 | LoadingIndicator | react, clsx, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-sidebar-documentpreview/src/client/locales.ts | 63 | zh, en, SidebarDocumentPreviewKey | — |
| packages/client/ui-sidebar-documentpreview/src/client/markdown/frontmatter-fields.tsx | 73 | FrontmatterFields, FrontmatterFieldsProps | react, yaml |
| packages/client/ui-sidebar-documentpreview/src/client/markdown/frontmatter.ts | 23 | splitFrontmatter, FrontmatterSplit | — |
| packages/client/ui-sidebar-documentpreview/src/client/markdown/index.ts | 32 | markdownDefinition, apply, MARKDOWN_BODY_ID | @deepseek-ai/cordis |
| packages/client/ui-sidebar-documentpreview/src/client/markdown/locales.ts | 26 | zh, en, MarkdownPreviewKey | — |
| packages/client/ui-sidebar-documentpreview/src/client/markdown/MarkdownBody.tsx | 72 | MarkdownBody, MarkdownBodyProps | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-sidebar-documentpreview/src/client/markdown/path-images.ts | 29 | markdownImageUrl | @deepseek-ai/dsh-util-workspace-path |
| packages/client/ui-sidebar-documentpreview/src/client/office/cache.ts | 194 | OfficePreviewCache, OfficeFileBytes, ReadOfficeDocument, ReadOfficeBytes | @deepseek-ai/dsh-office-to-pdf, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-api-workspace-files |
| packages/client/ui-sidebar-documentpreview/src/client/office/face.ts | 65 | officeFace, OfficeLoadInjected | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-dockkit, @deepseek-ai/dsh-session, @deepseek-ai/dsh-api-remotes |
| packages/client/ui-sidebar-documentpreview/src/client/office/FontNotice.tsx | 67 | FontNotice, FontNoticeProps | react, react-dom, clsx, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-sidebar-documentpreview/src/client/office/index.ts | 132 | apply | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-renderer, @deepseek-ai/dsh-office-to-pdf, @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-api-workspace-files |
| packages/client/ui-sidebar-documentpreview/src/client/office/locales.ts | 41 | zh, en, OfficePreviewKey | — |
| packages/client/ui-sidebar-documentpreview/src/client/office/OfficeBody.tsx | 79 | OfficeBody, OfficeBodyInjected, OfficeBodyProps | react, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-dockkit, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-util-workspace-path |
| packages/client/ui-sidebar-documentpreview/src/client/office/OfficeFontAction.tsx | 22 | OfficeFontAction, OfficeFontActionProps | react, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-sidebar-documentpreview/src/client/office/store.ts | 54 | createOfficeStore, OfficeView, OfficeState, OfficeStore | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-dockkit |
| packages/client/ui-sidebar-documentpreview/src/client/pdf/assets.ts | 40 | createPdfBinaryDataFactory, PdfAssetKind, PdfAssetMap, PdfBinaryDataFactory | pdfjs-dist |
| packages/client/ui-sidebar-documentpreview/src/client/pdf/document.ts | 92 | renderPdfPage, PdfDocument, PdfSession, PdfPageSize, RenderPdfText | pdfjs-dist |
| packages/client/ui-sidebar-documentpreview/src/client/pdf/errors.ts | 12 | PdfWorkerFailure | — |
| packages/client/ui-sidebar-documentpreview/src/client/pdf/index.ts | 57 | pdfBodyDefinition, apply, pdfBodyRegistration, PDF_BODY_ID | @deepseek-ai/cordis, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-session |
| packages/client/ui-sidebar-documentpreview/src/client/pdf/LazyPdfBody.tsx | 19 | LazyPdfBody | react |
| packages/client/ui-sidebar-documentpreview/src/client/pdf/locales.ts | 40 | zh, en, PdfLocaleKey | — |
| packages/client/ui-sidebar-documentpreview/src/client/pdf/pdf.tsx | 214 | PdfBody, PdfBodyInjected, PdfBodyProps | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-dockkit |
| packages/client/ui-sidebar-documentpreview/src/client/pdf/runtime.ts | 113 | openPdf | pdfjs-dist |
| packages/client/ui-sidebar-documentpreview/src/client/pdf/store.ts | 53 | createPdfStore, PdfView, PdfState, PdfStore | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-dockkit |
| packages/client/ui-sidebar-documentpreview/src/client/pdf/text.ts | 39 | pdfTextRenderer | pdfjs-dist |
| packages/client/ui-sidebar-documentpreview/src/client/rpc.ts | 94 | hostFileOf, createReadPage, WorkspaceFilesReadRemote, ReadWorkspaceFilePage, SessionFile, DocumentFileBytes, ReadDocumentBytes | @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-session, @deepseek-ai/dsh-api-workspace-files, @deepseek-ai/dsh-util-workspace-path |
| packages/client/ui-sidebar-documentpreview/src/client/store.ts | 269 | fresh, createTextStore, TextPage, TextTabState, TextState, TextStore | @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-dockkit, @deepseek-ai/dsh-api-workspace-files |
| packages/client/ui-sidebar-documentpreview/src/client/text/index.ts | 27 | textBodyDefinition, apply, PLAIN_BODY_ID | @deepseek-ai/cordis |
| packages/client/ui-sidebar-documentpreview/src/client/text/lines.ts | 53 | linesOf, loadedPages, lastLineLoaded, scrollToLine, LoadedPage | — |
| packages/client/ui-sidebar-documentpreview/src/client/text/TextBody.tsx | 36 | TextBody | react, clsx |
| packages/client/ui-sidebar-documentpreview/src/client/TextPreview.tsx | 406 | TextPreview, TextPreviewInjected, TextPreviewProps | react, clsx, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-sidebar-documentpreview/src/client/TextTitle.tsx | 25 | TextTitle | react, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-sidebar-documentpreview/src/client/zoom/locales.ts | 23 | zoomZh, zoomEn, ZoomLocaleKey | — |
| packages/client/ui-sidebar-documentpreview/src/client/zoom/store.ts | 44 | createZoomStore, DEFAULT_ZOOM, ZoomInjected, ZoomState, ZoomStore | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-dockkit |
| packages/client/ui-sidebar-documentpreview/src/client/zoom/types.ts | 30 | FIT_WIDTH, MIN_FIXED_ZOOM, MAX_FIXED_ZOOM, ZOOM_STEP, ZOOM_OPTIONS, ZoomPreference, ZoomLabels | — |
| packages/client/ui-sidebar-documentpreview/src/client/zoom/ZoomControls.tsx | 79 | ZoomControls, ZoomControlsHandle | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-sidebar-documentpreview/src/client/zoom/ZoomViewport.tsx | 216 | fitWidthZoom, ZoomViewport, zoomSurfaceClass, ZoomViewportProps | react |
| packages/client/ui-sidebar-documentpreview/src/config.ts | 42 | Config | @deepseek-ai/schemastery |
| packages/client/ui-sidebar-documentpreview/src/index.ts | 18 | apply | @deepseek-ai/cordis, @deepseek-ai/dsh-host-webserver |
| packages/client/ui-sidebar-documentpreview/tsdown.config.ts | 111 | $ | node:fs, node:module, node:path, tsdown |

#### packages/client/ui-sidebar-files — @deepseek-ai/dsh-client-ui-sidebar-files@0.2.1-alpha.1（10 文件 / 1047 行）

职责：文件侧栏


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-sidebar-files/src/client/definition.tsx | 41 | filesDefinition, FILES_KIND, FILES_ID | @deepseek-ai/dsh-client-shortcuts, @deepseek-ai/dsh-client-ui-sidebar-right, @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-sidebar-files/src/client/directory-node.ts | 157 | DirectoryNode | — |
| packages/client/ui-sidebar-files/src/client/face.ts | 222 | createWatch, createList, childPath, filesFace, WatchWorkspaceDirectory, ListWorkspaceDirectory, WorkspaceFilesListRemote, FilesInjected | @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-dockkit, @deepseek-ai/dsh-session, @deepseek-ai/dsh-api-workspace-files |
| packages/client/ui-sidebar-files/src/client/FilesBody.tsx | 232 | orderEntries, failureLine, FilesBody, FilesBodyProps | react, clsx, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-sidebar-files/src/client/FilesTitle.tsx | 26 | FilesTitle | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-sidebar-files/src/client/index.ts | 98 | apply, inject | @deepseek-ai/dsh-client-shortcuts, @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-ui-renderer, @deepseek-ai/dsh-client-ui-session |
| packages/client/ui-sidebar-files/src/client/locales.ts | 65 | zh, en, SidebarFilesKey | @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-sidebar-files/src/client/store.ts | 197 | createFilesStore, DirLevel, LevelState, FilesTabState, FilesState | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-ui-dockkit, @deepseek-ai/dsh-api-workspace-files |
| packages/client/ui-sidebar-files/src/index.ts | 5 | apply | — |
| packages/client/ui-sidebar-files/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-sidebar-right — @deepseek-ai/dsh-client-ui-sidebar-right@0.2.1-alpha.1（26 文件 / 3929 行）

职责：右侧栏框架


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-sidebar-right/src/client/contract/params.ts | 53 | SidebarRightResourceParamsMap, SidebarRightResourceParams, SidebarRightTabParamsMap, SidebarRightTabParamsFor, SidebarRightTabParams, SidebarRightNavigationParams | — |
| packages/client/ui-sidebar-right/src/client/contract/seed.ts | 48 | defaultSeed, pageAddress, GUIDE_KIND, SidebarRightSeed | — |
| packages/client/ui-sidebar-right/src/client/contract/slots.ts | 218 | SidebarRightTabNavigation, SidebarRightTabPlacement, SidebarRightTabCommands, SidebarRightTabActions, SidebarRightTabInfo, UseSidebarRightTabInfo, SidebarRightTabInjected, SidebarRightTabMenuOwnerProps …等9项 | @deepseek-ai/dsh-client-shortcuts, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-layout, @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-dockkit |
| packages/client/ui-sidebar-right/src/client/focus.ts | 138 | sidebarTargetFromElement, visibleSidebarPane, observeSidebarFocus, SidebarRightTarget | @deepseek-ai/dsh-client-ui-dockkit, @deepseek-ai/dsh-session |
| packages/client/ui-sidebar-right/src/client/index.ts | 280 | apply, inject | @deepseek-ai/dsh-client-shortcuts, @deepseek-ai/cordis, @deepseek-ai/dsh-client-resources, @deepseek-ai/dsh-client-ui-renderer, @deepseek-ai/dsh-client-ui-session |
| packages/client/ui-sidebar-right/src/client/labels.ts | 45 | dockLabels | @deepseek-ai/dsh-client-shortcuts, @deepseek-ai/dsh-client-ui-dockkit, @deepseek-ai/dsh-client-locale |
| packages/client/ui-sidebar-right/src/client/locales.ts | 87 | zh, en, SidebarRightKey | — |
| packages/client/ui-sidebar-right/src/client/persistence.ts | 102 | readSidebarLayout, writeSidebarLayout, clearSidebarLayout, sidebarPersistence | zod, @deepseek-ai/dsh-client-ui-dockkit |
| packages/client/ui-sidebar-right/src/client/service.ts | 735 | createSidebarRightController, SidebarRightController, SurfaceActions, SidebarRightSurfaceStore, SidebarRightHost, SidebarRightPlacement, SidebarRightOpenResourceOptions, SidebarRightOpenTabOptions …等10项 | @deepseek-ai/dsh-util-crypto, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-dockkit, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-session |
| packages/client/ui-sidebar-right/src/client/session-view.ts | 92 | SidebarSessionView | @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-session, @deepseek-ai/dsh-client-ui-dockkit |
| packages/client/ui-sidebar-right/src/client/session-views.ts | 81 | SidebarSessionViews, SidebarSessionViewSnapshot | @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-session, @deepseek-ai/dsh-client-store |
| packages/client/ui-sidebar-right/src/client/shell/close-focus.ts | 36 | openWithPaneFocus, closeWithPaneFocus | react-dom, @deepseek-ai/dsh-client-ui-dockkit, @deepseek-ai/dsh-session |
| packages/client/ui-sidebar-right/src/client/shell/ExpandButton.tsx | 54 | ExpandButton, ExpandButtonProps | @deepseek-ai/dsh-client-shortcuts, @deepseek-ai/dsh-client-ui-slots, react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-sidebar-right/src/client/shell/RightbarRoot.tsx | 39 | RightbarRoot, RightbarRootInjected | react, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-api-session-controller |
| packages/client/ui-sidebar-right/src/client/shell/SidebarRight.tsx | 424 | intentsFor, RightbarSeat, SidebarRightPresentation, SidebarRightInjected, RightbarSeatProps | react, @deepseek-ai/dsh-client-shortcuts, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-dockkit |
| packages/client/ui-sidebar-right/src/client/shortcuts.ts | 100 | registerSidebarShortcuts | @deepseek-ai/dsh-client-shortcuts, @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-sidebar-right/src/client/stores.ts | 439 | canCloseTab, createSurface, soleDockedTab, createSidebarRightStore, SurfaceState, SidebarRightState, OpenContentIntent | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-dockkit |
| packages/client/ui-sidebar-right/src/client/tab-domain.ts | 210 | TabDomain, SidebarRightNavigator, PinResource, SidebarRightOccurrenceId, TabOccurrence | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-util-crypto, @deepseek-ai/dsh-client-ui-dockkit, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-session |
| packages/client/ui-sidebar-right/src/client/tab-info.ts | 65 | tabInfoFactory, guideTabInfoFactory, TabHookContext | @deepseek-ai/dsh-client-shortcuts, react, @deepseek-ai/dsh-client-ui-dockkit, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-sidebar-right/src/client/tab-inventory.ts | 60 | SidebarTabInventory, SidebarRightOpenTab | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-session, @deepseek-ai/dsh-client-ui-dockkit |
| packages/client/ui-sidebar-right/src/client/tab-registry.ts | 415 | SidebarRightTabRegistry, SidebarRightTabPriority, SidebarRightGuideEntry, SidebarRightGuideBox, SidebarRightTabDefinition, SidebarRightTabClaim | @deepseek-ai/dsh-client-shortcuts, react, @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-store |
| packages/client/ui-sidebar-right/src/client/tabs/guide/definition.ts | 28 | guideDefinition, GUIDE_ID | @deepseek-ai/dsh-client-locale |
| packages/client/ui-sidebar-right/src/client/tabs/guide/GuideBody.tsx | 113 | GuideBody, GuideInjected, GuideBodyProps | @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-shortcuts, react, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-sidebar-right/src/client/tabs/guide/GuideTitle.tsx | 58 | CompassGlyph, CubeGlyph, GuideTitle | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-sidebar-right/src/index.ts | 5 | apply | — |
| packages/client/ui-sidebar-right/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-sidebar-terminal — @deepseek-ai/dsh-client-ui-sidebar-terminal@0.2.1-alpha.1（14 文件 / 773 行）

职责：终端侧栏


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-sidebar-terminal/src/client/face.ts | 26 | TerminalInjected, TerminalBodyInjected | @deepseek-ai/dsh-api-terminal-controller, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-theme |
| packages/client/ui-sidebar-terminal/src/client/index.ts | 131 | apply, inject | @deepseek-ai/dsh-client-shortcuts, @deepseek-ai/cordis, @deepseek-ai/dsh-api-terminal-controller, @deepseek-ai/dsh-client-ui-sidebar-right, @deepseek-ai/dsh-session |
| packages/client/ui-sidebar-terminal/src/client/LazyTerminalBody.tsx | 15 | LazyTerminalBody | react |
| packages/client/ui-sidebar-terminal/src/client/locales.ts | 45 | zh, en | @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-sidebar-terminal/src/client/terminal-cursor.ts | 62 | observeTerminalCursor | @xterm/xterm |
| packages/client/ui-sidebar-terminal/src/client/terminal-theme.ts | 105 | TerminalTheme | @xterm/xterm |
| packages/client/ui-sidebar-terminal/src/client/terminal.tsx | 161 | TerminalBody, TerminalBodyProps | react, @xterm/xterm, @xterm/addon-fit, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-api-terminal-controller |
| packages/client/ui-sidebar-terminal/src/client/TerminalCleanup.tsx | 30 | TerminalCleanup, TerminalCleanupInjected | react, @deepseek-ai/dsh-api-terminal-controller, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-layout |
| packages/client/ui-sidebar-terminal/src/client/TerminalGuide.tsx | 84 | TerminalGuide, TerminalGuideInjected, TerminalGuideProps | react, @deepseek-ai/dsh-client-shortcuts, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-api-terminal-controller |
| packages/client/ui-sidebar-terminal/src/client/TerminalIcon.tsx | 14 | TerminalIcon | react |
| packages/client/ui-sidebar-terminal/src/client/TerminalRecovery.tsx | 30 | TerminalRecovery, TerminalRecoveryInjected | react, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-sidebar-terminal/src/client/TerminalTitle.tsx | 61 | TerminalTitle | react, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-sidebar-terminal/src/index.ts | 5 | apply | — |
| packages/client/ui-sidebar-terminal/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-skill — @deepseek-ai/dsh-client-ui-skill@0.2.1-alpha.1（5 文件 / 460 行）

职责：技能 UI


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-skill/src/client/index.ts | 240 | apply, inject | @deepseek-ai/dsh-client-ui-sidebar-right, @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-session |
| packages/client/ui-skill/src/client/locales.ts | 32 | NS, zh, en, SkillKey | — |
| packages/client/ui-skill/src/client/SkillRow.tsx | 174 | SkillRow | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-tool, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-skill/src/index.ts | 10 | apply | — |
| packages/client/ui-skill/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-slots — @deepseek-ai/dsh-client-ui-slots@0.2.1-alpha.1（4 文件 / 1974 行）

职责：类型化 Slot/Factory/Locale/Resource 四张声明合并表（零运行时依赖契约）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-slots/src/index.ts | 1670 | resolveSlotLabel, SlotCore, SlotMap, SlotFactoryMap, LocaleNamespaceMap, ResourceProtocolMap, Translate, CommonKeyOf …等71项 | react, @deepseek-ai/dsh-client-store |
| packages/client/ui-slots/src/renderer.ts | 279 | standardHookPropName, StaleAuthorizationError, SlotOwnershipError, LocaleFace, HostObservable, StoreInstanceLike, KeyedStandardSource, StandardSourceBinding …等14项 | @deepseek-ai/cordis, react, @deepseek-ai/dsh-client-store |
| packages/client/ui-slots/src/store.ts | 18 | — | @deepseek-ai/dsh-client-store |
| packages/client/ui-slots/tsdown.config.ts | 7 | staticLinked | — |

#### packages/client/ui-subagent — @deepseek-ai/dsh-client-ui-subagent@0.2.1-alpha.1（7 文件 / 1255 行）

职责：子代理呈现 UI


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-subagent/src/client/index.ts | 105 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-subagent, @deepseek-ai/dsh-session, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-client-locale |
| packages/client/ui-subagent/src/client/locales.ts | 94 | NS, zh, en, SubagentKey | — |
| packages/client/ui-subagent/src/client/sidebar-chat/index.tsx | 203 | subagentChatAddress, parseSubagentChatAddress, FixedChatConversationView, ConversationSlotPanel, SidebarChatTab, registerSidebarChat, SUBAGENT_CHAT_ID, SUBAGENT_CHAT_ADDRESS …等11项 | @deepseek-ai/cordis, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-client-resources, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-client-ui-sidebar-right |
| packages/client/ui-subagent/src/client/SubagentHeaderLineage.tsx | 807 | SubagentCatalogAction, SubagentHeaderLineage, SubagentCatalogInjected, SubagentHeaderLineageProps, SubagentCatalogActionProps | react, react-dom, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-subagent, @deepseek-ai/dsh-session |
| packages/client/ui-subagent/src/client/SubagentReadOnlyComposer.tsx | 32 | SubagentReadOnlyComposer, SubagentReadOnlyMatch, SubagentReadOnlyComposerProps | @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-subagent/src/index.ts | 10 | apply | — |
| packages/client/ui-subagent/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-theme — @deepseek-ai/dsh-client-ui-theme@0.2.1-alpha.1（10 文件 / 924 行）

职责：--dsw-* 主题刻度/语义别名/明暗主题


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-theme/src/boot-theme.ts | 54 | bootThemeInjections | @deepseek-ai/dsh-host-webserver |
| packages/client/ui-theme/src/client/AppearanceRow.tsx | 64 | AppearanceRow, AppearanceRowInjected, AppearanceRowComponentProps | clsx, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-settings |
| packages/client/ui-theme/src/client/FontSizeRow.tsx | 72 | FontSizeRow, FontSizeRowInjected, FontSizeRowComponentProps | @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-settings |
| packages/client/ui-theme/src/client/index.ts | 480 | apply, ThemeRuntime, SETTINGS_NS, inject, ThemeTokens, ThemeTokenModes, ThemeTokenOverrides, ThemeDefinition …等10项 | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-settings, @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-renderer |
| packages/client/ui-theme/src/client/locales.ts | 31 | zh, en, ThemeKey | — |
| packages/client/ui-theme/src/client/settings-store.ts | 68 | createAppearanceRowStore, createFontSizeRowStore, AppearanceRowState, FontSizeRowState | @deepseek-ai/dsh-client-store |
| packages/client/ui-theme/src/client/styles.ts | 41 | installThemeStyles | @deepseek-ai/cordis |
| packages/client/ui-theme/src/index.ts | 45 | apply, Config | @deepseek-ai/dsh-settings, @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-host-webserver |
| packages/client/ui-theme/src/theme-settings.ts | 54 | isThemePreference, THEME_PREFERENCES, THEME_SETTINGS_NAMESPACE, THEME_PREFERENCE_FIELD, FONT_SIZE_FIELD, DEFAULT_PREFERENCE, FONT_SIZE_MIN, FONT_SIZE_MAX …等12项 | @deepseek-ai/schemastery |
| packages/client/ui-theme/tsdown.config.ts | 15 | clientBundle | — |

#### packages/client/ui-tool — @deepseek-ai/dsh-client-ui-tool@0.2.1-alpha.1（40 文件 / 4694 行）

职责：工具调用树 + tool.call.toolview keyed slot 派发


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-tool/src/client/apply.ts | 54 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-client-ui-renderer |
| packages/client/ui-tool/src/client/contract/slots.ts | 158 | ToolImagesOwnerProps, ToolCallCommonProps, ToolCallPhaseProps, ToolCallOwnerProps, ToolCallViewProps, StartedToolCallViewProps, UserQuestionRecord, UserQuestionPanels …等10项 | @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-ui-chat, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-user-questions |
| packages/client/ui-tool/src/client/index.ts | 7 | — | — |
| packages/client/ui-tool/src/client/locale.ts | 3 | CONVERSATION_NS | — |
| packages/client/ui-tool/src/client/tool/components/AskQuestionCard.tsx | 41 | AskQuestionCard | — |
| packages/client/ui-tool/src/client/tool/components/QuestionToolRow.tsx | 65 | QuestionToolRow | @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-tool/src/client/tool/components/ToolDetails.tsx | 140 | ToolDetails, ToolDetailItem, ToolDetailsModel | @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-chat |
| packages/client/ui-tool/src/client/tool/components/ToolRow.tsx | 380 | ToolRow, ToolRowProps | react, clsx, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-chat |
| packages/client/ui-tool/src/client/tool/models/ask-question-card-model.ts | 26 | AskQuestionCardModel | — |
| packages/client/ui-tool/src/client/tool/models/auto-review-denial.ts | 37 | normalizeAutoReviewReason, localizeAutoReviewDenial, AutoReviewDenialPresentation | @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-tool/src/client/tool/models/control-details-model.ts | 200 | controlDetails | — |
| packages/client/ui-tool/src/client/tool/models/detail-model-shared.ts | 162 | detailRecord, nonempty, detailJson, detailBadge, detailLabel, inspectionItems, detailList, DetailTranslate …等9项 | @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-tool/src/client/tool/models/details-card-model.ts | 191 | todosDetail, detailsCardModel | @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-tool/src/client/tool/models/diff-card-model.ts | 112 | diffCardModel, CHAT_DIFF_MAX_LINES, DiffCardModel | @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-tool/src/client/tool/models/image-card-model.ts | 242 | imageCardModel, ImageCardModel | @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-util-workspace-path |
| packages/client/ui-tool/src/client/tool/models/inspection-details-model.ts | 180 | inspectionDetails | @deepseek-ai/dsh-spill-policy |
| packages/client/ui-tool/src/client/tool/models/primitive-labels.ts | 110 | codeToolbarLabels, markdownLabels, diffBlockLabels, readBlockLabels, searchBlockLabels, webBlockLabels | @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-tool/src/client/tool/models/raw-tool-call.ts | 53 | parsedToolCall, singleResultText, ParsedToolCall | @deepseek-ai/dsh-client-ui-chat |
| packages/client/ui-tool/src/client/tool/models/read-card-model.ts | 120 | readCallLine, readCardModel, CHAT_READ_MAX_LINES, ReadCardModel | @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-util-workspace-path |
| packages/client/ui-tool/src/client/tool/models/search-card-model.ts | 101 | searchCardModel, CHAT_SEARCH_MAX_LINES, SearchCardModel | @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-tool/src/client/tool/models/terminal-card-model.ts | 326 | terminalBlockLabels, localizeTerminalCardModel, terminalFailed, isSettledPersistentShellCall, isSpilledShellCall, terminalCardModel, TerminalCardModel | @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-util-workspace-path, @deepseek-ai/dsh-spill-policy |
| packages/client/ui-tool/src/client/tool/models/todo-diff-model.ts | 80 | todoDiffModel | @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-tool/src/client/tool/models/todo-history.ts | 90 | registerTodoHistory, todoWriteDefinition, todoCallDefinition, todoHistoryView, TodoBaseline, TodoHistory | @deepseek-ai/dsh-tools, @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-tool/src/client/tool/models/tool-call-model.ts | 334 | classifyTool, toolTitleKey, resultText, formatToolBody, toolRowModel, VARIANT_TITLE_KEYS, ToolRowVariant, ToolRowState …等10项 | @deepseek-ai/dsh-client-ui-chat, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-util-workspace-path |
| packages/client/ui-tool/src/client/tool/models/web-card-model.ts | 101 | webCardModel, webFetchHref, WebCardModelProps | @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-tool/src/client/tool/ToolCallTree.tsx | 128 | ToolCallTree | react, @deepseek-ai/dsh-client-ui-chat |
| packages/client/ui-tool/src/client/tool/toolviews/ask-question-row.tsx | 387 | AskQuestionRow, askQuestionToolview | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-tool/src/client/tool/toolviews/bash-sample.tsx | 172 | BashRow, bashToolviewSample | react, @deepseek-ai/cordis, clsx, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-tool/src/client/tool/toolviews/details-row.tsx | 120 | DetailsRow, detailsToolview | react, @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-tool/src/client/tool/toolviews/file-mutation-row.tsx | 70 | FileMutationRow, fileMutationToolview | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-tool/src/client/tool/toolviews/GenericToolCard.tsx | 76 | GenericToolCard, GenericToolCardProps | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-tool/src/client/tool/toolviews/plan-summary.ts | 61 | planSummary, PlanItemLike, PlanSummary | — |
| packages/client/ui-tool/src/client/tool/toolviews/read-family-row.tsx | 62 | readFamilyRow, ReadFamilyRowProps, ReadImageRowProps, ReadFamilyCard | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-tool/src/client/tool/toolviews/read-image-row.tsx | 62 | ReadImageRow, readImageToolview | @deepseek-ai/cordis |
| packages/client/ui-tool/src/client/tool/toolviews/read-row.tsx | 31 | ReadRow, readToolview | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-tool/src/client/tool/toolviews/search-row.tsx | 54 | SearchRow, searchToolview | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-tool/src/client/tool/toolviews/todo-row.tsx | 95 | TodoRow, todoToolview | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-tool/src/client/tool/toolviews/web-row.tsx | 54 | WebRow, webToolview | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-tool/src/index.ts | 5 | apply | — |
| packages/client/ui-tool/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-trajectory — @deepseek-ai/dsh-client-ui-trajectory@0.2.1-alpha.1（31 文件 / 9418 行）

职责：轨迹检查器（turn/step 树状视图）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-trajectory/src/client/code-program.ts | 63 | codeProgram, PTC_TOOL_NAME, CodeProgram | — |
| packages/client/ui-trajectory/src/client/copy-codes.ts | 5 | COMPACTION_INTERRUPTED_ERROR | — |
| packages/client/ui-trajectory/src/client/duration-store.ts | 14 | createTrajectoryDurationStore | @deepseek-ai/dsh-client-store |
| packages/client/ui-trajectory/src/client/index.ts | 114 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-session |
| packages/client/ui-trajectory/src/client/layout.ts | 1180 | deriveTrajectoryLayout, appendTrajectoryPartialLayout, TrajectoryGroupModel, TrajectoryTurnModel, TrajectoryLayoutInput | @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-attachment |
| packages/client/ui-trajectory/src/client/locales.ts | 411 | NS, zh, en, TrajectoryKey, TrajectoryTranslate | @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-trajectory/src/client/string-wrapping-store.ts | 14 | createTrajectoryStringWrappingStore | @deepseek-ai/dsh-client-store |
| packages/client/ui-trajectory/src/client/timeline.ts | 206 | formatTimelineOffset, deriveTrajectoryTimeline, trajectoryTimelineFocusIndexes, TrajectoryTimelineMode, TrajectoryTimeRange, TrajectoryTimelineSpan, TrajectoryTimelineTurnBoundary, TrajectoryTimelineModel | — |
| packages/client/ui-trajectory/src/client/trajectory-assistant-definition.ts | 468 | registerTrajectoryAssistantDefinition | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session |
| packages/client/ui-trajectory/src/client/trajectory-compaction-definition.ts | 144 | registerTrajectoryCompactionDefinitions | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-compaction |
| packages/client/ui-trajectory/src/client/trajectory-contract.ts | 101 | TrajectoryRequestHeaderState, TrajectoryContribution, TrajectoryConversationViewNode, TrajectorySnapshot, UseTrajectory | @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-trajectory/src/client/trajectory-definition-common.ts | 29 | trajectoryNode | @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-trajectory/src/client/trajectory-event-projection.ts | 158 | contextForm, contextProducer, toAssistantBlocks, toAssistantBlock, emptyAssistantBlock, displayFailure, isTokenDelta, DisplayFailure | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-trajectory/src/client/trajectory-message-definitions.ts | 207 | registerTrajectoryMessageDefinitions | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-agent |
| packages/client/ui-trajectory/src/client/trajectory-preview.ts | 21 | trajectoryPreviewText | @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-trajectory/src/client/trajectory-record.ts | 148 | trajectoryRecordId, formatDurationMillis, formatElapsedSeconds, TrajectoryCellKind, AssistantMetricDetail, TrajectorySourceBlock, TrajectoryCellProps | react, @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-trajectory/src/client/trajectory-request-header-definition.ts | 152 | registerTrajectoryRequestHeaderDefinition, TrajectorySystemMessageState | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-trajectory/src/client/trajectory-search-index.ts | 134 | TrajectorySearchIndex | — |
| packages/client/ui-trajectory/src/client/trajectory-snapshot-builder.ts | 321 | registerTrajectoryConversationView, TrajectorySnapshotBuilder, EMPTY_TRAJECTORY_SNAPSHOT, trajectoryViewDefinition | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-trajectory/src/client/trajectory-tool-definition.ts | 284 | registerTrajectoryToolDefinition | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-util-values |
| packages/client/ui-trajectory/src/client/trajectory-virtual-rows.ts | 84 | trajectoryVirtualRecordKey, groupTrajectoryVirtualRows, VirtualizableTrajectoryRecord, TrajectoryVirtualRowEntry, TrajectoryVirtualRow | — |
| packages/client/ui-trajectory/src/client/TrajectoryCell.tsx | 97 | TrajectoryCell | — |
| packages/client/ui-trajectory/src/client/TrajectoryGroupHeader.tsx | 27 | TrajectoryGroupHeader, TrajectoryGroupHeaderProps | — |
| packages/client/ui-trajectory/src/client/TrajectoryTable.tsx | 3514 | TrajectoryTable, TrajectoryTableProps, TrajectoryRequestNumber, TrajectoryUsage | react, @tanstack/react-virtual, @deepseek-ai/dsh-client-ui-primitives, diff, @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-trajectory/src/client/TrajectoryTimeline.tsx | 740 | TrajectoryTimeline, TrajectoryTimelineProps | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-trajectory/src/client/TrajectoryToolbar.tsx | 129 | TrajectoryToolbar, TrajectoryToolbarProps | @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-trajectory/src/client/TrajectoryTurn.tsx | 30 | TrajectoryTurn, TrajectoryTurnProps | react |
| packages/client/ui-trajectory/src/client/TrajectoryTurnHeader.tsx | 36 | TrajectoryTurnHeader, TrajectoryTurnHeaderProps | — |
| packages/client/ui-trajectory/src/client/TrajectoryView.tsx | 578 | TrajectoryView, TrajectoryViewInjected | react, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-trajectory/src/index.ts | 5 | apply | — |
| packages/client/ui-trajectory/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-user-questions — @deepseek-ai/dsh-client-ui-user-questions@0.2.1-alpha.1（10 文件 / 2153 行）

职责：用户问答 UI（answerer 接 user-questions waterfall）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-user-questions/src/client/contract/slots.ts | 575 | planReviewOf, createWaterfallRequest, PendingQuestion, QuestionAnswer, PlanReview, QuestionRejectionCode, QuestionWaterfallChannel, QuestionRpcChannel …等13项 | @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session, @deepseek-ai/dsh-user-questions |
| packages/client/ui-user-questions/src/client/draft-store.ts | 65 | createQuestionDraftStore, QuestionDraftAnswer, QuestionDraftProgress | @deepseek-ai/dsh-client-store |
| packages/client/ui-user-questions/src/client/index.ts | 404 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-session, @deepseek-ai/dsh-client-ui-chat |
| packages/client/ui-user-questions/src/client/locales.ts | 75 | zh, en, QuestionKey | — |
| packages/client/ui-user-questions/src/client/PlanReviewPanel.tsx | 92 | PlanReviewPanel, PlanReviewPanelProps | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-user-questions/src/client/question-reply.ts | 185 | replyPairsOf, replyAnswerValues, replyClipboardText, questionReplyDefinition, QuestionReplyQuestion, QuestionReplyAnswer, QuestionReplyData | @deepseek-ai/dsh-client-ui-chat, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-session, @deepseek-ai/dsh-user-questions |
| packages/client/ui-user-questions/src/client/QuestionComposer.tsx | 635 | parseRecommendedLabel, QuestionComposer | react, clsx, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-user-questions/src/client/QuestionReplyView.tsx | 106 | QuestionReplyBubble, QuestionReplyView | react, @deepseek-ai/dsh-client-ui-chat, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-user-questions/src/index.ts | 12 | apply | — |
| packages/client/ui-user-questions/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-workflow-run — @deepseek-ai/dsh-client-ui-workflow-run@0.2.1-alpha.1（6 文件 / 779 行）

职责：工作流运行 UI


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-workflow-run/src/client/index.ts | 38 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-chat, @deepseek-ai/dsh-client-ui-conversation |
| packages/client/ui-workflow-run/src/client/locales.ts | 52 | NS, zh, en, WorkflowRunKey | — |
| packages/client/ui-workflow-run/src/client/workflow-definition.ts | 194 | workflowPhaseKey, workflowRunDefinition, WorkflowRunStatus, WorkflowRunMemberData, WorkflowRunPhaseData, WorkflowRunChatData | @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-client-ui-chat, @deepseek-ai/dsh-session, @deepseek-ai/dsh-tool-workflow, @deepseek-ai/dsh-workflow |
| packages/client/ui-workflow-run/src/client/WorkflowRunPanel.tsx | 486 | WorkflowRunPanel, WorkflowRunInjected, WorkflowRunPanelProps | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-client-store |
| packages/client/ui-workflow-run/src/index.ts | 5 | apply | — |
| packages/client/ui-workflow-run/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/ui-workspace — @deepseek-ai/dsh-client-ui-workspace@0.2.1-alpha.1（20 文件 / 5658 行）

职责：工作区选择/创建 UI


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/ui-workspace/src/client/contract/slots.ts | 489 | menuOpenStateFactory, DirectoryFlowOwnerProps, SessionRowOwnerProps, MenuOpenState, UseMenuOpenState, SessionRowScheduleOwnerProps, DirectoryFlowSlotName, DirectoryPickingInjected …等30项 | @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-sidebar, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-client-ui-layout, @deepseek-ai/dsh-api-session-controller |
| packages/client/ui-workspace/src/client/index.ts | 331 | apply, inject | @deepseek-ai/dsh-client-product-analytics, @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-api-workspace-controller |
| packages/client/ui-workspace/src/client/locales.ts | 245 | zh, en, WorkspaceKey | — |
| packages/client/ui-workspace/src/client/navigation.ts | 480 | DirectoryBrowseError, StartSessionOptions, UiWorkspace | @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-subagent |
| packages/client/ui-workspace/src/client/pin-order.ts | 52 | pinOrderSource, pinOrderAccounts, PinOrderSource | @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-api-workspace-controller, @deepseek-ai/dsh-session |
| packages/client/ui-workspace/src/client/rows/AnimatedRows.tsx | 184 | AnimatedRows | react |
| packages/client/ui-workspace/src/client/rows/Rows.tsx | 704 | ProjectRowItem, SearchResultItem, SessionNodeItem, RowDragProps | react, clsx, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-shortcuts |
| packages/client/ui-workspace/src/client/rows/WorkspaceBrowser.tsx | 1488 | WorkspaceBrowser | react, clsx, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-api-workspace-controller |
| packages/client/ui-workspace/src/client/session-actions/ArchiveSession.tsx | 172 | ArchiveSessionMenuItem, ArchiveSessionRowButton, SessionArchiveConfirmDialog | react, @deepseek-ai/dsh-api-workspace-controller, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-jobs, @deepseek-ai/dsh-schedule |
| packages/client/ui-workspace/src/client/session-actions/derived.ts | 27 | derive | @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-workspace/src/client/session-actions/ForkSession.tsx | 29 | ForkSessionMenuItem | @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-workspace/src/client/session-actions/PinSession.tsx | 70 | PinSessionMenuItem, PinSessionRowButton | @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-workspace/src/client/session-actions/RenameSession.tsx | 125 | RenameSessionMenuItem, SessionRenameDialog | react, @deepseek-ai/dsh-client-ui-primitives |
| packages/client/ui-workspace/src/client/session-actions/RowActionToast.tsx | 83 | RowActionToast | @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-util-values |
| packages/client/ui-workspace/src/client/shortcuts.ts | 125 | createWorkspaceShortcutControls, installWorkspaceShortcuts, WorkspaceShortcutState | @deepseek-ai/cordis, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-shortcuts, @deepseek-ai/dsh-session |
| packages/client/ui-workspace/src/client/stores.ts | 134 | createWorkspaceViewStore, FLAT_SESSION_ORDER_KEY, SessionGroupBy, SessionOrderBy, WorkspaceViewStoreActions | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-session |
| packages/client/ui-workspace/src/client/tree.ts | 649 | owningGroupKey, workspaceLabel, orderByRecency, reconcileManualOrder, pinCurrentBlank, deriveGroups, sessionMemberIds, visibleSessionIds …等21项 | @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-api-workspace-controller, @deepseek-ai/dsh-client-ui-session, @deepseek-ai/dsh-session, @deepseek-ai/dsh-util-values |
| packages/client/ui-workspace/src/client/WorkspacePicker.tsx | 257 | WorkspacePickFlow, WorkspacePicker, WorkspacePickFlowProps | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-api-workspace-controller, @deepseek-ai/dsh-client-ui-slots |
| packages/client/ui-workspace/src/index.ts | 10 | apply | — |
| packages/client/ui-workspace/tsdown.config.ts | 4 | clientBundle | — |

#### packages/client/web — @deepseek-ai/dsh-client-web@0.2.1-alpha.1（12 文件 / 830 行）

职责：Web boot 内核：AppWebEntry/static 模块表/boot 页/ui-renderer 移交


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/client/web/src/apply-injections.ts | 53 | applyIndexInjections | @deepseek-ai/dsh-host-webserver |
| packages/client/web/src/boot-client.ts | 90 | bootClient, assertEntriesActive, EntryStateLabel, ClientBootOptions | @deepseek-ai/cordis, @deepseek-ai/cordis-plugin-loader, @deepseek-ai/dsh-client-modules |
| packages/client/web/src/boot-page.ts | 104 | BootPage | — |
| packages/client/web/src/boot.ts | 124 | AppWebEntry, BootSeams | @deepseek-ai/cordis, @deepseek-ai/dsh-client-modules |
| packages/client/web/src/index.ts | 13 | — | — |
| packages/client/web/src/loader-status.ts | 36 | FIBER_STATE, STATE_LABELS, LoaderEntryState | @deepseek-ai/cordis |
| packages/client/web/src/mount.ts | 25 | mountClient | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-renderer |
| packages/client/web/src/platform.ts | 22 | PLATFORM_MODULES, PRELOADED_CLIENT_EXTERNALS, PlatformModule | — |
| packages/client/web/src/seed.ts | 40 | getStaticModules | react, react-dom, @deepseek-ai/cordis, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-slots |
| packages/client/web/src/window-drag/recall.ts | 225 | installWindowDragRecall, WindowDragRecallOptions | — |
| packages/client/web/src/window-drag/regions.ts | 91 | containsPoint, isDraggableAt, DRAG_MARK, RECALL_MARK, INTERACTIVE_SELECTOR, RegionRect | — |
| packages/client/web/tsdown.config.ts | 7 | staticLinked | — |

#### packages/compaction/command-compact — @deepseek-ai/dsh-command-compact@0.2.1-alpha.1（1 文件 / 109 行）

职责：/compact 人类命令


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/compaction/command-compact/src/index.ts | 109 | apply, name, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-commands, @deepseek-ai/dsh-compaction |

#### packages/compaction/compaction — @deepseek-ai/dsh-compaction@0.2.1-alpha.1（6 文件 / 520 行）

职责：压缩 Service Definition（ctx.compaction）+ summary-error waterfall


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/compaction/compaction/src/brand.ts | 14 | CompactionId | @deepseek-ai/dsh-brand |
| packages/compaction/compaction/src/checkpoint.ts | 52 | compactCheckpointSource, isCompactCheckpointSource, CompactionCheckpointSource | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-commands |
| packages/compaction/compaction/src/index.ts | 196 | ManualCompactionError, CompactionEngine, CompactionTrigger, ManualCompactionErrorCode, CompactionAgentContext, ManualCompactAgentContext | @deepseek-ai/cordis, @deepseek-ai/dsh-session, @deepseek-ai/dsh-commands |
| packages/compaction/compaction/src/tool-pairing.ts | 127 | toolPairingBalancedBefore, toolPairingBalancedAfter | @deepseek-ai/dsh-session |
| packages/compaction/compaction/src/types.ts | 121 | CompactionResult | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-commands, @deepseek-ai/dsh-session |
| packages/compaction/compaction/tsdown.config.ts | 10 | defineConfig | tsdown |

#### packages/compaction/compaction-basic — @deepseek-ai/dsh-compaction-basic@0.2.1-alpha.1（5 文件 / 1720 行）

职责：默认压缩实现：区间选择算法 + 前缀缓存友好的 LLM 摘要事务


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/compaction/compaction-basic/src/config.ts | 363 | resolveConfig, resolveTargetPolicy, resolveCompactSpec, TargetPressureConfigError | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-util-values |
| packages/compaction/compaction-basic/src/index.ts | 453 | BasicCompactionEngine | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-compaction, @deepseek-ai/dsh-session, @deepseek-ai/dsh-llm |
| packages/compaction/compaction-basic/src/region.ts | 601 | selectCompactableRange, compactSurfaceRegion, assertNoActiveCompaction | node:crypto, node:util, @deepseek-ai/dsh-compaction, @deepseek-ai/dsh-commands, @deepseek-ai/dsh-llm |
| packages/compaction/compaction-basic/src/summarizer.ts | 222 | summarizeWithLlm, frameSummary, SummarizationInput, SummaryResult | @deepseek-ai/cordis, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-util-values, @deepseek-ai/dsh-agent |
| packages/compaction/compaction-basic/src/types.ts | 81 | CompactionPolicyConfig, ModelCompactPolicyConfig, BasicCompactionConfig, ResolvedRetention, ResolvedConfig, ResolvedTargetPolicy, ResolvedCompactSpec | @deepseek-ai/dsh-llm |

#### packages/compaction/compaction-image-offload — @deepseek-ai/dsh-compaction-image-offload@0.2.1-alpha.1（4 文件 / 201 行）

职责：响应 IMAGE_OFFLOAD_REQUIRED 的图片卸载


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/compaction/compaction-image-offload/src/image-offload.ts | 47 | offloadOldestImages | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session |
| packages/compaction/compaction-image-offload/src/index.ts | 42 | apply, name, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-compaction, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-llm |
| packages/compaction/compaction-image-offload/src/project-message.ts | 37 | offloadMessageImages | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-util-values |
| packages/compaction/compaction-image-offload/src/projection.ts | 75 | imageOffloadProjection, ImageOffloadTarget | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session |

#### packages/compaction/compaction-tool-result-pruner — @deepseek-ai/dsh-compaction-tool-result-pruner@0.2.1-alpha.1（3 文件 / 306 行）

职责：压缩前裁剪过大工具结果


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/compaction/compaction-tool-result-pruner/src/config.ts | 78 | codePointLength, resolveConfig, PRUNE_MARKER, DEFAULTS | @deepseek-ai/dsh-util-values |
| packages/compaction/compaction-tool-result-pruner/src/index.ts | 186 | ToolResultPruner | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session, @deepseek-ai/dsh-compaction |
| packages/compaction/compaction-tool-result-pruner/src/types.ts | 42 | ToolResultPruneConfig, ResolvedConfig, PrunedEntry, PruneResult | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session |

#### packages/computer-use/computer-use — @deepseek-ai/dsh-computer-use@0.2.1-alpha.1（2 文件 / 65 行）

职责：桌面操控排他命名注册槽（ComputerUseRegistry）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/computer-use/computer-use/src/brand.ts | 16 | ComputerUseProviderName | @deepseek-ai/dsh-brand |
| packages/computer-use/computer-use/src/index.ts | 49 | ComputerUseRegistry | @deepseek-ai/cordis |

#### packages/context/agent-instructions — @deepseek-ai/dsh-agent-instructions@0.2.1-alpha.1（6 文件 / 1838 行）

职责：AGENTS.md 类指令文件的 digest/render/state 注入


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/context/agent-instructions/src/config.ts | 124 | workspaceBaselineIdentity, resolveConfig, resolveDiscoveryConfig, Config, ResolvedDiscoveryConfig, ResolvedConfig | node:path, @deepseek-ai/schemastery, @deepseek-ai/dsh-home-paths |
| packages/context/agent-instructions/src/digest.ts | 29 | instructionContentSha1, trimmedInstructionDigest | node:crypto |
| packages/context/agent-instructions/src/files.ts | 531 | findProjectRoot, ancestorChain, descendantDirsBetween, relativeDisplay, discoverBaselineInstructionFiles, dedupInstructionFilesByDirectory, loadBaselineInstructions, loadBaselineInstructionSet …等15项 | node:fs, node:path, @deepseek-ai/dsh-fs, @deepseek-ai/dsh-home-paths, @deepseek-ai/dsh-util-values |
| packages/context/agent-instructions/src/index.ts | 361 | apply, inject | @deepseek-ai/cordis, node:util, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session |
| packages/context/agent-instructions/src/render.ts | 358 | scopeForDisplayPath, candidateScopeKey, instructionScopeKey, decodeScopeKey, renderInstructionChanges, renderAgentInstructionSet, renderAgentInstructions, USER_GLOBAL_DIRECTORY …等13项 | node:path |
| packages/context/agent-instructions/src/state.ts | 435 | agentInstructionsMessage, baselineInstructionState, retainedInstructionVersionUpdates, applyInstructionVersionUpdates, reconcileInstructionContext, name, AgentInstructionSource, InstructionVersionState …等11项 | @deepseek-ai/dsh-agent, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session, @deepseek-ai/dsh-fs |

#### packages/context/file-reference — @deepseek-ai/dsh-file-reference@0.2.1-alpha.1（3 文件 / 116 行）

职责：@文件 引用文法与解析缝


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/context/file-reference/src/grammar.ts | 56 | activeAtToken, formatFileMention, ActiveAtToken | — |
| packages/context/file-reference/src/index.ts | 46 | FileReferenceService, FILE_REFERENCE_PROMPT | @deepseek-ai/cordis, @deepseek-ai/dsh-agent |
| packages/context/file-reference/src/types.ts | 14 | FileReferenceCandidate | — |

#### packages/context/file-reference-local — @deepseek-ai/dsh-file-reference-local@0.2.1-alpha.1（2 文件 / 530 行）

职责：@文件 引用的本地搜索展开实现


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/context/file-reference-local/src/index.ts | 142 | LocalFileReferenceService, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-file-reference, @deepseek-ai/dsh-tools |
| packages/context/file-reference-local/src/search.ts | 388 | WorkspaceFileSearch, DEFAULT_FILE_SEARCH_MAX_RESULTS, DEFAULT_FILE_SEARCH_MAX_ENTRIES, DEFAULT_FILE_SEARCH_EXCLUDED_DIRECTORIES, FileSearchConfig | node:fs, node:path, @deepseek-ai/dsh-file-reference |

#### packages/context/session-reference — @deepseek-ai/dsh-session-reference@0.2.1-alpha.1（7 文件 / 986 行）

职责：@会话 召回：注入 recall form 上下文


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/context/session-reference/src/config.ts | 44 | SessionReferenceError, MAX_REFERENCES, DEFAULT_CANDIDATE_LIMIT, DEFAULT_MAX_REFERENCE_BYTES, Config, SessionReferenceErrorCode | — |
| packages/context/session-reference/src/index.ts | 473 | SessionReferenceResolver | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-llm |
| packages/context/session-reference/src/projection.ts | 181 | retainReferencedSession, ReferencedSessionData, ReferenceRetentionStats | @deepseek-ai/dsh-compaction, @deepseek-ai/dsh-session-query, @deepseek-ai/dsh-output-retention, @deepseek-ai/dsh-util-values, @deepseek-ai/dsh-session |
| packages/context/session-reference/src/serialization.ts | 13 | stringifyTagSafeJson | — |
| packages/context/session-reference/src/spill.ts | 82 | prepareReferenceOmission, REFERENCE_WARNING | @deepseek-ai/dsh-session, @deepseek-ai/dsh-spill |
| packages/context/session-reference/src/types.ts | 89 | SessionReferenceSource, SessionReferenceInput, SessionReferenceCandidate, SessionReferenceMentionCandidate, PreparedReferencedMessage, ReferencedConversationItem | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session |
| packages/context/session-reference/src/uri.ts | 104 | encodeSessionReferenceUri, decodeSessionReferenceUri, formatSessionReferenceMention, parseSessionReferenceText, SESSION_REFERENCE_SCHEME, ParsedSessionReferenceText | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-session |

#### packages/context/time-context — @deepseek-ai/dsh-time-context@0.2.1-alpha.1（4 文件 / 363 行）

职责：当前时间注入 prompt 变量


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/context/time-context/src/index.ts | 227 | apply, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, zod, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-llm |
| packages/context/time-context/src/request-zone.ts | 82 | deriveBrowserTimeZoneContext, renderBrowserTimeZoneContext, BrowserTimeZoneContext | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-util-values |
| packages/context/time-context/src/timestamp.ts | 38 | createTimestampFormatter, formatTimestamp | — |
| packages/context/time-context/tsdown.config.ts | 16 | defineConfig | tsdown |

#### packages/context/tmux-context — @deepseek-ai/dsh-tmux-context@0.2.1-alpha.1（1 文件 / 276 行）

职责：tmux 会话上下文注入


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/context/tmux-context/src/index.ts | 276 | apply, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, zod, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-session-projection |

#### packages/core/agent — @deepseek-ai/dsh-agent@0.2.1-alpha.1（9 文件 / 1678 行）

职责：Agent 接口+活注册表（ctx.agents）+ AsyncLocalStorage 发起者归因


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/core/agent/src/archive-admission.ts | 39 | installTurnArchiveAdmission | @deepseek-ai/cordis, @deepseek-ai/dsh-session, @deepseek-ai/dsh-workspace |
| packages/core/agent/src/consumed-work.ts | 110 | foldConsumedWork, ConsumedWork | @deepseek-ai/dsh-session |
| packages/core/agent/src/dispatch.ts | 177 | agentCarrier, agentEvents, emitAgentEvent, assembleContextFor, AgentSubjectEvent, AgentEventDispatch | @deepseek-ai/cordis, @deepseek-ai/dsh-scope, @deepseek-ai/dsh-system-prompt |
| packages/core/agent/src/index.ts | 690 | AgentRegistry, AgentSetupCommit, AgentSetup, CreateAgentOptions, ResumeAgentOptions, AgentHandle, AgentFactory | @deepseek-ai/cordis, node:async_hooks, node:util, @deepseek-ai/dsh-scope, @deepseek-ai/dsh-session |
| packages/core/agent/src/model-selection.ts | 133 | installModelSelection, ModelSelection, ModelSelectionRef | @deepseek-ai/cordis, @deepseek-ai/dsh-llm |
| packages/core/agent/src/projection.ts | 12 | — | @deepseek-ai/dsh-session-projection |
| packages/core/agent/src/runtime-types.ts | 396 | AgentOptions, CancelOptions, Inbox, AgentStatus, PreStepDecision, RequestErrorAction, SessionStartSource, AssistantStreamFrame | @deepseek-ai/cordis, @deepseek-ai/dsh-scope, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session, @deepseek-ai/dsh-system-prompt |
| packages/core/agent/src/types.ts | 105 | Agent, InboxTarget, InboxState, InboxWireState, TurnBoundaryProjection | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-workspace, @deepseek-ai/dsh-session, @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-util-values |
| packages/core/agent/tsdown.config.ts | 16 | defineConfig | tsdown |

#### packages/core/agent-default-model — @deepseek-ai/dsh-agent-default-model@0.2.1-alpha.1（2 文件 / 114 行）

职责：入口点创建 Agent 的传输无关默认模型（deepseek-official/deepseek-flash）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/core/agent-default-model/src/index.ts | 98 | AgentDefaultModelConfig, Config | @deepseek-ai/dsh-settings, @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-llm |
| packages/core/agent-default-model/tsdown.config.ts | 16 | defineConfig | tsdown |

#### packages/core/agent-loop — @deepseek-ai/dsh-agent-loop@0.2.1-alpha.1（8 文件 / 2448 行）

职责：默认驱动（ctx.agentLoop）：ReactLoopAgent turn/step 状态机 + 生命周期事务 + inbox/turnBoundary 投影


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/core/agent-loop/src/agent.ts | 689 | ReactLoopAgent | @deepseek-ai/dsh-agent, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-util-values, @deepseek-ai/dsh-scope, @deepseek-ai/dsh-session |
| packages/core/agent-loop/src/assistant-stream.ts | 141 | AssistantStreamAttempt | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-session |
| packages/core/agent-loop/src/constants.ts | 7 | DEFAULT_MAX_PARALLEL_TOOL_CALLS | — |
| packages/core/agent-loop/src/inbox.ts | 245 | ReactLoopInbox, inboxProjectionSchema, inboxProjectionDefinition | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session-projection, @deepseek-ai/dsh-session, @deepseek-ai/dsh-agent, zod |
| packages/core/agent-loop/src/index.ts | 894 | AgentLoop, turnBoundaryProjectionDefinition, CONFIGURED_AGENT_IDENTITIES_KEY, LauncherAgentIdentity, ConfiguredAgentIdentities, Config | @deepseek-ai/cosmokit, @deepseek-ai/cordis, node:crypto, @deepseek-ai/schemastery, zod |
| packages/core/agent-loop/src/runtime-context.ts | 165 | SystemPromptProjection, RuntimeContextProjection, SystemPromptCommit, SystemPromptDecisionInput | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session, @deepseek-ai/cordis |
| packages/core/agent-loop/src/tool-calls.ts | 291 | executeToolCalls | @deepseek-ai/cordis, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-util-values |
| packages/core/agent-loop/tsdown.config.ts | 16 | defineConfig | tsdown |

#### packages/core/agent-tool-presentation — @deepseek-ai/dsh-agent-tool-presentation@0.2.1-alpha.1（1 文件 / 73 行）

职责：按代理声明工具呈现模式（PTC/native 共存的 preset 侧封装）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/core/agent-tool-presentation/src/index.ts | 73 | apply, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-tools |

#### packages/core/scope — @deepseek-ai/dsh-scope@0.2.1-alpha.1（3 文件 / 489 行）

职责：作用域原语：createScope/scopeTarget/ScopedLayers（library 无 ctx 键）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/core/scope/src/index.ts | 205 | bindScopeParent, scopeParentOf, scopeChainOf, createScope, scopeOf, scopeTarget, isScopeCarrier, carrierKeyOf …等13项 | @deepseek-ai/cordis |
| packages/core/scope/src/store.ts | 268 | NamedEntries, AnonymousEntries, ScopedLayers, ScopeLayer | @deepseek-ai/cordis |
| packages/core/scope/tsdown.config.ts | 16 | defineConfig | tsdown |

#### packages/core/session — @deepseek-ai/dsh-session@0.2.1-alpha.1（11 文件 / 3179 行）

职责：追加式会话事件日志（ctx.sessions）：Session.append/surface/deriveMessages/fork/repair


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/core/session/src/fork.ts | 31 | buildForkSeed | — |
| packages/core/session/src/index.ts | 1325 | adoptSessionEvent, snapshotSessionEvent, Session, SessionForkError, SessionStore, SessionForkSource, SessionForkErrorCode | @deepseek-ai/cordis, node:path, @deepseek-ai/dsh-brand, @deepseek-ai/dsh-util-values, @deepseek-ai/dsh-scope |
| packages/core/session/src/known-event-types.ts | 88 | KNOWN_SESSION_EVENT_TYPES, MESSAGE_PROJECTION_EVENT_TYPES | — |
| packages/core/session/src/preparation.ts | 50 | SessionPreparation, SessionPreparationOptions | — |
| packages/core/session/src/repair.ts | 212 | openTurnClosers, interruptedTurnClosers, ToolCallRecovery, TOOL_NOT_STARTED, TOOL_OUTCOME_UNKNOWN, OpenTurnCloseCause | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-util-values |
| packages/core/session/src/request-header.ts | 70 | canonicalHeader, headerEquals, foldRequestHeader | @deepseek-ai/dsh-llm |
| packages/core/session/src/seq-ranges.ts | 74 | encodeSeqRanges, decodeSeqRanges, EncodedSeq | — |
| packages/core/session/src/surface.ts | 713 | isSurfaceEligibleType, isSurfaceEvent, isAppendSurfaceEvent, isReplacementSurfaceEvent, deriveEventMessage, validateSessionEventData, validateSurfaceMetadata, foldSurface …等14项 | @deepseek-ai/dsh-llm |
| packages/core/session/src/tool-history.ts | 76 | ToolHistoryProjection | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-util-values |
| packages/core/session/src/types.ts | 524 | SessionId, SessionSeq, SessionLogOffset, SESSION_FORMAT_VERSION, SessionSeqCursor, OptionalSessionSeq, SessionHeader, CreateSessionOptions …等25项 | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-util-values |
| packages/core/session/tsdown.config.ts | 16 | defineConfig | tsdown |

#### packages/core/system-prompt — @deepseek-ai/dsh-system-prompt@0.2.1-alpha.1（1 文件 / 639 行）

职责：系统提示组装（ctx.systemPrompt）：有序 section/变量/工具 schema 注册表


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/core/system-prompt/src/index.ts | 639 | renderPrompt, renderContextSnapshot, joinContextSections, renderContextSections, SystemPrompt, PERSONA_PREFIX_SECTION, PERSONA_SUFFIX_SECTION, TOOL_ORDER_REST …等18项 | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-scope, @deepseek-ai/dsh-llm |

#### packages/core/tools — @deepseek-ai/dsh-tools@0.2.1-alpha.1（9 文件 / 5679 行）

职责：工具注册表与守卫执行管线（ctx.tools）：六段管线 + PTC 传输工具


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/core/tools/src/index.ts | 1986 | ToolNotFoundError, ToolOutputError, ToolRuntime, TOOL_RUNTIME_SCHEDULER, TOOL_ABORTED, TOOL_ABORTED_BEFORE_DISPATCH, ToolOutputDefinition, ToolDefinition …等30项 | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-scope, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-agent |
| packages/core/tools/src/json-schema.ts | 657 | isPlainJsonRecord, isJsonSchemaRecord, isPlainJsonArray, assertSupportedJsonSchema, assertObjectJsonSchema, validateJsonSchemaValue, JsonSchemaError, JsonSchemaScalar …等11项 | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-util-values |
| packages/core/tools/src/presentation.ts | 390 | ToolCallKind, FileLocation, FileDiff, ToolCallView, GenericCallView, TerminalCallView, DiffCallView, ReadFileLine …等22项 | @deepseek-ai/dsh-llm |
| packages/core/tools/src/ptc.ts | 772 | createRunCodeTool, CodeRunFailedError, RUN_CODE_NAME, PtcSdkLanguage, RunCodeBridgeOptions | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-ptc-runtime, @deepseek-ai/dsh-sandbox, @deepseek-ai/dsh-user-approval |
| packages/core/tools/src/py-types.ts | 819 | jsonSchemaToPy, renderToolsSdkPy | — |
| packages/core/tools/src/schema.ts | 633 | valueSchemaSpecToJsonSchema, parameterSchemaSpecToJsonSchema, validateArgs, defineTool, ToolArgsError, ValueSchemaAnnotations, StringValueSchemaSpec, NumberValueSchemaSpec …等22项 | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-util-values |
| packages/core/tools/src/testing.ts | 43 | defineContentToolFixture, ContentToolFixtureOptions | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-util-values |
| packages/core/tools/src/ts-types.ts | 318 | jsonSchemaToTs, renderToolsSdk, ToolSdkSchema | @deepseek-ai/dsh-llm |
| packages/core/tools/src/types.ts | 61 | PtcDispatchStartEventData, PtcDispatchEventData | @deepseek-ai/dsh-llm |

#### packages/credentials/authorization — @deepseek-ai/dsh-authorization@0.2.1-alpha.1（2 文件 / 543 行）

职责：人类对话式授权缝（ctx.authorization）：AuthorizationFlow/Session


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/credentials/authorization/src/index.ts | 451 | AuthorizationError, AuthorizationDeclinedError, AuthorizationService, AuthorizationSession, AuthorizationFlow, AuthorizationInteraction, AuthorizationRequest | @deepseek-ai/cordis, @deepseek-ai/dsh-credentials, @deepseek-ai/dsh-llm |
| packages/credentials/authorization/src/types.ts | 92 | AuthorizationMethod, AuthorizationNotice, AuthorizationPromptOption, AuthorizationPrompt, AuthorizationStatus, AuthorizationSettlement, AuthorizationOutcome, AuthorizationEntry | @deepseek-ai/dsh-credentials |

#### packages/credentials/credentials — @deepseek-ai/dsh-credentials@0.2.1-alpha.1（2 文件 / 410 行）

职责：凭证 Service Definition（ctx.credentials）：ref+record 双键空间


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/credentials/credentials/src/index.ts | 308 | credentialRef, isCredentialRefName, isCredentialKeySegment, credentialKey, parseCredentialKey, credentialKeyScope, credentialKeyId, CredentialProvider …等11项 | @deepseek-ai/cordis, @deepseek-ai/dsh-brand |
| packages/credentials/credentials/src/types.ts | 102 | CredentialRef, CredentialKey, ApiKeyRecord, GrantRecord, CredentialRecord, CredentialInfo | @deepseek-ai/dsh-brand |

#### packages/credentials/credentials-local — @deepseek-ai/dsh-credentials-local@0.2.1-alpha.1（1 文件 / 910 行）

职责：文件凭证实现：.credentials.yaml 分层 + 0600 + 跨进程锁


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/credentials/credentials-local/src/index.ts | 910 | resolveSpec, parseCredentialsDocument, renderFlatLayoutMigration, LocalCredentialProvider, CREDENTIALS_FILENAME, DOCUMENT_VERSION, Config, CredentialsDocument | @deepseek-ai/cordis, @deepseek-ai/schemastery, chokidar, node:fs, node:path |

#### packages/credentials/deepseek-account — @deepseek-ai/dsh-deepseek-account@0.2.1-alpha.1（3 文件 / 308 行）

职责：DeepSeek 平台账号抽象（ctx.deepseekAccount）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/credentials/deepseek-account/src/account-tasks.ts | 36 | isRunningAccountTask, installAccountTaskCancellation | @deepseek-ai/cordis, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-agent |
| packages/credentials/deepseek-account/src/index.ts | 174 | mergePlatformCookies, desktopClientHeaders, platformClientHeaders, platformWireLocale, DeepSeekAccount, PlatformSession | @deepseek-ai/cordis |
| packages/credentials/deepseek-account/src/types.ts | 98 | AccountClientMetadata, SignInAttemptId, SignInErrorCode, SignInAttemptView, AccountLinks, AccountView, AccountUserId, AccountProfile …等13项 | @deepseek-ai/cordis, @deepseek-ai/dsh-brand |

#### packages/credentials/deepseek-account-platform — @deepseek-ai/dsh-deepseek-account-platform@0.2.1-alpha.1（5 文件 / 1057 行）

职责：平台账号 PKCE 实现（browser flow + token 轮换）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/credentials/deepseek-account-platform/src/details.ts | 103 | profile, readAccountDetail, readUnnotifiedBonuses, sendBonusNotified | zod, @deepseek-ai/dsh-deepseek-account |
| packages/credentials/deepseek-account-platform/src/index.ts | 661 | PlatformAccount, Config | node:crypto, node:http, @deepseek-ai/dsh-host-webserver, node:os, node:stream |
| packages/credentials/deepseek-account-platform/src/logout.ts | 38 | revokeAccount, LogoutRetryPolicy | node:timers |
| packages/credentials/deepseek-account-platform/src/protocol.ts | 252 | platformOrigin, browserUrl, platformHeaders, requestPlatform, requestAccount, requestUnnotifiedBonuses, requestBonusNotified, logoutAccount …等13项 | zod, @deepseek-ai/dsh-deepseek-account |
| packages/credentials/deepseek-account-platform/src/types.ts | 3 | — | @deepseek-ai/dsh-deepseek-account |

#### packages/deliverables/tool-present — @deepseek-ai/dsh-tool-present@0.2.1-alpha.1（2 文件 / 128 行）

职责：present 工具：声明既有文件为 turn 交付物（deliverables/presented 事件）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/deliverables/tool-present/src/index.ts | 110 | apply, name, Config, inject | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-fs, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-agent |
| packages/deliverables/tool-present/src/types.ts | 18 | PresentedFile | @deepseek-ai/dsh-llm |

#### packages/deliverables/workspace-changes — @deepseek-ai/dsh-workspace-changes@0.2.1-alpha.1（8 文件 / 1310 行）

职责：turn 级 git 变更摘要/diff 记录（ctx.workspaceChanges）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/deliverables/workspace-changes/src/capture.ts | 113 | captureFile, sameCapture, mutationPath, Capture | node:crypto, node:fs, node:path |
| packages/deliverables/workspace-changes/src/compare.ts | 67 | compareText, Comparison | diff |
| packages/deliverables/workspace-changes/src/git.ts | 280 | locateGitWorkspace, snapshotTree, treeBlob, blobText, diffTrees, gitlinkPaths, ignoredPaths, GitRunner …等13项 | node:fs, node:path, @deepseek-ai/dsh-subprocess |
| packages/deliverables/workspace-changes/src/index.ts | 166 | apply, name, inject, Config | node:os, @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-session |
| packages/deliverables/workspace-changes/src/numstat.ts | 53 | parseNumstat, NumstatEntry | — |
| packages/deliverables/workspace-changes/src/paths.ts | 110 | toPosix, isInside, temporaryRoots, canonicalPath, isTemporaryPath, displayPathOf, durablePathOf, compareDisplay | node:fs, node:os, node:path |
| packages/deliverables/workspace-changes/src/recorder.ts | 405 | TurnRecorder, RecorderEnvironment | node:fs, node:os, node:path, @deepseek-ai/dsh-session |
| packages/deliverables/workspace-changes/src/types.ts | 116 | WorkspaceChangedFile, WorkspaceChangesSummary, WorkspaceDiffHunk, WorkspaceFileDiff, WorkspaceChanges | @deepseek-ai/dsh-session |

#### packages/document/office-to-pdf — @deepseek-ai/dsh-office-to-pdf@0.2.1-alpha.1（6 文件 / 662 行）

职责：LibreOffice 转 PDF 服务（ctx.officeToPdf）：限额+内容寻址缓存


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/document/office-to-pdf/src/errors.ts | 16 | OfficeToPdfError | — |
| packages/document/office-to-pdf/src/identity.ts | 32 | OfficeSourceKey, OfficeToPdfGeneration, OfficeToPdfKey | @deepseek-ai/dsh-brand |
| packages/document/office-to-pdf/src/index.ts | 281 | OfficeToPdf, Config | node:crypto, node:fs, node:os, node:path, @deepseek-ai/cordis |
| packages/document/office-to-pdf/src/output.ts | 40 | readPdf | node:fs |
| packages/document/office-to-pdf/src/queue.ts | 234 | ConversionQueue | node:crypto |
| packages/document/office-to-pdf/src/types.ts | 59 | OfficeExtension, OfficeToPdfPriority, OfficeToPdfRequest, OfficeToPdfResult, OfficeToPdfErrorCode, RenderedDocumentBytes | @deepseek-ai/dsh-api-workspace-files, @deepseek-ai/dsh-typert-protocol |

#### packages/experimental/agent-team — @deepseek-ai/dsh-experimental-agent-team@0.2.1-alpha.1（17 文件 / 2533 行）

职责：实验 Agent Teams（ctx.agentTeams）：roster/mailbox/task board/journal


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/experimental/agent-team/src/activity.ts | 88 | TeamActivity | — |
| packages/experimental/agent-team/src/client.ts | 12 | — | — |
| packages/experimental/agent-team/src/error.ts | 24 | errorMessage, TeamError | node:util, @deepseek-ai/dsh-llm |
| packages/experimental/agent-team/src/index.ts | 271 | TeamService | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-session-persistence |
| packages/experimental/agent-team/src/journal.ts | 74 | TeamJournal | @deepseek-ai/dsh-agent, @deepseek-ai/cordis, @deepseek-ai/dsh-session |
| packages/experimental/agent-team/src/lifecycle.ts | 88 | TeamRuntimeLifecycle | — |
| packages/experimental/agent-team/src/mailbox.ts | 333 | TeamMailbox | node:crypto, @deepseek-ai/cordis, @deepseek-ai/dsh-brand, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-llm |
| packages/experimental/agent-team/src/persisted.ts | 35 | readPersistedSession, PersistedSessionView | @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-persistence |
| packages/experimental/agent-team/src/projection.ts | 395 | emptyTeamState, isTeamEvent, teamProjectionView, teamProjectionDefinition, TeamState, TeamProjectionState, TeamEventType | zod, @deepseek-ai/dsh-brand, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-projection |
| packages/experimental/agent-team/src/roster.ts | 495 | resolveActiveMember, TeamRoster, TeamMembership | node:crypto, @deepseek-ai/cordis, @deepseek-ai/dsh-brand, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-llm |
| packages/experimental/agent-team/src/session-message.ts | 32 | messageAccepted | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session |
| packages/experimental/agent-team/src/task-board.ts | 256 | TeamTaskBoard | @deepseek-ai/dsh-agent |
| packages/experimental/agent-team/src/task-graph.ts | 70 | assertTaskGraphCandidate, TeamTaskGraphError, TeamTaskGraphViolation | — |
| packages/experimental/agent-team/src/task-view.ts | 63 | taskReady, projectTaskView | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-session |
| packages/experimental/agent-team/src/types.ts | 246 | TeamId, TeamTaskId, TeamMessageId, TeamMemberPhase, TeamMemberSnapshot, TeamMemberView, TeamTaskStatus, TeamTaskSnapshot …等22项 | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session |
| packages/experimental/agent-team/src/validation.ts | 35 | requiredText, writeScope | — |
| packages/experimental/agent-team/tsdown.config.ts | 16 | defineConfig | tsdown |

#### packages/experimental/agent-team-profile — @deepseek-ai/dsh-experimental-agent-team-profile@0.2.1-alpha.1（1 文件 / 9 行）

职责：Agent Teams 可选 bundle


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/experimental/agent-team-profile/src/index.ts | 9 | — | — |

#### packages/experimental/api-speech-to-text — @deepseek-ai/dsh-experimental-api-speech-to-text@0.2.1-alpha.1（3 文件 / 142 行）

职责：语音转文本 Typert Remote API


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/experimental/api-speech-to-text/src/index.ts | 112 | Config, SpeechController | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-experimental-speech-to-text |
| packages/experimental/api-speech-to-text/src/types.ts | 26 | TranscriptionRequest, SpeechCatalog | @deepseek-ai/dsh-experimental-speech-to-text, @deepseek-ai/dsh-typert-protocol |
| packages/experimental/api-speech-to-text/tsdown.config.ts | 4 | defineConfig | tsdown |

#### packages/experimental/auto-review — @deepseek-ai/dsh-experimental-auto-review@0.2.1-alpha.1（1 文件 / 741 行）

职责：自动代码审查（bundle 形式提供）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/experimental/auto-review/src/index.ts | 741 | apply, name, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-agent-instructions, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-util-values |

#### packages/experimental/browser-use-chrome-devtools-mcp — @deepseek-ai/dsh-experimental-browser-use-chrome-devtools-mcp@0.2.1-alpha.1（1 文件 / 43 行）

职责：chrome-devtools-mcp 浏览器 provider


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/experimental/browser-use-chrome-devtools-mcp/src/index.ts | 43 | apply, name, inject, Config | node:url, @deepseek-ai/cordis, @deepseek-ai/dsh-experimental-browser-use-runtime |

#### packages/experimental/browser-use-playwright-mcp — @deepseek-ai/dsh-experimental-browser-use-playwright-mcp@0.2.1-alpha.1（1 文件 / 51 行）

职责：playwright-mcp 浏览器 provider


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/experimental/browser-use-playwright-mcp/src/index.ts | 51 | apply, name, inject, Config | node:path, node:url, @deepseek-ai/cordis, @deepseek-ai/dsh-experimental-browser-use-runtime |

#### packages/experimental/browser-use-runtime — @deepseek-ai/dsh-experimental-browser-use-runtime@0.2.1-alpha.1（2 文件 / 415 行）

职责：浏览器资源公共底座：SessionResources 归属活 Agent + 每会话 MCP 挂载


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/experimental/browser-use-runtime/src/index.ts | 198 | SessionResources, OwnedSessionResource, SessionResourceOptions | @deepseek-ai/cordis, @deepseek-ai/dsh-agent |
| packages/experimental/browser-use-runtime/src/mcp.ts | 217 | validateBrowserMcpConfig, mountSessionMcp, BrowserMcpConfig, BrowserMcpLaunchConfig, BrowserMcpAttachConfig, SessionMcpOptions | @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/schemastery, @deepseek-ai/dsh-browser-use, @deepseek-ai/dsh-mcp-client |

#### packages/experimental/browser-use-stagehand-native — @deepseek-ai/dsh-experimental-browser-use-stagehand-native@0.2.1-alpha.1（7 文件 / 668 行）

职责：Stagehand SDK 原生浏览器 provider（独立 worker）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/experimental/browser-use-stagehand-native/src/index.ts | 211 | apply, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-browser-use, @deepseek-ai/dsh-experimental-browser-use-runtime, @deepseek-ai/dsh-mcp-client |
| packages/experimental/browser-use-stagehand-native/src/launch.ts | 65 | launchChromium, OwnedChromium | node:fs, node:os, node:path, @puppeteer/browsers, @deepseek-ai/dsh-subprocess |
| packages/experimental/browser-use-stagehand-native/src/native.ts | 172 | openNativeBrowser, StagehandDrainError, stagehandModelSchema, browserInputs, StagehandModelConfig, NativeBrowserConfig, BrowserMethod, NativeBrowserRuntime | @browserbasehq/stagehand, @deepseek-ai/dsh-util-values, zod |
| packages/experimental/browser-use-stagehand-native/src/worker-client.ts | 91 | openBrowserWorker | node:worker_threads |
| packages/experimental/browser-use-stagehand-native/src/worker-rpc.ts | 73 | request, answer, requestSchema | node:worker_threads, zod |
| packages/experimental/browser-use-stagehand-native/src/worker.ts | 41 | — | node:worker_threads, zod |
| packages/experimental/browser-use-stagehand-native/tsdown.config.ts | 15 | defineConfig | tsdown |

#### packages/experimental/claude-code-mods — @deepseek-ai/dsh-experimental-claude-code-mods@0.2.1-alpha.1（20 文件 / 4203 行）

职责：把 Claude Code mod 当 DSH 插件跑（事件桥 + host ops）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/experimental/claude-code-mods/examples/blast-radius/hooks/blast-radius.mjs | 128 | register | — |
| packages/experimental/claude-code-mods/examples/blast-radius/index.ts | 11 | defineMod | — |
| packages/experimental/claude-code-mods/examples/replay-theater/hooks/replay-theater.mjs | 134 | register | — |
| packages/experimental/claude-code-mods/examples/replay-theater/index.ts | 11 | defineMod | — |
| packages/experimental/claude-code-mods/examples/token-weather/hooks/token-weather.mjs | 88 | register | — |
| packages/experimental/claude-code-mods/examples/token-weather/index.ts | 14 | defineMod | — |
| packages/experimental/claude-code-mods/src/api.ts | 220 | createModsApi, TimerHost, ApiBinding | — |
| packages/experimental/claude-code-mods/src/chain.ts | 350 | dispatch, HookTimeoutError, BudgetClock, RewriteRefusedError, ENGINE_ORIGIN, LoadedMod, RegisteredHook, DispatchRequest | @deepseek-ai/dsh-util-values |
| packages/experimental/claude-code-mods/src/define-mod.ts | 66 | defineMod, ModConfig, ModSpec, ModPlugin | @deepseek-ai/cordis, @deepseek-ai/schemastery |
| packages/experimental/claude-code-mods/src/elements.ts | 201 | isUiElement, uiElements, treeProblem, serializeTree, findAll, renderText, UiElement, UiNode …等13项 | — |
| packages/experimental/claude-code-mods/src/engine.ts | 400 | OpDenied, ModsEngine, OpCore, OpTable, OpResolver, OpContext, ModsEngineOptions, RaiseOptions | — |
| packages/experimental/claude-code-mods/src/host-ops.ts | 567 | modToolName, toolCallResultOf, createHostOps, MODS_API_VERSION, FS_MAX_BYTES, STORE_MAX_BYTES, HTTP_MAX_BYTES, AgentBinding …等9项 | @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-subprocess, @deepseek-ai/dsh-session-projection, @deepseek-ai/dsh-commands |
| packages/experimental/claude-code-mods/src/index.ts | 536 | ClaudeCodeMods, SERVED_EVENTS, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-llm |
| packages/experimental/claude-code-mods/src/matcher.ts | 119 | isEventPattern, eventMatches, matcherMatches, describeMatcher, ENGINE_EVENTS, KNOWN_EVENTS | — |
| packages/experimental/claude-code-mods/src/module.ts | 162 | createOn, registerMod, HookRegistry | — |
| packages/experimental/claude-code-mods/src/surfaces.ts | 247 | SurfaceTable, SurfaceHost | — |
| packages/experimental/claude-code-mods/src/testing.ts | 355 | createModTestKit, mock, StubHook, ModTestKitOptions, MountArgs, MountedElement, MountedSurface, TestKitRaisers …等11项 | — |
| packages/experimental/claude-code-mods/src/tool-names.ts | 46 | createToolNameAliases, DEFAULT_TOOL_ALIASES, ToolNameAliases | — |
| packages/experimental/claude-code-mods/src/types.ts | 501 | PluginOptionValue, PluginOptions, ModTier, HookOrigin, HookFailure, HookBudget, HookNext, ModHook …等61项 | — |
| packages/experimental/claude-code-mods/src/values.ts | 47 | messageOf, record, requireString, stringify | — |

#### packages/experimental/client-ui-agent-team — @deepseek-ai/dsh-experimental-client-ui-agent-team@0.2.1-alpha.1（6 文件 / 515 行）

职责：Agent Teams UI


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/experimental/client-ui-agent-team/src/client/index.ts | 17 | apply | @deepseek-ai/cordis |
| packages/experimental/client-ui-agent-team/src/client/locales.ts | 66 | NS, zh, en, TeamKey | — |
| packages/experimental/client-ui-agent-team/src/client/mount.ts | 64 | registerAgentTeamUi, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-session, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-client-locale |
| packages/experimental/client-ui-agent-team/src/client/TeamAction.tsx | 359 | TeamAction, TeamActionInjected, TeamActionProps | react, react-dom, @deepseek-ai/dsh-session, @deepseek-ai/dsh-experimental-agent-team, @deepseek-ai/dsh-api-session-controller |
| packages/experimental/client-ui-agent-team/src/index.ts | 5 | apply | — |
| packages/experimental/client-ui-agent-team/tsdown.config.ts | 4 | clientBundle | — |

#### packages/experimental/client-ui-claude-code-mods — @deepseek-ai/dsh-experimental-client-ui-claude-code-mods@0.2.1-alpha.1（6 文件 / 315 行）

职责：mods UI


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/experimental/client-ui-claude-code-mods/src/client/Band.tsx | 131 | Band, BandInjected, BandProps | react, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-experimental-claude-code-mods |
| packages/experimental/client-ui-claude-code-mods/src/client/index.ts | 19 | apply | @deepseek-ai/cordis, @deepseek-ai/dsh-experimental-claude-code-mods |
| packages/experimental/client-ui-claude-code-mods/src/client/locales.ts | 24 | NS, zh, en, ModsBandKey | — |
| packages/experimental/client-ui-claude-code-mods/src/client/mount.ts | 132 | mountModsBand, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-conversation |
| packages/experimental/client-ui-claude-code-mods/src/index.ts | 5 | apply | — |
| packages/experimental/client-ui-claude-code-mods/tsdown.config.ts | 4 | clientBundle | — |

#### packages/experimental/client-ui-voice-input — @deepseek-ai/dsh-experimental-client-ui-voice-input@0.2.1-alpha.1（12 文件 / 916 行）

职责：语音输入 UI


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/experimental/client-ui-voice-input/src/client/audio.ts | 158 | encodeWave, audioBase64, RecordingError, Recording | — |
| packages/experimental/client-ui-voice-input/src/client/index.ts | 16 | apply | @deepseek-ai/cordis, @deepseek-ai/dsh-experimental-api-speech-to-text |
| packages/experimental/client-ui-voice-input/src/client/locales.ts | 201 | NS, zh, en, VoiceKey | @deepseek-ai/dsh-client-ui-slots |
| packages/experimental/client-ui-voice-input/src/client/mount.ts | 66 | mountVoiceInput, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-experimental-api-speech-to-text, @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-renderer |
| packages/experimental/client-ui-voice-input/src/client/PreparationCard.tsx | 164 | PreparationCard, VoicePreparation, PreparationCardProps | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-experimental-speech-to-text |
| packages/experimental/client-ui-voice-input/src/client/readiness.ts | 41 | observeReadiness, SpeechReadiness | @deepseek-ai/cordis, @deepseek-ai/dsh-api-gateway, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-experimental-api-speech-to-text |
| packages/experimental/client-ui-voice-input/src/client/VoiceInput.tsx | 174 | VoiceInput, VoiceInputActions, VoiceInputInjected, VoiceInputProps | react, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-experimental-api-speech-to-text, @deepseek-ai/dsh-experimental-speech-to-text |
| packages/experimental/client-ui-voice-input/src/client/VoiceSetupDialog.tsx | 26 | VoiceSetupDialog | @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-plugin-manager |
| packages/experimental/client-ui-voice-input/src/client/VoiceSetupPrompt.tsx | 28 | VoiceSetupPrompt, VoiceSetupPromptProps | react, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-plugin-manager |
| packages/experimental/client-ui-voice-input/src/client/Waveform.tsx | 34 | Waveform | react |
| packages/experimental/client-ui-voice-input/src/index.ts | 4 | apply | — |
| packages/experimental/client-ui-voice-input/tsdown.config.ts | 4 | clientBundle | — |

#### packages/experimental/computer-use-cua-driver-mcp — @deepseek-ai/dsh-experimental-computer-use-cua-driver-mcp@0.2.1-alpha.1（1 文件 / 72 行）

职责：CUA driver MCP 桌面 provider


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/experimental/computer-use-cua-driver-mcp/src/index.ts | 72 | apply, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-computer-use, @deepseek-ai/dsh-mcp-client |

#### packages/experimental/computer-use-cua-driver-native — @deepseek-ai/dsh-experimental-computer-use-cua-driver-native@0.2.1-alpha.1（1 文件 / 139 行）

职责：CUA driver 原生桌面 provider


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/experimental/computer-use-cua-driver-native/src/index.ts | 139 | apply, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-computer-use, @deepseek-ai/dsh-mcp-client, zod |

#### packages/experimental/inspector — @deepseek-ai/dsh-experimental-inspector@0.2.1-alpha.1（161 文件 / 16689 行）

职责：跨 realm CDP 调试 hub（专用 Worker + DevTools 前端镜像）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/experimental/inspector/assets/devtools/connect.js | 13 | — | — |
| packages/experimental/inspector/scripts/build-devtools.ts | 55 | buildDevtools | node:crypto, node:fs, node:path, node:url |
| packages/experimental/inspector/scripts/devtools/inputs.ts | 49 | frontendSourceRoot, frontendImages, imagesModule | node:fs, node:path, node:url |
| packages/experimental/inspector/scripts/devtools/source.ts | 84 | restoreModuleUrls, configureHostPerformanceSource, cssTextModule, configureCodeMirrorBrowser, DEVTOOLS_NPM_VERSION, DEVTOOLS_SOURCE_REVISION, $ | typescript |
| packages/experimental/inspector/scripts/devtools/vite.ts | 133 | buildFrontend, LOCALES, LOCAL_FETCH_PATTERN, SHOULD_SHOW_EASTER_EGG | node:fs, node:path, node:url, vite |
| packages/experimental/inspector/src/client/bottom/keyboard.ts | 38 | bindInspectorKeyboard | @deepseek-ai/dsh-client-shortcuts |
| packages/experimental/inspector/src/client/bottom/locales.ts | 25 | zh, en | — |
| packages/experimental/inspector/src/client/bottom/page.tsx | 99 | registerInspectorPage | @deepseek-ai/cordis, react, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/experimental/inspector/src/client/bottom/resize.tsx | 51 | InspectorResizeHandle | react |
| packages/experimental/inspector/src/client/bridge/controller.ts | 23 | startInspectorClient | — |
| packages/experimental/inspector/src/client/bridge/dispatcher.ts | 87 | dispatchBridgeFrame, ClientBridgeFrameHandlers | — |
| packages/experimental/inspector/src/client/bridge/lifecycle.ts | 46 | ClientBridgeLifecycle | — |
| packages/experimental/inspector/src/client/bridge/locales.ts | 3 | untitledClientLabel | — |
| packages/experimental/inspector/src/client/bridge/publisher.ts | 111 | ClientBridgePublisher | — |
| packages/experimental/inspector/src/client/bridge/rpc.ts | 22 | ClientBridgeRpc | — |
| packages/experimental/inspector/src/client/bridge/transport.ts | 354 | ClientInspectorSource | — |
| packages/experimental/inspector/src/client/cdp/console.ts | 177 | consoleBridgeCapability, ClientConsoleObserver, ClientConsoleSink | — |
| packages/experimental/inspector/src/client/cdp/debugger.ts | 12 | debuggerBridgeCapability | — |
| packages/experimental/inspector/src/client/cdp/errors.ts | 11 | ClientRuntimeExecutionError | — |
| packages/experimental/inspector/src/client/cdp/heap-profiler.ts | 12 | heapProfilerBridgeCapability | — |
| packages/experimental/inspector/src/client/cdp/index.ts | 27 | bridgeCapabilities | — |
| packages/experimental/inspector/src/client/cdp/objects.ts | 407 | ClientObjectStore, ClientObjectAllocation, ClientRuntimeObjectOptions | — |
| packages/experimental/inspector/src/client/cdp/profiler.ts | 12 | profilerBridgeCapability | — |
| packages/experimental/inspector/src/client/cdp/properties.ts | 161 | getClientProperties | — |
| packages/experimental/inspector/src/client/cdp/runtime.ts | 502 | runtimeBridgeCapability, ClientRuntimeExecutor, ClientRuntimeLimits | — |
| packages/experimental/inspector/src/client/cdp/sources.ts | 249 | sourcesBridgeCapability, discoverInspectorClientSourceCatalog, ClientSourceCatalogError, ClientSourceCatalog, ClientSourceAsset | @deepseek-ai/dsh-util-crypto |
| packages/experimental/inspector/src/client/cdp/stack.ts | 79 | captureClientConsoleStack, clientErrorStack, parseClientStack, ClientScriptKeyResolver | — |
| packages/experimental/inspector/src/client/index.ts | 4 | — | — |
| packages/experimental/inspector/src/client/inspection/cordis.ts | 4 | — | — |
| packages/experimental/inspector/src/client/inspection/network.ts | 5 | NETWORK_TOPICS | — |
| packages/experimental/inspector/src/client/inspection/realm.ts | 127 | ClientRealmSource | @deepseek-ai/dsh-util-crypto |
| packages/experimental/inspector/src/client/plugin.ts | 160 | apply, name, inject, InspectorService | @deepseek-ai/cordis, @deepseek-ai/dsh-client-connection |
| packages/experimental/inspector/src/host/bridge/controller.ts | 351 | resolveInspectorOptions, startInspector, InspectorOptions, InspectorSpec, InspectorEndpoint, InspectorHandle | node:crypto, node:os, node:worker_threads |
| packages/experimental/inspector/src/host/bridge/dispatcher.ts | 62 | dispatchBridgeFrame, HostBridgeFrameHandlers | — |
| packages/experimental/inspector/src/host/bridge/lifecycle.ts | 126 | InspectorWorkerLifecycle | node:worker_threads |
| packages/experimental/inspector/src/host/bridge/publisher.ts | 82 | HostBridgePublisher | node:worker_threads |
| packages/experimental/inspector/src/host/bridge/rpc.ts | 23 | HostBridgeRpc | node:worker_threads |
| packages/experimental/inspector/src/host/bridge/transport.ts | 90 | HostInspectorSource, HostSourceOptions | node:worker_threads |
| packages/experimental/inspector/src/host/cdp/console.ts | 21 | consoleBridgeCapability, rejectConsoleBridgeCommand | — |
| packages/experimental/inspector/src/host/cdp/debugger.ts | 12 | debuggerBridgeCapability | — |
| packages/experimental/inspector/src/host/cdp/errors.ts | 11 | HostCdpBridgeUnavailableError | — |
| packages/experimental/inspector/src/host/cdp/heap-profiler.ts | 12 | heapProfilerBridgeCapability | — |
| packages/experimental/inspector/src/host/cdp/index.ts | 29 | bridgeCapabilities | — |
| packages/experimental/inspector/src/host/cdp/objects.ts | 13 | rejectObjectBridgeOperation | — |
| packages/experimental/inspector/src/host/cdp/profiler.ts | 12 | profilerBridgeCapability | — |
| packages/experimental/inspector/src/host/cdp/properties.ts | 12 | rejectPropertyBridgeOperation | — |
| packages/experimental/inspector/src/host/cdp/runtime.ts | 43 | runtimeBridgeCapability, rejectRuntimeBridgeCommand | — |
| packages/experimental/inspector/src/host/cdp/sources.ts | 21 | sourcesBridgeCapability, rejectSourcesBridgeCommand | — |
| packages/experimental/inspector/src/host/cdp/stack.ts | 5 | HOST_CDP_BRIDGE_REASON | — |
| packages/experimental/inspector/src/host/index.ts | 4 | — | — |
| packages/experimental/inspector/src/host/inspection/cordis.ts | 4 | — | — |
| packages/experimental/inspector/src/host/inspection/network.ts | 235 | installFetchObserver, NETWORK_TOPICS, FetchCaptureOptions, FetchObserver | — |
| packages/experimental/inspector/src/host/inspection/realm.ts | 23 | createHostRealmSource | node:crypto |
| packages/experimental/inspector/src/host/plugin.ts | 165 | apply, HostPluginConfig | @deepseek-ai/cordis, node:url, node:net, node:stream, serve-static |
| packages/experimental/inspector/src/index.ts | 109 | apply, name, inject, Config, InspectorService | @deepseek-ai/cordis, @deepseek-ai/schemastery |
| packages/experimental/inspector/src/shared/bridge/buffer.ts | 162 | InspectorSourceBuffer, InspectorSourceBufferOptions | — |
| packages/experimental/inspector/src/shared/bridge/codec.ts | 5 | — | — |
| packages/experimental/inspector/src/shared/bridge/control-codec.ts | 154 | parseInspectorWorkerConfig, parseInspectorHostControl, parseInspectorWorkerControl, parseInspectorClientBootstrap | — |
| packages/experimental/inspector/src/shared/bridge/ids.ts | 28 | InspectorSourceId, InspectorSourceGeneration, ClientRuntimeSessionId, ClientRuntimeRequestId, ClientSourceSessionId, ClientSourceRequestId, ClientRemoteObjectHandle | — |
| packages/experimental/inspector/src/shared/bridge/messages/control.ts | 73 | InspectorWorkerConfig, InspectorWorkerBoot, InspectorWorkerShutdown, InspectorHostControl, InspectorWorkerReady, InspectorWorkerFailure, InspectorWorkerStopped, InspectorWorkerControl …等9项 | — |
| packages/experimental/inspector/src/shared/bridge/messages/cordis.ts | 5 | CORDIS_TREE_TOPIC | — |
| packages/experimental/inspector/src/shared/bridge/messages/network.ts | 13 | FETCH_TOPICS | — |
| packages/experimental/inspector/src/shared/bridge/messages/observation.ts | 392 | parseWorkerSourceFrame, parseSourceFrame, InspectorSourceKind, InspectorSourceCapability, InspectorSourceDescriptor, InspectorRecordInput, SourceOpenFrame, SourceReplaceFrame …等16项 | — |
| packages/experimental/inspector/src/shared/bridge/messages/query/codec.ts | 139 | isInspectorQueryRequestEnvelope, isInspectorQueryResponseEnvelope, parseInspectorQueryRequestFrame, parseInspectorQueryFrameIdentity, parseInspectorQueryResponseFrame, InspectorQueryFrameIdentity | — |
| packages/experimental/inspector/src/shared/bridge/messages/query/commands.ts | 41 | CordisTreeGetQuery, InspectorQuery, CordisTreeGetResult, InspectorQueryResult, InspectorQueryResultFor, InspectorQueryError, InspectorQueryRequester | — |
| packages/experimental/inspector/src/shared/bridge/messages/query/frames.ts | 31 | InspectorQueryRequestId, InspectorQueryRequestFrame, InspectorQueryResponseFrame | — |
| packages/experimental/inspector/src/shared/bridge/messages/query/index.ts | 6 | — | — |
| packages/experimental/inspector/src/shared/bridge/messages/runtime/command-codec.ts | 135 | parseClientRuntimeCommand | — |
| packages/experimental/inspector/src/shared/bridge/messages/runtime/commands.ts | 102 | ClientRuntimeRemoteObject, ClientRuntimePropertyDescriptor, ClientRuntimeInternalPropertyDescriptor, ClientRuntimeExceptionDetails, ClientCallArgument, ClientRuntimeEvaluateCommand, ClientRuntimeGetPropertiesCommand, ClientRuntimeCallFunctionCommand …等16项 | — |
| packages/experimental/inspector/src/shared/bridge/messages/runtime/console-frames.ts | 148 | parseClientConsoleCapability, parseClientConsoleControlFrame, parseClientConsoleEventFrame, ClientConsoleCapability, ClientConsoleEnableFrame, ClientConsoleDisableFrame, ClientConsoleEventFrame | — |
| packages/experimental/inspector/src/shared/bridge/messages/runtime/frames.ts | 214 | parseClientRuntimeCapability, parseClientRuntimeRequestFrame, parseClientRuntimeCancelFrame, parseClientRuntimeResponseAcknowledgedFrame, parseClientRuntimeResponseFrame, parseClientRuntimeSessionClosedFrame, ClientRuntimeCapability, ClientRuntimeRequestFrame …等12项 | — |
| packages/experimental/inspector/src/shared/bridge/messages/runtime/index.ts | 6 | — | — |
| packages/experimental/inspector/src/shared/bridge/messages/runtime/value-codec.ts | 335 | parseClientRuntimeResult, parseClientRuntimeRemoteObject, parseClientRuntimeExceptionDetails, parseClientRuntimeStackTrace | — |
| packages/experimental/inspector/src/shared/bridge/messages/sources/codec.ts | 128 | parseClientSourceCommand, parseClientSourceResult | — |
| packages/experimental/inspector/src/shared/bridge/messages/sources/commands.ts | 48 | ClientScriptDescriptor, ClientSourceContentKind, ClientSourceCommand, ClientSourceResult, ClientSourceError | — |
| packages/experimental/inspector/src/shared/bridge/messages/sources/frames.ts | 144 | parseClientSourcesCapability, parseClientSourceRequestFrame, parseClientSourceResponseFrame, parseClientSourceSessionClosedFrame, ClientSourcesCapability, ClientSourceRequestFrame, ClientSourceResponseFrame, ClientSourceSessionClosedFrame | — |
| packages/experimental/inspector/src/shared/bridge/messages/sources/index.ts | 6 | — | — |
| packages/experimental/inspector/src/shared/bridge/publisher.ts | 46 | InspectorSourceConnection, InspectorPublisher, InspectorStatePublisher, InspectorConnection | — |
| packages/experimental/inspector/src/shared/bridge/query-reader.ts | 19 | createQueryCordisRuntimeTreeReader | — |
| packages/experimental/inspector/src/shared/bridge/rpc.ts | 183 | InspectorQueryRemoteError, InspectorQueryConnection, InspectorQuerySender, InspectorQueryConnectionOptions | — |
| packages/experimental/inspector/src/shared/bridge/validation.ts | 4 | — | — |
| packages/experimental/inspector/src/shared/bridge/version.ts | 3 | INSPECTOR_PROTOCOL_VERSION | — |
| packages/experimental/inspector/src/shared/cdp/capabilities.ts | 29 | RuntimeOperation, ConsoleOperation, SourceOperation, DebuggerOperation, InspectorRealmCapabilities | — |
| packages/experimental/inspector/src/shared/cdp/console.ts | 47 | RuntimeConsoleType, RuntimeConsoleEvent, RuntimeExceptionEvent, RuntimeConsoleBackendEvent | — |
| packages/experimental/inspector/src/shared/cdp/debugger.ts | 79 | RuntimeDebuggerLocation, RuntimeDebuggerScope, RuntimeDebuggerCallFrame, RuntimeCallFrameEvaluationRequest, RuntimeDebuggerEnableRequest, RuntimeDebuggerResumeRequest, RuntimeDebuggerEvent, RuntimeCallFrameEvaluation | — |
| packages/experimental/inspector/src/shared/cdp/errors.ts | 31 | RuntimeCallFrame, RuntimeStackTrace, RuntimeExceptionDetails | — |
| packages/experimental/inspector/src/shared/cdp/ids.ts | 13 | InspectorRealmId, RuntimeBackendObjectHandle, RuntimeScriptKey | — |
| packages/experimental/inspector/src/shared/cdp/index.ts | 12 | — | — |
| packages/experimental/inspector/src/shared/cdp/operations.ts | 88 | RuntimeCallArgument, RuntimeExecutionContext, RuntimeEvaluateRequest, RuntimeGetPropertiesRequest, RuntimeCallFunctionRequest, RuntimeAwaitPromiseRequest, RuntimeCompletion, RuntimeProperties | — |
| packages/experimental/inspector/src/shared/cdp/property.ts | 32 | RuntimePropertyDescriptor, RuntimeInternalPropertyDescriptor, RuntimePrivatePropertyDescriptor | — |
| packages/experimental/inspector/src/shared/cdp/realm.ts | 163 | NativeProtocolNotification, RealmCapability, RuntimeBackend, ConsoleBackend, SourceBackend, DebuggerBackend, NativeDomainBackend | — |
| packages/experimental/inspector/src/shared/cdp/remote-object.ts | 79 | RuntimeRemoteObjectType, RuntimeRemoteObjectSubtype, RuntimePropertyPreview, RuntimeObjectPreview, RuntimeRemoteObjectDescriptor, RuntimeBackendObjectReference, RuntimeRemoteObject | — |
| packages/experimental/inspector/src/shared/cdp/sources.ts | 20 | RuntimeScript | — |
| packages/experimental/inspector/src/shared/cordis/collector.ts | 199 | CordisTreeCollector, CordisTreeLimits | @deepseek-ai/cordis |
| packages/experimental/inspector/src/shared/cordis/ids.ts | 10 | InspectorObjectRegistryId, InspectorObjectHandle | — |
| packages/experimental/inspector/src/shared/cordis/model.ts | 161 | parseCordisRuntimeTree, cordisRuntimeSourceId, CORDIS_RUNTIME_TREE_SCHEMA_VERSION, CordisRuntimeSourceId, CordisRuntimeSourceKind, CordisRuntimeConnection, CordisRuntimeSource, CordisRuntimeContext …等12项 | — |
| packages/experimental/inspector/src/shared/cordis/object-reference.ts | 24 | parseInspectorObjectReference, InspectorObjectReference | — |
| packages/experimental/inspector/src/shared/cordis/object-registry.ts | 177 | realmObjectExpression, identifyRealmObject, RealmObjectRegistry, RealmObjectGeneration, IDENTIFY_REALM_OBJECT_FUNCTION | @deepseek-ai/dsh-util-crypto |
| packages/experimental/inspector/src/shared/cordis/observer.ts | 47 | observeCordisTree, CordisTreeSnapshotListener | @deepseek-ai/cordis |
| packages/experimental/inspector/src/shared/cordis/projector.ts | 79 | projectCordisRuntimeTree, CordisTreeSourceConnection, CordisTreeSource, CordisTreeSourceSnapshot, CordisInspectionTree | — |
| packages/experimental/inspector/src/shared/cordis/publisher.ts | 26 | publishCordisTree | @deepseek-ai/cordis |
| packages/experimental/inspector/src/shared/cordis/reader.ts | 25 | createCordisRuntimeTreeReader, CordisRuntimeTreeReader | — |
| packages/experimental/inspector/src/shared/cordis/snapshot.ts | 112 | parseCordisTreeSnapshot, CORDIS_TREE_SCHEMA_VERSION, CORDIS_TREE_MAX_DEPTH, CordisContextTreeNode, CordisFiberTreeNode, CordisTreeNode, CordisTreeSnapshot | — |
| packages/experimental/inspector/src/shared/dispose.ts | 24 | disposeInspectorResources | — |
| packages/experimental/inspector/src/shared/identity.ts | 20 | inspectorId, InspectorId | @deepseek-ai/dsh-brand |
| packages/experimental/inspector/src/shared/index.ts | 19 | — | — |
| packages/experimental/inspector/src/shared/json.ts | 80 | isJsonValue, requireJsonObject, jsonByteLength, isPlainObject, InspectorJsonPrimitive, InspectorJsonValue, InspectorJsonObject | — |
| packages/experimental/inspector/src/shared/network/event-source.ts | 78 | InspectorEventSourceParser | — |
| packages/experimental/inspector/src/shared/network/observation.ts | 61 | InspectorHeader, FetchIdentity, FetchStartPayload, FetchBodyChunkPayload, FetchRequestBodyEndPayload, FetchResponsePayload, FetchEndPayload, InspectorEventSourceMessage …等9项 | — |
| packages/experimental/inspector/src/shared/service.ts | 33 | createInspectorService, InspectorService | — |
| packages/experimental/inspector/src/shared/validation.ts | 94 | exactObject, exactKeys, wireId, optionalString, optionalBoolean, optionalNonNegativeNumber | — |
| packages/experimental/inspector/src/shared/web.ts | 27 | readInspectorClientSelection, INSPECTOR_BOOTSTRAP_PATH, INSPECTOR_BOOTSTRAP_ROUTE, INSPECTOR_CLIENT_QUERY | — |
| packages/experimental/inspector/src/worker/bridge/endpoint.ts | 317 | InspectorEndpoint, InspectorEndpointInfo | node:http, node:net, node:stream, ws |
| packages/experimental/inspector/src/worker/bridge/hub.ts | 324 | InspectorSourceRegistry, IngestedInspectorRecord, SourceConnection, InspectorRecordConsumer, InspectorSourceEvent, InspectorSourceView | — |
| packages/experimental/inspector/src/worker/bridge/runtime-rpc.ts | 381 | ClientRuntimeRemoteError, ClientRuntimeRouter, ClientRuntimeTarget, ClientRuntimeTargetEvent | node:crypto |
| packages/experimental/inspector/src/worker/bridge/session.ts | 27 | sendClientSessionClosed | — |
| packages/experimental/inspector/src/worker/bridge/source-rpc.ts | 193 | ClientSourceRemoteError, ClientSourceRouter | node:crypto |
| packages/experimental/inspector/src/worker/cdp/domains/debugger/cdp-params.ts | 53 | parseCallFrameEvaluation, requestScriptId | — |
| packages/experimental/inspector/src/worker/cdp/domains/debugger/index.ts | 7 | — | — |
| packages/experimental/inspector/src/worker/cdp/domains/debugger/projector.ts | 115 | scriptParsedEvent, debuggerEvent | — |
| packages/experimental/inspector/src/worker/cdp/domains/debugger/script-registry.ts | 118 | cdpScriptId, DebuggerScriptRegistry, DebuggerScriptRoute | — |
| packages/experimental/inspector/src/worker/cdp/domains/debugger/session.ts | 352 | DebuggerDomainSession | — |
| packages/experimental/inspector/src/worker/cdp/domains/dom/index.ts | 5 | — | — |
| packages/experimental/inspector/src/worker/cdp/domains/dom/model.ts | 326 | CordisDomBackend, CordisDomNode, CordisDomDocument, CordisDomMutation, CordisDomChange | — |
| packages/experimental/inspector/src/worker/cdp/domains/dom/session.ts | 556 | CordisDomSession | — |
| packages/experimental/inspector/src/worker/cdp/domains/native.ts | 56 | HostNativeDomainSession | — |
| packages/experimental/inspector/src/worker/cdp/domains/network/session.ts | 251 | NetworkDomain, NetworkSink | node:buffer |
| packages/experimental/inspector/src/worker/cdp/domains/runtime/cdp-params.ts | 257 | parseEvaluate, parseGetProperties, parseCallFunction, parseAwaitPromise, parseReleaseObject, parseReleaseObjectGroup, parseGlobalLexicalScopeNames, CdpExecutionContextSelector …等11项 | — |
| packages/experimental/inspector/src/worker/cdp/domains/runtime/index.ts | 4 | — | — |
| packages/experimental/inspector/src/worker/cdp/domains/runtime/object-table.ts | 324 | RuntimeObjectTable, RuntimeObjectRoute, RuntimeObjectPresentation, RuntimeObjectObserver, CdpRuntimeCompletion, CdpGetPropertiesResult, CdpRuntimeEvent | — |
| packages/experimental/inspector/src/worker/cdp/domains/runtime/session.ts | 476 | RuntimeDomainSession | — |
| packages/experimental/inspector/src/worker/cdp/ids.ts | 54 | cdpStringId, cdpNumericId, CdpNumericId, InspectorConnectionId, CdpRemoteObjectId, CdpScriptId, CdpCallFrameId, CdpExecutionContextId …等10项 | — |
| packages/experimental/inspector/src/worker/cdp/protocol.ts | 83 | parseCdpRequest, cdpError, sendCdpFailure, respondToCdpRequest, CdpRequest, CdpNotification, CdpTransport | — |
| packages/experimental/inspector/src/worker/cdp/realm-sessions.ts | 135 | InspectorRealmSessionSet, InspectorRealmSessionEvent | node:crypto |
| packages/experimental/inspector/src/worker/cdp/session.ts | 135 | CdpSession | — |
| packages/experimental/inspector/src/worker/cdp/target.ts | 78 | handleScaffold, CDP_METHOD_NOT_HANDLED, CdpTargetDescriptor | — |
| packages/experimental/inspector/src/worker/entry.ts | 56 | — | node:worker_threads |
| packages/experimental/inspector/src/worker/inspection/cordis-query.ts | 18 | executeInspectorQuery | — |
| packages/experimental/inspector/src/worker/inspection/cordis-store.ts | 249 | CordisTreeStore, CordisTreeSourceSnapshot, CordisInspectionTree, CordisTreeObjectRoute, CordisTreeStoreEvent, CordisTreeStoreOptions | — |
| packages/experimental/inspector/src/worker/inspection/network-store.ts | 450 | NetworkStore, NetworkStoreOptions, CapturedNetworkBody, NetworkStoreEvent | node:buffer |
| packages/experimental/inspector/src/worker/inspection/query-router.ts | 256 | InspectorQueryRouter, InspectorQueryPeer, InspectorQueryPeerTransport | — |
| packages/experimental/inspector/src/worker/inspection/realm-store.ts | 117 | InspectorRealmRegistry, InspectorRealmEvent | — |
| packages/experimental/inspector/src/worker/inspection/realm.ts | 55 | InspectorRealmDescriptor, InspectorRealmContext, InspectorRealmSession, InspectorRealm | — |
| packages/experimental/inspector/src/worker/realms/client/bridge.ts | 27 | createClientRealmBridge, ClientRealmBridge | — |
| packages/experimental/inspector/src/worker/realms/client/console.ts | 41 | ClientConsoleBackend | — |
| packages/experimental/inspector/src/worker/realms/client/debugger.ts | 12 | clientDebuggerCapability | — |
| packages/experimental/inspector/src/worker/realms/client/index.ts | 105 | ClientInspectorRealm | node:crypto |
| packages/experimental/inspector/src/worker/realms/client/runtime.ts | 168 | ClientRuntimeBackend | — |
| packages/experimental/inspector/src/worker/realms/client/scripts.ts | 28 | ClientScriptIdentity | — |
| packages/experimental/inspector/src/worker/realms/client/sources.ts | 123 | ClientSourceBackend | — |
| packages/experimental/inspector/src/worker/realms/client/values.ts | 163 | clientCompletion, clientProperty, clientInternalProperty, clientException, clientConsoleEvent, clientRemoteObject, clientHandle, ClientScriptKeyMapper | — |
| packages/experimental/inspector/src/worker/realms/host/bridge.ts | 165 | HostInspectorSession, HostNotificationChannel, HostInspectorNotification | node:inspector |
| packages/experimental/inspector/src/worker/realms/host/console.ts | 91 | HostConsoleBackend | — |
| packages/experimental/inspector/src/worker/realms/host/debugger.ts | 168 | HostDebuggerBackend | — |
| packages/experimental/inspector/src/worker/realms/host/index.ts | 68 | HostInspectorRealm | node:crypto |
| packages/experimental/inspector/src/worker/realms/host/runtime.ts | 339 | HostRuntimeBackend | — |
| packages/experimental/inspector/src/worker/realms/host/scripts.ts | 14 | hostScriptKey | — |
| packages/experimental/inspector/src/worker/realms/host/sources.ts | 100 | HostSourceBackend | — |
| packages/experimental/inspector/src/worker/realms/host/values.ts | 35 | isNativeRecord, requireNativeRecord, optionalNativeField | — |
| packages/experimental/inspector/src/worker/server.ts | 112 | startInspectorWorker, InspectorWorkerRuntime | node:worker_threads |
| packages/experimental/inspector/tsdown.config.ts | 36 | clientBundle | tsdown |

#### packages/experimental/inspector-profile — @deepseek-ai/dsh-experimental-inspector-profile@0.2.1-alpha.1（1 文件 / 4 行）

职责：inspector 启动 profile


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/experimental/inspector-profile/src/index.ts | 4 | — | — |

#### packages/experimental/ptc-runtime-python — @deepseek-ai/dsh-experimental-ptc-runtime-python@0.2.1-alpha.1（5 文件 / 5899 行）

职责：Python PTC 运行时（ctx.ptcRuntime 的 Python 实现）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/experimental/ptc-runtime-python/py/bootstrap.py | 2568 | — | — |
| packages/experimental/ptc-runtime-python/py/protocol.py | 140 | — | — |
| packages/experimental/ptc-runtime-python/src/index.ts | 2455 | hostFrameParseCeiling, readProcessStart, resolvePythonBin, detachResidual, PythonPtcRuntime, Config | node:child_process, node:fs, node:os, node:path, node:url |
| packages/experimental/ptc-runtime-python/src/protocol.ts | 719 | logTruncationMarker, encodeJsonPlain, checkDoneValue, hasUnsafeIntegerToken, hasNonLosslessNumber, validateChildFrame, PROTOCOL_FD, WIRE_FRAME_FIELDS …等11项 | — |
| packages/experimental/ptc-runtime-python/tsdown.config.ts | 17 | defineConfig | tsdown |

#### packages/experimental/session-inspector — @deepseek-ai/dsh-experimental-session-inspector@0.2.1-alpha.1（29 文件 / 2888 行）

职责：会话检查器 UI


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/experimental/session-inspector/src/client/index.ts | 20 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-sidebar-right |
| packages/experimental/session-inspector/src/client/locales.ts | 127 | NS, zh, en, SessionInspectorKey | — |
| packages/experimental/session-inspector/src/client/views/chat-node/dom.ts | 88 | displayed, mainChatRoot, inChat, findChatTargets | — |
| packages/experimental/session-inspector/src/client/views/chat-node/highlight.ts | 42 | visibleChatRect, placeChatHighlight | — |
| packages/experimental/session-inspector/src/client/views/chat-node/model.ts | 213 | ChatNodeModel | @deepseek-ai/dsh-client-ui-chat, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-session |
| packages/experimental/session-inspector/src/client/views/chat-node/objects.ts | 91 | ChatObjectIndex | @deepseek-ai/dsh-client-ui-chat, @deepseek-ai/dsh-client-ui-conversation |
| packages/experimental/session-inspector/src/client/views/chat-node/pick-match.ts | 69 | matchChatElement, matchChatNodeRow, InspectorPickTarget, InspectorElementMatch | — |
| packages/experimental/session-inspector/src/client/views/chat-node/picker.ts | 173 | InspectorChatPicker | — |
| packages/experimental/session-inspector/src/client/views/chat-node/reveal-target.ts | 91 | resolveChatRevealTargets | @deepseek-ai/dsh-client-ui-chat |
| packages/experimental/session-inspector/src/client/views/chat-node/reveal.ts | 179 | InspectorChatRevealer | react-dom |
| packages/experimental/session-inspector/src/client/views/format.ts | 34 | inspectorPreview, INSPECTOR_PREVIEW_LIMIT | — |
| packages/experimental/session-inspector/src/client/views/index.ts | 81 | registerInspectorTab | @deepseek-ai/cordis, @deepseek-ai/dsh-client-ui-renderer, @deepseek-ai/dsh-client-ui-sidebar-right, @deepseek-ai/dsh-client-ui-session, @deepseek-ai/dsh-api-session-controller |
| packages/experimental/session-inspector/src/client/views/InspectorDetails.tsx | 76 | InspectorDetails, InspectorDetailsProps | react, @deepseek-ai/dsh-client-ui-slots |
| packages/experimental/session-inspector/src/client/views/InspectorObjectTree.tsx | 123 | InspectorJsonTree, InspectorObjectTree, InspectorObjectTreeProps | react, @deepseek-ai/dsh-client-ui-slots |
| packages/experimental/session-inspector/src/client/views/InspectorTable.tsx | 346 | InspectorTable, InspectorInjected, InspectorTableProps | react, @tanstack/react-virtual, @deepseek-ai/dsh-client-ui-conversation, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-slots |
| packages/experimental/session-inspector/src/client/views/object-value.ts | 101 | InspectorObjectValue, InspectorObjectEntry | — |
| packages/experimental/session-inspector/src/client/views/objects.ts | 43 | InspectorChatTarget, InspectorObjectReference, InspectorObjects | @deepseek-ai/dsh-session, @deepseek-ai/dsh-client-store |
| packages/experimental/session-inspector/src/client/views/raw-json.ts | 45 | inspectorJson | — |
| packages/experimental/session-inspector/src/client/views/session-log/chat-target.ts | 48 | sessionLogChatTarget, SessionLogAnchor | @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-llm |
| packages/experimental/session-inspector/src/client/views/session-log/groups.ts | 48 | SessionLogGroups | @deepseek-ai/dsh-api-session-controller |
| packages/experimental/session-inspector/src/client/views/session-log/model.ts | 219 | SessionLogModel | @deepseek-ai/dsh-api-session-controller, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session |
| packages/experimental/session-inspector/src/client/views/session-log/stream.ts | 79 | AssistantLogStream | @deepseek-ai/dsh-llm |
| packages/experimental/session-inspector/src/client/views/table-layout.ts | 111 | InspectorTableLayout, INSPECTOR_ROW_HEIGHT, InspectorTableItem, InspectorViewport, InspectorRowAnchor | — |
| packages/experimental/session-inspector/src/client/views/table-model.ts | 123 | inspectorRowCollapsed, InspectorTableHierarchy, InspectorRecordSource, InspectorRow, InspectorDisclosure, InspectorRecord | @deepseek-ai/dsh-client-store |
| packages/experimental/session-inspector/src/client/views/type-filter.ts | 83 | InspectorTypeFilter, InspectorTypeMatches | — |
| packages/experimental/session-inspector/src/client/views/TypeFilter.tsx | 127 | TypeFilter, InspectorTypeFilterProps | react, react-dom, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/experimental/session-inspector/src/client/views/View.tsx | 99 | SessionInspectorView, InspectorPresentation, SessionInspectorInjected, SessionInspectorProps | react, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-sidebar-right |
| packages/experimental/session-inspector/src/index.ts | 5 | apply | — |
| packages/experimental/session-inspector/tsdown.config.ts | 4 | clientBundle | — |

#### packages/experimental/speech-to-text — @deepseek-ai/dsh-experimental-speech-to-text@0.2.1-alpha.1（4 文件 / 377 行）

职责：语音转文本缝与设置


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/experimental/speech-to-text/src/index.ts | 211 | Config, SpeechToText | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-settings, @deepseek-ai/cordis-plugin-loader |
| packages/experimental/speech-to-text/src/types.ts | 138 | SpeechProviderId, SpeechSetupEstimate, SpeechProviderInfo, SpeechPreparationStepKind, SpeechPreparationStep, SpeechDownloadFailure, SpeechPreparationState, SpeechProviderView …等18项 | @deepseek-ai/dsh-brand |
| packages/experimental/speech-to-text/src/wave.ts | 24 | validateWave | — |
| packages/experimental/speech-to-text/tsdown.config.ts | 4 | defineConfig | tsdown |

#### packages/experimental/speech-to-text-sensevoice — @deepseek-ai/dsh-experimental-speech-to-text-sensevoice@0.2.1-alpha.1（11 文件 / 904 行）

职责：SenseVoice 本地转写 provider


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/experimental/speech-to-text-sensevoice/src/config.ts | 79 | Config | @deepseek-ai/schemastery, @deepseek-ai/dsh-timeout |
| packages/experimental/speech-to-text-sensevoice/src/download-error.ts | 47 | classifyDownloadFailure, SpeechDownloadError | @deepseek-ai/dsh-experimental-speech-to-text, @deepseek-ai/dsh-timeout |
| packages/experimental/speech-to-text-sensevoice/src/index.ts | 43 | apply, name, inject | node:path, @deepseek-ai/cordis, @deepseek-ai/dsh-experimental-speech-to-text, @deepseek-ai/dsh-subprocess |
| packages/experimental/speech-to-text-sensevoice/src/inference.ts | 80 | createTranscriber, InferenceConfig | node:module, @deepseek-ai/dsh-experimental-speech-to-text |
| packages/experimental/speech-to-text-sensevoice/src/input.ts | 23 | validateInput, SpeechInputError, languages | @deepseek-ai/dsh-experimental-speech-to-text |
| packages/experimental/speech-to-text-sensevoice/src/model-sources.ts | 42 | orderModelSources | @deepseek-ai/dsh-timeout |
| packages/experimental/speech-to-text-sensevoice/src/process-server.ts | 56 | startRecognitionServer | node:http, node:crypto, @deepseek-ai/dsh-experimental-speech-to-text |
| packages/experimental/speech-to-text-sensevoice/src/recognizer.ts | 328 | readReady, readTranscript, SenseVoiceWorker | node:crypto, node:fs, @deepseek-ai/cordis, @deepseek-ai/dsh-subprocess, @deepseek-ai/dsh-experimental-speech-to-text |
| packages/experimental/speech-to-text-sensevoice/src/runtime.ts | 188 | inspectRuntime, downloadAsset, prepareRuntime, Asset, RuntimePaths | node:crypto, node:fs, node:path, node:stream, node:url |
| packages/experimental/speech-to-text-sensevoice/src/worker.ts | 14 | — | zod |
| packages/experimental/speech-to-text-sensevoice/tsdown.config.ts | 4 | defineConfig | tsdown |

#### packages/experimental/tool-agent-team — @deepseek-ai/dsh-experimental-tool-agent-team@0.2.1-alpha.1（1 文件 / 423 行）

职责：Agent Teams 模型工具（九个）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/experimental/tool-agent-team/src/index.ts | 423 | apply, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-experimental-agent-team, @deepseek-ai/dsh-tools |

#### packages/experimental/voice-input-bundle — @deepseek-ai/dsh-experimental-voice-input-bundle@0.2.1-alpha.1（2 文件 / 7 行）

职责：语音输入可选 bundle


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/experimental/voice-input-bundle/src/index.ts | 3 | — | — |
| packages/experimental/voice-input-bundle/tsdown.config.ts | 4 | defineConfig | tsdown |

#### packages/experimental/webworker-packer — @deepseek-ai/dsh-experimental-webworker-packer@0.2.1-alpha.1（9 文件 / 1241 行）

职责：WebWorker Host 打包器


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/experimental/webworker-packer/bin.js | 21 | — | node:fs, node:url |
| packages/experimental/webworker-packer/src/bin.ts | 90 | — | node:fs, node:path, node:url, @deepseek-ai/dsh-experimental-webworker-runtime |
| packages/experimental/webworker-packer/src/index.ts | 17 | — | — |
| packages/experimental/webworker-packer/src/pack.ts | 684 | packVfsImage, packVfsOverlay, MANIFEST_PATH, CONFIG_PATH, ImageTree, ConfigTree, PackOptions, PackResult …等9项 | node:fs, node:path, node:zlib, @deepseek-ai/dsh-experimental-webworker-runtime, picomatch |
| packages/experimental/webworker-packer/src/preview.ts | 91 | packPreviewFixture | node:fs, node:os, node:path, @deepseek-ai/dsh-session-format, @deepseek-ai/dsh-session-format-catalog |
| packages/experimental/webworker-packer/src/repository.ts | 218 | indexWorkspacePackages, composeProfile, configTrees, previewFixtures, describePack, PreviewFixture | node:child_process, node:fs, node:os, node:path, @deepseek-ai/dsh-home-paths |
| packages/experimental/webworker-packer/src/rules.ts | 74 | EXCLUDE, EXCLUDE_WORKSPACE, PAGE_ASSETS, IMAGE_ENTRY_SEEDS | — |
| packages/experimental/webworker-packer/src/transform-image.ts | 27 | WRAPPER_CONTRACT, ImageFiles, TransformOutcome | @deepseek-ai/dsh-experimental-webworker-runtime |
| packages/experimental/webworker-packer/tsdown.config.ts | 19 | defineConfig | tsdown |

#### packages/experimental/webworker-runtime — @deepseek-ai/dsh-experimental-webworker-runtime@0.2.1-alpha.1（82 文件 / 13364 行）

职责：浏览器 WebWorker 内跑完整 Host（实验）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/experimental/webworker-runtime/src/client/apply-injections.ts | 3 | — | @deepseek-ai/dsh-client-web |
| packages/experimental/webworker-runtime/src/client/client.ts | 570 | WorkerTunnel, BootPayload, TunnelFetch | @deepseek-ai/dsh-host-webserver |
| packages/experimental/webworker-runtime/src/client/index.ts | 176 | chooseWorkerHostSource, connectWorkerHost, WorkerHostConnectOptions, WorkerHostSourceOptions, WorkerHostSource, WorkerHostConnection | @deepseek-ai/dsh-client-file-upload |
| packages/experimental/webworker-runtime/src/client/source-chooser.ts | 265 | choosePreviewSource | — |
| packages/experimental/webworker-runtime/src/client/text-viewer.ts | 89 | showTextViewer | — |
| packages/experimental/webworker-runtime/src/compile/transform.ts | 626 | lowerModuleSource, x, LoweredModule | acorn |
| packages/experimental/webworker-runtime/src/fixture-manifest.ts | 69 | parsePreviewFixtureManifest, PREVIEW_FIXTURE_MANIFEST_VERSION, PREVIEW_FIXTURE_MANIFEST_FILE, PreviewFixtureManifestEntry, PreviewFixtureManifest | — |
| packages/experimental/webworker-runtime/src/image-layout.ts | 54 | DEFAULT_ROOT, IMAGE_FILE_NAME, IMAGE_CONFIG_PATH, IMAGE_MANIFEST_PATH, IMAGE_HOME_DIRECTORY, IMAGE_EMPTY_DIRECTORIES, IMAGE_OVERLAY_DIRECTORIES, LOWERING_VERSION …等9项 | — |
| packages/experimental/webworker-runtime/src/index.ts | 53 | — | — |
| packages/experimental/webworker-runtime/src/module-proxies.ts | 90 | MODULE_PROXIES, MODULE_PROXY_PREFIXES | — |
| packages/experimental/webworker-runtime/src/module-system/module-loader.ts | 453 | setActiveModuleLoader, requireActiveModuleLoader, WorkerModuleLoader, DEFAULT_CONDITIONS, StaticModuleFactory, Resolution, WorkerInternalResolution, WorkerRequireResolve …等10项 | — |
| packages/experimental/webworker-runtime/src/module-system/posix-path.ts | 171 | normalize, join, resolve, dirname, basename, extname, isAbsolute, relative …等13项 | — |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/abort-error.ts | 15 | abortError | — |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/assert/strict.ts | 29 | ok, __esModule, assert | — |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/async_hooks.ts | 407 | captureAsyncContext, runWithAsyncContext, bindAsyncContext, runAtAsyncContextRoot, __snapshotAll, __restoreAll, executionAsyncId, triggerAsyncId …等15项 | node:async_hooks |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/buffer.ts | 29 | constants, __esModule | buffer, node:buffer |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/child_process.ts | 453 | spawn, spawnSync, exec, execFile, WorkerChildProcess, execSync, execFileSync, fork …等11项 | buffer, node:child_process |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/crypto.ts | 127 | createHash, randomBytes, randomUUID, getRandomValues, randomInt, webcrypto, __esModule, Hash | @noble/hashes, @deepseek-ai/dsh-util-crypto, buffer, node:crypto |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/events.ts | 157 | EventEmitter, __esModule | node:events |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/fs-watch.ts | 429 | watch, watchFile, unwatchFile, watchAsync, FSWatcher, StatWatcher, WatchOptions, WatchFileOptions | buffer |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/fs.ts | 878 | readFileSync, writeFileSync, appendFileSync, existsSync, statSync, stat, chmodSync, lstatSync …等37项 | buffer, node:fs |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/fs/promises.ts | 21 | __esModule, promises | node:fs |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/http.ts | 186 | requestListener, whenRequestListener, createServer, request, get, ServerResponse, STATUS_CODES, __esModule | node:http |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/module.ts | 75 | createRequire, isBuiltin, stripTypeScriptTypes, register, syncBuiltinESMExports, builtinModules, __esModule, NodeRequire …等9项 | node:module |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/os.ts | 119 | tmpdir, homedir, platform, type, arch, release, hostname, availableParallelism …等13项 | node:os |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/path.ts | 399 | resolve, normalize, isAbsolute, join, relative, dirname, basename, extname …等17项 | node:path |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/perf_hooks.ts | 28 | performance, PerformanceObserver, __esModule | node:perf_hooks |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/stream.ts | 85 | __esModule, streamDefault | readable-stream, node:stream |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/stream/promises.ts | 15 | finished, pipeline, __esModule, promises | — |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/timers/promises.ts | 61 | setTimeout, setImmediate, scheduler, __esModule | node:timers |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/tty.ts | 20 | isatty, __esModule | node:tty |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/url.ts | 74 | fileURLToPath, pathToFileURL, resolve, __esModule | node:url |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/util.ts | 157 | promisify, callbackify, inspect, format, isDeepStrictEqual, parseArgs, deprecate, types …等9项 | node:util |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/util/types.ts | 15 | __esModule, types | — |
| packages/experimental/webworker-runtime/src/node/builtin_modules/implemented/zlib.ts | 86 | createZstdDecompress, constants, zstdCompressSync, zstdDecompressSync, zstdCompress, zstdDecompress, createZstdCompress, gzip …等12项 | node:zlib |
| packages/experimental/webworker-runtime/src/node/builtins.ts | 137 | createNodeBuiltins, REPLACED_PREFIXES | node:fs |
| packages/experimental/webworker-runtime/src/node/external_packages/execa.ts | 6 | execa | — |
| packages/experimental/webworker-runtime/src/node/external_packages/got.ts | 11 | __esModule, got | — |
| packages/experimental/webworker-runtime/src/node/external_packages/koffi.ts | 156 | __esModule, koffi | — |
| packages/experimental/webworker-runtime/src/node/external_packages/libreoffice-kit.ts | 13 | createConverter | — |
| packages/experimental/webworker-runtime/src/node/external_packages/node-addon-system-flock.ts | 21 | tryLockExclusive, __esModule | — |
| packages/experimental/webworker-runtime/src/node/external_packages/node-pty.ts | 20 | spawn, open, __esModule | — |
| packages/experimental/webworker-runtime/src/node/external_packages/pi-ai.ts | 93 | builtinProviders, getBuiltinProviders, getBuiltinModels, createProvider, createModels, getSupportedThinkingLevels, isContextOverflow, anthropicMessagesApi …等11项 | — |
| packages/experimental/webworker-runtime/src/node/external_packages/replaced-externals.ts | 21 | REPLACED_EXTERNAL_PACKAGES | — |
| packages/experimental/webworker-runtime/src/node/external_packages/ripgrep.ts | 16 | rgPath, __esModule | — |
| packages/experimental/webworker-runtime/src/node/external_packages/sharp.ts | 14 | __esModule, sharp | — |
| packages/experimental/webworker-runtime/src/node/external_packages/ws.ts | 63 | WebSocketServer, __esModule, Server, WebSocket | — |
| packages/experimental/webworker-runtime/src/node/globals/crypto.ts | 20 | installCryptoGlobals | @deepseek-ai/dsh-util-crypto |
| packages/experimental/webworker-runtime/src/node/globals/process.ts | 147 | installProcessGlobal, ProcessShimOptions, ProcessShim | — |
| packages/experimental/webworker-runtime/src/node/globals/timers.ts | 69 | installTimerGlobals, TimerHandle | — |
| packages/experimental/webworker-runtime/src/node/notImplementedFail.ts | 45 | notImplementedFail, notAvailableError | — |
| packages/experimental/webworker-runtime/src/node/process-table.ts | 77 | registerProcess, releaseProcess, processAlive, signalProcess, WorkerProcessEntry | — |
| packages/experimental/webworker-runtime/src/polyfill/async-context/als-runtime.ts | 103 | createAlsRuntime, AlsSnapshot, AlsToken, AlsCausality, AlsRuntime | — |
| packages/experimental/webworker-runtime/src/polyfill/async-context/async-context-hooks.ts | 81 | installAsyncContextHooks | — |
| packages/experimental/webworker-runtime/src/shell/ast.ts | 24 | Command, ValueArgument, RedirectArgument | @yarnpkg/parsers |
| packages/experimental/webworker-runtime/src/shell/expand.ts | 229 | isGlobPattern, readVariable, expandGlob, expandArgument, ExpansionContext | picomatch |
| packages/experimental/webworker-runtime/src/shell/fs-access.ts | 123 | resolveIn, describeFailure, filesystemError, hostFileSystem | — |
| packages/experimental/webworker-runtime/src/shell/interpret.ts | 390 | runShellCommand, runShellProgram, ShellRunOptions | @yarnpkg/parsers |
| packages/experimental/webworker-runtime/src/shell/process/child.ts | 95 | runShellProcess, ProcessScope | — |
| packages/experimental/webworker-runtime/src/shell/process/host.ts | 182 | startProcess, ProcessStartOptions, RunningProcess | — |
| packages/experimental/webworker-runtime/src/shell/process/landlock.ts | 195 | parseLandlockArguments, landlockFileSystem, LandlockLauncherError, LANDLOCK_EXECUTABLE, LandlockInvocation | — |
| packages/experimental/webworker-runtime/src/shell/process/protocol.ts | 83 | isShellStartFrame, ShellStartFrame, ShellOutputFrame, ShellExitFrame, ShellSignalFrame, FilesystemOperation, FilesystemCallFrame, FilesystemReplyFrame …等10项 | — |
| packages/experimental/webworker-runtime/src/shell/process/virtual-executables.ts | 64 | virtualExecutable, VirtualExecutableExit, VirtualExecutableDelegate, VirtualExecutablePreparation, VirtualExecutableSyncResult, VirtualExecutable | — |
| packages/experimental/webworker-runtime/src/shell/process/xdg-open.ts | 47 | setTextViewer, XDG_OPEN_EXECUTABLE, TextViewer | — |
| packages/experimental/webworker-runtime/src/shell/programs/builtins.ts | 193 | BUILTIN_PROGRAMS | — |
| packages/experimental/webworker-runtime/src/shell/programs/files.ts | 294 | FILE_PROGRAMS | picomatch |
| packages/experimental/webworker-runtime/src/shell/programs/index.ts | 46 | standardPrograms | — |
| packages/experimental/webworker-runtime/src/shell/programs/options.ts | 97 | parseOptions, numberOption, toLines, ParsedOptions | — |
| packages/experimental/webworker-runtime/src/shell/programs/text.ts | 364 | TEXT_PROGRAMS | — |
| packages/experimental/webworker-runtime/src/shell/types.ts | 147 | ShellState, ShellIo, ShellDirent, ShellStats, ShellFileSystem, ShellProgram, ShellRunOutcome | — |
| packages/experimental/webworker-runtime/src/storage/active.ts | 29 | setActiveVfs, requireActiveVfs | — |
| packages/experimental/webworker-runtime/src/storage/image-gzip.ts | 101 | inflateImageStream, inflateImage | — |
| packages/experimental/webworker-runtime/src/storage/memory.ts | 1047 | loadVfsImage, loadVfsOverlay, MemoryVfs, MemoryVfsOptions | — |
| packages/experimental/webworker-runtime/src/storage/paths.ts | 24 | DSH_ROOT, DSH_HOME, DSH_NODE_MODULES, DSH_CONFIG, DSH_WORKSPACE, DSH_TMP | — |
| packages/experimental/webworker-runtime/src/storage/tar.ts | 140 | packTar, parseTar, TarEntry | — |
| packages/experimental/webworker-runtime/src/storage/types.ts | 258 | VfsEncoding, VfsReadOptions, VfsError, VfsStats, VfsBigIntStats, VfsStatOptions, VfsWriteOptions, VfsSeedOptions …等16项 | — |
| packages/experimental/webworker-runtime/src/transport/frames.ts | 208 | parseInboundFrame, TunnelRequestId, TunnelRequestFrame, TunnelStreamOpenFrame, TunnelStreamUplinkItemFrame, TunnelStreamUplinkEndFrame, TunnelAbortFrame, TunnelInitFrame …等19项 | — |
| packages/experimental/webworker-runtime/src/transport/synthetic-http.ts | 159 | createSyntheticExchange, ResponseSink, RequestListener, SyntheticExchange | — |
| packages/experimental/webworker-runtime/src/transport/tunnel.ts | 566 | describeFailure, TunnelServer, API_PREFIX, SYNTHETIC_HOST, TunnelPort, TunnelSeams, TunnelServerOptions | — |
| packages/experimental/webworker-runtime/src/worker-host.ts | 474 | createWorkerHost, installLogSink, startWorkerHost, DEFAULT_PORT, LogMessage, LogExporter, HostContext, WorkerHostOptions …等10项 | @deepseek-ai/dsh-app-boot, @deepseek-ai/dsh-api-gateway, @deepseek-ai/dsh-client-connection, @deepseek-ai/dsh-cmdline, @deepseek-ai/cordis |
| packages/experimental/webworker-runtime/src/worker.ts | 91 | — | — |
| packages/experimental/webworker-runtime/tsdown.config.ts | 97 | defineConfig | node:module, node:path, node:url, tsdown |

#### packages/extensions/cordis-client-runner — @deepseek-ai/dsh-cordis-client-runner@0.2.1-alpha.1（12 文件 / 7821 行）

职责：动态 Cordis 插件的客户端半边与 remote 桥


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/extensions/cordis-client-runner/src/client/api-catalog.ts | 1149 | queryServiceApi, queryEventApi, RemoteStream, RemoteStreamCarrierError, SlotCore, SERVICE_API, EVENT_API, TYPE_API …等154项 | — |
| packages/extensions/cordis-client-runner/src/client/evaluator.ts | 223 | isDynamicCordisPlugin, evaluateClientHalf, DynamicCordisStyles, DYNAMIC_CLIENT_REDIRECTS, DynamicCordisEvaluatedPlugin, DynamicCordisClosureEnv | react, @deepseek-ai/dsh-api-remotes |
| packages/extensions/cordis-client-runner/src/client/guard.ts | 246 | dynamicCordisContext, DynamicCordisSlotLedgerRow, DynamicCordisGuardEnv | @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-ui-renderer, @deepseek-ai/dsh-client-ui-theme |
| packages/extensions/cordis-client-runner/src/client/index.ts | 310 | apply, name, inject, CordisRunnerFace | @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-modules, @deepseek-ai/dsh-client-ui-renderer, @deepseek-ai/dsh-util-values |
| packages/extensions/cordis-client-runner/src/client/inspect-registry.ts | 151 | provideClientCordisInspect, ClientCordisInspectRegistry, ClientCordisInspectQueryContext, ClientCordisInspectProviderRegistration, ClientCordisInspectHost | @deepseek-ai/cordis, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-util-values |
| packages/extensions/cordis-client-runner/src/client/orchestrator.ts | 459 | CordisRunOrchestrator, CordisRunActivity, CordisRunFailure, CordisRunHostSeam, CordisRunOrchestratorEnv, CordisRunRequest, CordisUserRunRequest | @deepseek-ai/dsh-api-remotes |
| packages/extensions/cordis-client-runner/src/client/providers.ts | 264 | clientInspectProviders, CLIENT_BUILTIN_INSPECTION | @deepseek-ai/cordis, @deepseek-ai/dsh-util-values, @deepseek-ai/dsh-client-ui-renderer, @deepseek-ai/dsh-client-ui-theme |
| packages/extensions/cordis-client-runner/src/client/runtime.ts | 513 | errorDetails, DynamicCordisPackageRunner, CordisObservable, DynamicCordisLoadErrorCause, CordisErrorDetails, DynamicCordisClientHalf, DynamicCordisRenderFailure, DynamicCordisLoadResult …等10项 | @deepseek-ai/cordis, @deepseek-ai/cordis-plugin-loader, @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-modules, @deepseek-ai/dsh-client-ui-renderer |
| packages/extensions/cordis-client-runner/src/client/slot-catalog.ts | 4275 | CLIENT_NOTES, CLIENT_SLOT_API, ClientSlotOption, ClientSlotEntry, ApprovalDetailOwnerProps, AssistantActionOwnerProps, CommandRowOwnerProps, ChatNodeOwnerProps …等64项 | — |
| packages/extensions/cordis-client-runner/src/client/timer.ts | 217 | provideClientTimer, ClientTimerService | @deepseek-ai/cordis |
| packages/extensions/cordis-client-runner/src/index.ts | 10 | apply | — |
| packages/extensions/cordis-client-runner/tsdown.config.ts | 4 | clientBundle | — |

#### packages/extensions/cordis-host-runner — @deepseek-ai/dsh-cordis-host-runner@0.2.1-alpha.1（7 文件 / 3388 行）

职责：运行时自修改宿主半（ctx.dynamicCordisRunner）：VM 求值+专用 fiber 组挂载


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/extensions/cordis-host-runner/src/guard.ts | 837 | sandboxDefineTool, normalizeHandler, sandboxRegisterTool, isPlugin, guardedPlugin, pluginName | @deepseek-ai/cordis, @deepseek-ai/dsh-scope, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-util-values |
| packages/extensions/cordis-host-runner/src/index.ts | 1281 | CordisDynamicPluginId, CordisDynamicPackageId, CordisDynamicPluginRunId, ApprovalRequestId, DynamicCordisRunnerService, Config, DynamicCordisSnapshotRow | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-typert-protocol |
| packages/extensions/cordis-host-runner/src/inspect-registry.ts | 293 | CordisInspectRegistryService, HostCordisInspectQueryContext, HostCordisInspectProviderRegistration | @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-api-gateway, @deepseek-ai/dsh-util-values, @deepseek-ai/dsh-tools |
| packages/extensions/cordis-host-runner/src/lifecycle.ts | 58 | startHostHalf, missingServices | @deepseek-ai/cordis |
| packages/extensions/cordis-host-runner/src/registry.ts | 277 | DynamicCordisRegistry, DynamicCordisHandler, DynamicCordisRun, DynamicCordisDefinition, DynamicCordisPlugin, DynamicCordisPendingRequest, DynamicCordisDefineRequest, DynamicCordisDefineReceipt …等11项 | @deepseek-ai/cordis, @deepseek-ai/dsh-session |
| packages/extensions/cordis-host-runner/src/sandbox.ts | 238 | createSandbox, syntaxErrorContext, parseErrorMessage, precheckCode, evaluateHostCode | node:vm |
| packages/extensions/cordis-host-runner/src/types.ts | 404 | CordisDynamicPluginId, CordisDynamicPackageId, CordisDynamicPluginRunId, ApprovalRequestId, CordisInspectRequestId, CordisInspectPlatform, CordisInspectMethodManifest, CordisInspectProviderManifest …等35项 | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-session, @deepseek-ai/dsh-util-values |

#### packages/extensions/tool-cordis — @deepseek-ai/dsh-tool-cordis@0.2.1-alpha.1（6 文件 / 8858 行）

职责：cordis_inspect_list/query 只读发现工具（8.9K 行含 API 目录）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/extensions/tool-cordis/src/api-catalog.ts | 8502 | queryServiceApi, queryEventApi, AttachmentError, BackendRegistry, DomainImpl, EventLogReporter, LlmAdapter, LlmRuntime …等1004项 | — |
| packages/extensions/tool-cordis/src/config.ts | 121 | queryLiveConfig | @deepseek-ai/cordis, @deepseek-ai/cordis-plugin-loader, @deepseek-ai/dsh-app-boot, @deepseek-ai/dsh-util-values |
| packages/extensions/tool-cordis/src/host.ts | 21 | apply, name, inject | @deepseek-ai/cordis |
| packages/extensions/tool-cordis/src/index.ts | 75 | apply, name, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-util-values, @deepseek-ai/dsh-tools |
| packages/extensions/tool-cordis/src/present.ts | 20 | presentInspectListCall, presentInspectQueryCall | @deepseek-ai/dsh-tools |
| packages/extensions/tool-cordis/src/providers.ts | 119 | hostInspectProviders | @deepseek-ai/cordis, @deepseek-ai/dsh-cordis-host-runner, @deepseek-ai/dsh-util-values |

#### packages/extensions/ui-cordis — @deepseek-ai/dsh-client-ui-cordis@0.2.1-alpha.1（16 文件 / 1702 行）

职责：动态 Cordis 的面板/卡片 UI


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/extensions/ui-cordis/src/client/card-model.ts | 162 | cordisDefineCard, cordisRunCard, cordisActionCard, CordisToolState, CordisDefineCard, CordisRunCard, CordisActionCard | @deepseek-ai/dsh-client-ui-tool |
| packages/extensions/ui-cordis/src/client/CordisActionRow.tsx | 51 | CordisActionRow, CordisActionRowProps | @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-tool |
| packages/extensions/ui-cordis/src/client/CordisDefineRow.tsx | 173 | CordisDefineRow, CordisDefineRowProps | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-tool |
| packages/extensions/ui-cordis/src/client/CordisPanel.tsx | 508 | CordisPanel, CordisPanelProps | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-sidebar, @deepseek-ai/dsh-cordis-client-runner |
| packages/extensions/ui-cordis/src/client/CordisPreparingRow.tsx | 31 | CordisPreparingRow | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-tool |
| packages/extensions/ui-cordis/src/client/CordisRunRow.tsx | 137 | CordisRunRow, CordisRunRowProps | react, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-client-ui-tool |
| packages/extensions/ui-cordis/src/client/dynamic-port.ts | 25 | CordisActionResult, CordisDynamicPort, CordisInventoryRow | @deepseek-ai/dsh-api-remotes |
| packages/extensions/ui-cordis/src/client/events.ts | 18 | — | @deepseek-ai/dsh-api-remotes |
| packages/extensions/ui-cordis/src/client/index.ts | 149 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-session, @deepseek-ai/dsh-client-ui-tool, @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-sidebar |
| packages/extensions/ui-cordis/src/client/inventory.ts | 114 | createCordisInventory, CordisInventorySnapshot, CordisInventory | @deepseek-ai/dsh-client-ui-slots |
| packages/extensions/ui-cordis/src/client/locales.ts | 124 | NS, zh, en, CordisKey | — |
| packages/extensions/ui-cordis/src/client/run-card-index.ts | 77 | cordisToolViewKey, CordisRunCardRegistry, CordisToolViewKey, CordisRunCardPointer, CordisRunCardStore | @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-ui-slots |
| packages/extensions/ui-cordis/src/client/slots.ts | 73 | CordisToolViewOwnerProps, CordisCardFace, CordisRunCardFace, CordisPanelFace | @deepseek-ai/dsh-api-remotes, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-cordis-client-runner |
| packages/extensions/ui-cordis/src/client/status.ts | 46 | packageOf, cordisVisibleStatus, CordisVisibleStatus | @deepseek-ai/dsh-cordis-client-runner |
| packages/extensions/ui-cordis/src/index.ts | 10 | apply | — |
| packages/extensions/ui-cordis/tsdown.config.ts | 4 | clientBundle | — |

#### packages/feedback/command-feedback — @deepseek-ai/dsh-command-feedback@0.2.1-alpha.1（2 文件 / 198 行）

职责：/feedback 命令 → log-only feedback/record 事件


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/feedback/command-feedback/src/index.ts | 128 | recordFeedback, apply, SessionFeedbackService, FEEDBACK_CATEGORIES, name, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-commands, @deepseek-ai/dsh-session, @deepseek-ai/dsh-anonymous-user-id, @deepseek-ai/dsh-typert-protocol |
| packages/feedback/command-feedback/src/types.ts | 70 | FeedbackCategory, FeedbackRecord, SessionFeedbackRecordRequest, SessionFeedbackRecordValue, SessionFeedbackSessionNotFound, SessionFeedbackRecordResult | @deepseek-ai/dsh-session |

#### packages/feedback/message-feedback — @deepseek-ai/dsh-message-feedback@0.2.1-alpha.1（2 文件 / 492 行）

职责：消息级评分/备注（ctx.messageFeedback）：冷路径直写持久层


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/feedback/message-feedback/src/index.ts | 314 | MessageFeedbackService, Config | node:buffer, node:crypto, node:util, @deepseek-ai/cordis, @deepseek-ai/schemastery |
| packages/feedback/message-feedback/src/types.ts | 178 | MessageFeedbackVersion, MessageFeedbackRating, MessageFeedbackItem, MessageFeedbackPut, MessageFeedbackDelete, MessageFeedbackListRequest, MessageFeedbackListValue, MessageFeedbackPutRequest …等21项 | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session, @deepseek-ai/dsh-command-feedback |

#### packages/fs/fs — @deepseek-ai/dsh-fs@0.2.1-alpha.1（2 文件 / 501 行）

职责：文件系统 Service Definition（ctx.fs）+ fs/write-intent|edit-intent|observed 事件


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/fs/fs/src/index.ts | 297 | FileSystem | @deepseek-ai/cordis, @deepseek-ai/dsh-sandbox |
| packages/fs/fs/src/types.ts | 204 | FsTargetKey, FsVersion, FsError, FsObservation, FsTarget, FsInfo, FsPathInfo, FsDirEntry …等13项 | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-brand |

#### packages/fs/fs-local — @deepseek-ai/dsh-fs-local@0.2.1-alpha.1（3 文件 / 1274 行）

职责：本地文件系统实现：realpath targetKey + FIFO 锁 + 版本 CAS 写


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/fs/fs-local/src/fsio.ts | 837 | localDisplayPath, resolveLocalTarget, probe, probeNoFollow, listDirectory, readWholeText, readWholeBytes, readByteWindow …等19项 | node:crypto, node:fs, node:path, node:util, @deepseek-ai/dsh-fs |
| packages/fs/fs-local/src/index.ts | 302 | LocalFileSystem, Config | @deepseek-ai/cordis, node:buffer, node:events, chokidar, node:path |
| packages/fs/fs-local/src/win32.ts | 135 | readFileDaclWin32, copyFileDaclWin32, replaceFileWin32 | node:path, koffi |

#### packages/fs/fs-observation-policy — @deepseek-ai/dsh-fs-observation-policy@0.2.1-alpha.1（2 文件 / 161 行）

职责：先读后写审批：ObservedStateGate 占用两个 waterfall 单槽


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/fs/fs-observation-policy/src/index.ts | 131 | apply, name | @deepseek-ai/cordis, @deepseek-ai/dsh-fs |
| packages/fs/fs-observation-policy/src/types.ts | 30 | FsObservationActor | — |

#### packages/fs/fs-sandbox — @deepseek-ai/dsh-fs-sandbox@0.2.1-alpha.1（2 文件 / 225 行）

职责：沙箱围栏文件系统：workspace-write 重新 resolve + 可写根校验


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/fs/fs-sandbox/src/containment.ts | 77 | isPathUnder | node:fs, node:path |
| packages/fs/fs-sandbox/src/index.ts | 148 | SandboxedFileSystem, Config | @deepseek-ai/cordis, @deepseek-ai/dsh-fs-local, @deepseek-ai/dsh-fs, @deepseek-ai/dsh-sandbox, @deepseek-ai/dsh-sandbox-policy |

#### packages/fs/tool-fs — @deepseek-ai/dsh-tool-fs@0.2.1-alpha.1（11 文件 / 1538 行）

职责：read/write/edit/read_image 模型工具 + 沙箱升级参数控制器


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/fs/tool-fs/src/diff.ts | 82 | computeHunkDiffs, diffsFromMeta, DIFF_CONTEXT, FsDiffMeta | diff, @deepseek-ai/dsh-tools |
| packages/fs/tool-fs/src/edit.ts | 173 | parseEditArgs, formatEditOutput, applyEditTool | @deepseek-ai/cordis, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-fs |
| packages/fs/tool-fs/src/error.ts | 35 | remediateFsError | @deepseek-ai/dsh-fs |
| packages/fs/tool-fs/src/index.ts | 80 | apply, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-user-approval |
| packages/fs/tool-fs/src/read-image.ts | 350 | sniffImageMediaType, imageMediaTypeForPath, assertImageCapableRoute, imageRefFromValue, formatImageReadOutput, applyReadImageTool, ImageReadValue | node:path, @deepseek-ai/cordis, @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-tools |
| packages/fs/tool-fs/src/read-render.ts | 245 | buildWindow, formatReadOutput, readMetaFromMeta, READ_MAX_LINE_LENGTH, READ_MAX_BYTES, ReadWindow, FileTextLine, WindowResult …等10项 | @deepseek-ai/dsh-fs, @deepseek-ai/dsh-util-code-language |
| packages/fs/tool-fs/src/read-target.ts | 35 | resolveRegularReadTarget | @deepseek-ai/cordis, @deepseek-ai/dsh-fs, @deepseek-ai/dsh-tools |
| packages/fs/tool-fs/src/read.ts | 211 | parseReadArgs, applyReadTool, READ_LIMIT, STREAM_MIN_SIZE, ReadToolCaps | @deepseek-ai/cordis, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-fs |
| packages/fs/tool-fs/src/sandbox.ts | 132 | FsSandboxController, FsEscalationArgs, EscalationSchemaFields | @deepseek-ai/cordis, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-sandbox, @deepseek-ai/dsh-sandbox-policy, @deepseek-ai/dsh-fs |
| packages/fs/tool-fs/src/session-cwd.ts | 37 | sessionCwd, sessionResolveOptions | @deepseek-ai/dsh-tools |
| packages/fs/tool-fs/src/write.ts | 158 | parseWriteArgs, formatWriteOutput, applyWriteTool | @deepseek-ai/cordis, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-fs |

#### packages/fs/tool-fs-search — @deepseek-ai/dsh-tool-fs-search@0.2.1-alpha.1（6 文件 / 1545 行）

职责：glob/grep 搜索工具（ripgrep 子进程）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/fs/tool-fs-search/src/direct-call.ts | 29 | acceptedDirectCallValue | @deepseek-ai/cordis, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-util-values |
| packages/fs/tool-fs-search/src/glob.ts | 369 | parseGlobArgs, buildGlobCommand, sampleAcrossTopLevel, formatGlobOutput, presentGlobCall, presentGlobResult, applyGlobTool, GLOB_MAX_RESULTS …等12项 | @deepseek-ai/cordis, node:path, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-spill |
| packages/fs/tool-fs-search/src/grep.ts | 367 | parseGrepArgs, buildGrepCommand, parseGrepMatches, formatGrepMatches, formatGrepOutput, presentGrepCall, presentGrepResult, applyGrepTool …等12项 | @deepseek-ai/cordis, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-output-retention, @deepseek-ai/dsh-spill |
| packages/fs/tool-fs-search/src/index.ts | 161 | apply, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-timeout |
| packages/fs/tool-fs-search/src/presentation.ts | 206 | groupMatchesByFile, grepSearchMeta, globSearchMeta, searchViewFromMeta, SearchMeta | @deepseek-ai/dsh-tools, @deepseek-ai/dsh-output-retention |
| packages/fs/tool-fs-search/src/search-core.ts | 413 | resolveRgPath, runRipgrep, toWorkdirRelative, previewLine, retainGrepMatches, retainGlobPaths, trySaveFormattedResult, SearchError …等16项 | node:fs, node:path, @deepseek-ai/cordis, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-output-retention |

#### packages/fs/tool-str-replace-editor — @deepseek-ai/dsh-tool-str-replace-editor@0.2.1-alpha.1（1 文件 / 533 行）

职责：字面替换编辑工具


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/fs/tool-str-replace-editor/src/index.ts | 533 | apply, name, inject, Config | node:path, @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-fs, @deepseek-ai/dsh-output-retention |

#### packages/goal/command-goal — @deepseek-ai/dsh-command-goal@0.2.1-alpha.1（1 文件 / 199 行）

职责：/goal 人类命令：观察或变更当前目标


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/goal/command-goal/src/index.ts | 199 | apply, name, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-commands, @deepseek-ai/dsh-goal, @deepseek-ai/dsh-llm |

#### packages/goal/goal — @deepseek-ai/dsh-goal@0.2.1-alpha.1（7 文件 / 1332 行）

职责：同会话目标域（ctx.goals）：事件溯源+CAS+进程本地 activation


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/goal/goal/src/client.ts | 11 | — | — |
| packages/goal/goal/src/domain.ts | 117 | GoalOperation, GoalSnapshotChangeMeta, GoalClearChangeMeta, GoalChangeMeta, GoalMessageSource, FoldedGoal, GoalChanged, GoalErrorCode | @deepseek-ai/dsh-agent, @deepseek-ai/dsh-scope |
| packages/goal/goal/src/fold.ts | 350 | emptyGoalFoldState, decodeGoalChange, goalChangeRef, applyGoalChange, applyGoalEvent, foldGoal, GoalFoldState | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session |
| packages/goal/goal/src/index.ts | 654 | applyGoalProjection, GoalService, goalProjectionDefinition, Config, ResolvedConfig | node:crypto, @deepseek-ai/cordis, @deepseek-ai/schemastery, zod, @deepseek-ai/dsh-agent |
| packages/goal/goal/src/runtime.ts | 31 | GoalId, GoalError, GOAL_CHANGE_VERSION | @deepseek-ai/dsh-llm |
| packages/goal/goal/src/types.ts | 153 | GoalId, GoalRef, CreateGoalRequest, CreateGoalResult, EditGoalRequest, GoalPhase, GoalBlockReason, GoalSnapshot …等13项 | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-session |
| packages/goal/goal/tsdown.config.ts | 16 | defineConfig | tsdown |

#### packages/goal/goal-round-driver — @deepseek-ai/dsh-goal-round-driver@0.2.1-alpha.1（3 文件 / 504 行）

职责：goal round 驱动：agent 空闲且 armed 时注入下一轮提示


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/goal/goal-round-driver/src/index.ts | 461 | apply, name, inject | node:util, @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-goal, @deepseek-ai/dsh-llm |
| packages/goal/goal-round-driver/src/prompt.ts | 27 | renderGoalRoundPrompt | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-goal |
| packages/goal/goal-round-driver/tsdown.config.ts | 16 | defineConfig | tsdown |

#### packages/goal/tool-goal — @deepseek-ai/dsh-tool-goal@0.2.1-alpha.1（3 文件 / 505 行）

职责：get/create/update_goal 模型工具（人工门禁 + wrapup 指引）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/goal/tool-goal/src/authority.ts | 119 | goalToolExecution, requireDirectHuman, completionAuthority, GoalToolExecution, GoalToolAuthority | @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-goal, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session |
| packages/goal/tool-goal/src/index.ts | 344 | apply, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-goal, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-tools |
| packages/goal/tool-goal/src/wrapup.ts | 42 | renderWrapupContext | @deepseek-ai/dsh-llm |

#### packages/guard/repeat-tool-reminder — @deepseek-ai/dsh-repeat-tool-reminder@0.2.1-alpha.1（1 文件 / 241 行）

职责：重复工具调用连击提醒（只提醒不否决）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/guard/repeat-tool-reminder/src/index.ts | 241 | apply, name, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session |

#### packages/guard/timeout-policy — @deepseek-ai/dsh-tool-call-timeout-policy@0.2.1-alpha.1（1 文件 / 82 行）

职责：tools/execute 协作式超时（结构化 TOOL_TIMEOUT 结果）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/guard/timeout-policy/src/index.ts | 82 | apply, TOOL_TIMEOUT, name, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-timeout, @deepseek-ai/dsh-tools |

#### packages/hooks/hook-protocol — @deepseek-ai/dsh-hook-protocol@0.2.1-alpha.1（8 文件 / 741 行）

职责：Claude Code/Codex hook 共享执行与解码库（JSON stdin，永不抛出）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/hooks/hook-protocol/src/codec.ts | 135 | parseHookOutput | — |
| packages/hooks/hook-protocol/src/detached.ts | 63 | createDetachedRuns, DetachedRuns | — |
| packages/hooks/hook-protocol/src/events.ts | 105 | summarizeStderr, appendHookInvoked, appendHookResult, DEFAULT_STDERR_SUMMARY_MAX_CHARS, HookInvocation, HookResultRecord | @deepseek-ai/dsh-session |
| packages/hooks/hook-protocol/src/index.ts | 26 | — | — |
| packages/hooks/hook-protocol/src/matcher.ts | 66 | matcherDiagnostic, matchesMatcher | — |
| packages/hooks/hook-protocol/src/merge.ts | 101 | mergeHookOutputs, MergedDecision, MergedHookOutcome | — |
| packages/hooks/hook-protocol/src/runner.ts | 107 | runHook, DEFAULT_HOOK_TIMEOUT_MS, RunHookOptions, RunHookResult | @deepseek-ai/dsh-shell |
| packages/hooks/hook-protocol/src/types.ts | 138 | HookDialect, CommandHook, MatcherGroup, MatcherMode, HookOutput | — |

#### packages/hooks/hooks-claude-code — @deepseek-ai/dsh-hooks-claude-code@0.2.1-alpha.1（2 文件 / 491 行）

职责：CC hooks.json 事件映射（SessionStart/PreToolUse/Stop 等）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/hooks/hooks-claude-code/src/config.ts | 124 | substituteCommand, parseClaudeCodeConfig, ClaudeCodeHookConfig, SkippedHook, ParsedClaudeConfig, SubstitutionVars | @deepseek-ai/dsh-hook-protocol |
| packages/hooks/hooks-claude-code/src/index.ts | 367 | apply, name, inject, Config | node:fs, @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-session-projection |

#### packages/hooks/hooks-codex — @deepseek-ai/dsh-hooks-codex@0.2.1-alpha.1（2 文件 / 422 行）

职责：Codex hooks 桥（同构）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/hooks/hooks-codex/src/config.ts | 87 | parseCodexConfig, CODEX_EVENTS, CodexHookConfig, SkippedHook, ParsedCodexConfig | @deepseek-ai/dsh-hook-protocol |
| packages/hooks/hooks-codex/src/index.ts | 335 | apply, name, inject, Config | node:fs, @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-session-projection |

#### packages/host/directory-picker — @deepseek-ai/dsh-host-directory-picker@0.2.1-alpha.1（2 文件 / 156 行）

职责：工作区目录选择 Service Definition


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/host/directory-picker/src/index.ts | 116 | DirectoryPickerError, DirectoryPicker, DirectoryPickerNativeCapability, DirectoryPickerBrowseCapability, DirectoryPickerCapabilities, DirectoryPickerCapability, DirectoryPickerErrorCode | @deepseek-ai/cordis |
| packages/host/directory-picker/src/types.ts | 40 | DirectoryEntry, DirectoryListing | — |

#### packages/host/directory-picker-auto — @deepseek-ai/dsh-host-directory-picker-auto@0.2.1-alpha.1（3 文件 / 206 行）

职责：按 bind/SSH/显示探测自动选型


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/host/directory-picker-auto/src/index.ts | 105 | apply, name, inject, BACKEND_PACKAGES, SURFACE_PACKAGES | @deepseek-ai/cordis, @deepseek-ai/cordis-plugin-loader, @deepseek-ai/dsh-host-webserver, @deepseek-ai/dsh-launch-environment |
| packages/host/directory-picker-auto/src/probe.ts | 45 | canExecute, hasLinuxChooserBinary | node:fs, node:path |
| packages/host/directory-picker-auto/src/resolve.ts | 56 | resolveDirectoryPickerBackend, DirectoryPickerBackendKind, DirectoryPickerEnv, DirectoryPickerHostFacts | @deepseek-ai/dsh-host-webserver |

#### packages/host/directory-picker-browse — @deepseek-ai/dsh-host-directory-picker-browse@0.2.1-alpha.1（2 文件 / 341 行）

职责：浏览器内浏览式选择


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/host/directory-picker-browse/src/index.ts | 325 | fullyQualified, boundedInsert, raceAbort, ListingCandidate, Config, BrowseDirectoryPicker | node:fs, node:os, node:path, @deepseek-ai/cordis, @deepseek-ai/schemastery |
| packages/host/directory-picker-browse/tsdown.config.ts | 16 | defineConfig | tsdown |

#### packages/host/directory-picker-native — @deepseek-ai/dsh-host-directory-picker-native@0.2.1-alpha.1（8 文件 / 783 行）

职责：原生对话框（win32 worker）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/host/directory-picker-native/src/index.ts | 37 | NativeDirectoryPicker | @deepseek-ai/dsh-host-directory-picker |
| packages/host/directory-picker-native/src/native-picker.ts | 108 | pickNativeDirectory, DirectoryPickerRunner, DirectoryPickerInternals | @deepseek-ai/dsh-native-command |
| packages/host/directory-picker-native/src/win32-dialog-bindings.ts | 207 | loadWin32DialogBindings, closeThreadWindows | koffi |
| packages/host/directory-picker-native/src/win32-dialog-host.ts | 35 | spawnDialogWorker | node:child_process, node:url |
| packages/host/directory-picker-native/src/win32-dialog-logic.ts | 148 | runFolderDialog, HRESULT_CANCELLED, FOS_PICKFOLDERS, FOS_FORCEFILESYSTEM, FOS_NOCHANGEDIR, Win32FolderDialog, Win32DialogBindings | — |
| packages/host/directory-picker-native/src/win32-dialog-worker.ts | 56 | Win32DialogWorkerData, Win32DialogWorkerMessage | — |
| packages/host/directory-picker-native/src/win32-dialog.ts | 160 | pickWin32Directory, DIALOG_TITLE, Win32DialogWorkerLike, Win32DialogInternals | — |
| packages/host/directory-picker-native/tsdown.config.ts | 32 | defineConfig | tsdown |

#### packages/host/frontend-static — @deepseek-ai/dsh-host-frontend-static@0.2.1-alpha.1（1 文件 / 141 行）

职责：前端 dist 的 fallback 席位持有者


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/host/frontend-static/src/index.ts | 141 | serveStatic, apply, name, inject, Config | node:http, node:fs, node:path, @deepseek-ai/cordis, @deepseek-ai/schemastery |

#### packages/host/open-in-app — @deepseek-ai/dsh-host-open-in-app@0.2.1-alpha.1（7 文件 / 1694 行）

职责："Open In..." 宿主应用解析（catalog/resolver/icons）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/host/open-in-app/src/catalog.ts | 394 | PATH_TOKEN, OPEN_IN_APP_CATALOG, OpenInAppPlatform, OpenInAppLaunch, OpenInAppLocator, OpenInAppPlatformSpec, OpenInAppApp | — |
| packages/host/open-in-app/src/icons.ts | 162 | extractAppIcon, OpenInAppIcon | node:fs, node:os, node:path, @deepseek-ai/dsh-native-command |
| packages/host/open-in-app/src/index.ts | 312 | apply, name, inject, Config | node:http, node:path, node:fs, @deepseek-ai/cordis, @deepseek-ai/dsh-host-webserver |
| packages/host/open-in-app/src/internals.ts | 7 | internals | — |
| packages/host/open-in-app/src/resolver.ts | 761 | resolveInternals, output, isDirectory, isFile, expandCandidate, parseRegistryDump, readWindowsRegistryView, parseDesktopEntry …等24项 | node:child_process, node:fs, node:os, node:path, @deepseek-ai/dsh-native-command |
| packages/host/open-in-app/src/shared.ts | 38 | OPEN_IN_APP_APPS_PATH, OPEN_IN_APP_APPS_ROUTE, OPEN_IN_APP_ICON_PREFIX_PATH, OPEN_IN_APP_ICON_PREFIX_ROUTE, OPEN_IN_APP_OPEN_PATH, OPEN_IN_APP_OPEN_ROUTE, OpenInAppAppsPayload, OpenInAppOpenPayload | — |
| packages/host/open-in-app/tsdown.config.ts | 20 | defineConfig | tsdown |

#### packages/host/plugin-inventory — @deepseek-ai/dsh-host-plugin-inventory@0.2.1-alpha.1（2 文件 / 191 行）

职责：Loader 条目只读投影（可信客户端 RPC）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/host/plugin-inventory/src/index.ts | 115 | pluginEntryId, readPluginInventory, PluginInventoryGateway | @deepseek-ai/cordis, @deepseek-ai/cordis-plugin-loader, @deepseek-ai/dsh-agent-preset-registry, @deepseek-ai/dsh-app-boot, @deepseek-ai/dsh-typert-protocol |
| packages/host/plugin-inventory/src/types.ts | 76 | PluginEntryId, PluginFiberPhase, PluginInventoryEntry, PresetPluginEnablement, AgentPresetPluginRow, AgentPresetPluginGroup, PluginInventorySnapshot | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-package-manifest |

#### packages/host/product-telemetry-otel — @deepseek-ai/dsh-host-product-telemetry-otel@0.2.1-alpha.1（1 文件 / 122 行）

职责：桌面产品遥测上报


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/host/product-telemetry-otel/src/index.ts | 122 | Config, ProductTelemetryRecord, ProductTelemetryScalar, ProductTelemetry | @deepseek-ai/cordis, @deepseek-ai/schemastery, node:http, @opentelemetry/otlp-exporter-base, @deepseek-ai/dsh-otel |

#### packages/host/webserver — @deepseek-ai/dsh-host-webserver@0.2.1-alpha.1（2 文件 / 486 行）

职责：node:http 服务（ctx.webServer）：路由/升级注册、gzip、index 注入事件


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/host/webserver/src/index.ts | 366 | WebServer, WebRouteKind, WebRoute, WebUpgradeRoute, Config | node:http, node:net, node:stream, @deepseek-ai/cordis, @deepseek-ai/schemastery |
| packages/host/webserver/src/injections.ts | 120 | renderIndexInjections, IndexInjectionPlacement, IndexInjection | — |

#### packages/identity/anonymous-user-id — @deepseek-ai/dsh-anonymous-user-id@0.2.1-alpha.1（1 文件 / 101 行）

职责：匿名身份：$DSH_HOME/.anonymous-user-id 裸 UUID（并发独占创建）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/identity/anonymous-user-id/src/index.ts | 101 | getOrCreateAnonymousUserId, ANONYMOUS_USER_ID_FILE_NAME, AnonymousUserId, AnonymousUserIdOptions | node:crypto, node:fs, node:path, @deepseek-ai/dsh-brand, @deepseek-ai/dsh-home-paths |

#### packages/interaction/commands — @deepseek-ai/dsh-commands@0.2.1-alpha.1（3 文件 / 695 行）

职责：斜杠命令注册/解析/分发（ctx.commands，不经模型 turn）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/interaction/commands/src/brand.ts | 41 | CommandDefinitionId, CommandId | @deepseek-ai/dsh-brand |
| packages/interaction/commands/src/index.ts | 534 | parseCommand, CommandRuntime, name, CommandFileReceiptResolver, CommandInvocation, CommandDefinition, ParsedCommand | @deepseek-ai/cordis, @deepseek-ai/dsh-util-crypto, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-llm |
| packages/interaction/commands/src/types.ts | 120 | CommandSubmitAttachment, CommandInputDescriptor, CommandResult, CommandExecution, CommandDescriptor, CommandSourceMap, CommandSource | @deepseek-ai/dsh-session, @deepseek-ai/dsh-attachment |

#### packages/interaction/permission-presets — @deepseek-ai/dsh-permission-presets@0.2.1-alpha.1（3 文件 / 557 行）

职责：沙箱模式+审批策略捆绑预设


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/interaction/permission-presets/src/client.ts | 11 | — | — |
| packages/interaction/permission-presets/src/index.ts | 482 | PermissionPresetService, CUSTOM_PRESET, AUTO_PRESET, PresetSpec, KnobState, PermissionSettings, Config | @deepseek-ai/dsh-settings, @deepseek-ai/cordis, @deepseek-ai/dsh-commands, @deepseek-ai/schemastery, zod |
| packages/interaction/permission-presets/src/types.ts | 64 | PresetOption, PermissionCatalog, PermissionSelection | — |

#### packages/interaction/tool-ask-user — @deepseek-ai/dsh-tool-ask-user@0.2.1-alpha.1（2 文件 / 329 行）

职责：ask_user_question 工具（legacy 阻塞/timed 两模式）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/interaction/tool-ask-user/src/index.ts | 120 | apply, Config, name, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-tools, @deepseek-ai/schemastery, @deepseek-ai/dsh-user-questions |
| packages/interaction/tool-ask-user/src/timed.ts | 209 | registerTimedAskUser | @deepseek-ai/cordis, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-user-questions |

#### packages/interaction/user-approval — @deepseek-ai/dsh-user-approval@0.2.1-alpha.1（3 文件 / 421 行）

职责：审批缝（ctx.approval）：开放 turn 内一次性询问，fail-closed


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/interaction/user-approval/src/index.ts | 311 | setApprovalPolicy, ApprovalService, APPROVAL_POLICIES, ApprovalPolicy, ApprovalRequest, Config | node:crypto, @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-llm |
| packages/interaction/user-approval/src/types.ts | 94 | ApprovalRequestId, ApprovalOutcome, ApprovalRequestEvent | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-scope, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-llm |
| packages/interaction/user-approval/tsdown.config.ts | 16 | defineConfig | tsdown |

#### packages/interaction/user-questions — @deepseek-ai/dsh-user-questions@0.2.1-alpha.1（4 文件 / 929 行）

职责：用户问答缝（ctx.userQuestions）：作用域化 waterfall + timed


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/interaction/user-questions/src/index.ts | 343 | UserQuestionError, UserQuestionService, AskUserQuestionRequest, TimedUserQuestionResult | @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session, @deepseek-ai/dsh-scope |
| packages/interaction/user-questions/src/projection.ts | 338 | isTimedAskUserQuestionSchema, questionsOf, applyUserQuestionEvent, foldUserQuestions, ASK_USER_QUESTION_TOOL, TIMED_WAIT_PARAMETER, userQuestionProjectionDefinition, UserQuestionFold …等9项 | zod, @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-projection, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-tools |
| packages/interaction/user-questions/src/timed-wait.ts | 84 | TimedQuestionWait | — |
| packages/interaction/user-questions/src/types.ts | 164 | AskUserQuestionOption, AskUserQuestionIntent, AskUserQuestionItem, AskUserQuestionAnswerItem, AskUserQuestionAnswer, UserQuestionState, PendingUserQuestion, SettledUserQuestion …等10项 | @deepseek-ai/dsh-scope, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-projection |

#### packages/jobs/jobs — @deepseek-ai/dsh-jobs@0.2.1-alpha.1（5 文件 / 630 行）

职责：后台任务契约（ctx.jobs）：owner 授权/first-wins/有界输出 ring


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/jobs/jobs/src/archive-admission.ts | 49 | installJobArchiveAdmission | @deepseek-ai/cordis, @deepseek-ai/dsh-session, @deepseek-ai/dsh-workspace |
| packages/jobs/jobs/src/brand.ts | 29 | JobId | @deepseek-ai/dsh-brand |
| packages/jobs/jobs/src/index.ts | 196 | JobRegistry | @deepseek-ai/cordis, @deepseek-ai/dsh-session |
| packages/jobs/jobs/src/types.ts | 255 | JobOutcome, JobSourceRead, JobOutputSource, JobAppendOptions, JobHandle, JobHooks, JobSpec, JobRead …等14项 | @deepseek-ai/dsh-session |
| packages/jobs/jobs/src/view.ts | 101 | JobStatus, JobKindMap, JobKind, JobChannel, JobChunk, JobView | @deepseek-ai/dsh-session, @deepseek-ai/dsh-workspace |

#### packages/jobs/jobs-local — @deepseek-ai/dsh-jobs-local@0.2.1-alpha.1（4 文件 / 1012 行）

职责：进程内任务实现（TrackedJob：ring/cursor/pump/spill）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/jobs/jobs-local/src/events.ts | 103 | JobLayer, JobEventHub | @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-scope, @deepseek-ai/dsh-jobs |
| packages/jobs/jobs-local/src/index.ts | 688 | LocalJobRegistry, TASK_WAIT_TIMEOUT, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-scope, @deepseek-ai/dsh-session |
| packages/jobs/jobs-local/src/pump.ts | 107 | startPump, PumpHandle, PumpSink | @deepseek-ai/dsh-jobs |
| packages/jobs/jobs-local/src/ring.ts | 114 | OutputRing | @deepseek-ai/dsh-jobs |

#### packages/jobs/tool-jobs — @deepseek-ai/dsh-tool-jobs@0.2.1-alpha.1（2 文件 / 501 行）

职责：job_output/job_list/job_kill 工具 + 完成通知唤醒


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/jobs/tool-jobs/src/index.ts | 416 | apply, name, inject, Config, CompletionDelivery | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-output-retention, @deepseek-ai/dsh-tools |
| packages/jobs/tool-jobs/src/render.ts | 85 | jobDetail, publicJob, statusLine, renderModelDelta, PublicJobSnapshot | @deepseek-ai/dsh-jobs |

#### packages/llm/deepseek-llm-api-extensions — @deepseek-ai/dsh-deepseek-llm-api-extensions@0.2.1-alpha.1（2 文件 / 193 行）

职责：DeepSeek wire 扩展注册表（顶层请求字段独占）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/llm/deepseek-llm-api-extensions/src/index.ts | 133 | DeepSeekLlmApiExtensionRegistry | @deepseek-ai/cordis |
| packages/llm/deepseek-llm-api-extensions/src/types.ts | 60 | DeepSeekLlmApiJson, DeepSeekLlmApiExtensionMap, DeepSeekLlmApiExtensionRequest, PreparedDeepSeekLlmApiExtension, DeepSeekLlmApiExtensionProvider, PreparedDeepSeekLlmApiExtensions | — |

#### packages/llm/llm — @deepseek-ai/dsh-llm@0.2.1-alpha.1（13 文件 / 4016 行）

职责：LLM 中立词汇表 + Runtime（ctx.llm）+ llm/stream waterfall + prepareCall


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/llm/llm/src/adapter-failure.ts | 108 | normalizeLlmFailure | — |
| packages/llm/llm/src/api-key.ts | 42 | normalizeApiKey, ApiKeyRejection, ApiKeyCheck | — |
| packages/llm/llm/src/assembler.ts | 209 | BlockAssembler | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-util-values |
| packages/llm/llm/src/assistant-stream.ts | 535 | expandAssistantStream, isTokenDelta, isVisibleChunk, chunkHasVisibleText, runFirstTokenTime, runFirstVisibleTime, assistantStreamFirstTokenTime, assistantStreamHasVisibleContent …等18项 | @deepseek-ai/dsh-util-values |
| packages/llm/llm/src/attribution.ts | 69 | userAgent, attributionHeaders, APP_IDENTITY, AppIdentity | node:module |
| packages/llm/llm/src/brand.ts | 77 | MessageId, ToolCallId, ProviderRequestId, LlmAttemptId, ReasoningEffortId | @deepseek-ai/dsh-brand |
| packages/llm/llm/src/call-config.ts | 79 | callConfigEquals, markAgentLoopRequest, isAgentLoopRequest, LlmCallConfig, LlmCallConfigAdapterDefaults | — |
| packages/llm/llm/src/content.ts | 493 | resolveImageAttachmentAccess, textOnlyImageText, requestImageHandleText, offloadedImageText, contentHasImage, contentHasFile, fileHandleText, projectFilesToText …等15项 | @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-util-values |
| packages/llm/llm/src/error.ts | 176 | isContextWindowExceededError, isQuotaExceededError, errorChain, isHarnessError, HarnessError, CONTEXT_WINDOW_EXCEEDED_CODE, QUOTA_EXCEEDED_CODE, ACCOUNT_QUOTA_EXCEEDED_CODE …等11项 | — |
| packages/llm/llm/src/index.ts | 1170 | assertUsableApiKey, LlmError, LlmAdapter, LlmRuntime, LlmErrorOptions, PreparedLlmCall, PreparedAdapterCall, AdapterRegistrationHandle …等9项 | @deepseek-ai/cordis, @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-util-values, @deepseek-ai/dsh-attachment |
| packages/llm/llm/src/message.ts | 308 | boundContextSummary, freezeMessage, createMessage, createDeveloperMessage, createUserMessage, createAssistantMessage, createSystemMessage, createToolResultMessage …等26项 | @deepseek-ai/dsh-util-crypto, @deepseek-ai/dsh-brand, @deepseek-ai/dsh-util-values |
| packages/llm/llm/src/retry-policy.ts | 196 | resolveRetryPolicy, RetryPolicySchema, BackoffConfig, NormalRetryPolicyConfig, AlwaysRetryPolicyConfig, RetryPolicyConfig, ResolvedRetryBackoff, ResolvedNormalRetryPolicy …等10项 | @deepseek-ai/schemastery, @deepseek-ai/dsh-timeout |
| packages/llm/llm/src/types.ts | 554 | LlmFailure, TextBlock, ReasoningBlock, ImageBlock, FileBlock, ToolCallBlock, ToolAdditionBlock, ToolRemovalBlock …等38项 | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-attachment |

#### packages/llm/llm-deepseek — @deepseek-ai/dsh-llm-deepseek@0.2.1-alpha.1（24 文件 / 2830 行）

职责：官方 DeepSeek 适配器：SSE 翻译/Files API/thinking 重放/空闲看门狗


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/llm/llm-deepseek/src/adapter.ts | 161 | DeepSeekAdapter | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-deepseek-llm-api-extensions, @deepseek-ai/dsh-timeout |
| packages/llm/llm-deepseek/src/config.ts | 320 | plainOptions, resolveAdapterOptions, deepSeekConfigFields, Config, PUBLIC_BASE_URL, Options, ResolvedDeepSeekOptions | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/cosmokit, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-launch-environment |
| packages/llm/llm-deepseek/src/defaults.ts | 25 | DEFAULT_STREAM_IDLE_TIMEOUT_MS, DEFAULT_CONTEXT_WINDOW, DEFAULT_MAX_TOKENS, DEFAULT_MAX_INLINE_REQUEST_IMAGE_BYTES, DEFAULT_IMAGE_OFFLOAD_BYTE_QUANTUM, DEFAULT_INLINE_IMAGE_OFFLOAD_BYTE_QUANTUM, DEFAULT_IMAGE_OFFLOAD_COUNT_QUANTUM, DEFAULT_FILE_EXPIRY_SECONDS …等11项 | — |
| packages/llm/llm-deepseek/src/file-id.ts | 28 | DeepSeekFileId, DeepSeekFileScope | @deepseek-ai/dsh-brand |
| packages/llm/llm-deepseek/src/file-store.ts | 337 | DeepSeekFileStore, MAX_IMAGE_BYTES, DeepSeekFilePolicy, DeepSeekFileConnection, DeepSeekFileReference | @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-llm |
| packages/llm/llm-deepseek/src/files-api.ts | 263 | isFilesQuotaError, DeepSeekFilesError, DeepSeekFilesClient, MIN_FILE_EXPIRY_SECONDS, MAX_FILE_EXPIRY_SECONDS, MAX_FILE_UPLOAD_BYTES, MAX_STORED_FILE_COUNT, MAX_STORED_FILE_BYTES …等10项 | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-attachment |
| packages/llm/llm-deepseek/src/host.ts | 50 | registerDeepSeekProvider | @deepseek-ai/cordis, @deepseek-ai/dsh-settings, @deepseek-ai/cordis-plugin-loader, @deepseek-ai/dsh-fs, @deepseek-ai/dsh-llm |
| packages/llm/llm-deepseek/src/image-tokens.ts | 158 | deepSeekRequestImageDimensions, deepSeekImageTokens | @deepseek-ai/dsh-attachment |
| packages/llm/llm-deepseek/src/images.ts | 112 | prepareImages, inlineImages, prepareFileIds | @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-llm |
| packages/llm/llm-deepseek/src/index.ts | 42 | — | — |
| packages/llm/llm-deepseek/src/messages-api.ts | 18 | messagesApiRoot, MESSAGES_FILES_BETA, MESSAGES_TOOL_CHANGES_BETA | — |
| packages/llm/llm-deepseek/src/model-info.ts | 101 | catalogModelInfo, modelInfo | @deepseek-ai/dsh-llm |
| packages/llm/llm-deepseek/src/models.ts | 22 | DEFAULT_MODELS | — |
| packages/llm/llm-deepseek/src/replay.ts | 65 | object, replayState, readReplay, ReplayBlock | @deepseek-ai/dsh-llm |
| packages/llm/llm-deepseek/src/request-extensions.ts | 56 | prepareRequestExtensions | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-deepseek-llm-api-extensions |
| packages/llm/llm-deepseek/src/request-files.ts | 159 | FileResolutionFailure, RequestFiles, ImageWireLocation | @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-timeout |
| packages/llm/llm-deepseek/src/request-pricing.ts | 112 | resolveRequestImageMaxBytes, resolveRequestImageTarget, deepSeekImageRequestPricing, DEFAULT_MAX_REQUEST_FILES_BYTES, DEFAULT_MAX_IMAGES_PER_REQUEST, DEFAULT_LOW_DETAIL_IMAGE_PIXEL_BUDGET, DEFAULT_REQUEST_IMAGE_MAX_BYTES, REQUEST_IMAGE_MAX_DIMENSION | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-attachment |
| packages/llm/llm-deepseek/src/serialize.ts | 169 | serialize | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-attachment |
| packages/llm/llm-deepseek/src/sse.ts | 29 | parseSse | eventsource-parser, @deepseek-ai/dsh-llm |
| packages/llm/llm-deepseek/src/translate.ts | 167 | string, translate | @deepseek-ai/dsh-llm |
| packages/llm/llm-deepseek/src/transport.ts | 45 | providerErrorDetail, providerError | @deepseek-ai/dsh-llm |
| packages/llm/llm-deepseek/src/types.ts | 124 | DeepSeekCatalogModel, DeepSeekConnectionOptions, DeepSeekRequestAuth, DeepSeekAdapterOptions, RequestDefaults | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-anonymous-user-id, @deepseek-ai/dsh-deepseek-llm-api-extensions |
| packages/llm/llm-deepseek/src/upload-index.ts | 225 | deepSeekFileScope, DeepSeekUploadIndex, DeepSeekUploadRecord, UploadIndexCommit | node:crypto, node:fs, node:path, @deepseek-ai/dsh-atomic-write, @deepseek-ai/dsh-home-paths |
| packages/llm/llm-deepseek/src/wire-types.ts | 42 | WireInput, WireBlock, WireMessage, WireRequest | — |

#### packages/llm/llm-deepseek-account — @deepseek-ai/dsh-llm-deepseek-account@0.2.1-alpha.1（2 文件 / 62 行）

职责：平台账号凭据源


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/llm/llm-deepseek-account/src/config.ts | 7 | Config | @deepseek-ai/dsh-llm-deepseek |
| packages/llm/llm-deepseek-account/src/index.ts | 55 | apply, name, inject | @deepseek-ai/cordis-plugin-loader, @deepseek-ai/cordis, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-deepseek-account, @deepseek-ai/dsh-launch-environment |

#### packages/llm/llm-deepseek-api-key — @deepseek-ai/dsh-llm-deepseek-api-key@0.2.1-alpha.1（2 文件 / 88 行）

职责：API key 凭据源


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/llm/llm-deepseek-api-key/src/config.ts | 40 | plainOptions, resolveAdapterOptions, Config, Options, ResolvedDeepSeekOptions | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-credentials, @deepseek-ai/dsh-launch-environment, @deepseek-ai/dsh-llm-deepseek |
| packages/llm/llm-deepseek-api-key/src/index.ts | 48 | apply, name, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-llm, @deepseek-ai/cordis-plugin-loader, @deepseek-ai/dsh-launch-environment, @deepseek-ai/dsh-llm-deepseek |

#### packages/llm/llm-pi-ai — @deepseek-ai/dsh-llm-pi-ai@0.2.1-alpha.1（12 文件 / 4078 行）

职责：pi-ai 库多 provider 适配器


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/llm/llm-pi-ai/src/adapter.ts | 426 | PiAiAdapter, PiAiAdapterOptions, PiAiAuthInjection | @earendil-works/pi-ai, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-timeout |
| packages/llm/llm-pi-ai/src/auth.ts | 232 | recordKeyFor, credentialStoreFrom, authContextFrom, RECORD_SCOPE | node:os, node:fs, node:path, @earendil-works/pi-ai, @deepseek-ai/cordis |
| packages/llm/llm-pi-ai/src/catalog.ts | 971 | catalogProvider, catalogProviderIds, catalogModels, resolveRouteModels, PiAiCatalogError, MODALITIES, THINKING_LEVELS, SUPPORTED_THINKING_FORMATS …等27项 | @earendil-works/pi-ai |
| packages/llm/llm-pi-ai/src/config.ts | 511 | assertServiceable, resolveProfiles, DEFAULT_STREAM_IDLE_TIMEOUT_MS, DEFAULT_MAX_REQUEST_IMAGE_BYTES, DEFAULT_REQUEST_IMAGE_PIXEL_BUDGET, DEFAULT_REQUEST_IMAGE_MAX_BYTES, DEFAULT_CONTEXT_WINDOW, DEFAULT_MAX_TOKENS …等13项 | @deepseek-ai/cordis, @earendil-works/pi-ai, @deepseek-ai/schemastery, @deepseek-ai/dsh-credentials, @deepseek-ai/dsh-timeout |
| packages/llm/llm-pi-ai/src/context.ts | 340 | toPiContext, PiImageRequestContext, PiImageRequestBudget | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-attachment, @earendil-works/pi-ai |
| packages/llm/llm-pi-ai/src/discovery.ts | 364 | discoverModels, StoredModelDiscoveryProfile | @deepseek-ai/dsh-llm |
| packages/llm/llm-pi-ai/src/index.ts | 318 | apply, name, inject | @deepseek-ai/dsh-settings, @deepseek-ai/cordis-plugin-loader, @deepseek-ai/cordis, @deepseek-ai/dsh-launch-environment, @deepseek-ai/dsh-llm |
| packages/llm/llm-pi-ai/src/login.ts | 162 | registerPiAiFlows | @earendil-works/pi-ai, @deepseek-ai/cordis, @deepseek-ai/dsh-authorization, @deepseek-ai/dsh-credentials |
| packages/llm/llm-pi-ai/src/models.ts | 68 | createModels, createProvider, getSupportedThinkingLevels | @earendil-works/pi-ai |
| packages/llm/llm-pi-ai/src/provider.ts | 193 | supportedProtocols, buildProvider, ProviderSpec | @earendil-works/pi-ai |
| packages/llm/llm-pi-ai/src/replay.ts | 258 | toPiReplayState, toPiAssistant, PiAiReplayBlock, PiAiReplayResponse | @deepseek-ai/dsh-llm, @earendil-works/pi-ai |
| packages/llm/llm-pi-ai/src/stream.ts | 235 | mapUsage, mapStopReason, toStreamChunks | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-llm, @earendil-works/pi-ai |

#### packages/llm/llm-retry — @deepseek-ai/dsh-llm-retry@0.2.1-alpha.1（4 文件 / 339 行）

职责：请求错误重试 waterfall


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/llm/llm-retry/src/brand.ts | 14 | RetryId | @deepseek-ai/dsh-brand |
| packages/llm/llm-retry/src/index.ts | 260 | apply, name, inject, Config, RetryInternals | node:crypto, @deepseek-ai/cordis, @deepseek-ai/schemastery, zod, @deepseek-ai/dsh-agent |
| packages/llm/llm-retry/src/types.ts | 49 | LlmRetryEventData, LlmRetryStartedEventData | @deepseek-ai/dsh-llm |
| packages/llm/llm-retry/tsdown.config.ts | 16 | defineConfig | tsdown |

#### packages/llm/plugin-package-inventory-deepseek — @deepseek-ai/dsh-plugin-package-inventory-deepseek@0.2.1-alpha.1（2 文件 / 225 行）

职责：DeepSeek 模型能力清单


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/llm/plugin-package-inventory-deepseek/src/index.ts | 205 | apply, name, inject, Config | node:fs, node:module, node:path, node:url, @deepseek-ai/cordis |
| packages/llm/plugin-package-inventory-deepseek/src/types.ts | 20 | DeepSeekPluginPackageIdentity, DeepSeekPluginPackageInventoryExtension | — |

#### packages/llm/token-meter — @deepseek-ai/dsh-token-meter@0.2.1-alpha.1（11 文件 / 1482 行）

职责：token 计量（surface token 表，供压缩决策）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/llm/token-meter/src/breakdown-projection.ts | 82 | contextBreakdownProjectionDefinition | zod, @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-projection |
| packages/llm/token-meter/src/client.ts | 10 | — | — |
| packages/llm/token-meter/src/estimate.ts | 103 | estimateStructuralBlock, estimateContent, estimateSystemMessage, estimateMessage, estimateToolsTokens, ROLE_OVERHEAD | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session |
| packages/llm/token-meter/src/index.ts | 343 | TokenMeter | @deepseek-ai/cordis, @deepseek-ai/dsh-compaction-image-offload, @deepseek-ai/schemastery, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-util-values |
| packages/llm/token-meter/src/projection.ts | 78 | TokenUsageProjection, ContextPressureProjection, ContextBreakdownProjection | — |
| packages/llm/token-meter/src/route-pricing.ts | 77 | priceSurface, PricedSurface | @deepseek-ai/dsh-llm |
| packages/llm/token-meter/src/surface-fold.ts | 143 | planSurfaceTokens, commitSurfaceTokens, MeterSurfaceNode, SurfaceTokenPlan | @deepseek-ai/dsh-session, @deepseek-ai/dsh-llm |
| packages/llm/token-meter/src/surface-projection.ts | 97 | foldSurfaceProjection, ShadowPriceClaim, SurfaceTokensFold | @deepseek-ai/dsh-session, @deepseek-ai/dsh-compaction |
| packages/llm/token-meter/src/turn-usage.ts | 275 | deriveTurnTokenUsage, TurnTokenUsageRoute, TurnTokenUsage | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-llm-retry, @deepseek-ai/dsh-session |
| packages/llm/token-meter/src/types.ts | 55 | TokenMeterConfig, TokenMeasurementBaseline, TokenMeasurement, TokenSurfaceNode | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session |
| packages/llm/token-meter/src/usage-projection.ts | 219 | tokenUsageProjectionDefinition, contextPressureProjectionDefinition | zod, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-llm-retry, @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-projection |

#### packages/lsp/lsp — @deepseek-ai/dsh-lsp@0.2.1-alpha.1（3 文件 / 312 行）

职责：语言服务器 Service Definition（ctx.lsp）：扩展名路由四操作


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/lsp/lsp/src/brand.ts | 22 | LspProviderId | @deepseek-ai/dsh-brand |
| packages/lsp/lsp/src/index.ts | 159 | finalExtension, LspError, Lsp | @deepseek-ai/cordis, @deepseek-ai/dsh-llm |
| packages/lsp/lsp/src/types.ts | 131 | LspOperation, LspPosition, LspRange, LspQueryRequest, LspProviderQuery, LspLocation, LspHover, LspQueryResult …等10项 | — |

#### packages/lsp/lsp-stdio — @deepseek-ai/dsh-lsp-stdio@0.2.1-alpha.1（8 文件 / 1651 行）

职责：通用 stdio LSP provider：懒启动单飞实例


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/lsp/lsp-stdio/src/abort.ts | 49 | abortError, throwIfAborted, abortable | @deepseek-ai/dsh-timeout |
| packages/lsp/lsp-stdio/src/connection.ts | 324 | LspConnection, ConnectionSpec, ConnectionWriter, ConnectionSpawner | node:stream, @deepseek-ai/dsh-subprocess |
| packages/lsp/lsp-stdio/src/framing.ts | 103 | encodeMessage, MessageDecoder | — |
| packages/lsp/lsp-stdio/src/host.ts | 125 | canonicalizeWorkspace, readHostSource, HostWorkspace, HostSource | node:buffer, @deepseek-ai/dsh-fs |
| packages/lsp/lsp-stdio/src/index.ts | 382 | apply, name, inject, Config, LspLocalServerConfig | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-lsp, @deepseek-ai/dsh-timeout |
| packages/lsp/lsp-stdio/src/instance.ts | 351 | LspInstance, InstanceSpec | @deepseek-ai/dsh-lsp, @deepseek-ai/dsh-timeout |
| packages/lsp/lsp-stdio/src/protocol.ts | 81 | WirePosition, WireRange, WireLocation, WireLocationLink, WireMarkupContent, WireMarkedStringObject, WireMarkedString, WireHover …等13项 | — |
| packages/lsp/lsp-stdio/src/translate.ts | 236 | requestMethod, supportsOperation, supportsTransientOpen, negotiatePositionEncoding, normalizeLocations, normalizeHover | @deepseek-ai/dsh-lsp, @deepseek-ai/dsh-util-values |

#### packages/lsp/tool-lsp — @deepseek-ai/dsh-tool-lsp@0.2.1-alpha.1（3 文件 / 457 行）

职责：模型侧 LSP 查询工具


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/lsp/tool-lsp/src/index.ts | 247 | apply, name, inject, DEFAULT_LSP_TOOL_TIMEOUT_MS, LSP_PROMPT_TEXT, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-lsp, @deepseek-ai/dsh-timeout |
| packages/lsp/tool-lsp/src/render.ts | 192 | parseLspArgs, formatLocations, formatHover, renderUri, presentLspCall, LSP_OPERATIONS, DEFAULT_MAX_LOCATIONS, DEFAULT_MAX_RESULT_CHARS …等10项 | @deepseek-ai/dsh-tools, @deepseek-ai/dsh-lsp, node:path, node:url |
| packages/lsp/tool-lsp/src/session-cwd.ts | 18 | sessionCwd | @deepseek-ai/dsh-tools |

#### packages/mcp/mcp-client — @deepseek-ai/dsh-mcp-client@0.2.1-alpha.1（5 文件 / 1214 行）

职责：MCP 客户端：连接监督 + mcp__server__tool 工具桥（两阶段同步）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/mcp/mcp-client/src/connection.ts | 410 | resolveReconnectPolicy, startConnection, RECONNECT_DEFAULTS, DEFAULT_MAX_INSTRUCTION_BYTES, ReconnectConfig, ResolvedReconnectPolicy, ConnectionOutcome, ConnectionHandle | @modelcontextprotocol/client, @deepseek-ai/cordis, @deepseek-ai/dsh-util-values, @deepseek-ai/dsh-timeout |
| packages/mcp/mcp-client/src/index.ts | 204 | apply, name, inject, Config, StdioConfig, StreamableHttpConfig | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-scope, @deepseek-ai/dsh-timeout, @deepseek-ai/dsh-tools |
| packages/mcp/mcp-client/src/server-context.ts | 41 | registerServerContext, ServerContext | @deepseek-ai/cordis, @deepseek-ai/dsh-mcp-resources, @deepseek-ai/dsh-system-prompt |
| packages/mcp/mcp-client/src/tools.ts | 512 | publicToolName, syncTools, createMcpToolDefinition, ToolBridgeOptions, ToolDisposers, McpResult, McpToolDefinitionOptions | node:crypto, node:util, @modelcontextprotocol/client, @deepseek-ai/cordis, @deepseek-ai/dsh-attachment |
| packages/mcp/mcp-client/src/transport.ts | 47 | createTransport | @modelcontextprotocol/client, @deepseek-ai/dsh-subprocess |

#### packages/mcp/mcp-resources — @deepseek-ai/dsh-mcp-resources@0.2.1-alpha.1（3 文件 / 220 行）

职责：MCP 资源三工具（list/templates/read）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/mcp/mcp-resources/src/index.ts | 130 | McpResourceRuntime, McpResourceRequest, McpResourceProvider | @deepseek-ai/cordis, @deepseek-ai/dsh-scope, @deepseek-ai/dsh-util-values, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-system-prompt |
| packages/mcp/mcp-resources/src/render.ts | 25 | renderResourceResult | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-util-values |
| packages/mcp/mcp-resources/src/tools.ts | 65 | registerResourceTools | @deepseek-ai/cordis, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-util-values |

#### packages/plan/plan-mode — @deepseek-ai/dsh-plan-mode@0.2.1-alpha.1（3 文件 / 530 行）

职责：Logged planning（ctx.planMode）：plan/mode 事件 + exit_plan_mode 审查


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/plan/plan-mode/src/client.ts | 11 | — | — |
| packages/plan/plan-mode/src/index.ts | 471 | resolveConfig, PlanModeController, EXIT_PLAN_MODE, planProjectionDefinition, PlanModeConfig | @deepseek-ai/cordis, @deepseek-ai/dsh-brand, zod, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-llm |
| packages/plan/plan-mode/src/types.ts | 48 | PlanProjection, PlanUnitState | @deepseek-ai/dsh-commands |

#### packages/preset/agent-preset — @local/my-decoration@1.0.0（3 文件 / 57 行）

职责：出厂 preset 插件集合 + cordis 插件开发 SKILL 模板（示例包名 @local/my-decoration）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/preset/agent-preset/skills/cordis-plugin-development/templates/decoration/client.js | 23 | — | react |
| packages/preset/agent-preset/skills/cordis-plugin-development/templates/decoration/index.js | 3 | apply | — |
| packages/preset/agent-preset/src/index.ts | 31 | Config, AgentPreset | @deepseek-ai/cordis, @deepseek-ai/cordis-plugin-loader, @deepseek-ai/schemastery, @deepseek-ai/dsh-agent-preset-registry |

#### packages/preset/agent-preset-registry — @deepseek-ai/dsh-agent-preset-registry@0.2.1-alpha.1（8 文件 / 1070 行）

职责：preset 注册/激活（ctx.agentPresets）：preset 作用域装载 + 会话绑定


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/preset/agent-preset-registry/src/composition-inventory.ts | 206 | activeCompositionModules, definitionComposition, mountedCompositionRows, CompositionRowEnablement, DisabledExpressionEvaluator, AgentPresetCompositionRow, AgentPresetComposition, AgentPresetInspection | @deepseek-ai/cordis, @deepseek-ai/cordis-plugin-loader |
| packages/preset/agent-preset-registry/src/definition.ts | 40 | entryListProblem, PresetDefinition | @deepseek-ai/cordis-plugin-loader |
| packages/preset/agent-preset-registry/src/display.ts | 74 | isBuiltInPreset, presetDisplayText, BuiltInPresetCopyKey, PresetDisplaySource, PresetDisplayText | — |
| packages/preset/agent-preset-registry/src/index.ts | 395 | AgentPresetRegistry | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-scope, @deepseek-ai/cordis-plugin-include |
| packages/preset/agent-preset-registry/src/mount.ts | 217 | leakedServices, serviceForMount, auditRows, mountPreset, PresetMount, RowAudit | @deepseek-ai/cordis, @deepseek-ai/cordis-plugin-loader, @deepseek-ai/dsh-app-boot, @deepseek-ai/dsh-scope |
| packages/preset/agent-preset-registry/src/preset.ts | 19 | AgentPreset, Config | @deepseek-ai/cordis |
| packages/preset/agent-preset-registry/src/session.ts | 45 | agentPresetProjectionDefinition | @deepseek-ai/dsh-session-projection, zod |
| packages/preset/agent-preset-registry/src/types.ts | 74 | AgentPresetRow, AgentPresetRoster, AgentPresetDocument | @deepseek-ai/dsh-session |

#### packages/preset/persona — @deepseek-ai/dsh-persona@0.2.1-alpha.1（1 文件 / 76 行）

职责：persona 模板包


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/preset/persona/src/index.ts | 76 | apply, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-system-prompt |

#### packages/ptc-runtime/ptc-runtime — @deepseek-ai/dsh-ptc-runtime@0.2.1-alpha.1（2 文件 / 317 行）

职责：PTC 执行 Service Definition（ctx.ptcRuntime）+ 跨后端保留名契约


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/ptc-runtime/ptc-runtime/src/index.ts | 154 | PtcRuntime, RESERVED_BINDING_GLOBALS, RESERVED_ERROR_MEMBERS, DUNDER_MEMBER, PORTABLE_RESERVED_WORDS | @deepseek-ai/cordis, @deepseek-ai/dsh-sandbox |
| packages/ptc-runtime/ptc-runtime/src/types.ts | 163 | PtcBindingFunction, PtcJsonValue, PtcBindingErrorClass, PtcBindingNamespace, PtcRunRequest, PtcRunSpec, PtcRunSandbox, PtcRunFailure …等9项 | @deepseek-ai/dsh-sandbox |

#### packages/ptc-runtime/ptc-runtime-node — @deepseek-ai/dsh-ptc-runtime-node@0.2.1-alpha.1（14 文件 / 1889 行）

职责：Node worker-thread PTC 实现（launch/process/json-wire/output-ledger）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/ptc-runtime/ptc-runtime-node/src/bindings.ts | 52 | validateBindings | @deepseek-ai/dsh-ptc-runtime |
| packages/ptc-runtime/ptc-runtime-node/src/bootstrap.ts | 423 | makeConsoleShim, captureStreamWrites, prepareCompletion, prepareException, makeBindingErrorClasses, wireReplies, makeNamespaces, runProgram …等13项 | node:util |
| packages/ptc-runtime/ptc-runtime-node/src/channel.ts | 141 | JsonChannel | node:buffer, node:stream, @deepseek-ai/dsh-ptc-runtime |
| packages/ptc-runtime/ptc-runtime-node/src/environment.ts | 5 | STARTUP_ENVIRONMENT_NAMES | — |
| packages/ptc-runtime/ptc-runtime-node/src/index.ts | 358 | NodePtcRuntime, Config | node:module, node:path, @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-ptc-runtime |
| packages/ptc-runtime/ptc-runtime-node/src/json-wire.ts | 421 | snapshotPtcJsonValue, encodePtcJsonWire, decodePtcJsonWire, PtcJsonWire | @deepseek-ai/dsh-ptc-runtime |
| packages/ptc-runtime/ptc-runtime-node/src/launch.ts | 39 | bootstrapArgs, LaunchConfig | node:path, node:url, @deepseek-ai/dsh-fs |
| packages/ptc-runtime/ptc-runtime-node/src/output-json.ts | 180 | jsonStringBytesUpTo, jsonValueBytesUpTo, truncateJsonStringBytes | @deepseek-ai/dsh-ptc-runtime |
| packages/ptc-runtime/ptc-runtime-node/src/output-ledger.ts | 67 | OutputLedger | @deepseek-ai/dsh-ptc-runtime |
| packages/ptc-runtime/ptc-runtime-node/src/output-stream.ts | 30 | drainOutput | node:stream |
| packages/ptc-runtime/ptc-runtime-node/src/process-entry.ts | 6 | — | @deepseek-ai/dsh-subprocess |
| packages/ptc-runtime/ptc-runtime-node/src/process.ts | 91 | runNodeMain, ProgramProcess | node:stream |
| packages/ptc-runtime/ptc-runtime-node/src/protocol.ts | 68 | ProgramBootData, DoneMessage, ProgramToHost, ReplyMessage | — |
| packages/ptc-runtime/ptc-runtime-node/tsdown.config.ts | 8 | defineConfig | tsdown |

#### packages/sandbox/sandbox — @deepseek-ai/dsh-sandbox@0.2.1-alpha.1（4 文件 / 549 行）

职责：进程围栏缝（ctx.sandbox.confine）：argv 包裹，fail-closed


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/sandbox/sandbox/src/diagnostics.ts | 101 | isRunnerSpawnFailure, classifyRunnerFailure, matchesSignature | node:fs |
| packages/sandbox/sandbox/src/escalation.ts | 209 | validateEscalationArgs, sandboxDenialMarker, escalationHintMarker, sandboxPermissionsDescription, approveEscalation, WIDER_MODES, ESCALATION_TARGETS, EscalationOutcome …等11项 | @deepseek-ai/dsh-util-values |
| packages/sandbox/sandbox/src/index.ts | 183 | SandboxUnavailableError, SandboxProvider, SANDBOX_UNAVAILABLE, SandboxMode, ConfinedSandboxMode, SandboxExecutionPolicy, SandboxEnforcement, SandboxPolicy …等10项 | @deepseek-ai/cordis, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session |
| packages/sandbox/sandbox/src/roots.ts | 56 | canonicalPath, writableRoots | node:fs, node:os |

#### packages/sandbox/sandbox-local — @deepseek-ai/dsh-sandbox-local@0.2.1-alpha.1（2 文件 / 643 行）

职责：平台链选择：bwrap/landlock/seatbelt/windows-acl


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/sandbox/sandbox-local/src/index.ts | 584 | LocalSandboxProvider, Config, SandboxInternals | node:child_process, node:fs, node:os, node:path, node:url |
| packages/sandbox/sandbox-local/src/profiles.ts | 59 | bwrapProfileArgs, landlockProfileArgs, seatbeltProfileArgs | @deepseek-ai/node-addon-system, @deepseek-ai/dsh-sandbox |

#### packages/sandbox/sandbox-policy — @deepseek-ai/dsh-sandbox-policy@0.2.1-alpha.1（3 文件 / 256 行）

职责：策略之家（ctx.sandboxPolicy）：唯一策略源 + 共享升级编舞


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/sandbox/sandbox-policy/src/index.ts | 184 | SandboxPolicyService, Config, SandboxPolicyRequest | node:path, @deepseek-ai/cordis, zod, @deepseek-ai/schemastery, @deepseek-ai/dsh-agent |
| packages/sandbox/sandbox-policy/src/session-mode.ts | 56 | setSandboxMode, SANDBOX_MODES | @deepseek-ai/dsh-session, @deepseek-ai/dsh-sandbox |
| packages/sandbox/sandbox-policy/tsdown.config.ts | 16 | defineConfig | tsdown |

#### packages/sandbox/sandbox-windows-acl — @deepseek-ai/dsh-sandbox-windows-acl@0.2.1-alpha.1（12 文件 / 2211 行）

职责：Windows 受限 token+DACL 实现（workspace ACE+会话私有 temp）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/sandbox/sandbox-windows-acl/src/acl-skill.ts | 77 | registerAclDiagnosisSkill, ACL_DIAGNOSIS_SKILL | node:fs, node:os, node:path, node:url, @deepseek-ai/cordis |
| packages/sandbox/sandbox-windows-acl/src/acl.ts | 449 | buildExplicitAccess, lockFilePath, withPathLock, buildLowLabelAcl, grantWrite, revokeWrite | node:crypto, node:fs, node:path |
| packages/sandbox/sandbox-windows-acl/src/ffi.ts | 315 | isInvalidHandle, encodeUint32, ptrAddress, allocBytes, allocOverlapped, decodePtrAt, decodeUint8At, decodeUint16At …等14项 | @deepseek-ai/dsh-lazy-require, @deepseek-ai/dsh-win32-process, koffi |
| packages/sandbox/sandbox-windows-acl/src/grant.ts | 142 | AclWriteGrant | — |
| packages/sandbox/sandbox-windows-acl/src/index.ts | 448 | AclSandbox, AclSandboxOptions, AclSandboxSpawnOptions, AclSandboxChildResult, AclSandboxChild | node:fs, node:path, @deepseek-ai/dsh-win32-process |
| packages/sandbox/sandbox-windows-acl/src/path-boundary.ts | 41 | assertTempRootOutsideWorkspace, assertPrivateTempDisjoint | node:fs, node:path |
| packages/sandbox/sandbox-windows-acl/src/runner.ts | 230 | — | @deepseek-ai/dsh-subprocess, node:fs, node:path |
| packages/sandbox/sandbox-windows-acl/src/spawn.ts | 61 | spawnSandboxed, spawnSandboxedInherited, waitForExit, SpawnedNative, SpawnedInherited | @deepseek-ai/dsh-win32-process |
| packages/sandbox/sandbox-windows-acl/src/token.ts | 244 | openCurrentProcessToken, findLogonSid, makeWellKnownSid, setTokenDefaultDaclGrant, restrictTokenIntegrity, createRestrictedToken, RestrictingSidSet | — |
| packages/sandbox/sandbox-windows-acl/src/win32-abi.ts | 132 | PROCESS_QUERY_INFORMATION, TOKEN_ASSIGN_PRIMARY, TOKEN_DUPLICATE, TOKEN_QUERY, TOKEN_ADJUST_DEFAULT, SE_GROUP_LOGON_ID, STANDARD_RIGHTS_WRITE, FILE_GENERIC_WRITE …等60项 | — |
| packages/sandbox/sandbox-windows-acl/src/workspace-sid.ts | 55 | workspaceWriteSid, tempWriteSid | node:crypto |
| packages/sandbox/sandbox-windows-acl/tsdown.config.ts | 17 | defineConfig | tsdown |

#### packages/schedule/schedule — @deepseek-ai/dsh-schedule@0.2.1-alpha.1（9 文件 / 3355 行）

职责：定时 follow-up（ctx.schedule）：持久域 + 六种 selector + 合并批次驱动


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/schedule/schedule/src/client.ts | 3 | — | — |
| packages/schedule/schedule/src/delivery-history.ts | 78 | appendDelivery, deliveryHistoryPage | — |
| packages/schedule/schedule/src/domain.ts | 1897 | ScheduleId, scheduleTitle, decodeStoredTitle, canonicalizeTimeZone, weeklyTime, normalizeWeekdays, decodeScheduleRecord, decodeScheduleChange …等40项 | @js-temporal/polyfill, @deepseek-ai/dsh-session |
| packages/schedule/schedule/src/index.ts | 472 | ScheduleService, Config | node:crypto, @deepseek-ai/schemastery, @deepseek-ai/cordis, @deepseek-ai/dsh-typert-protocol, @deepseek-ai/dsh-storage-domain |
| packages/schedule/schedule/src/runtime.ts | 167 | ScheduleRuntime, MAX_TIMER_DELAY_MS | @deepseek-ai/dsh-llm, @deepseek-ai/cordis, @deepseek-ai/dsh-api-session-controller |
| packages/schedule/schedule/src/storage.ts | 61 | scheduleTaskSchema, scheduleDomain, ScheduleTask | zod, @deepseek-ai/dsh-session, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-storage-domain |
| packages/schedule/schedule/src/types.ts | 481 | ScheduleId, AfterScheduleRecord, AtScheduleRecord, EveryScheduleRecord, DailyScheduleRecord, WeeklyScheduleRecord, CronScheduleRecord, DailyInput …等57项 | @deepseek-ai/dsh-session, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-brand, @deepseek-ai/dsh-workspace |
| packages/schedule/schedule/src/update.ts | 180 | retainedTitle, resolveScheduleUpdate | node:util |
| packages/schedule/schedule/tsdown.config.ts | 16 | defineConfig | tsdown |

#### packages/schedule/tool-schedule — @deepseek-ai/dsh-tool-schedule@0.2.1-alpha.1（1 文件 / 583 行）

职责：schedule_create/list/delete/update 工具


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/schedule/tool-schedule/src/index.ts | 583 | apply, name, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-subagent, @deepseek-ai/dsh-tools |

#### packages/sdk/client — @deepseek-ai/dsh-sdk-client@0.2.1-alpha.1（6 文件 / 1176 行）

职责：TS SDK 客户端：拉起 dsh --profile sdk 子进程 + 类型化调用


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/sdk/client/src/api.ts | 311 | createProcessDeepSeekHarness, normalizeInput, finalResponse, DeepSeekHarness, HarnessSession, RunOptions | node:crypto, node:path, @deepseek-ai/dsh-session |
| packages/sdk/client/src/client.ts | 492 | createProcessHarnessClient, isRecord, TransportClosedError, RequestTimeoutError, SdkProtocolError, HarnessClient, NotificationSubscription | node:child_process, @deepseek-ai/dsh-sdk-protocol |
| packages/sdk/client/src/dispose.ts | 100 | disposeRuntimeProcess | node:child_process |
| packages/sdk/client/src/index.ts | 31 | — | @deepseek-ai/dsh-sdk-protocol |
| packages/sdk/client/src/launch.ts | 158 | resolveDshBinFromManifests, installedDshBin, resolveDshNodeLaunchFromManifests, resolveDshLaunch, DEFAULT_INITIALIZE_TIMEOUT_MS, RuntimeProcessOptions, DshNodeLaunch | node:fs, node:path, node:url |
| packages/sdk/client/src/types.ts | 84 | HarnessNotification, NotificationFilter, HarnessClientOptions, DeepSeekHarnessOptions, RunResult | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-sdk-protocol, @deepseek-ai/dsh-session |

#### packages/sdk/protocol — @deepseek-ai/dsh-sdk-protocol@0.2.1-alpha.1（3 文件 / 428 行）

职责：SDK JSON-RPC 协议类型 + transport peer


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/sdk/protocol/src/index.ts | 28 | — | — |
| packages/sdk/protocol/src/transport.ts | 280 | JsonRpcResponseError, JsonRpcLineTransport, JsonRpcTransportPeer | node:crypto, node:stream, node:string_decoder |
| packages/sdk/protocol/src/types.ts | 120 | InitializeParams, InitializeResult, SessionPromptParams, SdkEncodedImageBlock, SdkPromptContentBlock, SessionPromptResult, SdkRunStatus, SessionEventNotification …等13项 | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session, @deepseek-ai/dsh-subagent |

#### packages/sdk/server — @deepseek-ai/dsh-sdk-jsonrpc-server@0.2.1-alpha.1（2 文件 / 403 行）

职责：SDK stdio 服务端：事件通知转发/initialize/prompt/shutdown


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/sdk/server/src/index.ts | 103 | apply, name, inject, Config, JsonRpcConfig | @deepseek-ai/cordis, node:stream, @deepseek-ai/schemastery, @deepseek-ai/dsh-sdk-protocol |
| packages/sdk/server/src/server.ts | 300 | HarnessSdkJsonRpcServer, HarnessSdkJsonRpcServerOptions | @deepseek-ai/cordis, node:path, @deepseek-ai/dsh-brand, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-attachment |

#### packages/session-query/session-log-export — @deepseek-ai/dsh-session-log-export@0.2.1-alpha.1（9 文件 / 1163 行）

职责：会话日志归档导出（UI 命令）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/session-query/session-log-export/src/archive.ts | 617 | sessionLogExportDeps, flushLiveSessionLog, serializeSessionLog, readSessionLogText, sessionLogZipFilename, sessionLogZipEntries, streamSessionLogZip, DEFAULT_SESSION_LOG_COMPRESSION_LEVEL …等13项 | fflate, @deepseek-ai/cordis, @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-session-query, @deepseek-ai/dsh-session |
| packages/session-query/session-log-export/src/client/controller.ts | 135 | sessionLogZipFilename, downloadUrl, SessionLogDownloadController, SessionLogDownloadStatus, SessionLogDownloadEntry, SessionLogDownloadState | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-session |
| packages/session-query/session-log-export/src/client/Dialog.tsx | 51 | SessionLogDownloadDialog, SessionLogDownloadDialogInjected, SessionLogDownloadDialogProps | @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-session, @deepseek-ai/dsh-client-ui-primitives, @deepseek-ai/dsh-client-ui-slots |
| packages/session-query/session-log-export/src/client/HeaderAction.tsx | 70 | SessionLogDownloadHeaderAction, SessionLogDownloadHeaderInjected, SessionLogDownloadHeaderProps | react, @deepseek-ai/dsh-client-store, @deepseek-ai/dsh-client-ui-slots, @deepseek-ai/dsh-session, @deepseek-ai/dsh-client-ui-primitives |
| packages/session-query/session-log-export/src/client/index.ts | 66 | apply, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-session, @deepseek-ai/dsh-client-locale, @deepseek-ai/dsh-client-ui-commands, @deepseek-ai/dsh-client-ui-conversation |
| packages/session-query/session-log-export/src/client/locales.ts | 34 | NS, zh, en, SessionLogDownloadKey | — |
| packages/session-query/session-log-export/src/index.ts | 170 | apply, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/dsh-commands, @deepseek-ai/schemastery, @deepseek-ai/dsh-brand, @deepseek-ai/dsh-attachment |
| packages/session-query/session-log-export/src/routes.ts | 12 | SESSION_LOG_EXPORT_PATH, SESSION_LOG_EXPORT_ROUTE | — |
| packages/session-query/session-log-export/tsdown.config.ts | 8 | clientBundle | — |

#### packages/session-query/session-query — @deepseek-ai/dsh-session-query@0.2.1-alpha.1（12 文件 / 2205 行）

职责：会话检索引擎（ctx.sessionQuery）：live 优先精确读/过滤/trace/游标分页


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/session-query/session-query/src/cold-read.ts | 58 | readColdSessionLog, ColdSessionLog | @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-persistence |
| packages/session-query/session-query/src/config.ts | 58 | SessionQueryError, SESSION_QUERY_READ_WINDOW_MAX, SESSION_QUERY_DEFAULT_PERSISTED_INSPECT_CONCURRENCY, SESSION_QUERY_DEFAULT_PREPARED_SESSION_CACHE_SIZE, Config, SessionQueryErrorCode | @deepseek-ai/dsh-llm |
| packages/session-query/session-query/src/corpus.ts | 318 | SessionCorpus, LogicalSession, LogicalSessionSource, LogicalProjectionResult | @deepseek-ai/cordis, @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-persistence |
| packages/session-query/session-query/src/cursor.ts | 16 | SessionSearchCursor | @deepseek-ai/dsh-brand |
| packages/session-query/session-query/src/documents.ts | 76 | buildSessionEventRecords, buildSessionEventSearchDocuments | @deepseek-ai/dsh-session-format-catalog, @deepseek-ai/dsh-session |
| packages/session-query/session-query/src/extraction.ts | 88 | extractSessionEventText | @deepseek-ai/dsh-session, @deepseek-ai/dsh-tool-todo |
| packages/session-query/session-query/src/filters.ts | 244 | filterSessionResults, filterSessionEventDocuments, materializeSessionResultFilters, materializeSessionEventResultFilters, compileSessionTextFilter | — |
| packages/session-query/session-query/src/index.ts | 409 | SessionQueryEngine | @deepseek-ai/dsh-session-format-catalog, @deepseek-ai/cordis, @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-title |
| packages/session-query/session-query/src/observation.ts | 368 | SessionObservationReader, SessionObservation, SessionObservationOptions | @deepseek-ai/cordis, @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-persistence, @deepseek-ai/dsh-session-projection, @deepseek-ai/dsh-session-projection-cache |
| packages/session-query/session-query/src/sources.ts | 26 | assertSessionHeadersCompatible | @deepseek-ai/dsh-session |
| packages/session-query/session-query/src/tracing.ts | 255 | eventRecords, currentSurfaceEvents, traceEvent, traceSession | @deepseek-ai/dsh-session-format-catalog, @deepseek-ai/dsh-session |
| packages/session-query/session-query/src/types.ts | 289 | SessionEventSurface, SessionRecord, SessionSurfaceSnapshot, SessionLogSnapshot, SessionEventRecord, SessionLineageNode, SessionLineageTrace, SessionEventTraceRequest …等27项 | @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-title |

#### packages/session-query/session-query-sqlite — @deepseek-ai/dsh-session-query-sqlite@0.2.1-alpha.1（3 文件 / 1784 行）

职责：SQLite FTS5 全文检索后端


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/session-query/session-query-sqlite/src/index.ts | 1132 | SqliteSessionQueryEngine, SESSION_QUERY_SQLITE_PATH_KEY, SESSION_QUERY_SQLITE_DEFAULT_LIMIT, SESSION_QUERY_SQLITE_MAX_LIMIT, SESSION_QUERY_SQLITE_SNIPPET_CHARS, OpenAt, Config | node:crypto, @deepseek-ai/dsh-session, node:sqlite, @deepseek-ai/cordis, @deepseek-ai/schemastery |
| packages/session-query/session-query-sqlite/src/query.ts | 478 | assertPortableBindingCount, assertFts5OuterPredicateCount, normalizeSessionRequest, normalizeEventRequest, buildSessionWhere, buildEventWhere, quoteFtsData, sanitizeFtsText …等19项 | @deepseek-ai/dsh-session-query |
| packages/session-query/session-query-sqlite/src/schema.ts | 174 | openSearchDatabase, SESSION_QUERY_SQLITE_SCHEMA_VERSION, SESSION_QUERY_SQLITE_APPLICATION_ID, JournalMode | node:sqlite, node:fs, node:path |

#### packages/session-query/tool-session-query — @deepseek-ai/dsh-tool-session-query@0.2.1-alpha.1（6 文件 / 1426 行）

职责：模型侧会话查询工具


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/session-query/tool-session-query/src/index.ts | 137 | apply, name, inject, DEFAULT_MAX_SEARCH_RESULTS, DEFAULT_SEARCH_TIMEOUT_MS, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-timeout, @deepseek-ai/dsh-tools |
| packages/session-query/tool-session-query/src/input.ts | 308 | toolInput | @deepseek-ai/dsh-session, @deepseek-ai/dsh-brand, @deepseek-ai/dsh-session-query |
| packages/session-query/tool-session-query/src/operations.ts | 287 | operations | @deepseek-ai/cordis, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-query, @deepseek-ai/dsh-tools |
| packages/session-query/tool-session-query/src/presentation.ts | 256 | presentation | @deepseek-ai/dsh-session-query, @deepseek-ai/dsh-session, @deepseek-ai/dsh-tools |
| packages/session-query/tool-session-query/src/service-boundary.ts | 180 | serviceBoundary | @deepseek-ai/cordis, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session-query |
| packages/session-query/tool-session-query/src/workspace-access.ts | 258 | workspaceAccess | @deepseek-ai/cordis, @deepseek-ai/dsh-brand, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session, @deepseek-ai/dsh-agent |

#### packages/session/session-checkpoint-policy — @deepseek-ai/dsh-session-checkpoint-policy@0.2.1-alpha.1（1 文件 / 84 行）

职责：会话 checkpoint 策略


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/session/session-checkpoint-policy/src/index.ts | 84 | apply, name, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-session, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-agent |

#### packages/session/session-format — @deepseek-ai/dsh-session-format@0.2.1-alpha.1（9 文件 / 967 行）

职责：会话格式链框架（强制相邻迁移无缺口）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/session/session-format/src/catalog.ts | 290 | createSessionFormatCatalog | — |
| packages/session/session-format/src/chain.ts | 256 | defineSessionFormatMigration, createSessionFormatChain | — |
| packages/session/session-format/src/context.ts | 28 | SessionFormatEventCollector | — |
| packages/session/session-format/src/error.ts | 10 | SessionFormatError, SessionFormatUnsupportedMigrationError | — |
| packages/session/session-format/src/filename.ts | 33 | sessionFormatLogFilename, parseSessionFormatLogFilename | — |
| packages/session/session-format/src/index.ts | 10 | — | — |
| packages/session/session-format/src/json.ts | 95 | isSessionFormatJsonObject, sessionFormatCount, sessionFormatSafeInteger, sessionFormatVersion, inspectSessionFormatVersion, snapshotSessionFormatJson, snapshotSessionFormatHeader | @deepseek-ai/dsh-util-values |
| packages/session/session-format/src/types.ts | 231 | SessionFormatJsonPrimitive, SessionFormatJsonValue, SessionFormatJsonObject, SessionFormatHeader, SessionFormatEvent, SessionFormatArtifact, SessionFormatMigration, SessionFormatMigrationStageInput …等23项 | — |
| packages/session/session-format/tsdown.config.ts | 14 | defineConfig | tsdown |

#### packages/session/session-format-catalog — @deepseek-ai/dsh-session-format-catalog@0.2.1-alpha.1（7 文件 / 173 行）

职责：格式目录：汇总 v0→v4 迁移 + 终验


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/session/session-format-catalog/src/children.ts | 20 | createSessionFormatCatalogWithChildren | @deepseek-ai/dsh-session-format, @deepseek-ai/dsh-session-format-v3-to-v4 |
| packages/session/session-format-catalog/src/current.ts | 53 | validateInstalledCurrentSessionHeader, validateInstalledCurrentSessionArtifact | @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-format |
| packages/session/session-format-catalog/src/generated.ts | 49 | sessionFormatCatalogOptions, sessionFormatCatalog | @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-format, @deepseek-ai/dsh-session-format-v0-to-v1, @deepseek-ai/dsh-session-format-v1-to-v2, @deepseek-ai/dsh-session-format-v2-to-v3 |
| packages/session/session-format-catalog/src/historical.ts | 22 | historicalSessionFormatCatalog | @deepseek-ai/dsh-session-format-v3-to-v4, @deepseek-ai/dsh-session-format, @deepseek-ai/dsh-session-format-v0-to-v1, @deepseek-ai/dsh-session-format-v1-to-v2, @deepseek-ai/dsh-session-format-v2-to-v3 |
| packages/session/session-format-catalog/src/index.ts | 7 | — | @deepseek-ai/dsh-session-format |
| packages/session/session-format-catalog/src/message-projections.ts | 8 | currentSessionMessageProjections | @deepseek-ai/dsh-compaction-image-offload, @deepseek-ai/dsh-session |
| packages/session/session-format-catalog/tsdown.config.ts | 14 | defineConfig | tsdown |

#### packages/session/session-format-v0-to-v1 — @deepseek-ai/dsh-session-format-v0-to-v1@0.2.1-alpha.1（11 文件 / 2893 行）

职责：格式迁移步骤 v0→v1


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/session/session-format-v0-to-v1/src/codec.ts | 323 | isReleasedAssistantChunkRun, releasedV0SessionFormatCodec, releasedV1SessionFormatCodec, ReleasedAssistantChunkRun | @deepseek-ai/dsh-session-format |
| packages/session/session-format-v0-to-v1/src/dispositions.ts | 132 | defineReleasedPayloadDisposition, RELEASED_V0_EVENT_DISPOSITIONS, RELEASED_V0_EVENT_TYPES, ReleasedV0PayloadDisposition | — |
| packages/session/session-format-v0-to-v1/src/index.ts | 14 | — | — |
| packages/session/session-format-v0-to-v1/src/migration.ts | 449 | sessionFormatV0ToV1 | @deepseek-ai/dsh-session-format |
| packages/session/session-format-v0-to-v1/src/payload-validation.ts | 1063 | assertReleasedPayloadSemantics | @deepseek-ai/dsh-session-format, @deepseek-ai/dsh-util-values |
| packages/session/session-format-v0-to-v1/src/relationships.ts | 498 | assertReleasedArtifactRelationships, ReleasedRelationshipExtensions | @deepseek-ai/dsh-util-values, @deepseek-ai/dsh-session-format |
| packages/session/session-format-v0-to-v1/src/testing/restore.ts | 82 | restoreV0ToV1, restoreV1 | @deepseek-ai/dsh-session-format |
| packages/session/session-format-v0-to-v1/src/testing/validation.ts | 66 | assertReleasedV0SourceArtifact, assertNormalizedReleasedV0Artifact, assertReleasedV1MigrationSource, assertReleasedV1Artifact, assertReleasedV1PhysicalArtifact | @deepseek-ai/dsh-session-format |
| packages/session/session-format-v0-to-v1/src/validation-helpers.ts | 34 | releasedV0Record, assertReleasedV0Keys | @deepseek-ai/dsh-session-format |
| packages/session/session-format-v0-to-v1/src/validation.ts | 218 | assertReleasedSessionFormatHeader, assertReleasedV1Header, restoreReleasedV1Artifact, assertReleasedArtifactCoordinates, assertReleasedSurfaceMetadata, assertReleasedEventPayload | node:path, @deepseek-ai/dsh-session-format, @deepseek-ai/dsh-util-values |
| packages/session/session-format-v0-to-v1/tsdown.config.ts | 14 | defineConfig | tsdown |

#### packages/session/session-format-v1-to-v2 — @deepseek-ai/dsh-session-format-v1-to-v2@0.2.1-alpha.1（7 文件 / 1276 行）

职责：格式迁移步骤 v1→v2


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/session/session-format-v1-to-v2/src/codec.ts | 253 | releasedV2SessionFormatCodec | @deepseek-ai/dsh-session-format |
| packages/session/session-format-v1-to-v2/src/dispositions.ts | 35 | RELEASED_V2_EVENT_DISPOSITIONS, RELEASED_V2_EVENT_TYPES | @deepseek-ai/dsh-session-format-v0-to-v1 |
| packages/session/session-format-v1-to-v2/src/index.ts | 8 | — | @deepseek-ai/dsh-session-format-v0-to-v1 |
| packages/session/session-format-v1-to-v2/src/migration.ts | 696 | sessionFormatV1ToV2 | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session-format, @deepseek-ai/dsh-session-format-v0-to-v1 |
| packages/session/session-format-v1-to-v2/src/testing/validation.ts | 106 | assertReleasedV2Artifact | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-util-values, @deepseek-ai/dsh-session-format, @deepseek-ai/dsh-session-format-v0-to-v1 |
| packages/session/session-format-v1-to-v2/src/validation.ts | 164 | assertReleasedV2Header, releasedV2Record, assertReleasedV2Keys, restoreReleasedV2Artifact, assertReleasedV2PhysicalArtifact | node:path, @deepseek-ai/dsh-session-format, @deepseek-ai/dsh-session-format-v0-to-v1 |
| packages/session/session-format-v1-to-v2/tsdown.config.ts | 14 | defineConfig | tsdown |

#### packages/session/session-format-v2-to-v3 — @deepseek-ai/dsh-session-format-v2-to-v3@0.2.1-alpha.1（7 文件 / 835 行）

职责：格式迁移步骤 v2→v3


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/session/session-format-v2-to-v3/src/codec.ts | 95 | assertV3RowAdmission, releasedV3SessionFormatCodec | @deepseek-ai/dsh-session-format, @deepseek-ai/dsh-session-format-v1-to-v2 |
| packages/session/session-format-v2-to-v3/src/index.ts | 7 | — | @deepseek-ai/dsh-session-format-v1-to-v2 |
| packages/session/session-format-v2-to-v3/src/migration.ts | 174 | sessionFormatV2ToV3 | node:crypto, @deepseek-ai/dsh-session-format, @deepseek-ai/dsh-session-format-v1-to-v2 |
| packages/session/session-format-v2-to-v3/src/payload.ts | 372 | record, keys, assertEvent, isRepairIdentity, assertV3StructuralRow, assertV3Event, canonicalizeTransformedEvent, SURFACE_TYPES | @deepseek-ai/dsh-session-format, @deepseek-ai/dsh-session-format-v0-to-v1, @deepseek-ai/dsh-session-format-v1-to-v2 |
| packages/session/session-format-v2-to-v3/src/references.ts | 52 | remapEvent | @deepseek-ai/dsh-session-format |
| packages/session/session-format-v2-to-v3/src/validation.ts | 121 | assertReleasedV3Header, restoreReleasedV3Artifact, assertV3EventAdmission | @deepseek-ai/dsh-session-format, @deepseek-ai/dsh-session-format-v1-to-v2 |
| packages/session/session-format-v2-to-v3/tsdown.config.ts | 14 | defineConfig | tsdown |

#### packages/session/session-format-v3-to-v4 — @deepseek-ai/dsh-session-format-v3-to-v4@0.2.1-alpha.1（18 文件 / 1704 行）

职责：格式迁移步骤 v3→v4


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/session/session-format-v3-to-v4/src/codec.ts | 76 | assertV4RowAdmission, releasedV4SessionFormatCodec | @deepseek-ai/dsh-session-format, @deepseek-ai/dsh-session-format-v2-to-v3 |
| packages/session/session-format-v3-to-v4/src/content.ts | 96 | migrateV3Content, migrateV3EventContent | @deepseek-ai/dsh-session-format |
| packages/session/session-format-v3-to-v4/src/developer.ts | 114 | assertV4DeveloperData | @deepseek-ai/dsh-session-format |
| packages/session/session-format-v3-to-v4/src/extension-identities.ts | 80 | namespaceV3OpaqueEvent, RELEASED_V3_EVENT_TYPES | @deepseek-ai/dsh-session-format |
| packages/session/session-format-v3-to-v4/src/facts.ts | 93 | historicalChildCatalogSource, childCatalogSource, childCatalogFact, catalogFact, childCatalogSubject | @deepseek-ai/dsh-session-format |
| packages/session/session-format-v3-to-v4/src/fork-result.ts | 41 | assertV4ForkResult | @deepseek-ai/dsh-session-format |
| packages/session/session-format-v3-to-v4/src/index.ts | 9 | — | @deepseek-ai/dsh-session-format-v2-to-v3 |
| packages/session/session-format-v3-to-v4/src/message-sources.ts | 43 | assertV4MessageSources, assertV4SourceRowAdmission | @deepseek-ai/dsh-session-format |
| packages/session/session-format-v3-to-v4/src/migration.ts | 176 | createSessionFormatV3ToV4, sessionFormatV3ToV4 | @deepseek-ai/dsh-session-format, @deepseek-ai/dsh-session-format-v2-to-v3 |
| packages/session/session-format-v3-to-v4/src/references.ts | 69 | remapV3References | @deepseek-ai/dsh-session-format |
| packages/session/session-format-v3-to-v4/src/relationships.ts | 386 | assertV4LifecycleRelationships | node:util, @deepseek-ai/dsh-session-format |
| packages/session/session-format-v3-to-v4/src/retired-syntax.ts | 76 | assertV4RetiredSyntax | @deepseek-ai/dsh-session-format |
| packages/session/session-format-v3-to-v4/src/sources.ts | 107 | mapEventMessages, rewritePluginSource, rewriteV3MessageSource | @deepseek-ai/dsh-session-format |
| packages/session/session-format-v3-to-v4/src/system-message.ts | 65 | assertV4SystemMessageFields | @deepseek-ai/dsh-session-format |
| packages/session/session-format-v3-to-v4/src/testing/validation.ts | 16 | assertReleasedV4Artifact | @deepseek-ai/dsh-session-format |
| packages/session/session-format-v3-to-v4/src/tool-role.ts | 113 | liftToolResult, assertV4ToolResultMessage | @deepseek-ai/dsh-session-format |
| packages/session/session-format-v3-to-v4/src/validation.ts | 131 | assertReleasedV4Header, restoreReleasedV4Artifact, validateDeliveryAccepted, assertReleasedV4Relationships | node:path, @deepseek-ai/dsh-session-format |
| packages/session/session-format-v3-to-v4/tsdown.config.ts | 13 | defineConfig | tsdown |

#### packages/session/session-log-deepseek — @deepseek-ai/dsh-session-log-deepseek@0.2.1-alpha.1（2 文件 / 336 行）

职责：授权会话日志上传


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/session/session-log-deepseek/src/index.ts | 245 | acceptedThrough, apply, name, inject, Config | node:buffer, @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-brand, @deepseek-ai/dsh-deepseek-llm-api-extensions |
| packages/session/session-log-deepseek/src/types.ts | 91 | DeepSeekSessionLogWireHeader, DeepSeekSessionLogWireSurfaceOp, DeepSeekSessionLogWireEvent, DeepSeekSessionLogExtension | @deepseek-ai/dsh-session, @deepseek-ai/dsh-util-values |

#### packages/session/session-persistence — @deepseek-ai/dsh-session-persistence@0.2.1-alpha.1（5 文件 / 632 行）

职责：持久化 Service Definition（ctx.sessionPersistence）+ SessionHandle


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/session/session-persistence/src/errors.ts | 138 | sessionFormatVersionRefusal, SessionPersistenceNotFoundError, SessionAlreadyExistsError, SessionAlreadyOwnedError, SessionReadOnlyError, SessionOwnershipLostError, SessionHandleClosedError, SessionPersistenceCorruptionError …等10项 | @deepseek-ai/dsh-session |
| packages/session/session-persistence/src/handle.ts | 118 | SessionAccess, SessionHandleReadOptions, SessionHandleReadResult, SessionHandleAppendOptions, SessionHandleFlushOptions, SessionHandle | @deepseek-ai/dsh-session |
| packages/session/session-persistence/src/index.ts | 205 | SessionPersistence, SessionPersistenceSnapshot, SessionPersistenceCreateOptions, SessionStorageMetadata, SessionInspection, SessionPersistenceOpenOptions, SessionPersistenceStatOptions, SessionPersistenceListOptions | @deepseek-ai/cordis, @deepseek-ai/dsh-session |
| packages/session/session-persistence/src/revision.ts | 19 | SessionPersistenceRevision | @deepseek-ai/dsh-brand |
| packages/session/session-persistence/src/storage-contract.ts | 152 | assertStoredId, assertVersion, validateStoredEvents, materializeCreateHeader, materializeAppendBatch, assertContiguous | @deepseek-ai/dsh-session, @deepseek-ai/dsh-util-values |

#### packages/session/session-persistence-jsonl — @deepseek-ai/dsh-session-persistence-jsonl@0.2.1-alpha.1（14 文件 / 5005 行）

职责：JSONL+zstd 物理 后端：分帧/撕裂恢复/generation 独占发布


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/session/session-persistence-jsonl/src/catalog-migration.ts | 93 | prepareCatalogFacts | node:fs, node:path, @deepseek-ai/dsh-session-format-catalog, @deepseek-ai/dsh-session-format-v3-to-v4, @deepseek-ai/dsh-session-format |
| packages/session/session-persistence-jsonl/src/format.ts | 539 | logSuffix, generationLogFilename, parseGenerationLogFilename, assertNoRetiredHeaderFields, toHeaderLine, encodeSegment, projectKey, projectDir …等16项 | node:path, @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-format, @deepseek-ai/dsh-session-format-catalog, @deepseek-ai/dsh-session-format-v3-to-v4 |
| packages/session/session-persistence-jsonl/src/generation.ts | 1060 | readStableJsonlFile, verifyJsonlCurrentGeneration, prepareJsonlMigration, createJsonlGenerationRuntime, readDecodedJsonlSource, JsonlGenerationSourceChangedError, JsonlGenerationUnsupportedMigrationError, JsonlGenerationTargetConflictError …等17项 | @deepseek-ai/dsh-session-format-catalog, node:crypto, node:fs, node:path, node:perf_hooks |
| packages/session/session-persistence-jsonl/src/index.ts | 1726 | JsonlCompressionSchema, Config, JsonlSessionPersistence | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-session-format-catalog, node:fs, node:path |
| packages/session/session-persistence-jsonl/src/lease.ts | 136 | SessionWriteLease, LEASE_FILENAME | node:fs, node:path, @deepseek-ai/node-addon-system, @deepseek-ai/dsh-session-persistence, @deepseek-ai/dsh-session |
| packages/session/session-persistence-jsonl/src/migration-verifier.ts | 194 | verifyCurrentGenerationInWorker | node:worker_threads |
| packages/session/session-persistence-jsonl/src/storage.ts | 568 | JsonlSessionHandle, JsonlBackendTracker, LIVE_WRITE_BATCH_MAX_DELAY_MS, JsonlHandleStorage, StorageHandleState, PendingSession | @deepseek-ai/cordis, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-persistence |
| packages/session/session-persistence-jsonl/src/testing/generation.ts | 17 | createJsonlGenerationTestRuntime | — |
| packages/session/session-persistence-jsonl/src/win32.ts | 209 | publishNewFileWin32, acquireLockHandleWin32, releaseLockHandleWin32, ensureDurableDirectoryWin32 | node:crypto, node:fs, node:path, koffi |
| packages/session/session-persistence-jsonl/src/worker.ts | 57 | — | node:worker_threads |
| packages/session/session-persistence-jsonl/src/zstd-private-decoder.ts | 179 | NodePrivateZstdFrameDecoder | node:buffer, node:zlib |
| packages/session/session-persistence-jsonl/src/zstd-public-decoder.ts | 41 | PublicZstdFrameDecoder | node:zlib |
| packages/session/session-persistence-jsonl/src/zstd.ts | 157 | scanZstdFrames, compressZstdFrame, decompressZstdFrame, createZstdFrameDecoder, decompressZstdPrefix, ZstdFrameRange, ZstdFrameScan, ZstdFrameDecoder | node:zlib, node:util |
| packages/session/session-persistence-jsonl/tsdown.config.ts | 29 | defineConfig | tsdown |

#### packages/session/session-projection — @deepseek-ai/dsh-session-projection@0.2.1-alpha.1（2 文件 / 740 行）

职责：读侧投影框架（ctx.sessionProjections）+ checkpoint 读梯


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/session/session-projection/src/index.ts | 715 | SessionProjectionRegistry, ProjectionDefinition, ProjectionChangeListener, ProjectionSnapshot, ProjectionCheckpointRow, ProjectionCheckpoint | @deepseek-ai/cordis, zod, @deepseek-ai/dsh-session |
| packages/session/session-projection/src/types.ts | 25 | SessionProjectionMap, SessionProjectionStateMap | — |

#### packages/session/session-projection-cache — @deepseek-ai/dsh-session-projection-cache@0.2.1-alpha.1（2 文件 / 580 行）

职责：投影 checkpoint 持久缓存（storage 后端）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/session/session-projection-cache/src/index.ts | 472 | SessionProjectionCache, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-util-values, @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-projection |
| packages/session/session-projection-cache/src/spec.ts | 108 | checkpointRow, checkpointIdentity, checkpointRecord, projectionCacheDomainSpec, CheckpointIdentity, CheckpointRecord | zod, @deepseek-ai/dsh-util-values, @deepseek-ai/dsh-session, @deepseek-ai/dsh-storage-domain |

#### packages/session/session-stats — @deepseek-ai/dsh-session-stats@0.2.1-alpha.1（4 文件 / 301 行）

职责：会话统计派生


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/session/session-stats/src/client.ts | 11 | — | — |
| packages/session/session-stats/src/index.ts | 30 | apply, name, inject | @deepseek-ai/cordis |
| packages/session/session-stats/src/projection.ts | 213 | sessionStatsProjectionDefinition | zod, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session-projection |
| packages/session/session-stats/src/types.ts | 47 | SessionStatsProjection | — |

#### packages/session/session-telemetry — @deepseek-ai/dsh-session-telemetry@0.2.1-alpha.1（2 文件 / 481 行）

职责：会话遥测事件定义


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/session/session-telemetry/src/coordinator.ts | 306 | SessionTelemetryCoordinator, SessionTelemetryCapture, SessionTelemetryCaptureOptions | @deepseek-ai/cordis, @deepseek-ai/dsh-session, @deepseek-ai/dsh-agent |
| packages/session/session-telemetry/src/index.ts | 175 | SessionTelemetryBackend, SessionTelemetrySeverity, SessionTelemetryRecord, SessionTelemetrySink, SessionTelemetrySharingStatus | @deepseek-ai/cordis, @deepseek-ai/dsh-session |

#### packages/session/session-telemetry-otel — @deepseek-ai/dsh-session-telemetry-otel@0.2.1-alpha.1（1 文件 / 278 行）

职责：会话遥测 OTel 上报


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/session/session-telemetry-otel/src/index.ts | 278 | OpenTelemetrySessionBackend, DEFAULT_TELEMETRY_MODE, Config, DEFAULT_SHUTDOWN_TIMEOUT_MILLIS, SessionTelemetryMode | node:module, @deepseek-ai/schemastery, @deepseek-ai/cordis, @deepseek-ai/dsh-command-feedback, @deepseek-ai/dsh-message-feedback |

#### packages/session/session-title — @deepseek-ai/dsh-session-title@0.2.1-alpha.1（4 文件 / 1017 行）

职责：会话标题缝（唯一 provider）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/session/session-title/src/client.ts | 11 | — | — |
| packages/session/session-title/src/index.ts | 836 | SessionTitleProviderId, foldSessionTitle, SessionTitleInvalidError, SessionTitleService, titleProjectionDefinition, Config, SessionTitleAutomaticMode, SessionTitleProviderRequest …等10项 | @deepseek-ai/cordis, @deepseek-ai/schemastery, zod, @deepseek-ai/dsh-brand, @deepseek-ai/dsh-llm |
| packages/session/session-title/src/normalize.ts | 75 | truncateTitleUtf8, normalizeSessionTitle, fallbackSessionTitle | — |
| packages/session/session-title/src/types.ts | 95 | SessionTitleProviderId, SessionTitleModelIdentity, SessionTitleSource, SessionTitleEventData, SessionTitleSnapshot, TitleProjection, SessionTitleUserMessage, TitleInputState | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-session |

#### packages/session/session-title-all-prompts-llm — @deepseek-ai/dsh-session-title-all-prompts-llm@0.2.1-alpha.1（1 文件 / 37 行）

职责：标题策略：全 prompts LLM


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/session/session-title-all-prompts-llm/src/index.ts | 37 | apply, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-session-title-llm |

#### packages/session/session-title-first-prompt-llm — @deepseek-ai/dsh-session-title-first-prompt-llm@0.2.1-alpha.1（1 文件 / 41 行）

职责：标题策略：首 prompt LLM（默认）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/session/session-title-first-prompt-llm/src/index.ts | 41 | apply, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-session-title-llm |

#### packages/session/session-title-llm — @deepseek-ai/dsh-session-title-llm@0.2.1-alpha.1（1 文件 / 304 行）

职责：标题 LLM 基类实现


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/session/session-title-llm/src/index.ts | 304 | resolveSessionTitleLlmConfig, registerSessionTitleLlmProvider, generateSessionTitleWithLlm, SESSION_TITLE_TIMEOUT_CODE, SessionTitleLlmConfigFields, SessionTitleLlmConfigSchema, SessionTitleLlmRequestEventData, SessionTitleLlmConfig …等10项 | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-timeout, @deepseek-ai/dsh-util-values |

#### packages/session/session-turn-outline — @deepseek-ai/dsh-session-turn-outline@0.2.1-alpha.1（4 文件 / 229 行）

职责：turn 大纲派生视图


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/session/session-turn-outline/src/client.ts | 11 | — | — |
| packages/session/session-turn-outline/src/index.ts | 30 | apply, name, inject | @deepseek-ai/cordis |
| packages/session/session-turn-outline/src/projection.ts | 138 | turnOutlineProjectionDefinition | zod, @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-projection |
| packages/session/session-turn-outline/src/types.ts | 50 | TurnOutlineEntry, TurnOutlineState | @deepseek-ai/dsh-session |

#### packages/settings/settings — @deepseek-ai/dsh-settings@0.2.1-alpha.1（4 文件 / 707 行）

职责：用户设置（ctx.settings）：表单投影 + volatile 编辑 + 乐观并发


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/settings/settings/src/index.ts | 432 | SettingsConflictError, SettingsForms, SettingsDescriptor, SettingsDescribeOptions, SettingsPathOp | node:fs, node:path, yaml, @deepseek-ai/cordis, @deepseek-ai/schemastery |
| packages/settings/settings/src/redact.ts | 117 | redactSecrets, RedactedSecret, RedactedValue | @deepseek-ai/schemastery |
| packages/settings/settings/src/schema.ts | 80 | plainConfig, volatileForm, projectForm, isVolatilePath | @deepseek-ai/schemastery, @deepseek-ai/cosmokit |
| packages/settings/settings/src/types.ts | 78 | SettingsNamespace, SettingsSecretView, SettingsNamespaceView, SettingsPathOpView, SettingsDescribeValue | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-util-values |

#### packages/shell/bash-local — @deepseek-ai/dsh-bash-local@0.2.1-alpha.1（1 文件 / 405 行）

职责：本地 bash 执行器（resolve/spec 默认与上限、首因分类取消）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/shell/bash-local/src/index.ts | 405 | assertServiceableBashConfig, LocalBashExecutor, ENV_OVERRIDES, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-shell, @deepseek-ai/dsh-subprocess, @deepseek-ai/dsh-timeout |

#### packages/shell/bash-sandbox — @deepseek-ai/dsh-bash-sandbox@0.2.1-alpha.1（2 文件 / 208 行）

职责：沙箱 bash 执行器（confine 包裹 + 拒绝/故障分类）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/shell/bash-sandbox/src/helpers.ts | 15 | classifyDenial | @deepseek-ai/dsh-shell, @deepseek-ai/dsh-sandbox |
| packages/shell/bash-sandbox/src/index.ts | 193 | SandboxBashExecutor, Config | @deepseek-ai/cordis, @deepseek-ai/dsh-shell, @deepseek-ai/dsh-sandbox, @deepseek-ai/dsh-sandbox-policy, @deepseek-ai/dsh-bash-local |

#### packages/shell/pwsh-local — @deepseek-ai/dsh-pwsh-local@0.2.1-alpha.1（2 文件 / 530 行）

职责：本地 PowerShell 执行器


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/shell/pwsh-local/src/index.ts | 450 | assertServiceablePwshConfig, PwshLocalExecutor, ENV_OVERRIDES, ENCODING_PREAMBLE, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-shell, @deepseek-ai/dsh-subprocess, @deepseek-ai/dsh-timeout |
| packages/shell/pwsh-local/src/resolve.ts | 80 | candidatePwshPaths, resolvePwshPath | node:fs, node:path |

#### packages/shell/pwsh-sandbox — @deepseek-ai/dsh-pwsh-sandbox@0.2.1-alpha.1（2 文件 / 322 行）

职责：沙箱 PowerShell 执行器


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/shell/pwsh-sandbox/src/helpers.ts | 121 | isRunnerSpawnFailure, classifyDenial, classifyRunnerFailure, matchesSignature | node:fs, @deepseek-ai/dsh-shell, @deepseek-ai/dsh-sandbox |
| packages/shell/pwsh-sandbox/src/index.ts | 201 | SandboxPwshExecutor, Config | @deepseek-ai/cordis, @deepseek-ai/dsh-shell, @deepseek-ai/dsh-sandbox, @deepseek-ai/dsh-sandbox-policy, @deepseek-ai/dsh-pwsh-local |

#### packages/shell/shell — @deepseek-ai/dsh-shell@0.2.1-alpha.1（3 文件 / 380 行）

职责：命令执行 Service Definition（ctx.shell）：request/spec split 模板


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/shell/shell/src/index.ts | 97 | ShellExecutor | @deepseek-ai/cordis, @deepseek-ai/dsh-sandbox |
| packages/shell/shell/src/render.ts | 44 | parseExitStatus, ParsedExitStatus | — |
| packages/shell/shell/src/types.ts | 239 | ShellObservedStreams, ShellSandboxInfo, ShellExpiryPolicy, ShellExecRequest, ShellExecSpec, ShellRunResult, ShellProcessStatus, ShellProcessRead …等10项 | @deepseek-ai/dsh-sandbox, @deepseek-ai/dsh-subprocess |

#### packages/shell/shell-env — @deepseek-ai/dsh-shell-env@0.2.1-alpha.1（1 文件 / 212 行）

职责：shell 工具的环境变量上下文注入


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/shell/shell-env/src/index.ts | 212 | apply, ShellEnvRegistry, name, inject, Config, BashEnvVariable, BashEnvContributor, BashEnvVariableInfo | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-shell, @deepseek-ai/dsh-home-paths, @deepseek-ai/dsh-tools |

#### packages/shell/tool-bash — @deepseek-ai/dsh-tool-bash@0.2.1-alpha.1（3 文件 / 816 行）

职责：bash 工具：job 注册/超时提升后台/升级审批


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/shell/tool-bash/src/background.ts | 130 | processOutcome, processSources, ringDelta, processJob | @deepseek-ai/dsh-sandbox, @deepseek-ai/dsh-shell, @deepseek-ai/dsh-jobs |
| packages/shell/tool-bash/src/index.ts | 557 | apply, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, node:path, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-llm |
| packages/shell/tool-bash/src/render.ts | 129 | renderResult, renderPromoted, renderJobRead | @deepseek-ai/dsh-shell, @deepseek-ai/dsh-sandbox |

#### packages/shell/tool-bash-persistent — @deepseek-ai/dsh-tool-bash-persistent@0.2.1-alpha.1（1 文件 / 485 行）

职责：bash 持久终端变体工具


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/shell/tool-bash-persistent/src/index.ts | 485 | apply, name, inject, Config | node:crypto, @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-output-retention |

#### packages/shell/tool-pwsh — @deepseek-ai/dsh-tool-pwsh@0.2.1-alpha.1（3 文件 / 885 行）

职责：pwsh 工具（Windows 主路径）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/shell/tool-pwsh/src/background.ts | 133 | processOutcome, processSources, ringDelta, processJob | @deepseek-ai/dsh-sandbox, @deepseek-ai/dsh-shell, @deepseek-ai/dsh-jobs |
| packages/shell/tool-pwsh/src/index.ts | 610 | apply, name, inject, Config | node:path, @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-llm |
| packages/shell/tool-pwsh/src/render.ts | 142 | renderPwshResult, renderPwshPromoted, renderPwshJobRead, RenderablePwshResult | @deepseek-ai/dsh-shell, @deepseek-ai/dsh-sandbox |

#### packages/shell/tool-pwsh-persistent — @deepseek-ai/dsh-tool-pwsh-persistent@0.2.1-alpha.1（1 文件 / 500 行）

职责：pwsh 持久终端变体工具


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/shell/tool-pwsh-persistent/src/index.ts | 500 | apply, name, inject, Config | node:crypto, @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-output-retention |

#### packages/skill/skill — @deepseek-ai/dsh-skill@0.2.1-alpha.1（1 文件 / 869 行）

职责：技能注册表（ctx.skills）：分层作用域发现 + LRU + revision 双检


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/skill/skill/src/index.ts | 869 | isSkillName, isModelInvocable, isUserInvocable, renderSkillContent, escapeText, SkillRegistry, BUNDLED_SKILL_RANK, SkillSource …等22项 | @deepseek-ai/cordis, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-util-values, @deepseek-ai/dsh-scope, @deepseek-ai/schemastery |

#### packages/skill/skill-badge — @deepseek-ai/dsh-skill-badge@0.2.1-alpha.1（1 文件 / 61 行）

职责：技能徽章（UI 辅助）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/skill/skill-badge/src/index.ts | 61 | apply, name, inject | node:fs, node:url, @deepseek-ai/cordis, @deepseek-ai/dsh-skill |

#### packages/skill/skill-filesystem — @deepseek-ai/dsh-skill-filesystem@0.2.1-alpha.1（1 文件 / 1050 行）

职责：文件系统技能 provider：六层根发现 SKILL.md/扁平 md


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/skill/skill-filesystem/src/index.ts | 1050 | apply, FileSystemSkillProvider, name, inject, Config | node:fs, node:path, node:os, @deepseek-ai/cordis, chokidar |

#### packages/skill/skill-office — @deepseek-ai/dsh-skill-office@0.2.1-alpha.1（2 文件 / 378 行）

职责：Office 技能（LibreOffice 转换）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/skill/skill-office/assets/scripts/check_office.py | 280 | — | — |
| packages/skill/skill-office/src/index.ts | 98 | apply, Config, name, inject | node:fs, node:path, node:sea, node:url, @deepseek-ai/cordis |

#### packages/skill/tool-skill — @deepseek-ai/dsh-tool-skill@0.2.1-alpha.1（1 文件 / 432 行）

职责：skill 工具：目录 section + 显式调用正文注入


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/skill/tool-skill/src/index.ts | 432 | apply, name, inject, Config, SkillCatalogSource | node:crypto, @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-tools |

#### packages/skill/tool-workspace-dependencies — @deepseek-ai/dsh-tool-workspace-dependencies@0.2.1-alpha.1（1 文件 / 278 行）

职责：工作区依赖盘点工具


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/skill/tool-workspace-dependencies/src/index.ts | 278 | parsePrimaryRuntime, readPrimaryRuntime, workspaceDependencyPaths, resolvePrimaryRuntime, installPrimaryRuntime, apply, name, inject …等11项 | node:fs, node:path, @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-tools |

#### packages/spill/spill — @deepseek-ai/dsh-spill@0.2.1-alpha.1（2 文件 / 140 行）

职责：溢出存储缝（ctx.spillStore）：saveText→SpillRef


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/spill/spill/src/index.ts | 59 | SpillStore | @deepseek-ai/cordis |
| packages/spill/spill/src/types.ts | 81 | SpillLocator, SpillOwner, SpillSource, SaveTextSpill, SpillRef | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session |

#### packages/spill/spill-local — @deepseek-ai/dsh-spill-local@0.2.1-alpha.1（3 文件 / 729 行）

职责：本地溢出文件实现 + cleanup


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/spill/spill-local/src/cleanup.ts | 432 | sweepSpillRoots, discoverDefaultRoots, gatherSweepRoots, WarnFn, SweepRoot, SweepOptions | node:fs, node:path, node:os |
| packages/spill/spill-local/src/index.ts | 165 | LocalSpillStore, Config | @deepseek-ai/cordis, node:path, node:os, @deepseek-ai/schemastery, @deepseek-ai/dsh-spill |
| packages/spill/spill-local/src/store.ts | 132 | isErrno, privateRoot, encodeSegment, sessionDir, saveTextFile, DEFAULT_ROOT_PREFIX, SaveTextOptions, SavedText | node:crypto, node:fs, node:path, node:os |

#### packages/spill/spill-policy — @deepseek-ai/dsh-spill-policy@0.2.1-alpha.1（4 文件 / 349 行）

职责：工具结果 token 预算裁剪（图片精确计价）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/spill/spill-policy/src/index.ts | 157 | apply, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-token-meter, @deepseek-ai/dsh-spill |
| packages/spill/spill-policy/src/notice.ts | 60 | formatSpillNotice, hasSpillNotice | @deepseek-ai/dsh-output-retention, @deepseek-ai/dsh-spill |
| packages/spill/spill-policy/src/retention.ts | 105 | retainContent, RetainableBlock, RetainedContent | @deepseek-ai/dsh-llm |
| packages/spill/spill-policy/src/types.ts | 27 | SpillPolicyExec | @deepseek-ai/dsh-session |

#### packages/ssh/fs-ssh — @deepseek-ai/dsh-fs-ssh@0.2.1-alpha.1（1 文件 / 108 行）

职责：SSH 文件系统 provider（helper RPC）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/ssh/fs-ssh/src/index.ts | 108 | SshFileSystem | node:path, node:url, @deepseek-ai/dsh-fs, @deepseek-ai/dsh-sandbox, @deepseek-ai/dsh-sandbox-policy |

#### packages/ssh/sandbox-ssh — @deepseek-ai/dsh-sandbox-ssh@0.2.1-alpha.1（1 文件 / 34 行）

职责：SSH 沙箱 provider


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/ssh/sandbox-ssh/src/index.ts | 34 | SshSandboxProvider | @deepseek-ai/dsh-sandbox, @deepseek-ai/dsh-ssh, zod |

#### packages/ssh/ssh — @deepseek-ai/dsh-ssh@0.2.1-alpha.1（8 文件 / 1408 行）

职责：SSH 连接（ctx.ssh）：master 复用 + 远端 Node helper JSON-RPC + 流转发


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/ssh/ssh/src/helper-entry.ts | 18 | — | node:url |
| packages/ssh/ssh/src/helper-processes.ts | 457 | RemoteProcesses | node:crypto, node:fs, node:path, node:net, node:tls |
| packages/ssh/ssh/src/helper.ts | 258 | runSshHelper, HelperTransport | node:crypto, node:fs, node:stream, @deepseek-ai/cordis, @deepseek-ai/dsh-fs |
| packages/ssh/ssh/src/index.ts | 295 | SshConnection, Config | node:child_process, node:fs, node:path, node:net, @deepseek-ai/cordis |
| packages/ssh/ssh/src/protocol.ts | 236 | RemoteOperationError, SshRpcPeer, SSH_PROTOCOL_VERSION, SSH_MAX_PROCESS_HANDLES, SSH_MAX_TEXT_STREAMS | node:crypto, node:events, node:stream, zod, @deepseek-ai/dsh-brand |
| packages/ssh/ssh/src/schemas.ts | 89 | outputSnapshotFrameLimit, processIdSchema, textStreamIdSchema, remotePath, targetSchema, infoSchema, pathInfoSchema, policySchema …等26项 | zod, @deepseek-ai/dsh-brand |
| packages/ssh/ssh/src/stream-security.ts | 48 | authenticateStream, SSH_STREAM_TLS_OPTIONS | node:tls, node:net |
| packages/ssh/ssh/tsdown.config.ts | 7 | defineConfig | tsdown |

#### packages/ssh/subprocess-ssh — @deepseek-ai/dsh-subprocess-ssh@0.2.1-alpha.1（1 文件 / 346 行）

职责：SSH 子进程 provider（四缝齐换=远端执行世界）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/ssh/subprocess-ssh/src/index.ts | 346 | SshSubprocessRuntime | node:stream, node:net, @deepseek-ai/cordis, @deepseek-ai/dsh-subprocess, @deepseek-ai/dsh-subprocess-local |

#### packages/storage/storage — @deepseek-ai/dsh-storage@0.2.1-alpha.1（4 文件 / 337 行）

职责：KV 存储缝：Backend/KvFacet + 命名注册表


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/storage/storage/src/backend.ts | 139 | UNIT_NAME_RE, StorageBackend, KvFacet, KvUnitDescriptor, KvUnit | — |
| packages/storage/storage/src/error.ts | 36 | StorageError, StorageErrorCode | — |
| packages/storage/storage/src/index.ts | 99 | storageBackendServiceKey, Storage, StorageForms | @deepseek-ai/cordis |
| packages/storage/storage/src/registry.ts | 63 | BackendRegistry | — |

#### packages/storage/storage-domain — @deepseek-ai/dsh-storage-domain@0.2.1-alpha.1（5 文件 / 863 行）

职责：单域单写链实现（先耐久后内存后事件）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/storage/storage-domain/src/domain.ts | 358 | DomainImpl, DomainGlobal, KvTable, DomainGlobalHandleOf, Domain | @deepseek-ai/cordis, @deepseek-ai/dsh-storage |
| packages/storage/storage-domain/src/error.ts | 54 | DomainError, DomainErrorCode, InvalidRecordDetail, DomainErrorOptions | — |
| packages/storage/storage-domain/src/events.ts | 49 | DomainChangedBase, DomainChangedPut, DomainChangedDeleted, DomainChanged | — |
| packages/storage/storage-domain/src/index.ts | 238 | apply, DomainFacility, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-storage |
| packages/storage/storage-domain/src/spec.ts | 164 | domainTable, defineDomain, descriptorOf, DomainGlobalSpec, DomainTableSpec, DomainSpec, TableKeyOf, TableValueOf …等9项 | zod, @deepseek-ai/dsh-storage |

#### packages/storage/storage-json — @deepseek-ai/dsh-storage-json@0.2.1-alpha.1（5 文件 / 765 行）

职责：JSON 文件后端（原子写）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/storage/storage-json/src/atomic.ts | 54 | writeAtomic | node:fs, node:path, node:crypto |
| packages/storage/storage-json/src/format.ts | 129 | serialize, parse, serializeRecord, parseRecord, UnitState | @deepseek-ai/dsh-storage |
| packages/storage/storage-json/src/index.ts | 120 | apply, JsonStorageBackend, name, inject, Config | node:fs, @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-storage |
| packages/storage/storage-json/src/per-record-unit.ts | 313 | openPerRecordUnit, PerRecordJsonUnit | node:fs, node:path, @deepseek-ai/dsh-storage |
| packages/storage/storage-json/src/single-unit.ts | 149 | openSingleUnit | node:fs, node:path, @deepseek-ai/dsh-storage |

#### packages/storage/storage-sqlite — @deepseek-ai/dsh-storage-sqlite@0.2.1-alpha.1（3 文件 / 446 行）

职责：SQLite 后端


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/storage/storage-sqlite/src/index.ts | 169 | apply, SqliteStorageBackend, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, node:sqlite, @deepseek-ai/dsh-storage |
| packages/storage/storage-sqlite/src/schema.ts | 120 | openDatabase, recordTableName, STORAGE_SQLITE_SCHEMA_VERSION, JournalMode | node:sqlite, node:fs, node:path, @deepseek-ai/dsh-storage |
| packages/storage/storage-sqlite/src/unit.ts | 157 | SqliteKvUnit | node:sqlite, @deepseek-ai/dsh-storage |

#### packages/subagent/subagent — @deepseek-ai/dsh-subagent@0.2.1-alpha.1（23 文件 / 5148 行）

职责：委托 agent 缝（ctx.subagents）：provider 注册表 + continuable 编排 + 目录投影


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/subagent/subagent/src/archive-admission.ts | 91 | installSubagentArchiveAdmission | @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-query, @deepseek-ai/dsh-workspace |
| packages/subagent/subagent/src/assistant-output.ts | 76 | finalAssistantOutput, AssistantOutputFold | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session |
| packages/subagent/subagent/src/catalog.ts | 166 | establishCatalogChild, SUBAGENT_CATALOG_VERSION, subagentCatalogProjectionDefinition, SubagentCatalogEvent, SubagentCatalogState | zod, @deepseek-ai/dsh-chunked-list, @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-projection |
| packages/subagent/subagent/src/child-agent.ts | 293 | resolveChildDepth, parentAgentOptionsForDelegation, resolveChildAgentOptions, childSessionMeta, applyChildComposition, captureDelegatedPolicyOverrides, appendDelegatedPolicyOverrides, SubagentDepthError …等12项 | @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-sandbox, @deepseek-ai/dsh-session, @deepseek-ai/dsh-system-prompt |
| packages/subagent/subagent/src/client.ts | 9 | — | — |
| packages/subagent/subagent/src/continuation-activation.ts | 903 | ChildLock, ContinuableActivationRegistry, Activation, MaterializeInputs | @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session, @deepseek-ai/dsh-tools |
| packages/subagent/subagent/src/continuation-messages.ts | 161 | createAgentMessage, withContinuableReturnGuidance, createSettlementMessage, AgentMessageSource, SubagentSettledMessageSource | @deepseek-ai/dsh-agent, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session |
| packages/subagent/subagent/src/continuation.ts | 553 | SubagentContinuationManager | node:crypto, @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-brand, @deepseek-ai/dsh-llm |
| packages/subagent/subagent/src/control-types.ts | 141 | SubagentPromptRequestId, SubagentCatalogRow, SubagentListEntry, SubagentAddress, SubagentPromptRequest, SubagentPromptReceipt, SubagentInterruptReceipt | @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-brand, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session, @deepseek-ai/dsh-workspace |
| packages/subagent/subagent/src/control.ts | 108 | validateControlRequest, rejectPrompt | @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-session, @deepseek-ai/dsh-typert-protocol, zod |
| packages/subagent/subagent/src/depth.ts | 52 | delegationDepthOf, assertSubagentMaxDepth | @deepseek-ai/dsh-agent |
| packages/subagent/subagent/src/descriptor.ts | 324 | snapshotSubagentDescriptor, foldSubagentDescriptor, SUBAGENT_DESCRIPTOR_VERSION, OneShotSubagentDescriptorData, ContinuableSubagentDescriptorData, SubagentDescriptorData, OneShotSubagentDescriptorInput, ContinuableSubagentDescriptorInput …等9项 | @deepseek-ai/dsh-util-values, @deepseek-ai/dsh-session, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-tools |
| packages/subagent/subagent/src/error.ts | 16 | SubagentError | @deepseek-ai/dsh-llm |
| packages/subagent/subagent/src/inbox.ts | 71 | SubagentInbox, SubagentDelivery | @deepseek-ai/dsh-agent, @deepseek-ai/dsh-session |
| packages/subagent/subagent/src/index.ts | 662 | SubagentRuntime, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-attachment, @deepseek-ai/dsh-scope, @deepseek-ai/dsh-tools |
| packages/subagent/subagent/src/internal.ts | 111 | markAdjacentAgentSendMessageTool, isAdjacentAgentSendMessageTool, queueHostSubagentPrompt, steerHostSubagentPrompt, adjacentAgentSendMessageTool, deliverSubagentPrompt, HostPromptDeliverer | @deepseek-ai/dsh-agent, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session, @deepseek-ai/dsh-tools |
| packages/subagent/subagent/src/lifecycle.ts | 273 | createLifecycleEmitter, observeRun, createActivationObserver, ActivationTerminal, ActivationObserver, LifecycleEmitter | node:crypto, @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session |
| packages/subagent/subagent/src/list-children.ts | 134 | listChildren, listDescendants, SubagentDescendantListEntry | @deepseek-ai/cordis, @deepseek-ai/dsh-session |
| packages/subagent/subagent/src/out-of-process.ts | 260 | assertPositiveFinite, assertUsableCwd, validateConfiguredCwd, resolveChildCwd, settleRunResult, subprocessRunHandle, NO_START_CAPABILITIES, RunResultSettlement …等9项 | node:fs, node:path, @deepseek-ai/dsh-llm |
| packages/subagent/subagent/src/projection-types.ts | 86 | SubagentCatalogEntry, SubagentTimingProjection, SubagentIdentityProjection | @deepseek-ai/dsh-session |
| packages/subagent/subagent/src/projection.ts | 191 | subagentTimingProjectionDefinition, subagentIdentityProjectionDefinition, TimingState | zod, @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-projection |
| packages/subagent/subagent/src/run-settlement.ts | 76 | settleRun | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-jobs |
| packages/subagent/subagent/src/types.ts | 391 | SubagentRunId, ContinuableStartSpec, ContinuableStart, SubagentInterruptAuthority, SubagentSendMessageOptions, SubagentRunInfo, SubagentRunEndInfo, SubagentCapabilities …等17项 | @deepseek-ai/dsh-agent, @deepseek-ai/dsh-brand, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session, @deepseek-ai/dsh-tools |

#### packages/subagent/subagent-acp — @deepseek-ai/dsh-subagent-acp@0.2.1-alpha.1（2 文件 / 827 行）

职责：ACP 协议子代理 provider


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/subagent/subagent-acp/src/index.ts | 207 | apply, name, inject, Config | node:fs, node:path, @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-subagent |
| packages/subagent/subagent-acp/src/run.ts | 620 | acpConfigurationFailure, disposeAcpChild, acpStopReason, acpContentText, toAcpPrompt, startAcpRun, DEFAULT_DISPOSE_EOF_GRACE_MS, DEFAULT_DISPOSE_GRACE_MS …等10项 | node:crypto, node:stream, @agentclientprotocol/sdk, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-brand |

#### packages/subagent/subagent-claude-code — @deepseek-ai/dsh-subagent-claude-code@0.2.1-alpha.1（3 文件 / 906 行）

职责：Claude Code CLI 子代理 provider


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/subagent/subagent-claude-code/src/index.ts | 158 | apply, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-timeout, @deepseek-ai/dsh-subagent |
| packages/subagent/subagent-claude-code/src/process.ts | 160 | sdkEnvironmentOverlay, claudeSpawnSpec, ManagedClaudeCodeProcess | node:events, @anthropic-ai/claude-agent-sdk, @deepseek-ai/dsh-subprocess |
| packages/subagent/subagent-claude-code/src/run.ts | 588 | claudeCodeStartupFailure, textTask, successfulResult, consumeClaudeQuery, disposeClaudeCodeChild, claudeQueryOptions, startClaudeCodeRun, DEFAULT_DISPOSE_GRACE_MS …等12项 | node:crypto, @anthropic-ai/claude-agent-sdk, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-brand, @deepseek-ai/dsh-session |

#### packages/subagent/subagent-codex — @deepseek-ai/dsh-subagent-codex@0.2.1-alpha.1（3 文件 / 1285 行）

职责：Codex CLI 子代理 provider


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/subagent/subagent-codex/src/index.ts | 141 | apply, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-timeout, @deepseek-ai/dsh-subagent |
| packages/subagent/subagent-codex/src/run.ts | 440 | codexStartupFailure, codexAppServerArgv, textTask, disposeCodexChild, startCodexRun, DEFAULT_DISPOSE_GRACE_MS, CODEX_PERMISSION_MODES, DEFAULT_CODEX_PERMISSION_MODE …等10项 | node:crypto, node:fs, node:module, node:path, @deepseek-ai/dsh-brand |
| packages/subagent/subagent-codex/src/wire.ts | 704 | CodexAppServerWire, CodexWireFailureFacts | node:stream, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-subagent, @deepseek-ai/dsh-sdk-protocol |

#### packages/subagent/subagent-dsh-sdk — @deepseek-ai/dsh-subagent-dsh-sdk@0.2.1-alpha.1（2 文件 / 561 行）

职责：dsh SDK 子进程子代理 provider


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/subagent/subagent-dsh-sdk/src/index.ts | 201 | apply, name, inject, Config | @deepseek-ai/cordis, node:fs, node:path, @deepseek-ai/schemastery, @deepseek-ai/dsh-agent |
| packages/subagent/subagent-dsh-sdk/src/run.ts | 360 | sdkConfigurationFailure, sdkChildOutcome, startSdkRun, DEFAULT_DISPOSE_EOF_GRACE_MS, DEFAULT_DISPOSE_GRACE_MS, DEFAULT_SHUTDOWN_TIMEOUT_MS, internals, SdkRunSpec | node:crypto, @deepseek-ai/dsh-brand, @deepseek-ai/dsh-sdk-client, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session |

#### packages/subagent/subagent-fork-in-process — @deepseek-ai/dsh-subagent-fork-in-process@0.2.1-alpha.1（1 文件 / 97 行）

职责：fork provider：父日志平衡前缀作 seed


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/subagent/subagent-fork-in-process/src/index.ts | 97 | apply, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-session, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-subagent |

#### packages/subagent/subagent-in-process-driver — @deepseek-ai/dsh-subagent-in-process-driver@0.2.1-alpha.1（2 文件 / 382 行）

职责：进程内子代理公共合成层（策略捕获/组合/结构化输出）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/subagent/subagent-in-process-driver/src/index.ts | 239 | startInProcessRun, InProcessRunOptions | node:crypto, @deepseek-ai/cordis, @deepseek-ai/dsh-brand, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-session |
| packages/subagent/subagent-in-process-driver/src/structured.ts | 143 | attachStructuredRuntime, STRUCTURED_OUTPUT_TOOL, STRUCTURED_OUTPUT_INSTRUCTION, StructuredAttachment | @deepseek-ai/cordis, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-tools |

#### packages/subagent/subagent-spawn-in-process — @deepseek-ai/dsh-subagent-spawn-in-process@0.2.1-alpha.1（1 文件 / 71 行）

职责：spawn provider：全新进程内子代理


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/subagent/subagent-spawn-in-process/src/index.ts | 71 | apply, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-subagent, @deepseek-ai/dsh-subagent-in-process-driver |

#### packages/subagent/tool-subagent — @deepseek-ai/dsh-tool-subagent@0.2.1-alpha.1（6 文件 / 1188 行）

职责：subagent 模型工具（provider 选择 + 模型选择）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/subagent/tool-subagent/src/index.ts | 712 | apply, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-scope, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-agent |
| packages/subagent/tool-subagent/src/list-models.ts | 114 | registerListSubagentModels | @deepseek-ai/cordis, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-tools |
| packages/subagent/tool-subagent/src/model-selection-settings.ts | 64 | SubagentModelSelectionConfig, name, SubagentModelSelectionSettings, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery |
| packages/subagent/tool-subagent/src/model-selection-state.ts | 82 | subagentModelSelectionPolicy, recordSubagentModelSelection, subagentModelSelectionProjectionDefinition | zod, @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-projection |
| packages/subagent/tool-subagent/src/model-selection.ts | 197 | modelRouteKey, assertAllowedModelRoutes, hasDelegationModelRequest, requestedAgentOptions, assertAllowedModelSelection, hasConfiguredLlmSelection, preflightChildLlmRoute, AllowedModelRouteSchema …等11项 | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-agent, @deepseek-ai/schemastery |
| packages/subagent/tool-subagent/tsdown.config.ts | 19 | defineConfig | tsdown |

#### packages/subagent/tool-subagent-control — @deepseek-ai/dsh-tool-subagent-control@0.2.1-alpha.1（2 文件 / 292 行）

职责：send_message/interrupt_agent/list_agents 全局工具


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/subagent/tool-subagent-control/src/index.ts | 113 | apply, name, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-brand, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session |
| packages/subagent/tool-subagent-control/src/list-agents.ts | 179 | apply, name, inject | @deepseek-ai/cordis, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-session, @deepseek-ai/dsh-subagent |

#### packages/subprocess/subprocess — @deepseek-ai/dsh-subprocess@0.2.1-alpha.1（4 文件 / 517 行）

职责：子进程基座缝（ctx.subprocess）：spawn/spawnTerminal/环境清洗


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/subprocess/subprocess/src/control.ts | 25 | openInheritedControlChannel, SUBPROCESS_CONTROL_FD, SUBPROCESS_CONTROL_ENV | node:net, node:stream |
| packages/subprocess/subprocess/src/index.ts | 178 | scrubbedParentEnv, SubprocessRuntime, SubprocessExecutableNotFoundError, SENSITIVE_ENV_PATTERN | @deepseek-ai/cordis, @deepseek-ai/dsh-http-proxy |
| packages/subprocess/subprocess/src/types.ts | 298 | DSH_ENV_PREFIX, DshEnvironmentKey, DshEnvironment, CollectedOutput, SubprocessStdinMode, SubprocessCollect, SubprocessOutputMode, SubprocessStdio …等20项 | node:stream |
| packages/subprocess/subprocess/tsdown.config.ts | 16 | defineConfig | tsdown |

#### packages/subprocess/subprocess-local — @deepseek-ai/dsh-subprocess-local@0.2.1-alpha.1（18 文件 / 4833 行）

职责：本地实现：进程树收容（systemd scope/Job Object/PGID）+ 输出收集


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/subprocess/subprocess-local/scripts/ensure-spawn-helper.mjs | 17 | — | node:fs, node:path, node:url |
| packages/subprocess/subprocess-local/src/bin.ts | 26 | runSelectedSubprocessRunner | — |
| packages/subprocess/subprocess-local/src/control-spawn.ts | 36 | controlPipe, controlEnvironment | @deepseek-ai/dsh-subprocess, node:stream |
| packages/subprocess/subprocess-local/src/index.ts | 341 | LocalSubprocessRuntime | node:fs, node:os, node:path, node:stream, @deepseek-ai/cordis |
| packages/subprocess/subprocess-local/src/linux-execve.ts | 80 | loadLinuxExecve, LinuxExecve | node:util, @deepseek-ai/dsh-subprocess, @deepseek-ai/dsh-lazy-require, koffi |
| packages/subprocess/subprocess-local/src/linux-scope.ts | 613 | probeLinuxBootstrap, probeLinuxScope, probeLinuxManager, probeLinuxNative, signalLinuxDirectProcess, prepareLinuxTerminalScope, launchLinuxScope, LinuxScopeInternals …等9项 | node:child_process, node:crypto, node:fs, node:timers, @deepseek-ai/dsh-subprocess |
| packages/subprocess/subprocess-local/src/managed-owner.ts | 57 | waitWithAbort, BoundProcessOwner, ManagedProcessLaunch | node:stream, @deepseek-ai/dsh-subprocess |
| packages/subprocess/subprocess-local/src/output.ts | 314 | logSpillFailure, prepareManagedProcessBinding, OutputCollector, SpillFailureReporter, SpillOptions, ManagedProcessBinding | node:crypto, node:fs, node:path, node:os, @deepseek-ai/dsh-subprocess |
| packages/subprocess/subprocess-local/src/process-inspector.ts | 552 | parseProcStat, linuxProcessGroupHasLiveMembers, createProcessInspector, ProcessIdentity, ProcessSnapshot, ProcessInspector, ProcessInspectorInternals | node:fs, node:child_process, @deepseek-ai/dsh-subprocess |
| packages/subprocess/subprocess-local/src/runner-launch.ts | 316 | spawnRunnerInvocation, runnerInvocationAvailable, runnerEnvironment, consumeRunnerSelection, parseRunnerTargetArgv, runnerStdio, resolveWindowsExecutable, targetEnvironment …等11项 | node:child_process, node:fs, node:path, node:util, node:url |
| packages/subprocess/subprocess-local/src/runner-protocol.ts | 274 | createLinuxLaunchFiles, linuxLaunchFilesFromLocator, consumeLinuxLaunchRequest, writeLinuxStartupError, readLinuxStartupError, parseWindowsStartRequest, isWindowsTerminateRequest, parseWindowsRunnerResult …等18项 | node:fs, node:os, node:path |
| packages/subprocess/subprocess-local/src/shell-activity.ts | 132 | prepareShellActivity, ShellActivity | node:fs, node:os, node:path, @deepseek-ai/dsh-subprocess |
| packages/subprocess/subprocess-local/src/spawn-runner.ts | 491 | runSpawnRunner, reportSpawnRunnerFailure, SpawnRunnerInternals | @deepseek-ai/dsh-subprocess, node:fs, @deepseek-ai/dsh-win32-process |
| packages/subprocess/subprocess-local/src/spawn.ts | 493 | childEnv, killGroup, taskkillProcessTree, validateSubprocessSpec, bindManagedProcess, spawnSubprocess, SpawnInternals, LocalSubprocessHandle | node:child_process, node:stream, node:timers, @deepseek-ai/dsh-subprocess, @deepseek-ai/dsh-timeout |
| packages/subprocess/subprocess-local/src/terminal.ts | 479 | LocalTerminalHandle | node:buffer, node:os, node:stream, node-pty, @deepseek-ai/dsh-subprocess |
| packages/subprocess/subprocess-local/src/windows-inspector.ts | 347 | windowsProcessTree, createWindowsProcessInspector, isInvalidHandle, WindowsProcessInspector, ProcessEntry, WindowsProcessState, WindowsProcessInspectorInternals, NativePtr | node:child_process, @deepseek-ai/dsh-subprocess, @deepseek-ai/dsh-lazy-require, koffi |
| packages/subprocess/subprocess-local/src/windows-job.ts | 248 | probeWindowsJob, launchWindowsJob, WindowsJobInternals | node:child_process, node:fs, node:os, node:stream, @deepseek-ai/dsh-subprocess |
| packages/subprocess/subprocess-local/tsdown.config.ts | 17 | defineConfig | tsdown |

#### packages/subprocess/win32-process — @deepseek-ai/dsh-win32-process@0.2.1-alpha.1（7 文件 / 1192 行）

职责：Windows 进程 FFI 辅助


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/subprocess/win32-process/src/abi.ts | 53 | STARTF_USESTDHANDLES, STARTF_USESHOWWINDOW, SW_HIDE, HANDLE_FLAG_INHERIT, INFINITE, WAIT_TIMEOUT, CREATE_SUSPENDED, CREATE_UNICODE_ENVIRONMENT …等25项 | — |
| packages/subprocess/win32-process/src/control-stdio.ts | 48 | inheritedControlStdio, InheritedControlStdio | — |
| packages/subprocess/win32-process/src/errors.ts | 15 | Win32Error | — |
| packages/subprocess/win32-process/src/ffi.ts | 384 | isNullPtr, startupInfoType, processInformationType, allocPtrSlot, allocUint32, decodePtr, decodeUint32, allocStartupInfo …等22项 | — |
| packages/subprocess/win32-process/src/index.ts | 39 | — | — |
| packages/subprocess/win32-process/src/koffi.ts | 11 | requireKoffi, Koffi | koffi, @deepseek-ai/dsh-lazy-require |
| packages/subprocess/win32-process/src/process.ts | 642 | quoteArg, buildCommandLine, spawnPipedProcess, drainPipe, waitForProcessExit, spawnInheritedJobProcess, spawnCurrentTokenJobProcess, probeCurrentTokenJobSupport …等17项 | — |

#### packages/telemetry/otel — @deepseek-ai/dsh-otel@0.2.1-alpha.1（5 文件 / 450 行）

职责：OTel 通道工厂（ctx.otel）：产品事件 + 授权会话日志两通道


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/telemetry/otel/src/event-log.ts | 94 | EventLogReporter, OTelEventScalar, OTelEventRecord, EventLogOptions | @opentelemetry/api, node:events, @opentelemetry/api-logs, @opentelemetry/core, @opentelemetry/resources |
| packages/telemetry/otel/src/event-transport.ts | 58 | createEventLogExporter | node:https, node:zlib, got, @opentelemetry/otlp-exporter-base, @opentelemetry/otlp-transformer |
| packages/telemetry/otel/src/index.ts | 35 | OTel | @deepseek-ai/cordis |
| packages/telemetry/otel/src/session-log.ts | 225 | resolveSessionLogLimits, SessionLogReporter, SESSION_LOG_MAX_REQUEST_BYTES, SessionLogRecord, SessionLogOptions | @deepseek-ai/dsh-session, @opentelemetry/api, @opentelemetry/api-logs, @opentelemetry/core, @opentelemetry/otlp-exporter-base |
| packages/telemetry/otel/src/transport.ts | 38 | createLogExporter, logTransportOptions | @opentelemetry/otlp-exporter-base, @opentelemetry/otlp-transformer, @opentelemetry/sdk-logs |

#### packages/terminal/terminal — @deepseek-ai/dsh-terminal@0.2.1-alpha.1（2 文件 / 655 行）

职责：持久终端注册表（ctx.terminals）：owner 作用域 + 排他交互


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/terminal/terminal/src/index.ts | 477 | TerminalSessionId, TerminalError, TerminalSessionService, TerminalErrorCode | @deepseek-ai/cordis, @deepseek-ai/dsh-agent |
| packages/terminal/terminal/src/types.ts | 178 | TerminalBackendCleanupError, TerminalSessionIdValue, TerminalWaitReason, TerminalSignal, TerminalSessionStatus, TerminalSpawnRequest, TerminalBackendSpawnSpec, TerminalSendRequest …等18项 | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-agent |

#### packages/terminal/terminal-bash — @deepseek-ai/dsh-terminal-bash@0.2.1-alpha.1（4 文件 / 1365 行）

职责：bash/pwsh PTY 后端：沙箱 confine + OSC 133 提示符标记


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/terminal/terminal-bash/src/config.ts | 143 | resolveConfig, validateConfig, DEFAULT_BASH_SHELL, DEFAULT_BASH_ARGS, DEFAULT_PWSH_ARGS, Config, ShellDialect, ResolvedConfig | @deepseek-ai/schemastery, @deepseek-ai/dsh-pwsh-local |
| packages/terminal/terminal-bash/src/index.ts | 239 | apply, BashTerminalBackend, name, inject, PWSH_PROMPT_SETUP | @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-session, @deepseek-ai/dsh-terminal, @deepseek-ai/dsh-subprocess |
| packages/terminal/terminal-bash/src/sanitize.ts | 189 | normalizeTerminalText, TerminalSanitizer, PROMPT_MARKER_PREFIX, CONTROLLED_PROMPT, SanitizedChunk | node:buffer |
| packages/terminal/terminal-bash/src/session.ts | 794 | LocalPtySession | node:buffer, @xterm/headless, @deepseek-ai/dsh-lazy-require, @deepseek-ai/dsh-subprocess, @deepseek-ai/dsh-terminal |

#### packages/terminal/tool-terminal — @deepseek-ai/dsh-tool-terminal@0.2.1-alpha.1（3 文件 / 615 行）

职责：terminal_open/send/read/signal 工具


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/terminal/tool-terminal/src/background.ts | 32 | sendSource | @deepseek-ai/dsh-jobs, @deepseek-ai/dsh-terminal |
| packages/terminal/tool-terminal/src/index.ts | 405 | apply, name, inject, DEFAULT_MAX_RESULT_BYTES, MIN_MAX_RESULT_BYTES, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-terminal |
| packages/terminal/tool-terminal/src/render.ts | 178 | boundTerminalText, renderSpawn, renderSend, renderSendRead, renderRead, renderList | @deepseek-ai/dsh-output-retention |

#### packages/todo/tool-todo — @deepseek-ai/dsh-tool-todo@0.2.1-alpha.1（3 文件 / 272 行）

职责：todo_write 工具（整表替换 + todos 投影）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/todo/tool-todo/src/client.ts | 11 | — | — |
| packages/todo/tool-todo/src/index.ts | 213 | apply, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, zod, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-session-projection |
| packages/todo/tool-todo/src/types.ts | 48 | TodoItem | — |

#### packages/typert/generator — @deepseek-ai/dsh-typert-generator@0.2.1-alpha.1（8 文件 / 6630 行）

职责：类型图生成器：WorkspaceAnalyzer/FaceModelEmitter/cordis-catalog


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/typert/generator/src/analyzer.ts | 3286 | TypertAnalysisError, WorkspaceCaches, WorkspaceAnalyzer, AnalysisMode, WorkspaceAnalyzerOptions, DiscoveredTypertPackage, ParsedConfig, PackageRegistration | node:fs, node:path, typescript |
| packages/typert/generator/src/cordis-catalog.ts | 1070 | projectCordisCatalog, collectEvents, collectServices, queryServiceApi, queryEventApi, renderPageRegion, renderInheritedPage, CordisCatalogProjector …等26项 | — |
| packages/typert/generator/src/emitter.ts | 1129 | TypertEmitError, FaceModelEmitter, $, TYPERT, TYPERT_REMOTE, ModelEmitResult, RemoteModelEmitResult | node:buffer, node:path, @jridgewell/gen-mapping |
| packages/typert/generator/src/index.ts | 17 | — | — |
| packages/typert/generator/src/model.ts | 443 | childTypeNodeIds, TypertFace, TypeNodeId, SymbolId, KeywordTypeName, TypeOperatorName, SourceLocation, ExportModel …等41项 | — |
| packages/typert/generator/src/renderer.ts | 366 | TypeGraphRenderError, TypeGraphRenderer, $ | — |
| packages/typert/generator/src/tsdown-plugin.ts | 163 | typertPlugin, TypertPluginOptions | node:fs, node:path, typescript |
| packages/typert/generator/src/workspace.ts | 156 | WorkspaceTypertGenerator, WorkspaceEmitResult, WorkspaceTypertGeneratorOptions | node:fs, node:path |

#### packages/typert/loader — @deepseek-ai/dsh-typert-loader@0.2.1-alpha.1（1 文件 / 470 行）

职责：按 Loader 条目自动导入包 ./typert 导出并注册


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/typert/loader/src/index.ts | 470 | validateTypertManifest, apply, TYPERT_HOST_EXPORT, name, inject, Config | node:fs, node:module, node:path, node:url, @deepseek-ai/cordis |

#### packages/typert/protocol — @deepseek-ai/dsh-typert-protocol@0.2.1-alpha.1（5 文件 / 1196 行）

职责：Typert Remote 契约类型（InvocationDescriptor/RemoteResult/RemoteStream）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/typert/protocol/src/index.ts | 349 | isTypertRemoteSegment, bindTypertRemote, Remote, RemoteScope, remoteMethods, TypertRemoteService, TypertGatewayBindingOptions, TypertGatewayBinding …等11项 | @deepseek-ai/cordis |
| packages/typert/protocol/src/json-value.ts | 54 | isRemoteJsonValue, isRemoteUplinkItem | — |
| packages/typert/protocol/src/owned-value.ts | 40 | typertOwnedValue, isTypertOwnedValue, TYPERT_OWNED_VALUE, TypertOwnedValue | — |
| packages/typert/protocol/src/remote-error.ts | 50 | remoteErrorOf, RemoteError | — |
| packages/typert/protocol/src/types.ts | 703 | TypertLookup, TypertLookupHost, TypertLookupWire, TypertContext, TypertContextWire, TypertLookupMap, TypertContextMap, TypertRemoteMap …等48项 | @deepseek-ai/cordis, @deepseek-ai/dsh-brand |

#### packages/typert/registry — @deepseek-ai/dsh-typert-registry@0.2.1-alpha.1（5 文件 / 917 行）

职责：运行时注册表（ctx.typert）：五 store + 调用校验


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/typert/registry/src/client/index.ts | 16 | apply, inject | @deepseek-ai/cordis |
| packages/typert/registry/src/index.ts | 28 | — | zod, @deepseek-ai/dsh-typert-protocol |
| packages/typert/registry/src/service.ts | 750 | typertKey, typertPackageKey, typertEndpoint, TypertRegistry | @deepseek-ai/cordis, zod, @deepseek-ai/dsh-typert-protocol |
| packages/typert/registry/src/types.ts | 119 | TypertFace, TypertDocTag, TypertDocumentation, TypertMemberModel, TypertTypeModel, TypertServiceModel, TypertEventModel, TypertObjectModel …等15项 | zod, @deepseek-ai/dsh-typert-protocol |
| packages/typert/registry/tsdown.config.ts | 4 | clientBundle | — |

#### packages/util/atomic-write — @deepseek-ai/dsh-atomic-write@0.2.1-alpha.1（1 文件 / 269 行）

职责：原子写 + 跨进程文件锁（flock）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/util/atomic-write/src/index.ts | 269 | writeFileAtomic, withFileLock, WriteFileAtomicOptions, FileLockOptions | node:crypto, node:fs, node:path |

#### packages/util/brand — @deepseek-ai/dsh-brand@0.2.1-alpha.1（1 文件 / 40 行）

职责：Branded<B> 名义类型构造器


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/util/brand/src/index.ts | 40 | brandString, brandNumber, Branded, BrandedNumber | — |

#### packages/util/chunked-list — @deepseek-ai/dsh-chunked-list@0.2.1-alpha.1（1 文件 / 59 行）

职责：分块列表原语


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/util/chunked-list/src/index.ts | 59 | appendChunkedList, iterateChunkedList, chunkedListSchema, ChunkedList | zod |

#### packages/util/code-language — @deepseek-ai/dsh-util-code-language@0.2.1-alpha.1（1 文件 / 234 行）

职责：代码语言识别辅助


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/util/code-language/src/index.ts | 234 | languageForPath, readLangHintForPath, CODE_HIGHLIGHT_EXTENSIONS | — |

#### packages/util/crypto — @deepseek-ai/dsh-util-crypto@0.2.1-alpha.1（1 文件 / 42 行）

职责：RFC 9562 UUID v4


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/util/crypto/src/index.ts | 42 | bytesToBase64, randomUUID, Uuid | — |

#### packages/util/deque — @deepseek-ai/dsh-deque@0.2.1-alpha.1（2 文件 / 133 行）

职责：双端队列


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/util/deque/benchmarks/drain.ts | 37 | — | node:perf_hooks |
| packages/util/deque/src/index.ts | 96 | Deque | — |

#### packages/util/home-paths — @deepseek-ai/dsh-home-paths@0.2.1-alpha.1（1 文件 / 124 行）

职责：resolveDshHome（$DSH_HOME > ~/.dsh）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/util/home-paths/src/index.ts | 124 | canonicalizeWatchPath, defaultDshHome, expandHomePath, resolveDshHome, dshHomePath, dshCachePath, dshHomeDisplay, DSH_HOME_DIR_NAME …等10项 | node:fs, node:os, node:path |

#### packages/util/http-proxy — @deepseek-ai/dsh-http-proxy@0.2.1-alpha.1（3 文件 / 684 行）

职责：出站代理策略与安装（启动期生效）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/util/http-proxy/src/index.ts | 24 | — | — |
| packages/util/http-proxy/src/install.ts | 316 | proxyRouteFor, proxyEnvironmentForChild, installProxyFromEnvironment, clearedProxyEnv, ProxyRoute | undici |
| packages/util/http-proxy/src/policy.ts | 344 | isSupportedProxyUrl, isLoopbackHost, bypassesProxy, resolveProxyPolicy, proxyForUrl, LOOPBACK_NO_PROXY, POLICY_ENV_NAMES, PROXY_ENV_NAMES …等13项 | — |

#### packages/util/launch-environment — @deepseek-ai/dsh-launch-environment@0.2.1-alpha.1（1 文件 / 138 行）

职责：启动环境快照类型


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/util/launch-environment/src/index.ts | 138 | createLaunchEnvironmentSnapshot, launchEnvironmentOf, launchedThroughSsh, DSH_LAUNCH_ENVIRONMENT_KEY, LaunchEnvironmentSource, LaunchEnvironmentEntry, LaunchEnvironmentSnapshot, LaunchEnvironmentLayerInput | @deepseek-ai/cordis |

#### packages/util/lazy-require — @deepseek-ai/dsh-lazy-require@0.2.1-alpha.1（1 文件 / 25 行）

职责：懒 require 辅助


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/util/lazy-require/src/index.ts | 25 | createLazyRequire | node:module |

#### packages/util/native-command — @deepseek-ai/dsh-native-command@0.2.1-alpha.1（8 文件 / 1044 行）

职责：无 shell 直启宿主命令 / .desktop 解析


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/util/native-command/src/desktop-entry.ts | 77 | desktopEntryFields, desktopDataDirectories, desktopApplicationIcon, DesktopIcon | node:fs, node:path |
| packages/util/native-command/src/file-applications-linux.ts | 67 | linuxFileApplications | node:fs, node:os, node:path |
| packages/util/native-command/src/file-applications-windows.ts | 277 | windowsFileApplications | node:fs, node:os, node:path |
| packages/util/native-command/src/file-applications.ts | 201 | nativeFileApplications, openNativeFileApplication | AppKit |
| packages/util/native-command/src/index.ts | 26 | — | — |
| packages/util/native-command/src/path-opener.ts | 316 | canOpenNativePath, openNativePath, openNativeAssociatedPath, openNativeTextFile, nativeFileManager, revealNativePath, PathOpenerRunner, PathOpenerInternals …等9项 | node:os, node:path, node:url |
| packages/util/native-command/src/runner.ts | 45 | runNativeCommand, NativeCommandRunner | node:child_process |
| packages/util/native-command/src/types.ts | 35 | parseNativeFileApplications, NativeFileApplication | — |

#### packages/util/output-retention — @deepseek-ai/dsh-output-retention@0.2.1-alpha.1（1 文件 / 461 行）

职责：输出保留策略原语


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/util/output-retention/src/index.ts | 461 | describeOmitted, formatRetentionNotice, truncateWithoutSplittingSurrogatePair, ItemRetainer, TextRetainer, Omitted, PushDecision, RetainedItems …等12项 | — |

#### packages/util/package-manifest — @deepseek-ai/dsh-package-manifest@0.2.1-alpha.1（2 文件 / 111 行）

职责：包清单解析辅助


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/util/package-manifest/src/index.ts | 16 | — | — |
| packages/util/package-manifest/src/types.ts | 95 | DshPackageManifest, DshManifest, LocalizedText, PluginLocalizedMeta, DshEnginesManifest, DshBundleManifest, DshProfileManifest, DshClientManifest | — |

#### packages/util/time — @deepseek-ai/dsh-util-time@0.2.1-alpha.1（1 文件 / 34 行）

职责：时间格式化辅助


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/util/time/src/index.ts | 34 | canonicalClientTimeZone | — |

#### packages/util/timeout — @deepseek-ai/dsh-timeout@0.2.1-alpha.1（1 文件 / 191 行）

职责：deadline 信号融合


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/util/timeout/src/index.ts | 191 | clampTimeout, deadline, idleWatchdog, timeoutOf, TimeoutReason, MAX_TIMER_DELAY_MS, Deadline, IdleWatchdog | — |

#### packages/util/values — @deepseek-ai/dsh-util-values@0.2.1-alpha.1（2 文件 / 976 行）

职责：跨 realm JSON 判定与快照（snapshotJsonValue）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/util/values/src/index.ts | 309 | assertNever, snapshotJsonValue, isJsonValue, deepEqualJson, deepFreeze, WeakMapWithValues, JsonValue | — |
| packages/util/values/src/partial-json.ts | 667 | PartialArguments, LengthReadOptions | — |

#### packages/util/workspace-path — @deepseek-ai/dsh-util-workspace-path@0.2.1-alpha.1（2 文件 / 238 行）

职责：浏览器安全的工作区路径与 file-address


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/util/workspace-path/src/file-address.ts | 113 | sessionFileAddress, absoluteFileAddress, parseFileAddress, FileAddress | — |
| packages/util/workspace-path/src/index.ts | 125 | isAbsoluteWorkspacePath, resolveWorkspacePath, abbreviateHomePath, workspaceTitleOf, pathPartsOf, fileAddressFor, relativizeToCwd, fileMediaUrl | — |

#### packages/web/tool-web — @deepseek-ai/dsh-tool-web@0.2.1-alpha.1（4 文件 / 998 行）

职责：web_fetch/web_search 工具


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/web/tool-web/src/fetch.ts | 516 | parseFetchArgs, formatFetchOutput, presentFetchCall, fetchMetaFromValue, fetchMetaFromResult, presentFetchResult, applyWebFetchTool, WebFetchMeta | @deepseek-ai/cordis, turndown, @joplin/turndown-plugin-gfm, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-web |
| packages/web/tool-web/src/index.ts | 96 | apply, name, inject, DEFAULT_WEB_TOOL_TIMEOUT_MS, DEFAULT_FETCH_MAX_OUTPUT_CHARS, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-web |
| packages/web/tool-web/src/search.ts | 378 | parseSearchArgs, formatSearchOutput, presentSearchCall, searchMetaFromValue, searchMetaFromResult, presentSearchResult, applyWebSearchTool, WEB_SEARCH_MAX_RESULTS …等10项 | @deepseek-ai/cordis, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-util-values, @deepseek-ai/dsh-web |
| packages/web/tool-web/src/trust.ts | 8 | EXTERNAL_WEB_CONTENT_NOTICE | — |

#### packages/web/web — @deepseek-ai/dsh-web@0.2.1-alpha.1（2 文件 / 334 行）

职责：Web 能力运行时（ctx.web）：search/fetch 调用时选 provider


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/web/web/src/index.ts | 203 | WebRuntime, WebRuntimeConfig | @deepseek-ai/cordis, @deepseek-ai/schemastery |
| packages/web/web/src/types.ts | 131 | WebError, WebSearchRequest, WebSearchResult, WebSearchSource, WebFetchRequest, WebFetchResult, WebFetchBody, WebSearchProvider …等9项 | @deepseek-ai/dsh-llm |

#### packages/web/web-fetch-http — @deepseek-ai/dsh-web-fetch-http@0.2.1-alpha.1（4 文件 / 788 行）

职责：HTTP fetch provider：SSRF 防护 + 同源重定向限制


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/web/web-fetch-http/src/index.ts | 95 | apply, DEFAULT_USER_AGENT, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-web |
| packages/web/web-fetch-http/src/network.ts | 302 | isPublicIpAddress, resolvePublicAddresses, isNonPublicIpLiteral, requestPinned, requestVia, createPinnedLookup, publicHttpNetwork, PublicAddress …等10项 | node:dns, node:net, undici, ipaddr.js, @deepseek-ai/dsh-web |
| packages/web/web-fetch-http/src/policy.ts | 119 | parseFetchUrl, validateFetchUrl, isSameOrigin, classifyContentType, parseCharset, decoderForCharset, WEB_FETCH_MAX_URL_LENGTH, FetchableKind | @deepseek-ai/dsh-web |
| packages/web/web-fetch-http/src/provider.ts | 272 | HttpFetchProvider, LOCAL_FETCH_PROVIDER_ID, HttpFetchLimits, HttpFetchResolver | @deepseek-ai/dsh-web, @deepseek-ai/dsh-timeout, undici, @deepseek-ai/dsh-http-proxy |

#### packages/web/web-search-deepseek — @deepseek-ai/dsh-web-search-deepseek@0.2.1-alpha.1（3 文件 / 626 行）

职责：DeepSeek 搜索 provider（Anthropic 兼容 + 服务端 web_search 工具）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/web/web-search-deepseek/src/index.ts | 146 | apply, name, inject, Config, WEB_SEARCH_DEEPSEEK_SETTINGS_NAMESPACE | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-credentials, @deepseek-ai/dsh-deepseek-account |
| packages/web/web-search-deepseek/src/provider.ts | 430 | citationSnippets, mapAnthropicResponse, DeepSeekSearchProvider, DEEPSEEK_PROVIDER_ID, DEEPSEEK_DEFAULT_BASE_URL, DEEPSEEK_DEFAULT_MODEL, DEEPSEEK_DEFAULT_API_VERSION, DEEPSEEK_DEFAULT_MAX_TOKENS …等11项 | @deepseek-ai/dsh-web, @deepseek-ai/dsh-credentials, @deepseek-ai/dsh-session |
| packages/web/web-search-deepseek/src/types.ts | 50 | WebSearchResultItem, WebSearchToolResultBlock, CitationLocation, TextBlock, ContentBlock, AnthropicResponse, AnthropicError | — |

#### packages/web/web-search-exa — @deepseek-ai/dsh-web-search-exa@0.2.1-alpha.1（3 文件 / 273 行）

职责：Exa 搜索 provider


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/web/web-search-exa/src/index.ts | 68 | apply, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/dsh-launch-environment, @deepseek-ai/schemastery, @deepseek-ai/dsh-web |
| packages/web/web-search-exa/src/provider.ts | 166 | mapExaResult, mapExaResponse, ExaSearchProvider, EXA_PROVIDER_ID, EXA_DEFAULT_BASE_URL, EXA_DEFAULT_SEARCH_TYPE, EXA_DEFAULT_HIGHLIGHTS_PER_RESULT, ExaSearchProviderOptions | @deepseek-ai/dsh-web |
| packages/web/web-search-exa/src/types.ts | 39 | ExaSearchRequest, ExaResult, ExaSearchResponse, ExaError | — |

#### packages/web/web-search-perplexity — @deepseek-ai/dsh-web-search-perplexity@0.2.1-alpha.1（3 文件 / 267 行）

职责：Perplexity 搜索 provider


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/web/web-search-perplexity/src/index.ts | 63 | apply, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/dsh-launch-environment, @deepseek-ai/schemastery, @deepseek-ai/dsh-web |
| packages/web/web-search-perplexity/src/provider.ts | 168 | mapPerplexityResult, mapPerplexityResponse, PerplexitySearchProvider, PERPLEXITY_PROVIDER_ID, PERPLEXITY_DEFAULT_BASE_URL, PERPLEXITY_DEFAULT_MODEL, PERPLEXITY_DEFAULT_MAX_TOKENS, PerplexityRecency …等9项 | @deepseek-ai/dsh-web |
| packages/web/web-search-perplexity/src/types.ts | 36 | PerplexityRequest, PerplexitySearchResult, PerplexityResponse, PerplexityError | — |

#### packages/webhook/webhook — @deepseek-ai/dsh-webhook@0.2.1-alpha.1（4 文件 / 485 行）

职责：Webhook 运行时（ctx.webhookRuntime）：fire-and-forget 规则 + Workspace Session 创建


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/webhook/webhook/src/brand.ts | 40 | WebhookRuleId, WebhookSourceId, WebhookDeliveryId | @deepseek-ai/dsh-brand |
| packages/webhook/webhook/src/index.ts | 179 | WebhookRuntime | @deepseek-ai/cordis, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-util-values |
| packages/webhook/webhook/src/session.ts | 181 | createWebhookSession | @deepseek-ai/cordis, node:crypto, node:path, @deepseek-ai/dsh-brand, @deepseek-ai/dsh-agent |
| packages/webhook/webhook/src/types.ts | 85 | WebhookEventMap, WebhookEventOf, VerifiedWebhookDelivery, WebhookModelSelection, WebhookSessionRequest, WebhookRule | @deepseek-ai/dsh-util-values |

#### packages/webhook/webhook-github — @deepseek-ai/dsh-webhook-github@0.2.1-alpha.1（4 文件 / 287 行）

职责：GitHub webhook 签名适配（HMAC 验签，202 立返）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/webhook/webhook-github/src/body.ts | 70 | readBoundedUtf8Body, WebhookHttpError | node:http |
| packages/webhook/webhook-github/src/handler.ts | 131 | createGitHubWebhookHandler, GitHubWebhookHandlerConfig | @deepseek-ai/cordis, node:http, @octokit/webhooks, @deepseek-ai/dsh-credentials, @deepseek-ai/dsh-util-values |
| packages/webhook/webhook-github/src/index.ts | 63 | apply, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/dsh-credentials, @deepseek-ai/dsh-host-webserver, @deepseek-ai/schemastery |
| packages/webhook/webhook-github/src/types.ts | 23 | GitHubJsonObject, GitHubWebhookEvent | @deepseek-ai/dsh-util-values, @octokit/webhooks |

#### packages/workflow/tool-ralph — @deepseek-ai/dsh-tool-ralph@0.2.1-alpha.1（1 文件 / 478 行）

职责：Ralph 循环工具（每轮 fresh 子会话 + 有界 handoff）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/workflow/tool-ralph/src/index.ts | 478 | apply, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-util-values, @deepseek-ai/dsh-subagent |

#### packages/workflow/tool-workflow — @deepseek-ai/dsh-tool-workflow@0.2.1-alpha.1（3 文件 / 615 行）

职责：workflow 工具（前台/后台 job 双模式 + 事件镜像）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/workflow/tool-workflow/src/index.ts | 485 | apply, name, inject, Config, meta | @deepseek-ai/cordis, @deepseek-ai/schemastery, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-llm |
| packages/workflow/tool-workflow/src/record.ts | 65 | createWorkflowRecordMirror, WorkflowRecordMirror | @deepseek-ai/cordis, @deepseek-ai/dsh-jobs, @deepseek-ai/dsh-workflow |
| packages/workflow/tool-workflow/src/types.ts | 65 | ToolWorkflowRunStartData, ToolWorkflowAgentStartData, ToolWorkflowAgentEndData, ToolWorkflowRunEndData | @deepseek-ai/dsh-session, @deepseek-ai/dsh-workflow |

#### packages/workflow/workflow — @deepseek-ai/dsh-workflow@0.2.1-alpha.1（3 文件 / 386 行）

职责：工作流 Service Definition（ctx.workflowEngine）+ 事件词汇


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/workflow/workflow/src/index.ts | 204 | isFatalWorkflowError, WorkflowError, WorkflowEngine, WorkflowEventName, WorkflowErrorCode | @deepseek-ai/cordis, @deepseek-ai/dsh-llm |
| packages/workflow/workflow/src/runtime-types.ts | 50 | WorkflowStartRequest, WorkflowRun | @deepseek-ai/dsh-agent |
| packages/workflow/workflow/src/types.ts | 132 | WorkflowRunId, WorkflowPhase, WorkflowMeta, WorkflowStopReason, WorkflowResult, WorkflowRunInfo, WorkflowAgentInfo, WorkflowAgentOutcome …等10项 | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-session |

#### packages/workflow/workflow-ptc — @deepseek-ai/dsh-workflow-ptc@0.2.1-alpha.1（10 文件 / 1343 行）

职责：沙箱脚本工作流引擎：guest DSL（agent/pipeline/parallel）+ 限额


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/workflow/workflow-ptc/src/guest-source.ts | 5 | WORKFLOW_GUEST_SOURCE | — |
| packages/workflow/workflow-ptc/src/guest-types.ts | 60 | StartedWorkflowChild, WorkflowChildRequest, WorkflowProgress, WorkflowGuestHost | @deepseek-ai/dsh-workflow |
| packages/workflow/workflow-ptc/src/guest.ts | 76 | runWorkflowGuest | @deepseek-ai/dsh-workflow |
| packages/workflow/workflow-ptc/src/host.ts | 307 | PtcWorkflowRun | @deepseek-ai/cordis, @deepseek-ai/dsh-agent, @deepseek-ai/dsh-ptc-runtime, @deepseek-ai/dsh-sandbox, @deepseek-ai/dsh-session |
| packages/workflow/workflow-ptc/src/index.ts | 192 | meta, Config, PtcWorkflowEngine | node:crypto, node:os, node:vm, @deepseek-ai/cordis, @deepseek-ai/dsh-ptc-runtime |
| packages/workflow/workflow-ptc/src/meta.ts | 83 | validateMeta | @deepseek-ai/dsh-workflow |
| packages/workflow/workflow-ptc/src/realm.ts | 148 | renderThrown, materializeFromRealm, MaterializeError | — |
| packages/workflow/workflow-ptc/src/runtime.ts | 368 | WorkflowExecution, ExecutionObserver | node:vm, @deepseek-ai/dsh-brand, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-session, @deepseek-ai/dsh-tools |
| packages/workflow/workflow-ptc/src/types.ts | 91 | WorkerLimits, WorkerInit, ChildStartRequest, ChildResult, ChildHandle, ChildPort | @deepseek-ai/dsh-llm, @deepseek-ai/dsh-tools, @deepseek-ai/dsh-workflow |
| packages/workflow/workflow-ptc/tsdown.config.ts | 13 | defineConfig | tsdown |

#### packages/workspace/workspace — @deepseek-ai/dsh-workspace@0.2.1-alpha.1（5 文件 / 1412 行）

职责：工作区实体注册表（ctx.workspaceRegistry）：串行队列两阶段写 + 归档/置顶


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| packages/workspace/workspace/src/entity.ts | 222 | WorkspaceMoveInvalidError, WorkspaceEntity, WorkspaceEntityHost | node:fs, @deepseek-ai/dsh-session, @deepseek-ai/dsh-storage-domain |
| packages/workspace/workspace/src/index.ts | 902 | WorkspaceId, WorkspaceUnknownSessionError, WorkspaceActiveSessionError, WorkspaceArchivedSessionPinError, WorkspaceOrderInvalidError, WorkspaceRegistry, SessionActivityRequest, ArchiveSessionOptions | node:crypto, node:fs, @deepseek-ai/cordis, @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-persistence |
| packages/workspace/workspace/src/paths.ts | 58 | fullyQualifiedWorkspacePath, defaultWorkspaceTitle, realpathNormalize | node:fs, node:path |
| packages/workspace/workspace/src/spec.ts | 85 | workspaceRecord, workspaceDomainState, workspaceDomainSpec, WorkspaceRecord, WorkspaceDomainState | zod, @deepseek-ai/dsh-brand, @deepseek-ai/dsh-session, @deepseek-ai/dsh-storage-domain |
| packages/workspace/workspace/src/types.ts | 145 | WorkspaceId, SessionActivityKindMap, SessionActivityKind, SessionActivityItem, SessionActivity, Workspace | @deepseek-ai/dsh-brand, @deepseek-ai/dsh-session, @deepseek-ai/dsh-typert-protocol |

#### python/sdk — python/sdk（6 文件 / 965 行）

职责：Python SDK：同步 JSON-RPC over stdio 客户端 + DeepSeekHarness 高层 API


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| python/sdk/examples/minimal.py | 49 | — | — |
| python/sdk/src/deepseek_harness/__init__.py | 20 | — | — |
| python/sdk/src/deepseek_harness/api.py | 249 | — | — |
| python/sdk/src/deepseek_harness/client.py | 590 | — | — |
| python/sdk/src/deepseek_harness/errors.py | 24 | — | — |
| python/sdk/src/deepseek_harness/models.py | 33 | — | — |

#### python/sdk-runtime — dsh-python-runtime-closure@0.0.1（4 文件 / 413 行）

职责：Python runtime wheel 打包（单文件 Node exe + ripgrep + office kit）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| python/sdk-runtime/hatch_build.py | 122 | — | — |
| python/sdk-runtime/runtime-bootstrap.mjs | 44 | — | node:module, node:path, node:sea, node:url, @deepseek-ai/dsh-sandbox-windows-acl |
| python/sdk-runtime/src/deepseek_harness_runtime/__init__.py | 203 | — | — |
| python/sdk-runtime/src/deepseek_harness_runtime/_resources.py | 44 | — | — |

#### scripts — scripts（159 文件 / 43358 行）

职责：构建编排与 CI 门禁脚本（build/dev-web/primary-runtime/release 关键，余为 verify-*/gen-* 门禁）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| scripts/agent-note-tree.ts | 84 | walkAgentNoteTree, agentNoteRoot, AGENT_NOTE_CLASSES, AgentNote | node:fs, node:path |
| scripts/archived-agent-notes.ts | 205 | gitBlobHash, parseArchiveManifest, renderArchiveManifest, validateArchiveManifestExtension, validateArchiveArtifacts, extendArchiveManifest, ArchiveManifest | node:crypto, node:path |
| scripts/attribute-chunk-bytes.mjs | 102 | — | node:fs |
| scripts/benchmark-next-package-dependency.ts | 272 | parseNextPackageBenchmarkOptions, applyFactsToRegistry, discoverBenchmarkCandidates, MutableRegistryManifest | node:os, node:path, node:util |
| scripts/benchmark-npm-resolution.ts | 554 | parsePositiveIntegerOption, parseBenchmarkOptions, publishWorkspaceRange, buildRegistryIndex, runCommandWithTimeout, resolveNpmPackageLock, benchmarkNpmResolution, RegistryIndex …等13项 | node:child_process, node:fs, node:http, node:os, node:path |
| scripts/browser-bundled-externals.ts | 184 | browserPackageOfFile, browserSourceAliases, browserBundledExternals | node:fs, node:module, node:path, node:url, tsdown |
| scripts/build-exe-for-python-sdk-native-pty.ts | 46 | resolveLinuxNodePtyAddon, resolveWindowsNodePtyAddons | node:fs, node:path |
| scripts/build-exe-for-python-sdk-office.ts | 38 | copyOfficeSidecar, OFFICE_ASSET_IGNORES | node:fs, node:path |
| scripts/build-exe-for-python-sdk.ts | 656 | — | node:child_process, node:fs, node:os, node:path, node:util |
| scripts/build-python-release.py | 339 | — | — |
| scripts/build.ts | 58 | — | node:child_process, node:fs, node:path, node:util |
| scripts/bundle-input-isolation.ts | 96 | physicalBundleInput, BundleInputIsolation | node:fs, node:path, node:url |
| scripts/change-scope.ts | 249 | renderChangeScope | node:child_process, node:url, node:path, node:util |
| scripts/check-macos-deployment-target.py | 112 | — | — |
| scripts/check-workspace-constraints.ts | 621 | readWorkspaceManifests, expectedDshPackageFiles, checkExperimentalManifest, checkDshFamilyVersion, checkWorkspaceManifest, checkExperimentalDependencyIsolation, checkWorkspaceProtocol, main …等11项 | node:fs, node:path, node:url, js-yaml |
| scripts/ci-compatible-toolcache.mjs | 9 | — | node:assert, node:path |
| scripts/clean.ts | 193 | RepositoryCleaner | node:fs, node:path, node:url, typescript |
| scripts/client-build-environment.ts | 396 | repositoryCommitHash, repositoryVersion, repositoryGitDirty, repositoryClientBuildEnvironment, officialClientBuildEnvironment, resolveClientBuildEnvironment, clientBuildProcessEnvironment, assertClientBuildEnvironment …等15项 | node:crypto, node:child_process, node:fs, node:path |
| scripts/cordis-config-files.ts | 19 | cordisConfigFiles | node:fs |
| scripts/cordis-core-api.ts | 434 | renderCordisCoreApiPage, renderCordisCoreApiPages, CORDIS_CORE_API_PAGES, CordisCoreApiPage | node:fs, node:path, typescript |
| scripts/cordis-walk.ts | 103 | contextMergeFiles, cordisModuleBody, contextKeyMap, eventNameList | node:fs, node:path, typescript |
| scripts/cordis-yaml.ts | 79 | loadCordisYaml, isJsExpr, isCordisGroupEntry, isAgentPresetEntry, presetDefinitions, JsExpr | js-yaml |
| scripts/coverage-canonical-locations.ts | 95 | canonicalizeEndOfLineColumns, END_OF_LINE_COLUMN, CanonicalCoverageLocationsReporter | — |
| scripts/coverage-exempt.ts | 60 | COVERAGE_EXEMPT_ENV, coverageExemptHeavySuites, CoverageExemptSuite | — |
| scripts/coverage-partitions.ts | 716 | parseCoveragePartitionCount, parseCoverageTestTimeout, coverageTestTimeoutOptions, forwardedCoverageArgs, parseListOutput, readFileDurations, writeFileDurations, collectPartitionDurations …等19项 | node:child_process, node:fs, node:path, vitest |
| scripts/coverage-uncovered-locations.cjs | 122 | — | node:path, istanbul-lib-report |
| scripts/demo-ptc.mjs | 19 | — | node:child_process |
| scripts/dev-web.ts | 440 | devWebBuildEnvironment, parseDevWebArguments, discoverPluginDirs, discoverLibraryDirs, watchClientPlugins, StageSupervisor, DevWebArguments, StageHandle …等9项 | node:fs, node:path, node:url, execa, tsdown |
| scripts/doc-typecheck-paths.ts | 25 | builtDeclarationPath | — |
| scripts/doc-typecheck.ts | 253 | — | node:child_process, node:fs, node:path, typescript |
| scripts/experimental-package-policy.ts | 17 | isPublicExperimentalPackageDirectory, PRIVATE_EXPERIMENTAL_PACKAGE_DIRECTORIES | — |
| scripts/gen-client-catalog.ts | 595 | collectSlotEntries, oversizedSlotReports, validateSlotContracts, resolveSlotEntries, renderClientCatalog, main, CLIENT_NOTES, CLIENT_SLOT_API …等11项 | node:fs, node:path, typescript |
| scripts/gen-config-catalog.ts | 1073 | collectConfigCatalog, render, computeConfigCatalogOutputs, inject, CatalogEntry | node:fs, node:path, typescript, ${resolved.ref.specifier}, ${refs.get(name)?.specifier ??  |
| scripts/gen-cordis-api.ts | 10 | — | — |
| scripts/gen-cordis-catalog.ts | 1271 | spliceRegion, localizePageRegion, walkPartitionProblems, computeOutputs, main, SERVICE_PAGE, SERVICE_WALK_EXEMPTIONS, EVENT_SCOPE_PAGE …等15项 | node:fs, node:path, @deepseek-ai/dsh-typert-generator |
| scripts/gen-cordis-inspect-catalog.ts | 92 | — | node:fs, node:path, @deepseek-ai/dsh-typert-generator |
| scripts/gen-dependency-catalog.ts | 305 | collectDependencies, deduplicateDependencies, computeDependencyCatalog, isDependencyCatalogCurrent, createNpmResolutionEnvironment, DependencyRow | node:fs, node:os, node:path, node:util |
| scripts/gen-doc-graphs.ts | 1747 | collectPackageSources, EventRelationCollector, PackageSource | node:fs, node:path, typescript, @deepseek-ai/dsh-typert-generator |
| scripts/gen-module-graph.ts | 192 | renderModuleGraph, computeModuleGraphOutputs, writeModuleGraph, main | node:fs, node:path |
| scripts/gen-persistence-catalog.ts | 221 | render, renderKnownEventTypes, persistenceCatalogArtifacts, KNOWN_SESSION_EVENT_TYPES, MESSAGE_PROJECTION_EVENT_TYPES | node:fs, node:path |
| scripts/gen-plugin-packages.ts | 84 | render | node:fs, node:path |
| scripts/gen-session-format-catalog.ts | 262 | readCurrentSessionFormatVersion, collectSessionFormatMigrations, renderSessionFormatCatalog, SESSION_FORMAT_VERSION, sessionFormatCatalogOptions, sessionFormatCatalog, SessionFormatMigrationManifest | node:fs, node:path, node:url, @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-format |
| scripts/gen-third-party-notices.ts | 871 | isOwnerAuthorizedRuntime, manifestPatterns, claudeDistributionFromManifest, virtualManifest, tierExternalDeps, parseVendoredRows, parsePyprojectRequirements, collectPythonDependencies …等17项 | node:fs, node:path, js-yaml, smol-toml, spdx-expression-parse |
| scripts/gen-tool-catalog.ts | 859 | assertManifestComplete, assertToolsHarvested, collectToolCatalog, render, ToolPackage, ToolCatalog | node:fs, node:path, @deepseek-ai/cordis, @deepseek-ai/dsh-llm, @deepseek-ai/dsh-agent |
| scripts/gen-translation-brief.ts | 332 | — | node:child_process, node:fs, node:os, node:path |
| scripts/gen-tsconfig-paths.ts | 240 | collectPackageAliases, collectPackageNames, mappedSpecifiers, uncoveredPackages, renderAliases, writeRegion | node:fs, node:path, node:url |
| scripts/gen-workflow-guest.ts | 73 | bundleWorkflowGuest, generateWorkflowGuest, WORKFLOW_GUEST_SOURCE | node:fs, node:module, node:path, node:util, tsdown |
| scripts/historical-schema-region.ts | 18 | historicalSchemaRegion | — |
| scripts/install-lefthook.mjs | 770 | — | node:crypto, node:fs, node:child_process, node:path, lefthook |
| scripts/jsdoc.ts | 202 | pointer, rawJsDoc, parseJsDoc, parseTags, checkParams, checkReturns, reportViolations, Mode | typescript |
| scripts/libreoffice-packages.mjs | 81 | selectOfficeEngine, officePackageDirectories | node:fs, node:module, node:path |
| scripts/markdown.ts | 272 | parseMarkdown, visitMarkdown, isExternalOrAbsoluteMarkdownUrl, splitMarkdownUrlTarget, markdownDestination, markdownFences, markdownHeadingLines, markdownProseLines …等13项 | mdast-util-from-markdown, mdast-util-gfm, micromark-extension-gfm, mdast |
| scripts/migrate-packed-session-fixtures.ts | 22 | — | node:fs, node:path |
| scripts/migrate-sessions-to-v4.ts | 304 | runMigrationJobs | node:child_process, node:assert, node:fs, node:os, node:path |
| scripts/migration-failure-summary.ts | 44 | classifyMigrationFailure, MigrationFailureDiagnostic | node:util |
| scripts/npm-baseline-packages.ts | 27 | discoverNpmBaselineManifests | node:fs |
| scripts/package-dependency-policy.ts | 119 | hasClientDeclaration, usesFlattenedPackageDependencies, PACKAGE_DEPENDENCY_POLICY, PackageDependencyPolicy | — |
| scripts/package-graph.ts | 169 | collectPackageGraph, graphNodeId, escapeMermaidLabel, PackageGraphNode | node:fs, node:path |
| scripts/paired-markdown-derivatives.ts | 64 | partitionPairedMarkdownDerivatives, MarkdownDerivativePartition | — |
| scripts/persistence-artifacts.ts | 55 | renderPersistencePair, PersistenceArtifact | node:fs |
| scripts/persistence-catalog-source.ts | 308 | collectLogEvents, collectEventEnvelopeTypes, collectSurfaceEventTypes, annotateSurface, LogEventEntry, AnnotatedLogEventEntry, EventEnvelopeTypeEntry | node:fs, node:path, typescript |
| scripts/persistence-catalog-text.ts | 50 | persistenceCatalogText, PersistenceCatalogLocale | — |
| scripts/persistence-changes.ts | 934 | parsePersistenceSnapshot, parseHistoricalPersistenceSnapshot, classifyPersistenceChange, validatePersistenceHistory, loadPersistenceHistory, verifyPersistenceChanges, parsePersistenceProse, runPersistenceChanges …等17项 | node:fs, node:path, node:util, js-yaml |
| scripts/persistence-finalization.ts | 173 | createPersistenceFinalizationCheckpoint, loadPersistenceFinalization, PersistenceFinalizationCheckpoint, PersistenceFinalization | node:crypto, node:fs, node:path, js-yaml |
| scripts/persistence-format-facts.ts | 79 | persistenceFormatFactArtifacts | node:fs, node:path |
| scripts/persistence-formats.ts | 231 | loadPersistenceFormats, runPersistenceFormats, PersistenceFormatSource, PersistenceFormatEntry, PersistenceFormats | node:fs, node:path, node:util, js-yaml |
| scripts/persistence-release-facts.ts | 96 | persistenceReleaseFactArtifacts | node:fs, node:path |
| scripts/persistence-releases.ts | 258 | loadPersistenceReleases, runPersistenceReleases, PersistenceRelease, PersistenceReleaseManifest, PersistenceReleaseChange, PersistenceReleaseRecord, PersistenceReleaseEntry, PersistenceReleases | node:fs, node:path, node:util, js-yaml |
| scripts/persistence-review.ts | 231 | reviewPersistenceSchemas, renderPersistenceReview, runPersistenceReview, PersistenceReviewEvidence, PersistenceReview | node:fs, node:path, node:util |
| scripts/persistence-schema-model.ts | 322 | reachableSchemaTypes, persistenceSchemaSnapshot, schemaChildren, canonicalizeSchema, schemaDigest, schemaHasCompatibility, isArbitraryJsonSchema, SourceCompatibility …等17项 | node:crypto, node:util |
| scripts/persistence-schema.ts | 513 | extractPersistenceSchema, PersistenceSchemaError, HeaderRoot, SurfaceRoot, EventNamesRoot, EventRoot$ | node:fs, node:path, typescript, @deepseek-ai/dsh-session |
| scripts/persistence-source-annotations.ts | 82 | sourceCompatibilityAnnotations | node:path, typescript |
| scripts/persistence-source-metadata.ts | 19 | withoutPersistenceSourceLines | — |
| scripts/persistence-source-policy.ts | 70 | sourceKindGroups, validSourceCompatibility, matchingSourceCompatibility | — |
| scripts/pnpm-invocation.ts | 22 | pnpmInvocation | — |
| scripts/primary-runtime/prepare.ts | 208 | downloadPrimaryRuntimeAsset, primaryRuntimePayloadDigest, unpackPrimaryRuntimeWheel, prepareOfficeSkillAssets, preparePrimaryRuntime, smokePrimaryRuntime, PrimaryRuntimeTarget, PreparePrimaryRuntimeOptions | node:child_process, node:crypto, node:fs, node:module, node:os |
| scripts/primary-runtime/smoke.py | 100 | — | — |
| scripts/project-doc-site.ts | 578 | resolveRepositoryRef, rewriteMarkdown, addProjectionFrontmatter, projectedPageContent, publishableImage, docsSourceFiles, projectDocs, rawMarkdownPageContent …等15项 | node:fs, node:path, mdast-util-from-markdown, mdast-util-gfm, micromark-extension-gfm |
| scripts/project-reference-faces.ts | 130 | collectProjectReferenceFaceViolations | node:fs, node:path, typescript |
| scripts/publication-payload.ts | 56 | hasTypertRemoteNavigation, isForbiddenPublicationFile, validateTarballPayload | — |
| scripts/publint-all.ts | 261 | — | node:fs, node:os, node:path, node:util, publint |
| scripts/publish-npm-baseline.ts | 1078 | — | node:child_process, node:crypto, node:fs, node:os, node:path |
| scripts/release/bump.ts | 417 | compareVersions, nextVendorVersion, reachesPayload, planShared | node:fs, node:path, node:util |
| scripts/release/families.ts | 450 | releaseFamily, tarballName, ReleaseFamily, PublishPlan, ReleaseMember, InstalledEntry | node:fs, node:path |
| scripts/release/installed-product-isolation.ts | 73 | verifyInstalledProductIsolation | node:fs, node:module, node:path |
| scripts/release/pack.ts | 91 | — | node:fs, node:path, node:util |
| scripts/release/process.ts | 130 | attempt, attemptEchoed, capture, runConcurrent, isEntry, pnpmCommand, RunOptions, CommandResult | node:child_process, node:fs, node:path, node:url |
| scripts/release/publish.ts | 236 | publishRelease | node:crypto, node:fs, node:path, node:timers, node:util |
| scripts/release/tarball.ts | 55 | tarballFiles, packedIdentity, readPublishOrder, PUBLISH_ORDER_FILE, PackedIdentity | node:fs, node:path |
| scripts/release/verify-packed-install.ts | 126 | — | node:fs, node:os, node:path, node:url, node:util |
| scripts/release/verify.ts | 111 | — | node:util |
| scripts/render-persistence-schema.ts | 320 | renderPersistenceSchemaIndex, renderPersistenceSchemaDefinitions, PersistenceSchemaRendering | — |
| scripts/repo-files.ts | 258 | isArchivedAgentNotePath, uniqueRepoFiles, findReferenceViolations, RepoFile, ReferenceViolation | node:fs, node:path |
| scripts/rescope-vendor.ts | 662 | isRescopeExcluded, exactEditState, VendoredRow, ExactEditState | node:child_process, node:fs, node:path, node:url, schemastery |
| scripts/run-coverage-partitions.ts | 26 | — | node:path |
| scripts/run-gates.ts | 1677 | cliGateOptions, defaultConcurrency, ciWorkerEnvironment, gatesForMode, runGates, runGate, parsePidPpidLines, taskkillArgs …等14项 | node:child_process, node:fs, node:os, node:path, node:perf_hooks |
| scripts/run-oxlint.ts | 99 | resolveOxlintInvocation, OxlintInvocation | node:child_process, node:path, node:url |
| scripts/run-web-snapshots.ts | 45 | — | node:child_process |
| scripts/session-fixture-layout.ts | 295 | isPhysicalSessionFixture, canonicalSessionFixture, inspectSessionFixtureLayouts, SessionFixtureLayout | node:assert, node:child_process, node:fs, node:path, @deepseek-ai/dsh-session |
| scripts/session-snapshot-corpus-policy.ts | 113 | assertSnapshotCorpusPolicy, SnapshotCorpusScenarioGenerations, SnapshotCorpusGenerationSummary | @deepseek-ai/dsh-session, @deepseek-ai/dsh-session-snapshot |
| scripts/session-snapshot-corpus.corpus.ts | 212 | — | node:fs, node:path, vitest, @deepseek-ai/dsh-session-snapshot |
| scripts/slot-walk.ts | 433 | scanSlotFiles, indexExportedTypes, slotDeclarations, slotRegistrations, standardKitMembers, referencedTypeNames, declaredTypes, SlotDeclaration …等11项 | node:fs, node:path, typescript |
| scripts/smoke-python-runtime.py | 2915 | apply, name, inject, SESSION_FORMAT_VERSION | @deepseek-ai/cordis, node:child_process |
| scripts/snapshot-shell-path.ts | 31 | apply, name, inject, Config | @deepseek-ai/cordis, @deepseek-ai/dsh-shell |
| scripts/snapshot-spill-locators.ts | 67 | apply, name, inject, Config | @deepseek-ai/cordis, node:path, @deepseek-ai/dsh-spill, @deepseek-ai/dsh-fs |
| scripts/snapshot-workspace-parent.ts | 47 | outsideTempWorkspaceParent, assertWorkspaceOutsideTemp | node:fs, node:os, node:path, @deepseek-ai/dsh-sandbox |
| scripts/test-dom-environment.ts | 42 | — | vitest |
| scripts/test-fixture-cleanup.ts | 50 | unlinkFixtureLinks, removeFixtureSafely | node:fs, node:path |
| scripts/test-proxy-environment.ts | 64 | vitestConfigFiles, clearAmbientProxyEnv, TEST_PROXY_SETUP_FILE | node:fs, node:path |
| scripts/translation-brief.ts | 513 | markdownUnits, sectionSpans, spansAligned, changedSpanIndices, computeMechanicalUpdate, parseTerminologyRows, termOffsets, relevantTerminologyRows …等17项 | mdast |
| scripts/translation-links.ts | 329 | languageSwitcherLinkOffset, hasLanguageSwitcher, translationLinkLocaleViolations, rewriteTranslationLinkLocales, normalizeTranslationMarkdownLinks, semanticTranslationLinkNodeTarget, TranslationLinkContext, TranslationLinkLocaleViolation …等9项 | node:fs, node:path, mdast |
| scripts/translation-pairing-git.ts | 61 | gitIndexPaths, readGitIndexBlob | node:child_process |
| scripts/translation-pairing-record.ts | 210 | translationPairPaths, computeTranslationPairingRecord, parseTranslationPairingRecord, renderTranslationPairingRecord, translationPairingRecordDiff, TranslationPairPaths, TranslationSectionHashes, TranslationPairingRecord …等9项 | node:crypto, node:path, mdast |
| scripts/translation-pairing.ts | 419 | generatedRegions, renderGeneratedRegion, spliceGeneratedRegion, isTranslationScopeFile, parseTranslationPairingManifest, isTranslationPairingManifestExcluded, translationPairSourcePredicate, pairAnchorOfArgument …等19项 | node:path, mdast-util-from-markdown, mdast-util-gfm, micromark-extension-gfm, mdast |
| scripts/translation-prompt.ts | 260 | documentedTranslationPromptPlaceholders, renderTranslationPrompt, renderTranslationRequest, renderTranslationResponse, parseTranslationResponse, consumeTranslationResponse, TRANSLATION_PROMPT_PLACEHOLDERS, TranslationPromptInput …等12项 | node:path |
| scripts/ts-project.ts | 152 | faceConfigs, TypeScriptProject, repositoryConfigHost, CompilerFace, FaceConfigs | node:path, typescript |
| scripts/verify-agent-note-classification.ts | 28 | — | node:fs, node:path |
| scripts/verify-agent-note-format.ts | 95 | — | node:fs, node:path |
| scripts/verify-application-entrypoints.ts | 204 | applicationEntrypointViolations | node:fs, node:path, node:url |
| scripts/verify-archived-agent-notes.ts | 116 | — | node:child_process, node:fs, node:path |
| scripts/verify-client-domain-graph.ts | 105 | resolveClientImport | node:fs, node:path |
| scripts/verify-client-packages.ts | 714 | collectSourcePackageUses, collectRuntimeSourcePackageUses, collectRuntimeSourceSpecifiers, collectLocalSourceSpecifiers, collectRuntimeLocalSourceSpecifiers, readClientDeclarations, collectClientPackageViolations, fixClientPackageManifests …等12项 | node:fs, node:path, node:url, typescript |
| scripts/verify-client-route-resolution.ts | 340 | findRouteResolutionViolations, browserFaceSources, RouteResolutionRule, RouteGateFace, RouteResolutionViolation | node:fs, node:path, typescript |
| scripts/verify-client-ui-i18n.ts | 362 | findUiI18nViolations, clientSourceRoot, UiI18nViolation | node:fs, node:path, typescript |
| scripts/verify-concrete-terms.ts | 106 | findConcreteTermViolations, readTrackedSource, ConcreteTermViolation | node:child_process, node:fs, node:path, node:url |
| scripts/verify-config-source-ownership.ts | 57 | collectConfigSourceOwnershipViolations | node:fs, node:path |
| scripts/verify-cordis-config.ts | 579 | packageTestPluginDependencyErrors, packageTestFixtureDependencyErrors, bundleManifestPaths, bundlePluginDependencyErrors, metadataExpressionErrors, PackageManifest, PluginReference | node:fs, node:path, node:vm, typescript |
| scripts/verify-default-product-isolation.ts | 413 | verifyDefaultProductIsolation, ProductIsolationResult | node:fs, node:path, node:url, jsdom, typescript |
| scripts/verify-doc-budgets.ts | 59 | — | node:fs, node:path |
| scripts/verify-doc-refs.ts | 43 | — | node:fs, node:path |
| scripts/verify-doc-site-fragments.ts | 182 | inspectSiteFragments, missingSiteFiles, BrokenSiteFragment, SiteFragmentReport | node:fs, node:path, jsdom |
| scripts/verify-dsh-package-licenses.ts | 90 | inspectDshPackageLicenses, DshPackageLicenseReport | node:fs, node:path |
| scripts/verify-export-jsdoc.ts | 608 | collectExportJsdocViolations | node:fs, node:path, typescript |
| scripts/verify-md-links.ts | 225 | markdownLinkSourcePaths, githubSlug, documentAnchors, anchorCache, findViolations | node:fs, node:path, mdast |
| scripts/verify-md-wrap.ts | 87 | — | node:fs, node:path, mdast |
| scripts/verify-mermaid.ts | 107 | — | node:fs, node:path, mdast-util-from-markdown, mdast-util-gfm, micromark-extension-gfm |
| scripts/verify-no-bare-dispatcher.ts | 227 | findDispatcherViolations, scanRepository, DISPATCHER_OWNER, ALLOW_MARKER, DispatcherViolation | undici, node:fs, node:path, typescript |
| scripts/verify-no-unknown-casts.ts | 187 | findUnknownCasts, scanUnknownCasts, countUnknownCasts, verifyNoUnknownCasts, UnknownCastBaseline, UnknownCast | node:child_process, node:crypto, node:fs, node:path, typescript |
| scripts/verify-node-next-types.ts | 165 | — | node:child_process, node:fs, node:path |
| scripts/verify-npm-install-layout.ts | 276 | buildDualDshRegistry, assertDualDshInstallLayout, assertResolutionWorkBudget, MAX_RESOLUTION_WORK_UNITS, SYNTHETIC_DSH_VERSIONS, DshInstallLayoutSummary | node:fs, node:path |
| scripts/verify-optional-dependency-imports.ts | 214 | collectOptionalImportViolations | node:fs, node:path, typescript, x |
| scripts/verify-package-dependencies.ts | 905 | readWorkspacePackageManifests, discoverPackageDependencyScope, collectRuntimeSourceExportUses, readPackageDependencyFacts, collectHostDependencyExportPolicyViolations, readPackageDependencyState, expectedPackageDependencies, formatManagedRuntimeDependencies …等19项 | node:child_process, node:fs, node:module, node:path, typescript |
| scripts/verify-package-meta.ts | 235 | packageMetaProblems | node:fs, node:path, node:url |
| scripts/verify-package-paths.ts | 114 | findPackagePathViolations | node:fs, node:path, node:url |
| scripts/verify-package-readme-limitations.ts | 95 | — | node:fs, node:path |
| scripts/verify-package-readme-model-experience.ts | 623 | — | node:fs, node:path |
| scripts/verify-package-readme-summaries.ts | 78 | packageReadmeSummaryErrors, MAX_PACKAGE_README_SUMMARY_WORDS | node:fs, node:path |
| scripts/verify-public-repository-links.ts | 100 | canonicalReferenceText, findUnavailableRepositoryReferences, UnavailableRepositoryReference | node:child_process, node:fs, node:path, node:url |
| scripts/verify-repository-references.ts | 115 | findRepositoryReferences, scanRepositoryReferences, RepositoryReference | node:child_process, node:fs, node:path, node:url |
| scripts/verify-runtime-closure.ts | 236 | verifyRuntimeClosure, RuntimeClosureResult | node:fs, node:path, node:util |
| scripts/verify-skill-invocation-metadata.ts | 123 | collectSkillInvocationMetadataViolations | node:fs, node:path, js-yaml |
| scripts/verify-subsystem-pages.ts | 139 | auditSubsystemPages, GROUPS_WITHOUT_SUBSYSTEM_PAGE, SubsystemPageAudit | node:fs, node:path |
| scripts/verify-translation-pairing.ts | 368 | — | node:fs, node:path |
| scripts/verify-translation-prompt.ts | 99 | — | node:fs, node:path |
| scripts/verify-type-equiv.ts | 377 | — | node:fs, node:path, typescript |
| scripts/verify-upgrade-guides.ts | 86 | collectUpgradeGuideViolations | node:fs, node:path, js-yaml, mdast-util-from-markdown |
| scripts/verify-v3-event-vocabulary.ts | 106 | verifyV3EventVocabulary, V3EventVocabularyCheck | node:child_process, node:path, node:util, typescript, @deepseek-ai/dsh-session-format-v3-to-v4 |
| scripts/volatile-config.fixture.ts | 12 | Config | @deepseek-ai/schemastery |
| scripts/web-product-bundle-isolation.ts | 200 | WebProductBundleIsolation, WebOutputChunk, WebOutputAsset, WebOutputBundle, WebModuleInfo | node:path |

#### tsdown.config.ts — tsdown.config.ts（1 文件 / 36 行）

职责：根 tsdown 运行时 bundle 配置（host/client 双 face）


| 文件 | 行数 | 导出概要 | 主要依赖 |
|---|---|---|---|
| tsdown.config.ts | 36 | defineConfig | tsdown |
