# DeerFlow Backend 2.0-M1-RC0 生产项目代码分析报告

> **分析对象**：`deer-flow-backend-2.0-m1-rc0/`
> **排除范围**：`packages/harness/`（deerflow-harness 工作空间包，全部排除）、`tests/`、`docs/`、`.vscode/`、锁文件与 lint 配置。报告中仅在说明依赖边界时提及 `deerflow.*` 的引用关系，不分析其内部实现。
> **报告生成日期**：2026-10-08
> **结论基准**：全部结论基于对纳入范围源码的实际阅读，引用格式为 `文件路径:行号`。

---

## 0. 批次计划表（分批输出策略）

本项目纳入范围的生产源文件约 **60 个**（> 40 个）、模块数 **6 个以上**，触发分批输出策略。本报告以单一 Markdown 文件交付，批次内容已全部包含在本文中，各批次状态如下：

| 批次 | 覆盖模块/目录 | 覆盖章节 | 涉及文件数 | 状态 |
|------|--------------|----------|-----------|------|
| 1 | 全局总览（根目录 + app/ 整体） | 第 1~3 章 + 第 5 章 + 本计划 | 全部（清单层，60） | ✅ 已完成 |
| 2 | Gateway 核心与运行时装配（`app/gateway` 核心 12 文件） | 第 4 章（4.1、4.2、4.5） | 12 | ✅ 已完成 |
| 3 | 认证授权 + 路由层（`auth/` 13 文件 + `routers/` 16 文件） | 第 4 章（4.3、4.4） | 29 | ✅ 已完成 |
| 4 | IM 渠道模块 + 运维脚本（`app/channels` 14 文件 + `scripts/` + `debug.py`） | 第 4 章（4.6、4.7、4.8） | 16 | ✅ 已完成 |
| 5 | 深度解析与收尾（跨模块关键函数 + 调用链 + 横切机制） | 第 6~10 章 + 收尾三件套 | 关键函数层 | ✅ 已完成 |

批次划分遵循依赖方向：总览 → 基础层（网关装配/服务层）→ 认证与业务路由 → 渠道与脚本 → 深度解析收尾。章节编号全局连续。

---

## 0.1 术语表

| 术语 | 解释 |
|------|------|
| **Gateway（网关）** | 本项目主体：基于 FastAPI 的 API 网关（`app/gateway/`），默认监听 8001 端口，是前端与 Agent 运行时之间的唯一 HTTP 入口。 |
| **Harness（运行时底座）** | `packages/harness` 中的 `deerflow-harness` 包，提供 LangGraph Agent（`make_lead_agent`）、RunManager、StreamBridge、持久化等能力。**本报告排除其内部实现**，仅描述 `app/` 对它的调用边界。 |
| **Thread（会话）** | 一段与 Agent 的对话上下文，由 LangGraph checkpointer 持久化；元数据存于 `threads_meta` 表（ThreadMetaStore）。 |
| **Run（运行）** | 在某个 Thread 上的一次 Agent 执行，由 `RunManager` 管理生命周期（pending → running → success/error/cancelled）。 |
| **SSE（Server-Sent Events）** | 服务端推送协议，用于流式返回 Agent 执行事件；帧格式与 LangGraph Platform 对齐（`useStream` React hook 可直接消费）。 |
| **StreamBridge** | Harness 提供的事件桥：后台 Agent 任务把事件写入 bridge，HTTP SSE 消费端从 bridge 订阅（支持 `Last-Event-ID` 断点续传）。 |
| **Lead Agent（主 Agent）** | 默认 Assistant（`assistant_id="lead_agent"`），所有自定义 Agent 都是「lead_agent + agent_name 上下文」的路由变体（`services.py:139-150`）。 |
| **Channel（渠道）** | 接入的外部 IM 平台（飞书/Slack/Telegram/钉钉/Discord/微信/企业微信），通过 `MessageBus` 与 `ChannelManager` 解耦。 |
| **MessageBus** | 进程内异步 pub/sub 枢纽：渠道 → `InboundMessage` → 派发器；派发器 → `OutboundMessage` → 渠道（`app/channels/message_bus.py:117`）。 |
| **Double Submit Cookie** | CSRF 防护模式：服务端种 `csrf_token` Cookie（JS 可读），前端把它回填到 `X-CSRF-Token` 请求头，两者比对一致才放行。 |
| **token_version** | 用户表字段，改密码时 +1，使旧 JWT 立即失效（`jwt.py:18`、`auth.py:363`）。 |
| **虚拟路径（virtual path）** | 沙箱内可见的路径（如 `/mnt/user-data/outputs/x.pdf`），由 `resolve_thread_virtual_path` 映射到宿主机真实路径（`path_utils.py:11`）。 |
| **Artifact（产物）** | Agent 生成的文件，位于线程 outputs 目录，可通过 `/api/threads/{id}/artifacts/...` 下载。 |
| **Skill（技能）** | 以 `SKILL.md` 为核心的可安装能力包（.skill 文件为 ZIP 归档），受安全扫描器管束。 |
| **内部认证（internal auth）** | 进程级随机令牌 `X-DeerFlow-Internal-Token`，供同进程内 ChannelManager 回调 Gateway 时绕过 Cookie 认证（`internal_auth.py`）。 |
| **DooD** | Docker-out-of-Docker：容器内挂载宿主 Docker socket 启动沙箱容器（`Dockerfile:64`）。 |

---

# 第 1 章 项目概述

## 1.1 项目用途与业务背景

本项目是 **DeerFlow 的后端服务（2.0 版本 M1 里程碑 RC0）**——一个「LangGraph 驱动、带沙箱执行能力的 AI Agent 系统」（`pyproject.toml:4`）。从代码结构可归纳出三层业务定位：

1. **Agent API 网关**：对外暴露与 LangGraph Platform 协议兼容的 HTTP/SSE API（threads、runs、assistants、feedback 等），使前端可以直接使用 `@langchain/langgraph-sdk` 的 `useStream` Hook 而无需修改（`app/gateway/routers/thread_runs.py:7-9`）。同时提供 DeerFlow 特有端点：模型列表、MCP 配置、记忆（memory）、技能（skills）、产物（artifacts）、文件上传（uploads）、自定义 Agent 管理、追问建议（suggestions）。
2. **多用户认证与数据隔离**：内建完整的账号体系（注册/登录/JWT Cookie 会话/CSRF/权限装饰器/线程属主校验），并为 LangGraph Server 模式提供同一套认证（`langgraph.json:11-13`）。
3. **IM 渠道接入**：将飞书、Slack、Telegram、钉钉、Discord、微信、企业微信七个 IM 平台的私聊/群聊接入同一个 Agent，支持命令（`/new`、`/status` 等）、流式卡片更新、文件上传下载（`app/channels/`）。

## 1.2 技术栈清单

| 类别 | 选型 | 证据 |
|------|------|------|
| 语言 | Python **3.12**（强制 `requires-python >= 3.12`） | `pyproject.toml:6`、`.python-version` |
| 运行时框架 | **FastAPI** `>=0.115` + **uvicorn[standard]** `>=0.34` | `pyproject.toml:9,13` |
| Agent 框架 | **LangGraph**（通过 workspace 包 `deerflow-harness` 引入）+ **langgraph-sdk** `>=0.1.51` | `pyproject.toml:8,17`、`pyproject.toml:45-49` |
| 包管理 | **uv**（workspace 模式，成员 `packages/harness`） | `pyproject.toml:42-49`、`Makefile:2` |
| Web 工具 | httpx `>=0.28`、sse-starlette `>=2.1`、python-multipart `>=0.0.26` | `pyproject.toml:10-12` |
| 认证 | **PyJWT** `>=2.9`（HS256）、**bcrypt** `>=4.0`、email-validator `>=2.0` | `pyproject.toml:21-23` |
| IM SDK | lark-oapi（飞书）、slack-sdk、python-telegram-bot、dingtalk-stream、wecom-aibot-python-sdk、markdown-to-mrkdwn | `pyproject.toml:14-20` |
| 隐式依赖（经 harness 传递） | sqlalchemy（异步引擎）、pydantic、PyYAML、cryptography（`app/channels/wechat.py:21-22` 使用）、discord.py（`app/channels/discord.py:47` 可选导入，**未在 pyproject 声明**，见存疑清单） | 代码 import |
| 部署 | Docker 多阶段构建（builder/dev/runtime 三阶段），Node.js 22 运行时（供 npx 启动 MCP server）、Docker CLI（DooD 沙箱） | `Dockerfile:10-101` |
| 代码规范 | ruff（check + format） | `Makefile:13-18`、`ruff.toml` |

## 1.3 如何运行

### 启动命令（Makefile，均在项目根执行）

```makefile
install:    uv sync                                    # 安装依赖（含 workspace 的 harness）
dev:        PYTHONPATH=. uv run uvicorn app.gateway.app:app --host 0.0.0.0 --port 8001 --reload
gateway:    PYTHONPATH=. uv run uvicorn app.gateway.app:app --host 0.0.0.0 --port 8001
test:       PYTHONPATH=. uv run pytest tests/ -v
lint:       uvx ruff check . && uvx ruff format --check .
```
（摘自 `Makefile:1-18`）

- **程序入口**：`app.gateway.app:app`——模块级 `app = create_app()`（`app/gateway/app.py:389`）。
- **调试入口**：`debug.py`（`cd backend && PYTHONPATH=. uv run python debug.py`），交互式 REPL 直连 lead_agent，日志写入 `debug.log`（`debug.py:8-16`）。
- **LangGraph Server 模式**：`langgraph.json` 声明图 `lead_agent = deerflow.agents:make_lead_agent`、认证 `./app/gateway/langgraph_auth.py:auth`、checkpointer 走 harness 的 `async_provider.py`（`langgraph.json:8-16`）。此模式下 LangGraph Server（2024 端口）与 Gateway 分进程，由 nginx 反代分流（`app/gateway/app.py:242-243` 的描述）。
- **Docker**：`Dockerfile:69/101` 的 CMD 均为 `uvicorn app.gateway.app:app --port 8001`；暴露 8001（gateway）与 2024（langgraph）。

### 环境配置方式

| 配置来源 | 内容 | 读取位置 |
|---------|------|---------|
| `.env`（dotenv） | `AUTH_JWT_SECRET` 等；`langgraph.json:7` 声明 `env: ".env"` | `app/gateway/auth/config.py:37-39` |
| `config.yaml`（harness 管理） | 模型、数据库、渠道凭据、上传限额、记忆等（`AppConfig` 允许 extra 字段） | `app/gateway/app.py:167`、`app/channels/service.py:91-94` |
| 环境变量（Gateway 自身） | `GATEWAY_HOST`、`GATEWAY_PORT`、`CORS_ORIGINS`、`GATEWAY_ENABLE_DOCS` | `app/gateway/config.py:22-28` |
| 环境变量（CORS 中间件） | `GATEWAY_CORS_ORIGINS`（逗号分隔，禁止 `*`） | `app/gateway/app.py:312-328` |
| 环境变量（认证） | `AUTH_JWT_SECRET`、`AUTH_TRUSTED_PROXIES`（受信代理 CIDR 列表） | `auth/config.py:40`、`routers/auth.py:172` |
| 环境变量（渠道） | `DEER_FLOW_CHANNELS_LANGGRAPH_URL`、`DEER_FLOW_CHANNELS_GATEWAY_URL` | `app/channels/service.py:41-42` |

---

# 第 2 章 整体架构

## 2.1 架构风格与分层

项目是典型的 **前后端分离 + 单体网关 + 插件式渠道** 架构：

- **表现/接入层**：FastAPI 中间件栈（CORS → CSRF → Auth）+ 15 个路由模块 + 7 个 IM 渠道适配器。
- **服务层**：`app/gateway/services.py`（Run 生命周期服务）、`app/channels/manager.py`（消息派发器）——路由保持"薄"，业务集中于此。
- **装配/依赖注入层**：`app/gateway/deps.py` 把所有单例挂到 `app.state`，路由通过 FastAPI Depends 按需取用。
- **领域底座（排除范围）**：`packages/harness` 提供 LangGraph 图（lead_agent）、RunManager/StreamBridge、SQLAlchemy 持久化（users/threads_meta/runs/run_events/feedback 五张表）、沙箱、技能、MCP 等能力。

```
            ┌───────────────────────────────────────────────────────────────┐
            │                客户端（Web UI / useStream Hook）                │
            └───────────────┬───────────────────────────────────────────────┘
                            │ HTTP + SSE (Cookie: access_token / csrf_token)
            ┌───────────────▼───────────────────────────────────────────────┐
            │                FastAPI Gateway  (app/gateway, :8001)           │
            │  ┌─────────────────────────────────────────────────────────┐  │
            │  │ 中间件栈（外→内）：CORS(可选) → CSRFMiddleware →          │  │
            │  │               AuthMiddleware（fail-closed + contextvar） │  │
            │  └─────────────────────────────────────────────────────────┘  │
            │  routers/: models mcp memory skills artifacts uploads threads  │
            │            agents suggestions channels assistants_compat      │
            │            auth(注册/登录) feedback thread_runs runs /health  │
            │  services.py: start_run / sse_consumer / build_run_config     │
            │  deps.py: app.state 单例（stream_bridge/checkpointer/store/   │
            │           run_manager/thread_store/...）                       │
            └──────┬──────────────────────────────────┬────────────────────┘
                   │ 函数调用（进程内）                  │ HTTP 回环（langgraph-sdk
                   ▼                                  ▼ + 内部令牌 + CSRF）
   ┌───────────────────────────────┐   ┌───────────────────────────────────┐
   │  deerflow runtime (harness*,   │   │  app/channels（IM 渠道子系统）      │
   │  排除范围)                      │◀──│  MessageBus ⇄ ChannelManager      │
   │  run_agent → make_lead_agent   │   │  Feishu/Slack/Telegram/DingTalk/  │
   │  StreamBridge / RunManager     │   │  Discord/WeChat/WeCom 适配器       │
   │  SQLAlchemy 持久化/沙箱/技能    │   │  ChannelStore (JSON 映射持久化)    │
   └───────────────────────────────┘   └───────────────────────────────────┘
        * packages/harness，本报告排除范围，仅示依赖方向
```

## 2.2 模块划分与依赖关系

| 模块 | 目录 | 依赖方向 |
|------|------|---------|
| M1 网关装配 | `app/gateway/`（核心 12 文件） | 被 uvicorn 入口加载；依赖 M2/M3/M4 与 harness |
| M2 认证授权 | `app/gateway/auth/`（+ repositories） | 被 M1、M3、M5 引用；依赖 harness 持久化引擎 |
| M3 路由层 | `app/gateway/routers/`（16 文件） | 依赖 M1（deps/services/authz/path_utils）与 harness |
| M4 Run 服务 | `app/gateway/services.py`（归入 M1 描述） | 依赖 harness runtime；被 thread_runs/runs 调用 |
| M5 渠道核心 | `app/channels/`（base/bus/manager/service/store/commands） | 依赖 M3 暴露的 HTTP API（回环）与 harness |
| M6 渠道实现 | `app/channels/{feishu,slack,...}.py`（7 文件） | 实现 M5 的 Channel 抽象 |
| M7 运维/调试 | `scripts/migrate_user_isolation.py`、`debug.py`、`auth/reset_admin.py` | 独立 CLI，依赖 harness |

模块间依赖关系图（箭头 = 依赖）：

```
uvicorn 入口 ──▶ M1 网关装配 ──▶ M3 路由层 ──▶ M2 认证授权 ──▶ harness 持久化
   │                │               │
   │                └──▶ M5 渠道核心 ─┐
   │                                  │ (HTTP 回环, langgraph-sdk)
   └──▶ harness (langgraph.json 模式) ◀┘
M6 渠道实现 ──▶ M5 (Channel 抽象 / MessageBus)
M7 运维脚本 ──▶ harness (paths/engine)
```

## 2.3 核心数据流：一次流式 Agent 请求的完整路径

以「前端发起一次流式对话」为例（文件 + 函数级）：

1. `POST /api/threads/{thread_id}/runs/stream`（请求体 `RunCreateRequest`，`routers/thread_runs.py:36`）
2. → 中间件栈：`CSRFMiddleware.dispatch`（`csrf_middleware.py:70`，校验双 Cookie）→ `AuthMiddleware.dispatch`（`auth_middleware.py:75`，Cookie→JWT→用户→contextvar）
3. → `@require_permission("runs","create",owner_check=True,require_existing=True)`（`authz.py:197`，`threads_meta` 属主校验）
4. → `thread_runs.stream_run`（`thread_runs.py:105`）→ `services.start_run`（`services.py:229`）：
   - `RunManager.create_or_reject` 创建 RunRecord（并发策略 reject → 409）
   - `thread_store` upsert 线程元数据（让 `/threads/search` 可见）
   - `resolve_agent_factory` → `make_lead_agent`；`normalize_input` 把消息 dict 转 `HumanMessage`
   - `build_run_config` + `merge_run_context_overrides` 组装 RunnableConfig（含自定义 agent_name）
   - `asyncio.create_task(run_agent(...))` 在后台执行 LangGraph 图
5. → 返回 `StreamingResponse(sse_consumer(...))`（`services.py:318`）：`bridge.subscribe(run_id, last_event_id)` 消费后台事件，逐帧 `format_sse` 输出；心跳哨兵转 `: heartbeat` 注释帧；`END_SENTINEL` 后发 `event: end` 收尾；`finally` 按 `on_disconnect` 决定取消或放行后台任务
6. → 后台 `run_agent`（harness）驱动 lead_agent 执行，事件/消息/token 用量分别落入 StreamBridge、RunEventStore、RunRepository
7. 客户端断线重连时携带 `Last-Event-ID`，从 bridge 缓冲续播（`services.py:330`）

IM 渠道数据流见第 7 章时序图。

---

# 第 3 章 目录结构详解

```
deer-flow-backend-2.0-m1-rc0/
├── app/                          → 应用主包（本报告主体）
│   ├── __init__.py               → 空包标记
│   ├── gateway/                  → 【模块 M1/M2/M3】FastAPI 网关
│   │   ├── app.py                → 应用工厂 + lifespan + 管理员引导/孤儿线程迁移
│   │   ├── config.py             → GatewayConfig（host/port/docs 开关）
│   │   ├── deps.py               → app.state 单例装配 + 请求级 Getter + 用户解析
│   │   ├── services.py           → Run 生命周期服务（start_run/sse_consumer）
│   │   ├── authz.py              → 权限常量 + @require_auth/@require_permission
│   │   ├── auth_middleware.py    → 全局认证中间件（fail-closed）
│   │   ├── csrf_middleware.py    → CSRF 双 Cookie 中间件
│   │   ├── internal_auth.py      → 进程内内部令牌（渠道回调用）
│   │   ├── langgraph_auth.py     → LangGraph Server 模式认证桥
│   │   ├── path_utils.py         → 沙箱虚拟路径 → 宿主机路径
│   │   ├── utils.py              → 日志注入防护工具
│   │   ├── auth/                 → 认证子模块（JWT/bcrypt/Provider/仓库/CLI）
│   │   │   └── repositories/     → UserRepository 抽象 + SQLAlchemy 实现
│   │   └── routers/              → 16 个业务路由模块
│   └── channels/                 → 【模块 M5/M6】IM 渠道子系统
│       ├── base.py               → Channel 抽象基类
│       ├── message_bus.py        → Inbound/Outbound 消息 + MessageBus
│       ├── manager.py            → ChannelManager 派发器（核心）
│       ├── service.py            → ChannelService 生命周期 + 单例
│       ├── store.py              → chat↔thread 映射 JSON 持久化
│       ├── commands.py           → 已知 / 命令集合
│       └── {feishu,slack,telegram,dingtalk,discord,wechat,wecom}.py → 7 个平台适配器
├── scripts/
│   └── migrate_user_isolation.py → 一次性迁移：线程目录/记忆 → 按用户布局
├── debug.py                      → lead_agent 交互式调试 REPL
├── pyproject.toml                → 项目元数据 + uv workspace 声明
├── langgraph.json                → LangGraph Server 模式配置（图/认证/checkpointer）
├── Makefile                      → install/dev/gateway/test/lint/format
├── Dockerfile                    → 三阶段构建（builder/dev/runtime）
├── .python-version               → 3.12
├── README.md / CONTRIBUTING.md / CLAUDE.md / AGENTS.md → 文档（未逐文件分析）
├── ruff.toml / .gitignore / .vscode/ → lint/IDE 配置（排除）
├── docs/                         → 文档（排除，仅作理解参考）
├── tests/                        → 测试（排除）
└── packages/harness/             → deerflow-harness 包（★ 排除范围，不分析）
```

| 目录路径 | 职责说明 | 关键内容 |
|---------|---------|---------|
| `app/gateway/` | 网关装配与横切关注点 | `create_app()` 工厂、lifespan 引导、中间件栈、单例注入、Run 服务层 |
| `app/gateway/auth/` | 账号体系 | JWT 签发/校验、bcrypt v2 哈希、LocalAuthProvider、SQLite 用户仓库、管理员密码重置 CLI、凭据文件安全落盘 |
| `app/gateway/auth/repositories/` | 用户存储抽象 | `UserRepository` ABC + `SQLiteUserRepository`（复用 harness 共享引擎） |
| `app/gateway/routers/` | HTTP 端点 | 16 个模块、15 组 API 前缀 + `/health`，覆盖模型/MCP/记忆/技能/产物/上传/线程/Run/反馈/认证/渠道/Agent/建议/兼容层 |
| `app/channels/` | IM 集成核心 | 消息总线、派发器、生命周期服务、映射存储、7 平台适配器 |
| `scripts/` | 数据迁移 | 单用户 → 多用户目录布局迁移（幂等、支持 dry-run） |

---

# 第 5 章 文件清单总表（第 1 批交付）

覆盖全部纳入范围的生产文件（60 个源/配置文件 + 2 个空包标记）。`主要依赖` 列中 `harness:*` 指 `packages/harness` 提供的 `deerflow.*` 命名空间（排除范围，仅列引用点）。

## 5.1 根目录

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---------|---------|------|---------|---------|
| `pyproject.toml` | 全局 | 项目元数据、依赖、uv workspace（成员 `packages/harness`）、pytest 标记 | — | deerflow-harness(workspace)、fastapi、uvicorn 等 15 项 |
| `langgraph.json` | 全局 | LangGraph Server 模式配置：注册 `lead_agent` 图、认证路径、checkpointer 路径、`.env` | `graphs.lead_agent = deerflow.agents:make_lead_agent` | harness |
| `Makefile` | 全局 | install/dev/gateway/test/lint/format 六个任务 | — | uv、uvicorn、pytest、ruff |
| `Dockerfile` | 全局 | 三阶段构建：builder（编译+Node22）/dev（保留工具链+DockerCLI）/runtime（精简镜像） | — | python:3.12-slim、uv、docker:cli |
| `debug.py` | M7 调试 | lead_agent 交互式 REPL；日志重定向 `debug.log`；延迟导入避免导入期副作用泄漏到终端 | `main()` | harness(config/agents/mcp)、prompt_toolkit(可选) |

## 5.2 app/channels（渠道模块 14 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---------|---------|------|---------|---------|
| `app/channels/__init__.py` | M5 | 包门面 | `Channel`、`InboundMessage`、`MessageBus`、`OutboundMessage` | base、message_bus |
| `app/channels/base.py` | M5 | Channel 抽象基类：start/stop/send/send_file 契约、入站工厂、出站回调路由（文本先发、成功后才传附件） | `Channel`(ABC)、`_make_inbound`、`_on_outbound`、`receive_file` | message_bus |
| `app/channels/message_bus.py` | M5 | 消息数据类（Inbound/Outbound/ResolvedAttachment）+ 异步 pub/sub 总线（asyncio.Queue 入站、回调列表出站） | `InboundMessage`、`OutboundMessage`、`ResolvedAttachment`、`InboundMessageType`、`MessageBus` | asyncio |
| `app/channels/commands.py` | M5 | 渠道命令唯一权威集合，保证解析器与派发器同步 | `KNOWN_CHANNEL_COMMANDS` | — |
| `app/channels/manager.py` | M5 | 核心派发器：消费入站队列→建/复用线程→调 Gateway API（runs.wait 或 runs.stream）→产物解析→发布出站；含并发信号量、会话参数三层合并、流式文本累积与节流 | `ChannelManager`、`InvalidChannelSessionConfigError`、`register_inbound_file_reader`、`INBOUND_FILE_READERS` | langgraph-sdk、httpx、gateway(csrf/internal_auth)、harness(paths/uploads/user_context) |
| `app/channels/service.py` | M5 | 渠道生命周期管理：读 `config.yaml` 的 `channels:` 段，懒加载实例化渠道，暴露全局单例与状态查询 | `ChannelService`、`get_channel_service`、`start_channel_service`、`stop_channel_service` | manager、store、bus、harness(reflection.resolve_class/config) |
| `app/channels/store.py` | M5 | chat↔thread 映射 JSON 持久化（原子写：临时文件+replace），键 `channel:chat[:topic]` | `ChannelStore`（`get_thread_id`/`set_thread_id`/`remove`/`list_entries`） | harness(paths) |
| `app/channels/feishu.py` | M6 | 飞书 WebSocket 渠道：卡片消息流式更新、OK/DONE 表情回应、文件/图片收发、富文本解析、独立线程规避 uvloop 冲突 | `FeishuChannel`（`supports_streaming=True`） | lark-oapi、harness(paths/sandbox/user_context) |
| `app/channels/slack.py` | M6 | Slack Socket Mode 渠道：Markdown→mrkdwn 转换、eyes/✓/× 表情、线程回复、用户白名单 | `SlackChannel` | slack-sdk、markdown-to-mrkdwn |
| `app/channels/telegram.py` | M6 | Telegram 长轮询渠道：私聊单线程/群聊按回复分话题、命令处理器、消息分片回复链 | `TelegramChannel` | python-telegram-bot |
| `app/channels/dingtalk.py` | M6 | 钉钉 Stream Push 渠道：accessToken 缓存刷新、sampleMarkdown 降级适配（表格/代码块转引用）、AI 卡片流式更新、媒体上传 | `DingTalkChannel`、`_DingTalkMessageHandler` | dingtalk-stream、httpx |
| `app/channels/discord.py` | M6 | Discord 渠道：自动为消息建线程、2000 字符分片（按换行优先切分）、跨事件循环安全发送 | `DiscordChannel` | discord.py（可选导入） |
| `app/channels/wechat.py` | M6 | 微信 iLink 渠道：长轮询+游标持久化、二维码登录引导、AES-128-ECB 媒体加解密与 CDN 直传、文件类型白名单 | `WechatChannel`、`MessageItemType`、`UploadMediaType` | httpx、cryptography |
| `app/channels/wecom.py` | M6 | 企业微信渠道：WebSocket 流式回复（reply_stream）、分块媒体上传（init/chunk/finish 三段协议）、上下文帧缓存 | `WeComChannel`（`supports_streaming=True`） | wecom-aibot-python-sdk(aibot) |

## 5.3 app/gateway 核心（12 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---------|---------|------|---------|---------|
| `app/gateway/__init__.py` | M1 | 包门面 | `app`、`create_app`、`GatewayConfig`、`get_gateway_config` | app、config |
| `app/gateway/app.py` | M1 | 应用工厂：中间件装配、15 路由注册、`/health`；lifespan：配置加载→LangGraph 运行时→管理员引导/孤儿线程迁移→渠道服务启停（带 5s 超时上限） | `create_app`、`lifespan`、`_ensure_admin_user`、`_migrate_orphaned_threads`、`_iter_store_items`、`app` | 全部 routers、auth/csrf 中间件、deps、harness(config/persistence) |
| `app/gateway/config.py` | M1 | 网关配置 Pydantic 模型 + 环境变量懒加载单例 | `GatewayConfig`、`get_gateway_config` | pydantic、os |
| `app/gateway/deps.py` | M1 | `langgraph_runtime()` 装配/拆卸全部运行时单例到 `app.state`；请求级 Getter（缺依赖→503）；用户解析链（Cookie→JWT→User）与 LocalAuthProvider 缓存单例 | `langgraph_runtime`、`get_config`、`get_stream_bridge` 等 8 个 Getter、`get_run_context`、`get_local_provider`、`get_current_user_from_request`、`get_optional_user_from_request`、`get_current_user` | harness(runtime/persistence/config)、auth 模块 |
| `app/gateway/services.py` | M1/M4 | Run 服务层：SSE 帧格式化、输入/流模式归一化、上下文白名单合并、RunnableConfig 构建、`start_run`（建 RunRecord+后台任务）、`sse_consumer`（订阅 bridge+断连语义） | `format_sse`、`start_run`、`sse_consumer`、`build_run_config`、`normalize_input`、`normalize_stream_modes`、`merge_run_context_overrides`、`resolve_agent_factory` | deps、utils、harness(runtime)、langchain-core |
| `app/gateway/authz.py` | M1 | 权限常量（threads/runs 六权限）、AuthContext、`@require_auth`、`@require_permission(owner_check, require_existing)`（属主校验走 ThreadMetaStore.check_access） | `Permissions`、`AuthContext`、`require_auth`、`require_permission`、`get_auth_context` | fastapi、deps、harness(thread_meta) |
| `app/gateway/auth_middleware.py` | M1 | 全局认证中间件（fail-closed）：公共路径放行、内部令牌旁路、Cookie 存在性+严格 JWT 校验、用户写入 `request.state` 与 `user_context` contextvar | `AuthMiddleware`、`_PUBLIC_PATH_PREFIXES`、`_PUBLIC_EXACT_PATHS` | authz、deps、internal_auth、harness(user_context) |
| `app/gateway/csrf_middleware.py` | M1 | CSRF 双 Cookie 中间件：状态变更方法校验 Cookie↔Header 一致（常数时间比较）；登录类端点成功后种新 csrf Cookie | `CSRFMiddleware`、`CSRF_COOKIE_NAME`、`CSRF_HEADER_NAME`、`generate_csrf_token`、`is_secure_request`、`should_check_csrf`、`get_csrf_token` | secrets、starlette |
| `app/gateway/internal_auth.py` | M1 | 进程级内部令牌（启动时随机 32B），供 ChannelManager 以 SDK 回环调用 Gateway 时通过认证；合成内部用户 | `INTERNAL_AUTH_HEADER_NAME`、`create_internal_auth_headers`、`is_valid_internal_auth_token`、`get_internal_user` | secrets、harness(user_context.DEFAULT_USER_ID) |
| `app/gateway/langgraph_auth.py` | M1 | LangGraph Server 模式认证桥：`@auth.authenticate`（同一 Cookie→JWT→用户→token_version 链 + CSRF）与 `@auth.on`（写入盖 user_id 章、读取按 user_id 过滤） | `auth`(langgraph_sdk.Auth)、`authenticate`、`add_owner_filter` | langgraph-sdk、auth(jwt/errors)、deps |
| `app/gateway/path_utils.py` | M1 | 线程虚拟路径解析（带 user_id 归属）；遍历攻击→403、非法路径→400 | `resolve_thread_virtual_path` | harness(paths/user_context) |
| `app/gateway/utils.py` | M1 | 日志参数清洗（去 `\n`/`\r`/`\x00` 防日志注入） | `sanitize_log_param` | — |

## 5.4 app/gateway/auth（认证模块 13 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---------|---------|------|---------|---------|
| `app/gateway/auth/__init__.py` | M2 | 包门面，聚合导出 | `AuthConfig`、`create_access_token`、`decode_token`、`hash_password`、`verify_password`、`User`、`UserResponse`、`AuthProvider`、`LocalAuthProvider`、`UserRepository` 等 | — |
| `app/gateway/auth/config.py` | M2 | JWT 配置（密钥、7 天有效期、GitHub OAuth 占位）；密钥缺失时自动生成临时密钥并告警 | `AuthConfig`、`get_auth_config`、`set_auth_config` | pydantic、dotenv、secrets |
| `app/gateway/auth/errors.py` | M2 | 类型化错误：`AuthErrorCode`（8 种）、`TokenError`（3 种）、结构化响应体、映射函数 | `AuthErrorCode`、`TokenError`、`AuthErrorResponse`、`token_error_to_code` | enum、pydantic |
| `app/gateway/auth/jwt.py` | M2 | JWT 签发（HS256，含 `ver`=token_version）与解码（区分过期/坏签名/畸形三类错误） | `TokenPayload`、`create_access_token`、`decode_token` | pyjwt、config、errors |
| `app/gateway/auth/models.py` | M2 | 用户领域模型（UUID 主键、邮箱、bcrypt 哈希、admin/user 角色、OAuth 关联、needs_setup、token_version）与对外响应模型 | `User`、`UserResponse` | pydantic(EmailStr) |
| `app/gateway/auth/password.py` | M2 | 版本化密码哈希：v1=裸 bcrypt（72 字节截断风险）、v2=SHA-256 预哈希+bcrypt（前缀 `$dfv2$`）；校验自动识别版本；异步包装避免阻塞事件循环 | `hash_password`、`verify_password`、`needs_rehash`、`hash_password_async`、`verify_password_async` | bcrypt、asyncio.to_thread |
| `app/gateway/auth/providers.py` | M2 | 认证 Provider 抽象（authenticate/get_user 两方法），为未来 OAuth 扩展预留 | `AuthProvider`(ABC) | abc |
| `app/gateway/auth/local_provider.py` | M2 | 本地邮箱密码 Provider：认证（含机会式哈希升级 rehash）、建号、按 OAuth/邮箱/ID 查询、计数 | `LocalAuthProvider` | models、password、repositories |
| `app/gateway/auth/credential_file.py` | M2 | 管理员初始/重置凭据安全落盘：原子 `os.open(0600)` 写文件，避免明文密码进日志被采集 | `write_initial_credentials` | harness(paths) |
| `app/gateway/auth/reset_admin.py` | M2 | CLI：`python -m app.gateway.auth.reset_admin [--email]` 重置管理员密码，随机 16B 密码写 0600 文件，token_version+1 使旧会话失效 | `main`、`_run` | repositories、password、credential_file、harness(engine/config) |
| `app/gateway/auth/repositories/__init__.py` | M2 | 空包标记 | — | — |
| `app/gateway/auth/repositories/base.py` | M2 | 用户仓库抽象（7 方法）+ `UserNotFoundError`（LookupError 子类，区分并发删除） | `UserRepository`(ABC)、`UserNotFoundError` | abc、models |
| `app/gateway/auth/repositories/sqlite.py` | M2 | SQLAlchemy 异步实现：行↔模型转换（读时补 UTC tzinfo）、唯一约束冲突→ValueError、更新缺行→硬失败 | `SQLiteUserRepository` | sqlalchemy(async)、harness(UserRow)、models、base |

## 5.5 app/gateway/routers（路由模块 16 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---------|---------|------|---------|---------|
| `app/gateway/routers/__init__.py` | M3 | 包门面（聚合导入 9 个模块；其余 7 个由 `app.py` 直接按子模块导入） | `artifacts`…`uploads` 9 个模块引用 | — |
| `routers/models.py` | M3 | `GET /api/models`、`GET /api/models/{name}`：从 AppConfig 列出模型（剥离敏感字段）+token 用量显示开关 | `router` | deps(get_config)、harness(app_config) |
| `routers/mcp.py` | M3 | `GET/PUT /api/mcp/config`：读写 `extensions_config.json`（MCP server 注册表，含 OAuth 配置），PUT 后重载配置缓存 | `router` | harness(extensions_config) |
| `routers/memory.py` | M3 | 记忆 CRUD：get/reload/clear、facts 增删改、export/import、config/status 共 10 端点（按 user_id 隔离） | `router` | harness(memory.updater/memory_config/user_context) |
| `routers/skills.py` | M3 | 技能管理：列表/详情/启停（写 extensions_config.json）、.skill 归档安装、自定义技能内容编辑/删除/历史/回滚（均过安全扫描器，成功后刷新系统提示词缓存） | `router` | harness(skills/paths)、path_utils |
| `routers/artifacts.py` | M3 | `GET /api/threads/{id}/artifacts/{path}`：产物下载；HTML/XHTML/SVG 强制附件下载防同源脚本执行；支持从 .skill ZIP 内直接取文件；文本嗅探（无 `\x00` 即文本） | `router`、`is_text_file_by_content`、`ACTIVE_CONTENT_MIME_TYPES` | authz、path_utils |
| `routers/uploads.py` | M3 | 线程上传：多文件上传（限额校验、8KB 分块写、失败清理）、limits/list/delete；可选宿主侧文档转 Markdown；非线程挂载型沙箱需同步写入沙箱 | `router`、`UploadLimits` | authz、deps、harness(uploads/sandbox/file_conversion/paths) |
| `routers/threads.py` | M3 | 线程管理：创建（幂等，写 thread_meta+空检查点）/搜索/PATCH/详情/删除（文件系统+检查点+meta 三清）/state 读写（HITL 恢复、标题同步）/history 分页；入站 metadata 剥离服务端保留键（owner_id/user_id） | `router` 及 10 个 Pydantic 模型 | authz、deps、harness(checkpointer/paths/serialization/time) |
| `routers/thread_runs.py` | M3 | LangGraph Platform 兼容 Run API：create/stream/wait/cancel/join/双方法 stream、线程消息/事件/token 用量；SSE 含 `Content-Location` 供 SDK 提取 run_id | `router`、`RunCreateRequest`、`RunResponse` | authz、deps、services、harness(runtime) |
| `routers/runs.py` | M3 | 无状态 Run：`POST /api/runs/stream|wait`（自动建临时线程或复用 body 中的 thread_id）；`GET /api/runs/{id}/messages|feedback`（仓库层 contextvar 属主过滤） | `router` | authz、deps、services、thread_runs(RunCreateRequest) |
| `routers/feedback.py` | M3 | 反馈：create/upsert/delete/list/stats，PUT 幂等；先验证 run 属于该线程 | `router` | authz、deps |
| `routers/suggestions.py` | M3 | `POST /api/threads/{id}/suggestions`：调 LLM 生成 n 条追问（严格 JSON 数组解析、代码栅栏剥离、异常吞掉返回空列表） | `router` 及解析函数 | authz、deps、harness(models.create_chat_model)、langchain-core |
| `routers/agents.py` | M3 | 自定义 Agent CRUD（config.yaml + SOUL.md 落盘，agents_api.enabled 开关控制）+ 全局 USER.md 读写 | `router` | harness(agents_config/agents_api_config/paths)、yaml |
| `routers/channels.py` | M3 | `GET /api/channels/` 状态查询、`POST /api/channels/{name}/restart` 重启单渠道 | `router` | channels.service（运行时懒导入） |
| `routers/assistants_compat.py` | M3 | LangGraph Platform assistants 兼容桩：search/get/graph/schemas（满足 useStream 初始化；lead_agent + 自定义 Agent 列表） | `router` | harness(agents_config) |
| `routers/auth.py` | M3 | 认证端点 10 个：login/local（登录+限流）、register、logout、change-password（兼首启 setup）、me、setup-status（60s 冷却）、initialize（首管理员，409 防重）、OAuth 占位（501）；强密码校验（SecLists 常用密码黑名单） | `router` 及限流/密码校验函数 | auth 包、csrf_middleware、deps |

## 5.6 scripts（1 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---------|---------|------|---------|---------|
| `scripts/migrate_user_isolation.py` | M7 | 一次性迁移：legacy `threads/` 目录按 DB 属主归位到 `users/<uid>/threads/`、`memory.json` 迁至 default 用户；冲突移入 `migration-conflicts/`；幂等、支持 `--dry-run` | `migrate_thread_dirs`、`migrate_memory`、`main` | harness(paths)、sqlite3(裸驱动避免异步依赖) |

> **完整性说明**：`app/__init__.py` 与 `app/gateway/auth/repositories/__init__.py` 为空包标记文件，已列入上表；`tests/`、`docs/`、`.vscode/`、`packages/harness/`、`ruff.toml`、`uv.lock`、`.gitignore`、根目录四个 Markdown 文档均属排除范围，未列入。

---

# 第 4 章 核心模块详解（第 2~4 批交付）

## 4.1 模块：网关装配层（`app/gateway` 核心）

### 模块职责
构建 FastAPI 应用并完成三件事：**中间件栈装配**（安全横切）、**运行时单例装配**（LangGraph 基础设施）、**启动/停机编排**（lifespan）。它是整个后端的组合根（Composition Root）。

### 文件组成
`app.py`（应用工厂与 lifespan）、`config.py`（网关配置）、`deps.py`（依赖注入中枢）、`authz.py`（授权装饰器）、`auth_middleware.py`、`csrf_middleware.py`、`internal_auth.py`、`langgraph_auth.py`（四种安全机制分见第 8 章）、`path_utils.py`、`utils.py`、`services.py`（见 4.2）。

### 关键类 / 函数解析

#### `create_app() -> FastAPI`（`app/gateway/app.py:215-385`）
- **签名**：无参；返回配置完成的 FastAPI 实例。
- **实现步骤**：
  1. `get_gateway_config()` 读配置（`app.py:221`）；
  2. 按 `enable_docs` 决定是否暴露 `/docs`、`/redoc`、`/openapi.json`（`app.py:222`）——生产可关闭文档面；
  3. 构造 FastAPI（标题/描述/version/lifespan/openapi_tags）；
  4. 依次 `add_middleware(AuthMiddleware)` → `add_middleware(CSRFMiddleware)` → 可选 `CORSMiddleware`（`app.py:305-328`）。**Starlette 语义：后添加者在最外层**，故请求实际经过顺序为 **CORS → CSRF → Auth → 路由**；
  5. CORS 通配符防御：`GATEWAY_CORS_ORIGINS` 含 `*` 且 `allow_credentials=True` 会被浏览器拒绝，代码检测到 `*` 时记 error 并剔除（`app.py:316-319`）；
  6. 注册 15 个路由 + `/health` 内联端点（`app.py:332-383`）。
- **副作用**：模块导入即执行 `app = create_app()`（`app.py:389`），uvicorn 以 `app.gateway.app:app` 引用。
- **调用关系**：被 uvicorn/Makefile/Dockerfile 调用；内部调用 config/auth/csrf 中间件与全部 routers。

#### `lifespan(app)`（`app/gateway/app.py:161-212`，`@asynccontextmanager`）
- **启动序**：① `get_app_config()` + `apply_logging_level`（失败直接抛 RuntimeError 阻止启动，`app.py:166-173`）→ ② `async with langgraph_runtime(app)` 装配运行时单例 → ③ `_ensure_admin_user(app)`（须在 ② 之后，因为线程迁移需要 `app.state.store`）→ ④ `start_channel_service`（IM 渠道，失败仅告警不阻断）→ `yield`。
- **停机序**：`stop_channel_service()` 用 `asyncio.wait_for` 限时 **5 秒**（`_SHUTDOWN_HOOK_TIMEOUT_SECONDS`，`app.py:49`），防止 uvicorn reload 监督器反复向卡死的 worker 发信号；随后退出 `langgraph_runtime` 上下文（关闭引擎）。
- **设计要点**：启动顺序有硬依赖——persistence 引擎必须先于 checkpointer 初始化（见 deps 的注释），管理员迁移必须晚于 store。

#### `_ensure_admin_user(app)`（`app/gateway/app.py:52-121`）
- **功能**：首启检测与「无认证 → 有认证」升级迁移。
- **实现**：
  1. `get_local_provider()`（auth 持久化未就绪时捕获 RuntimeError 跳过，保证测试/特殊引导路径可启动，`app.py:80-85`）；
  2. `count_admin_users()==0` → 仅打日志提示访问 `/setup` 创建首个管理员，**不自动建号**（`app.py:93-98`）；
  3. 已有管理员 → 查首个 admin 行，调用 `_migrate_orphaned_threads(store, admin_id)` 把 `metadata.user_id` 缺失的 LangGraph 线程划归管理员（`app.py:100-121`，非致命）。
- **为什么需要**：老版本无用户体系，升级后存量线程必须挂上属主才会出现在属主的 `/threads/search` 中；SQL 侧无需迁移（四张含 user_id 的表随 auth 模块 `create_all` 才出现，不可能有 NULL 属主行，`app.py:68-71` 注释）。

#### `_iter_store_items(store, namespace, page_size=500)`（`app/gateway/app.py:124-141`）
- 游标式分页异步生成器：`asearch(limit, offset)` 循环；空页或短页终止。替代旧的硬编码 `limit=1000`，避免孤儿超过一页时静默丢数据。

#### `_migrate_orphaned_threads(store, admin_user_id) -> int`（`app/gateway/app.py:144-158`）
- 遍历 `("threads",)` 命名空间，对 `metadata.user_id` 为空的项补写 admin id 并 `aput` 回写，返回迁移计数。

#### `langgraph_runtime(app)`（`app/gateway/deps.py:42-97`，`@asynccontextmanager`）
- **功能**：以 `AsyncExitStack` 装配全部运行时单例，退出时逆序拆卸（保证 close_engine 最后执行）。
- **装配清单（写入 `app.state`）**：
  | 单例 | 工厂 | 说明 |
  |------|------|------|
  | `stream_bridge` | `make_stream_bridge(config)` | SSE 事件桥 |
  | （引擎） | `init_engine_from_config(config.database)` | 先于 checkpointer（自动建库逻辑） |
  | `checkpointer` | `make_checkpointer(config)` | LangGraph 检查点 |
  | `store` | `make_store(config)` | LangGraph KV 存储 |
  | `run_store` | `RunRepository(sf)` 或 `MemoryRunStore()` | SQL 可用时走库，否则内存 |
  | `feedback_repo` | `FeedbackRepository(sf)` 或 `None` | 同上 |
  | `thread_store` | `make_thread_store(sf, store)` | 线程元数据（SQL/内存双形态） |
  | `run_event_store` | `make_run_event_store(config.run_events)` | 事件存储（配置驱动后端） |
  | `run_manager` | `RunManager(store=run_store)` | Run 生命周期 |
- **Getter 生成器 `_require(attr, label)`（`deps.py:105-115`）**：闭包工厂批量生产 FastAPI 依赖——读 `app.state.<attr>`，缺失抛 503；并用 `dep.__name__ = f"get_{attr}"` 修正闭包名称使 OpenAPI 文档可读。这是一种**元编程消除样板**的手法。

#### `get_current_user_from_request(request)`（`app/gateway/deps.py:186-223`）
- **功能**：请求 → 用户的严格解析链，是认证体系的中枢。
- **实现步骤**：① 取 Cookie `access_token`（缺失→401 `not_authenticated`）→ ② `decode_token`（返回 `TokenError` 变体→401，错误码经 `token_error_to_code` 细分为 expired/invalid）→ ③ `provider.get_user(payload.sub)`（无此用户→401 `user_not_found`）→ ④ `user.token_version != payload.ver` → 401 `token_invalid`（"Token revoked (password changed)"，`deps.py:216-221`）。
- **被调用方**：AuthMiddleware、`@require_auth`/`@require_permission`（间接经 `_authenticate`）、auth 路由的 `/me`、`/change-password`。
- **配套**：`get_optional_user_from_request`（吞 401 返回 None，`deps.py:226-234`）与 `get_current_user`（仅取 id 字符串的轻量适配，`deps.py:237-245`，供 feedback 等只需标识的调用方）。

#### `resolve_thread_virtual_path(thread_id, virtual_path)`（`app/gateway/path_utils.py:11-29`）
- 委托 `get_paths().resolve_virtual_path(..., user_id=get_effective_user_id())`；`ValueError` 文案含 "traversal" → 403，否则 400。路径解析的属主隔离依赖 auth 中间件设置的 contextvar。

### 模块对外接口
`app`（ASGI 实例）、`create_app`、`get_gateway_config`、`deps.get_*` 系列（被所有路由通过 `Depends` 消费）。

---

## 4.2 模块：Run 生命周期服务（`app/gateway/services.py`）

### 模块职责
把「创建 Run + 后台执行 + SSE 推送」的业务逻辑从 HTTP 路由剥离，`thread_runs` 与 `runs` 两个路由模块均为薄封装（`services.py:1-6` 的模块注释明确此意图）。

### 关键类 / 函数解析

#### `start_run(body, thread_id, request) -> RunRecord`（`services.py:229-315`）
- **参数**：`body` 为 `RunCreateRequest`（Pydantic，定义在 `routers/thread_runs.py:36-56`；此处类型标 `Any` 规避与路由模块的循环导入，`services.py:237-240` 注释）。
- **实现步骤**：
  1. 取三单例：bridge / run_mgr / run_ctx（`services.py:246-248`）；
  2. `on_disconnect` 字符串映射为 `DisconnectMode` 枚举（`services.py:250`）；
  3. `run_mgr.create_or_reject(...)`：`ConflictError`→409、`UnsupportedStrategyError`→501（`services.py:253-264`）——这是** multitask_strategy=reject 并发语义**的 HTTP 呈现；
  4. thread_meta upsert：无记录则 `create`，有则 `update_status("running")`；失败仅告警（非致命），保证「stateless run 未显式建线程也能被 /threads/search 搜到」（`services.py:266-280`）；
  5. `resolve_agent_factory(body.assistant_id)`——**恒返回 `make_lead_agent`**：自定义 Agent 的分流在图内部读取 `agent_name` 完成（`services.py:139-150`）；
  6. `normalize_input`：LangGraph Platform 的 `{messages:[{role,content}]}` → `HumanMessage` 列表（非 user/human 角色暂也转 HumanMessage，代码内留 TODO，`services.py:90-91`）；
  7. `build_run_config(...)` 组装 RunnableConfig（见下）；
  8. `merge_run_context_overrides(config, body.context)`：白名单键（`_CONTEXT_CONFIGURABLE_KEYS`，8 个：model_name/mode/thinking_enabled/reasoning_effort/is_plan_mode/subagent_enabled/max_concurrent_subagents/agent_name/is_bootstrap）**同时**写入 `configurable` 与 `context`——兼容旧读取方与 LangGraph ≥1.1.9 的 `ToolRuntime.context` 消费方（issue #2677，`services.py:101-136`）；
  9. `asyncio.create_task(run_agent(...))` 启动后台执行，task 句柄存 `record.task`（`services.py:294-309`）。
- **副作用**：DB 写（thread_meta、runs 表）、后台任务创建、bridge 订阅注册。

#### `build_run_config(thread_id, request_config, metadata, *, assistant_id)`（`services.py:153-221`）
- **核心规则**：
  - 基础 `{"recursion_limit": 100}`；
  - LangGraph ≥0.6 语义：请求同时带 `context` 与 `configurable` 时**优先 context** 并告警（两者并存会被新版 LangGraph 拒绝，`services.py:179-194`）；否则合并 `configurable`（注入 `thread_id`）；
  - 自定义 assistant：`assistant_id != "lead_agent"` 时归一化（小写、`_`→`-`、正则 `[a-z0-9-]+` 校验，非法抛 ValueError→400），把 `agent_name` 写入当前活跃容器且**不覆盖**调用方已显式给出的值（`services.py:207-218`）；
  - metadata 合入 `config.metadata`。

#### `sse_consumer(bridge, record, request, run_mgr)`（`services.py:318-349`）
- 异步生成器，产出 SSE 文本帧：
  - 入口读 `Last-Event-ID` 头交给 `bridge.subscribe(..., last_event_id=...)` 实现**断线续传**；
  - 每轮 `await request.is_disconnected()` 检测客户端断开；
  - `HEARTBEAT_SENTINEL` → `": heartbeat\n\n"`（SSE 注释帧，保活但不触发前端事件）；
  - `END_SENTINEL` → `format_sse("end", None, ...)` 并终止；
  - `finally` 块实现 **on_disconnect 语义**：Run 仍处 pending/running 且模式为 cancel 时调 `run_mgr.cancel(run_id)`；continue 模式则任由后台跑完、事件被丢弃（`services.py:346-349`）。
- **注意**：该生成器在 StreamingResponse 中执行，异常会中断响应流。

#### `format_sse(event, data, *, event_id)`（`services.py:43-56`）
- 帧字段顺序 `event: → data: → id: → 空行`，与 LangGraph Platform 线协议一致（`useStream` 与 Python SDK 的 SSE 解码器共同消费该格式）；`json.dumps(default=str, ensure_ascii=False)` 兜底不可序列化对象并保留中文。

### 模块对外接口
`start_run`、`sse_consumer`（仅被 thread_runs/runs 路由使用），以及若干可单测的纯函数。

---

## 4.3 模块：认证与授权（`app/gateway/auth` + `authz.py`）

### 模块职责
提供「JWT Cookie 会话 + bcrypt 密码 + 权限装饰器 + 用户仓储」的完整账号体系；设计上借鉴 LangGraph Auth（`authz.py:3` 引用其仓库），并以 Provider 抽象为 OAuth 留扩展位。

### 架构模式
- **策略模式**：`AuthProvider`(ABC) ← `LocalAuthProvider`（`providers.py:6-24`）；仓库同理 `UserRepository`(ABC) ← `SQLiteUserRepository`。
- **版本化哈希**：`$dfv<N>$` 前缀 + 双版本校验（`password.py:1-14`）。
- **装饰器链**：`@require_auth`（认证）置于 `@require_permission`（授权）之上（`authz.py:13-18` 的用法示例）。

### 关键类 / 函数解析

#### `AuthMiddleware.dispatch`（`app/gateway/auth_middleware.py:75-126`）
- **两阶段校验**：① Cookie 存在性（缺失→401 `not_authenticated`）② 严格 JWT 解析（垃圾/过期 Cookie 也 401，关闭「任意 Cookie 字符串即放行」漏洞，对应注释中 AUTH_TEST_PLAN 7.5.8，`auth_middleware.py:96-99`）。
- **旁路**：内部令牌（`X-DeerFlow-Internal-Token`）匹配时使用合成内部用户（`auth_middleware.py:80-81,108-109`）。
- **关键副作用**：
  - `request.state.user = user`、`request.state.auth = AuthContext(user, _ALL_PERMISSIONS)`——后者让 `@require_permission` 的"auth is None"分支短路，**避免每请求重复一次 JWT 解码+DB 查询**（`auth_middleware.py:116-121`）；
  - `set_current_user(user)` 设置 `deerflow.runtime.user_context` contextvar 并在 finally 中 `reset_current_user(token)`——仓储层的属主过滤（如 `runs.py:99` 的 `user_id=AUTO`）依赖它自动生效。
- **公共路径**：前缀 `/health`、`/docs`、`/redoc`、`/openapi.json` + 精确集合（login/register/logout/setup-status/initialize 五个，`auth_middleware.py:25-42`）。

#### `require_permission(resource, action, owner_check=False, require_existing=False)`（`app/gateway/authz.py:197-301`）
- **实现**：functools.wraps 包装为 async wrapper——
  1. 取/补 `request.state.auth`（AuthMiddleware 已设置则直接用）；
  2. 未认证→401；无权限→403（当前 `_ALL_PERMISSIONS` 授予登录用户全部六权限，真正的隔离靠 owner_check）；
  3. `owner_check=True`：取路径参数 `thread_id`，调 `thread_store.check_access(thread_id, user_id, require_existing=...)`；不通过→**404（而非 403，避免资源存在性泄露）**。
- **`require_existing` 的语义**（`authz.py:212-217`）：读类路由对「threads_meta 无行的旧线程」放行（宽松）；**破坏性路由**（DELETE/PATCH/状态更新）把缺行视为拒绝——防止已删除线程被他人经缺行路径重新定向（TOCTOU 防御）。
- **单测友好性**：无 Request 时注入 `_make_test_request_stub()`（带 `_deerflow_test_bypass_auth=True` 标志直接放行，`authz.py:122-128,182-183`）——绕过中间件直接调用处理函数的单测因此可行。

#### `create_access_token / decode_token`（`app/gateway/auth/jwt.py:21-55`）
- 签发：`{sub, exp, iat, ver}` + HS256；`ver` 即 token_version，是**改密即全端下线**机制的核心。
- 解码：`jwt.decode` 后按异常类型细分——`ExpiredSignatureError`→EXPIRED、`InvalidSignatureError`→INVALID_SIGNATURE、其余 PyJWTError→MALFORMED；返回 `TokenPayload | TokenError`（联合类型而非抛异常，便于调用方映射 HTTP 细粒度错误码）。

#### `hash_password / verify_password`（`app/gateway/auth/password.py:32-58`）
- v2 哈希：`bcrypt(base64(sha256(password)))`——SHA-256 预哈希突破 bcrypt 72 字节截断上限；前缀 `$dfv2$` 标版本。
- 校验：按前缀分派；无前缀裸 bcrypt 视为 v1（兼容存量数据，下次登录机会式升级）；`ValueError`（畸形盐等）**返回 False 而非崩溃**（fail-closed，`password.py:55-58`）。
- `*_async` 变体用 `asyncio.to_thread` 把 CPU 密集的 bcrypt 移出事件循环。

#### `LocalAuthProvider.authenticate(credentials) -> User | None`（`auth/local_provider.py:24-59`）
- 邮箱查用户→无密码（OAuth 用户）拒绝→`verify_password_async`→（可选）`needs_rehash` 时**机会式升级**并落库，升级失败仅告警不阻断登录（`local_provider.py:50-57`）。

#### `SQLiteUserRepository`（`auth/repositories/sqlite.py:27-127`）
- 复用 harness 共享异步引擎（与 threads_meta/runs/run_events/feedback 同库）；`_row_to_user` 读时为 SQLite 丢失的 tzinfo 补 UTC（`sqlite.py:43-44`）；`create_user` 捕获 `IntegrityError`→`ValueError`（邮箱重复的业务语义）；`update_user` 缺行抛 `UserNotFoundError` 硬失败——防止把「并发删除」误当成功（`sqlite.py:91-101`）。

#### 登录限流（`routers/auth.py:148-269`）
- 进程内 dict `ip → (fail_count, lock_until)`；5 次失败锁 300 秒；**内存上限防御**：超过 10000 条先清过期再淘汰最早一半（`auth.py:240-256`）。
- **真实 IP 信任模型**（`_get_client_ip`，`auth.py:187-222`）：以 TCP peer 为基线；仅当 peer 命中 `AUTH_TRUSTED_PROXIES`（CIDR 列表）才信任 `X-Real-IP`；**刻意不用 `X-Forwarded-For`**（首跳天然客户端可控，信任链难审计）。
- **已知限制**（代码注释自认）：多 worker 部署下每 worker 独立计数，攻击者实际可尝试 N×5 次；生产建议换 Redis/DB 计数（`auth.py:149-155`）。

#### `write_initial_credentials(email, password, *, label)`（`auth/credential_file.py:21-48`）
- 原子创建 0600 凭据文件（`os.open(O_WRONLY|O_CREAT|O_TRUNC, 0o600)`，单系统调用窗口内也不可读）；`O_TRUNC` 而非 `O_EXCL` 使重置密码路径可覆写。目的是规避 CodeQL `clear-text-logging-sensitive-data`（密码永不进日志，只回显文件路径）。

### 模块对外接口
`app.gateway.auth` 包导出 17 个符号（见 5.4 表）；`authz` 导出装饰器与 AuthContext；`AuthMiddleware`/`CSRFMiddleware` 供 `create_app` 装配。

---

## 4.4 模块：路由层（`app/gateway/routers`，16 文件）

### 模块职责
HTTP 端点集合。除 auth/channels/agents/feedback/runs 等业务端点外，最重要的两条线是：**LangGraph Platform 协议兼容**（threads/thread_runs/runs/assistants_compat）与 **DeerFlow 资产管理**（models/mcp/memory/skills/artifacts/uploads/agents）。

### 关键端点解析

#### `thread_runs.stream_run`（`routers/thread_runs.py:103-128`）
- `start_run` 后返回 `StreamingResponse(sse_consumer(...))`；响应头 `Content-Location: /api/threads/{tid}/runs/{rid}`——SDK 用**贪婪正则**从中提取 run_id，故路径必须精确指向 run 资源、不能带后缀（`thread_runs.py:122-126` 注释）；`X-Accel-Buffering: no` 禁用 nginx 缓冲。

#### `thread_runs.stream_existing_run`（`routers/thread_runs.py:236-276`）
- `api_route(methods=["GET","POST"])` 双方法端点：GET=加入既有流（joinStream）；POST+`action=interrupt|rollback`=**先取消再流式收尾**（useStream 停止按钮的实现）；`wait=1` 时等待任务真正结束返回 204。

#### `thread_runs.list_thread_messages`（`routers/thread_runs.py:284-326`）
- 跨 Run 聚合线程消息（事件存储分页）+ 反馈联表：`feedback_repo.list_by_thread_grouped` 得 `run_id→feedback` 映射，仅给**每个 run 最后一条 AI 消息**挂 `feedback` 字段（`thread_runs.py:303-324`）——前端点赞按钮的落点。

#### `runs._resolve_run`（`routers/runs.py:96-102`）
- `run_store.get(run_id)` 不传显式 user_id——仓库层经 contextvar 哨兵自动按当前用户过滤（注释 `user_id=AUTO`）；找不到一律 404（不区分"不存在"与"不属你"）。

#### `threads.create_thread`（`routers/threads.py:224-286`）
- 幂等创建：先查 `thread_store.get`，存在即原样返回；否则写 thread_meta + `checkpointer.aput(config, empty_checkpoint(), ...)` 空`检查点（使 state 端点立即可用）。入站 metadata 经 `_strip_reserved_metadata` 剥离 `owner_id/user_id`（服务端保留键）——**防客户端经 metadata echo 伪造属主**（`threads.py:36-48`）。

#### `threads.update_thread_state`（`routers/threads.py:461-548`）
- HITL（human-in-the-loop）恢复写：读最新检查点→深拷贝 channel_values 并 merge `body.values`→写新检查点（**不带 checkpoint_id 以生成新 ID**，`threads.py:513-516` 注释）；`as_node` 提供时补 `source=update`/`step+1`/`writes`；`title` 变更同步 `thread_store.update_display_name`（失败非致命）。

#### `threads._derive_thread_status`（`routers/threads.py:166-182`）
- 从检查点元数据推导状态：pending_writes 含 `__error__`→error；有 tasks→interrupted；否则 idle。

#### `uploads.upload_files`（`routers/uploads.py:169-285`）
- **限额三层**：max_files（默认 10）/max_single_file_size（50MB）/max_total_size（100MB），来自 `config.uploads`（兼容新旧键名与 dict/对象两种形态，`uploads.py:80-109`）。
- **流式写入**：8KB 分块边写边计，超限抛 413 并 `os.unlink` 半成品（`uploads.py:122-151`）；**多文件失败回滚**已写文件（`_cleanup_uploaded_paths` 逆序删除）。
- **沙箱同步**：`_uses_thread_data_mounts(provider)` 为假（非线程数据挂载型沙箱）时，`sandbox.update_file(virtual_path, bytes)` 推入沙箱；写入前 `_make_file_sandbox_writable` 补 u+w/g+w/o+w（AIO 沙箱运行时用户与网关用户不一致问题，`uploads.py:58-73`）。
- **可选文档转换**：`uploads.auto_convert_documents` 显式开启时对可转换扩展名文件生成 .md 副本（`uploads.py:154-166,242-255`）。

#### `artifacts.get_artifact`（`routers/artifacts.py:80-183`）
- **主动内容强制下载**：`text/html`、`application/xhtml+xml`、`image/svg+xml` 一律 `Content-Disposition: attachment`——防止生成物中的脚本在应用同源下执行（`artifacts.py:17-21,172-175`）。
- **.skill 归档内读**：路径含 `.skill/` 时切分为「ZIP 路径 + 内部路径」，`zipfile` 直读（含任意顶层目录前缀兼容），并加 5 分钟私有缓存头避免重复解压（`artifacts.py:119-155`）。
- **文本嗅探**：`is_text_file_by_content` 读前 8KB 判 `\x00`（`artifacts.py:36-44`）。

#### `suggestions.generate_suggestions`（`routers/suggestions.py:98-141`）
- 直接 `create_chat_model(...).ainvoke([SystemMessage, HumanMessage], config={"run_name":"suggest_agent"})`；解析链 `_strip_markdown_code_fence → _parse_json_string_list`（定位首个 `[` 与最后一个 `]` 之间做 `json.loads`，过滤非字符串/空项）；**任何异常都返回空列表**（端点永不 5xx，降级为"无建议"）。

#### `agents.*`（`routers/agents.py`）
- 自定义 Agent= 文件系统上的 `agents/<name>/{config.yaml, SOUL.md}`；名称正则 `^[A-Za-z0-9-]+$`、存储统一小写；**总开关** `_require_agents_api_enabled()`（`agents_api.enabled`，默认关，403 拒绝）。
- 更新用 `model_fields_set` 区分「字段未提交」与「显式置 null」——skills 的 None=继承全部、[]=清空、列表=白名单三态语义依赖它（`agents.py:281-304`）。
- 创建失败 `shutil.rmtree` 回滚目录（`agents.py:240-243`）。

#### `skills.*`（`routers/skills.py`）
- 安装：`resolve_thread_virtual_path` 定位 .skill 文件 → `ainstall_skill_from_archive`；编辑/回滚先 `scan_skill_content`（安全扫描器），`decision=="block"` → 400；每次写操作 `append_history`（action/author/prev_content/new_content/scanner 结论）实现审计与回滚；成功后 `refresh_skills_system_prompt_cache_async()` 让 Agent 系统提示词即时生效。

#### `auth.initialize_admin`（`routers/auth.py:429-458`）
- 双重防线：前置 `count_admin_users()>0`→409；并发竞态下 `create_user` 的 IntegrityError 也映射 409（`auth.py:448-453`）。

#### `mcp.update_mcp_configuration`（`routers/mcp.py:104-169`）
- 写 `extensions_config.json`（保留 skills 段）→ `reload_extensions_config()` 刷新缓存；**不主动重置 MCP 工具缓存**——LangGraph Server 独立进程靠 mtime 检测自动重初始化（`mcp.py:160-162` 注释）。

### 模块对外接口
全部以 `router: APIRouter` 暴露，由 `create_app` 统一挂载；`thread_runs.RunCreateRequest` 被 `runs.py` 复用。

---

## 4.5 模块：渠道核心（`app/channels`：base / message_bus / manager / service / store / commands）

### 模块职责
以「总线解耦」模式连接 IM 平台与 Agent：渠道实现只认识 MessageBus，派发器只认识 Gateway API，二者互不感知。

#### `MessageBus`（`message_bus.py:117-173`）
- 入站：`asyncio.Queue`（`publish_inbound`/`get_inbound`）；出站：回调列表（`subscribe_outbound`/`unsubscribe_outbound`），`publish_outbound` 逐个 await 且**单回调异常不影响其他回调**（捕获+exc 记录，`message_bus.py:169-173`）。

#### `Channel`（ABC）（`base.py:14-130`）
- 契约：`start`/`stop`/`send`；默认实现：`send_file`（返回 False=不支持）、`receive_file`（原样返回，飞书等覆写以落盘附件）、`_on_outbound`（**先发文本，文本成功后才逐个传附件**——避免"只有文件没有说明"的半投递，`base.py:91-112`）。

#### `ChannelManager`（`manager.py:527-1001`）——本模块心脏
- **构造参数**：bus、store、max_concurrency(5)、langgraph_url/gateway_url（默认 `http://localhost:8001`）、assistant_id、default_session/channel_sessions（三层会话配置）。
- **`_dispatch_loop`（`manager.py:651-669`）**：`wait_for(bus.get_inbound(), 1.0)` 超时轮询（保证 stop 可中断）；每条消息 `create_task(_handle_message)` + done_callback 上浮异常。
- **`_handle_message`（`manager.py:680-701`）**：信号量限并发；COMMAND→`_handle_command`，CHAT→`_handle_chat`；`InvalidChannelSessionConfigError` 回错误消息，其余异常统一"内部错误"回复。
- **`_resolve_run_params`（`manager.py:578-607`）**：三层合并 `DEFAULT → default_session → channel → user`（config 与 context 分别 merge）；**assistant_id 兼容逻辑**：非 `lead_agent` 的值视为自定义 Agent 名，归一化后写入 `run_context["agent_name"]` 并把 assistant_id 改回 `lead_agent`（`manager.py:603-605`）——与 `services.build_run_config` 的逻辑互为镜像（`services.py:171-172` 注释点明此一致性要求）。
- **`_get_client`（`manager.py:611-624`）**：懒构造 langgraph-sdk 客户端，**鉴权三件套**：内部令牌头 + CSRF 头 + Cookie（自持 csrf token 既是 Cookie 又是 Header，满足双提交校验）——同进程回环调用的完整通关凭证。
- **`_handle_chat`（`manager.py:719-802`）**：store 查映射→无则 `client.threads.create()` 建线程并落映射→`_resolve_run_params`→渠道 `receive_file` 物化附件→`_ingest_inbound_files` 把消息级附件下载进线程 uploads 目录并把 `<uploaded_files>` 块前置到文本（告知模型用 read_file/view_image，`manager.py:500-524`）→按 `supports_streaming` 分流：
  - 非流式：`client.runs.wait(...)` → `_extract_response_text`（倒序找最后一条 human 之后的 AI 文本，兼容 ask_clarification 工具消息与 content-blocks 列表，`manager.py:149-201`）→ `_extract_artifacts`（只取本轮 `present_files` 工具调用路径，`manager.py:296-326`）→ 发布 Outbound。
  - 流式：见 `_handle_streaming_chat`。
- **`_handle_streaming_chat`（`manager.py:804-908`）**：
  - 订阅 `stream_mode=["messages-tuple","values"]`；`_accumulate_stream_text` 维护 `message_id→buffer` 快照集，`_merge_stream_text` **智能合并 delta 与累积两种语义**（chunk 以 existing 开头→替换为 chunk；existing 以 chunk 结尾→去重；否则拼接，`manager.py:230-240`）；
  - **节流**：距上次发布 <0.35s（`STREAM_UPDATE_MIN_INTERVAL_SECONDS`）则跳过本帧；
  - finally 统一收尾：从 last_values 提取最终文本与产物，错误分类（`_is_thread_busy_error`：ConflictError 或文案含 "already running a task"→专属忙碌提示），发布 `is_final=True` 的 Outbound。
- **`_resolve_attachments`（`manager.py:342-389`）**：产物→附件的安全闸：① 仅接受 `/mnt/user-data/outputs/` 前缀；② `resolve().relative_to(outputs_dir)` 二次校验防前缀伪造+遍历；③ 必须是已存在文件。防止 IM 渠道被用作任意文件外带通道。
- **`_handle_command`（`manager.py:912-967`）**：`/new`（建新线程+落映射）、`/status`、`/models`、`/memory`（httpx 直调 Gateway）、`/help`、`/bootstrap`（改写为 CHAT + `extra_context={"is_bootstrap": True}` 走正常聊天链）。

#### `ChannelService`（`service.py:55-231`）
- `from_app_config`：从 AppConfig 的 extra 字段取 `channels:` 段（`service.py:91-94`）；URL 解析优先级 config 键 > 环境变量 > 默认值（`_resolve_service_url`，注意它会 `config.pop` 掉 URL 键避免被当成渠道）。
- `start`：先启 manager，再逐渠道 `_start_channel`；`enabled:false` 但凭据齐全时打 warning 提示"配了凭据却没启用"（`service.py:106-114`）。
- `_start_channel`：`deerflow.reflection.resolve_class(import_path)` 按注册表懒加载类（`_CHANNEL_REGISTRY`，7 项，`service.py:20-28`）；启动后校验 `is_running`，未进入运行态则回滚剔除。
- 全局单例：`start_channel_service/stop_channel_service`（`service.py:215-230`），由 lifespan 调用；`routers/channels.py` 懒导入 `get_channel_service` 查询状态/重启。

#### `ChannelStore`（`store.py:16-153`）
- JSON 文件 + `threading.Lock`；**原子写**：NamedTemporaryFile → `Path.replace`（同目录 rename 原子性）；损坏文件告警后从空开始（`store.py:48-54`）。
- 键设计 `channel:chat[:topic]`：topic 存在=同一话题复用同一 DeerFlow 线程；topic 为 None=该 chat 单线程（私聊场景）。`remove` 不带 topic 时按前缀清全部话题映射。

---

## 4.6 模块：渠道实现（7 个平台适配器）

所有适配器共同骨架：`start()`（建平台连接，多为独立线程+独立事件循环）→ 平台回调 → 组装 `InboundMessage`（**topic_id 决定线程映射策略**）→ `run_coroutine_threadsafe(bus.publish_inbound, main_loop)` 切回主循环 → `_on_outbound` → `send()`（指数退避重试 3 次：1s/2s）。

| 适配器 | 连接方式 | 流式 | 线程映射（topic_id） | 特色实现 |
|--------|---------|------|---------------------|---------|
| `FeishuChannel`（`feishu.py:28`） | lark-oapi WebSocket（专用线程） | ✅（卡片原地 patch） | `root_id or msg_id`（话题回复共享线程） | ① 独立线程+新事件循环并**替换 SDK 模块级 loop 引用**，规避 uvloop 已运行导致的 `run_until_complete` 冲突（`feishu.py:139-174` 注释详述）；② 消息生命周期：OK 表情→"Working on it..."卡片→流式 patch→最终回复→DONE 表情（`feishu.py:37-43`）；③ `_running_card_ids/_running_card_tasks` 双字典管理卡片创建的异步竞态（创建中到达的更新会 await 同一 task，`feishu.py:463-502`）；④ `receive_file` 覆写：下载资源→净化文件名（`re.sub(r"[./\\]","_")`）→写 uploads→同步进非本地沙箱（`feishu.py:290-395`）；⑤ 富文本解析覆盖 text/file_key/image_key/post 结构（`feishu.py:605-651`） |
| `SlackChannel`（`slack.py:35`） | Socket Mode（executor 线程） | ❌ | `thread_ts or ts` | Markdown→mrkdwn 转换（`slack.py:16`）；eyes 表情确认 + ✓/× 表情标记成败（`slack.py:113-149`）；`already_reacted` 静默（幂等，`slack.py:185`）；用户白名单（`slack.py:19-32` 归一化容忍标量/列表） |
| `TelegramChannel`（`telegram.py:16`） | long-polling（专用线程+自建循环） | ❌ | 私聊 None（单线程）/群聊 reply-to 或 msg_id | 不能用 `run_polling()`（其 `add_signal_handler` 仅主线程可用）→ 手动 initialize/start/updater.start_polling + run_forever（`telegram.py:201-224` 注释）；`_last_bot_message` 维护回复链；photo≤10MB 走 send_photo、其余 send_document≤50MB |
| `DingTalkChannel`（`dingtalk.py:121`） | Stream Push WebSocket（专用线程） | ✅（AI 卡片，需 `card_template_id`） | 群聊 msg_id / P2P None | ① accessToken 双检锁缓存，提前 300s 刷新（`dingtalk.py:491-521`）；② `_adapt_markdown_for_dingtalk`：代码块→引用块、行内码→粗体、表格→「> **表头**: 值」列表、水平线→长横线（sampleMarkdown 渲染器受限，`dingtalk.py:75-118`）；③ 卡片流：`_card_track_ids`（源消息→outTrackId）+ `_card_repliers`；卡片流失败且 is_final 时降级 sampleMarkdown（`dingtalk.py:222-248`）；④ 消息路由 P2P/群聊 API 不同（oToMessages/batchSend vs groupMessages/send）；⑤ `_DingTalkMessageHandler.raw_process` 手工构造 AckMessage 应答流协议 |
| `DiscordChannel`（`discord.py:18`） | discord.py Gateway（专用线程） | ❌ | 自动 create_thread 的线程 id | 每条用户消息自动开帖（`deerflow-<昵称>-<msgId>` 截 100 字符，`discord.py:199-209`）；2000 字符限制分片（优先换行切，`discord.py:256-273`）；跨循环安全：所有 SDK 调用经 `run_coroutine_threadsafe`+`wrap_future`（`discord.py:110-111`） |
| `WechatChannel`（`wechat.py:129`） | iLink HTTP 长轮询（主循环任务） | ❌ | None（chat 单线程） | ① **游标持久化** `wechat-getupdates.json`（断线续拉）与 auth 状态 `wechat-auth.json`；② **二维码登录**：get_bot_qrcode → 轮询 status（confirmed 拿 bot_token），token 过期（errcode -14）自动停渠道（`wechat.py:655-714,563-570`）；③ **媒体加解密**：AES-128-ECB + PKCS7（`wechat.py:82-97`），上传三要素 rawsize/rawfilemd5/filesize（密文长度公式 `(n//16+1)*16`，`wechat.py:71-74`），aeskey 经 base64(hex) 双编码随消息下发（`wechat.py:111-112`）；④ 入站 key 解析多候选（hex/base64 多键名递归，`wechat.py:1151-1169`）；⑤ 文件类型白名单（扩展名+MIME 双列表，`wechat.py:157-216`）；⑥ 上下文 token 三级解析（metadata→thread→chat，`wechat.py:752-758`） |
| `WeComChannel`（`wecom.py:21`） | aibot WebSocket（主循环任务） | ✅（reply_stream） | user_id（每用户单线程） | ① `_ws_frames` 缓存入站帧供 reply 使用，`_ws_stream_ids` 管理流会话，final 后 `_clear_ws_context` 清理；② **分块上传协议**：512KB/块、md5 全量校验、init→chunk(base64)→finish 三段命令（最多 100 块≈50MB，`wecom.py:338-398`）；③ 覆写 `_on_outbound`：final 失败也清理上下文（`wecom.py:112-133`）；④ 混合消息（text+image+file）解析为文本+附件列表 |

---

## 4.7 模块：运维脚本（`scripts/migrate_user_isolation.py`）

- **`migrate_thread_dirs(paths, thread_owner_map, dry_run)`（`scripts/migrate_user_isolation.py:18-69`）**：遍历 legacy `threads/` 目录，按 DB 属主映射迁至 `users/<uid>/threads/<tid>`；**无属主→default 用户**（结尾统一 warning 列出）；**目标已存在→`migration-conflicts/`**（不覆盖）；迁移完的空 legacy 目录删除。
- **`migrate_memory`（`migrate_user_isolation.py:72-101`）**：`memory.json` → default 用户记忆文件；目标存在时把 legacy 改名 `memory.legacy.json` 保底。
- **`_build_owner_map_from_db`（`migrate_user_isolation.py:104-124`）**：**裸 sqlite3 同步驱动**查 `threads_meta`（刻意避免异步依赖，注释言明）；表不存在返回空映射。
- 幂等性：目标不存在才迁移、无 legacy 目录即 no-op，重复执行安全。

## 4.8 模块：调试入口（`debug.py`）

- 日志先行：`_setup_logging` 清空 root handlers 后仅挂 `debug.log` 文件Handler（幂等，`debug.py:37-60`）——防导入期告警经 lastResort 泄漏到交互终端。
- **延迟导入**：`deerflow.agents` 等 harness 导入放在日志配置之后，因其导入会启动后台技能加载线程产生日志（`debug.py:74-77` 注释）。
- 主循环：prompt_toolkit（可选，`uv sync --group dev` 启用方向键/历史）→ `agent.ainvoke({"messages":[HumanMessage(...)]}, config)` → 打印最后一条消息；config 演示了 `thinking_enabled/is_plan_mode/model_name` 等上下文键与 `__pregel_runtime` 注入（`debug.py:91-104`）。

---

# 第 6 章 关键函数深度解析（第 5 批交付）

选取覆盖核心业务链路的 6 个函数，给出带行号的代码片段与逐段解读。

## 6.1 `start_run` —— Run 创建全链路（`app/gateway/services.py:229-315`）

```python
229  async def start_run(
230      body: Any,
231      thread_id: str,
232      request: Request,
233  ) -> RunRecord:
246      bridge = get_stream_bridge(request)
247      run_mgr = get_run_manager(request)
248      run_ctx = get_run_context(request)
250      disconnect = DisconnectMode.cancel if body.on_disconnect == "cancel" else DisconnectMode.continue_
253      record = await run_mgr.create_or_reject(
254          thread_id,
255          body.assistant_id,
256          on_disconnect=disconnect,
257          metadata=body.metadata or {},
258          kwargs={"input": body.input, "config": body.config},
259          multitask_strategy=body.multitask_strategy,
260      )
261      except ConflictError as exc:
262          raise HTTPException(status_code=409, detail=str(exc)) from exc
263      except UnsupportedStrategyError as exc:
264          raise HTTPException(status_code=501, detail=str(exc)) from exc
270      existing = await run_ctx.thread_store.get(thread_id)
271      if existing is None:
272          await run_ctx.thread_store.create(...)
278      else:
279          await run_ctx.thread_store.update_status(thread_id, "running")
282      agent_factory = resolve_agent_factory(body.assistant_id)
283      graph_input = normalize_input(body.input)
284      config = build_run_config(thread_id, body.config, body.metadata, assistant_id=body.assistant_id)
290      merge_run_context_overrides(config, getattr(body, "context", None))
292      stream_modes = normalize_stream_modes(body.stream_mode)
294      task = asyncio.create_task(
295          run_agent(
296              bridge,
297              run_mgr,
298              record,
299              ctx=run_ctx,
300              agent_factory=agent_factory,
301              graph_input=graph_input,
302              config=config,
303              stream_modes=stream_modes,
304              stream_subgraphs=body.stream_subgraphs,
305              interrupt_before=body.interrupt_before,
306              interrupt_after=body.interrupt_after,
307          )
308      )
309      record.task = task
315      return record
```

**逐段解读**：
- **L246-248**：三个单例从 `app.state` 解包——bridge（事件通道）、run_mgr（生命周期）、run_ctx（基础设施聚合）。HTTP 层不持有全局变量，全部依赖注入。
- **L250**：`on_disconnect` 的字符串协议（"cancel"/"continue"）翻译为枚举，供 sse_consumer 的 finally 分支使用。
- **L253-264**：`create_or_reject` 是并发闸门——同线程已有活跃 Run 且策略为 reject 时抛 `ConflictError`（409）；未知策略 501。`kwargs` 把原始 input/config 快照进 RunRecord（run 列表接口可回显）。
- **L270-280**：线程元数据 upsert。注意 `except Exception: logger.warning`——**线程索引用户可见，但不构成 Run 失败条件**，属可用性优先的取舍。
- **L282-292**：四步参数就绪（工厂恒为 make_lead_agent、输入归一、config 组装、上下文白名单合并，详见 4.2）。
- **L294-309**：`asyncio.create_task` 立即返回——**创建即分离**：HTTP 请求不必等待 Agent 跑完；`record.task` 保存句柄供 cancel/wait 端点 `await record.task`。

## 6.2 `AuthMiddleware.dispatch` —— 认证总闸（`app/gateway/auth_middleware.py:75-126`）

```python
 75      async def dispatch(self, request: Request, call_next: Callable) -> Response:
 76          if _is_public(request.url.path):
 77              return await call_next(request)
 79          internal_user = None
 80          if is_valid_internal_auth_token(request.headers.get(INTERNAL_AUTH_HEADER_NAME)):
 81              internal_user = get_internal_user()
 84          if internal_user is None and not request.cookies.get("access_token"):
 85              return JSONResponse(status_code=401, content={
 86                  "detail": AuthErrorResponse(
 87                      code=AuthErrorCode.NOT_AUTHENTICATED,
 88                      message="Authentication required",
 89                  ).model_dump()
 90              })
106          from app.gateway.deps import get_current_user_from_request
108          if internal_user is not None:
109              user = internal_user
110          else:
111              try:
112                  user = await get_current_user_from_request(request)
113              except HTTPException as exc:
114                  return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})
120          request.state.user = user
121          request.state.auth = AuthContext(user=user, permissions=_ALL_PERMISSIONS)
122          token = set_current_user(user)
123          try:
124              return await call_next(request)
125          finally:
126              reset_current_user(token)
```

**逐段解读**：
- **L76-77**：公共路径（健康检查/文档/五个 auth 端点）直接放行——**白名单制**，新增端点默认受保护（fail-closed）。
- **L80-81**：内部令牌旁路——常量时间比较（`secrets.compare_digest`，`internal_auth.py:19-21`）校验进程启动时生成的 32 字节随机令牌；命中则用合成用户（id=DEFAULT_USER_ID, system_role="internal"）。**仅同进程有效**（令牌不落盘、不跨进程分发）。
- **L84-93**：Cookie 缺失快速拒绝（省一次 JWT 解码）。
- **L111-114**：严格校验链（见 4.3 的 `get_current_user_from_request`）。因为 `BaseHTTPMiddleware` 不让 HTTPException 冒泡，此处手工转 JSONResponse（`auth_middleware.py:103-105` 注释解释该坑）。
- **L120-121**：双重缓存——`request.state.auth` 已设置时 `@require_permission` 走短路分支，免二次解码+查库。
- **L122-126**：contextvar 的**设置-恢复**配对（`reset_current_user(token)`），保证并发请求间用户上下文不串扰——这是仓储层 `user_id=AUTO` 过滤能透明工作的前提。

## 6.3 `build_run_config` —— 兼容多版本 LangGraph 的配置组装（`app/gateway/services.py:153-221`）

```python
174      config: dict[str, Any] = {"recursion_limit": 100}
175      if request_config:
180          if "context" in request_config:
187              context_value = request_config["context"]
194              config["context"] = context
195          else:
196              configurable = {"thread_id": thread_id}
197              configurable.update(request_config.get("configurable", {}))
198              config["configurable"] = configurable
199          for k, v in request_config.items():
200              if k not in ("configurable", "context"):
201                  config[k] = v
203          config["configurable"] = {"thread_id": thread_id}
207      if assistant_id and assistant_id != _DEFAULT_ASSISTANT_ID:
208          normalized = assistant_id.strip().lower().replace("_", "-")
209          if not normalized or not re.fullmatch(r"[a-z0-9-]+", normalized):
210              raise ValueError(f"Invalid assistant_id {assistant_id!r}: ...")
211          if "configurable" in config:
212              target = config["configurable"]
213          elif "context" in config:
214              target = config["context"]
217          if target is not None and "agent_name" not in target:
218              target["agent_name"] = normalized
219      if metadata:
220          config.setdefault("metadata", {}).update(metadata)
221      return config
```

**逐段解读**：
- **L174**：递归上限 100——Agent 图（含子代理循环）的步数护栏。
- **L180-194**：LangGraph ≥0.6 的**双通道二选一**：请求带 `context` 就完全尊重（`configurable` 同现仅告警不合并，因新版会拒绝并存请求）；否则把 `thread_id` 强制注入 `configurable` 首位（随后 update 允许调用方覆盖，但 thread_id 实际由路由路径决定，正常调用方不会再传）。
- **L199-201**：`recursion_limit` 等顶层键透传。
- **L207-218**：自定义 Agent 的**注入点收敛**：归一化（小写/下划线转连字符）→ 白名单正则校验（防注入到文件路径 `agents/<name>/SOUL.md`）→ 写进「当前活跃容器」（configurable 或 context，跟随上面二选一的结果）且**不覆盖显式值**（`"agent_name" not in target`）。
- **安全视角**：`assistant_id` 最终会参与文件系统路径拼接（harness 的 agent_dir），这里的 fullmatch 是第一道路径注入防线（第二道在 `routers/agents.py:59-72` 的 `^[A-Za-z0-9-]+$`）。

## 6.4 `ChannelManager._handle_chat` —— IM 消息进 Agent 的主干（`app/channels/manager.py:719-802`）

```python
725      thread_id = self.store.get_thread_id(msg.channel_name, msg.chat_id, topic_id=msg.topic_id)
730      if thread_id is None:
731          thread_id = await self._create_thread(client, msg)
733      assistant_id, run_config, run_context = self._resolve_run_params(msg, thread_id)
745          msg = await channel.receive_file(msg, thread_id) if channel else msg
749      uploaded = await _ingest_inbound_files(thread_id, msg)
750      if uploaded:
751          msg.text = f"{_format_uploaded_files_block(uploaded)}\n\n{msg.text}".strip()
753      if self._channel_supports_streaming(msg.channel_name):
754          await self._handle_streaming_chat(...)
760          return
765      result = await client.runs.wait(
766          thread_id,
767          assistant_id,
768          input={"messages": [{"role": "human", "content": msg.text}]},
769          config=run_config,
770          context=run_context,
771      )
773      response_text = _extract_response_text(result)
774      artifacts = _extract_artifacts(result)
783      response_text, attachments = _prepare_artifact_delivery(thread_id, response_text, artifacts)
791      outbound = OutboundMessage(
792          channel_name=msg.channel_name,
...
802      await self.bus.publish_outbound(outbound)
```

**逐段解读**：
- **L725-731**：映射复用是渠道记忆的核心——`channel:chat:topic` 键命中即续聊；`_create_thread` 走 Gateway 的 `client.threads.create()` 并立即落库映射（掉电后话题不断链）。
- **L733**：三层会话配置合并（4.5 节），渠道/用户可各自覆盖 assistant、config、context。
- **L745**：渠道侧附件物化（目前仅飞书实现）：下载到线程 uploads 并把虚拟路径替换进文本占位符 `[image]`/`[file]`（`feishu.py:304-310`）。
- **L749-751**：消息级附件（wecom/wechat 的 files 元数据）由 manager 统一摄取：按渠道注册的 reader（`INBOUND_FILE_READERS`：wecom 带 AES 解密、wechat 读本地路径或 CDN，`manager.py:60-112`）拉字节流→净化文件名→写 uploads→生成 `<uploaded_files>` 块（含大小/类型/路径 + read_file/view_image 使用指引）前置到用户文本——**让多模态输入对模型可见**。
- **L753-760**：能力分流：支持流式的渠道走 `_handle_streaming_chat`（节流推送+卡片原地更新），否则阻塞等 `runs.wait`。
- **L773-783**：结果三件套——文本（倒序扫描，越过最后一条 human 即停，防止串轮）、产物（只认本轮 present_files）、`_prepare_artifact_delivery` 把未解析成功的产物路径以文字兜底附言（文件传不上平台时用户至少知道文件名）。
- **L802**：出站统一经总线（渠道不直接出现在函数中）——解耦的落点。

## 6.5 `SQLiteUserRepository.update_user` —— 并发删除的硬失败语义（`app/gateway/auth/repositories/sqlite.py:91-110`）

```python
91      async def update_user(self, user: User) -> User:
92          async with self._sf() as session:
93              row = await session.get(UserRow, str(user.id))
94              if row is None:
101                  raise UserNotFoundError(f"User {user.id} no longer exists")
102              row.email = user.email
103              row.password_hash = user.password_hash
104              row.system_role = user.system_role
105              row.oauth_provider = user.oauth_provider
106              row.oauth_id = user.oauth_id
107              row.needs_setup = user.needs_setup
108              row.token_version = user.token_version
109              await session.commit()
110          return user
```

**逐段解读**：
- **L93-101**：读-改-写模式下，取不到行说明**调用方刚取的用户已被并发删除**。选择抛 `UserNotFoundError`（LookupError 子类）而非静默成功——否则 reset_admin/change_password 会向操作者报告"重置成功"而实际上行已消失（`sqlite.py:96-100` 注释）。
- **L102-108**：全字段覆盖（非增量）——调用方（Provider 层）持有完整聚合对象，简化为一处转换 `_user_to_row` 的对称写法。
- **注意**：无乐观锁版本列；token_version 兼作"会话版本"而非行版本。

## 6.6 `_migrate_orphaned_threads` —— 升级路径数据迁移（`app/gateway/app.py:144-158`）

```python
144  async def _migrate_orphaned_threads(store, admin_user_id: str) -> int:
150      migrated = 0
151      async for item in _iter_store_items(store, ("threads",)):
152          metadata = item.value.get("metadata", {})
153          if not metadata.get("user_id"):
154              metadata["user_id"] = admin_user_id
155              item.value["metadata"] = metadata
156              await store.aput(("threads",), item.key, item.value)
157              migrated += 1
158      return migrated
```

**逐段解读**：
- **L151**：经 `_iter_store_items` 游标分页（500/页，见 4.1）——存量线程数不受单页上限约束。
- **L153**：判空而非判键——兼容 `user_id: null` 与键缺失两种历史形态；**已有属主的行不动**（幂等，重启重复执行无副作用）。
- **L156**：整值回写 `aput`（LangGraph store 无局部更新语义）。
- 该函数只在「管理员已存在」的启动分支运行（`app.py:100-121`），且被 try/except 包裹为非致命——**迁移失败不阻断服务**，下次重启重试。

---

# 第 7 章 端到端调用链分析

## 7.1 场景 A：前端流式对话（HTTP/SSE 主链路）

以「用户在已有线程发送一条消息，前端 useStream 消费事件流」为例，完整调用链：

```
浏览器
 │ POST /api/threads/t-123/runs/stream  (Cookie: access_token, csrf_token; Header: X-CSRF-Token)
 ▼
CSRFMiddleware.dispatch                csrf_middleware.py:70
 │ POST+非 auth 端点 → compare_digest(cookie, header) ──不一致──▶ 403
 ▼
AuthMiddleware.dispatch                auth_middleware.py:75
 │ get_current_user_from_request       deps.py:186
 │   ├─ decode_token                   auth/jwt.py:40  (HS256, ver 校验)
 │   ├─ provider.get_user(sub)         auth/local_provider.py:61 → sqlite.py:79
 │   └─ user.token_version == payload.ver ?
 │ set_current_user(user)  → contextvar（属主过滤生效）
 ▼
require_permission("runs","create",owner_check=True,require_existing=True)
 │                                      authz.py:197
 │ thread_store.check_access(t-123, uid, require_existing=True)
 │   不通过 ──▶ 404
 ▼
thread_runs.stream_run                 routers/thread_runs.py:105
 ▼
services.start_run                     services.py:229
 │ ├─ run_mgr.create_or_reject         （活跃 Run+reject ─▶ 409）
 │ ├─ thread_store.get/create/update_status   （元数据 upsert）
 │ ├─ resolve_agent_factory ─▶ make_lead_agent（harness）
 │ ├─ normalize_input / build_run_config / merge_run_context_overrides
 │ └─ asyncio.create_task(run_agent(bridge, run_mgr, record, ctx, ...))
 │     │
 │     │  (后台协程, harness run_agent)
 │     ├─ agent_factory(config) ─▶ LangGraph CompiledGraph
 │     ├─ graph.astream(...)  ─▶ 每步事件
 │     ├─ 事件/消息/token 写入 StreamBridge / RunEventStore / RunRepository
 │     └─ 完成后 run_mgr 标记 success/error + worker 侧标题回写 thread_store
 ▼
StreamingResponse(sse_consumer(bridge, record, request, run_mgr))   services.py:318
 │ bridge.subscribe(run_id, last_event_id)   （断线续传游标）
 │ ├─ HEARTBEAT_SENTINEL ─▶ ": heartbeat\n\n"
 │ ├─ 普通事件 ─▶ format_sse(event, data, id)
 │ └─ END_SENTINEL ─▶ format_sse("end") 并结束
 │ finally: pending/running 且 cancel 模式 ─▶ run_mgr.cancel(run_id)
 ▼
浏览器 useStream 逐帧渲染
```

**时序要点**：HTTP 响应在 `start_run` 返回后立刻开始流式输出（`thread_runs.py:114-128`），Agent 执行与 SSE 推送**并行**；取消（停止按钮）走 `POST .../runs/{rid}/stream?action=interrupt`（`thread_runs.py:236-265`）。

## 7.2 场景 B：飞书用户对话（IM 渠道全链路）

```
飞书用户发消息（话题内）
 ▼
[Feishu WS 线程] lark EventDispatcher → FeishuChannel._on_message   feishu.py:585
 │ 解析 content（text/file_key/image_key/富文本）→ text + files_list
 │ topic_id = root_id or msg_id
 ▼
run_coroutine_threadsafe(_prepare_inbound, main_loop)   feishu.py:691-694
 │ ├─ _add_reaction("OK")               feishu.py:414（后台任务）
 │ ├─ _ensure_running_card_started("Working on it...")  feishu.py:473
 │ └─ bus.publish_inbound(inbound)      message_bus.py:131
 ▼
[主循环] ChannelManager._dispatch_loop 收到消息          manager.py:651
 │ create_task(_handle_message)（信号量≤5）
 ▼
_handle_chat                              manager.py:719
 │ ├─ store.get_thread_id("feishu", chat, topic)     store.py:82
 │ │    未命中 ─▶ client.threads.create() + set_thread_id
 │ ├─ _resolve_run_params（三层合并 + agent_name 注入）
 │ ├─ channel.receive_file(msg, thread_id)           feishu.py:290
 │ │    下载 image_key/file_key → 写 uploads → 同步沙箱 → 文本占位替换
 │ ├─ _ingest_inbound_files（若有消息级附件）
 │ └─ supports_streaming=True ─▶ _handle_streaming_chat  manager.py:804
 │      ├─ client.runs.stream(..., stream_mode=["messages-tuple","values"])
 │      │    （langgraph-sdk → HTTP 回环 → 场景 A 同一条 Gateway 链路，
 │      │      凭内部令牌+自持 CSRF 通过 Auth/CSRF 中间件）
 │      ├─ 每≥0.35s 发布非 final OutboundMessage（流式草稿）
 │      └─ finally: 最终文本+产物附件 → final OutboundMessage
 ▼
bus.publish_outbound                       message_bus.py:160
 ▼
FeishuChannel._on_outbound                 base.py:91 → feishu.py 覆写链
 │ ├─ _send_card_message                   feishu.py:511
 │ │    非 final：patch 运行中卡片（原地更新）
 │ │    final：最终 patch + _add_reaction("DONE") + 清理卡片缓存
 │ └─ send_file × N                        feishu.py:225（≤10MB 图/≤30MB 文件）
 ▼
飞书话题内卡片实时刷新 → 完成态 + DONE 表情
```

**关键机制**：IM 全链路对 Gateway 的调用是 **HTTP 回环**（同进程 localhost:8001），不是函数直调——保证 IM 与 Web 走完全相同的 API 语义（`manager.py:578-607` 与 `services.build_run_config` 互为镜像的原因）。

## 7.3 场景 C：首启初始化（无认证 → 有认证）

```
Operator 部署后首次启动
 ▼
lifespan → _ensure_admin_user              app.py:52
 │ count_admin_users()==0 ─▶ 日志提示访问 /setup（不建号）
 ▼
浏览器 GET /api/v1/auth/setup-status       routers/auth.py:390 （公共路径, 60s/IP 冷却）
 │ 返回 {needs_setup: true}
 ▼
浏览器 POST /api/v1/auth/initialize        routers/auth.py:429
 │ count_admin_users()>0 ─▶ 409
 │ create_user(role=admin)（IntegrityError 竞态 ─▶ 409）
 │ 签发 JWT + 种 access_token Cookie
 │ CSRFMiddleware：auth 端点 POST 成功 ─▶ 种 csrf_token Cookie   csrf_middleware.py:92-102
 ▼
后续请求携双 Cookie 进入正常认证链
（老数据升级：下次重启 lifespan 检测到 admin 存在 → _migrate_orphaned_threads 划归存量线程）
```

---

# 第 8 章 横切机制说明

| 机制 | 实现位置 | 要点 |
|------|---------|------|
| **认证（Authentication）** | `auth_middleware.py`（全局）+ `deps.get_current_user_from_request`（严格链）+ `auth/jwt.py`（HS256+ver） | fail-closed 白名单制；Cookie `access_token`（HttpOnly、Secure 按 `x-forwarded-proto` 判定、SameSite=lax，HTTPS 下带 max_age，`routers/auth.py:134-145`）；token_version 改密即失效；内部令牌旁路供渠道回环 |
| **授权（Authorization）** | `authz.py`（六权限 + owner_check）+ `threads.py:_strip_reserved_metadata`（防 metadata 伪造属主）+ 仓储层 contextvar 过滤（`runs.py:99`）+ `langgraph_auth.add_owner_filter`（LangGraph Server 侧同语义） | 三层防线：中间件认证 → 装饰器属主校验（404 防存在性探测）→ 数据层自动过滤 |
| **CSRF** | `csrf_middleware.py`（Gateway 全部状态变更方法）+ `langgraph_auth._check_csrf`（LangGraph Server 侧镜像） | Double Submit Cookie；`secrets.compare_digest` 常数时间比较；豁免：GET/HEAD/OPTIONS/TRACE、`/api/v1/auth/me`、四个无会话 auth 端点 |
| **错误处理** | 路由层：统一 `HTTPException(detail=...)`；auth 域：`AuthErrorResponse{code,message}` 结构化错误（8 错误码，`auth/errors.py`）；Run 域：409/501 语义映射（`services.py:261-264`）；后台任务：done_callback 上浮异常（`manager.py:671-678`、`feishu.py:459-476`）；大量"非致命"降级点（thread_meta upsert、标题同步、rehash 等）带 `logger.warning` 继续 | 区分"可重试/可忽略"与"必须失败"两种错误哲学：安全数据完整性（用户行消失）硬失败；辅助索引/缓存类软失败 |
| **日志体系** | `app.py:38-42` basicConfig（INFO）→ lifespan 内 `apply_logging_level(config.log_level)` 按 config.yaml 覆盖；`debug.py` 重定向文件；`sanitize_log_param`（`utils.py:4`）防日志注入；凭据永不入日志（`credential_file.py`） | 命名 logger（每模块 `logging.getLogger(__name__)`）；渠道日志带 `[Feishu]`/`[Manager]`/`[Bus]` 前缀便于过滤 |
| **配置管理** | 三源：`.env`（密钥类）→ `config.yaml`（业务，harness AppConfig，extra=allow 容纳 channels 段）→ 环境变量（部署覆盖：GATEWAY_*/AUTH_*/DEER_FLOW_CHANNELS_*）；单例缓存（`get_gateway_config`/`get_auth_config`/`get_extensions_config`，后者支持 reload） | 无显式多环境 profile 机制——靠环境变量叠加实现（推断：配合 docker-compose 覆盖） |
| **并发/异步** | ① 后台 Run：`asyncio.create_task(run_agent)` + task 句柄（wait/cancel）；② 渠道并发：`Semaphore(5)` + 每消息独立 task；③ SDK 线程互操作：`run_coroutine_threadsafe`（飞书/Telegram/Discord/钉钉）与 `asyncio.to_thread`（bcrypt/lark SDK 调用）；④ 阻塞保护：登录限流 dict 无锁（GIL 下单 dict 操作原子，多键复合更新存在理论竞态但影响仅为计数偏差）；⑤ 停机限时：`asyncio.wait_for(5s)` | 多事件循环架构是本项目最复杂的异步特征（详见 10.3 坑点） |
| **限流** | 登录：进程内 IP 计数（5 次/300s 锁定，10000 条上限淘汰）；setup-status：60s/IP 冷却；Run 并发：`multitask_strategy`（reject/rollback/interrupt/enqueue） | 均为单进程实现，多 worker 需外置（代码注释自认） |
| **缓存** | 进程级：accessToken（钉钉，双检锁+提前 300s 刷新）、`get_local_provider` 单例、skills 系统提示词缓存（`refresh_skills_system_prompt_cache_async` 刷新）、artifacts 的 .skill ZIP 提取走 HTTP 私有缓存头（max-age=300） | 无外部 Redis 依赖 |
| **定时/轮询任务** | 无 cron 型定时任务；常驻轮询：Telegram `getUpdates` 长轮询、WeChat iLink `getupdates` 长轮询（游标持久化+服务端时长自适应 `longpolling_timeout_ms`，`wechat.py:765-782`）；ChannelManager 1s 心跳式派发循环 | 全部随 lifespan 启停 |
| **安全防护汇总** | 路径遍历：`resolve_thread_virtual_path`（403）+ 产物目录前缀+relative_to 双检（`manager.py:359-371`）；文件类型白名单（wechat 上下行）；上传限额三层+失败回滚；主动内容强制下载；密码黑名单（SecLists 子集）+min_length 8；日志注入清洗；凭据 0600 文件；CORS 通配符防御；`X-Real-IP` 仅信受信代理 | 纵深防御明显，多数点配有针对性注释 |

---

# 第 9 章 外部依赖说明

| 依赖名 | 用途 | 在哪些文件中使用 | 替代/备注 |
|--------|------|----------------|----------|
| fastapi | Web 框架（路由/依赖注入/中间件/文件上传） | gateway 全部 | — |
| uvicorn[standard] | ASGI 服务器 | 入口（Makefile/Dockerfile） | 开发 --reload；生产建议多 worker（注意限流为单进程） |
| pydantic | 配置与请求/响应模型（含 EmailStr） | 全部 routers、config、auth | EmailStr 依赖 email-validator |
| httpx | 异步 HTTP 客户端 | channels（manager/wechat/dingtalk 命令查询） | — |
| sse-starlette | SSE 支持（声明于 pyproject） | **纳入范围内未见直接 import**（Gateway 用 fastapi StreamingResponse 手写 SSE 帧）；推断由 harness 或历史遗留使用 | 见存疑清单 |
| python-multipart | multipart 表单解析（OAuth2 表单/文件上传） | routers/auth.py（OAuth2PasswordRequestForm）、uploads.py | — |
| langgraph-sdk | ① LangGraph Server 认证 Handler（`Auth` 对象）② 渠道侧 SDK 客户端（runs.wait/stream、threads.create） | langgraph_auth.py、channels/manager.py | 回环调用本进程 Gateway |
| langchain-core | 消息类型（HumanMessage/SystemMessage） | services.py、routers/suggestions.py、debug.py | — |
| pyjwt | JWT 签发/校验（HS256） | auth/jwt.py、langgraph_auth.py | — |
| bcrypt | 密码哈希（v2=SHA-256 预哈希+bcrypt） | auth/password.py | — |
| sqlalchemy（经 harness 传递） | 异步 ORM（UserRow 等五表） | auth/repositories/sqlite.py、app.py、reset_admin.py | — |
| lark-oapi | 飞书 WS 事件 + IM API | channels/feishu.py | 需规避 uvloop 冲突（专用线程） |
| slack-sdk | Slack Socket Mode + Web API | channels/slack.py | — |
| python-telegram-bot | Telegram Bot（手动 polling） | channels/telegram.py | 不能用 run_polling（信号处理器限制） |
| dingtalk-stream | 钉钉 Stream Push + AI 卡片 | channels/dingtalk.py | httpx 手调其余 REST |
| wecom-aibot-python-sdk | 企业微信 aibot WS | channels/wecom.py | 需 ==0.1.6+（`wecom.py:49` 版本检查） |
| markdown-to-mrkdwn | Markdown→Slack mrkdwn | channels/slack.py | — |
| cryptography（经 harness 传递） | AES-128-ECB 媒体加解密 | channels/wechat.py | — |
| discord.py（**未在 pyproject 声明**） | Discord Gateway | channels/discord.py（try/except 守护） | 见存疑清单 Q1 |
| PyYAML（经 harness 传递） | agent config.yaml 读写 | routers/agents.py | — |
| **内部依赖：deerflow-harness**（workspace） | Agent 图、runtime、持久化、沙箱、技能、上传、路径、配置 | gateway/channels 的几乎每个文件（`deerflow.*` 前缀） | 排除范围；升级它即升级整个领域层 |

---

# 第 10 章 新人上手路径

## 10.1 建议的文件阅读顺序（由浅入深）

1. **项目定位**：`pyproject.toml` → `Makefile` → `langgraph.json`（三种运行形态）
2. **应用骨架**：`app/gateway/app.py`（只看 `create_app` 的装配清单）→ `app/gateway/config.py`
3. **依赖注入**：`app/gateway/deps.py`（理解 `app.state` 上有哪些单例、路由怎么拿）
4. **一条主链路**：`routers/thread_runs.py` → `services.py`（start_run/sse_consumer）——**这是全项目最重要的 300 行**
5. **认证授权**：`auth_middleware.py` → `authz.py` → `auth/jwt.py` → `auth/password.py` → `routers/auth.py`
6. **资产与线程**：`routers/threads.py`（线程状态机）→ `uploads.py` → `artifacts.py` → `path_utils.py`
7. **渠道子系统**：`channels/message_bus.py` → `channels/base.py` → `channels/manager.py`（重点 `_handle_chat`/`_handle_streaming_chat`）→ `channels/service.py` → 挑一个 `feishu.py` 精读，其余平台扫读差异
8. **运维面**：`scripts/migrate_user_isolation.py`、`auth/reset_admin.py`、`debug.py`

## 10.2 常见修改需求的切入点

| 需求 | 入手位置 | 步骤 |
|------|---------|------|
| **改一个已有 API 的行为** | `app/gateway/routers/<模块>.py` | 路由都是薄层；若涉及 Run 生命周期改 `services.py`；涉及权限改装饰器参数（owner_check/require_existing） |
| **新增一个 API** | 新建 `routers/foo.py`（`APIRouter(prefix="/api/foo")`）→ `app.py` import + `include_router` | 依赖统一走 `deps.get_*`；需要属主校验就挂 `@require_permission(..., owner_check=True)` |
| **接入一个新的 IM 平台** | 新建 `app/channels/<platform>.py` 继承 `Channel` | 实现 start/stop/send（可选 send_file/receive_file）；在 `service.py:_CHANNEL_REGISTRY` 注册；在 `service.py:_CHANNEL_CREDENTIAL_KEYS` 补凭据键；需要流式则覆写 `supports_streaming=True` 并在 `manager.py:CHANNEL_CAPABILITIES` 登记 |
| **给 Agent 增加一个请求级开关** | `services.py:_CONTEXT_CONFIGURABLE_KEYS` 白名单加键 | 前端经 `body.context` 传入；harness 侧图/工具读该键（跨包协作） |
| **加一个渠道命令** | `commands.py:KNOWN_CHANNEL_COMMANDS` 加名 → `manager.py:_handle_command` 加分支 | 解析器（feishu/dingtalk 的 `_is_*_command`）自动同步 |
| **修改上传/产物策略** | `routers/uploads.py`（限额/转换）、`artifacts.py`（MIME 行为） | 限额默认值常量在 `uploads.py:36-38` |
| **新增用户表字段** | `auth/models.py:User` → `repositories/sqlite.py` 两个转换器 → 表结构在 harness `persistence/user/model.py`（跨包） | 注意 `update_user` 的全字段覆盖要同步补 |
| **修改启动/停机行为** | `app/gateway/app.py:lifespan` | 注意顺序依赖（config→runtime→admin→channels）与 5s 停机上限 |

## 10.3 隐性约定与易踩坑点

1. **`packages/harness` 与 `app/` 是一个 uv workspace**——改 `deerflow.*` 行为要进 harness 包；本仓库根的 pyproject 通过 `[tool.uv.sources]` 以 workspace 成员方式引用（`pyproject.toml:45-49`）。跑任何代码都要 `PYTHONPATH=.`（Makefile 全部任务都带）。
2. **中间件顺序是"后加者在外"**——新增中间件时想清楚它该在 Auth 内还是外；例如新加的日志/限流中间件若加在 Auth 之前（更内层），将拿不到 `request.state.user`。
3. **contextvar 用户上下文是属主隔离的隐形支柱**——任何绕过 AuthMiddleware 的调用路径（自定义脚本、测试直调）都不会有 user_context；仓储层 `user_id=AUTO` 过滤会拿到默认值。测试里有 `no_auto_user` pytest 标记（`pyproject.toml:38-40`）处理此类场景。
4. **owner_check 的 404 语义**：属主不符返回 404 不是 403——有意防止资源枚举；新端点对私有资源要沿用该约定。
5. **`require_existing` 只该用于破坏性端点**：读端点误用会把"legacy 无 meta 线程"全部 404。
6. **渠道线程是多事件循环协作**：平台 SDK 回调运行在专用线程的独立 loop，一切对 bus/主循环对象的操作必须 `run_coroutine_threadsafe`；在回调里直接 `await` 是常见错误。飞书还替换了 SDK 的模块级 loop（`feishu.py:161`），升级 lark-oapi 时要回归这一点。
7. **`assistant_id` 与 `agent_name` 的双轨约定**：所有自定义 Agent 的 assistant_id 在网关/渠道两处都会被改写为 `lead_agent` + `agent_name` 上下文（`services.py:205-218`、`manager.py:603-605`）；改任一侧都要同步另一侧，否则自定义 Agent 会静默退化为默认主 Agent（`services.py:167-169` 注释明确警告过）。
8. **SSE 帧格式不可随意改**：`event/data/id` 顺序与 `Content-Location` 头被 `useStream`/Python SDK 的解析器硬依赖（`thread_runs.py:122-126`）。
9. **进程内限流与内存态**：登录限流、`_last_bot_message`、`_running_card_ids` 等均为单进程状态——多 worker/多副本部署（k8s 多 Pod）下行为会变化。
10. **非致命降级点多**：thread_meta upsert、标题同步、rehash、附件上传失败等只告警不失败——排查"列表里没有/文件没收到"类问题先查 warning 日志而非异常栈。
11. **`auth/repositories/sqlite.py` 名字有历史包袱**：它实际是"共享 SQLAlchemy 引擎仓库"，SQLite/Postgres 都走它（`auth/config.py:15-19` 注释说明 users_db_path 已删除）。
12. **Dockerfile 假设构建上下文含 `backend/` 目录**（`Dockerfile:46` 的 `COPY backend ./backend`）——本仓库即该 backend 目录本身，构建时需在上层上下文执行（推断：完整项目含前端与 nginx 编排）。

---

# 收尾：全报告总目录 · 完成度自检 · 存疑清单（第 5 批交付）

## A. 全报告总目录（章节 ↔ 批次索引）

| 章节 | 内容 | 所在批次 |
|------|------|---------|
| 0 / 0.1 | 批次计划表 / 术语表 | 第 1 批 |
| 1 | 项目概述（用途/技术栈/运行方式） | 第 1 批 |
| 2 | 整体架构（分层图/模块依赖/核心数据流） | 第 1 批 |
| 3 | 目录结构详解 | 第 1 批 |
| 4.1 | 网关装配层（app.py/deps.py 等） | 第 2 批 |
| 4.2 | Run 生命周期服务（services.py） | 第 2 批 |
| 4.3 | 认证与授权（auth + authz + 中间件） | 第 3 批 |
| 4.4 | 路由层（16 文件端点解析） | 第 3 批 |
| 4.5 | 渠道核心（bus/manager/service/store） | 第 4 批 |
| 4.6 | 渠道实现（7 平台适配器对照） | 第 4 批 |
| 4.7 / 4.8 | 迁移脚本 / 调试入口 | 第 4 批 |
| 5 | 文件清单总表（60 文件全覆盖） | 第 1 批 |
| 6 | 关键函数深度解析（6 个函数带行号） | 第 5 批 |
| 7 | 端到端调用链（3 场景时序） | 第 5 批 |
| 8 | 横切机制说明 | 第 5 批 |
| 9 | 外部依赖说明 | 第 5 批 |
| 10 | 新人上手路径 | 第 5 批 |

## B. 完成度自检表

| 检查项 | 结果 |
|--------|------|
| 根目录生产/配置文件（pyproject.toml、langgraph.json、Makefile、Dockerfile、debug.py） | ✅ 5/5 已覆盖（第 5.1 节） |
| `app/channels/` 14 文件 | ✅ 14/14（第 5.2 节 + 4.5/4.6） |
| `app/gateway/` 核心 12 文件 | ✅ 12/12（第 5.3 节 + 4.1/4.2） |
| `app/gateway/auth/` + repositories 13 文件 | ✅ 13/13（第 5.4 节 + 4.3） |
| `app/gateway/routers/` 16 文件 | ✅ 16/16（第 5.5 节 + 4.4） |
| `scripts/migrate_user_isolation.py` | ✅（第 5.6 节 + 4.7） |
| 空包标记（`app/__init__.py`、repositories/`__init__.py`） | ✅ 已列入并标注 |
| 排除范围（tests/、docs/、.vscode/、packages/harness/、ruff.toml、uv.lock、根 Markdown 文档） | ✅ 未分析，仅作背景参考 |
| 计划变更 | 无（未发现计划外模块） |

## C. 存疑与待确认清单

| # | 疑点 | 位置 | 说明 |
|---|------|------|------|
| Q1 | `discord.py` 未在 `pyproject.toml` 声明 | `app/channels/discord.py:47`（try/except 守护导入）；`pyproject.toml:7-24` 无此依赖 | **推断**：Discord 为可选渠道，需使用者自行安装；守护式导入使其缺失时仅禁用该渠道。建议与维护方确认是否遗漏声明 |
| Q2 | `sse-starlette` 在纳入范围代码中无直接使用 | `pyproject.toml:11` 声明；Gateway 的 SSE 用 `fastapi.responses.StreamingResponse` 手写（`services.py:318`） | **推断**：供 `packages/harness`（排除范围）使用，或为历史遗留依赖 |
| Q3 | `routers/__init__.py` 仅聚合 9 个模块，`agents/auth/channels/feedback/runs` 未列入 | `routers/__init__.py:1-3` vs `app.py:14-30` | 非 bug：`from package import submodule` 语义可自动解析；**推断**为渐进迁移未同步的聚合清单 |
| Q4 | 登录限流字典的复合更新无锁 | `routers/auth.py:258-264`（读-改-写 `_login_attempts[ip]`） | GIL 下单条 dict 赋值原子，但"读计数→计算→写回"非原子；并发下计数可能少记。代码注释已自认多 worker 局限，单进程竞态属已知取舍（推断为有意简化） |
| Q5 | Dockerfile `COPY backend ./backend` 暗示构建上下文在仓库上一层 | `Dockerfile:46` | **推断**：完整产品仓库含 frontend/nginx 编排，本目录对应其中的 `backend/` |
| Q6 | `normalize_input` 将非 user 角色也转为 HumanMessage | `services.py:88-91`（代码内 TODO） | 已确认是待完成项而非设计；报告仅如实记录 |
| Q7 | WeCom `send_file` 对非 final 消息直接返回 True | `app/channels/wecom.py:136-137` | **推断**：流式阶段只更新文本卡片，文件仅在最终消息后上传；返回 True 是为了抑制 base 类的"skipped"告警噪音 |
| Q8 | `channels/wechat.py` 的 `cryptography` 依赖来源 | `wechat.py:21-22` 直接 import，pyproject 未声明 | **推断**：经 `deerflow-harness` 的依赖树传递安装；若独立安装 app 包需补声明 |

---

*报告完。全部结论基于对纳入范围源码的实际阅读；`packages/harness` 属排除范围，凡涉及其内部实现的表述均以"推断"或仅描述调用边界的方式给出。*
