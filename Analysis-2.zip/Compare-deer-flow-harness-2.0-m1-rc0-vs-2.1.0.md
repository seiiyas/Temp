# DeerFlow Harness 版本对比报告：2.0-m1-rc0 → 2.1.0

对比对象：
- 旧版：`deer-flow-backend-2.0-m1-rc0/packages/harness/deerflow/`
- 新版：`deer-flow-backend-2.1.0/packages/harness/deerflow/`

---

## 1. 总览

| 指标 | 2.0-m1-rc0 | 2.1.0 | 变化 |
|---|---|---|---|
| harness 包版本（pyproject） | 0.1.0 | 2.1.0 | — |
| 文件总数 | 197 | 605 | +413 新增 / -5 删除 / 156 修改 / 36 未变 |
| Python 代码行数 | ~23,900 | ~118,500 | **约 5 倍** |
| 顶层子包数 | 17 | 25 | 新增 authz、extensions、integrations、projects、scheduler、tui、workspace_changes（另根目录新增 AGENTS.md、constants.py、logging_config.py、trace_context.py、checkpoint_patches.py） |
| middlewares 文件数 | 17 | 50 | 新增 33 个中间件 |
| 数据库迁移 | 无（versions 目录为空） | 0001–0025 共 26 个迁移 | 建立完整 Alembic 迁移链 |
| pyproject 可选依赖 extras | 3（ollama/postgres/pymupdf） | 14（+tui/redis/browser/monocle/boxlite/tenki/opensandbox/groundroute/memory-zh…） | — |
| 控制台命令 | 无 | `deerflow`（TUI 入口） | — |

**一句话总结**：2.1.0 是一次从"单进程演示级 Agent 后端"到"多租户、多实例、可插拔、安全纵深的企业化 Agent 平台"的重写级升级。核心方向有八条：**多用户/多实例化、授权与安全纵深、可插拔生态（扩展/记忆后端/沙箱后端）、子代理工程化与可验证委派、上下文经济（延迟加载/预算/压缩）、持久化与调度体系、终端与项目等新产品面、以及全面的鲁棒性治理**。

---

## 2. 架构级变化

### 2.1 部署架构：独立 LangGraph Server → Gateway 内嵌运行时
- 旧版：`make dev` 起独立 LangGraph Server（端口 2024）+ Gateway API（8001）两个进程，Nginx 分别转发。
- 新版：agent 运行时**内嵌进 FastAPI Gateway**（`runtime/runs/` 的 RunManager/Worker/StreamBridge），`langgraph.json` 仅保留给 LangGraph 工具链/Studio 兼容，不再是服务入口。部署从两进程简化为单服务。
- README/架构图同步更新，`make dev` 只起 Gateway（带安全 reload 边界）。

### 2.2 打包与依赖
- 版本号从 0.1.0 跳到 2.1.0，与后端发行版本对齐。
- 新增核心依赖：`deerflow-extension-api==0.2.1`（扩展契约包，精确锁版）、`croniter`（调度）、`e2b-code-interpreter`（E2B 沙箱）、`cryptography`、`tzdata`、`beautifulsoup4/html5lib`、`langchain-openviking`。
- langgraph 收紧为 `>=1.2.9,<1.3`，并带 `checkpoint_patches.py` 对 langgraph 1.2.9 的 delta 通道历史问题打补丁。
- 新增 `[project.scripts] deerflow = "deerflow.tui.cli:main"` 与 14 个 extras（tui/redis/browser/playwright/monocle 观测/各云沙箱等），核心安装保持精简、按需启用。

### 2.3 数据层
- 旧版仅 runs/threads_meta/feedback/users/run_events/channel_* 几张表且无迁移管理；新版建立 **0001–0025 Alembic 迁移链**，Gateway 启动时 `bootstrap_schema()` 自动升级（Postgres advisory lock 跨进程串行化 + SQLite 进程内锁，幂等），新增约 13 张表：scheduled_tasks(+runs)、agents、managed_subagents、mcp_tasks、personal_access_tokens、projects、project_documents、subagent_batches(+items)、webhook_deliveries、user_preferences、run_change_clock 等。
- runs 表大幅扩展：token_usage_by_model、owner_worker_id/lease_expires_at（多 worker 所有权）、stop_reason、operation_kind、cancel_action/cancel_requested_at（跨 worker 取消）、idempotency_key、change_seq（增量同步游标）。
- `runtime/store`/`stream_bridge`/`events` 全部接口增加 `user_id` 三态过滤（多租户隔离贯穿持久层）。

---

## 3. 目录结构变化

### 3.1 新增顶层模块（8 个）

| 模块 | 行数 | 功能定位 |
|---|---|---|
| `extensions/` | 3,599 | Python 插件系统宿主侧：config.yaml `plugins:` 驱动加载 → 六类贡献点注册（中间件/生命周期/观察者/服务/路由/task store）→ 语义锚点注入中间件栈（失败隔离）→ Gateway 挂载；`ExtensionManager` 提供 uv 安装/升级/回滚/跨进程锁的运维 CLI |
| `authz/` | 851 | 细粒度授权：可插拔 `AuthorizationProvider`（内置 RBAC）双层执行——Layer 1 装配期工具/模型过滤 + Layer 2 运行期拦截（复用 GuardrailMiddleware）；覆盖 tool/model/skill/sandbox/mcp_server/route 六类资源 |
| `tui/` | 1,918 | Textual 终端工作台 + 无头 CLI（`deerflow --print/--json`）；纯 reducer/纯渲染/worker 流式三段分离；会话写入共享 threads_meta，在 Web UI 侧栏可见 |
| `projects/` | 1,220 | 项目系统运行时：run 开始时把线程项目"钉住"为不可变快照渲染 `<project>`/`<documents>` 请求级上下文；两个只读书架工具；内容寻址文档存储 + 回收站（恢复/清除/保留清扫） |
| `workspace_changes/` | 922 | run 前后对 workspace/outputs 做快照对比，生成带 unified diff、脱敏的变更清单写入事件存储，支撑交付验证与 API 查询 |
| `scheduler/` | 59 | once/cron/interval 三类调度的下次执行时间纯函数计算（时区墙钟→UTC 统一） |
| `integrations/` | 2,824 | Lark/飞书托管集成：28 个官方 lark-* 技能安装、OAuth 应用注册与用户授权、凭据安全加固（Windows 走 NT API handle-relative 加固）、沙箱内 loopback broker 代理凭据（明文永不落沙箱） |
| `agents/task_continuity/` | — | 上下文压缩后记忆连续性：被压缩的原始消息存入线程本地 SQLite FTS5 归档，配 history_search/history_read/task_note 三工具 |

### 3.2 既有模块内的新增子系统

- **`agents/memory/backends/`**：记忆系统插件化（见 §4.2）。
- **`mcp/tasks/`**：协议中立的 MCP 长时后台任务运行时（submit/status/cancel 契约、六态任务状态机、驱动注册表、配置冻结校验），任务在发起 run 结束后仍由 Gateway 轮询跟踪。
- **`runtime/checkpoint_cache/` + `checkpointer/cached_saver.py`**：checkpoint 增量历史缓存（memory/Redis），条目不可变、无需失效的正确性设计，消除长会话恢复的逐祖先 SQL 爬取。
- **`skills/review/` + `skills/skillscan/`**：确定性技能包审查（资源图/eval 清单/发布就绪报告/CI 门禁 CLI）与原生静态安全扫描（38 条规则，含 Python AST 数据流分析，CRITICAL 阻断）。
- **`agents/middlewares/` 新增 33 个中间件**（见 §4.4）。
- **`subagents/` 新增 12 个文件**：验收清单、报告契约、状态契约、持久批次（runtime/service/acceptance）、执行容量、父上下文快照、步骤事件、token 收集器、turn 预算换算。
- **`persistence/` 新增 10 个实体存储**（agents、channel_connections、managed_subagents、mcp_tasks、personal_access_tokens、projects、scheduled_tasks(+runs)、subagent_batches、webhook_delivery、user/preferences）。
- **`community/` 新增 16 个 provider**（见 §5.3）。

### 3.3 删除的文件

仅 5 个：`agents/memory/{message_processing,prompt,queue,storage,updater}.py` —— 旧单体记忆实现整体迁入 `backends/deermem/deermem/core/` 并重写（体积膨胀 3–10 倍，updater.py 23.7KB→123KB）。这是唯一的"删除"，属于重构而非功能移除。

---

## 4. 功能点新增（按主题）

### 4.1 多租户与身份
- `user_id` 贯穿全部子系统：per-user 技能目录与启用状态、per-user 记忆作用域、per-user MCP stdio 会话池、per-user 沙箱身份（`local:{user}:{thread}`）、上传目录隔离、事件/运行存储三态 user 过滤。
- `runtime/user_context.py` 新增 LangGraph 认证身份解析链（Agent Server 认证 → langgraph_auth_user → gateway 注入 context → ContextVar → 默认用户）。
- 认证面：OIDC/SSO 配置（`auth_config.py`）、个人访问令牌 PAT（`dfp_` SHA-256 摘要、scopes、撤销）、用户偏好表。

### 4.2 记忆系统重构（变化最大的子系统）
- **旧**：单体五文件、模块级单例、单 JSON 文档存储、记忆/日期拼进 system prompt。
- **新**：`MemoryManager` 三层契约（Tier1 抽象 add/get_context、Tier2 管理操作、Tier3 可选钩子）+ drop-in 后端注册表，`memory.manager_class` 一行切换后端：
  - **deermem**（默认）：LLM 事实提炼管线全面强化——会话水印防重喂/漏提、6 类信号检测（YAML 正则外置）、scope 门控（仅 user/durable/descriptive 事实入库，拒绝率>60% 告警）、陈旧度审查（90 天默认）、事实合并（consolidation，默认关）、hybrid 淘汰策略（置信度+新鲜度+访问热度，correction 保底槽）、SQLite FTS5 BM25 检索（jieba 分词，失败回退子串匹配）；存储改为"摘要 JSON + 每事实独立 Markdown 分片 + 边车元数据"，跨进程文件锁 + 乐观并发 + 原子写。
  - **mem0 / honcho / openviking / noop**：外部记忆平台适配（honcho 零本地 LLM 调用；noop 兼开发模板）。
- **双注入模式**：`memory.mode: middleware`（被动抽取）或 `tool`（模型主动调 memory_search/add/update/delete 四工具）。
- 记忆注入从 system prompt 移到 DynamicContextMiddleware 的请求级 `<system-reminder>`（保前缀缓存），读失败按后端 fail_open/fail_closed 策略。
- run 级记忆身份：`context:memory` 事件只存 SHA-256 指纹不复制内容。

### 4.3 授权与安全纵深（全新维度）
- **authz 双层授权**：装配期能力过滤（无权工具模型根本看不到，tool_search 提升不回来）+ 运行期拦截（GuardrailAuthorizationAdapter 复用 GuardrailMiddleware）；fail_closed/fail_open 显式配置。
- **提示注入防御**：InputSanitizationMiddleware（用户输入 XML 类标签转义、"去标识而非拒绝"）+ ToolResultSanitizationMiddleware（web/MCP 工具结果中和防伪造 `<system-reminder>`）+ SOUL/技能/子代理描述系统性 html.escape。
- **技能安全**：SkillScan 原生静态扫描（安装与 agent 写入前置，CRITICAL 阻断）+ skills/review 确定性审查工具 + 沙箱技能树只读挂载（0555/0444）+ 技能投影白名单。
- **沙箱安全**：继承环境密钥擦洗（`*KEY*/*SECRET*/*TOKEN*/*PASS*`）、请求级 secret 仅经 `bash.exec` env 注入不落命令串、输出脱敏、受限网络模式（internal+egress 双网络 + SSRF 校验的网络代理容器 + 交互式域名审批）、RBAC 沙箱执行门禁。
- **凭据卫生**：凭据永不进装配描述符/日志（logging_config 脱敏 httpx 日志）；Lark 凭据目录 Windows NT-API 级加固。
- **`__` 前缀 context key 约定**：防 Gateway 入口伪造服务器拥有的运行时键（授权结果、扩展快照、项目上下文等）。

### 4.4 中间件体系扩展（17→50 文件）
新中间件按主题归组：
- **上下文经济**：DynamicContext（记忆/日期 system-reminder，静态 prompt 保前缀缓存）、DurableContext（委派台账/已载技能/摘要投影进 checkpoint 通道）、SystemMessageCoalescing（兼容严格后端）、TokenBudget（run 级 token 预算，软警告/硬剥离 tool_calls）、ToolOutputBudget（超大工具输出落盘 `.tool-results/` + 确定性 synopsis；被取代的历史 write_file 内容占位符化）、ToolProgress（按 (thread,tool) 状态机检测停滞）、TerminalResponse（保证工具回合有可见收尾）。
- **工具治理**：ToolReceipt（每个工具结果盖 r1..rN 确定性回执）+ ReceiptVerification（父侧交叉核验子代理报告引用）、ReadBeforeWrite（写前必须读过当前版本，sha256 印记）、McpRouting + ToolPromotionAudit（延迟 MCP 工具按关键词/优先级自动提升并审计）、ToolCallArgs/Metadata（四表面一致重写工具参数）。
- **安全终止**：SafetyFinishReason（content_filter/refusal 时剥离半截 tool_calls 防截断参数被执行，可配置检测器）、ModelLengthFinishReason（length 截断打 stop_reason）。
- **技能**：SkillActivation（/skill 显式激活 + secret 绑定）、SkillToolPolicy（激活技能的 allowed-tools 运行时白名单）。
- **其他**：AuditContext、ConfiguredExtensions（config 声明式外部中间件）、DelegationLedger、SkillContext、BoundedDict 等。
既有中间件全部大幅增强（详见 §5.1）。

### 4.5 子代理工程化与"可验证委派"
- **验证三层栈**（RFC #4651）：① 工具回执（零 LLM，确定性）→ ② 验收清单（`file:<path> exists/non-empty`、`file_written`、`tests_passed:<cmd>` 确定性检查，不可判定返回 UNVERIFIED）→ ③ 报告契约（子代理 system prompt 要求引用 [rN] 回执与可验证 handle，父侧核验）。
- **持久批次**：`batch_task` 工具提交大量独立子代理条目（幂等 submission_key、租约认领、崩溃恢复、并发/尝试上限）。
- **执行容量**：进程级 FIFO 准入（max_running/max_queued，queue|reject）。
- **委派策略重写**：提示词从"积极并行分解"改为"默认直接执行、净收益明显才委派"的成本/收益框架；并发+总量双上限；context_mode isolated/snapshot。
- 子代理获得与 lead 完全镜像的中间件能力（loop/token budget/summarization/安全终止等），token 用量归并进父 RunJournal，stop_reason（token_capped/turn_capped/loop_capped）结构化带回。
- **托管子代理**第三层来源（管理员经 Settings UI 持久化，file/db 双存储）。

### 4.6 目标循环与任务连续性
- **goal 系统**（Claude Code 式）：`/goal` 设定目标 → LLM 评估完成度 → 未满足则以隐藏 continuation turn 自动续跑（上限 8 次续跑/2 次无进展熔断），支持 human_input 卡暂停。
- **task_continuity**：压缩前把原始消息归档线程本地 FTS5，配 history_search/history_read/task_note 工具，跨压缩保持任务记忆。

### 4.7 定时任务与后台任务
- scheduled_tasks：once/cron/interval、时区、overlap 策略（skip/enqueue）、多实例租约、occurrence_seq 幂等记账（配合 app/scheduler 服务与 Gateway 路由）。
- MCP 后台长任务：`task_toolsets` 把 MCP 服务器的 submit/status/cancel 声明为任务型，提交立即返回 DeerFlow task id，Gateway 轮询驱动、事件指纹去重、通知 outbox、取消重试；配 `list_background_tasks`/`cancel_background_task` 自然语言管理工具。

### 4.8 项目系统（Projects）
- 项目 = 指令 + 文档书架 + 回收站：run 准入期解析线程项目并钉住为不可变快照，渲染请求级 `<project>`/有界 `<documents>` 上下文（不持久化、不可信内容中和、角色权威分离——项目数据走用户角色消息不走 system prompt）。
- 文档存储内容寻址（sha256 命名空间独占）、file-before-row 原子插入、首读惰性 Markdown 转换、trash 层纯行迁移（恢复=数据库 re-point）、保留期惰性清扫 + 存储对账。

### 4.9 多实例高可用（全新）
- **Run 所有权**：worker_id、租约心跳续租（lease_seconds/3 周期）、续租失败 fence 本地 worker（取消任务、不再写终态）、孤儿 run 周期回收、跨 worker 持久取消请求、`CancelOutcome` 七态取消语义、同线程活跃 run 数据库部分唯一索引 + 幂等准入 key。
- **Redis StreamBridge**：跨进程 SSE 流桥（旧版 async 路径是 NotImplementedError），XADD/XREAD + Last-Event-ID 重放 + 心跳 + TTL。
- **StreamGap**：订阅者落后于保留缓冲时显式 yield gap 让调用方重载状态，而非假装完整重放。
- scheduled/batch/mcp-task 各自的租约与恢复原语；跨 Pod webhook 去重表。

### 4.10 Checkpoint 体系升级
- **delta 通道模式**：`checkpoint_channel_mode: full|delta`（全量快照 vs 增量通道），构建期冻结 + 读写兼容门（delta 可读旧 full，单向迁移）；`DeltaThreadState` 线性实现 add_messages 语义；fork 恢复的兄弟分支重放修复（#4458 线性化写）。
- **checkpoint 历史缓存**：`CachedHistorySaver` 装饰任意 saver，递归组装增量历史（稳态 ~2 层命中），memory/Redis 双后端，部署身份哈希防跨部署键碰撞。
- CheckpointStateAccessor 统一状态读写咽喉 + `build_state_mutation_graph` 合成节点做整体状态替换（回滚/压缩）。

### 4.11 上下文经济（token/成本治理）
- 延迟工具加载（tool_search 重做：构建期闭包 catalog + graph state 持久化提升 + catalog_hash 防漂移 + fail-closed）+ MCP 路由自动提升。
- 延迟技能发现（`<skill_index>` 紧凑索引 + `describe_skill` 工具按需取元数据）。
- 静态 system prompt（记忆/日期移出）+ 前缀缓存；summary 独立通道（不再写回 messages）+ 增量摘要 + 多模型候选链；viewed_images 元数据化（base64 不再进 state）。

### 4.12 可观测性
- trace_context（ContextVar 唯一来源，X-Trace-Id 派生，覆盖调度/IM/嵌入入口）；Langfuse 根级 trace + session/user/assistant/environment 元数据；装配描述符 AgentAssemblyDescriptor（模型/工具/中间件/策略的可比较身份，"哈希而非复制"）；release_policy_parameters 策略身份；RunJournal 事件目录化（events/catalog）+ 中间件审计事件 + caller 分桶 token 统计（lead/subagent/middleware + per-model + cache_read）+ LLM usage 回放合并；Monocle 观测可选 extra。

### 4.13 新产品面
- **TUI 终端工作台**（textual，`deerflow` 命令；会话互通 Web UI）。
- **输入润色**（input_polish）、**后续建议**（suggestions，≤5 条）——共用 oneshot_llm 辅助。
- **IM 渠道升级**：用户自有渠道连接（channel_connections 表 + Fernet 凭据加密）、Feishu 流式卡片、Discord 支持（typing 循环/关闭治理）、GitHub webhook 触发 agent（repo 绑定/require_mention/白名单）。

---

## 5. 既有模块的重大变更

### 5.1 Agent 层（agents/）
- **`lead_agent/agent.py`（330→1106 行）**：新增 `assemble_lead_agent()` 返回 (graph, descriptor)；模型授权 `_authorize_model_name`；checkpoint 模式冻结；authz 工具过滤；十数个新中间件装配；bootstrap agent 走完整管线；子代理总量上限。
- **`thread_state.py`（41→374 行，重写）**：新增状态通道 goal、promoted（延迟工具提升）、delegations（委派台账，≤50 条终态不可回退）、skill_context（最近 8 个技能引用）、task_notes、task_history、summary_text、background_tasks；sandbox 冲突 fail-closed reducer；delta 模式 schema 工厂。
- **`prompt.py`（612→974 行）**：多用户技能缓存（(config, user) 键 LRU）；系统性 html.escape；`<disabled_skills>` 清单；延迟技能索引；子代理委派策略重写；`<self_update>`/`<memory_tool_system>` 段；静态 system prompt。
- **既有中间件增强**（抽样）：
  - llm_error_handling（322→881）：进程级 LLM 并发限流器（跨事件循环共享）、burst-rate 识别、按异常的重试预算、AWS 去相关抖动退避、结构化 fallback 标记（`deerflow_error_fallback`，子代理据此判 FAILED）。
  - loop_detection（323→847）：警告排队到下次 model call（修 OpenAI 配对错误）、(thread,run) 作用域、精确读窗口键、滑动窗口频率检测、per-tool 覆盖、审计事件。
  - summarization（289→912）：独立 summary_text 通道、增量摘要、多模型候选链 fail-open、必保上下文、手动 /compact API、task continuity 归档。
  - clarification（158→483）：v2 结构化表单（8 类字段/16 字段上限）、同级工具丢弃、非交互渠道降级。
  - dangling_tool_call（126→449）：四合一消息修复器（非法名清洗/synthetic id 重配对/causal 重排/孤儿 ToolMessage 丢弃）。
  - guardrails（86→243）：请求上下文大扩容（身份/角色/run_id），授权结果通道，审计事件，fail-open 语义化。

### 5.2 运行时（runtime/）
- **`runs/manager.py`（212→2202）**：多 worker 所有权/租约/心跳/孤儿回收/跨 worker 取消/幂等准入/finalizing 屏障/优雅停机（详见 §4.9）。
- **`runs/worker.py`（480→2702）**：run 生命周期强化（try_start CAS、取消结算、终态写入次序重构）；extensions 生命周期接线；goal 自动续跑；交付验证（workspace 快照对比 + present_files 覆盖检查 + 幂等 run.delivery 回执，未交付判 error）；子图命名空间事件（子代理帧不再冒充根图）；LLM 错误 fallback 检测；delta 恢复线性化；消息 seq 盖章；大文件工具调用分片批处理；终态后循环 GC；agent 构建 off-loop。
- **`journal.py`（332→1163）**：caller 分桶 token 统计；进度上报节流；交付事实记录；分支/checkpoint 历史种子事件（regenerate/edit-replay 配套）；LLM usage 回放合并；工具结果补账。
- **events/store**：Postgres advisory lock fence 序列化线程内变更；put_if_absent 幂等原语；message→run 归属查找；jsonl 后备存储全异步 + 取消安全。
- **stream_bridge**：Redis 桥落地 + StreamGap 语义。
- **serialization**：values 序列化剥离 data: 图片块；保留 `__interrupt__`。

### 5.3 工具与生态（tools/、mcp/、community/、models/、skills/）
- **mcp/tools.py（108→864）**：stdio 会话池（(server, user:thread) 作用域，Playwright 类有状态服务器可用）；per-server 初始化/调用超时；stdio 子进程 cwd/TMP 钉定 + 本地路径→虚拟路径确定性映射；MCP 工具名白名单；路由元数据打标；后台任务工具集包装；服务器独立发现互不拖累。
- **extensions_config.py（209→715）**：MCP server 级新增 user_auth（每用户凭据头）、headers_from_context、routing（软路由提示）、per-tool 覆盖、超时、task_toolsets；`middlewares` 可配置中间件链。
- **task_tool.py（257→1125）**：返回 LangGraph Command 结构化结果（status/stop_reason/token/receipts/verdicts 元数据）；验收清单；receipt 核验；context_mode；身份归因传播；生命周期健壮化（隔离 loop、延迟清理防 GC）。
- **tools/builtins 新增**：update_agent（自定义 agent 自我更新 SOUL/config）、list_uploaded_files、review_skill_package、background_tasks 管理、batch_task 三件套、read_conversation（宿主授权的会话读取）。
- **community 新增 16 provider**：搜索 6（brave/searxng/serply/sofya/tencent_wsa/groundroute 元搜索）、抓取 3（browserless/crawl4ai/fastcrw）、沙箱 4（boxlite micro-VM/e2b/opensandbox/tenki）、RAG 2（lightrag/ragflow）、浏览器自动化 1（browser_automation，Playwright 工具组）；共享模块 search_time_range（统一时间范围）、url_safety（SSRF 防护）、warm_pool_lifecycle（暖池 mixin）。
- **models**：新增 Codex provider 集成（thinking→reasoning_effort 映射）、MiMo/StepFun 推理模型补丁（reasoning_content 回放）、RequestAdmission 限流器、assistant payload 回放共享层；vLLM 流式 usage 增量核算修复；OpenAI 兼容客户端默认 stream_chunk_timeout=240s。
- **skills**：allowed-tools 别名规范化（Bash/Read/Write/Edit→小写工具名）；required-secrets 请求级密钥声明；安装器接入静态扫描与 4096 条目上限；用户作用域存储；投影/导出/斜杠命令/工具策略等 11 个新文件。
- **sandbox**：全工具异步化；RBAC 门禁；read_file 行范围分页；write_file 字节上限 + append；本地沙箱 per-(user,thread) LRU；有界管道捕获防内存撑爆；跨实例所有权租约（own:/del: 两态，memory/redis）；暖池生命周期；受限网络模式（双网络 + 代理容器 + 审批）；执行租约（多持有者最后释放）；技能投影四类视图。

### 5.4 配置面（config/）
- `app_config.py`（362→678）新增约 27 个配置块：authorization、auth(SSO)、plugins、token_budget、tool_output、tool_progress、verification、read_before_write、safety_finish_reason、loop_detection(独立)、task_continuity、projects、scheduler、mcp_tasks、subagent_runtime、subagent_batches、run_ownership、dedupe_storage、channel_connections、input_polish、suggestions、llm_call(并发/重试整形)、skill_scan、logging、recursion_limit、agent_storage 等。
- `database_config.py`（83→273）：checkpoint delta/缓存/graph_cache、连接池参数、postgres_schema 自动创建。
- `reload_boundary.py`：登记需重启的基础设施字段（热重载边界单一事实源）；`file_signature.py`：(mtime,size,sha256) 变更签名防漂移漏检。

### 5.5 client.py（嵌入式客户端入口，1060→1532）
- 新增授权身份 kwargs 与 principal 构建、agent 缓存键纳入身份与 memory_enabled；tool_search/延迟装配接入；goal get/set/clear API；per-turn trace 绑定与 tracing 回调注入；沙箱租约清理包装；checkpoint 模式注入与 state schema 归一化；子代理执行容量配置。
- 流事件去重升级（id→对象映射支持替换消息增量、tool_call 分片缓冲）；get_thread 经 CheckpointStateAccessor 一次 materialize；thread_id 统一校验；MCP/skills 配置更新走跨进程文件锁；memory 系列改走 get_memory_manager()。

---

## 6. 行为/契约变化（对使用方的影响）

| 领域 | 2.0 行为 | 2.1.0 行为 |
|---|---|---|
| 部署 | LangGraph Server 独立进程 | Gateway 内嵌运行时（langgraph.json 仅工具兼容） |
| 记忆注入 | 拼进 system prompt | DynamicContextMiddleware 请求级 system-reminder；或 tool 模式四工具 |
| 记忆存储 | 单 memory.json | 摘要 JSON + 每事实 Markdown 分片（DOCUMENT_VERSION 2.0，自动迁移备份） |
| 摘要 | HumanMessage(name=summary) 写回 messages | 独立 summary_text 通道，DurableContext 投影 |
| task 工具返回 | 裸字符串 | LangGraph Command + 结构化 ToolMessage 元数据（subagent_status 等） |
| RunManager.cancel | 返回 bool | CancelOutcome 七态枚举 |
| viewed_images | state 存 base64 | 仅存元数据，按需从沙箱/验证过的主机副本读取 |
| write_file | 覆盖写 | 默认覆盖 + append 参数 + 字节上限 |
| 子代理上限 | 仅 max_concurrent(3) | 并发 + max_total_per_run 双限 + 进程容量准入 |
| max_turns 参数 | task 工具参数 | 移除，由配置/预算体系接管（recursion_limit 按中间件链换算） |
| 事件类型名 | 字符串散落 | events/catalog 集中目录（公共 JSON 契约 CI 校验） |
| SSE 子代理事件 | 冒充根图帧 | `mode|ns` 命名空间事件名 |
| 配置热重载 | 全部可热更 | reload_boundary 登记基础设施字段需重启 |
| 数据库 schema | 应用自建 | Alembic 迁移链 + Gateway 启动自动升级 |

---

## 7. 工程实践与代码质量

- **AGENTS.md 文档体系**：根目录 + agents/config/extensions/mcp/models/persistence/runtime/sandbox/skills/subagents/tools/tracing/tui/utils/community(tavily) 共 15+ 份包内架构约定文档。
- **一致性设计模式贯穿**：fail-closed/fail-open 显式成对配置；staging + os.replace 原子发布；异步路径文件 IO 全部经专用线程池卸载（file_io/assembly_io）且取消安全（shield + drain）；`__` 前缀服务器拥有的 context key；幂等原语（put_if_absent/idempotency_key/CAS）。
- **测试与工具链**：`make test`（离线默认）/`test-blocking-io`（阻塞 IO 严格套件）/`test-live`（真实 API 客户端集成）；`make detect-blocking-io` 静态扫描事件循环阻塞；`make migrate-rev` 迁移自动生成。
- **第三方兼容**：checkpoint_patches.py 对 langgraph 1.2.9 打补丁；assistant_payload_replay 处理 provider 专属字段回放；严格后端（vLLM/SGLang/Qwen/Anthropic）单 SystemMessage 兼容。

---

## 8. 各模块代码规模变化（Python 行数）

| 模块 | 2.0 | 2.1.0 | 增量 |
|---|---|---|---|
| agents | 5,651 | 28,949 | +23,298 |
| community | 2,477 | 17,917 | +15,440 |
| persistence | 1,269 | 11,050 | +9,781 |
| runtime | 2,953 | 12,471 | +9,518 |
| skills | 830 | 5,973 | +5,143 |
| subagents | 945 | 5,492 | +4,547 |
| sandbox | 2,306 | 6,360 | +4,054 |
| extensions | 0 | 3,599 | +3,599 |
| config | 1,931 | 4,950 | +3,019 |
| mcp | 392 | 3,255 | +2,863 |
| integrations | 0 | 2,824 | +2,824 |
| tools | 1,314 | 3,768 | +2,454 |
| tui | 0 | 1,918 | +1,918 |
| projects | 0 | 1,220 | +1,220 |
| workspace_changes | 0 | 922 | +922 |
| authz | 0 | 851 | +851 |
| models | 1,772 | 2,514 | +742 |
| utils | 483 | 1,211 | +728 |
| client.py | 1,060 | 1,532 | +472 |
| 其他（guardrails/tracing/uploads/根文件） | ~430 | ~1,020 | +590 |

---

## 9. 结论

2.0-m1-rc0 是一个功能骨架完整的 MVP（lead agent + 9 中间件 + 沙箱 + 子代理 + 记忆 + MCP + 技能）；2.1.0 在保留全部既有能力的基础上，围绕**生产化**完成了系统性重建：

1. **从单用户到多租户**：身份贯穿 + per-user 隔离 + 授权双层。
2. **从单进程到多实例**：run/调度/批次/任务租约 + Redis 流桥 + 孤儿恢复 + webhook 去重。
3. **从单体到可插拔**：扩展系统（带契约包）、记忆五后端、沙箱八后端、16 个新社区 provider。
4. **从"相信模型"到"验证模型"**：工具回执、验收清单、报告契约、交付验证、workspace diff。
5. **从"尽力而为"到"确定性治理"**：token 预算、循环/进度检测、安全终止、fail-closed 纪律、审计与可观测。
6. **新增产品面**：TUI、项目/文档架/回收站、定时任务、goal 自主循环、Lark 集成、输入润色/建议。

改动量级：约 4.1 万行新增实现代码 + 156 个文件修改，几乎每个既有子系统（除 reflection、少数 `__init__`）都有实质性演进；唯一删除是旧记忆单体（被后端化重构取代）。
