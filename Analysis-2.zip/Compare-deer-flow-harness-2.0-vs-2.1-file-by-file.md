# DeerFlow Harness 逐文件详尽对比报告：2.0-m1-rc0 → 2.1.0

对比对象：
- 旧版：`deer-flow-backend-2.0-m1-rc0/packages/harness/deerflow/`（下称 **旧**）
- 新版：`deer-flow-backend-2.1.0/packages/harness/deerflow/`（下称 **新**）

本报告在上一版主题报告基础上进行**逐目录、逐文件**的详尽对比。每个文件条目标注：状态（新增 ➕ / 修改 ✏️ / 删除 ❌ / 未变 ＝）、行数（旧→新），并给出具体变化点（新增类/函数/字段、行为变化、默认值变化）。

---

# 第 0 部分 统计总览

## 0.1 文件级统计

| 类别 | 数量 |
|---|---|
| 新增文件 | 413（含 15 份 AGENTS.md 文档、7 个 YAML 提示词模板、7 个 YAML 消息模式） |
| 修改文件 | 156 |
| 删除文件 | 5（agents/memory 旧单体五文件） |
| 完全未变 | 36 |
| 合计（旧→新） | 197 → 605 |

## 0.2 行数统计（Python）

| 模块 | 旧 | 新 | 增量 |
|---|---|---|---|
| agents | 5,651 | 28,949 | +23,298 |
| community | 2,477 | 17,917 | +15,440 |
| persistence | 1,269 | 11,050 | +9,781 |
| runtime | 2,953 | 12,471 | +9,518 |
| skills | 830 | 5,973 | +5,143 |
| subagents | 945 | 5,492 | +4,547 |
| sandbox | 2,306 | 6,360 | +4,054 |
| extensions | 0 | 3,599 | +3,599 |
| config | 1,931 | 4,950 | +3,019 |
| mcp | 392 | 3,255 | +2,863 |
| integrations | 0 | 2,824 | +2,824 |
| tools | 1,314 | 3,768 | +2,454 |
| tui | 0 | 1,918 | +1,918 |
| projects | 0 | 1,220 | +1,220 |
| workspace_changes | 0 | 922 | +922 |
| authz | 0 | 851 | +851 |
| models | 1,772 | 2,514 | +742 |
| utils | 483 | 1,211 | +728 |
| client.py | 1,060 | 1,532 | +472 |
| guardrails | 153 | 333 | +180 |
| tracing | 43 | 208 | +165 |
| uploads | 229 | 340 | +111 |
| 根目录散文件 | 0 | 743 | +743 |
| reflection | 75 | 75 | 0 |
| **合计** | **~23,883** | **~118,468** | **+94,585（≈5 倍）** |

## 0.3 最大的 20 个新增/重写文件

| 文件（新） | 行数 | 内容 |
|---|---|---|
| subagents/acceptance_checks.py | 1,636 | 子代理验收清单确定性检查 |
| agents/memory/backends/deermem/deermem/core/updater.py | 2,235 | DeerMem 事实提炼管线（旧 23.7KB→123KB） |
| community/e2b_sandbox/e2b_sandbox_provider.py | 2,623 | E2B 云沙箱 provider |
| agents/memory/backends/deermem/deermem/core/storage.py | 1,699 | DeerMem 分片存储 |
| integrations/lark_cli.py | 2,434 | Lark/飞书托管集成 |
| community/aio_sandbox/local_backend.py | 1,762（旧519） | Docker 本地后端 + 受限网络 |
| sandbox/tools.py | 2,343（旧1294） | 沙箱工具全家桶异步化 |
| runtime/runs/worker.py | 2,702（旧480） | run 执行器 |
| subagents/batch_service.py 等 | 369+ | 持久批次 |
| skills/skillscan/orchestrator.py | 1,055 | 38 条规则静态安全扫描 |
| extensions/manager.py | 1,003 | 扩展安装器 |
| persistence/bootstrap.py | 597 | 混合 schema 引导 |
| community/browser_automation/session.py | 935 | 浏览器会话管理 |
| persistence/scheduled_task_runs/sql.py | 813 | 调度出现记录 SQL |
| sandbox/local/local_sandbox.py | 825（旧358） | 本地沙箱 |
| persistence/scheduled_tasks/sql.py | 737 | 调度任务 SQL |
| skills/projection.py | 746 | 沙箱技能投影 |
| agents/memory/backends/deermem/deermem/core/retrieval.py | 614 | FTS5 检索 |
| sandbox/lease.py | 616 | 沙箱执行租约 |
| community/aio_sandbox/network_proxy.py | 580 | 网络代理容器 |

---

# 第 1 部分 根目录（deerflow/ 顶层）

## 1.1 `__init__.py` ＝（未变）

## 1.2 `client.py` ✏️（1,060 → 1,532）

嵌入式客户端（`DeerFlowClient`）主入口。主要变化：

1. **授权身份注入**：新增 `_EMBEDDED_AUTHORIZATION_CONTEXT_KEYS`（user_id、user_role、oauth_provider、oauth_id、channel_user_id、is_internal、authz_attributes）。`stream()` 的 `**kwargs` 可接收这些可信身份写入 graph context；`_ensure_agent` 在 `authorization.enabled` 时调 `build_principal_from_context()` 构建 principal，完整身份元组纳入 agent 缓存 key；调 `_authorize_model_name()` 在嵌入路径强制 `model:use` 授权（防绕过 Gateway）。
2. **工具授权**：工具侧调 `authz.tool_filter.apply_tool_authorization()`（Layer 1 过滤），`authorization_provider` 传给 middleware 构建（Layer 2 复用）。
3. **延迟工具装配**：接入 `tools.builtins.tool_search` 的 `assemble_deferred_tools`、`build_mcp_routing_middleware`、`get_mcp_routing_hints_prompt_section`——按 `tool_search.enabled` 延迟装配工具并注入 MCP 路由提示。
4. **技能系统多用户化**：`get_or_new_skill_storage()` → `get_or_new_user_skill_storage(user_id)`；`update_skill` 按 `SkillCategory.PUBLIC`（全局 extensions_config.json + 跨进程投影锁）与 CUSTOM/LEGACY（每用户 `_skill_states.json`）分流；更新后失效提示词缓存（`clear_skills_system_prompt_cache` / `invalidate_user_skill_cache`）。
5. **Goal API**：新增 `get_goal/set_goal/clear_goal`，走 `runtime.goal`（`build_goal_state`、`write_thread_goal`、`goal_thread_lock`），经 `_run_async_from_sync` 在同步 API 中跑 async checkpointer。
6. **Tracing 重构**：`stream()` 拆为外层 `stream()` + `_stream_turn()`：每 turn 绑定 trace id（`bind_trace_id`/`generate_trace_id`，每步 set/reset 防跨 Context 泄漏）；`build_tracing_callbacks` 在 graph 根注入回调；`inject_langfuse_metadata` 注入 session/user/assistant/model/environment 元数据。
7. **沙箱租约清理**：`_stream_with_sandbox_lease_cleanup` 包装 graph 迭代器，finally 调 `sandbox.lease.release_sandbox_execution_lease`。
8. **Checkpoint 通道模式**：`__init__` 冻结 `freeze_checkpoint_channel_mode`/`freeze_checkpoint_snapshot_frequency`；`stream()` 中 `inject_checkpoint_mode` + `ensure_checkpoint_mode_compatible`；`state_schema` 从固定 `ThreadState` 改为 `get_thread_state_schema(mode, frequency)`，middleware 经 `normalize_middleware_state_schemas` 归一化。
9. **新参数**：`environment`（进 langfuse tags，回退 `DEER_FLOW_ENV`/`ENVIRONMENT`）；`subagent_runtime` 配置经 `configure_subagent_execution_capacity` 设置执行容量；并发数走 `effective_subagent_concurrency`，新增 `max_total_subagents`。
10. **agent 配置**：命名 agent 走 `load_agent_config(agent_name, user_id)`（缓存 key 含 user_id），失败回退 memory-enabled 兼容默认；`memory_enabled` 进 agent 缓存 key。
11. **流事件去重升级**：`seen_ids` 集合 → `seen_messages`（id→对象映射），支持同一 id 被后继节点替换/追加文本（guard stop notice）时只发增量 delta；新增 `pending_tool_call_ids` 处理 `AIMessageChunk.tool_call_chunks` 分片流（分片期间不发 tool_calls 事件，等 values 快照补发）。
12. **get_thread 重写**：经 `CheckpointStateAccessor.bind(...).history()` 物化状态（delta 模式必需），一次 list 收集 pending_writes 避免 N 次往返。
13. **入口统一**：`list_threads`/uploads 等统一 `validate_thread_id`/`resolve_thread_id`；`update_mcp_config`/`update_skill` 走跨进程文件锁，raw 读写保留 `$VAR` 占位符；upload_files 转换 markdown 时预占伴生 .md 文件名防覆盖。
14. **memory 系列**：改走 `get_memory_manager()`（后端抽象，NotImplementedError 回退）；`get_memory_config` 返回 mode/shutdown_flush_timeout_seconds/manager_class/backend_config。

## 1.3 `AGENTS.md` ➕（106 行）
harness 包级架构约定文档：trace 上下文规则、Lark CLI 凭据管理、浏览器进度截图编码、嵌入式 `DeerFlowClient`（chat/stream、值/消息/自定义流模式）等约定。

## 1.4 `checkpoint_patches.py` ➕（158 行）
第三方 checkpoint 兼容补丁：针对 langgraph 1.2.9 的 `InMemorySaver.get_delta_channel_history` 等 delta 通道历史问题；从 `thread_state` 锚定导入，保证每个建图进程生效。

## 1.5 `constants.py` ➕（62 行）
共享运行时常量单一事实源：`DEFAULT_SKILLS_CONTAINER_PATH=/mnt/skills`、会话读取能力键与 `read_conversation` 工具名、`.browser-frames`/`.tool-results`/`.mcp` 隐藏目录名单、`RUN_EVENT_TYPE_MAX_LENGTH`(32)/`RUN_EVENT_CATEGORY_MAX_LENGTH`(16) 等——写入方与扫描方共用防漂移。

## 1.6 `logging_config.py` ➕（310 行）
日志设置辅助：trace_id 增强格式与过滤器；httpx/urllib3 日志中签名媒体 URL/凭据改写（脱敏 authority）。

## 1.7 `trace_context.py` ➕（147 行）
请求级 trace id 的唯一来源 ContextVar（`ensure_trace_context`/`resolve_trace_id`/`get_current_trace_id`）；`X-Trace-Id` 头与 run 元数据为派生输出不可回读；覆盖非 HTTP 入口（调度、MCP 通知、IM、嵌入式客户端）。

---

# 第 2 部分 agents/

## 2.1 `agents/__init__.py` ✏️（18 → 39）
改为轻量懒加载（`__getattr__` 惰性导出 `create_deerflow_agent`/`ThreadState` 等，降低导入开销）；`make_lead_agent` 变为模块级函数包装（LangGraph Server 反射要求）；新增 `DeltaThreadState` 导出。

## 2.2 `agents/factory.py` ✏️（308 → 426）
1. 新参数：`checkpoint_channel_mode`（默认 "full"；"delta"+checkpointer 直接拒绝防状态损坏）、`checkpoint_snapshot_frequency`、`subagent_runtime`（显式共享 SubagentRuntime：容量、batch worker；校验 batch submitter 已启动）。
2. 中间件链新增固定项：`DurableContextMiddleware`（写 delegations ledger + summary 投影）、`SystemMessageCoalescingMiddleware`。
3. memory 特性支持 `memory_config` 显式注入；tool 模式注册 4 个 memory 工具，仅会话抽取型后端保留被动 MemoryMiddleware。
4. subagent 特性：容量感知 `SubagentLimitMiddleware(max_concurrent, max_total)`；`bind_task_tool(execution_capacity)` 显式绑定；batch 三工具按运行时可用性注册。
5. `loop_detection`、`token_budget` 成为可关的特性开关；所有中间件经 `normalize_middleware_state_schemas` 适配 delta 模式。

## 2.3 `agents/thread_state.py` ✏️（41 → 374，重写）
1. **新增状态通道**：`goal`（GoalState）、`promoted`（PromotedTools，按 catalog_hash 作用域的延迟工具提升，reducer 防 catalog 漂移后暴露错误工具）、`delegations`（DelegationEntry 委派台账：status/result_brief/sha256/ref、stop_reason、receipt_verdict、acceptance_verdict，上限 50 条、终态不可回退）、`skill_context`（最近 8 个已加载技能引用，替代正文）、`task_notes`（TaskNotesChannel）、`task_history`、`summary_text`（摘要独立通道）、`background_tasks`。
2. `viewed_images` 瘦身：base64 → 仅存 `{mime_type,size,actual_path,sha256,source_sandbox_id}` 元数据（#4138），字节按需从沙箱/主机副本读取。
3. sandbox 冲突 fail-closed reducer：同线程不同 sandbox_id 直接抛错。
4. Delta checkpointing：`merge_message_writes` 线性实现 add_messages 语义（含 RemoveMessage/REMOVE_ALL_MESSAGES）；`DeltaThreadState` 用 DeltaChannel；`get_thread_state_schema(mode)`/`adapt_state_schema_for_mode`/`normalize_middleware_state_schemas` 按模式与快照频率生成缓存 schema。
5. `todos` 获得显式 reducer；时间戳统一 UTC。

## 2.4 `agents/features.py` ✏️（43 → 50）
`RuntimeFeatures` 新增：`memory_config`、`loop_detection`（默认 True）、`token_budget`（默认 False）。

## 2.5 `agents/goal_state.py` ➕（25 行）
目标驱动持续执行的状态载体（TypedDict）：`GoalBlocker` 六值（none/missing_evidence/needs_user_input/run_failed/external_wait/goal_not_met_yet）、`GoalEvaluation`（satisfied/blocker/reason/evidence_summary）、`GoalState`（objective/status/created_at/updated_at/continuation_count 与 max_continuations/no_progress_count 与 max_no_progress_continuations/last_evaluation）——为"自主循环续跑 + 无进展熔断"提供计数与上限。

## 2.6 `agents/human_input.py` ➕（61 行）
人机输入响应的结构化消息元数据契约：`HUMAN_INPUT_RESPONSE_KEY="human_input_response"`；`HumanInputTextResponse`/`HumanInputOptionResponse`（version=1/kind/source/request_id/response_kind/value[/option_id]）；`read_human_input_response()` 严格校验。记忆系统保留隐藏消息的权威判据（仅当隐藏消息携带人类澄清回答时保留进记忆）；deermem 的 `message_processing._is_human_clarification_response` 是其宿主无关镜像。

## 2.7 `agents/assembly_descriptor.py` ➕（456 行）
把 agent 工厂装配完成的瞬态知识投影为可比较的 `AgentAssemblyDescriptor`（哪些模型幸存、渲染后 prompt、授权留下的工具、中间件栈顺序）。设计规则："声明优于探测"（中间件实现 `release_policy_parameters()` 即拥有行为身份；探测私有属性仅回退并标 `probed: True`）与"哈希而非复制"（prompt/工具描述/schema 一律 canonical_hash）。关键函数：`describe_model_identity`（解 bound wrapper 链≤8 层，凭据永不序列化）、`describe_tool`（source: builtin|skill|community|mcp:server/mcp_transport）、`describe_middleware`（先解扩展隔离包装防坍缩）、`build_assembly_descriptor`（build 身份 = package_version + `DEER_FLOW_IMAGE_DIGEST`/`DEER_FLOW_IMAGE_DIGEST`，独立字段不进指纹）。

## 2.8 `agents/lead_agent/agent.py` ✏️（330 → 1,106）
1. 新增 `assemble_lead_agent()` 返回 `(graph, descriptor)` 二元组；`make_lead_agent` 保留为 LangGraph Server ABI 纯 graph 入口。
2. 模型授权 `_authorize_model_name()`：authorization.enabled 时 `authorize("model","use")`，拒绝时优雅回退第一个可见可用模型，fail_closed 时抛错。
3. checkpoint 通道模式冻结（防伪造 configurable key 或热改 config 改写通道表）。
4. 工具授权统一 `apply_tool_authorization()`；`update_agent` 仅对自定义 agent 且非 github webhook 渠道注入；memory 工具、project 文档工具（按 PROJECT_CONTEXT_KEY 钉定）、task_continuity 工具条件追加且去重。
5. 新中间件装配：DynamicContext、SkillActivation、SkillToolPolicy、DurableContext、SystemMessageCoalescing、McpRouting+DeferredToolFilter（含顺序断言）、TokenBudget、TerminalResponse、ModelLengthFinishReason、SafetyFinishReason、`load_configured_extension_middlewares`、`compose_with_extensions(AgentScope.LEAD)`。
6. Tracing 不变量：回调在 graph 调用根注入，in-graph `create_chat_model` 必须 `attach_tracing=False`（文件头 INVARIANT 文档化）。
7. `max_total_subagents` 进提示词、SubagentLimitMiddleware 与装配描述符。
8. 行为变化：thinking/reasoning/采样参数改为"请求 > 自定义 agent 配置 > 默认"三层优先级（区分 falsy 与未设置，#4336）；bootstrap agent 走完整管线且 `owns_agent_skill_projection=False`；`non_interactive` 剔除 `ask_clarification`。

## 2.9 `agents/lead_agent/prompt.py` ✏️（612 → 974）
1. 多用户技能缓存：`get_enabled_skills_for_config(app_config, user_id)`，(id(app_config), user_id) 键 LRU 上限 256；`invalidate_user_skill_cache`/`refresh_user_skills_system_prompt_cache_async` 按用户失效。
2. 提示注入防御：SOUL.md、技能 name/description/location、子代理 description 全部 html.escape（#4137/#4097/#4128）。
3. `<disabled_skills>` 禁用清单区块（加载全部技能渲染，明令不得读取）。
4. 延迟技能发现：`skill_names` 参数走 `<skill_index>`（仅名称），由 `describe_skill` 工具发现；"Skill First" 按模式分化。
5. 子代理委派策略重写：从"积极分解并行"改为"默认直接执行、净收益明显才委派"；n=1 与 n>1 两套话术；并行硬否决（依赖、共享状态）；context_mode 指引；验收清单结果解读；receipts 关闭时不提示；durable batch 专用段。
6. 新增段：`<self_update>`（教 update_agent 持久化 SOUL/config）、`<memory_tool_system>`（四 memory 工具准则）、系统上下文保密段（用户输入边界标记 + system prompt 不泄露）。
7. 静态系统提示词：memory 与当前日期不再拼进 system prompt（由 DynamicContextMiddleware 注入），保前缀缓存；`mcp_routing_hints_section` 注入路由提示。
8. 其他：`<current_uploads>` + `list_uploaded_files` 按需发现；文件编辑建议 str_replace/分段 write_file（#3189）；图片/Mermaid 用虚拟 artifact 完整路径。

## 2.10 `agents/lead_agent/__init__.py` ＝（未变）

## 2.11 agents/memory/（重构核心区）

### 2.11.1 删除的旧文件 ❌
- `message_processing.py`（4.3KB）→ 迁入 `backends/deermem/deermem/core/message_processing.py`（14.5KB）：模式外置 YAML；新增 4 类信号、trivial 过滤、人机澄清结构镜像。
- `prompt.py`（15KB）→ `core/prompt.py`（37KB）：常量 → YAML 外置 + 缓存 + agent 覆盖 + 聊天模板。
- `queue.py`（9.4KB）→ `core/queue.py`（20.8KB）：新增背压（QueueFull/queue_max_depth=1000）、信号豁免、flush_sync 硬超时排水、bypass_watermark。
- `storage.py`（9.2KB）→ `core/storage.py`（89.5KB）：单 JSON 文档 → 摘要 JSON + 每事实 Markdown 分片（`agents/{agent}/facts/{sha前2位}/{fact_id}.md`）+ `.metadata/` 边车；跨进程咨询文件锁、乐观并发（MemoryRevisionConflict）、原子写+fsync、损坏恢复、旧格式迁移备份、DOCUMENT_VERSION="2.0"。
- `updater.py`（23.7KB）→ `core/updater.py`（123KB）：新增 scope 门控、水印 LRU（4096）、staleness review、consolidation、信号提示、hybrid 淘汰、近重复合并门控。

### 2.11.2 `agents/memory/__init__.py` ✏️（54 → 31）
不再导出 DeerMem 私有符号（format_memory_for_injection、get_memory_data、MemoryUpdater、FileMemoryStorage、MemoryUpdateQueue 等），只导出 Manager 契约与工厂（`MemoryManager`、`get_memory_manager`、`reset_memory_manager`、错误类型、`memory_read_failures_are_fatal`）。私有实现从 `backends.deermem.deermem.core.*` 导入。

### 2.11.3 `agents/memory/manager.py` ➕（872 行）
`MemoryManager`（pydantic BaseModel + ABCMeta，未实现抽象方法构造期抛 TypeError）三层契约：Tier1 抽象（`add`/`get_context`）、Tier2 管理操作（add_nowait/search/get_memory/clear/import/export/delete_memory/cancel_by_agent/shutdown_flush）、Tier3 可选钩子（warm/reload_memory/create|delete|update_fact/on_pre_compress/on_turn_start）。`_check_invariants`：`supports_search` 标志必须与 search 覆写一致；mode="tool" 强制实现 search。`MemoryCallbacks` 观测钩子（langfuse 追踪，后端包零依赖）。错误体系：`MemoryManagerError`→`MemoryReadError`/`MemoryConflictError`/`MemoryCorruptionError`。`get_memory_manager()` 双检锁单例工厂；宿主钩子（callbacks/should_keep_hidden_message/trace_context_manager/host_llm_factory/extraction_callback）以 from_config kwargs 注入不进 backend_config。`_scan_backends()` drop-in 发现（backends/<name>/ 暴露 MANAGER_CLASS）；`_resolve_manager_class` 支持短名或点路径，解析失败响亮报错。

### 2.11.4 `agents/memory/tools.py` ➕（212 行）
memory.mode=="tool" 时注册 4 个 @tool：`memory_search`（自然语言查询 + category 过滤）、`memory_add`（快速去重预检 + 后端临界区权威复查）、`memory_update`、`memory_delete`。`_resolve_scope(runtime)` 从 LangGraph runtime context 解析 agent_name/user_id；错误返回 JSON 不抛异常。工具模式无自动陈旧度审查。

### 2.11.5 `agents/memory/AGENTS.md` ➕（234 行）、`backends/README.md` ➕（109 行）
架构文档与新后端开发指南（noop 为模板，含 6 步文档）。

### 2.11.6 `backends/deermem/`（默认后端，580+358+5,514 行核心 + YAML）
- `deer_mem.py`（580）：`DeerMem` 类包装五大核心模块为后端契约；依赖全部 PrivateAttr 依赖注入（消灭模块级单例）。
- `deermem/config.py`（358）：DeerMemConfig 全套旋钮（debounce_seconds=30、queue_max_depth=1000、max_facts=100、fact_confidence_threshold=0.7、max_injection_tokens=2000、token_counting、guaranteed_categories=["correction"]+guaranteed_token_budget=500、staleness/consolidation/dedup/eviction 开关）。
- `core/eviction.py`（212）：confidence 与 hybrid-v1 两策略（0.65 置信 + 0.25 新鲜度半衰期 90 天 + 0.10 访问热度半衰期 30 天）；correction 保底槽 0.10；影子淘汰审计。
- `core/llm.py`（54）：`build_llm` 走 `langchain.init_chat_model`；host_llm 优先失败降级。
- `core/paths.py`（104）：自解析数据根（storage_path > $DEERMEM_DATA_DIR > ~/.deermem/）；内联 user_id 清洗。
- `core/retrieval.py`（614）：SQLite FTS5 BM25 + jieba 分词 + 时间衰减×置信度 0.2 + 用户作用域；失败回退子串匹配。
- `core/message_patterns/*.yaml`（7 个）：correction/decision/goal/identity/preference/reinforcement/trivial 信号正则。
- `core/prompts/*.yaml`（4 个）：memory_update.chat（12.4KB 聊天模板）、staleness_review、consolidation、fact_extraction；支持 agent 级覆盖。

### 2.11.7 `backends/honcho/` ➕（client 54 + config 76 + manager 264 + README 75）
Honcho v3 远程 HTTP 后端，专注用户维度记忆；零本地 LLM 调用（服务端 deriver）；workspace-per-user 隔离；`_stable_id` 用 sanitize[:48]+sha256[:8] 防碰撞。

### 2.11.8 `backends/mem0/` ➕（client 109 + config 114 + manager 310 + message_filtering 81 + README 61）
mem0 Platform 无状态 HTTP 适配；状态全在服务端，多 worker 安全；身份映射 (user_id, agent_name)→(user_id, agent_id)、thread_id→run_id；`requires_passive_writes_in_tool_mode=True`。

### 2.11.9 `backends/noop/` ➕（config 64 + manager 159）
空实现 + 新后端开发模板。

### 2.11.10 `backends/openviking/` ➕（config 153 + manager 574 + session 142）
基于官方 langchain-openviking 集成包；仅 middleware 模式；会话锁与生命周期 Condition 管理。

### 2.11.11 `agents/memory/summarization_hook.py` ✏️（25 → 22）
`memory_flush_hook` 变薄入口：仅保留 enabled+thread_id 门与 `resolve_runtime_user_id(event.runtime)`；过滤/校验/纠错检测全部下沉 `manager.add_nowait(...)`；记忆按 user_id 作用域。

## 2.12 agents/middlewares/（17 → 50 文件）

### 2.12.1 修改的旧中间件

**`thread_data_middleware.py` ✏️（92 → 92，内容变）**
user_id 解析 `get_effective_user_id()`（仅 ContextVar）→ `resolve_runtime_user_id(runtime)`（runtime.context 优先）；run_id 读取等价重构。目录初始化逻辑不变。

**`uploads_middleware.py` ✏️（242 → 256）**
1. 不再扫描/注入历史文件（historical_files 枚举删除），改由 `list_uploaded_files` 工具按需发现；注入标签 `<uploaded_files>` → `<current_uploads>`。
2. 上下文上限 `_MAX_FILES_PER_CONTEXT_SECTION=10`：超出折叠 "N more file(s) omitted" + 扩展名统计 + glob/grep 提示。
3. 注入防护：filename/path/outline/preview 全部 `neutralize_untrusted_tags`。
4. `is_upload_staging_file` 过滤分块上传暂存文件；无新文件时清除陈旧状态。
5. `additional_kwargs[ORIGINAL_USER_CONTENT_KEY]` 保存原始用户内容供还原。
6. 新增 `abefore_agent`：`run_in_executor` 把阻塞文件 IO 派发工作线程；outline 提取移至 `utils.file_outline`。

**`memory_middleware.py` ✏️（86 → 100）**
1. 接口重构：`filter_messages_for_memory`+`detect_*`+`get_memory_queue().add(...)` → `get_memory_manager().add(thread_id, messages, agent_name, user_id, trace_id)`（过滤/校验全部进 manager）。
2. 新增 trace_id 捕获（Timer 线程无 ContextVar，以数据形式传递）。
3. 新增 `aafter_agent` 异步钩子（`manager.aadd`）。
4. 拆出 `_resolve_add_args` 统一判定。

**`clarification_middleware.py` ✏️（158 → 483）**
1. v2 表单模式：`fields`（text/textarea/number/select/multi_select/checkbox/date；≤16 字段、≤24 选项、序列化 ≤16KB；原子校验失败整体降级；防 JS 原型链保留字）。
2. options/fields 规范化（去 XML 标签/去重/dict 扁平化）。
3. 结构化 payload 走 `ToolMessage.artifact={"human_input":...}`（协议版本 v1/v2）。
4. 同级工具丢弃：ask_clarification 与其他工具同批时克隆 AIMessage 只保留澄清调用；malformed 也视为停止信号。
5. 非交互渠道（disable_clarification）把澄清转"按最佳判断继续" ToolMessage 而非中断。

**`dangling_tool_call_middleware.py` ✏️（126 → 449）**
从"补悬挂调用"扩展为四合一修复器：(1) 清洗非法工具名/参数（invalid_tool_calls、raw payload、unknown_tool 重命名、write_file 大 payload 恢复提示 #2894）；(2) 空/缺失 tool_call_id 重写为位置派生合成 id 并重新配对；(3) 工具结果按 AIMessage 分组 causal 重排；(4) 丢弃孤儿 ToolMessage（summarization/分支遗留）。防严格后端 HTTP 400。

**`llm_error_handling_middleware.py` ✏️（322 → 881）**
1. 进程级 LLM 并发限流器 `_ProcessWideLimiter`（threading 原语跨 loop 共享，FIFO+许可转让、取消不丢容量，cap 启动冻结）。
2. burst-rate 识别（单独 reason，重试预算 2 次、基延迟更长）。
3. 按异常/原因的重试预算（StreamChunkTimeoutError 固定 2 次）。
4. AWS 去相关抖动退避（防重试风暴，Retry-After 优先）。
5. 结构化 fallback 标记：`deerflow_error_fallback/error_type/error_reason/error_detail`（执行器据此判子代理 FAILED）。
6. 流中断专用文案；重试事件自定义事件发送；半开探针 token 化。

**`loop_detection_middleware.py` ✏️（323 → 847）**
1. 警告排队到下次 model call 注入（修 OpenAI "tool_call_ids did not have response messages"）。
2. 跟踪键 (thread_id, run_id)；同 run 隐藏 continuation 共享预算。
3. read_file 键从 200 行分桶改精确窗口。
4. Layer2 频率检测滑动窗口 + Counter（O(1)）。
5. `tool_freq_overrides` per-tool (warn, hard)；`from_config` Pydantic 校验；`consume_stop_reason`；审计事件；pending 警告 LRU。

**`summarization_middleware.py` ✏️（289 → 912）**
1. 摘要写独立 `summary_text` 通道（不再 HumanMessage(name=summary) 回写 messages），DurableContext 投影。
2. 增量摘要（previous_summary 参与，`<new_messages>` 转义）。
3. 多模型候选链（配置摘要模型→run 模型→默认→None；惰性构建、失败缓存、fail-open）。
4. `TAG_NOSTREAM` 防摘要 token 被前端当幻影 AI 消息。
5. 必保上下文（SystemMessage、动态 reminder、最新真实用户消息）。
6. `compact_state/acompact_state` 公开 API（手动 /compact）。
7. task continuity 归档（capture task_history）；CompactionEvent 观察者。
8. skill rescue 逻辑移除（由 skill_context 通道接管）。

**`tool_error_handling_middleware.py` ✏️（133 → 526）**
1. 变为生产者中间件：每个工具结果盖 `deerflow_tool_meta`（`normalize_tool_result`/`stamp_exception_meta`）。
2. task 工具异常打 status_contract 元数据；技能文件读取盖 skill_context 条目。
3. `_build_runtime_middlewares` 三层结构：外层 wrap（InputSanitization→ToolOutputBudget→ToolResultSanitization）→ 线程钩子（ThreadData→Uploads→Sandbox）→ 尾部（Dangling→LLMError→ToolReceipt→GuardrailAuthorizationAdapter→外部 guardrail→SandboxAudit→ReadBeforeWrite→ToolProgress→ToolErrorHandling）。
4. `build_subagent_runtime_middlewares` 给子代理完整镜像 lead 能力（Summarization 带 skip_memory_flush=True）。

**`title_middleware.py` ✏️（139 → 316）**：附件标题（数量/截断）、部分交互（allow_partial_exchange）、动态 reminder 识别、extensions 注入、attach_tracing 修复。

**`todo_middleware.py` ✏️（149 → 310）**：完成提醒 pending 队列 + wrap_model_call 注入；(thread,run) 作用域；工具调用意图检测；`release_policy_parameters`。

**`token_usage_middleware.py` ✏️（233 → 304）**：归因扩展到子代理（`_subagent_usage_from_tool_message` 从 ToolMessage 元数据提取回填 AIMessage）。

**`sandbox_audit_middleware.py` ✏️（304 → 457）**：heredoc 体感知的复合命令切分；管道不切分；eval/source+命令替换高危；`_COMMAND_POSITION_PREFIX` 位置感知匹配；`<(...)` 进程替换识别。

**`subagent_limit_middleware.py` ✏️（54 → 144）**：新增 max_total per run；计数从 delegations 台账读取（按 run_id 过滤）；`release_policy_parameters`。

**`view_image_middleware.py` ✏️（166 → 360）**：从 state 读元数据按需重读（沙箱 download_file 或 `_read_verified_host_copy`，#4138）；注入从 before_model 写 state 改 wrap_model_call 改请求；去重；大小上限。

**`deferred_tool_filter_middleware.py` ✏️（85 → 101）**：构造方式重做（构建期注入 deferred_names + catalog_hash）；promotion 状态改图状态（catalog_hash 匹配才生效）；`release_policy_parameters`；旧全局注册表逻辑移除。

**`agents/middlewares/__init__.py` ＝（未变）**

### 2.12.2 新增中间件（33 个，按主题）

**上下文管理组**
- `dynamic_context_middleware.py` ➕（664）：记忆/当前日期以 `<system-reminder>` 一次性注入首条用户消息前（冻结快照保前缀缓存）；跨午夜日期更新提醒；`DEER_FLOW_DATE_TIMEZONE`。
- `durable_context_middleware.py` ➕（264）：委派台账/已载技能/摘要捕获进 checkpoint 通道；注入时静态规则 SystemMessage + 不可信 channel 值隐藏 HumanMessage。
- `system_message_coalescing_middleware.py` ➕（135）：合并所有 SystemMessage 为单条前置（vLLM/SGLang/Qwen/Anthropic 兼容）；只改请求不改 checkpoint。
- `delegation_ledger.py` ➕（215）：委派台账确定性捕获/渲染（头尾截断预算 6000 字符）。
- `skill_context.py` ➕（164）：已加载技能文件确定性捕获/渲染。
- `message_utils.py` ➕（47）：`is_genuine_user_message`/`requires_input_sanitization`/`insert_after_leading_system_messages`。
- `_bounded_dict.py` ➕（24）：BoundedDict LRU 供守卫按 run_id 存状态。

**工具治理组**
- `token_budget_middleware.py` ➕（327）：run 级 token 预算；软阈值延迟警告、硬阈值剥离 tool_calls；`consume_stop_reason`→budget_capped（#3875）。
- `tool_output_budget_middleware.py` ➕（683）：超大输出落盘 `.tool-results/` + 紧凑预览；被取代历史 write_file 内容占位符化（#5328）。
- `tool_output_synopsis.py` ➕（541）：json/csv/tsv/yaml/xml/code/text 确定性摘要；5MB 上限。
- `tool_progress_middleware.py` ➕（675）：(thread,tool) 状态机 ACTIVE→WARNED→BLOCKED（RFC #3177）。
- `mcp_routing_middleware.py` ➕（128）：模型调用前按最新用户文本+路由索引自动提升延迟 MCP 工具。
- `tool_promotion_audit_middleware.py` ➕（121）：提升决策持久化审计。
- `read_before_write_middleware.py` ➕（407）：读后写版本门（sha256 印记；写后失效；(scope,path) 锁；#3857）。
- `tool_call_args.py` ➕（240）：四表面（tool_calls/kwargs/content 块/chunks）一致重写参数。
- `tool_call_metadata.py` ➕（104）：id 一致性辅助。
- `tool_receipt.py` ➕（223）+ `tool_receipt_middleware.py` ➕（161）：确定性回执 r1..rN；台账注入模型。
- `receipt_verification.py` ➕（148）：子代理报告 [rN] 引用交叉核验（纯函数）。
- `tool_result_meta.py` ➕（304）：统一 `deerflow_tool_meta`（status + 推荐下一步）。
- `tool_transform_meta.py` ➕（20）：raw→visible 变换链元数据。
- `terminal_response_middleware.py` ➕（188）：工具回合保证可见收尾（空响应重试一次再 fallback）。

**安全组**
- `input_sanitization_middleware.py` ➕（450）：用户输入 XML 类标签转义（#3630，"去标识而非拒绝"）；请求级变换 state 保留原文。
- `tool_result_sanitization_middleware.py` ➕（136）：不可信工具结果（web/MCP）中和防伪造 `<system-reminder>`。
- `safety_finish_reason_middleware.py` ➕（385）+ `safety_termination_detectors.py` ➕（191）：content_filter/refusal/SAFETY 处理——剥离半截 tool_calls、空响应回填解释（#3028/#4393）；检测器可配置（内置 OpenAI/Anthropic/Gemini）。
- `model_length_finish_reason_middleware.py` ➕（106）+ `model_length_termination_detectors.py` ➕（94）：length 截断检测打 stop_reason（#4271）。

**技能组**
- `skill_activation_middleware.py` ➕（522）：/skill 显式激活 + secret 绑定（`ACTIVE_SECRETS_CONTEXT_KEY`）。
- `skill_tool_policy_middleware.py` ➕（329）：激活技能 allowed-tools 白名单；决策带所有权 token 防伪造；tool_search 提升不能恢复。

**其他**
- `audit_context.py` ➕（22）：窄作用域审计 recorder 的 runtime context 解析。
- `configured_extensions.py` ➕（37）：按 config 实例化外部声明中间件。
- `agents/middlewares/AGENTS.md` ➕（108）：中间件栈架构文档。

## 2.13 agents/task_continuity/ ➕（全新，161+84+83+1）
- `archive.py`（161）：线程本地 SQLite FTS5 归档（scope=threads/<id>/task-history/history.sqlite；owner digest 授权；中文 2-gram+英文词分词；BEGIN IMMEDIATE 批次去重、LRU 淘汰、128MiB 页上限；acapture shield 取消安全）。
- `state.py`（84）：`normalize_task_history`（64-hex 去重上限 64、status 白名单）、`normalize_task_notes`（8 键/750 字符/4 source_id；authority=model_report）、`TaskNotesChannel`（通道层校验写入）。
- `tools.py`（83）：`history_search`（600 字符摘录+source_id）、`history_read`（分页 4000 字符）、`task_note`（保存/替换/删除笔记，source_id 必须可检索）；同步/异步双实现。
- `__init__.py`（1）。


---

# 第 3 部分 authz/（全新模块，10 文件 851 行）

| 文件 | 行数 | 内容 |
|---|---|---|
| `provider.py` ➕ | 91 | `Principal`（user_id/role/oauth_*/channel_user_id/is_internal/attributes）、`AuthzRequest`（principal+resource+action+target+context）、`AuthzDecision`（allow/reasons/policy_id/metadata）、`AuthorizationProvider` Protocol（authorize/aauthorize/filter_resources）。resource/action/target 为自由字符串，新资源类型无需改 schema |
| `principal.py` ➕ | 49 | `build_principal_from_context()`（唯一官方构造点，纯函数）、`normalize_authz_attributes()` |
| `rbac.py` ➕ | 217 | `RbacAuthorizationProvider` 内置 RBAC；`_CompiledPolicy` 不可变预编译（deny 恒胜 allow）；构造期全量校验（未知键拒绝防静默错授权）；无策略=不限制（authz.no_policy）。配置形如 `roles: {user: {tools: {allow: "*", deny: [update_agent]}}}` |
| `adapter.py` ➕ | 119 | `GuardrailAuthorizationAdapter`：把 AuthorizationProvider 适配成 GuardrailProvider 协议（现有 GuardrailMiddleware 无需新类即可执行授权）；`_infrastructure_decision()` 让框架派生工具免二次判定 |
| `enforcement.py` ➕ | 32 | `filter_tools_by_authorization()`：Layer 1 批量过滤（保序；provider 异常 fail_closed 清空/fail_open 保留） |
| `tool_filter.py` ➕ | 58 | `apply_tool_authorization()`：lead/subagent/embedded client 三条装配路径一行式封装，返回 (filtered_tools, provider) 供 Layer 2 复用 |
| `runtime.py` ➕ | 67 | 两阶段工厂 `resolve_authorization_provider_spec()`（离事件循环）+ `construct_authorization_provider()`（事件循环上构造+协议校验） |
| `sandbox_authz.py` ➕ | 153 | `authorize_sandbox_execution(_async)()`：沙箱执行前 `authorize("sandbox","execute")` 门禁；拒绝抛 `SandboxAuthorizationError`；`safe_app_config()` 无 config 降级 no-op |
| `outcome.py` ➕ | 41 | `AuthorizationOutcome` + put/pop（context key `__authorization_outcome`，`__` 前缀防 Gateway 伪造，容量 500） |
| `__init__.py` ➕ | 24 | 导出 |

配置：`config/authorization_config.py`（enabled、provider.use+config、default_role="user"、fail_closed）。

---

# 第 4 部分 community/

## 4.1 修改的既有 provider

**`ddg_search/tools.py` ✏️（75 → 168）**
1. `_search_text` 新增 `backend` 与 `time_range` 参数（映射 DDGS timelimit）；`_resolve_time_range_backend` 过滤到支持时间范围的 backend（brave/duckduckgo/yahoo）。
2. Wikipedia region 修正：`_infer_wikipedia_region`（按查询 Unicode 码点推断日/韩/中/俄等）+ `_resolve_ddgs_region`（wt-wt 替换具体 region，jp→ja 别名）。
3. `web_search_tool` 新增 `time_range` 工具参数；config 覆盖扩展 max_results/region/safesearch/backend。

**`serper/tools.py` ✏️（77 → 271）**
1. 新增 `image_search` 工具（google.serper.dev/images，返回 image_url/thumbnail_url/usage_hint）。
2. SSRF 防护链：`_safe_public_url`（拒绝非 http(s)/localhost/私网/非全局 IP/尾点 FQDN）+ `_decode_ipv4`（识别十进制/十六进制/八进制混淆 IPv4）+ `_is_url_present`。
3. `_clean_query`（截断 500）、`_coerce_max_results`（钳制 10）、`_response_items`（容忍 null organic）。
4. `_serper_post` 统一 POST 与错误处理；api key 警告按工具去重。

**`tavily/tools.py` ✏️（51 → 58）**：`_get_tavily_client(tool_name)`——web_fetch 用自己的 api_key；`time_range` 透传；标题回退 `title or url`（防 KeyError）。

**`firecrawl/tools.py` ✏️（58 → 65）**：`base_url` 支持自托管 Firecrawl。

**`jina_ai/jina_client.py` ✏️（35 → 38）**：`crawl()` 新增 proxy/trust_env。

**`jina_ai/tools.py` ✏️（26 → 56）**：config 新增 proxy/trust_env 读取（`_coerce_bool/_coerce_timeout/_coerce_proxy`）；`extract_article(html, url=url)`。

**`infoquest/infoquest_client.py` ✏️（339 → 342）**：三处 requests.post 加 `timeout=30`（旧版无任何超时）。

**`image_search/tools.py` ✏️（111 → 111，行数不变内容有变）**：接入统一 time_range（复用 search_time_range）。

**`aio_sandbox/aio_sandbox_provider.py` ✏️（588 → 2,219）**
1. `WarmPoolLifecycleMixin` 共享暖池生命周期（idle 检查、warm 过期、最老逐出、replica 计数）。
2. 跨实例所有权协调 `ownership/` 子包：take()（acquire 转移）与 claim()（adopt/reap 条件占有）分离；`own:`/`del:` 两态租约防"销毁窗口"竞态；acquire epoch、intent mark；memory/redis 双存储（Redis 支持多 Gateway 共享容量）。
3. 多用户化：确定性 id 由 (user_id, thread_id) 派生；Agent 技能策略独立身份 + 四类挂载。
4. 全异步路径；租约续约独立线程；孤儿容器周期 reconciliation；不健康容器丢弃；Lark CLI 集成挂载（含 broker 检测）；网络策略事件接口。

**`aio_sandbox/aio_sandbox.py` ✏️（200 → 706）**：`_ScopedShellSession`（每 scope 一条有序持久 shell 会话，404 自动轮换）；`_execute_with_env` 经 bash.exec 注入密钥；download_file、read_file 行范围、close()。

**`aio_sandbox/local_backend.py` ✏️（519 → 1,762）**：受限网络模式（internal+egress 双网络 + 独立 network proxy 容器 + 策略 digest 标签 + 销毁清理）；容器容量/策略兼容检查；CPU/内存限制；Docker Desktop/bridge/IPv6 规范化。

**`aio_sandbox/remote_backend.py` ✏️（121 → 328）**：provisioner 认证头、managed skills 四类挂载、shell 容量替换检测、`list_running`。

**`aio_sandbox/backend.py` ✏️（85 → 184）、`sandbox_info.py` ✏️（33 → 43）**：接口扩展（网络策略、容量）。

## 4.2 新增共享模块
- `search_time_range.py` ➕（15）：day/week/month/year → 各引擎参数（DDG timelimit、Brave freshness 等）。
- `url_safety.py` ➕（62）：共享 SSRF 防护（域名解析全部 IP、阻断内网/环回/云元数据）。
- `warm_pool_lifecycle.py` ➕（102）：暖池生命周期 mixin（idle 600s、replicas 3）。
- `aio_sandbox/network_proxy.py` ➕（580）：SQLite 状态、域名规则、SSRF 公网校验的 HTTP/HTTPS 代理容器（支持交互式审批 grant）。
- `aio_sandbox/ownership/{base,memory,redis,factory}.py` ➕（146+86+186+82+20）：所有权协调（RenewOutcome 区分 LAPSED/LOST）。

## 4.3 新增 provider（16 个）

**搜索类**
- `brave/` ➕（323+2）：Brave Search API web+图片（结构化结果、配额）。
- `searxng/` ➕（61+50+2）：自托管 SearxNG 元搜索。
- `serply/` ➕（176+2）：实时 Google 结果，一个 key 覆盖 web/News/Scholar（vertical 切换）。
- `sofya/` ➕（181+2）：搜索+抓取（返回正文非 snippet）。
- `tencent_wsa/` ➕（213+1）：腾讯云 Web Search API (SearchPro)。
- `groundroute/` ➕（135+2）：元搜索层——一个 API 前置 6 引擎（Serper/Brave/Exa/Tavily/Firecrawl/Perplexity），按质量/成本路由缓存去重。

**抓取类**
- `browserless/` ➕（232+293+3）：云浏览器抓取/截图，结果落 /mnt/user-data/outputs。
- `crawl4ai/` ➕（48+93+3）：自托管 Crawl4AI（fit/raw/bm25/llm 过滤）。
- `fastcrw/` ➕（91）：Firecrawl 兼容引擎（Rust 二进制，复用客户端只换 base_url）。

**沙箱类**
- `boxlite/` ➕（347+573+64+31）：BoxLite micro-VM（libkrun/KVM daemonless OCI VM），私有事件循环桥、暖池+replicas。
- `e2b_sandbox/` ➕（481+2,623+35+246+5）：E2B 云沙箱（Redis 所有权共享容量、周期 reconcile、warm pool、技能投影签名同步）。
- `opensandbox/` ➕（354+392+63+4）：OpenSandbox SDK provider。
- `tenki/` ➕（392+431+77+37）：Tenki 云 microVM（原生 fs API 二进制安全传输）。

**RAG 类**
- `lightrag/` ➕（141+73+126）：LightRAG 只读检索（operator 授权范围）。
- `ragflow/` ➕（155+79+321）：RAGFlow 只读检索。

**浏览器自动化**
- `browser_automation/` ➕（935+386+48）：BrowserSessionManager（多 tab、容量限制）+ navigate/click/type/snapshot/screenshot/get_text/back/close 工具集（live viewer、URL 脱敏）；可选 extra `browser=[playwright]`。

**文档**：`tavily/AGENTS.md` ➕（5）。

---

# 第 5 部分 config/

## 5.1 修改的配置文件

**`app_config.py` ✏️（362 → 678）**：新增约 27 个配置块（字段级清单）：
`logging`（enhance/json）、`token_budget`、`plugins`、`recursion_limit`、`skill_scan`、`tool_output`、`task_continuity`、`authorization`、`input_polish`、`suggestions`、`llm_call`（max_concurrent_calls/retry/burst 延迟）、`channel_connections`、`loop_detection`（独立块）、`tool_progress`、`verification`（receipts/checklist/judge）、`read_before_write`、`projects`、`safety_finish_reason`、`auth`（本地+OIDC）、`agent_storage`、`scheduler`、`mcp_tasks`、`subagent_runtime`、`subagent_batches`、`run_ownership`、`dedupe_storage`、`goal`。

**`extensions_config.py` ✏️（209 → 715）**：MCP server 级新增 `user_auth`（每用户凭据头）、`headers_from_context`（deny/passthrough）、`routing`（mode/priority/keywords）、`tools`（per-tool 覆盖）、`tool_name_prefix`、`tool_call_timeout`、`session_init_timeout`、`task_toolsets`；`ExtensionsConfig` 新增 `middlewares` 可配置中间件链。

**`database_config.py` ✏️（83 → 273）**：新增 `checkpoint_delta`（增量快照频率）、`checkpoint_graph_cache`、`checkpoint_cache`（memory/Redis 检查点缓存）、`checkpoint_channel_mode`；连接池 `pool_recycle`/`command_timeout`；`postgres_schema` 自动创建。

**`agents_config.py` ✏️（98 → 318）**：AgentConfig 新增 `display_name`、`allowed_subagents`、`model_settings`（temperature/max_tokens）、`thinking_enabled`、`reasoning_effort`、`memory_enabled`；新增 GitHub 触发配置（repo 绑定、actions/issue/pr 触发、require_mention、作者白名单、installation_id、bot_login、独立 recursion_limit）。

**`sandbox_config.py` ✏️（73 → 256）**：新增 `network`（mode/allow_domains/approval/temporary_grant_ttl/proxy_image）、`ownership`（memory/redis、renewal_interval、ttl_multiplier）、`overflow_policy`（wait/reject/burst）、`acquire_timeout`、`burst_limit`、`health_check_skip_seconds`、`thread_data_mounts`、`bash_command_timeout`（默认 600s）、`provisioner_api_key`。

**`memory_config.py` ✏️（71 → 205）**：新增 `mode`（middleware/tool）、`shutdown_flush_timeout_seconds`、`manager_class` + `backend_config`（后端可插拔）。

**`paths.py` ✏️（264 → 433）**：新增 managed subagents 目录、用户级 agents/skills 目录、skills_view 四类投影目录（public/custom/legacy/integrations，含 per-thread 视图）、用户 projects 及项目文档路径、per-user integration config/data 目录、`make_safe_user_id`。

**`subagents_config.py` ✏️（156 → 265）**：新增 `max_total_per_run`、`token_budget`（全局默认+每 agent override）。

**`model_config.py` ✏️（38 → 68）**：新增 `RequestAdmissionConfig`（requests_per_minute/group/max_wait_seconds/max_queue_size）挂到 ModelConfig.request_admission；`context_window`（UI 上下文率+摘要 fraction 触发）；`stream_chunk_timeout`（默认 240s）。

**`summarization_config.py` ✏️（75 → 95）**：`ContextSize` 校验器（拒绝 nan/inf；fraction 必须 (0,1]；messages 整数）；删除 preserve_recent_skill_* 四字段（技能保留改 skill_context 通道）；`model_name=None` 语义反转为"用运行模型"；`DEFAULT_KEEP=("messages",20)` 常量。

**`title_config.py` ✏️（41 → 51）**：`model_name=None` 从"默认模型生成"改为"本地 fallback 不调 LLM"；`reset_title_config()`。

**`acp_config.py` ✏️（37 → 48）**：`ACPAgentConfig.timeout_seconds`（默认 1800）——单次 ACP 调用等待上限。

**`checkpointer_config.py` ✏️（32 → 55）**：`postgres_schema` + 校验；`ensure_config_loaded()`；`load_from_dict(None)` 重置；安装提示改 extra。

**`skills_config.py` ✏️（56 → 65）**：`deferred_discovery`（默认 False）；`container_path` 走常量。

**`skill_evolution_config.py` ✏️（11 → 15）**：`security_fail_closed`（默认 True）。

**`stream_bridge_config.py` ✏️（32 → 76）**：`heartbeat_interval_seconds=15.0`（拒布尔）、`max_connections`、`stream_ttl_seconds=86400`、`recovered_stream_cleanup_delay_seconds=60`；queue_maxsize ge=1。

**`tool_search_config.py` ✏️（24 → 37）**：`auto_promote_top_k=3`（钳制 [1,5]）。

**`tracing_config.py` ✏️（112 → 161）**：`MonocleTracingConfig`（enabled/exporters/okahu_api_key，六种 exporter 白名单）；`is_monocle_tracing_enabled()`；`reset_tracing_config()`。

**`config/__init__.py` ✏️（29 → 33）**：导出 `LoopDetectionConfig`、`is_monocle_tracing_enabled`。

**未变 ＝**：`agents_api_config.py`、`guardrails_config.py`、`runtime_paths.py`、`run_events_config.py`、`tool_config.py`、`token_usage_config.py`（行数未变但 hash 未变，确认未改）。

## 5.2 新增配置文件（26 个）

| 文件 | 行 | 内容 |
|---|---|---|
| `authorization_config.py` | 39 | AuthorizationConfig：enabled/provider.use+config/default_role/fail_closed |
| `auth_config.py` | 90 | OIDC/SSO：issuer/client_id/scopes/token_endpoint_auth_method 等 |
| `run_ownership_config.py` | 39 | 多 worker 租约（lease_seconds、心跳、时钟偏差预算） |
| `scheduler_config.py` | 20 | multi_instance、租约、max_concurrent_runs、recursion_limit=1000 |
| `mcp_tasks_config.py` | 12 | 轮询间隔、租约、退避、结果字节上限 |
| `subagent_runtime_config.py` | 27 | 进程内执行容量 max_running/max_queued/queue\|reject（startup-only） |
| `subagent_batches_config.py` | 26 | 每批条目/并发/尝试/结果字符上限 |
| `agent_storage_config.py` | 30 | agent 定义存储 file/db |
| `dedupe_storage_config.py` | 31 | webhook 去重存储 auto/memory/postgres |
| `projects_config.py` | 79 | instructions 字节上限、shelf index 边界、trash 保留天数 |
| `channel_connections_config.py` | 45 | 用户 IM 渠道连接 |
| `input_polish_config.py` | 6 | enabled、max_chars=4000、模型覆盖 |
| `suggestions_config.py` | 12 | 后续建议（≤5 条） |
| `task_continuity_config.py` | 7 | enabled 开关 |
| `token_budget_config.py` | 16 | 总量/输入/输出上限、warn/hard_stop |
| `tool_output_config.py` | 107 | externalize_min_chars、落盘子目录、elide_superseded_writes |
| `tool_progress_config.py` | 41 | stagnation_threshold、warn_escalation_count、提示注入开关 |
| `read_before_write_config.py` | 32 | enabled、elide_blocked_payloads |
| `loop_detection_config.py` | 63 | enabled + per-tool ToolFreqOverride |
| `safety_finish_reason_config.py` | 37 | 检测器类路径配置 |
| `verification_config.py` | 21 | receipts 开关/渲染模式、checklist、小模型 judge |
| `skill_scan_config.py` | 8 | 原生 SkillScan 开关（默认开） |
| `postgres_schema.py` | 22 | PG schema 名校验 |
| `file_signature.py` | 45 | (mtime,size,sha256) 变更签名 |
| `reload_boundary.py` | 120 | 需重启的基础设施字段登记（startup-only 描述生成） |
| `config/AGENTS.md` | 79 | 配置系统架构文档 |

---

# 第 6 部分 extensions/（全新模块，14 文件 3,599 行）

| 文件 | 行 | 内容 |
|---|---|---|
| `loader.py` ➕ | 235 | `ExtensionSpec`（config.yaml `plugins:` 列表项：enabled/name/package/use/config/required/table_prefix）、`load_extensions()`（默认 fail-open 跳过坏扩展、required=true 中断启动；semver 兼容窗口 0.x 同 minor/1.x 同 major；位置式回滚；table_prefix 注册进 alembic 过滤器） |
| `registry.py` ➕ | 164 | `ExtensionRegistry`（注册期可变）+ `LoadedExtensions`（不可变运行时快照：app_store + 6 类贡献 + has_* 短路） |
| `anchors.py` ➕ | 91 | `PlacementAnchor` 语义位置→栈下标（outer/inner/outer_last/inner_last/inner_last_after/start/end 七种边）；唯一知晓栈形状的模块 |
| `stack.py` ➕ | 151 | `PLACEMENT_ANCHORS`（MODEL_LOGICAL/MODEL_PHYSICAL/TOOL_VISIBLE/TOOL_RAW/STANDARD 五种 Placement；SUBAGENT 作用域替换 MODEL_PHYSICAL 锚）、`compose_with_extensions()` 唯一组合入口 |
| `injection.py` ➕ | 124 | 收集贡献按 (order, 注册序) 从内向外插入；中间件名全局唯一；provenance 映射 |
| `isolation.py` ➕ | 305 | `IsolatedMiddleware` 失败隔离包装（观察型 fail-open：pre 失败补调 handler 一次、post 失败返回已捕获结果；GraphBubbleUp 透传；按已实现钩子集合缓存子类） |
| `ordering.py` ➕ | 101 | 声明式栈序不变量（ToolReceiptMiddleware 必须包住 Guardrail/SandboxAudit/ReadBeforeWrite/ToolProgress 等短路者）；违反硬失败并指认责任扩展 |
| `notify.py` ➕ | 448 | fail-open 通知扇出：notify_task_start/stop、observe_system_model_call（取消路径非阻塞）、notify_context_compacted、notify_agent_assembled；`set_extension_notify_loop()` 绑定子代理隔离循环 |
| `gateway.py` ➕ | 555 | `include_contributed_routers()`（拒绝进入宿主 public/CSRF 豁免命名空间 fail-closed；影子路由检测 fail-open；不支持 Mount/WebSocket/lifespan）、`start/stop_services()`（注册序启动逆序停止、每项独立超时） |
| `policy.py` ➕ | 32 | `project_host_policy()`：token 预算/子代理上限投影为 HostPolicySnapshot |
| `run_evidence.py` ➕ | 131 | StoreRunEvidenceReader：run/事件存储只读投影（游标 user 指纹防跨用户复用、secret 脱敏、limit 1..2000） |
| `manager.py` ➕ | 1,003 | 运维安装器：install/upgrade/remove/set_enabled/list_configured；本地目录快照（禁符号链接/敏感文件）、远程源必须 HTTPS 公网 Git、uv add/sync + uv.lock 可复现性校验、config.yaml YAML-AST 级原位重写、跨进程文件锁（Windows msvcrt）、失败事务回滚 |
| `cli.py` ➕ | 138 | `deerflow extensions install/upgrade/enable/disable/list/remove` 命令行 |
| `__init__.py` ➕ | 121 | 进程级单例 get_loaded_extensions、图构建期 ContextVar 绑定、运行快照 key `__deerflow_extension_snapshot`、诊断环形缓冲（1000） |
| `AGENTS.md` ➕ | 356 | 扩展系统架构文档 |

依赖契约包：`deerflow-extension-api==0.2.1`（精确锁版，注释说明版本契约设计）。

---

# 第 7 部分 guardrails/

- `middleware.py` ✏️（86 → 243）：GuardrailRequest 新增 thread_id/is_subagent/user_id/user_role/oauth_*/run_id/tool_call_id/channel_user_id/is_internal/authz_attributes（角色感知策略对子代理同样生效）；`put_authorization_outcome()` 授权结果通道；`_record_guardrail_event` 审计事件（allow/deny/provider_error/fail_closed，best-effort）；fail-open 路径语义化（生成 allow decision + evaluator_error reason）；`release_policy_parameters()`。
- `builtin.py` ✏️（16 → 27）：AllowlistProvider 增加 `release_policy_parameters()`。
- `provider.py` ✏️（39 → 51）：接口小扩展。
- `__init__.py` ＝（未变）。

---

# 第 8 部分 integrations/（全新模块）

- `lark_broker.py` ➕（389）：Pattern B 凭据代理（issue #4338）——长驻 sidecar 持有 lark-cli 二进制与凭据，loopback HTTP 暴露 `/v1/exec`、`/v1/health`（请求 1MB/输出 4MB/并发 8 有界防护）；`install_shim()` 在沙箱内只放转发 shim；纯 stdlib。
- `lark_cli.py` ➕（2,434）：Lark/飞书托管集成主模块——安装官方 28 个 lark-* 技能（zip-slip/符号链接/魔数全防护、staging+rename 原子替换）；Gateway/沙箱运行时二进制管理（checksums.txt 校验、arch-dispatch）；OAuth 设备码流（应用注册+用户授权）；凭据安全加固（POSIX 0700/0600；**Windows 走 NT API handle-relative**：`NtOpenFile` RootDirectory 相对打开、拒绝 reparse/硬链接、owner-only DACL）；`lark_cli_env_overlay()` 四种沙箱 env overlay；`sandbox_lark_broker_active()` TTL 缓存探测。
- `__init__.py` ➕（1）。

---

# 第 9 部分 mcp/

## 9.1 修改

**`tools.py` ✏️（108 → 864）**
1. stdio 会话池 `_make_session_pool_tool`：按 (server_name, user_id:thread_id) 作用域池化（有状态服务器如 Playwright 跨调用保持状态且按用户/线程隔离）；HTTP/SSE 不池化（#3203）。
2. per-server `session_init_timeout`（超时跳过该服务器，子进程树正确回收）；`tool_call_timeout` 仅 stdio。
3. 文件系统钉定：stdio 子进程 cwd 与 TMPDIR/TMP/TEMP 钉进线程 user-data 树；`_convert_call_tool_result` 自实现 MCP→LangChain 转换，把 ResourceLink 与自由文本中的本地路径确定性映射 `/mnt/user-data/...` 虚拟路径（不复制文件）；fs 操作 to_thread。
4. 工具名安全 `_VALID_MCP_TOOL_NAME`（非法名在加载边界丢弃，防伪造框架标签进 system prompt）。
5. 路由元数据 `tag_mcp_tool`/`tag_mcp_routing`。
6. 后台任务 `task_toolsets`：隐藏 driver 专用 status/cancel，submit 替换为持久后台任务包装（立即返回 DeerFlow task id）；缺工具抛 `McpTaskConfigurationError`。
7. 服务器独立发现（asyncio.gather 互不拖累）；按源分组精确定位工具归属（修服务器名互为前缀时错误池化）。

**`cache.py` ✏️（106 → 253）**：`_ConfigSignature`（路径+签名）陈旧检测；初始化 generation 等待；缓存重置联动回收 MCP 会话池。

**`oauth.py` ✏️（114 → 221）**：token 管理器每服务器实例缓存；自定义 `_authorization_value`；拦截器参数化。

**`client.py` ✏️（52 → 64）、`__init__.py` ✏️（12 → 16）**：小扩展。

## 9.2 新增（8 文件）

| 文件 | 行 | 内容 |
|---|---|---|
| `session_pool.py` ➕ | 673 | stdio 会话池实现（生命周期、超时、回收） |
| `headers.py` ➕ | 85 | 头构建/覆盖（大小写不敏感） |
| `context_headers.py` ➕ | 177 | 请求上下文头注入（deny/passthrough） |
| `user_scoped_auth.py` ➕ | 129 | 每用户凭据注入 |
| `interceptors.py` ➕ | 81 | `build_mcp_tool_interceptors`（从 tools.py 迁出） |
| `task_tool_caller.py` ➕ | 243 | 后台任务 submit 包装的调用侧 |
| `tasks/driver.py` ➕ | 23 | `McpTaskDriver` Protocol + Registry |
| `tasks/models.py` ➕ | 119 | TaskStatus 六态 + TaskSnapshot/TaskReference/TaskSubmitRequest |
| `tasks/ordinary.py` ➕ | 180 | OrdinaryMcpTaskDriver（"普通三工具契约"；pydantic 严格解析；task_id 防串号；submit 唯一带请求级凭据头） |
| `tasks/runtime.py` ➕ | 96 | 提交边界安装、配置快照冻结（热变更抛错）、启动校验 |
| `tasks/__init__.py` ➕ | 31 | 导出 |
| `AGENTS.md` ➕ | 49 | MCP 架构文档 |

---

# 第 10 部分 models/

## 10.1 修改

- **`factory.py` ✏️（135 → 319）**：Codex 集成（thinking→reasoning_effort none~xhigh 映射、剥离 max_tokens）；`supports_reasoning_effort` 能力门控；`_apply_stream_chunk_timeout_default`（OpenAI 兼容默认 240s）；`_normalize_openai_base_url`；`_warn_unknown_model_settings`；`create_chat_model` 新增 `attach_tracing` 与 `model_overrides`；RequestAdmission 配速接入。
- **`openai_codex_provider.py` ✏️（393 → 410）**：`_convert_messages` AIMessage 分支重写——invalid_tool_calls 也序列化 function_call（与 DanglingToolCallMiddleware 占位 ToolMessage 配对）；缺 name/call_id 守卫丢弃；空串 args 回退 "{}"。
- **`patched_minimax.py` ✏️（182 → 199）**：`_strip_user_message_names`——删除 user 消息 name 字段（修 2013 "user name must be consistent"）。
- **`patched_deepseek.py` ✏️（58 → 45）/ `patched_openai.py` ✏️（105 → 96）**：恢复逻辑抽取到共享 `assistant_payload_replay.restore_assistant_payloads`。
- **`vllm_provider.py` ✏️（215 → 268）**：按 completion_id 的 usage 快照/增量核算（修流式 usage 统计）。
- **`claude_provider.py` ✏️（306 → 309）**：文档性变更（prompt caching docstring 说明静态 system prompt 约定）。
- **`credential_loader.py` ✏️（172 → 198）、`mindie_provider.py` ✏️（204 → 220）**：小修（MindIE 保守重试默认）。
- `models/__init__.py` ＝（未变）。

## 10.2 新增（4 文件）

| 文件 | 行 | 内容 |
|---|---|---|
| `assistant_payload_replay.py` ➕ | 94 | provider 专属 assistant 字段回放共享层（`restore_assistant_payloads`：位置匹配+assistant 计数 fallback） |
| `patched_mimo.py` ➕ | 112 | 小米 MiMo 补丁：捕获思考模式 reasoning_content 并在多轮工具调用历史回放（防 400） |
| `patched_stepfun.py` ➕ | 140 | StepFun 推理模型补丁：流式/非流式全路径捕获 reasoning/reasoning_content 回放 |
| `request_admission.py` ➕ | 102 | `RequestAdmission(BaseRateLimiter)`：有界 FIFO 准入（等距请求、无定时器驻留、可取消有截止） |
| `AGENTS.md` ➕ | 24 | 模型层文档 |


---

# 第 11 部分 persistence/

## 11.1 修改

- **`engine.py` ✏️（153 → 233）**：Postgres engine kwargs（pool_recycle/command_timeout）；`_ensure_postgres_schema` 自动建 schema。
- **`base.py` ✏️（28 → 38）**：`_column_keys(cls)` @cache 按类缓存 mapper 列 key（to_dict/repr 消除反射开销）；exclude 空快速路径。
- **`run/sql.py` ✏️（234 → 843）**：运行接管与租约（update_lease/renew_lease/claim_for_takeover/list_inflight_with_expired_lease/request_cancel/finalize_if_not_cancelled）；变更序列与增量拉取（_next_change_seq/list_changed）；线程级操作（delete_by_thread/get_many_by_thread/delete_thread_operation/create_thread_operation_atomic）；regenerate 溯源（list_successful_regenerate_sources/list_edit_regenerate_runs）；update_run_progress/update_model_name/stop_reason。
- **`run/model.py` ✏️（36 → 70）**：RunRow 新增列 operation_kind/idempotency_key/stop_reason/token_usage_by_model/owner_worker_id/lease_expires_at/cancel_action/cancel_requested_at/change_seq；5 个新索引（含部分唯一 uq_runs_thread_active——特意放 ORM 元数据覆盖空库 bootstrap 路径）；新增 RunChangeClockRow。
- **`thread_meta/` ✏️**：base（60→126）、memory（132→218）、model（16→18）、sql（195→376）、__init__（30→37）——新增 `claim_unowned`（无主线程认领）、`set_project`（线程-项目关联）、`update_owner`、`ThreadOwnershipConflictError`、search 项目过滤与元数据过滤校验。
- **`feedback/sql.py` ✏️（200 → 256）**：`delete_by_thread`（线程删除级联）、`list_by_run_ids`（单查询防 N+1）、`coerce_iso` 时区归一、确定性排序。
- **`user/model.py` ✏️（44 → 77）**：新增 `UserPreferenceRow`。
- **`migrations/env.py` ✏️（50 → 106）**：`include_object` 过滤（排除 LangGraph 自有表 + 扩展表前缀）；Postgres schema 钉定 search_path（否则 alembic_version 落 public）；SQLite PRAGMA busy_timeout=30000。
- **`models/run_event.py` ✏️（27 → 28）**：长度走常量；category 注释指向 events/catalog。
- **`models/__init__.py` ✏️（18 → 56）**：注册全部新表（AgentRow、channel_*、ManagedSubagentRow、McpTaskRow、PersonalAccessTokenRow、ProjectRow/ProjectDocumentRow、RunChangeClockRow、ScheduledTaskRow/RunRow、SubagentBatchRow/ItemRow、WebhookDeliveryRow、UserPreferenceRow）。
- `persistence/__init__.py` ＝、`feedback/model.py` ＝、`feedback/__init__.py` ＝、`run/__init__.py` ＝、`user/__init__.py` ＝、`migrations/alembic.ini` ＝。

## 11.2 新增实体存储（10 个域 + 基建）

| 目录/文件 | 行数 | 实体与要点 |
|---|---|---|
| `agents/`（base+file+sql+model+__init__）➕ | 115+235+34+223+86 | 用户自定义 agent 定义（(user_id,name) 唯一；config JSON + soul 文本）；FileAgentStore（temp+os.replace 原子）/SqlAgentStore（共享 agents 表） |
| `managed_subagents/` ➕ | 90+85+17+65+43 | 部署级托管子代理定义（管理员管理）；强制 disallow task 等工具 |
| `channel_connections/` ➕ | 102+499+19 | 用户 IM 渠道连接（连接/会话映射/凭据/OAuth state 四表）；ChannelCredentialCipher（Fernet）；活跃身份部分唯一索引 |
| `mcp_tasks/` ➕ | 74+699+3 | 持久 MCP 任务（远端 id、状态、结果预览/截断/工件、轮询退避、租约、事件指纹、通知 outbox、取消重试） |
| `personal_access_tokens/` ➕ | 23+115+4 | PAT（dfp_ 前缀 SHA-256 摘要、scopes、过期/撤销/最后使用） |
| `projects/` ➕ | 58+678+5 | ProjectRow + ProjectDocumentRow（内容寻址 stored_relpath、sha256、provenance、trashed_at/trash_origin） |
| `scheduled_tasks/` ➕ | 71+737+3 | 定时任务定义（schedule_type/spec、timezone、overlap_policy、next_run_at、租约、occurrence_seq） |
| `scheduled_task_runs/` ➕ | 47+813+28+8 | 出现记录（occurrence_seq/launch_accounted/attempt_count/租约、非终态唯一索引）；projection.py 父行锁下投影与一次性启动记账 |
| `subagent_batches/` ➕ | 62+555+3 | 持久批次（submission_key 幂等、并发/尝试上限、execution_spec）+ 批次条目（prompt、acceptance_criteria/verdict、租约、结果预览、token_usage） |
| `webhook_delivery/` ➕ | 28+4 | 跨 Pod webhook 去重（复合主键 channel+workspace+chat+message，first_seen 懒过期） |
| `user/preferences.py` ➕ | 19 | 用户偏好读写 |
| `bootstrap.py` ➕ | 597 | 混合 schema 引导：空库 create_all+stamp head / 旧库 stamp 0001+upgrade / 版本库 upgrade head；Postgres advisory lock 跨进程 + SQLite asyncio.Lock |
| `json_compat.py` ➕ | 186 | 方言感知 JSON 匹配谓词（键白名单防注入、int64 范围校验） |
| `postgres_schema.py` ➕ | 209 | search_path 钉定（asyncpg server_settings / psycopg libpq options 解析合并） |

## 11.3 数据库迁移（0001–0025，26 个文件，全新）

| 迁移 | 行 | 内容 |
|---|---|---|
| 0001_baseline | 261 | 基线链根（建 channel_connections、channel_oauth_states、feedback、run_events、runs、threads_meta、users、channel_conversations、channel_credentials） |
| 0002_runs_token_usage | 52 | runs 加 token_usage_by_model JSON（#3682） |
| 0003_scheduled_tasks | 83 | 建 scheduled_tasks + scheduled_task_runs |
| 0004_run_ownership | 116 | runs 加 owner_worker_id/lease_expires_at + ix_runs_lease + uq_runs_thread_active（先取消重复活跃行） |
| 0005_run_stop_reason | 18 | runs 加 stop_reason |
| 0006_agents | 41 | 建 agents 表 |
| 0007_scheduled_run_active_index | 116 | scheduled_task_runs 活跃唯一索引（重复行置 interrupted） |
| 0008_thread_operation_kind | 26 | runs 加 operation_kind |
| 0009_webhook_dedupe | 52 | 建 webhook_deliveries（#4120） |
| 0010_run_cancel_request | 26 | runs 加 cancel_action/cancel_requested_at |
| 0011_mcp_tasks | 63 | 建 mcp_tasks |
| 0012_mcp_task_results | 36 | mcp_tasks 加 result_preview/result_truncated/result_artifact |
| 0013_mcp_task_notifications | 75 | runs 加 idempotency_key（唯一）；mcp_tasks 事件指纹/outbox/取消重试列 |
| 0014_managed_subagents | 29 | 建 managed_subagents |
| 0015_scheduled_task_enqueue | 59 | scheduled_task_runs 加租约/attempt_count；overlap_policy skip→enqueue |
| 0016_subagent_batches | 86 | 建 subagent_batches + items |
| 0017_personal_access_tokens | 42 | 建 personal_access_tokens |
| 0018_oauth_identity_pg_partial | 57 | Postgres OAuth 唯一索引重建为部分索引（修 baseline 遗漏） |
| 0019_projects | 36 | 建 projects |
| 0019_thread_incarnations | 81 | threads_meta 加 incarnation；mcp_tasks 加 thread_incarnation（分支合并 revises 0021，可空 expand-only） |
| 0020_threads_meta_project_id | 26 | threads_meta 加 project_id + 索引 |
| 0021_batch_acceptance | 18 | batch_items 加 acceptance_criteria/acceptance_verdict |
| 0022_scheduled_occurrence_seq | 31 | occurrence_seq/launch_accounted + 唯一索引（幂等启动记账） |
| 0023_run_change_seq | 41 | runs 加 change_seq + run_change_clock 时钟表 |
| 0023_user_preferences | 20 | 建 user_preferences（与上行同号不同链，插入式迁移） |
| 0024_project_documents | 46 | 建 project_documents（Projects Phase 2 Slice B） |
| 0025_repair_run_change_seq | 58 | 修 #5516：已打过 0023_user_preferences 戳的库跳过了 run_change_seq，本迁移幂等重放补洞；downgrade 刻意 no-op |
| _helpers.py / _env_filters.py / script.py.mako / AGENTS.md ➕ | 154/131/21/144 | 幂等助手、alembic 表过滤、模板、迁移文档 |

---

# 第 12 部分 projects/（全新模块，1,220 行）

| 文件 | 行 | 内容 |
|---|---|---|
| `context.py` ➕ | 275 | `resolve_project_context()`（threads_meta.project_id → 项目行 → 书架快照，失败降级不 fail run）；`pinned_project_snapshot()`（读 PROJECT_CONTEXT_KEY）；`render_project_block()`（指令经 neutralize_untrusted_tags）；`render_documents_block()`（max_entries+max_bytes 双上限、溢出提示）；`build_project_context_message()`（瞬态请求消息：hide_from_ui+服务器标记+provenance）；`project_context_insertion_index()`（锚定本轮真实用户消息前，post-compaction 可重锚） |
| `documents.py` ➕ | 468 | `shelf_relpath()`（`{sha前2}/{sha}/{doc_id}` 内容寻址独占命名空间）；`stage_document_bytes()`（流式暂存+413）；`add_staged_document()`（file-before-row 事务；dedup 命中返回既有行）；`ensure_converted_markdown()`（首读惰性转换，行锁内 temp+os.replace）；`read_text_serving_path()`（derived/可转换/文本三路裁决）；`read_document_text_window()`（有界增量 UTF-8 窗口读 + LRU 字符数缓存）；`check_document_content()` |
| `tools.py` ➕ | 167 | `list_project_documents`/`read_project_document`（从钉住上下文取 project_id、live 查询；fail-closed 错误 JSON；分页 50/200、读窗 8000/20000） |
| `trash.py` ➕ | 288 | `restore_document()`（数据库 re-point；合并清理弃用命名空间）；`purge_all_trashed()`；`make_purge_file_remover()`（行锁内先删文件后删行）；`run_trash_retention_sweep()`（懒惰触发 + 网关启动一次；过期清除 + 存储对账（24h 孤儿守卫）+ 行对账（content_missing 只报告绝不删）） |
| `__init__.py` ➕ | 22 | 导出 |

---

# 第 13 部分 reflection/ ＝（未变，75 行）

仅新增 `AGENTS.md` ➕（3 行）。`resolvers.py` 与 `__init__.py` 完全未变。

---

# 第 14 部分 runtime/

## 14.1 修改

**`runs/manager.py` ✏️（212 → 2,202）**
1. 多 worker 所有权：RunRecord 大幅扩展（operation_kind/user_id/model_name/token 统计/owner_worker_id/lease_expires_at/ownership_lost/stop_reason/idempotency_key/start_lock/finalizing）；`worker_id`（hostname:uuid）；心跳任务（lease_seconds/3 周期续租，失败 `_mark_ownership_lost` fence 本 worker）；每 3 周期孤儿回收（单飞 + shutdown 有界 drain）。
2. 取消语义：`cancel()` 返回 `CancelOutcome` 七态（cancelled/requested/taken_over/lease_valid_elsewhere/not_cancellable/not_active_locally/unknown）；本 worker 走 durable cancel + 本地 abort；非本 worker 检查租约（过期 claim_for_takeover 接管标 error，未过期持久化取消请求）。
3. 原子准入：`_admit_thread_operation`（operation_kind + idempotency_key；`create_thread_operation_atomic` 依赖部分唯一索引；IntegrityError→ConflictError）；取消竞态 `_close_cancelled_admission` 补偿关闭。
4. 启动屏障 `try_start()`（pending→running CAS + per-run start_lock）；`fail_start_if_pending`。
5. 查询：store 回退水合 + user_id 过滤 + keyset 分页游标（before_created_at+before_run_id）；`list_successful_regenerate_sources`/`list_edit_replay_visibility`/`get_many_by_thread`；`_runs_by_thread` 二级索引。
6. 持久化健壮性：`PersistenceRetryPolicy` 有界重试；`set_status_if_not_cancelled` 经 `finalize_if_not_cancelled` 原子终态；`update_run_progress`/`update_finalizing_progress`；成功状态无法确认持久化时 `_mark_ownership_lost`（fail-closed）。
7. finalizing 屏障：`set_finalizing`/`wait_for_prior_finalizing`/`has_later_run`。
8. 优雅停机 `shutdown(timeout)`：先 signal、有界 drain、自行完成保留真实终态、未 settle 才标 interrupted、尾部持久化预算（#3373）。

**`runs/worker.py` ✏️（480 → 2,702）**
1. run 生命周期：流式前 wait_for_prior_finalizing + try_start；RunContext 扩展（mcp_task_repo/extensions/checkpoint 模式/on_run_completed/conversation_reader）。
2. extensions 接线：notify_task_start/stop（3s 超时）；extension 快照发布 runtime context（子任务绑定同代）；`_SERVER_OWNED_RUNTIME_CONTEXT_KEYS` 防伪造；`_pin_admission_project_context`。
3. Goal 自动续跑：`_prepare_goal_continuation_input`——首轮流完读线程 active goal、`evaluate_goal_completion`（LLM）、满足清除/不满足隐藏 continuation turn 继续；no-progress 熔断；human-input 卡暂停；GoalWriteConflict 双读防竞态。
4. 交付验证（#4272）：run 前 `capture_workspace_snapshot`；结束 `_produced_output_paths` 对比 outputs；`_delivery_content_with_outputs` 判定 present_files 覆盖；未交付标 error；`run.delivery` 回执 put_if_absent 幂等 + 有界重试；`record_workspace_changes`。
5. 子图命名空间：`_unpack_stream_item` 三元组；`_compose_sse_event` 生成 `mode|ns` 事件名（#4399）；`_SubagentEventBuffer`（#3779，25 条批量持久化）。
6. LLM 错误 fallback：`_extract_llm_error_fallback_message` → run 标 error。
7. checkpoint 回滚重构：`RollbackPoint`；delta 模式 `_linearize_delta_checkpoint_resume`（#4458）；`_rollback_to_pre_run_checkpoint` 经 `build_state_mutation_graph`；`_checkpoint_locks`（AsyncKeyedLockTable）。
8. run 历史元数据：`persist_run_history_metadata`/`persist_run_durations`（3 次乐观重试）；`_ensure_interrupted_title`。
9. 消息 seq 盖章 `_MessageSeqStamper`（#4666）。
10. 大文件工具分片 `_LargeFileToolChunkBatcher`（每 32 片合并发布）。
11. 性能治理：`_schedule_terminal_cycle_collection`（≤10s 一次循环 GC）；`_release_run_scoped_references`；`_create_contextless_task`；agent 构建 `run_assembly` off-loop（#5172）。
12. 流关闭确定性 `_close_agent_stream`；stop_reason 透传持久化；edit replay 失败回滚 + `_publish_restored_checkpoint_values`；trace 绑定；MCP 后台任务投影进 graph_input；CHECKPOINT_AGENT_NAME_METADATA_KEY。

**`runs/store/base.py` ✏️（81 → 424）**：新数据类型 EditReplayVisibility/LeaseRenewal/StatusFinalization/RunIdempotencyConflict；游标工具（(created_at, run_id) 全序 + Z 格式）；接口大扩容（put 新字段、get/list user_id+游标、list_changed、start_run CAS、update_run_progress、list_inflight、renew_lease、request_cancel、finalize_if_not_cancelled、claim_for_takeover、create_thread_operation_atomic、delete_thread_operation）；update_status 语义变 bool|None。

**`runs/store/memory.py` ✏️（84 → 526）**：实现全部新原语（二级索引、change_seq、cancel 字段、活跃 guard、两阶段 claim 模拟事务回滚、幂等冲突、per-model 聚合）。

**`journal.py` ✏️（332 → 1,163）**：caller 分桶 token 统计（lead/subagent/middleware + per-model + cache_read）；`record_external_llm_usage_records`（source_run_id 去重）；progress_reporter 节流（5s）；事件目录常量化；`_record_produced_artifacts`/`get_delivery_content`/`record_delivery`；`build_branch_history_seed_events`/`build_checkpoint_history_seed_events`；`_PendingLlmResponse` usage 回放合并；`_reconcile_final_tool_messages` 补账（#4666）；had_llm_error_fallback；`record_memory_context`（sha256 指纹）；`claim_tool_promotions`；`close(flush=...)` 显式释放。

**`events/store/base.py` ✏️（90 → 252）**：put_if_absent；find_latest_ai_message_run_ids（分页查找）；get_last_visible_ai_seq_by_run；get_message_seqs；list_events 增 task_id + after_seq；user_id 三态（AUTO/str/None）。

**`events/store/db.py` ✏️（262 → 520）**：Postgres advisory lock fence（`pg_advisory_xact_lock(hashtext(thread_id))`）序列化线程内 mutation；进程内 per-thread 锁（WeakValueDictionary + pin）；content_is_json/dict 双标记；coerce_iso；task_id SQL JSON 提取 LIMIT 前过滤。

**`events/store/jsonl.py` ✏️（160 → 403）**：线程锁 + 异步 IO（per-thread asyncio.Lock + shield 排干）；put_batch 按线程/run 分文件 + 失败回滚截断；全部新接口实现；validate_thread_id；物理换行切分。

**`user_context.py` ✏️（124 → 226）**：`resolve_config_user_id`/`resolve_runtime_user_id` 身份解析链（Agent Server → langgraph_auth_user → gateway context → ContextVar → DEFAULT）；make_safe_user_id 归一。

**`serialization.py` ✏️（64 → 124）**：Interrupt __slots__ 特判；保留 `__interrupt__`（#3595）；`strip_data_url_image_blocks` + `serialize_channel_values_for_api`（values/SSE 剥离 data: 图片块）。

**`checkpointer/provider.py` ✏️（140 → 220）**：统一 database 配置解析（legacy 优先）；Postgres schema；delta 模式 `_wrap_sync_if_delta`（CachedHistorySaver + MemoryCheckpointHistoryCache 单例）；线程安全双检锁（config 解析锁外防锁序反转）；reset 清缓存。

**`checkpointer/async_provider.py` ✏️（118 → 193）**：postgres 自建 AsyncConnectionPool（TCP keepalive、check_connection、autocommit、prepare_threshold=0、dict_row；DSN 注入 search_path 而非 options）；delta 包装（支持 redis 缓存）；sqlite 父目录 to_thread。

**`stream_bridge/base.py` ✏️（54 → 87）**：`StreamGap`/`StreamItem`；`supports_cross_process` 类属性；heartbeat_interval 构造校验。

**`stream_bridge/memory.py` ✏️（108 → 161）**：`_resolve_start_offset` O(1)（解析 `{ts}-{seq}`）；低于保留水位返回 StreamGap；`stream_exists`。

**`stream_bridge/async_provider.py` ✏️（39 → 78）**：Redis 桥落地（URL 解析顺序 config → env → 本机默认）；memory 桥透传 heartbeat。

**`runtime/__init__.py` ✏️（43 → 58）、`runs/__init__.py` ✏️（14 → 18）、`runs/schemas.py` ✏️（14 → 22）、`store/provider.py` ✏️（136 → 168）、`store/async_provider.py` ✏️（82 → 91）**：导出扩展；store 统一 database 配置解析 + Postgres schema + 双检锁。

**未变 ＝**：`converters.py`、`checkpointer/__init__.py`、`events/__init__.py`、`events/store/__init__.py`、`store/_sqlite_utils.py`、`store/__init__.py`、`runs/store/__init__.py`。

## 14.2 新增（runtime/）

| 文件 | 行 | 内容 |
|---|---|---|
| `checkpoint_mode.py` ➕ | 106 | full/delta 双模式安全：构建期冻结、写入盖戳、读取 fail-closed 门（Mismatch/Reconfiguration 错误）；delta 可读旧 full 单向迁移 |
| `checkpoint_state.py` ➕ | 175 | CheckpointStateAccessor（状态读写唯一咽喉）；build_state_mutation_graph（回滚/压缩的整体状态替换） |
| `context_compaction.py` ➕ | 193 | 手动线程上下文压缩（summarization + accessor；agent 绑定校验、内存 flush 门） |
| `context_keys.py` ➕ | 26 | 运行时私钥名集合（pre-run 消息 id、checkpoint agent 绑定、PROJECT_CONTEXT_KEY） |
| `goal.py` ➕ | 481 | 目标循环原语（state/evaluator、隐藏续跑 ≤8 次/2 次无进展；字符上限）；不引 FastAPI |
| `keyed_lock.py` ➕ | 125 | AsyncKeyedLockTable/KeyedLockTable（按键串行化 + 等待者感知回收、取消安全） |
| `secret_context.py` ➕ | 141 | 请求级秘密载体（config.context.secrets；仅激活技能 required-secrets 注入沙箱 env；#3861） |
| `stream_modes.py` ➕ | 35 | LangGraph 兼容流模式校验归一（7 种模式） |
| `events/catalog.py` ➕ | 97 | 持久 run 事件规范名/类别目录（公共 JSON 契约 CI 校验） |
| `events/message_identity.py` ➕ | 44 | 持久化消息稳定 UI 身份（ToolMessage 按 tool_call_id、`X__user` 折叠）+ MESSAGE_SEQ_KEY |
| `events/message_seq.py` ➕ | 39 | stamp_messages_with_seq（REST 读 checkpoint 批量盖 seq，#4666） |
| `runs/naming.py` ➕ | 12 | resolve_root_run_name（追踪命名） |
| `stream_bridge/redis.py` ➕ | 342 | Redis Streams 桥（XADD MAXLEN+TTL、XREAD BLOCK 批量 64、Last-Event-ID 重放、瞬态错误退避 3 次、可选依赖提示） |
| `checkpointer/cached_saver.py` ➕ | 266 | CachedHistorySaver（递归组装深度预算 8、稳态 ~2 层命中、prune/delete_thread 清缓存、统计） |
| `checkpoint_cache/{base,memory,provider,redis,__init__}.py` ➕ | 61+63+79+97+17 | checkpoint 历史缓存（不可变条目论证、部署身份哈希防键碰撞、Redis 故障降级全 miss） |
| `runtime/AGENTS.md` ➕ | 326 | 运行时架构文档 |

---

# 第 15 部分 sandbox/

## 15.1 修改

**`tools.py` ✏️（1,294 → 2,343）**
1. 全部工具（bash/ls/glob/grep/read_file/write_file/str_replace）新增异步版本 + `ensure_sandbox_initialized_async`。
2. RBAC 授权门 `sandbox_authorization_scope(_async)`（每次调用前 authorize("sandbox","execute")）；`_rollback_failed_sandbox_lookup`。
3. bash 请求级密钥注入：`mask_secret_values` 输出脱敏；GitHub/Lark CLI 环境按 runtime/channel 注入。
4. read_file 行范围分页（line_offset + 截断标记提示续读）；write_file 字节上限 + append。
5. 按用户过滤被禁用技能路径；host 路径掩码动态 root + 有界编译缓存。

**`middleware.py` ✏️（65 → 596）**：完整异步中间件（abefore_agent/aafter_agent/awrap_tool_call）；Agent 技能投影（不支持则 fail-closed）；沙箱保留/复用；网络访问审批流（ToolMessage/Command 回传）。

**`local/local_sandbox.py` ✏️（358 → 825）**：`_BoundedPipeCapture` 有界管道捕获（防内存撑爆）；POSIX/Windows 分离执行（超时杀进程组/树 + 后台化提示）；env 注入 + 墙钟超时；download_file；read_file 行范围；MSYS 路径转换排除；container→local 反查。

**`local/local_sandbox_provider.py` ✏️（101 → 513）**：全局单例 → per-(user_id,thread_id)（LRU 256 + 容量逐出）；技能投影目录构建（四类视图）；supports_agent_skill_isolation；reset/shutdown。

**`sandbox.py` ✏️（72 → 204）**：接口扩展（execute_command env、execute_command_in_scope/release_command_scope 作用域化持久 shell、read_file 行范围、download_file）。

**`sandbox_provider.py` ✏️（71 → 212）**：acquire 增 user_id；acquire_async、sync_agent_skills(_async)、reset；网络策略接口族。

**`exceptions.py` ✏️（49 → 103）**：`SandboxCapacityExceededError`（容量策略信息）、`SandboxAuthorizationError`。

**`search.py` ✏️（178 → 193）**：忽略模式性能优化（frozenset + 预编译 glob 正则）。

**`local/list_dir.py` ✏️（53 → 56）**：root 不存在从静默空列表 → raise FileNotFoundError。

**未变 ＝**：`file_operation_lock.py`、`security.py`、`__init__.py`、`local/__init__.py`。

## 15.2 新增（8 文件）

| 文件 | 行 | 内容 |
|---|---|---|
| `lease.py` ➕ | 616 | SandboxLeaseManager：跨实例执行租约（lead/subagent/Gateway/channel-upload 多持有者，最后释放） |
| `acquire_serialization.py` ➕ | 190 | AcquireSerializer：各 provider 共享的按键获取串行化（阻塞锁获取跑有界执行器，RFC #4741） |
| `identity.py` ➕ | 31 | derive_sandbox_scope_token（16 位 hex；兼容契约） |
| `env_policy.py` ➕ | 109 | 沙箱命令环境策略：擦洗 *KEY*/*SECRET*/*TOKEN*/*PASS*（含 ASKASS）再叠技能 secret（#3861） |
| `overwrite.py` ➕ | 16 | unwrap_sandbox：解包 fork 恢复的 Overwrite 通道值，标 fork_restored |
| `path_patterns.py` ➕ | 128 | 宿主→虚拟输出路径匹配单一实现（段边界+分隔符无关，防 #4035/#4053） |
| `remote_list_dir.py` ➕ | 81 | 远端 find|head 列目录契约（missing/traversal/SIGPIPE 三态） |
| `remote_search.py` ➕ | 79 | 远端 grep/glob 封装（完整性标记，防 127 当无匹配，#5376） |
| `AGENTS.md` ➕ | 100 | 沙箱架构文档 |

---

# 第 16 部分 scheduler/（全新模块）

- `schedules.py` ➕（57）：once/cron/interval 下次执行时间纯函数；MAX_INTERVAL_SECONDS（30 天）；validate_timezone；normalize_cron_expression（5 字段）；naive run_at 按任务时区墙钟解释转 UTC；cron 用 croniter 本地时区取下次转 UTC。
- `__init__.py` ➕（2）。

被 persistence/scheduled_tasks、app/scheduler/service.py、Gateway 路由消费；依赖 croniter。


---

# 第 17 部分 skills/

## 17.1 修改

- **`parser.py` ✏️（61 → 228）**：allowed-tools 规范化（别名 Bash/Read/Write/Edit→bash/read_file/write_file/str_replace；YAML 列表与参数作用域条目）；`parse_required_secrets`（required-secrets → SecretRequirement）；`parse_secrets_autonomous`；YAML 错误友好化。
- **`types.py` ✏️（51 → 73）**：SkillCategory 新增 INTEGRATION/LEGACY；frozen dataclass `SecretRequirement`；Skill frozen 化 + allowed_tools/required_secrets/secrets_autonomous 字段；容器路径走常量。
- **`validation.py` ✏️（68 → 76）**：frontmatter 解析外移 skills.frontmatter；`validate_skill_frontmatter_text`；description 非空校验；required-secrets list 校验。
- **`installer.py` ✏️（157 → 263）**：接入静态扫描（SkillSecurityScanError 携 findings）；归档 preflight；max_entries=4096；代码文件识别统一 package_files。
- **`security_scanner.py` ✏️（57 → 155）**：LLM 审查器融合静态 findings 上下文；fail_closed 可配置。
- **`storage/skill_storage.py` ✏️（198 → 261）**：基类新增 remove_custom_skill_file/validate_skill_file_path；符号链接技能目录兼容。
- **`storage/local_skill_storage.py` ✏️（161 → 226）**：写入/删除/切换触发投影重建（_skill_projection_mutation）。
- **`storage/__init__.py` ✏️（62 → 165）**：get_or_new_user_skill_storage 导出。
- **`__init__.py` ✏️（15 → 21）**：导出 SkillCatalog 与延迟发现构件。

## 17.2 新增（11 文件 + 2 子包）

| 文件 | 行 | 内容 |
|---|---|---|
| `catalog.py` ➕ | 140 | SkillCatalog：运行时延迟技能发现（agent 只见 `<skill_index>` 名称；字面意图排序；MAX_RESULTS=5） |
| `describe.py` ➕ | 145 | describe_skill 工具（闭包 catalog，返回结构化元数据） |
| `frontmatter.py` ➕ | 56 | SKILL.md frontmatter 共享解析（ALLOWED_FRONTMATTER_PROPERTIES 白名单 11 属性） |
| `package_files.py` ➕ | 33 | 技能包文件分类（代码后缀 + ELF/PE/Mach-O 魔数；安装器/导出/SkillScan 三方共用） |
| `package_paths.py` ➕ | 16 | evals/fixtures 路径识别与排除 |
| `permissions.py` ➕ | 26 | make_skill_tree_sandbox_readable（目录 0555/文件 0444 只读挂载） |
| `projection.py` ➕ | 746 | 沙箱技能投影：enabled-only 四类视图 + Agent 白名单交集视图、签名清单、原子替换、fcntl 读锁（Windows 降级） |
| `export.py` ➕ | 425 | 有界自定义技能导出（快照永不激活；4096 条/64MB/100MB 上限） |
| `slash.py` ➕ | 59 | /skill 斜杠命令解析（保留命令名集合前后端契约 fixture 双语固定） |
| `tool_policy.py` ➕ | 51 | allowed-tools 策略（ALWAYS_AVAILABLE 白名单：describe_skill/read_file/review_skill_package/tool_search） |
| `security_static_scanner.py` ➕ | 23 | SkillScan 兼容导出层 |
| `storage/user_scoped_skill_storage.py` ➕ | 370 | 用户作用域存储（`{base}/users/{user_id}/skills/custom/`；public 全局只读；legacy 只读回退；启用状态按用户 `_skill_states.json`） |
| `skillscan/models.py` ➕ | 42 | SecurityFinding TypedDict（7 类 rule_id 前缀）/ScanResult/RuleSpec/StaticScanBlockedError |
| `skillscan/orchestrator.py` ➕ | 1,055 | 38 条规则静态扫描：归档 preflight（穿越/ADS/symlink/魔数/嵌套 zip）；分层扫描器（secrets/declaration/python AST/shell/network）；约 500 行 HTTP client 句柄数据流分析（带预算作用域遍历消除误报）；CRITICAL 阻断 |
| `review/analyzer.py` ➕ | 344 | analyze_skill_package 主入口（嵌套 SKILL.md blocker、资源图、eval、SkillScan 聚合） |
| `review/resource_graph.py` ➕ | 101 | Markdown 链接/代码 span/路径 token → 节点边图（missing/escaping/unreferenced 发现） |
| `review/eval_schema.py` ➕ | 91 | 三种 eval 清单 schema 识别 |
| `review/readers.py` ➕ | 351 | LocalDirectoryReader/ArchivePackageReader/build_inline_snapshot（text/binary 二分 + sha256） |
| `review/models.py` ➕ | 105 | Severity 四级/findings 排序/稳定序列化 |
| `review/renderer.py` ➕ | 183 | review-report.v1（Readiness 三态/Assurance 四级/中英双语） |
| `review/digest.py` ➕ | 27 | compute_package_digest（长度前缀+排序 SHA-256） |
| `review/cli.py` ➕ | 63 | CI 门禁 CLI（--fail-on 等） |
| `review/__init__.py` / `skillscan/__init__.py` ➕ | 22/31 | 导出 |
| `AGENTS.md` ➕ | 34 | 技能系统文档 |

---

# 第 18 部分 subagents/

## 18.1 修改

- **`executor.py` ✏️（664 → 1,791）**：准入控制（SubagentExecutionCapacity.slot()，满则 FAILED+admission_failure）；SubagentResult 重构（线程安全 try_set_terminal、external_task_id、stop_reason、token_usage_records、tool_receipts 流式增量+终态收割、bash_executions 有界证据含真实退出码解析）；turn 预算 resolve_recursion_limit（middleware 链自适应换算；GraphRecursionError 恢复部分成果）；LLM fallback 识别；system prompt 拼装（report contract/验收指针注/技能索引/deferred 段/MCP 路由 hint；验收标准作不可信数据附 HumanMessage）；上下文传播（ContextVar 复制剥离 loop_bound 回调；身份/trace/`is_subagent`/沙箱租约/recorder 代理注入）；流处理 capture_new_step_messages 增量游标（#3779）；扩展 task 生命周期通知；执行入口 asyncio.wait_for + future 表 + 协程泄漏防护；_consume_guard_stop_reason。
- **`registry.py` ✏️（129 → 192）**：托管（managed）子代理第三层来源（1s 签名 TTL 缓存；冲突排除）；allowed_subagents caller 白名单参数。
- **`config.py` ✏️（43 → 53）**：system_prompt 可选（None）；max_turns 语义细化（turn=模型调用+工具执行，由 turn_budget 换算）；timeout 文档化。
- **`builtins/general_purpose.py` ✏️（43 → 60）**：max_turns 100→150；description 收紧为"有明确委托收益时"；system_prompt 新增 `<tool_restrictions>`（不调 task/不派子代理）与 `<file_editing_workflow>`（str_replace 优先/分节写 #3189）。
- **`__init__.py` ✏️（11 → 25）**：懒加载；导出 SubagentRuntime。
- `builtins/bash_agent.py` ＝（未变）、`builtins/__init__.py` ＝。

## 18.2 新增（12 文件）

| 文件 | 行 | 内容 |
|---|---|---|
| `acceptance_checks.py` ➕ | 1,636 | 验收清单确定性检查（RFC #4651 PR4）：file:<path> exists/non-empty、file_written、tests_passed:<cmd>（须锚定成功测试摘要形状的 bash 记录）；不可判定 UNVERIFIED |
| `report_contract.py` ➕ | 135 | 模型侧报告契约（[rN] 回执引用、可验证 handle、诚实申报失败）；验收标准不可信通道渲染（上限 20 条/500 字符） |
| `status_contract.py` ➕ | 298 | 后端↔前端结构化元数据契约（subagent_status/stop_reason/error/result_brief/result_sha256/model_name/token_usage/tool_receipts/receipt_verdict/acceptance_verdict；contracts JSON 双语固定） |
| `capacity.py` ➕ | 155 | SubagentExecutionCapacity：FIFO 准入（max_running/max_queued、queue\|reject） |
| `context_snapshot.py` ➕ | 104 | ParentContextSnapshot：不可变父会话快照（保留媒体块、排除 reasoning/工具块、防越权说明） |
| `runtime.py` ➕ | 126 | SubagentRuntime：显式运行时依赖（跨图共享容量、batch worker、配置快照） |
| `batch_runtime.py` ➕ | 37 | 进程内桥接（BatchSubmitRequest、SubagentBatchSubmitter Protocol、单例） |
| `batch_service.py` ➕ | 369 | SubagentBatchService：租约认领、执行、恢复持久批次条目 |
| `batch_acceptance.py` ➕ | 49 | 无父工具 runtime 时跑验收清单（借沙箱租约 + authz 重建上下文） |
| `step_events.py` ➕ | 225 | 子代理步骤载荷（task_running 流事件 + subagent.step 持久事件；每步 8192 字符） |
| `token_collector.py` ➕ | 73 | SubagentTokenCollector（caller=subagent:<name>；结束后转移父 journal） |
| `turn_budget.py` ➕ | 109 | max_turns → recursion_limit 换算（按链节点数；find_jumping_hooks 告警；修"150 turns 只买到 18 轮"） |
| `AGENTS.md` ➕ | 37 | 子代理架构文档 |

---

# 第 19 部分 tools/

## 19.1 修改

- **`tools.py` ✏️（145 → 188）**：签名新增 include_upload_tool/include_conversation_reader；BUILTIN_TOOLS 2→3（+review_skill_package）；条件追加 background/batch/list_uploaded_files 工具；`_ensure_sync_invocable_tool` 双检锁 sync wrapper；MCP 工具 tag_mcp_tool 打标（deferred 注册逻辑迁出至 agent 构建点）。
- **`builtins/task_tool.py` ✏️（257 → 1,125）**：返回 LangGraph Command（status_contract 结构化 ToolMessage）；acceptance_criteria 参数 + check_acceptance_criteria；verify_receipt_citations；context_mode isolated/snapshot；身份归因传播（user/role/oauth/run_id/trace 全传执行器）；SubagentTokenCollector 计量（增量+终态上报）；生命周期健壮化（execution_id 分离、recorder 代理回传父 loop、_finalize_interrupted_subagent shield 有界等待、_schedule_deferred_subagent_cleanup 挂进程级持久 loop、run_assembly 卸载）；allowed_subagents；max_turns 参数移除。
- **`builtins/tool_search.py` ✏️（151 → 270）**：架构重做（ContextVar 注册表 → 构建期闭包 catalog + graph state 提升）；DeferredToolCatalog（frozen，hash=schema sha256 前 16 位）；assemble_deferred_tools fail-closed；tool_search 返回 Command(update={"promoted":...})（catalog_hash 防漂移）；build_mcp_routing_middleware + hints 段。
- **`builtins/view_image_tool.py` ✏️（133 → 263）**：Command 更新；优先沙箱 download_file；state 只存元数据；`_read_verified_host_copy`（size+sha256 验证）恢复；异步版。
- **`builtins/setup_agent_tool.py` ✏️（57 → 81）**：agent_name 修复（防写坏全局默认配置）。
- **`builtins/clarification_tool.py` ✏️（46 → 80）**：fields 参数（结构化表单卡）；checkbox 默认 "no" 语义指导。
- **`builtins/invoke_acp_agent_tool.py` ✏️（202 → 223）**：asyncio.wait_for 超时（timeout_seconds 配置）；session_update 收紧（仅 agent_message_chunk）；阻塞操作 to_thread；mcode 专属错误指引。
- **`builtins/present_file_tool.py` ✏️（96 → 95）**：Runtime 统一别名；resolve_runtime_user_id。
- **`builtins/__init__.py` ✏️（12 → 25）**：导出 6 组新工具。
- **`skill_manage_tool.py` ✏️（208 → 259）**：锁 per-(user_id,name)；user storage；静态扫描层（StaticScanBlockedError/StaticScannerError）；remove_custom_skill_file 原子删除；按用户缓存刷新；sync wrapper 迁移。
- `tools/__init__.py` ＝（未变）。

## 19.2 新增（9 文件）

| 文件 | 行 | 内容 |
|---|---|---|
| `types.py` ➕ | 8 | `Runtime = ToolRuntime[dict, ThreadState]` 统一类型别名 |
| `sync.py` ➕ | 85 | 同步 agent 路径调用异步工具（共享线程池 _SYNC_TOOL_EXECUTOR） |
| `mcp_metadata.py` ➕ | 63 | MCP 工具元数据标签单一事实源（deerflow_mcp/routing/source） |
| `conversation.py` ➕ | 64 | read_conversation：宿主绑定可信能力分页读取会话（授权由宿主决定） |
| `builtins/background_tasks_tool.py` ➕ | 71 | 当前线程 MCP 后台任务自然语言管理（list/status/cancel） |
| `builtins/batch_task_tool.py` ➕ | 240 | batch_task：提交持久批条目（key/prompt/acceptance_criteria） |
| `builtins/list_uploaded_files_tool.py` ➕ | 239 | 历史上传按需发现（扩展名统计 + 文件大纲） |
| `builtins/review_skill_package_tool.py` ➕ | 159 | 非激活式技能包审查（双 profile、四种读取器、绝不激活/执行） |
| `builtins/update_agent_tool.py` ➕ | 223 | update_agent：自定义 agent 持久化自我 SOUL/config 更新（db 后端单事务） |
| `AGENTS.md` ➕ | 47 | 工具层文档 |

---

# 第 20 部分 tracing/

- `factory.py` ✏️（41 → 51）：LangSmith/Langfuse 构造小调整。
- `__init__.py` ✏️（2 → 9）：导出扩展。
- `metadata.py` ➕（94）：trace/run 元数据辅助（redact、注入）。
- `monocle.py` ➕（54）：Monocle OpenTelemetry 观测（可选 extra monocle_apptrace）。
- `AGENTS.md` ➕（16）。

---

# 第 21 部分 tui/（全新模块，16 文件 1,918 行）

| 文件 | 行 | 内容 |
|---|---|---|
| `cli.py` ➕ | 260 | LaunchPlan/plan_launch 纯决策（TTY/env/参数 → tui/print/json/headless-help）；build_parser（--tui/--tui-transparent/--cli/--print/--json/--continue/--resume/--recursion-limit；兼容 chat 前缀）；main 惰性导入 Textual |
| `app.py` ➕ | 669 | DeerFlowTUI(App)：slash 命令面板、模型/线程选择模态、/goal、中断、0.06s 合并重渲染、滚动保持、透明背景；agent 跑 worker 线程，call_from_thread 回 UI 线程 |
| `view_state.py` ➕ | 297 | 纯 reducer：ViewState + reduce() + 行类型 + 11 种动作；流式文本三分合并语义（累积/陈旧/真增量；空 id 按回合行下标路由） |
| `runtime.py` ➕ | 106 | translate(StreamEvent→action) + stream_actions（RunStarted…RunEnded 括号化） |
| `render.py` ➕ | 125 | Rich 纯渲染器（流式纯文本/历史 Markdown/工具卡片三态） |
| `command_registry.py` ➕ | 101 | 18 个内建命令 + 启用 skill 合并（尊重保留名）；前缀>子串>描述三级排序 |
| `session.py` ➕ | 82 | open_session：DeerFlowClient + checkpointer；resolve_thread/resolve_ref（id 或标题续接） |
| `persistence.py` ➕ | 87 | ThreadMetaWriter + _LoopThread：TUI 会话写共享 threads_meta（出现在 Web UI 侧栏） |
| `input_history.py` ➕ | 48 | 上限 200、连续去重、草稿暂存 |
| `message_format.py` ➕ | 87 | 工具活动友好化 |
| `theme.py` ➕ | 33 | Tokyo-Night 主题 + SYMBOLS |
| `widgets/composer.py` ➕ | 17 | 修正 Textual Input CJK 双宽字符光标偏移（IME 漂移） |
| `__init__.py`/`__main__.py`/`widgets/__init__.py` ➕ | 1/4/1 | 入口胶水 |
| `AGENTS.md` ➕ | 11 | TUI 文档 |

pyproject：`deerflow = "deerflow.tui.cli:main"`；extras `tui=["textual>=0.80"]`。

---

# 第 22 部分 uploads/

- `manager.py` ✏️（201 → 304）：上传目录按 user_id 隔离；staging 临时文件（.upload-*.part）与崩溃残留清理（cleanup_stale_upload_staging_files）；outputs 产物 URL/虚拟路径（output_artifact_url/output_virtual_path）；UTF-8 字节预算截断（_fit_utf8_bytes）；validate_upload_destination。
- `__init__.py` ✏️（28 → 36）：导出 staging 常量与清理函数。

---

# 第 23 部分 utils/

## 23.1 修改

- **`readability.py` ✏️（63 → 146）**：URL 感知提取（`_resolve_html_urls` + `_DestinationRewriter` 相对链接/图片绝对化）；extract_article 接受 url。
- **`file_conversion.py` ✏️（252 → 173，变小）**：outline 提取拆分到 file_outline.py；convert_file_to_markdown 新增 output_path。
- **`time.py` ✏️（63 → 79）**：coerce_iso（SQLite tzinfo 丢失归一）等。
- `network.py` ＝（未变）。

## 23.2 新增（9 文件）

| 文件 | 行 | 内容 |
|---|---|---|
| `assembly_io.py` ➕ | 100 | agent/工具组装专用卸载线程池（run_assembly；DEER_FLOW_ASSEMBLY_WORKERS 默认 8） |
| `file_io.py` ➕ | 65 | 文件系统专用卸载线程池（DEER_FLOW_FILE_IO_WORKERS；atexit 关闭） |
| `file_outline.py` ➕ | 176 | 文档大纲提取（粗体/分裂粗体标题正则、ReDoS 防护；上传中间件与 list_uploaded_files 共用） |
| `llm_text.py` ➕ | 50 | LLM 响应解析前归一（strip_think_blocks 完整/悬挂、strip_markdown_code_fence） |
| `messages.py` ➕ | 154 | ORIGINAL_USER_CONTENT_KEY/UNTRUSTED_INPUT_KEY/INJECTED_USER_MESSAGE_ID_SUFFIX 及剥离；message_content_to_text |
| `oneshot_llm.py` ➕ | 60 | 一次性非图谱 LLM 文本请求（run_oneshot_llm；润色/建议/标题共用） |
| `text_detection.py` ➕ | 34 | NULL 字节采样文本/二进制判定；浏览器可执行 MIME 判定 |
| `thread_id.py` ➕ | 26 | `^[A-Za-z0-9_-]{1,64}$` 校验单一实现（validate/resolve/Pydantic 注解） |
| `custom_events.py` ➕ | 43 | emit_custom_event（主走 writer、尽力 LangChain callback） |
| `AGENTS.md` ➕ | 2 | — |

---

# 第 24 部分 workspace_changes/（全新模块，6 文件 922 行）

| 文件 | 行 | 内容 |
|---|---|---|
| `types.py` ➕ | 93 | WorkspaceChangeLimits（max_files 200/max_scanned 2000/单 diff 256KB/总 1MB）、FileSnapshot（sha256/binary/sensitive/symlink）、Summary/Result |
| `scanner.py` ➕ | 331 | scan_workspace_roots（排除目录表 + extra 合入；符号链接绝不 follow 记元数据 stub；is_sensitive_workspace_path 11 种模式不读内容；大文件 text 落临时缓存） |
| `diff.py` ➕ | 193 | compare_snapshots（sha256 优先/size+mtime 兜底；symlink_created 独立状态；diff 字节预算截断）；get_changed_output_paths（交付校验） |
| `recorder.py` ➕ | 209 | capture_workspace_snapshot（shield + 孤儿缓存回收 + drain-then-cleanup 取消安全）；record_workspace_changes（二次扫描法 → event_store.put） |
| `api.py` ➕ | 63 | get_workspace_changes_response（API 投影：available/include_files/include_diff 裁剪） |
| `__init__.py` ➕ | 33 | 导出 |

---

# 第 25 部分 完全未变的 36 个文件清单

```
__init__.py（包根）
agents/lead_agent/__init__.py
agents/middlewares/__init__.py
community/aio_sandbox/__init__.py
community/ddg_search/__init__.py
community/exa/tools.py
community/image_search/__init__.py
config/agents_api_config.py
config/guardrails_config.py
config/runtime_paths.py
config/run_events_config.py
config/tool_config.py
config/token_usage_config.py
guardrails/__init__.py
models/__init__.py
persistence/__init__.py
persistence/feedback/model.py
persistence/feedback/__init__.py
persistence/migrations/alembic.ini
persistence/migrations/versions/.gitkeep
persistence/run/__init__.py
persistence/user/__init__.py
reflection/resolvers.py
reflection/__init__.py
runtime/converters.py
runtime/checkpointer/__init__.py
runtime/events/__init__.py
runtime/events/store/__init__.py
runtime/store/_sqlite_utils.py
runtime/store/__init__.py
sandbox/file_operation_lock.py
sandbox/security.py
sandbox/__init__.py
sandbox/local/__init__.py
subagents/builtins/__init__.py
tools/__init__.py
utils/network.py
```

---

# 第 26 部分 附录

## 26.1 打包/依赖变化（packages/harness/pyproject.toml）

**版本**：0.1.0 → 2.1.0。

**新增核心依赖**：
- `deerflow-extension-api==0.2.1`（精确锁版——扩展契约：宿主钉死实现的契约版本，扩展声明范围）
- `croniter>=6.0.0`（调度）
- `e2b-code-interpreter>=2.8.0`（E2B 沙箱）
- `cryptography>=50.0.0`（渠道凭据 Fernet 等）
- `beautifulsoup4>=4.12`、`html5lib>=1.1`（readability URL 重写）
- `langchain-openviking==0.1.0`（openviking 记忆后端）
- `tzdata>=2025.1`（DEER_FLOW_DATE_TIMEZONE 可移植性）
- `packaging>=24.2`

**版本收紧**：
- `langgraph>=1.2.9,<1.3`（配 checkpoint_patches.py 补丁）
- `langchain>=1.3`、`langgraph-runtime-inmem>=0.30.0`（Studio 预运行时持久修复验证）
- `langgraph-checkpoint-sqlite>=3.1.1,<3.2`
- `agent-sandbox>=0.0.19 → >=0.0.30`

**新增 [project.scripts]**：`deerflow = "deerflow.tui.cli:main"`。

**extras 3 → 14**：新增 tui（textual）、groundroute（空）、redis、boxlite、tenki、opensandbox、monocle、browser（playwright）、memory-zh（jieba）；postgres 版本更新。

## 26.2 行为契约变化速查（升级影响面）

| 领域 | 旧 | 新 |
|---|---|---|
| 部署 | LangGraph Server 独立进程（2024） | Gateway 内嵌运行时；langgraph.json 仅工具兼容 |
| 记忆注入 | system prompt 拼接 | DynamicContextMiddleware 请求级 system-reminder 或 tool 模式四工具 |
| 记忆存储 | 单 memory.json | 摘要 JSON + Markdown 分片（DOCUMENT_VERSION 2.0 自动迁移备份） |
| 记忆实现 | agents/memory 五文件单体 | MemoryManager 契约 + backends/*（manager_class 切换） |
| 摘要 | HumanMessage(name=summary) 回写 | summary_text 独立通道 |
| task 工具返回 | 裸字符串 | LangGraph Command + 结构化 ToolMessage（subagent_* 元数据） |
| RunManager.cancel | bool | CancelOutcome 七态 |
| task 的 max_turns | 工具参数 | 移除；配置/预算体系（recursion_limit 换算） |
| 上传注入 | `<uploaded_files>` 注入全部 | `<current_uploads>` 仅本轮（≤10）+ list_uploaded_files 工具 |
| viewed_images | state 存 base64 | 仅元数据按需读 |
| write_file | 覆盖 | 默认覆盖 + append + 字节上限 |
| list_dir | root 缺失静默空列表 | raise FileNotFoundError |
| title model_name=None | 用默认模型 | 本地 fallback 不调 LLM |
| summarization model_name=None | 用轻量模型 | 用运行模型 |
| 子代理上限 | max_concurrent=3 | 并发 + max_total_per_run + 进程容量 |
| SSE 子代理帧 | 冒充根图 | `mode\|ns` 命名空间事件名 |
| 事件类型 | 字符串散落 | events/catalog 目录（CI 契约校验） |
| 配置热重载 | 全部 | reload_boundary 登记基础设施字段需重启 |
| schema | 应用自建 | Alembic 0001–0025 + 启动自动升级 |
| checkpointer/store 配置 | checkpointer 段 | database 段统一（legacy 兼容优先） |
| 流桥 | 仅 memory | + redis（跨进程）；落后显式 StreamGap |

## 26.3 新增环境变量（部分）

`DEER_FLOW_TUI`、`DEER_FLOW_TUI_TRANSPARENT`、`DEER_FLOW_CHECKPOINT_CACHE_REDIS_URL`、`DEER_FLOW_STREAM_BRIDGE_REDIS_URL`、`DEER_FLOW_ASSEMBLY_WORKERS`、`DEER_FLOW_FILE_IO_WORKERS`、`DEER_FLOW_DATE_TIMEZONE`、`DEER_FLOW_LARK_CLI_SKILLS_ARCHIVE`、`DEER_FLOW_LARK_CLI_SANDBOX_RUNTIME_DIR`、`DEERFLOW_LARK_BROKER_URL/HOST/PORT/TIMEOUT/CLI/PYTHON/DENY_SUBCOMMANDS`、`MONOCLE_TRACING/MONOCLE_EXPORTERS/OKAHU_API_KEY`、`DEER_FLOW_EXTENSION_NAME/SOURCE`、`DEER_FLOW_IMAGE_DIGEST`、`DEER_FLOW_GIT_COMMIT`、`DEER_FLOW_ENV/ENVIRONMENT`、`DEERMEM_DATA_DIR`。

## 26.4 总体结论

- 413 个新增文件中：约 290 个为全新子系统的实现文件，约 60 个为 AGENTS.md/README 架构文档，约 63 个为 pydantic 配置模型与契约（config/ 26 + contracts）。
- 156 个修改文件中：24 个为重写级（行数翻倍以上，如 worker 5.6x、manager 10x、mcp/tools 8x、task_tool 4.4x、thread_state 9x）；其余为接口适配型修改（user_id 解析迁移、类型别名统一、to_thread 卸载等模式化变更）。
- 唯一的删除（agents/memory 五文件）是记忆后端化重构的自然结果，功能对应物全部存在于 `backends/deermem/deermem/core/` 并大幅增强。
- 贯穿性工程模式（新增代码中反复出现）：fail-closed/fail-open 显式成对、staging+os.replace 原子发布、`__` 前缀服务器拥有 context key、专用线程池卸载（file_io/assembly_io）+ 取消安全（shield/drain）、幂等原语（put_if_absent/idempotency_key/CAS）、确定性优先（纯函数 + byte 稳定序列化 + schema 版本化）、凭据永不进日志/描述符/prompt。
