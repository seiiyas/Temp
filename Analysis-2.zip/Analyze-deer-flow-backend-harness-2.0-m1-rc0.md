# 生产项目代码分析报告：deer-flow-backend `packages/harness/deerflow`

> 分析对象：`deer-flow-backend-2.0-m1-rc0/packages/harness/deerflow/`（下文简称 **deerflow 包**）
> 报告基线：195 个 Python 生产源文件 + 1 个 Alembic 配置（`persistence/migrations/alembic.ini`），约 2.6 万行代码
> 排除范围：`tests/`、`app/`（网关与渠道层，属仓库其他目录）、`docs/`、锁文件、`.github/.vscode` 等，均未纳入逐文件分析；`app/` 仅作为调用方在交叉验证中引用。

---

## 术语表（首次出现概念先读这里）

| 术语 | 解释 |
|---|---|
| **Harness（背带/承载框架）** | 本包的自称：不包含 HTTP 服务代码，而是承载 Agent 运行所需的全部可复用能力（模型、工具、沙箱、记忆、技能、持久化），供 LangGraph Server / FastAPI Gateway / 嵌入式客户端三方共用 |
| **Lead Agent（主代理）** | 面向用户的顶层 Agent，由 `make_lead_agent` 工厂按配置组装（模型+工具+19 段中间件+系统提示） |
| **Subagent（子代理）** | 由主代理通过 `task` 工具委派的下级 Agent（general-purpose / bash / 自定义），运行在隔离上下文，仅回传最终文本 |
| **ACP** | Agent Client Protocol，通过子进程方式调用外部 agent（如 codex-acp、claude_code）的协议 |
| **MCP** | Model Context Protocol，通过 stdio/http/sse 接入外部工具服务器 |
| **Middleware（中间件）** | LangChain `AgentMiddleware` 钩子（before/after_model、wrap_model/tool_call、before/after_agent），本包的全部横切能力都以此为载体 |
| **Sandbox（沙箱）** | Agent 执行 bash/文件操作的隔离环境；本地实现映射 `/mnt/user-data/*` 虚拟路径到宿主目录，容器实现（aio_sandbox）跑 Docker/远程 Pod |
| **Skill（技能）** | 一个目录 + `SKILL.md`（YAML frontmatter：name/description/license）的渐进式加载知识包，存于 `skills/public|custom` |
| **Run / Thread** | Run = 一次 agent 执行（pending→running→success/error/interrupted）；Thread = 一个会话（含消息历史与 checkpointer 状态） |
| **Checkpointer / Store** | LangGraph 的图状态持久化（InMemory/Sqlite/Postgres）与跨线程键值存储 |
| **StreamBridge** | Agent worker（生产者）与 SSE 端点（消费者）之间的事件桥，支持 Last-Event-ID 回放与心跳 |
| **虚拟路径** | 沙箱内统一路径前缀 `/mnt/user-data`（uploads/workspace/outputs）、`/mnt/skills`、`/mnt/acp-workspace` |
| **DeerFlowClient** | 嵌入式同步 Python 客户端（`client.py`），无需 HTTP 服务即可驱动整套 Agent |
| **deferred tools / tool_search** | MCP 工具延迟加载机制：schema 不进上下文，LLM 需先调 `tool_search` 检索并"晋升" |

## 分批输出策略（批次计划）

本包生产源文件 195 个（>40）、模块 17 个（>6），触发分批条件。本报告为**单文件交付**：下列各批次内容已按依赖方向（基础层→能力层→组装层→运行时层→入口与横切）**全部按序写入本文件**，章节编号全局连续，未重复分析。

| 批次 | 覆盖模块/目录 | 覆盖章节 | 涉及文件数 | 状态 |
|------|--------------|----------|-----------|------|
| 1 | 全局总览 | 第 1~3 章 + 第 5 章 + 本计划 | 全部（清单层） | 已完成（本文件） |
| 2 | 基础层：config / reflection / utils / uploads | 第 4 章（4.1~4.4） | 32 | 已完成（本文件） |
| 3 | 能力层：models+tracing / sandbox / community / mcp | 第 4 章（4.5~4.8） | 47 | 已完成（本文件） |
| 4 | 能力层：skills / tools / guardrails / subagents | 第 4 章（4.9~4.12） | 31 | 已完成（本文件） |
| 5 | 组装层：agents（核心+lead_agent+memory+middlewares） | 第 4 章（4.13~4.15） | 31 | 已完成（本文件） |
| 6 | 运行时层：persistence / runtime | 第 4 章（4.16~4.17） | 48 | 已完成（本文件） |
| 7 | 入口：client.py；深度与横切 | 第 6~10 章 + 收尾附录 | 2+ | 已完成（本文件） |

---

## 1. 项目概述

### 1.1 项目用途与业务背景

deerflow 包是 **DeerFlow 2.0**（一个开源深度研究/通用 AI Agent 平台，类似 OpenClode/Codex CLI 的服务端形态）的 **Agent 承载框架（harness）**。从代码与接口命名可归纳其业务定位：

- **对话式超级代理**：系统提示自述 "You are DeerFlow 2.0, an open-source super agent"（`agents/lead_agent/prompt.py:341` 起 `SYSTEM_PROMPT_TEMPLATE`），支持规划（TodoList）、澄清（ask_clarification）、引用规范、产物呈现（present_files）。
- **沙箱化执行**：Agent 可在本地映射目录或 Docker/远程容器中执行 bash、读写文件、跑代码（`sandbox/`、`community/aio_sandbox/`）。
- **多信息源检索**：内置 8 家搜索/抓取工具（DuckDuckGo、Exa、Firecrawl、InfoQuest、Jina、Serper、Tavily、图片搜索）（`community/`）。
- **长期记忆**：对话结束后经 LLM 抽取事实，按用户/代理维度持久化为 `memory.json`，下次会话注入系统提示（`agents/memory/`）。
- **技能系统**：SKILL.md 渐进式加载 + LLM 安全审查 + Agent 自助创建/修改技能（skill evolution）（`skills/`）。
- **多代理协作**：task 工具委派子代理（并发上限 3）、ACP 协议调用外部 agent 进程（`subagents/`、`tools/builtins/invoke_acp_agent_tool.py`）。
- **可运营性**：Run 生命周期管理与多任务策略（reject/interrupt/rollback）、SSE 流式推送、token 用量统计、运行事件落库（消息回放/审计）、用户数据隔离、反馈点赞（`runtime/`、`persistence/`）。

该包被仓库内两种上层消费（交叉验证，grep 证实）：
1. `app/gateway/`（FastAPI 网关，范围外）——`services.py` 调 `run_agent`/`make_lead_agent` 提供 HTTP/SSE API；
2. `langgraph.json`——把 `deerflow.agents:make_lead_agent` 注册为 LangGraph Server 的 graph。
3. `deerflow.client.DeerFlowClient`——进程内嵌入式调用（`client.py:80`）。

### 1.2 技术栈清单

| 类别 | 技术 | 版本约束（`packages/harness/pyproject.toml`） |
|---|---|---|
| 语言 | Python | `>=3.12`（用到 `StrEnum`、PEP 695 泛型、`datetime.UTC`） |
| 包管理/构建 | uv workspace + hatchling | 根 `pyproject.toml` `[tool.uv.workspace] members=["packages/harness"]`；包名 `deerflow-harness==0.1.0` |
| Agent 框架 | langchain / langgraph | `langchain>=1.2.15`、`langgraph>=1.1.9`、`langgraph-api/cli/runtime-inmem` |
| 模型接入 | langchain-openai/anthropic/deepseek/google-genai | 分别 >=1.2.1 / >=1.4.1 / >=1.0.1 / >=4.2.1；ollama 为可选依赖 |
| 数据校验 | pydantic | >=2.12.5（配置层全部 BaseModel） |
| 持久化 | SQLAlchemy 2 async + aiosqlite + asyncpg（可选） + alembic | `sqlalchemy[asyncio]>=2.0`；`langgraph-checkpoint-sqlite/postgres` |
| 协议 | agent-client-protocol（ACP）、langchain-mcp-adapters（MCP） | >=0.4.0 / >=0.2.2 |
| 沙箱 | agent-sandbox（AIO 容器 API 客户端）、kubernetes（依赖声明，供远程沙箱场景） | >=0.0.19 / >=30.0.0 |
| 观测 | langfuse（>=3.4.1）、tiktoken | LangSmith 经 langchain_core 内置 tracer |
| 文档转换 | markitdown[all,xlsx]、markdownify、readabilipy、pymupdf4llm（可选） | 上传文件→Markdown 管道 |
| 检索 SDK | tavily-python、firecrawl-py、exa-py、ddgs | 各搜索工具 |
| HTTP | httpx>=0.28.0、requests（aio_sandbox/infoquest 用） | |

### 1.3 如何运行

**运行前提**：项目根有 `config.yaml`（必需，含 `sandbox.use` 必填字段；仓库不自带，由 setup wizard 生成——`tests/test_setup_wizard.py:102` 佐证）与可选 `extensions_config.json`（MCP/技能开关）、`.env`（`config/app_config.py:32` import 时 `load_dotenv()`）。

三种运行形态（均以本包为核心）：

1. **FastAPI 网关**（仓库 `Makefile`）：`make dev` → `PYTHONPATH=. uv run uvicorn app.gateway.app:app --host 0.0.0.0 --port 8001 --reload`。网关 lifespan 中依次初始化 StreamBridge → SQLAlchemy 引擎 → checkpointer → store（`app/gateway/deps.py:55-67`，范围外，仅引用）。
2. **LangGraph Server**：根目录 `langgraph.json` 声明 `"graphs": {"lead_agent": "deerflow.agents:make_lead_agent"}`、`"checkpointer": ".../async_provider.py:make_checkpointer"`、`"auth": "./app/gateway/langgraph_auth.py:auth"`，`langgraph dev` 即起。
3. **嵌入式**：`from deerflow.client import DeerFlowClient; DeerFlowClient().chat("hello")`（`client.py:6-15` docstring）。

**配置解析优先级**（详见 4.1）：`config_path` 参数 → `DEER_FLOW_CONFIG_PATH` 环境变量 → 项目根 `config.yaml`（`DEER_FLOW_PROJECT_ROOT` 或 CWD）→ legacy 候选路径（`config/app_config.py:108-136`）。`get_app_config()` 带 mtime 热重载（`app_config.py:377-385`）。

---

## 2. 整体架构

### 2.1 架构风格与分层

整体是**分层 + 配置驱动插件化**的单体框架（无微服务），核心思想有三条：

1. **一切可插拔**：模型（`models:` 的 `use` 字段）、工具（`tools:` 的 `use`）、沙箱 Provider（`sandbox.use`）、技能存储（`skills.use`）、护栏 Provider（`guardrails.provider.use`）全部是 `"模块:类/变量"` 字符串，经 `reflection/resolvers.py` 动态 import（7 处生产调用点：models/factory.py:65、tools/tools.py:65、sandbox/sandbox_provider.py:56、skills/storage/__init__.py:35、mcp/tools.py:110、middlewares/tool_error_handling_middleware.py:107、app/channels/service.py:164）。
2. **能力以中间件为载体**：错误处理、护栏、审计、摘要、标题、记忆、循环检测等横切能力全部实现为 LangChain `AgentMiddleware` 钩子，按固定顺序串成链。
3. **读写分离的双态**：Agent 执行态走 LangGraph checkpointer；应用数据（runs/threads_meta/run_events/feedback/users）走独立 SQLAlchemy ORM（`persistence/__init__.py:1-9` 明确二者分离）。

```
                 ┌────────────────────────── 使用方（三种入口） ──────────────────────────┐
                 │ ① LangGraph Server (langgraph.json → deerflow.agents:make_lead_agent)│
                 │ ② FastAPI Gateway (app/gateway，范围外 → runtime.runs.run_agent)      │
                 │ ③ 嵌入式 DeerFlowClient (client.py，同步 stream/chat)                 │
                 └───────────────────────────────┬──────────────────────────────────────┘
                                                 │
┌────────────────────────────────────────────────▼─────────────────────────────────────────┐
│ 组装层 agents/                                                                            │
│  make_lead_agent(配置驱动, agent.py:318) / create_deerflow_agent(声明式, factory.py:61)     │
│   ├ 模型   models.create_chat_model（config.models[].use 反射 → ChatModel 实例）          │
│   ├ 工具   tools.get_available_tools（config 工具 + 内置 + MCP + ACP，按名去重）           │
│   ├ 提示   lead_agent/prompt.apply_prompt_template（记忆+技能+子代理+延迟工具+日期）        │
│   └ 中间件 middlewares/*（19 段链，见 4.14）                                                │
│  状态   thread_state.ThreadState（artifacts/viewed_images 带 reducer）                     │
├───────────────────────────────────────────────────────────────────────────────────────────┤
│ 能力层                                                                                     │
│  sandbox/      本地沙箱 + 7 个 @tool（bash/ls/glob/grep/read/write/str_replace）            │
│  community/    aio_sandbox 容器沙箱（Docker/远程 Pod）+ 8 家搜索抓取工具                    │
│  mcp/          MCP server 接入（会话缓存 + OAuth 令牌 + 工具转换）                          │
│  skills/       SKILL.md 解析/校验/LLM 安全扫描/安装/存储                                     │
│  subagents/    子代理配置/注册/执行引擎（隔离事件循环 + 后台任务表）                          │
│  tools/        工具聚合工厂 + 内置 7 工具（task/clarification/present/view_image/...）      │
│  guardrails/   工具调用前授权（Protocol + Allowlist 实现 + 中间件）                          │
├───────────────────────────────────────────────────────────────────────────────────────────┤
│ 运行时层 runtime/                                                                          │
│  runs/          RunManager（注册表+多任务策略） + run_agent worker（astream→SSE→回滚）      │
│  stream_bridge/ 事件桥（共享日志+Condition 扇出、Last-Event-ID 回放、心跳）                  │
│  journal.py     RunJournal 回调（LLM/工具事件 → RunEventStore，token 累计）                  │
│  events/store/  事件存储三实现（db / jsonl / memory）                                       │
│  checkpointer/ store/  LangGraph 状态持久化工厂（同步单例 / 异步 CM 两套）                   │
│  user_context.py ContextVar 用户三态解析（数据库属主过滤 + 文件分桶）                          │
│  serialization.py converters.py  LangGraph 对象 → JSON / OpenAI 线格式                      │
├───────────────────────────────────────────────────────────────────────────────────────────┤
│ 基础层                                                                                      │
│  config/        AppConfig 聚合根 + 20 余个子配置模块（单例五件套模式）                        │
│  models/+tracing/ 6 个 LLM Provider 定制 + 凭据加载 + LangSmith/Langfuse tracer             │
│  persistence/   SQLAlchemy async ORM（5 表）+ engine 生命周期 + alembic                      │
│  reflection/    resolve_class/resolve_variable（"模块:符号" 动态解析）                        │
│  utils/ uploads/  文档→Markdown 转换 / 端口分配 / 正文提取 / 时间格式 / 上传目录管理           │
└───────────────────────────────────────────────────────────────────────────────────────────┘
```

### 2.2 模块依赖关系（依赖方向自上而下）

```
client.py ─┬─> agents(lead_agent, thread_state) ─┬─> tools ─┬─> sandbox ─┬─> config
           ├─> runtime.checkpointer              │          ├─> mcp ─────┤
           ├─> skills.storage                    │          └─> community┤
           ├─> uploads / utils.file_conversion   │                       │
           └─> agents.memory(updater)            ├─> models ──> config / reflection / tracing
                                                ├─> middlewares ─> sandbox / guardrails / memory
                                                └─> subagents ──> executor ─> middlewares / skills
runtime.runs(worker) ─> agents(工厂经注入) + journal + stream_bridge + serialization + persistence(run)
app/gateway(范围外) ─> runtime.* 全家 + persistence.* + client 语义的各管理 API
```

要点：
- **循环依赖靠延迟 import 化解**是本包显著模式（`client.py:257`、`agents/lead_agent/agent.py:319-321`、`tools/builtins/task_tool.py:150`、`mcp/cache.py:71` 等均有注释 "Lazy import to avoid circular dependency"）。
- `agents/middlewares/tool_error_handling_middleware.py` 承担了**共享运行时链构建器**角色（`_build_runtime_middlewares`:70-126），lead 与 subagent 复用同一前缀。
- `config` 是被依赖最多的模块（约 60+ 文件引用 `get_app_config`）。

### 2.3 核心数据流：一次网关 SSE 对话（入口到出口）

1. HTTP POST 创建 run（`app/gateway/routers/thread_runs.py`，范围外）→ `services.py:253` `RunManager.create_or_reject`（内存注册表 + RunStore 落库，状态 `pending`）。
2. `services.py:295` 以 asyncio.Task 启动 `runtime/runs/worker.py:120 run_agent`；SSE 端点同时 `bridge.subscribe(run_id, last_event_id=...)` 挂起等待（`services.py:332`）。
3. `run_agent`：注入 runtime context（thread_id/run_id/app_config）→ 状态 `running` → 捕获 pre-run checkpoint 快照（供 rollback）→ 经 `agent_factory(config, app_config)` 即 `make_lead_agent` 构建 agent → 挂 checkpointer/store/RunJournal → `agent.astream(input, stream_mode=[...])`。
4. `make_lead_agent`（`agents/lead_agent/agent.py:318`）：解析运行时配置 → `create_chat_model` → `get_available_tools` → `apply_prompt_template` → `_build_middlewares`（19 段）→ `langchain.agents.create_agent(...)` 编译图。
5. 图执行循环：中间件 before_model（摘要/Todo/图片注入/悬空修补/延迟工具过滤）→ LLM 流式产出（`messages` 模式 token delta）→ after_model（标题/循环检测/子代理限流/token 归因）→ ToolNode（wrap_tool_call 链：审计→护栏→澄清→错误兜底→工具本体）→ 直至无 tool_calls。
6. 每个 chunk 经 `runtime/serialization.py serialize(mode=...)` → `bridge.publish(run_id, event, data)`；RunJournal 同步把消息/trace 缓冲进 RunEventStore。
7. 结束：`journal.flush()` 批量落库 → `update_run_completion` 写 token 统计 → 线程标题/状态同步 → `bridge.publish_end` → 延迟 60s `cleanup`。SSE 消费端收到 `__end__` 哨兵后关闭响应。

---

## 3. 目录结构详解

> 目录树仅展示纳入范围部分；`persistence/migrations/versions/`（仅 .gitkeep 占位）省略。

```
deerflow/
├── __init__.py            # 空文件（包标记）
├── client.py              # → 嵌入式 DeerFlowClient 门面（会话/配置/上传/记忆/技能管理 API）→ 1060 行
├── agents/                # → Agent 组装层 → 工厂、状态、主代理、记忆子系统、16 个中间件
│   ├── factory.py         #   create_deerflow_agent：声明式（RuntimeFeatures）工厂，14 段链
│   ├── features.py        #   RuntimeFeatures 特性开关 + @Next/@Prev 中间件定位装饰器
│   ├── thread_state.py    #   ThreadState（AgentState 扩展）+ artifacts/viewed_images reducer
│   ├── lead_agent/        #   agent.py(make_lead_agent 配置驱动工厂) + prompt.py(系统提示+技能缓存)
│   ├── memory/            #   记忆子系统：消息过滤/提示模板/防抖队列/文件存储/摘要钩子/LLM 更新器
│   └── middlewares/       #   16 个中间件 + __init__（空）+ 共享链构建器（tool_error_handling 内）
├── community/             # → 社区贡献集成（命名空间包，无顶层 __init__.py）
│   ├── aio_sandbox/       #   AIO 容器沙箱：AsyncSandbox + Provider(编排) + local/remote Backend
│   ├── ddg_search/ exa/ firecrawl/ image_search/ infoquest/ jina_ai/ serper/ tavily/
│   │                      #   8 家搜索/抓取工具，经 config tools[].use 动态加载
├── config/                # → 配置层：app_config 聚合根 + 24 个子配置/路径模块
├── guardrails/            # → 工具调用前授权：Protocol 抽象 + AllowlistProvider + 中间件
├── mcp/                   # → MCP 接入：client(参数转换) + tools(加载) + cache(会话缓存) + oauth
├── models/                # → LLM Provider：factory 路由 + 6 个定制 Provider + CLI 凭据加载
├── persistence/           # → 应用数据 ORM：engine + 5 表(run/thread_meta/run_event/feedback/user)
│   └── migrations/        #   alembic.ini + env.py（versions 目前为空，实际建表靠 create_all）
├── reflection/            # → resolve_class/resolve_variable："模块:符号" 动态解析
├── runtime/               # → 运行时层
│   ├── runs/              #   manager(注册表/状态机) + worker(run_agent 主循环) + store(抽象+内存)
│   ├── events/store/      #   RunEventStore 三实现（db/jsonl/memory）
│   ├── checkpointer/ store/   LangGraph 持久化工厂（同步单例 + 异步 CM）
│   ├── stream_bridge/     #   SSE 事件桥（抽象 + 内存实现 + 工厂）
│   ├── journal.py         #   RunJournal：LangChain 回调 → 结构化事件
│   ├── serialization.py converters.py user_context.py
├── sandbox/               # → 沙箱抽象与本地实现 + 7 个沙箱工具（tools.py 为包内最大文件）
│   └── local/             #   LocalSandbox（PathMapping 映射）+ Provider + list_dir
├── skills/                # → 技能体系：parser/validation/security_scanner/installer + storage
├── subagents/             # → 子代理：config/registry/executor(隔离事件循环) + builtins(2 个内置)
├── tools/                 # → 工具聚合：tools.py(get_available_tools) + skill_manage_tool + builtins/(7 内置)
├── tracing/               # → LangSmith/Langfuse callback 构造
├── uploads/               # → 上传目录管理（清洗/去重/防穿越/防符号链接）
└── utils/                 # → file_conversion(→Markdown) / network(端口分配) / readability / time
```

各目录职责速览（详见第 4 章逐模块展开）：

| 目录 | 职责 | 关键内容 |
|---|---|---|
| `agents/` | 把模型/工具/提示/中间件组装成可执行 LangGraph 图 | `make_lead_agent`（LangGraph Server 入口）、`create_deerflow_agent`（SDK 工厂）、`ThreadState` |
| `agents/middlewares/` | 16 个横切中间件 + 共享链构建器 | 错误处理/熔断、循环检测、摘要+技能拯救、记忆入队、标题、沙箱审计、澄清中断 |
| `agents/memory/` | 长期记忆读写全链路 | 防抖队列、mtime 缓存文件存储、LLM 事实抽取、2000 token 预算注入 |
| `community/` | 可插拔外部能力 | AIO 容器沙箱（Docker/远程）、8 家搜索抓取 |
| `config/` | 全部配置的加载/缓存/热重载/路径解析 | `AppConfig`、`Paths`（虚拟路径解析）、`ExtensionsConfig`（MCP/技能开关） |
| `guardrails/` | 工具调用授权 | OAP 对齐的 Decision/Reason、AllowlistProvider、fail-closed 中间件 |
| `mcp/` | MCP server 工具接入 | 会话缓存（mtime 失效）、client_credentials/refresh_token OAuth、异步工具补同步壳 |
| `models/` | LLM 接入 | 配置驱动反射路由、thinking 开关四级降级、Claude/Codex/MindIE/vLLM 定制 |
| `persistence/` | 应用数据持久化 | async engine（sqlite WAL/postgres 池）、5 表 ORM、4 个 Repository |
| `reflection/` | 插件化基石 | `resolve_variable("pkg.module:Attr", expected_type)` |
| `runtime/` | 服务端运行时 | run_agent worker、RunManager、StreamBridge、RunJournal、事件存储、用户上下文 |
| `sandbox/` | 执行环境抽象 | Sandbox 7 方法接口、LocalSandbox 路径映射、7 个沙箱工具、安全门控 |
| `skills/` | 技能全生命周期 | frontmatter 严格校验、LLM 安全扫描（fail-closed）、zip 安全解压、原子安装 |
| `subagents/` | 子代理引擎 | 注册表（内置+自定义+覆盖合并）、隔离事件循环执行器、后台任务表 |
| `tools/` | 工具聚合与内置工具 | `get_available_tools` 四来源聚合、task 委派、tool_search 晋升、skill_manage |
| `tracing/` | 可观测 | LangSmith tracer / Langfuse handler 构造 |
| `uploads/` | 上传文件管理 | 文件名去重算法、O_NOFOLLOW 防符号链接、虚拟路径/artifact URL |
| `utils/` | 通用工具 | 文档→Markdown 双转换器、线程安全端口分配器、Readability 正文提取、ISO 时间 |

---

## 4. 核心模块详解（报告主体）

> 依批次顺序：基础层（4.1~4.4）→ 能力层（4.5~4.12）→ 组装层（4.13~4.15）→ 运行时层（4.16~4.17）。行号引用基于实际源码。

### 4.1 模块：config/（配置层，25 文件）

**模块职责**：管理全部运行配置——`config.yaml`（AppConfig 聚合）、`extensions_config.json`（MCP/技能开关）、环境变量、数据目录布局与虚拟路径解析。是被依赖最广的模块（约 60+ 文件引用）。

**文件组成**：`app_config.py`（聚合根 455 行）、`paths.py`（338 行）、`extensions_config.py`（264 行）、`subagents_config.py`（188 行）、`tracing_config.py`（150 行）、`agents_config.py`（136 行）、`database_config.py`（103 行）、`sandbox_config.py`（84 行）、`memory_config.py`（84 行）、`summarization_config.py`（94 行）等 24 个子模块 + `__init__.py`（re-export 门面，import 即触发 `load_dotenv()`）。

**关键类/函数解析**：

- `AppConfig(BaseModel)`（`app_config.py:81-106`）——聚合根，字段：`log_level`、`token_usage`、`models: list[ModelConfig]`、**`sandbox: SandboxConfig`（唯一必填）**、`tools/tool_groups`、`skills/skill_evolution/extensions/tool_search`、`title/summarization/memory/agents_api`、`acp_agents`、`subagents/guardrails/circuit_breaker`、`database/run_events`、`checkpointer/stream_bridge`；`extra="allow"`。
  - `resolve_config_path`（:108-136）：config.yaml 查找优先级 = 参数 → `DEER_FLOW_CONFIG_PATH` → 项目根（`DEER_FLOW_PROJECT_ROOT` 或 CWD）→ legacy `{backend_dir}/{repo_root}` 候选 → 否则 `FileNotFoundError`。
  - `from_file`（:138-208）：`yaml.safe_load` → `config_version` 检查（对照 `config.example.yaml`，过旧仅 warning）→ `resolve_env_variables`（`$VAR` 占位符递归替换为 `os.getenv`，**未定义抛 ValueError**，:267-290）→ 数据库默认值注入 → 逐个刷新约 10 个子模块全局单例 → `ExtensionsConfig.from_file()` 单独加载注入 → `model_validate`。
  - 单例与热重载（:329-454）：`get_app_config()`（:357-386）优先级 = ContextVar 覆盖栈（`push/pop_current_app_config`，:439-454）→ 自定义实例（`set_app_config`）→ **mtime 变化即自动重载**（:377-385）；配套 `reload/reset`。
- `Paths`（`paths.py:62-312`）——数据目录与虚拟路径中枢。base_dir 解析：构造参数 → `DEER_FLOW_HOME` → `{project_root}/.deer-flow`（:113-121）。核心方法：
  - `thread_dir(thread_id, user_id=)`（:158-176）：用户级 `{base}/users/{uid}/threads/{tid}`，legacy 无用户 `{base}/threads/{tid}`。
  - `resolve_virtual_path`（:278-312）**防穿越三重机制**：① 前缀必须是段边界精确匹配（`/mnt/user-data` 不匹配 `/mnt/user-dataX`，:300-301）；② 拼接后 `resolve()`；③ `relative_to(base)` 失败即抛 "path traversal detected"（:307-310）。thread_id/user_id 另有 `^[A-Za-z0-9_\-]+$` 白名单（:11-12,20-31）。
  - `ensure_thread_dirs`（:247-267）：mkdir 后显式 `chmod(0o777)`（容器异 UID 可写）。
- `ExtensionsConfig`（`extensions_config.py:57-69`）：JSON 结构 `{"mcpServers": {...}, "skills": {"<name>": {"enabled": bool}}}`；`McpServerConfig`（:36-48）含 `type(stdio/sse/http)/command/args/env/url/headers/oauth`；`McpOAuthConfig`（:13-33）支持 client_credentials/refresh_token 两种 grant 及可配置的 token 响应字段名。`resolve_config_path`（:71-122）找不到时**返回 None（扩展可选）**；`resolve_env_variables`（:151-180）与 app_config 不同——未定义 `$VAR` 填空串不报错。**无 mtime 自动热重载**（只能显式 `reload_extensions_config`，:225-240）。
- `DatabaseConfig`（`database_config.py:40-102`）：`backend: memory|sqlite|postgres` 同时决定 checkpointer 与应用 ORM；派生 `sqlite_path = {sqlite_dir}/deerflow.db`（默认 `.deer-flow/data`）、`app_sqlalchemy_url`（sqlite → `sqlite+aiosqlite:///`；postgres 自动把 `postgresql://` 换成 `postgresql+asyncpg://`）。
- `ModelConfig`（`model_config.py:4-41`）：`name/use/model` 必填 + `supports_thinking/reasoning_effort/vision`、`when_thinking_enabled/disabled`（thinking 快捷字段会在 factory 深合并）；`extra="allow"` 使 yaml 中任意额外字段（api_key/base_url/max_tokens...）透传为构造参数。**注意：旧版 `BASIC_MODEL` 环境变量覆盖机制在 2.0 已移除**（全仓库大小写不敏感检索零匹配）；默认模型 = `models[0]`（`models/factory.py:60-61`）。
- `SkillsConfig`（`skills_config.py:16-72`）：`use`（默认 LocalSkillStorage）、`path` 四级解析（显式 → `DEER_FLOW_SKILLS_PATH` → `{project_root}/skills` → legacy）、`container_path="/mnt/skills"`。
- `TracingConfig`（`tracing_config.py:107-129`）：**唯一带双检锁的单例**；完全由环境变量驱动（`LANGSMITH_TRACING|LANGCHAIN_TRACING_V2`、`LANGFUSE_*` 等，truthy 集合 `1/true/yes/on`）；`enabled_providers` 要求开关+凭据齐全。

**设计模式**：约 10 个子模块采用"**单例五件套**"（`get_xxx / load_xxx_from_dict / reload_xxx / reset_xxx / set_xxx`），由 `AppConfig.from_file` 在加载时同步刷新——由此形成"AppConfig 组合字段"与"模块级全局单例"双通道（注入 mock 时二者可能短暂不一致，属已知权衡）。

**模块对外接口**：`get_app_config()/reload_app_config()/set_app_config()`、`get_paths()`、`get_extensions_config()`、`get_memory_config()`、`get_tracing_config()`、`get_acp_agents()`、`get_subagents_app_config()` 等。

### 4.2 模块：reflection/（动态解析，2 文件）

**职责**：插件化路由基石——把 `"module.path:AttrName"` 字符串解析为真实对象。
- `resolve_variable[T](variable_path, expected_type=None)`（`resolvers.py:25-70`）：`rsplit(":",1)` 拆模块/属性 → `import_module`（ImportError 时经 `MODULE_TO_PACKAGE_HINTS` 映射产出 `uv add X` 安装提示，:11-22）→ `getattr` → 可选 `isinstance` 校验。
- `resolve_class[T](class_path, base_class=None)`（:73-96）：委托 resolve_variable + `isinstance(x, type)` + `issubclass(x, base_class)` 双校验。
- 副作用：动态 import 任意配置指定的模块（受信配置面）。生产调用 7 处（见 2.1）。

### 4.3 模块：utils/（通用工具，4 文件，命名空间包）

- `file_conversion.py`（316 行）——上传文档 → Markdown。`CONVERTIBLE_EXTENSIONS={.pdf,.ppt,.pptx,.xls,.xlsx,.doc,.docx}`（:27-35）。**PDF 双转换器策略**：先 pymupdf4llm，`auto` 模式做稀疏检测（`chars/pages < 50` 判图片型 PDF，:50-77）回落 MarkItDown；PPT/Excel/Word 统一 MarkItDown（内部再依赖 python-pptx/openpyxl/python-docx）。`convert_file_to_markdown`（:138）对 >1MB 文件 `asyncio.to_thread` 卸载（:151-158），写同名 `.md`。`extract_outline`（:228-288）识别三种标题风格（`#` 标题 / SEC 式整行粗体 / 拆分粗体），上限 50 条。
- `network.py`（140 行）——**线程安全端口分配器**（非代理/UA 处理，实测无相关代码）。`PortAllocator.allocate`（:58）持锁扫描 + 试绑 `0.0.0.0`（刻意与 Docker 通配绑定一致防漏报，:47-56）；全局单例 `get_free_port/release_port`（:113/:133）。消费者：`community/aio_sandbox/local_backend.py:16`。
- `readability.py`（84 行）——HTML 正文提取。`ReadabilityExtractor.extract_article`（:59-83）首选 Readability.js（Node 子进程），失败回落纯 Python 解析；`Article.to_markdown`/`to_message`（多模态图片块）。**已知隐患**：类注解 `url: str` 从未赋值而 `to_message` 依赖 `self.url`（:14/:44），现调用方未触发。
- `time.py`（76 行）——`now_iso()`（UTC ISO8601）与 `coerce_iso(value)`（兼容历史 unix 秒：正则锚定 10 位数字防误改 ISO 年份片段，:22-27,49-75）。对齐 LangGraph Platform wire 格式。

### 4.4 模块：uploads/（上传管理，2 文件）

**职责**：线程级上传目录与文件安全操作，纯业务逻辑供 Gateway 与 Client 共用（`manager.py:1-5`）。
- 目录：`get_uploads_dir(thread_id)` = `Paths.sandbox_uploads_dir(thread_id, user_id=get_effective_user_id())`（`manager.py:40-44`）——按用户隔离。
- `normalize_filename`（:53-78）：剥目录成分 → 拒 `.`/`..`/反斜杠 → UTF-8 字节 ≤255。
- `claim_unique_filename(name, seen)`（:81-103）：**纯内存线性探测去重**——冲突时 `f"{stem}_{n}{suffix}"` 从 1 起（`a.pdf→a_1.pdf`），返回前入 seen。
- 防符号链接攻击（`open_upload_file_no_symlink`，:118-165）：背景是上传目录会挂进本地沙箱、沙箱进程可预埋符号链接诱使网关覆写目录外文件。实现：`os.lstat` 不跟随校验 → `O_NOFOLLOW` 打开（无此能力的平台直接拒绝）→ 打开后 `fstat` 复核**普通文件且硬链接数==1** → 同一 fd 上 ftruncate+写，消除 TOCTOU。
- `delete_file_safe`（:209-240）：resolve 校验后 unlink，可转换扩展名连带删除同名 `.md`。
- URL 构造：`upload_virtual_path` = `/mnt/user-data/uploads/{filename}`；`upload_artifact_url` = `/api/threads/{tid}/artifacts/mnt/user-data/uploads/{quote(filename)}`（:243-253）。

### 4.5 模块：models/ + tracing/（LLM 接入层，12 文件）

**模块职责**：按 config.yaml 声明动态构造 LangChain `BaseChatModel`，统一处理 thinking 开关、reasoning_effort、stream_usage、tracing 挂载，并为 5 类特殊后端提供定制 Provider。

**文件组成**：`factory.py`（路由核心 158 行）、`credential_loader.py`（CLI 凭据 220 行）、`claude_provider.py`（360 行）、`openai_codex_provider.py`（461 行）、`mindie_provider.py`（250 行）、`vllm_provider.py`（259 行）、`patched_deepseek.py`、`patched_minimax.py`、`patched_openai.py`、`__init__.py`（仅导出 `create_chat_model`）；`tracing/factory.py`（55 行）。

**关键函数解析——`create_chat_model(name=None, thinking_enabled=False, *, app_config=None, **kwargs)`（`factory.py:50`）**：

实现步骤（配置驱动路由，不做 provider 硬编码判断）：
1. `name is None` → 取 `config.models[0].name`（默认模型即列表第一项，:60-61）。
2. `model_class = resolve_class(model_config.use, BaseChatModel)`（:65）——选择 ChatOpenAI/ChatAnthropic 还是自定义 Provider **100% 由 yaml 的 `use` 字段决定**。
3. `model_dump(exclude_none, exclude={9 个元字段})`（:66-80）——因 `ModelConfig.extra="allow"`，yaml 的 api_key/base_url 等任意字段成为构造参数。
4. thinking 合并（:83-87）：`thinking` 快捷字段 ≡ `when_thinking_enabled["thinking"]`，深合并。
5. `thinking_enabled=True`：要求 `supports_thinking` 否则报错，然后应用 `when_thinking_enabled` 覆盖（:89-92）。
6. `thinking_enabled=False` 时**四级级联禁用**（:93-112）：显式 `when_thinking_disabled` → `extra_body.thinking.type` 存在则注入 `{"type":"disabled"}`+`reasoning_effort="minimal"`（OpenAI 兼容网关）→ `chat_template_kwargs` 含 thinking 键则禁用（vLLM/Qwen）→ 原生 `thinking={"type":"disabled"}`（Anthropic）。
7. 仅有的两处按类名特殊路由：Codex 剔除 `max_tokens` 并三态映射 `reasoning_effort`（:120-133）；MindIE 强制 `max_retries=1`（:137-139）。
8. `stream_usage` 默认 True（:34-47,146-148）；实例化后 `build_tracing_callbacks()` 挂到 `model.callbacks`（:152-156）。

**Provider 定制要点**（全部是**子类化**，无运行时 monkey-patch）：

| Provider | 基类 | 解决的问题 | 关键实现 |
|---|---|---|---|
| `ClaudeChatModel`（claude_provider.py:44） | ChatAnthropic | Claude Code OAuth 认证、prompt cache、thinking budget、限流重试 | `model_post_init` 判 `sk-ant-oat` 前缀走 OAuth（切换 `Authorization: Bearer` + anthropic-beta 头 + 禁用 cache）；`_apply_prompt_caching`（:192）对 system+最近消息+最后工具打 ≤4 个 ephemeral 断点；`_apply_thinking_budget`（:246）`budget_tokens=max_tokens*0.8`；429/500 指数退避重试（:292-341） |
| `CodexChatModel`（openai_codex_provider.py:61） | **直接实现 BaseChatModel** | 用 Codex CLI OAuth 调 ChatGPT 私有 Responses API | 构造期必须拿到 `~/.codex/auth.json`（:91-101）；`store:False, stream:True` 强制 SSE（:209-216）；`response.completed` 缺失时按 output_index 合并流式 items（:275-291）；reasoning summary → `additional_kwargs.reasoning_content` |
| `MindIEChatModel`（mindie_provider.py:162） | ChatOpenAI | 华为 MindIE 四个兼容性问题 | 消息扁平化 + tool_calls 序列化为 `<tool_call>` XML（:37-44）；流式+工具丢 choices → **有 tools 时 fallback 完整生成后按 15 字符/chunk 模拟流式**（:227-249） |
| `VllmChatModel`（vllm_provider.py:159） | ChatOpenAI | vLLM 0.19 要求 assistant reasoning 逐字回传 | 非流式/流式 delta/payload 三层保留 `reasoning` 字段（**完整重写** langchain_openai 私有 delta→chunk 转换，:94-147）；`chat_template_kwargs.thinking→enable_thinking` 规范化（:39-47） |
| `PatchedChatDeepSeek` / `PatchedChatMiniMax` / `PatchedChatOpenAI` | 各自官方类 | reasoning_content 多轮回传 / `<think>` 标签映射 / Gemini `thought_signature` 回传 | 共同模式：`_get_request_payload` 保留原始消息按位置 zip 回注 `additional_kwargs`（deepseek:34-71、openai:57-93）；MiniMax 强制 `extra_body.reasoning_split=True` 并复刻私有流式流水线（minimax:101-180） |

**凭据加载（credential_loader.py）**：Claude Code OAuth 优先级 = `$CLAUDE_CODE_OAUTH_TOKEN`/`$ANTHROPIC_AUTH_TOKEN` → FD 读取（`$CLAUDE_CODE_OAUTH_TOKEN_FILE_DESCRIPTOR`）→ `$CLAUDE_CODE_CREDENTIALS_PATH` → `~/.claude/.credentials.json`（:150-193）；过期令牌（1 分钟提前量，:43-47）丢弃。config.yaml 的 `api_key: $VAR` 由 AppConfig 展开后**优先于** OAuth 链（claude_provider.py:82-96）。

**tracing/factory.py**：`build_tracing_callbacks()`（:32）按 `enabled_providers`（开关+凭据齐全）构造 LangSmith `LangChainTracer` / Langfuse（先建 `Langfuse(...)` 全局单例再挂 callback，:24-29），构造失败包装 RuntimeError。

**模块对外接口**：`from deerflow.models import create_chat_model`（7 个生产调用点：lead_agent/agent.py:22、client.py:42、subagents/executor.py、memory/updater.py、title_middleware.py、skills/security_scanner.py 等）。

### 4.6 模块：sandbox/（沙箱抽象+本地实现+7 工具，13 文件）

**模块职责**：Agent 执行环境的抽象接口、本地实现、安全门控与暴露给 LLM 的 7 个文件/命令工具。

**文件组成**：`sandbox.py`（抽象接口 94 行）、`sandbox_provider.py`（Provider 接口+单例工厂 99 行）、`tools.py`（**包内最大文件 1583 行**）、`security.py`（能力门控）、`search.py`（glob/grep 引擎）、`middleware.py`（生命周期）、`file_operation_lock.py`、`exceptions.py`、`local/`（4 文件）。

**架构三层**：
- **抽象层**：`Sandbox(ABC)` 定义 7 个操作（`sandbox.py:18-93`）：`execute_command / read_file / list_dir / write_file / glob / grep / update_file`（glob/grep 返回 `(results, truncated)`）。`SandboxProvider(ABC)`（sandbox_provider.py:8-38）提供 `acquire(thread_id)→sandbox_id / get / release`；`get_sandbox_provider()`（:44-58）按 `config.sandbox.use` 反射实例化（单例）。
- **实现层**（local）：`LocalSandbox`（local_sandbox.py:29）以 `PathMapping(container_path, local_path, read_only)` 列表把容器路径映射到宿主。防穿越：命中 mapping 后拼 `local_root/relative` 再 `resolve()+relative_to` 校验，逃逸抛 `PermissionError`（:133-139）；未命中映射的路径**原样透传**（访问面收窄由工具层 `validate_local_tool_path` 完成）。命令执行 `subprocess.run(shell=False, timeout=600)`，按平台选 zsh→bash→sh→pwsh/cmd（:274-333）；输出中的宿主路径反译回容器路径（符号翻译双向，:174-247）；读文件仅对 `_agent_written_paths` 中的文件反译（PR #1935）。`LocalSandboxProvider` 以模块级单例提供 id 恒为 `"local"` 的沙箱；skills 恒只读挂载（local_sandbox_provider.py:33-48），自定义挂载校验保留前缀冲突（:51-95）。
- **工具层**（`tools.py`）：7 个 `@tool`——`bash`(:1224)、`ls`(:1273)、`glob`(:1320)、`grep`(:1370)、`read_file`(:1440)、`write_file`(:1495)、`str_replace`(:1535)。统一前置流程：`ensure_sandbox_initialized`（:1051-1107，state 复用→context.acquire→写 state+context）→ `ensure_thread_directories_exist`（:1110-1144，仅本地沙箱首调 mkdir 三目录）→ 本地沙箱专属：`validate_local_tool_path`（:585-636，白名单 `/mnt/user-data/*`(读写)、`/mnt/skills/*`、`/mnt/acp-workspace/*`(只读)、自定义挂载；拒 `..`）→ 解析宿主路径 → 执行 → `mask_local_paths_in_output` 脱敏回掩（:502-573）。

**bash 命令本地安全链**（`tools.py:1236-1269`）：`is_host_bash_allowed()` 门槛（**本地 Provider 默认禁 host bash**，security.py:35-45）→ `validate_local_bash_command_paths`（:891-930：拦截 `file://`、shlex 分词后拦 `..`、`cd/pushd` 目标白名单、16 个命令的裸 `/` 参数拒绝、绝对路径白名单=挂载+MCP allowed+系统前缀；自述 best-effort 非安全边界）→ `replace_virtual_paths_in_command`（虚拟→宿主）→ `cd workspace &&` 前缀锚定 → 执行。

**输出截断策略**（:1147-1220）：bash **中间截断**（头尾各 50%，stderr 顺序不定）；read_file/ls **头部截断**（附标记引导 start_line/更精确路径）；glob/grep 条目数截断（默认 200/100，上限 1000/500）。配置来自 `sandbox.bash_output_max_chars`（默认 20000）等三项。

**其余文件**：`search.py`（211 行）为 os.walk 剪枝式 glob/grep（49 个忽略模式、1MB/二进制/超 2000 字符行过滤、**ReDoS 与符号链接防穿越**：resolve 后 `is_relative_to(root)`，:167-189）；`file_operation_lock.py` 为 `(sandbox_id, path)` 粒度 WeakValueDictionary 锁（写文件/str_replace 持锁，防读改写竞态）；`middleware.py` 的 `SandboxMiddleware` 默认 `lazy_init=True`（before_agent 不获取，实际获取延迟到工具首调），`after_agent` 释放 sandbox_id（沙箱跨 turn 复用，容器清理在关机 `shutdown()`）。

**模块对外接口**：`get_sandbox_provider`、`Sandbox/SandboxProvider`、7 个工具（经 `config.tools[].use: deerflow.sandbox.tools:bash_tool` 等装载）、`is_host_bash_allowed`、`mask_local_paths_in_output`、`validate_local_tool_path`（被 view_image_tool 复用）。

### 4.7 模块：community/（社区集成，20 文件）

**模块职责**：两块——① `aio_sandbox/`：基于 agent-infra AIO 容器镜像的沙箱实现（Provider/Backend 分层）；② 8 家搜索/抓取工具包。命名空间包（无顶层 `__init__.py`），全部经 config `use` 字符串动态加载。

**aio_sandbox 体系**（7 文件）：
- `AioSandbox(Sandbox)`（aio_sandbox.py:17）：对容器 HTTP API 的封装；**`threading.Lock` 串行化所有 shell 命令**（容器内单一持久 shell 会话，防并发打坏，issue #1433）；`no_change_timeout=600` 避免容器 120s 无输出超时误杀长命令；`update_file` 走 base64（:225-237）。
- `SandboxBackend(ABC)`（backend.py:38）：`create/destroy/is_alive/discover` 四方法 + `wait_for_sandbox_ready`（每秒轮询 `GET /v1/sandbox`）。
- `LocalContainerBackend`（local_backend.py:172，619 行）：**subprocess 调 docker/container CLI**（非 SDK）；macOS 优先探测 Apple Container（:215-240）；端口冲突最多 10 次重试（:268-291）；容器名冲突时 `discover` 收养；Docker 用 `--mount type=bind` 规避 Windows 盘符歧义（:70-87）+ `seccomp=unconfined`（:507-508）；`list_running` 仅 2 次 subprocess 批量枚举（孤儿对账用）。
- `RemoteSandboxBackend`（remote_backend.py:30）：**Pod 生命周期全部委托外部 provisioner HTTP 服务**（POST/DELETE/GET `/api/sandboxes`），沙箱 URL 形如 `http://k3s:{NodePort}`；extra_mounts 被忽略。
- `AioSandboxProvider`（aio_sandbox_provider.py:69，708 行）——**编排层**：三层获取（进程内缓存 → warm pool（release 不销毁容器，保温复用）→ 跨进程文件锁内 discover-or-create）；`sandbox_id = sha256(thread_id)[:8]` 确定性命名（任何进程可推出同一容器名）；孤儿对账（启动时收养同前缀容器进 warm pool，:194-235）；idle checker 守护线程（默认 600s 回收，销毁前锁内二次确认）；replicas 软上限（默认 3，超限先逐 warm，全 active 时仅告警仍创建）；注册 SIGTERM/SIGINT/SIGHUP + atexit 优雅关停；挂载计算（workspace/uploads/outputs 读写 + acp-workspace 只读 + skills 只读）。

**搜索工具**（13 文件）——统一约定：`web_search`/`web_fetch`/`image_search` 共享工具名（互斥配置选用一家）；结果归一化 `{title, url, snippet}` 或 Markdown `# 标题\n\n正文[:4096]`；**错误一律返回 `"Error: ..."` 字符串不抛异常**：

| 工具包 | 凭据来源 | 特点 |
|---|---|---|
| ddg_search（tools.py:55） | 无需 key | `ddgs` SDK，max_results 可被 config 覆盖 |
| image_search（tools.py:77） | 无需 key | DuckDuckGo 图片，定位"生成参考图检索"，附 usage_hint |
| serper（tools.py:32） | config `api_key` **优先** → env `SERPER_API_KEY` | httpx POST `google.serper.dev/search`，回退链最完整 |
| tavily（tools.py:17） | config `web_search.api_key` | search + extract 两个工具 |
| exa（tools.py:17/56） | config 工具配置 `api_key` | search（highlights 可配长度）+ get_contents fetch |
| firecrawl（tools.py:17/49） | config 工具配置 `api_key` | `scrape(formats=["markdown"])` |
| jina_ai（tools.py:12） | env `JINA_API_KEY`（**可选**，免费可用） | 全 community **唯一 async 工具**；Readability 抽取放 `asyncio.to_thread` |
| infoquest（infoquest_client.py:17） | env `INFOQUEST_API_KEY` | BytePlus 三端点（reader/search/image），独立 404 行同步客户端；web_fetch 后本地 Readability 抽取 |

### 4.8 模块：mcp/（MCP 接入，5 文件）

**模块职责**：把 `extensions_config.json` 中启用的 MCP server 工具加载为 LangChain 工具，含会话缓存、OAuth 令牌管理与异步工具补壳。

- `client.py`：`build_server_params`（:11）/`build_servers_config`（:45）——McpServerConfig → MultiServerMCPClient 参数（stdio 需 command；sse/http 需 url）；单 server 失败仅告警不中断。
- `tools.py`：`get_mcp_tools()`（:57-135）——**每次从磁盘重读 `ExtensionsConfig.from_file()`**（Gateway 是独立进程，注释 :69-72）；对 sse/http server 注入 OAuth 初始头（连接/发现阶段）；装配拦截器（内建 OAuth + `mcpInterceptors` 扩展字段自定义构建器，经 `resolve_variable`）；`MultiServerMCPClient(..., tool_name_prefix=True).get_tools()` 完成协议握手与封装；对纯异步工具用全局 `ThreadPoolExecutor(10)` 补 `tool.func` 同步壳（:26-54，deerflow client 以同步方式调工具）。
- `cache.py`：进程级缓存 `_mcp_tools_cache` + `asyncio.Lock` + **config mtime 失效检测**（:31-53，让独立进程改 `extensions_config.json` 后可感知）。难点是同步函数里跑 async 初始化（:82-130）：循环运行中→线程池 `asyncio.run`；有循环未运行→`run_until_complete`；无循环→直接 `asyncio.run`。
- `oauth.py`：`OAuthTokenManager`——per-server `asyncio.Lock` 双检缓存令牌，`expires_at <= now+60s` 提前刷新（:67-70）；表单 POST token_url（client_credentials 需 id+secret；refresh_token 需 token）；响应字段名全可配（token_field/expires_in_field 等）；`build_oauth_tool_interceptor`（:122）把 `Authorization` 头注入**每次工具调用**。

### 4.9 模块：skills/（技能体系，9 文件）

**模块职责**：SKILL.md 的解析、协议校验、LLM 安全审查、zip 安装与存储抽象。

**文件组成**：`types.py`（`Skill` dataclass + `SkillCategory(public/custom)`）、`parser.py`（宽松解析）、`validation.py`（严格校验）、`security_scanner.py`（LLM 审查）、`installer.py`（zip 安装共享逻辑）、`storage/skill_storage.py`（抽象基类+模板流程）、`storage/local_skill_storage.py`（本地实现）、`storage/__init__.py`（反射单例工厂）。

**关键机制**：
- **解析 vs 校验双轨**：`parse_skill_file`（parser.py:12）服务运行时加载——正则抽 frontmatter、`yaml.safe_load`、只要求 name/description 非空，失败返回 None 不抛；`_validate_skill_frontmatter`（validation.py:17）服务安装/创建——**未知 key 直接拒绝**（白名单 8 个：name/description/license/allowed-tools/metadata/compatibility/version/author）、name 必须 hyphen-case `^[a-z0-9-]+$` 且 ≤64 字符、description **禁尖括号**（防注入）且 ≤1024。
- **LLM 安全扫描（fail-closed）**：`scan_skill_content`（security_scanner.py:40）判定封锁"提示注入/系统角色覆写/提权/数据外泄/不安全可执行代码"，边界外部 API 引用仅 warn；要求严格 JSON `{decision, reason}`；**模型调用异常或不可解析一律 fallback 为 block**（:65-70）。模型用 `skill_evolution.moderation_model_name` 或默认模型，`run_name="security_agent"`。
- **zip 安装防御**（installer.py）：`is_unsafe_zip_member`（:32-47）拒绝对对路径/盘符/`..`；符号链接条目跳过；resolve+`is_relative_to` 二次验证；**64KB 流式写 + 512MB 总量上限防 zip 炸弹**（:116-121）。扫描范围：根 SKILL.md 必扫 + `scripts/` 下全部（按可执行）+ `references|templates` 白名单文本；**可执行文件必须 allow（warn 也不行）**（:169-170）。原子落位：`mkdir(0o700)` 抢占目录名 → 已存在抛 `SkillAlreadyExistsError` → 失败 `finally rmtree` 回滚（:134-147）。
- **存储抽象**（skill_storage.py）：模板方法模式——抽象 `_iter_skill_files/read_custom_skill/write_custom_skill/ainstall_skill_from_archive/delete_custom_skill` 等；具体 `load_skills`（:212-246）遍历→解析→按名去重→**每次重读 extensions 配置合并 enabled**（跨进程即时一致）→排序。路径协议：`<root>/public|custom/<name>/SKILL.md`、历史 `<root>/custom/.history/<name>.jsonl`；`ensure_safe_support_path`（:79-99）限辅助文件于 4 个子目录且 resolve 后不得逃逸。
- `LocalSkillStorage`：`write_custom_skill` 同目录临时文件 `replace` 原子写（:81-92）；删除前旧内容追加进 history（只读错误仅告警不阻断，:165-172）。**无索引缓存**（每次全量 walk，缓存职责在消费侧 `lead_agent/prompt.py`，见 4.13）。
- 工厂 `get_or_new_skill_storage`（storage/__init__.py:15-68）：传 skills_path/app_config 时每次新建；否则按 AppConfig 对象身份变化重建的单例；实现类经 `resolve_class(skills_config.use, SkillStorage)`。

**模块对外接口**：`get_or_new_skill_storage()`、`LocalSkillStorage/SkillStorage`、`Skill/SkillCategory`、`scan_skill_content`、`SkillAlreadyExistsError/SkillSecurityScanError`。

### 4.10 模块：tools/（工具聚合+内置工具，11 文件）

**模块职责**：产出最终绑定给 LLM 的 `list[BaseTool]`，并提供 7 个内置工具与技能自助管理工具。

**`get_available_tools(groups=None, include_mcp=True, model_name=None, subagent_enabled=False, *, app_config=None)`（tools.py:36-175）四来源聚合**：

| 来源（优先级从高到低） | 注入条件 |
|---|---|
| ① config 工具（含 7 个沙箱工具，经 `use` 反射加载） | `config.tools` + `groups` 过滤 + **host-bash 安全过滤**（`is_host_bash_allowed()` 为 False 时剔除 bash 面，:62-63）；配置名 ≠ 工具 `.name` 告警（issue #1803，:71-78） |
| ② 内置工具 | `present_files`+`ask_clarification` 恒注入；`skill_manage` 需 `skill_evolution.enabled`；`task` 需 `subagent_enabled`；`view_image` 需模型 `supports_vision`；`tool_search` 需 `tool_search.enabled` 且有 MCP 工具 |
| ③ MCP 工具 | `include_mcp` 且磁盘 extensions 配置有启用 server；取 `get_cached_mcp_tools()`；tool_search 开启时注册进 `DeferredToolRegistry` 延迟化 |
| ④ ACP 工具 | `acp_agents` 非空时合成单个 `invoke_acp_agent` |

汇总后**按 `t.name` 去重，先到先得**（:158-174）。副作用：每次调用 `reset_deferred_registry()` 清 ContextVar 注册表（:112）。

**内置工具（builtins/，8 文件）**：
- `task_tool`（task_tool.py:51-308，257 行）——子代理委派核心：解析 `get_subagent_config(subagent_type)`（未知类型返回可用名单）→ bash 子代理过 `is_host_bash_allowed` 闸 → 合并技能白名单（父策略为准取交集，:40-48）→ 提取父上下文（sandbox/thread_data/thread_id/model_name/trace_id）→ 以 `subagent_enabled=False` 递归取工具（**杜绝嵌套 task**）→ `SubagentExecutor.execute_async(prompt, task_id=tool_call_id)` → **每 5 秒轮询** `get_background_task_result`，新 AI 消息经 `get_stream_writer()` 推 `task_running` 事件，终态发 `task_completed/failed/cancelled/timed_out` 并以 `"Task Succeeded. Result: {...}"` 纯文本回传主代理；轮询上限 `(timeout+60)//5` 兜底；`CancelledError` 时请求协作式取消并调度延迟清理。
- `tool_search`（tool_search.py:164-202）——三种查询语法（对齐 Claude Code）：`select:n1,n2` 精确、`+keyword rest` 名称必含+正则打分、普通关键词编译 IGNORECASE 正则（非法自动 escape 降级）对 `name+description` 打分（名称命中 2 分/描述 1 分）；命中转 OpenAI function schema JSON 返回并 `registry.promote()`（此后 DeferredToolFilterMiddleware 不再过滤其 schema）。
- `ask_clarification`（clarification_tool.py）——**占位空壳**（`return_direct=True`，函数体只返回一句话），真实中断逻辑在 `ClarificationMiddleware`（见 4.14）。
- `present_files`（present_file_tool.py:84）——把 `/mnt/user-data/outputs/*` 文件写入 `state.artifacts`（经 `merge_artifacts` reducer 去重合并，可并行调用）；路径强制 `relative_to(outputs_dir)` 校验。
- `view_image`（view_image_tool.py:49）——全链防御（虚拟根白名单→validate_local_tool_path→存在性→扩展名白名单→20MB 上限→**魔数与扩展名一致性校验**），成功 base64 写 `state.viewed_images`。
- `setup_agent`（setup_agent_tool.py:15）——bootstrap 专属：落盘自定义 agent 的 `config.yaml`+`SOUL.md`，失败且目录为本次新建时 rmtree 回滚；**不进入常规工具集**。
- `invoke_acp_agent`（invoke_acp_agent_tool.py:139-257）——动态构造：`_CollectingClient` 收集流式文本、`request_permission` 按 `auto_approve_permissions` 自动放行或一律拒绝；工作区按线程隔离 `{base}/threads/{tid}/acp-workspace/`；把 DeerFlow 的 MCP server 转成 ACP wire 格式桥接；`spawn_agent_process → initialize → new_session → prompt` 完成子进程 agent 调用。

**`skill_manage_tool`**（skill_manage_tool.py:205-236）：6 动作（create/edit/patch/delete/write_file/remove_file）；per-skill `asyncio.Lock`（WeakValueDictionary）；每次写入过 `scan_skill_content`（block 拒绝；`scripts/` 下必须 allow）；patch 用 `expected_count` 精确次数校验；成功后 `refresh_skills_system_prompt_cache_async()`；阻塞 IO 全走 `asyncio.to_thread`。

### 4.11 模块：guardrails/（工具授权，4 文件）

- `provider.py`：`GuardrailProvider` 是 **`@runtime_checkable Protocol`**（`name` 属性 + `evaluate/aevaluate`），`GuardrailDecision/Reason` 与 OAP Decision 对齐——任意鸭子类型类即可作为 provider，经 `resolve_variable` 加载。
- `builtin.py`：`AllowlistProvider`（:6）——白名单（None=全放行）+ 黑名单集合判断，拒绝携带 `oap.tool_not_allowed` 等 code。
- `middleware.py`：`GuardrailMiddleware`（:20）挂在 **wrap_tool_call**（工具执行前，非模型调用前）：`GraphBubbleUp`（LangGraph interrupt 信号）原样上抛（:63-65）；provider 异常时 `fail_closed=True`（默认）合成 `oap.evaluator_error` 拒绝、False 放行；拒绝以 `status="error"` 的 ToolMessage 反馈让 LLM 换路。
- 装配点：`tool_error_handling_middleware.py:99-120`——`guardrails.enabled and provider` 时 `resolve_variable(use)` 实例化（构造器接受 `framework` 参数时注入 `"deerflow"`）。

### 4.12 模块：subagents/（子代理引擎，7 文件）

**模块职责**：子代理的配置模型、注册发现与隔离执行引擎；由 `task` 工具驱动。

- `config.py`：`SubagentConfig` dataclass——`name/description/system_prompt/tools(None=继承全部)/disallowed_tools(默认含 task 防递归)/skills(None=继承全部，[]=无)/model("inherit")/max_turns(50)/timeout_seconds(900)`；`resolve_subagent_model_name`（:44-56）三级解析：自身 → 父模型 → 默认首个模型。
- `registry.py`：解析顺序 = 内置（general-purpose/bash）→ `subagents.custom_agents`；**覆盖合并分层**（模仿 Codex）：timeout/max_turns 全局默认仅对内置生效、per-agent 覆盖优先；model/skills 仅 per-agent 覆盖；`get_available_subagent_names` 按 `is_host_bash_allowed` 过滤 bash 可见性。
- `builtins/`：`general-purpose`（tools=None 继承全部，max_turns=100，系统提示强调"不得请求澄清"与引用格式）与 `bash`（tools 白名单 5 个沙箱工具，max_turns=60，隔离冗长命令输出）。
- `executor.py`（791 行）——**执行引擎**：
  - `_create_agent`（:272-290）：`create_chat_model(thinking_enabled=False)` + `build_subagent_runtime_middlewares`（与主代理共享 8 段基座，**不含 UploadsMiddleware**；视觉模型追加 ViewImageMiddleware）+ `create_agent(state_schema=ThreadState)`。
  - **隔离事件循环**：模块级持久守护线程 `_isolated_subagent_loop`（:89-173）——同步 `execute()` 在事件循环内被调用时投递到隔离循环执行（避免共享 httpx client 绑到短命循环）；`_submit_to_isolated_loop_in_context`（:176-186）用 `context.run(...)` 保持 ContextVar 跨线程传递。
  - `execute_async`（:640-709）：登记 PENDING 到模块级 `_background_tasks` → 复制父 context → 提交 `_scheduler_pool`（ThreadPoolExecutor(3)）→ worker 置 RUNNING → 隔离循环执行 → `future.result(timeout)` 超时置 TIMED_OUT + `cancel_event.set()`。
  - `_aexecute`（:380-556）：`agent.astream(stream_mode="values")` 流式迭代；**协作式取消**（迭代边界检查 `cancel_event`）；新 AIMessage 去重后 `model_dump()` 存 `ai_messages`（供前端流式事件）；最终取**最后一条 AIMessage 的 content** 作为 `result`。
  - **上下文隔离而非裁剪**：子代理全新 state（技能 SystemMessage + 一条 HumanMessage + 继承 sandbox/thread_data），只有最终文本字符串回传主代理；`recursion_limit = max_turns` 限制自身轮次。
  - **并发控制三层**（无 Semaphore）：`MAX_CONCURRENT_SUBAGENTS=3`（:712）→ `SubagentLimitMiddleware` 响应后截断超额 task 调用（被截断的调用由 DanglingToolCallMiddleware 兜底）；调度线程池 3 worker；timeout 秒级超时。
  - 技能注入（Codex 模式，:292-348）：SKILL.md 原文包 `<skill name="...">` 作为 **SystemMessage 会话条目**注入（非拼进 system_prompt）；`asyncio.to_thread` 加载避免阻塞。
  - 后台任务表 API：`request_cancel_background_task/get_background_task_result/list_background_tasks/cleanup_background_task`（:715-791，只删终态防竞态）。

### 4.13 模块：agents/（组装层核心，31 文件之顶层 + lead_agent）

**模块职责**：把模型/工具/提示/中间件组装成可执行的 LangGraph 图。两条建链路径并存：`create_deerflow_agent`（声明式 SDK 工厂）与 `make_lead_agent`（配置驱动的 LangGraph Server 入口）。

**文件组成**：`__init__.py`（re-export + **import 时预热技能缓存**——LangGraph 注册 graph 时即 import，提前启动后台加载线程）、`factory.py`、`features.py`、`thread_state.py`、`lead_agent/{__init__,agent,prompt}.py`。

- `ThreadState(AgentState)`（thread_state.py:48-55）：扩展字段 `sandbox/thread_data/title/todos/uploaded_files` + 带 reducer 的 `artifacts: Annotated[list[str], merge_artifacts]`（去重保序）与 `viewed_images: Annotated[dict, merge_viewed_images]`（**约定 `new=={}` 表示清空**）。LangGraph 在节点返回部分状态时按 reducer 合并而非覆盖。
- `RuntimeFeatures`（features.py:14-33）+ `@Next/@Prev(anchor)` 装饰器（:41-61）——把锚点写到类属性 `_next_anchor/_prev_anchor`，由 `factory._insert_extra`（factory.py:301-374）消费：迭代多轮插入（支持 extra 互相锚定）、无锚点插到链尾 Clarification 之前、冲突/环检测抛 ValueError；插入后强制把 ClarificationMiddleware 移回链尾（不变量修复，:284-291）。
- `create_deerflow_agent`（factory.py:61-147）：参数互斥校验（middleware 与 features/extra_middleware 互斥）→ `_assemble_from_features` 产出 **14 段链**（ThreadData→Uploads→Sandbox→DanglingToolCall→[Guardrail]→ToolErrorHandling→[Summarization]→[Todo]→[Title]→[Memory]→[ViewImage+工具]→[SubagentLimit+task 工具]→LoopDetection→Clarification）→ 工具按名去重合并（用户工具优先）→ `langchain.agents.create_agent(...)`。特性三态语义：`False` 跳过 / `True` 内置默认（guardrail/summarization 除外，必须传实例）/ 中间件实例直接替换。大量延迟 import 防循环依赖。
- `make_lead_agent(config: RunnableConfig)`（lead_agent/agent.py:311，LangGraph Server 兼容签名）→ `_make_lead_agent`（:318-411）流程：合并 runtime config（`configurable` 与 `context` 合并且 context 优先）→ 读取 thinking/reasoning_effort/model_name/is_plan_mode/subagent_enabled/max_concurrent_subagents/is_bootstrap/agent_name → `load_agent_config(agent_name)` → **模型名三级回退（请求 → agent 配置 → 全局默认）** → thinking 与模型能力不匹配降级 warning → `config["metadata"]` 注入 LangSmith 追踪标签（就地修改）→ 双分支建 agent（bootstrap 最小提示+setup_agent 工具 / 默认 lead 完整组装）。
- `_build_middlewares`（agent.py:238-308）**19 段链**：基座来自 `build_lead_runtime_middlewares`（定义在 tool_error_handling_middleware.py:70-136）——`ThreadData(lazy) → Uploads → Sandbox(lazy) → DanglingToolCall → LLMErrorHandling(app_config) → [Guardrail(条件)] → SandboxAudit → ToolErrorHandling`；lead 专属追加——`Summarization(app_config.summarization.enabled)` → `[Todo(is_plan_mode)]` → `[TokenUsage(app_config.token_usage.enabled)]` → `Title` → `Memory(agent_name)` → `[ViewImage(supports_vision)]` → `[DeferredToolFilter(tool_search.enabled)]` → `[SubagentLimit(subagent_enabled)]` → `LoopDetection` → `custom_middlewares` → `Clarification`（恒最后）。排序理由的注释块在 agent.py:228-237（thread_id 可用性、悬空修补要在模型看到历史前、摘要要早、澄清要最后拦截等）。
- `apply_prompt_template`（lead_agent/prompt.py:727-784）**系统提示拼接**：`_get_memory_context`（memory.enabled+injection_enabled 时读记忆并按 2000 token 预算格式化，**全函数 fail-open 失败返回空串**）→ 条件注入 subagent 编排段（含硬并发上限与动态子代理描述）→ 技能段 → 延迟工具段 → ACP/自定义挂载段 → `SYSTEM_PROMPT_TEMPLATE.format(...)`（`<role>/<soul>/<memory>/<thinking_style>/<clarification_system>(CLARIFY→PLAN→ACT 工作流)/<skill_system>/<working_directory>/<response_style>/<citations>/<critical_reminders>`）→ 末尾追加 `<current_date>`。
- **enabled-skills 后台缓存**（prompt.py:20-142）：模块级五件套（Lock+缓存+active 标志+**版本号**+Event）+ 守护线程 worker——加载完成后**版本号比对**，版本未变才写缓存并 set event，版本变了（期间又被失效）置 None 继续循环，保证收敛到最新；`warm_enabled_skills_cache(timeout=5)` 等待预热；技能提示段另有 `@lru_cache(32)` 二级缓存（key 为技能签名元组）。传入显式 app_config 时**绕过全局缓存**直读存储。

### 4.14 模块：agents/middlewares/（16 中间件，17 文件）

**模块职责**：全部横切能力的载体。基类 `langchain.agents.middleware.AgentMiddleware`；两个例外：`DeerFlowSummarizationMiddleware` 继承 LangChain 内置 SummarizationMiddleware、`TodoMiddleware` 继承 TodoListMiddleware。

**钩子矩阵**（同步/异步成对实现，下表合并列出）：

| 中间件 | 钩子 | 一句话职责 | 实现要点 |
|---|---|---|---|
| ThreadData | before_agent | 计算线程三目录写入 state | lazy_init 只算路径；给最后一条 HumanMessage 补 run_id/时间戳元数据 |
| Uploads | before_agent | 注入 `<uploaded_files>` 块（含大纲） | kwargs.files + 目录扫描；路径穿越校验；多模态消息插首个 text 块保留图片 |
| Sandbox | before/after_agent | 获取/释放沙箱写 sandbox_id | lazy 模式实际获取延迟到工具首调 |
| DanglingToolCall | wrap_model_call | 修补悬空 tool call | 收集已有 tool_call_id → 在悬空 AIMessage 后插入 `status="error"` 合成 ToolMessage；只改本次请求视图不回写 state（不能用 before_model 的原因：插入位置须精确） |
| LLMErrorHandling | wrap_model_call | LLM 错误重试+熔断+降级 | 瞬时错误指数退避（≤3 次，优先 Retry-After 头，封顶 8s）；quota/auth 不重试不进熔断；熔断三态（阈值=app_config.circuit_breaker，默认 5 次/60s）half_open 放单探针；`GraphBubbleUp` 原样上抛；耗尽后降级为友好 AIMessage 并发 `llm_retry` 流事件 |
| Guardrail | wrap_tool_call | 工具前授权（见 4.11） | fail-closed；`GraphBubbleUp` 透传 |
| SandboxAudit | wrap_tool_call | bash 命令分级审计 | 手写引号感知复合命令切分（未闭合引号 fail-closed）；17 条高危正则 block、5 条中危 warn；全部写 JSON 审计日志；命令截断 200 字符 |
| ToolErrorHandling | wrap_tool_call | 工具异常→error ToolMessage | 无重试单层兜底；`GraphBubbleUp` 透传；detail 截 500 字符 |
| Summarization | before_model | 上下文压缩 + 技能拯救 + 记忆抢救钩子 | 复用父类主流程；分区用 `_partition_with_skill_rescue`（从最新往旧拯救"读 skills 目录"的消息束：数量≤5/总量≤25k/单技能≤5k token；混合 tool_calls 的 AIMessage **拆分克隆**保配对）；`REMOVE_ALL_MESSAGES` 清空重建；摘要载体 `HumanMessage(name="summary")` 前端不显示；`before_summarization` 钩子单异常不中断 |
| Todo | before_model + after_model(jump_to) | 计划模式 | 摘要截断后注入 todo 全量提醒；**未完成 todo 且模型想结束时**注入提醒并 `jump_to:"model"` 强制继续（最多 2 次防死循环） |
| Title | after_model | 首轮自动起标题 | 判定（无 title 且 1 human + ≥1 ai）→ async 路径才真正调 LLM（`run_name="title_agent"` + tag），同步路径纯本地 fallback；异常 catch-all 降级 |
| Memory | after_agent | 对话入记忆队列 | 过滤消息 + 检测纠错/正强化信号 + **入队时捕获 user_id**（ContextVar 不传播到 Timer 线程） |
| ViewImage | before_model | 已看图片注入多模态消息 | 四条件（最后 AI 含 view_image 调用且全部完成且未注入过）；base64 图片块进消息历史 |
| DeferredToolFilter | wrap_model_call + wrap_tool_call | 延迟工具过滤/拦截 | 模型绑定前移除未晋升 MCP 工具 schema；未晋升直接调用则短路提示先调 tool_search |
| SubagentLimit | after_model | 截断超额 task 调用 | 上限夹取 [2,4]（默认 3）；`model_copy` 替换 AIMessage；被截断调用由 Dangling 兜底 |
| LoopDetection | after_model | 双层循环检测 | **哈希层**：规范化 key（read_file 按行 200 分桶、写类全量 args 排序序列化、其余取显著字段）+ 整组排序 md5（顺序无关）；滑动窗口 20 条，≥3 警告 ≥5 硬停。**频次层**：per-tool-type 累计，≥30 警告 ≥50 硬停。硬停清空 tool_calls 剥 additional_kwargs 迫使纯文本终答；警告用 HumanMessage(name="loop_warning")（规避 Anthropic 非连续 system 报错）；LRU 100 线程 |
| Clarification | wrap_tool_call | 澄清中断 | 匹配 `ask_clarification` → 格式化问题（兼容 Qwen3-Max 数组参数字符串化）→ `Command(update, goto=END)` 终结本轮；确定性消息 ID 保证重试替换而非追加 |

### 4.15 模块：agents/memory/（记忆子系统，7 文件）

**模块职责**：对话 → LLM 抽取事实 → memory.json 持久化 → 下次会话按 token 预算注入系统提示。

**架构（谁驱动谁）**：
- 写路径 1（常规）：`MemoryMiddleware.after_agent` → 过滤+信号检测 → `get_memory_queue().add(...)`（30s 防抖）。
- 写路径 2（摘要前抢救）：SummarizationMiddleware 删除旧消息前调 `memory_flush_hook`（summarization_hook.py:11）→ `add_nowait` 立即入队。
- 消费：`MemoryUpdateQueue._process_queue`（Timer 线程）→ `MemoryUpdater.update_memory` → LLM 抽取 → `FileMemoryStorage.save` 原子写盘。
- 读路径：`apply_prompt_template → _get_memory_context → get_memory_data + format_memory_for_injection`。

**关键实现**：
- `message_processing.py`：`filter_messages_for_memory` 保留 human 与无 tool_calls 的 ai 消息，剥离 `<uploaded_files>` 块（剥离后为空的 human 连带跳过紧随 AI——小状态机）；`detect_correction/detect_reinforcement` 中英双语正则（最近 6 条窗口），约定先测 correction、无 correction 才测 reinforcement。
- `queue.py`：`add` 每次重置 Timer（**滑动窗口防抖**）；`_enqueue_locked` **按 thread_id 合并去重**（同线程只留最新对话，信号标志 OR 合并不丢失）；`_process_queue` 单飞检查（处理中则 0 延迟重试）、多上下文间 `sleep(0.5)` 限流、单上下文失败不中断；`ConversationContext` 显式存 user_id（ContextVar 不传播）。
- `storage.py`：`FileMemoryStorage`——路径解析按 user/agent 维度隔离（`users/{uid}/agents/{name}/memory.json` 等）；**mtime 缓存**读；**临时文件原子替换**写；`get_memory_storage()` 双检锁单例 + 按 `storage_class` 配置动态导入（失败回退）。
- `prompt.py`：`MEMORY_UPDATE_PROMPT` 要求 LLM 输出结构化 JSON（user 三节/history 三节 `shouldUpdate+summary`、`newFacts[]`(content/category/confidence)、`factsToRemove[]`；六类 category；**禁止记录文件上传事件**）；`format_memory_for_injection` 按 confidence 降序 + 增量 token 记账截断（默认 2000）+ correction 类附 `(avoid: ...)`。
- `updater.py`（612 行）：`MemoryUpdater.update_memory` **事件循环感知**——在运行中 loop 内则提交专用 `ThreadPoolExecutor(4)` 阻塞等待（避免跨 loop 复用 httpx 连接，issue #2615）；`_apply_updates` 落地算法：shouldUpdate 且非空才覆盖+盖时间戳 → factsToRemove 按 id 过滤 → newFacts 过置信度阈值（0.7）+ casefold 去重 → 超 max_facts（100）按置信度截断；`_strip_upload_mentions_from_memory` 用窄匹配正则只删"上传事件"句子。手动 CRUD 函数族（create/delete/update_memory_fact 等）fail-loud。
- **Fact 字段**：`id="fact_"+uuid8 / content / category / confidence / createdAt(ISO-Z) / source(thread_id|manual) / 可选 sourceError`。

### 4.16 模块：persistence/（应用数据持久层，19 py + alembic.ini）

**模块职责**：应用数据（runs/threads_meta/run_events/feedback/users）的 SQLAlchemy 2.0 async ORM；与 LangGraph checkpointer 表完全分离（`__init__.py:1-9`）。

**文件组成**：`engine.py`（191 行）、`base.py`（DeclarativeBase+to_dict）、5 个 ORM（feedback/model、models/run_event、run/model、thread_meta/model、user/model）、4 个 Repository（feedback/sql、run/sql、thread_meta/sql、thread_meta/memory）、`migrations/`（alembic.ini + env.py；**versions 目前为空，实际建表靠 engine 的 create_all**）。

**关键实现**：
- `init_engine`（engine.py:57-156）：sqlite 分支——每条新连接执行 `PRAGMA journal_mode=WAL / synchronous=NORMAL / foreign_keys=ON`（事件监听器，:106-112）；postgres 分支——`pool_size(5)+pool_pre_ping`，缺 asyncpg 给安装提示；统一 `async_sessionmaker(expire_on_commit=False)`；import models 注册全部 ORM 后 `create_all`，postgres 库不存在时自动 `CREATE DATABASE` 重试（:144-152）。
- **5 张表**：`runs`（run 元数据+冗余统计：message_count/first_human/last_ai/token 七字段，索引 ix_runs_thread_status）、`threads_meta`（display_name/status/metadata_json）、`run_events`（event_type/category/content/metadata/seq；`UniqueConstraint(thread_id,seq)` + 两复合索引）、`feedback`（rating±1；`UniqueConstraint(thread_id,run_id,user_id)`）、`users`（email 唯一、oauth 部分唯一索引 `sqlite_where`——仅 SQLite 生效）。
- **Repository 通用模式**：每方法 `async with session_factory() as session` 短命会话 + 显式 commit；属主过滤三位置——get/delete 读后比对、list 在 WHERE、update 经 `_check_ownership` 预检。
- `user_id` 三态语义（`AUTO` 哨兵，来自 `runtime/user_context.py:121-167`）：AUTO=读 ContextVar（无用户抛 RuntimeError，UUID→str 强转因 aiosqlite 不能绑定原生 UUID）；显式 str=覆盖；显式 None=不加 WHERE（仅迁移/CLI）。
- `thread_meta` 双实现：`ThreadMetaRepository`（SQL，metadata 过滤为取 `limit*5+offset` 大窗口后 Python 端过滤，TODO Phase 2 换 JSON 操作符）与 `MemoryThreadMetaStore`（包装 LangGraph Store `("threads",)` 命名空间，服务端过滤）；`make_thread_store`（__init__.py:25-38）按 session_factory 有无选择。
- `RunRepository(RunStore)`：实现 `runtime/runs/store/base.py` 抽象，供 RunManager 持久化背书；`aggregate_tokens_by_thread`（sql.py:208-255）单条 GROUP BY SQL + Python 侧汇总 by_model/by_caller。

### 4.17 模块：runtime/（服务端运行时，29 文件）

**模块职责**：Run 生命周期、SSE 事件桥、事件日志与存储、LangGraph 持久化工厂、用户上下文与序列化协议。

**runs/ 子包**：
- `RunManager`（manager.py:49-242）——内存注册表 `dict[run_id→RunRecord]` + 可选 RunStore 背书。状态机 `pending→running→success|error|interrupted`（`timeout` 为死枚举，全仓库无赋值点）。**`create_or_reject`**（:165-229）把检查+插入放进同一锁消除 TOCTOU：`reject` 策略有 inflight 抛 `ConflictError`；`interrupt/rollback` 对每个 inflight run `abort_event.set()+task.cancel()+置 interrupted` 后再创建。`cancel`（:140-163）仅 pending/running 生效。所有 store 调用 best-effort（异常仅告警，持久化故障不杀运行）。
- `run_agent`（worker.py:120-392）——**后台执行主循环**（详见第 7 章调用链）：注入 runtime context（手动复刻 langgraph-cli 的 `__pregel_runtime` 注入，:210-220）→ 状态 running → 捕获 pre-run checkpoint 快照（rollback 用，失败不中断）→ `agent_factory(config, app_config?)`（inspect.signature 探测是否接受 app_config，lru_cache 缓存）→ 挂 checkpointer/store/RunJournal → stream 模式映射（`messages-tuple→messages`；`events` 被显式跳过——Python 公共 API 无法与 values 快照共存）→ `astream` 循环（每 chunk 先查 `abort_event` 协作式停止）→ `bridge.publish(run_id, mode, serialize(chunk, mode))`。三分支结束：rollback→error("Rolled back by user")+`_rollback_to_pre_run_checkpoint`（:411-501：用 `empty_checkpoint()` 生成**新** checkpoint id 作恢复标记避免复用旧 id 破坏历史链，按 task_id 分组回放 pending_writes）；interrupt→interrupted；正常→success。finally：journal.flush → update_run_completion 持久化 token → 线程标题/状态同步 → publish_end + 延迟 60s cleanup。
- `RunStore` 抽象（store/base.py）8 方法 + `MemoryRunStore`（dict 实现，memory 后端/测试用）。

**events/ 子包**：`RunEventStore` 抽象（store/base.py）——put/put_batch/list_messages(双向游标分页)/list_events/list_messages_by_run/count/delete；契约要求 **seq 在同一 thread 内严格递增**。三实现对比：

| 维度 | DbRunEventStore（db.py） | JsonlRunEventStore（jsonl.py） | MemoryRunEventStore（memory.py） |
|---|---|---|---|
| seq 分配 | 事务内 `SELECT max(seq) FOR UPDATE`（SQLite 上为 no-op，靠唯一约束兜底）；batch 一次锁整批 | 惰性全量扫描恢复 max seq + 进程内计数器（多进程会冲突） | 进程内计数器 |
| 特性 | trace 字节级截断（max_trace_content）、user_id 属主过滤、dict content JSON 化 | 每 run 一个 `.jsonl` 文件；**同步文件 IO 阻塞事件循环**（已知代价） | 进程重启即失 |

**stream_bridge/ 子包**：`StreamBridge` 抽象（base.py:37：publish/publish_end/subscribe/cleanup + `END/HEARTBEAT` 哨兵）。`MemoryStreamBridge`（memory.py:25-133）——**共享事件日志 + `asyncio.Condition` 扇出**（非每订阅者一队列）：publish 锁内 append+notify_all，各订阅者独立 `next_offset` 游标读取；**有界保留窗口**（默认 256，超限从头裁剪并推进 `start_offset`，实现全局偏移量寻址）；事件 ID `f"{ts}-{seq}"` 支撑 Last-Event-ID 回放（找不到则从最早保留事件重放）；慢消费者（offset 已被裁剪）**跳到 start_offset 丢事件保活跃**；空闲心跳（`wait_for(condition.wait, timeout)` 超时 yield 心跳哨兵）；yield 在锁外（消费处理不阻塞生产）。注意：`asyncio.Condition` 绑定 loop，仅单进程可用（redis 为 Phase 2 未实现）。

**checkpointer/ 与 store/ 子包**：每个各有两套——同步 `get_checkpointer()/get_store()`（模块级单例 + 存活 CM，服务 client.py 嵌入式）与异步 `make_checkpointer()/make_store()`（asynccontextmanager，进出即建销，服务网关 lifespan）。后端选择：legacy `checkpointer:` 段优先 → 统一 `database:` 段 → 兜底 InMemory（store 未配置时 WARNING "Thread list will be lost on server restart"）。`_sqlite_utils.py` 共享连接串解析（`:memory:`/`file:` URI 原样，其余转绝对路径）+ 父目录 mkdir。

**根级文件**：
- `user_context.py`：`ContextVar[CurrentUser]` + 三态 `resolve_user_id`（见 4.16）；`get_effective_user_id()` 永不抛错（无用户落 `"default"` 桶）；写方为网关 auth 中间件（set/finally reset Token）。
- `serialization.py`：`serialize(obj, mode)` 按 LangGraph stream 模式分派——`messages`→`(chunk, metadata)` 二元组协议、`values`→channel 协议（剥离 `__pregel_*` 内部键）、其余通用（Pydantic v2/v1 递归降级，tuple 退化 list，str() 兜底）。
- `journal.py`：`RunJournal(BaseCallbackHandler)`（:37）——把 LangChain 回调标准化为 RunEvent 写入 store：`on_chat_model_start` 作为首条 human 消息权威来源（`reversed` 遍历取 prompt 中**最后一条** HumanMessage，跳过 `name=="summary"`）；**写缓冲+批量刷写**（阈值 20；有 in-flight 刷写时跳过避免并发写同一 SQLite；失败把 batch 前置回缓冲重试）；token 累计与 LLM 延迟追踪；tags 归因 caller（subagent:*/middleware:*/lead_agent）。
- `converters.py`：LangChain 消息 → OpenAI Chat Completions 线格式（duck-typing 纯函数）；**当前无生产调用方**（RunJournal 直接 model_dump），属预留。
- `runs/schemas.py`：`RunStatus`/`DisconnectMode` StrEnum。

---

## 5. 文件清单总表（全部生产源文件）

> 覆盖 deerflow 包全部 195 个 `.py` 文件 + 1 个承载运行逻辑的配置（`alembic.ini`）。`persistence/migrations/versions/.gitkeep` 为空占位，不列入。行数为约数（空行计入）。

### 5.1 入口与根（2 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| `__init__.py` | 入口 | 空文件，仅包标记 | — | — |
| `client.py` (~1280 行) | 入口 | 嵌入式同步客户端：会话流式/线程查询/模型技能记忆管理/上传转换/产物读取 | `DeerFlowClient`, `StreamEvent` | agents(lead_agent/thread_state)、models、skills.storage、uploads、utils.file_conversion、runtime.checkpointer |

### 5.2 agents/（31 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| `agents/__init__.py` | agents | 包门面 + import 时预热技能缓存 | `create_deerflow_agent` 等 | factory/features/lead_agent/thread_state |
| `agents/factory.py` | agents | 声明式 SDK 工厂（14 段链 + @Next/@Prev 插入算法） | `create_deerflow_agent` | middlewares、thread_state、tools.builtins |
| `agents/features.py` | agents | 特性开关 dataclass + 中间件定位装饰器 | `RuntimeFeatures`, `Next`, `Prev` | langchain.middleware |
| `agents/thread_state.py` | agents | LangGraph 线程状态 schema | `ThreadState`, `SandboxState`, `merge_artifacts`, `merge_viewed_images` | langchain.agents.AgentState |
| `agents/lead_agent/__init__.py` | agents | re-export | `make_lead_agent` | agent.py |
| `agents/lead_agent/agent.py` (~412 行) | agents | 配置驱动主代理工厂（19 段中间件链） | `make_lead_agent`, `_build_middlewares` | models、tools、middlewares×10、config.agents_config |
| `agents/lead_agent/prompt.py` (~785 行) | agents | 系统提示模板 + 技能后台缓存 | `apply_prompt_template`, `prime/warm/clear/refresh_skills_*` | skills.storage、subagents.registry、memory |
| `agents/memory/__init__.py` | memory | 记忆子系统门面 | Queue/Storage/Updater 全量 API | 各子模块 |
| `agents/memory/message_processing.py` | memory | 消息过滤与纠错/正强化信号检测 | `filter_messages_for_memory`, `detect_correction/reinforcement` | re/copy |
| `agents/memory/prompt.py` (~364 行) | memory | 记忆更新提示模板 + token 预算格式化 | `MEMORY_UPDATE_PROMPT`, `format_memory_for_injection` | tiktoken(可选) |
| `agents/memory/queue.py` (~278 行) | memory | 防抖记忆更新队列（滑动窗口 Timer） | `MemoryUpdateQueue`, `get_memory_queue` | config.memory_config、updater(延迟) |
| `agents/memory/storage.py` (~232 行) | memory | 存储抽象 + JSON 文件实现（mtime 缓存/原子写） | `FileMemoryStorage`, `get_memory_storage` | config.paths、config.memory_config |
| `agents/memory/summarization_hook.py` | memory | 摘要前记忆抢救钩子 | `memory_flush_hook` | queue、message_processing |
| `agents/memory/updater.py` (~612 行) | memory | LLM 记忆抽取 + 事实 CRUD | `MemoryUpdater`, `get_memory_data` 等 CRUD 族 | models、storage、prompt |
| `agents/middlewares/__init__.py` | middlewares | 空文件（仅包标记） | — | — |
| `agents/middlewares/clarification_middleware.py` (~201 行) | middlewares | 澄清中断（goto=END） | `ClarificationMiddleware` | langchain/langgraph |
| `agents/middlewares/dangling_tool_call_middleware.py` (~149 行) | middlewares | 悬空 tool call 修补 | `DanglingToolCallMiddleware` | langchain_core.messages |
| `agents/middlewares/deferred_tool_filter_middleware.py` (~107 行) | middlewares | 延迟工具 schema 过滤/调用拦截 | `DeferredToolFilterMiddleware` | tools.builtins.tool_search(延迟) |
| `agents/middlewares/llm_error_handling_middleware.py` (~368 行) | middlewares | LLM 错误重试+熔断+降级 | `LLMErrorHandlingMiddleware` | config.app_config |
| `agents/middlewares/loop_detection_middleware.py` (~389 行) | middlewares | 双层循环检测（哈希+频次） | `LoopDetectionMiddleware` | 无外部项目依赖 |
| `agents/middlewares/memory_middleware.py` (~110 行) | middlewares | 对话入记忆队列 | `MemoryMiddleware` | memory.queue、user_context |
| `agents/middlewares/sandbox_audit_middleware.py` (~363 行) | middlewares | bash 命令分级审计 | `SandboxAuditMiddleware` | thread_state |
| `agents/middlewares/subagent_limit_middleware.py` (~75 行) | middlewares | 截断超额 task 调用 | `SubagentLimitMiddleware` | subagents.executor |
| `agents/middlewares/summarization_middleware.py` (~354 行) | middlewares | 摘要+技能拯救+before 钩子 | `DeerFlowSummarizationMiddleware`, `SummarizationEvent` | langchain SummarizationMiddleware |
| `agents/middlewares/thread_data_middleware.py` (~118 行) | middlewares | 线程三目录写入 state | `ThreadDataMiddleware` | config.paths、user_context |
| `agents/middlewares/title_middleware.py` (~179 行) | middlewares | 首轮自动起标题 | `TitleMiddleware` | config.title_config、models |
| `agents/middlewares/todo_middleware.py` (~179 行) | middlewares | 计划模式（上下文丢失检测+退出拦截） | `TodoMiddleware` | langchain TodoListMiddleware |
| `agents/middlewares/token_usage_middleware.py` (~294 行) | middlewares | token 日志+步骤归因元数据 | `TokenUsageMiddleware` | langchain Todo |
| `agents/middlewares/tool_error_handling_middleware.py` (~167 行) | middlewares | 工具异常兜底 + **共享链构建器** | `ToolErrorHandlingMiddleware`, `build_lead/subagent_runtime_middlewares` | sandbox.middleware、guardrails、reflection |
| `agents/middlewares/uploads_middleware.py` (~295 行) | middlewares | 上传文件注入 `<uploaded_files>` | `UploadsMiddleware` | config.paths、utils.file_conversion |
| `agents/middlewares/view_image_middleware.py` (~222 行) | middlewares | 已看图片注入多模态消息 | `ViewImageMiddleware` | thread_state |

### 5.3 community/（20 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| `community/aio_sandbox/__init__.py` | aio_sandbox | 包门面 | `AioSandbox(Provider)` 等全量 | 各子模块 |
| `community/aio_sandbox/aio_sandbox.py` (~239 行) | aio_sandbox | 容器 HTTP API 封装（锁串行 shell） | `AioSandbox` | agent_sandbox、sandbox.search |
| `community/aio_sandbox/aio_sandbox_provider.py` (~708 行) | aio_sandbox | 编排层：缓存/warm pool/文件锁/idle/孤儿对账 | `AioSandboxProvider` | backend、sandbox.sandbox_provider、config.paths |
| `community/aio_sandbox/backend.py` (~115 行) | aio_sandbox | 后端抽象 + 就绪探测 | `SandboxBackend`, `wait_for_sandbox_ready` | requests、sandbox_info |
| `community/aio_sandbox/local_backend.py` (~619 行) | aio_sandbox | 本地 Docker/Apple Container 管理 | `LocalContainerBackend` | utils.network |
| `community/aio_sandbox/remote_backend.py` (~157 行) | aio_sandbox | 远程 provisioner 薄客户端 | `RemoteSandboxBackend` | requests |
| `community/aio_sandbox/sandbox_info.py` | aio_sandbox | 沙箱元数据 dataclass | `SandboxInfo` | — |
| `community/ddg_search/__init__.py` | 搜索工具 | re-export | `web_search_tool` | tools |
| `community/ddg_search/tools.py` (~95 行) | 搜索工具 | DuckDuckGo 网页搜索（免费） | `web_search_tool` | ddgs、config |
| `community/exa/tools.py` (~79 行) | 搜索工具 | Exa 搜索+抓取 | `web_search_tool`, `web_fetch_tool` | exa-py、config |
| `community/firecrawl/tools.py` (~73 行) | 搜索工具 | Firecrawl 搜索+Markdown 抓取 | `web_search_tool`, `web_fetch_tool` | firecrawl-py、config |
| `community/image_search/__init__.py` | 搜索工具 | re-export | `image_search_tool` | tools |
| `community/image_search/tools.py` (~135 行) | 搜索工具 | DDG 图片搜索（生成参考图） | `image_search_tool` | ddgs、config |
| `community/infoquest/infoquest_client.py` (~404 行) | 搜索工具 | BytePlus InfoQuest 同步客户端 | `InfoQuestClient` | requests、env `INFOQUEST_API_KEY` |
| `community/infoquest/tools.py` (~93 行) | 搜索工具 | InfoQuest 三工具封装 | `web_search/web_fetch/image_search_tool` | infoquest_client、utils.readability |
| `community/jina_ai/jina_client.py` (~43 行) | 搜索工具 | Jina Reader 异步抓取客户端 | `JinaClient` | httpx、env `JINA_API_KEY` |
| `community/jina_ai/tools.py` (~32 行) | 搜索工具 | Jina 抓取工具（唯一 async 工具） | `web_fetch_tool` | jina_client、utils.readability |
| `community/serper/__init__.py` | 搜索工具 | re-export | `web_search_tool` | tools |
| `community/serper/tools.py` (~95 行) | 搜索工具 | Serper(Google JSON API) 搜索 | `web_search_tool` | httpx、config/api 双凭据 |
| `community/tavily/tools.py` (~62 行) | 搜索工具 | Tavily 搜索+抽取 | `web_search_tool`, `web_fetch_tool` | tavily-python、config |

### 5.4 config/（25 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| `config/__init__.py` | config | 包门面（import 即 load_dotenv） | 常用 get_* 函数 | app_config 等 |
| `config/app_config.py` (~455 行) | config | 聚合根：加载/热重载/环境变量展开 | `AppConfig`, `get_app_config`, `reload/reset/set_app_config` | 各子配置、yaml、dotenv |
| `config/paths.py` (~338 行) | config | 数据目录布局+虚拟路径安全解析 | `Paths`, `get_paths`, `VIRTUAL_PATH_PREFIX` | runtime_paths |
| `config/extensions_config.py` (~264 行) | config | MCP/技能开关（extensions_config.json） | `ExtensionsConfig`, `McpServerConfig`, `McpOAuthConfig` | runtime_paths |
| `config/model_config.py` | config | 单模型条目 schema | `ModelConfig` | pydantic |
| `config/database_config.py` (~103 行) | config | 统一持久化后端（memory/sqlite/postgres） | `DatabaseConfig` | — |
| `config/runtime_paths.py` | config | 项目根/运行时根解析基元 | `project_root`, `runtime_home`, `existing_project_file` | env |
| `config/tracing_config.py` (~150 行) | config | LangSmith/Langfuse 开关（纯环境变量，双检锁） | `get_tracing_config`, `get_enabled_tracing_providers` | env |
| `config/agents_config.py` (~136 行) | config | 自定义 agent 目录（config.yaml+SOUL.md） | `load_agent_config`, `load_agent_soul`, `AGENT_NAME_PATTERN` | paths |
| `config/acp_config.py` | config | ACP 子进程 agent 注册表 | `ACPAgentConfig`, `get_acp_agents` | — |
| `config/agents_api_config.py` | config | agent 管理 API 总开关 | `AgentsApiConfig` | — |
| `config/checkpointer_config.py` | config | legacy checkpointer 配置 | `CheckpointerConfig` | — |
| `config/guardrails_config.py` | config | 护栏配置 | `GuardrailsConfig`, `GuardrailProviderConfig` | — |
| `config/memory_config.py` (~84 行) | config | 记忆子系统配置 | `MemoryConfig`, `get_memory_config` | paths |
| `config/run_events_config.py` | config | 事件存储后端选择 | `RunEventsConfig` | — |
| `config/sandbox_config.py` (~84 行) | config | 沙箱 provider 配置+输出截断三项 | `SandboxConfig`, `VolumeMountConfig` | — |
| `config/skills_config.py` (~73 行) | config | 技能路径四级解析+容器挂载点 | `SkillsConfig`, `get_skills_path` | runtime_paths |
| `config/skill_evolution_config.py` | config | 技能自进化开关+审核模型 | `SkillEvolutionConfig` | — |
| `config/stream_bridge_config.py` | config | 事件桥配置（redis 预留） | `StreamBridgeConfig` | — |
| `config/subagents_config.py` (~188 行) | config | 子代理全局/覆盖/自定义配置 | `SubagentsAppConfig`, `CustomSubagentConfig` | — |
| `config/summarization_config.py` (~94 行) | config | 摘要触发/保留/技能拯救参数 | `SummarizationConfig`, `ContextSize` | — |
| `config/title_config.py` | config | 标题生成配置 | `TitleConfig` | — |
| `config/token_usage_config.py` | config | token 追踪开关 | `TokenUsageConfig` | — |
| `config/tool_config.py` | config | 工具/工具组注册 schema | `ToolConfig`, `ToolGroupConfig` | — |
| `config/tool_search_config.py` | config | 延迟工具发现开关 | `ToolSearchConfig` | — |

### 5.5 guardrails/ mcp/ models/ tracing/ reflection/（23 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| `guardrails/__init__.py` | guardrails | 包门面 | `GuardrailMiddleware` 等 | — |
| `guardrails/provider.py` | guardrails | Protocol 抽象 + OAP 对齐数据类 | `GuardrailProvider(Protocol)`, `GuardrailDecision/Request/Reason` | typing |
| `guardrails/builtin.py` | guardrails | 白/黑名单参考实现 | `AllowlistProvider` | provider |
| `guardrails/middleware.py` (~98 行) | guardrails | 工具前授权执行点（fail-closed） | `GuardrailMiddleware` | langchain/langgraph |
| `mcp/__init__.py` | mcp | 包门面 | `get_mcp_tools`, `get_cached_mcp_tools` 等 | — |
| `mcp/cache.py` (~143 行) | mcp | 会话缓存（mtime 失效+同步跑 async） | `get_cached_mcp_tools`, `initialize_mcp_tools`, `reset_mcp_tools_cache` | extensions_config、mcp.tools |
| `mcp/client.py` (~69 行) | mcp | 配置→MultiServerMCPClient 参数转换 | `build_server_params`, `build_servers_config` | extensions_config |
| `mcp/oauth.py` (~151 行) | mcp | OAuth 令牌管理+请求拦截器 | `OAuthTokenManager`, `build_oauth_tool_interceptor` | httpx、extensions_config |
| `mcp/tools.py` (~136 行) | mcp | 工具加载+拦截器装配+同步壳 | `get_mcp_tools`, `_make_sync_tool_wrapper` | langchain_mcp_adapters(可选)、reflection |
| `models/__init__.py` | models | 门面 | `create_chat_model` | factory |
| `models/factory.py` (~158 行) | models | 配置驱动模型路由+thinking 处理 | `create_chat_model` | config、reflection、tracing |
| `models/credential_loader.py` (~220 行) | models | Claude Code/Codex CLI 凭据加载 | `load_claude_code_credential`, `load_codex_cli_credential` | env/磁盘 |
| `models/claude_provider.py` (~360 行) | models | OAuth+cache 断点+thinking budget+重试 | `ClaudeChatModel` | langchain_anthropic、credential_loader |
| `models/openai_codex_provider.py` (~461 行) | models | ChatGPT Codex Responses API 直连 | `CodexChatModel` | httpx、credential_loader |
| `models/mindie_provider.py` (~250 行) | models | MindIE XML 工具调用兼容 | `MindIEChatModel` | langchain_openai |
| `models/vllm_provider.py` (~259 行) | models | vLLM reasoning 回传 | `VllmChatModel` | langchain_openai(私有 API) |
| `models/patched_deepseek.py` (~74 行) | models | reasoning_content 多轮回传 | `PatchedChatDeepSeek` | langchain_deepseek |
| `models/patched_minimax.py` (~221 行) | models | reasoning_details/<think> 映射 | `PatchedChatMiniMax` | langchain_openai(私有 API) |
| `models/patched_openai.py` (~133 行) | models | Gemini thought_signature 回传 | `PatchedChatOpenAI` | langchain_openai |
| `tracing/__init__.py` | tracing | 门面 | `build_tracing_callbacks` | factory |
| `tracing/factory.py` (~55 行) | tracing | LangSmith/Langfuse callback 构造 | `build_tracing_callbacks` | config.tracing_config |
| `reflection/__init__.py` | reflection | 门面 | `resolve_class`, `resolve_variable` | resolvers |
| `reflection/resolvers.py` (~96 行) | reflection | "模块:符号"动态解析+安装提示 | `resolve_class`, `resolve_variable` | importlib |

### 5.6 persistence/（19 py + 1 ini）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| `persistence/__init__.py` | persistence | 门面 | engine 生命周期函数 | engine |
| `persistence/base.py` | persistence | DeclarativeBase + to_dict/repr | `Base` | sqlalchemy |
| `persistence/engine.py` (~191 行) | persistence | 全局 AsyncEngine 生命周期（WAL/池/自动建库建表） | `init_engine(_from_config)`, `get_session_factory`, `close_engine` | aiosqlite/asyncpg |
| `persistence/feedback/__init__.py` | persistence | 导出 | `FeedbackRow`, `FeedbackRepository` | — |
| `persistence/feedback/model.py` | persistence | feedback 表 ORM（rating±1，三元唯一约束） | `FeedbackRow` | base |
| `persistence/feedback/sql.py` (~217 行) | persistence | 反馈 CRUD/upsert/聚合 | `FeedbackRepository` | user_context |
| `persistence/migrations/alembic.ini` | persistence | Alembic 配置（script_location=%(here)s） | — | — |
| `persistence/migrations/env.py` (~68 行) | persistence | Alembic 环境（render_as_batch，只管应用表） | — | base、models |
| `persistence/models/__init__.py` | persistence | ORM 注册入口（import 即挂 metadata） | 5 个 Row 类 | 各 model |
| `persistence/models/run_event.py` | persistence | run_events 表 ORM（thread+seq 唯一约束） | `RunEventRow` | base |
| `persistence/run/__init__.py` | persistence | 导出 | `RunRow`, `RunRepository` | — |
| `persistence/run/model.py` | persistence | runs 表 ORM（含 token 七字段冗余统计） | `RunRow` | base |
| `persistence/run/sql.py` (~255 行) | persistence | RunStore 的 SQL 实现 | `RunRepository(RunStore)` | runs.store.base、user_context |
| `persistence/thread_meta/__init__.py` | persistence | 导出+后端选择工厂 | `make_thread_store` | sql/memory |
| `persistence/thread_meta/base.py` | persistence | ThreadMetaStore 抽象（三态 user_id 文档） | `ThreadMetaStore(ABC)` | — |
| `persistence/thread_meta/memory.py` (~151 行) | persistence | LangGraph Store 包装实现 | `MemoryThreadMetaStore` | langgraph.store、utils.time |
| `persistence/thread_meta/model.py` | persistence | threads_meta 表 ORM | `ThreadMetaRow` | base |
| `persistence/thread_meta/sql.py` (~217 行) | persistence | SQL 实现（metadata Python 端窗口过滤） | `ThreadMetaRepository` | base/model、user_context |
| `persistence/user/__init__.py` | persistence | 导出（repo 在 app 层防反向依赖） | `UserRow` | — |
| `persistence/user/model.py` | persistence | users 表 ORM（oauth 部分唯一索引） | `UserRow` | base |

### 5.7 runtime/（29 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| `runtime/__init__.py` | runtime | 包门面（聚合导出 22 符号） | checkpointer/runs/serialization/store/stream_bridge API | 各子包 |
| `runtime/converters.py` (~137 行) | runtime | LangChain→OpenAI 线格式（暂无生产调用方） | `langchain_to_openai_*` | json |
| `runtime/journal.py` (~383 行) | runtime | RunJournal 回调→RunEventStore | `RunJournal` | langchain_core.callbacks、events.store |
| `runtime/serialization.py` (~79 行) | runtime | LangGraph 对象→JSON 权威协议 | `serialize`, `serialize_channel_values` | — |
| `runtime/user_context.py` (~167 行) | runtime | ContextVar 用户上下文+三态解析 | `get_effective_user_id`, `resolve_user_id`, `AUTO` | contextvars |
| `runtime/checkpointer/__init__.py` | runtime | 门面 | `make_checkpointer`, `get_checkpointer` | — |
| `runtime/checkpointer/provider.py` (~193 行) | runtime | 同步 checkpointer 单例工厂 | `get_checkpointer`, `checkpointer_context` | langgraph checkpoint、config |
| `runtime/checkpointer/async_provider.py` (~161 行) | runtime | 异步 checkpointer CM 工厂 | `make_checkpointer` | provider 常量、_sqlite_utils |
| `runtime/events/__init__.py` | runtime | 事件存储工厂（memory/db/jsonl+降级） | `make_run_event_store` | store 实现、persistence.engine |
| `runtime/events/store/__init__.py` | runtime | 导出 | `RunEventStore`, `MemoryRunEventStore` 等 | — |
| `runtime/events/store/base.py` (~101 行) | runtime | RunEventStore 抽象（seq 契约+双向游标） | `RunEventStore(ABC)` | — |
| `runtime/events/store/db.py` (~287 行) | runtime | SQLAlchemy 实现（FOR UPDATE seq+trace 截断+属主过滤） | `DbRunEventStore` | sqlalchemy、RunEventRow、user_context |
| `runtime/events/store/jsonl.py` (~187 行) | runtime | JSONL 文件实现（每 run 一文件） | `JsonlRunEventStore` | json/pathlib |
| `runtime/events/store/memory.py` (~128 行) | runtime | 内存实现（默认） | `MemoryRunEventStore` | — |
| `runtime/runs/__init__.py` | runtime | 门面 | `RunManager`, `run_agent` 等 9 符号 | — |
| `runtime/runs/manager.py` (~250 行) | runtime | 运行注册表+多任务策略状态机 | `RunManager`, `RunRecord`, `ConflictError` | schemas、utils.time |
| `runtime/runs/schemas.py` | runtime | RunStatus/DisconnectMode 枚举 | `RunStatus`, `DisconnectMode` | — |
| `runtime/runs/worker.py` (~569 行) | runtime | run_agent 后台执行主循环+SSE+回滚 | `run_agent`, `RunContext` | langgraph、serialization、journal、bridge |
| `runtime/runs/store/__init__.py` | runtime | 导出 | `RunStore`, `MemoryRunStore` | — |
| `runtime/runs/store/base.py` (~95 行) | runtime | RunStore 抽象（8 方法+token 聚合） | `RunStore(ABC)` | — |
| `runtime/runs/store/memory.py` (~98 行) | runtime | 内存实现 | `MemoryRunStore` | — |
| `runtime/store/__init__.py` | runtime | 门面（async make + sync get 两套） | `make_store`, `get_store` 等 | — |
| `runtime/store/provider.py` (~189 行) | runtime | 同步 Store 单例工厂（预留 API） | `get_store`, `store_context` | langgraph.store |
| `runtime/store/async_provider.py` (~115 行) | runtime | 异步 Store CM 工厂 | `make_store` | provider 常量 |
| `runtime/store/_sqlite_utils.py` | runtime | 共享 SQLite 连接串工具 | `resolve_sqlite_conn_str`, `ensure_sqlite_parent_dir` | config.paths |
| `runtime/stream_bridge/__init__.py` | runtime | 门面 | `make_stream_bridge`, 哨兵常量 | — |
| `runtime/stream_bridge/base.py` (~73 行) | runtime | StreamBridge 抽象+StreamEvent+哨兵 | `StreamBridge(ABC)`, `END/HEARTBEAT_SENTINEL` | abc/dataclasses |
| `runtime/stream_bridge/memory.py` (~134 行) | runtime | 内存实现（共享日志+Condition 扇出） | `MemoryStreamBridge` | base |
| `runtime/stream_bridge/async_provider.py` (~56 行) | runtime | 异步工厂 CM | `make_stream_bridge` | config.stream_bridge_config |

### 5.8 sandbox/（13 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| `sandbox/__init__.py` | sandbox | 门面（仅抽象层三符号） | `Sandbox`, `SandboxProvider`, `get_sandbox_provider` | — |
| `sandbox/sandbox.py` (~94 行) | sandbox | 沙箱抽象（7 操作接口） | `Sandbox(ABC)` | search.GrepMatch |
| `sandbox/sandbox_provider.py` (~99 行) | sandbox | Provider 抽象+反射单例工厂 | `get_sandbox_provider`, `shutdown_sandbox_provider` | config、reflection |
| `sandbox/tools.py` (~1583 行) | sandbox | 7 个沙箱工具+安全门控+脱敏+截断 | `bash/ls/glob/grep/read_file/write_file/str_replace_tool`, `validate_local_tool_path`, `mask_local_paths_in_output` | sandbox 抽象、config.paths、security |
| `sandbox/security.py` | sandbox | host-bash 能力门控 | `is_host_bash_allowed`, `uses_local_sandbox_provider` | config |
| `sandbox/search.py` (~211 行) | sandbox | glob/grep 引擎（忽略表/ReDoS/符号链接防护） | `find_glob/grep_matches`, `GrepMatch`, `IGNORE_PATTERNS` | os.walk/re |
| `sandbox/middleware.py` (~84 行) | sandbox | 沙箱生命周期中间件 | `SandboxMiddleware` | sandbox_provider、thread_state |
| `sandbox/file_operation_lock.py` | sandbox | (sandbox_id,path) 粒度弱引用锁 | `get_file_operation_lock` | threading/weakref |
| `sandbox/exceptions.py` | sandbox | 沙箱异常体系（带 details） | `SandboxError` 族 7 类 | — |
| `sandbox/local/__init__.py` | sandbox | 导出 | `LocalSandboxProvider` | — |
| `sandbox/local/local_sandbox.py` (~437 行) | sandbox | 本地实现（PathMapping+双向路径翻译） | `LocalSandbox`, `PathMapping` | list_dir、search |
| `sandbox/local/local_sandbox_provider.py` (~122 行) | sandbox | 本地 Provider（映射构建+单例） | `LocalSandboxProvider` | local_sandbox |
| `sandbox/local/list_dir.py` (~69 行) | sandbox | 受限深度目录树（防符号链接逃逸） | `list_dir` | search |

### 5.9 skills/ subagents/ tools/ uploads/ utils/（33 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| `skills/__init__.py` | skills | 门面 | installer/storage/types/validation API | — |
| `skills/types.py` | skills | Skill dataclass+类别枚举+容器路径计算 | `Skill`, `SkillCategory` | — |
| `skills/parser.py` (~80 行) | skills | SKILL.md 宽松解析（frontmatter） | `parse_skill_file` | yaml、types |
| `skills/validation.py` (~87 行) | skills | 安装期严格校验（字段白名单/hyphen-case/禁尖括号） | `ALLOWED_FRONTMATTER_PROPERTIES`, `_validate_skill_frontmatter` | yaml |
| `skills/security_scanner.py` (~70 行) | skills | LLM 安全审查（fail-closed） | `scan_skill_content`, `ScanResult` | models、config |
| `skills/installer.py` (~204 行) | skills | zip 安全解压/归档定位/暂存落位/扫描编排 | `safe_extract_skill_archive`, `SkillAlreadyExistsError` 等 | security_scanner |
| `skills/storage/__init__.py` (~83 行) | skills | 反射单例工厂（三种实例化策略） | `get_or_new_skill_storage`, `reset_skill_storage` | reflection、config |
| `skills/storage/skill_storage.py` (~254 行) | skills | 抽象基类+模板流程+路径协议 | `SkillStorage(ABC)`, `load_skills` 模板 | parser/validation/installer(延迟) |
| `skills/storage/local_skill_storage.py` (~195 行) | skills | 本地文件实现（原子写/history） | `LocalSkillStorage` | skill_storage、config |
| `subagents/__init__.py` | subagents | 门面 | executor/registry API | — |
| `subagents/config.py` (~56 行) | subagents | SubagentConfig+模型解析 | `SubagentConfig`, `resolve_subagent_model_name` | AppConfig(TYPE_CHECKING) |
| `subagents/registry.py` (~165 行) | subagents | 注册表（内置+自定义+覆盖合并+可见性） | `get_subagent_config`, `list_subagents`, `get_available_subagent_names` | builtins、config、sandbox.security |
| `subagents/executor.py` (~791 行) | subagents | 执行引擎（隔离事件循环/后台任务/协作取消） | `SubagentExecutor`, `SubagentResult`, `MAX_CONCURRENT_SUBAGENTS`, 后台任务表 API | models、middlewares 构建、skills.storage |
| `subagents/builtins/__init__.py` | subagents | 内置注册表 | `BUILTIN_SUBAGENTS` | — |
| `subagents/builtins/bash_agent.py` (~50 行) | subagents | bash 专精子代理配置 | `BASH_AGENT_CONFIG` | config |
| `subagents/builtins/general_purpose.py` (~50 行) | subagents | 通用子代理配置 | `GENERAL_PURPOSE_CONFIG` | config |
| `tools/__init__.py` | tools | 门面（惰性 `__getattr__` 导出 skill_manage_tool） | `get_available_tools` | tools |
| `tools/tools.py` (~175 行) | tools | 四来源工具聚合工厂 | `get_available_tools`, `BUILTIN_TOOLS`, `SUBAGENT_TOOLS` | reflection、mcp.cache、config |
| `tools/skill_manage_tool.py` (~240 行) | tools | 技能自助管理工具（6 动作） | `skill_manage_tool` | skills.*、mcp.tools 同步壳 |
| `tools/builtins/__init__.py` | tools | 内置工具聚合出口（5 工具） | `setup_agent` 等 | — |
| `tools/builtins/clarification_tool.py` | tools | 澄清占位工具（逻辑在中间件） | `ask_clarification_tool` | langchain |
| `tools/builtins/invoke_acp_agent_tool.py` (~257 行) | tools | ACP 外部 agent 调用工具 | `build_invoke_acp_agent_tool` | acp 包(可选)、mcp.client、config.paths |
| `tools/builtins/present_file_tool.py` (~122 行) | tools | outputs 产物呈现 | `present_file_tool` | config.paths、thread_state |
| `tools/builtins/setup_agent_tool.py` (~71 行) | tools | bootstrap 落盘自定义 agent | `setup_agent` | agents_config、config.paths |
| `tools/builtins/task_tool.py` (~308 行) | tools | 子代理委派工具（轮询+事件流） | `task_tool` | subagents、sandbox.security |
| `tools/builtins/tool_search.py` (~202 行) | tools | 延迟工具发现+晋升 | `tool_search`, `DeferredToolRegistry`, `get/set/reset_deferred_registry` | langchain_core |
| `tools/builtins/view_image_tool.py` (~166 行) | tools | 图片查看（base64 入 state） | `view_image_tool` | sandbox.tools(安全函数)、thread_state |
| `uploads/__init__.py` | uploads | 门面（12 符号） | manager API | — |
| `uploads/manager.py` (~267 行) | uploads | 上传目录/清洗/去重/防穿越/防符号链接 | `claim_unique_filename`, `ensure_uploads_dir`, `open_upload_file_no_symlink`, `delete_file_safe` 等 | config.paths、user_context |
| `utils/file_conversion.py` (~316 行) | utils | 文档→Markdown 双转换器+大纲提取 | `convert_file_to_markdown`, `extract_outline`, `CONVERTIBLE_EXTENSIONS` | markitdown/pymupdf4llm(可选) |
| `utils/network.py` (~140 行) | utils | 线程安全端口分配器 | `get_free_port`, `release_port`, `PortAllocator` | socket/threading |
| `utils/readability.py` (~84 行) | utils | HTML 正文提取（Readability.js 优先） | `ReadabilityExtractor`, `Article` | readabilipy、markdownify |
| `utils/time.py` (~76 行) | utils | ISO 时间+unix 秒兼容 | `now_iso`, `coerce_iso` | re/datetime |

---

## 6. 关键函数深度解析

> 覆盖核心业务链路的 8 个函数；代码片段为节选，行号来自实际源文件。

### 6.1 `DeerFlowClient.stream` —— 嵌入式流式消费主循环（client.py:489-760）

```python
# client.py:633-648（核心循环骨架）
for item in self._agent.stream(
    state, config=config, context=context,
    stream_mode=["values", "messages", "custom"],
):
    if isinstance(item, tuple) and len(item) == 2:
        mode, chunk = item
    ...
    if mode == "custom":
        yield StreamEvent(type="custom", data=chunk); continue
    if mode == "messages":
        msg_chunk, _metadata = chunk          # LangGraph messages 模式产出 (chunk, metadata)
        if isinstance(msg_chunk, AIMessage):
            counted_usage = _account_usage(msg_id, msg_chunk.usage_metadata)
            ...
            yield self._ai_text_event(msg_id, text, counted_usage, additional_kwargs_delta)
```

**实现解读**：
1. **三模式并发订阅**（:637）：`values`（节点完成后的全量快照）、`messages`（token 级增量）、`custom`（中间件/工具经 `get_stream_writer` 发的自定义事件）。
2. **跨模式去重**（:582-588）：`streamed_ids` 记录已按 `messages` 模式发过的消息 id——`values` 快照里的同 id 消息不再重发，只防御性地补记 usage；`seen_ids` 单独防 values 模式内部重复。
3. **usage 记账**（:592-617）：同一条消息的 `usage_metadata` 在流末 chunk 与快照中出现两次，`counted_usage_ids` 保证只计一次；总量在 `end` 事件返回。
4. **additional_kwargs 增量**（:619-631）：按 id 维护已发送 key→value，只发 diff（推理内容逐步到达的场景）。
5. `chat()`（:762-792）是对 stream 的累积包装：按 id 分桶追加 delta，**只返回最后一个 AI id 的全文**（中间的规划草稿消息丢弃）；用 `dict[id, list[str]]` 末尾一次 join，避免长回复 O(n²) 字符串拼接。
6. **为什么不用 Gateway 的 run_agent**（:521-551 docstring 自述）：run_agent 是 async + astream + JSON/SSE 序列化 + StreamBridge 解耦；本方法是同步生成器、进程内直传 Python 结构——两条并行路径靠测试 `test_messages_mode_emits_token_deltas` 保持订阅模式一致。

### 6.2 `_build_middlewares` —— 19 段中间件链装配（agents/lead_agent/agent.py:238-308）

```python
# agent.py:256-262（基座 + 条件追加，节选）
resolved_app_config = app_config or get_app_config()
middlewares = build_lead_runtime_middlewares(app_config=resolved_app_config, lazy_init=True)

summarization_middleware = _create_summarization_middleware(app_config=resolved_app_config)
if summarization_middleware is not None:
    middlewares.append(summarization_middleware)
...
# agent.py:302-307（不变量：自定义在前、澄清恒最后）
if custom_middlewares:
    middlewares.extend(custom_middlewares)
middlewares.append(ClarificationMiddleware())
```

**实现解读**：
1. 基座 8 段来自共享构建器（ThreadData→Uploads→Sandbox→DanglingToolCall→LLMErrorHandling→[Guardrail]→SandboxAudit→ToolErrorHandling），保证 lead 与 subagent 链前缀一致。
2. 条件追加各自读**运行时配置**（`cfg = _get_runtime_config(config)` 合并 `configurable` 与 `context`，context 优先）：`is_plan_mode`（Todo）、`subagent_enabled`+`max_concurrent_subagents`（SubagentLimit）、`token_usage.enabled`、`summarization.enabled`、`tool_search.enabled`。
3. `ViewImageMiddleware` 用**运行时解析出的 model_name** 查 `supports_vision`（:281-285 注释：避免过期配置值）。
4. 排序约束的注释块（:228-237）：ThreadData 必须最先（后续中间件要 thread_id）；Dangling 修补须在模型看到历史前（故在 wrap_model_call 层）；Summarization 尽量早以先压缩上下文；Clarification 必须最后以拦截所有 tool call。
5. 副作用：无 IO；每次 `_make_lead_agent` 都重建整链（中间件实例不跨 agent 复用，但 LoopDetection/LLMErrorHandling 的实例内状态在 agent 生命周期内跨请求存活）。

### 6.3 `run_agent` —— Gateway 后台执行主循环（runtime/runs/worker.py:120-392）

```python
# worker.py:213-231（手动复刻 langgraph-cli 的 runtime 注入，节选）
runtime_ctx = _build_runtime_context(thread_id, run_id, config.get("context"), ctx.app_config)
_install_runtime_context(config, runtime_ctx)
runtime = Runtime(context=cast(Any, runtime_ctx), store=store)
config.setdefault("configurable", {})["__pregel_runtime"] = runtime

if journal is not None:
    config.setdefault("callbacks", []).append(journal)

runnable_config = RunnableConfig(**config)
if ctx.app_config is not None and _agent_factory_supports_app_config(agent_factory):
    agent = agent_factory(config=runnable_config, app_config=ctx.app_config)
else:
    agent = agent_factory(config=runnable_config)
```

```python
# worker.py:272-298（流式循环：单模式快路径 / 多模式解包，节选）
if len(lg_modes) == 1 and not stream_subgraphs:
    async for chunk in agent.astream(graph_input, config=runnable_config, stream_mode=single_mode):
        if record.abort_event.is_set():
            break                                    # 协作式停止
        await bridge.publish(run_id, sse_event, serialize(chunk, mode=single_mode))
else:
    async for item in agent.astream(..., stream_mode=lg_modes, subgraphs=stream_subgraphs):
        mode, chunk = _unpack_stream_item(item, lg_modes, stream_subgraphs)
        if mode is None:
            continue                                 # 无法解包的 chunk 直接丢弃
        await bridge.publish(run_id, sse_event, serialize(chunk, mode=mode))
```

**实现解读**：
1. **runtime 注入**（:213-220）：网关不经过 langgraph-cli 而直接 `agent.astream(config=...)`，必须手工把 `{thread_id, run_id, app_config}` 装进 `config["context"]` 并构造 `Runtime` 塞进 `configurable["__pregel_runtime"]`（langgraph 1.1+ 的 `parent_runtime.merge` 机制），否则中间件/工具拿不到 `runtime.context`。
2. **工厂适配**（:228-231）：`inspect.signature` 探测 agent_factory 是否接受 `app_config`（`_agent_factory_supports_app_config`，lru_cache(128)），兼容注入配置与旧签名两种工厂。
3. **模式映射**（:248-258）：`messages-tuple→messages`；`events` 显式跳过（Python 公共 API 下 astream_events 无法与 values 快照共存，模块 docstring :10-13 说明了 JS 官方服务器的差异）；空结果兜底 `["values"]`。
4. **终态三分支**（:301-320）+ `except CancelledError`（:322-340）：rollback → `set_status(error, "Rolled back by user")` + 快照恢复（新 checkpoint id + pending_writes 回放）；interrupt → interrupted；正常 → success。回滚失败仅 warning 不改变已设状态。
5. **finally**（:355-392）：journal.flush → `update_run_completion`（token 统计落库）→ 从 checkpoint `channel_values.title` 同步线程标题 → 线程状态（success→idle 否则透传）→ `publish_end` + `create_task(cleanup(run_id, delay=60))`。

### 6.4 `MemoryStreamBridge.subscribe` —— 共享日志扇出与回放（runtime/stream_bridge/memory.py:85-123）

```python
# memory.py:94-116（节选，结构还原）
next_offset = self._resolve_start_offset(stream, last_event_id)   # Last-Event-ID → 起始游标
while True:
    async with stream.condition:
        if next_offset < stream.start_offset:                     # 慢消费者：事件已被裁剪
            next_offset = stream.start_offset                     # 跳到最早保留事件（丢旧保活）
        local_index = next_offset - stream.start_offset
        if local_index < len(stream.events):
            event = stream.events[local_index]
            next_offset += 1
        elif stream.ended:
            yield END_SENTINEL; return
        else:
            try:
                await asyncio.wait_for(stream.condition.wait(), timeout=heartbeat_interval)
            except TimeoutError:
                yield HEARTBEAT_SENTINEL                          # 仅空闲时心跳
```

**实现解读**：
1. **设计核心**：不是"每订阅者一条队列"，而是每 run 一份**有界事件日志**（`events` 列表 + `start_offset` 全局偏移量）+ `asyncio.Condition` 广播——`publish` 锁内 append + `notify_all()`，所有订阅者同时唤醒、各自持独立 `next_offset` 游标读取。天然多订阅者扇出、消费者速率互不阻塞。
2. **有界窗口**：`publish` 时 `len(events) > queue_maxsize`（默认 256）从头裁剪并推进 `start_offset`，偏移量仍是全局单调的，Last-Event-ID 回放（`_resolve_start_offset`，:51-64）与慢消费者检测都基于它。
3. **心跳语义**：`wait_for(condition.wait(), timeout)` 超时才发心跳哨兵——有事件流动时永不心跳。
4. **yield 在 `async with condition` 块外**（:120-123 相对 :97 缩进退层）：消费者处理帧期间不持锁，生产不被慢 SSE 消费者阻塞（有界窗口兜底）。
5. **约束**：`asyncio.Condition` 绑定事件循环 → 单进程单 loop；`close()` 不唤醒等待者（进程关闭场景语义缺口）；只订阅不生产的 run 依赖 cleanup 回收防 dict 泄漏。

### 6.5 `MemoryUpdater._apply_updates` —— LLM 输出落地算法（agents/memory/updater.py:502-584）

**实现解读**（无 IO 的纯状态合并，分四步）：
1. **user/history 六节**（:522-539）：仅当 `shouldUpdate` 为真且 `summary` 非空才覆盖，同时盖 `updatedAt` 时间戳——LLM 的"不改"意见不会清空已有内容。
2. **factsToRemove**（:542-544）：按 id 集合差集过滤。
3. **newFacts**（:549-575）：先过 `fact_confidence_threshold`（默认 0.7，低于即丢弃）；content strip 后以 `_fact_content_key`（`strip().casefold()`，:267-273）**大小写不敏感去重**；构造 fact 条目（`id="fact_"+uuid8`、`source=thread_id` 溯源、correction 类可带 `sourceError` 记录"错误做法"）。
4. **容量截断**（:577-584）：超过 `max_facts`（默认 100）按 confidence 降序保留 top。

配套机制：`_finalize_update`（:347-364）先 `copy.deepcopy(current_memory)` 再就地应用（save 失败不污染缓存对象）、剥 ```` ``` ```` 围栏后 `json.loads`；`update_memory`（:441-500）**事件循环感知**——运行中 loop 内提交到专用 `ThreadPoolExecutor(4)` 阻塞等待（跨 loop 复用 httpx 连接会崩，issue #2615）；`_strip_upload_mentions_from_memory`（:244-264）用窄匹配正则从 summary/facts 抹掉"上传事件"句子（上传是会话级的，进长期记忆会导致未来会话找不存在的文件）。

### 6.6 `task_tool` —— 子代理委派与轮询回传（tools/builtins/task_tool.py:96-308）

**实现解读**：
1. **防递归**（:159-167）：以 `subagent_enabled=False` 调 `get_available_tools`——子代理自己的工具集里没有 `task`。
2. **上下文传递**（:127-141,169-181）：从 `runtime.state` 取 `sandbox/thread_data`（子代理与父共享同一沙箱）、从 context/config 取 thread_id、从 metadata 取 model_name/trace_id——`SubagentExecutor` 据此构造子代理。
3. **后台执行 + 5 秒轮询**（:183-234）：`execute_async(prompt, task_id=tool_call_id)`（以 tool_call_id 作任务 id 便于前端关联）登记进模块级 `_background_tasks` 并提交调度线程池；主协程循环 `get_background_task_result`：
   - 新增 AI 消息 → `get_stream_writer()` 发 `task_running` 事件（前端实时渲染子代理思考过程）；
   - 终态 → `task_completed/failed/cancelled/timed_out` 事件 + **`"Task Succeeded. Result: {result.result}"` 纯文本作为工具返回值**回到主代理对话（子代理中间消息不进主上下文——隔离即裁剪）；
   - 轮询上限 `(timeout_seconds+60)//5`（:192）兜底线程池超时失效。
4. **取消传播**（:271-308）：`CancelledError` → `request_cancel_background_task`（置 `cancel_event`，子代理在下个迭代边界停止）→ 调度延迟清理协程（每 5s 查终态，超上限放弃并 warning）→ re-raise。

### 6.7 `create_chat_model` —— thinking 禁用四级级联（models/factory.py:50-156）

**实现解读**（路由部分见 4.5，此处展开 thinking=False 分支 :93-112）：
```python
# 优先级：显式 when_thinking_disabled > extra_body.thinking > chat_template_kwargs > 原生 thinking
```
1. 显式 `when_thinking_disabled`：全量覆盖 settings——模型声明了禁用参数即最优先。
2. `extra_body.thinking.type` 存在（OpenAI 兼容网关，如 Qwen3 经网关）：注入 `extra_body={"thinking": {"type": "disabled"}}` 且 `reasoning_effort="minimal"`。
3. `extra_body.chat_template_kwargs` 含 thinking 键（vLLM 直连）：`_vllm_disable_chat_template_kwargs` 把 `thinking/enable_thinking` 映射为 `False`。
4. 原生 `thinking.type`（langchain-anthropic）：`thinking={"type": "disabled"}`。
该级联让同一个开关适配四类后端的禁用方言；同理 `thinking_enabled=True` 要求 `supports_thinking` 并应用 `when_thinking_enabled` 覆盖。

### 6.8 `LoopDetectionMiddleware._stable_tool_key` —— 循环检测的规范化哈希（agents/middlewares/loop_detection_middleware.py:65-126）

**实现解读**：
- `read_file`：key = `path + 行号按 200 行分桶`（`(start-1)//200`）——相邻窗口的滚动读取合并为同 key，既容忍"顺序读大文件"又不误判。
- `write_file/str_replace`：对**全量 args** `json.dumps(sort_keys=True)`——内容敏感，同路径不同内容不被误合并。
- 其他工具：只取显著字段 `(path,url,query,command,pattern,glob,cmd)`。
- 整组调用哈希：`name:key` 列表**排序后**序列化再 md5[:12]——顺序无关，同一多重集的排列视为同一循环。
- 双层判定：哈希层滑动窗口（20 条）内同 key ≥3 警告、≥5 硬停；频次层按工具类型累计 ≥30/≥50——捕获"每次读不同文件"这类哈希层漏检。硬停动作是 `model_copy` 替换最后一条 AIMessage：清 tool_calls、剥 `additional_kwargs.tool_calls/function_call`、`finish_reason→stop`，迫使模型产出纯文本终答（P0 目标是不拖到 recursion_limit 才被杀）。

---

## 7. 端到端调用链分析

### 7.1 场景一：网关 SSE 一次对话（HTTP → 落库/回滚，完整文件+函数级链路）

**创建与执行**：
1. `POST /threads/{tid}/runs`（app/gateway/routers/thread_runs.py，范围外）→ `services.py:253 RunManager.create_or_reject(multitask_strategy=...)`
   - `manager.py:181-211`：锁内检查 inflight；reject+inflight → `ConflictError`；interrupt/rollback → 逐个 `abort_event.set()+task.cancel()+置 interrupted`
   - `manager.py:54-70 _persist_to_store` → `RunRepository.put`（persistence/run/sql.py:66-99）落 `runs` 表（status=pending）
2. `services.py:295` 启动 `asyncio.Task(run_agent(...))`；SSE 端点 `services.py:318-349 sse_consumer` 读 `Last-Event-ID` 头 → `bridge.subscribe(run_id, last_event_id=...)` 挂起
3. `run_agent`（worker.py:120）：
   - `:162-176` 构造 `RunJournal`（try 块内，DB 异常也保证 end 事件发布）→ `:179 set_status(running)` → `:182-197` `checkpointer.aget_tuple + deepcopy` 捕获 pre-run 快照
   - `:217-220` 注入 runtime context（thread_id/run_id/app_config）
   - `:228-231 agent_factory(config, app_config)` = `make_lead_agent`（agents/lead_agent/agent.py:311）
     - `:326-333` 读运行时配置；`:340 _resolve_model_name` 三级回退
     - `create_chat_model`（models/factory.py:50）→ 反射 Provider → tracing callbacks
     - `get_available_tools`（tools/tools.py:36）→ 四来源聚合去重
     - `apply_prompt_template`（lead_agent/prompt.py:727）→ 记忆/技能/子代理/日期段
     - `_build_middlewares`（agent.py:238）→ 19 段链
     - `langchain.agents.create_agent(..., state_schema=ThreadState)`
   - `:234-243` 挂 checkpointer/store/interrupt 节点；`:225` callbacks 追加 RunJournal
   - `:272-298` `agent.astream` 循环：每 chunk 查 `abort_event` → `serialize(chunk, mode)`（runtime/serialization.py:67）→ `bridge.publish`
     - 图内一轮：before_model 链（Summarization→Todo→ViewImage→DanglingToolCall(wrap)→DeferredFilter(wrap)→LLMErrorHandling(wrap)）→ LLM 流式 → after_model 链（Todo 拦截→Title→TokenUsage→SubagentLimit→LoopDetection）→ ToolNode（wrap_tool_call 链：SandboxAudit→Guardrail→Clarification→ToolErrorHandling→工具本体，工具内 `ensure_sandbox_initialized` 惰性获取沙箱）→ … → 无 tool_calls 结束
     - RunJournal 同步记录 `llm.human.input / llm.ai.response / llm.tool.result`，缓冲达 20 条 `_flush_sync` → `DbRunEventStore.put_batch`（thread 级 seq 事务分配）
4. 结束（worker.py:301-341 + finally :355-392）：
   - rollback 分支：`set_status(error)` + `_rollback_to_pre_run_checkpoint`（:411-501：`empty_checkpoint()` 新 id 写回 + pending_writes 按 task 回放）
   - `journal.flush()` → `run_manager.update_run_completion` → `RunRepository.update_run_completion`（token 七字段 + 首末消息落 runs 表）
   - checkpoint `channel_values.title` → `thread_store.update_display_name`；run 状态 → 线程 status
   - `bridge.publish_end` → `create_task(bridge.cleanup(run_id, delay=60))`
5. SSE 消费端收到 `END_SENTINEL` → 发送 `end` 帧并关闭；断连时按 `DisconnectMode`（cancel/continue）决定是否 `run_manager.cancel`

**时序图**：

```
客户端        Gateway(范围外)      RunManager       run_agent(worker)     make_lead_agent      LangGraph图/LLM     StreamBridge      DB/EventStore
  │ POST run ──► services ──► create_or_reject ─────────────┐
  │                          │   └─ RunRepository.put ──────────────────────────────────────────────────────────────────► runs表(pending)
  │ ◄─ 202 {run_id}          │        └─ Task(run_agent) ──► │
  │ GET /runs/{id}/stream ──►│            │ set_status(running)─► ───────────────────────────────► runs表(running)
  │                          │            │ 快照 pre-run checkpoint ─────────────────────────────────────────────────► checkpointer
  │                          │            │── agent_factory(config,app_config) ──► │ 模型/工具/提示/19中间件
  │                          │            │◄───────────── CompiledStateGraph ──────┤
  │                          │            │── astream(input) ────────────────────► │ ── before_model 链 ─► LLM
  │                          │            │◄── chunk(values/messages) ────────────┤ │        ▲   │token delta
  │                          │            │── publish(run_id,mode,data) ──────────────────────────►│   │
  │ ◄─ SSE: metadata/values/messages ─────┼────────── subscribe 游标读取 ←──────────┤(空闲15s→心跳)
  │                          │            │        ToolNode: audit→guardrail→tool │ │
  │ ◄─ custom(task_running/llm_retry…)    │◄─ get_stream_writer 事件 ─────────────┤ │
  │                          │            │        RunJournal 缓冲→put_batch ───────────────────────────────────────► run_events表
  │                          │            │ set_status(success) ─────────────────► │ runs表(success)
  │                          │            │ journal.flush→update_run_completion ─────────────────────────────────────► token统计
  │                          │            │ publish_end + cleanup(60s) ───────────► │
  │ ◄─ SSE: end 帧，关闭     │            ▼
```

### 7.2 场景二：嵌入式客户端一次多轮对话（进程内）

`DeerFlowClient.chat("...", thread_id=...)`（client.py:762）
→ `_get_runnable_config`（:196，configurable 塞 thread_id/model/thinking/plan/subagent）
→ `_ensure_agent`（:210-252，配置 key 变化才重建：`create_chat_model` + `_get_tools` + `_build_middlewares` + `apply_prompt_template` + `create_agent(state_schema=ThreadState, checkpointer=get_checkpointer())`）
→ `stream()`（:489）三模式消费（见 6.1）
→ 首次工具调用时 `ensure_sandbox_initialized`（sandbox/tools.py:1051）惰性 `provider.acquire(thread_id)`
→ 对话结束 `MemoryMiddleware.after_agent` → `MemoryUpdateQueue.add`（30s 防抖）
→ Timer 到期 `_process_queue` → `MemoryUpdater.update_memory`（线程池内同步 LLM）→ `FileMemoryStorage.save` 原子写 `users/{uid}/memory.json`
→ 下轮 `stream` 时 `apply_prompt_template → _get_memory_context`（mtime 缓存读回 + 2000 token 预算注入 `<memory>`）。

---

## 8. 横切机制说明

### 8.1 错误处理与异常体系
- **LLM 调用**：`LLMErrorHandlingMiddleware`（middlewares/llm_error_handling_middleware.py:208-298）——瞬时错误（408/409/425/429/5xx + 中英文"繁忙"文案）指数退避重试 ≤3 次（优先 Retry-After 头，封顶 8s）；quota/auth 不重试；**熔断器**（阈值 `app_config.circuit_breaker`：5 次失败/60s 恢复，三态+单探针）OPEN 时立即降级为友好 AIMessage；每次重试经 `get_stream_writer` 发 `llm_retry` 事件。Provider 内部另有重试（Claude 429/500、Codex 429/500/529）。
- **工具执行**：`ToolErrorHandlingMiddleware`（wrap_tool_call）把异常转 `status="error"` 的 ToolMessage（detail 截 500 字符）让循环优雅继续；沙箱工具自身再包一层 catch 返回 `"Error: ..."` 字符串（双保险）。
- **控制流信号透传约定**：所有 wrap_* 都对 LangGraph 的 `GraphBubbleUp`（interrupt/pause/resume）原样 re-raise，不打断人机协同断点。
- **读路径 fail-open / 写路径 fail-loud**：记忆上下文异常返回空串（prompt.py:568-570）、memory.json 损坏返回空骨架（storage.py:108-117）、LLM JSON 解析失败仅 warning（updater.py:434-436）；而记忆 CRUD 失败抛 OSError/KeyError/ValueError。
- **沙箱异常体系**：`SandboxError` 族 7 类（exceptions.py），全部携带结构化 details。
- **Run 级**：worker 的 except Exception → `set_status(error)` + 向 bridge 发 `error` 事件；RunStore 持久化失败 best-effort（仅告警，不杀运行）。

### 8.2 日志与可观测
- 常规日志：标准 `logging`，`apply_logging_level`（app_config.py:63-78）只调 `deerflow`/`app` 两个 logger；结构化审计日志（SandboxAudit 的 JSON 行）。
- **RunJournal**（runtime/journal.py:37）：LangChain 回调 → RunEvent（`run.start/end/error`、`llm.human.input/ai.response/error/tool.result`、`middleware:*`），写缓冲+批量刷写（阈值 20，in-flight 跳过防并发写 SQLite，失败回填重试）。
- **Tracing**：`build_tracing_callbacks()` 挂 LangSmith tracer / Langfuse handler 到每个 model 实例（models/factory.py:152-156）；标题/摘要等辅助 LLM 调用用 `run_name`+tag 区分（`title_agent`、`middleware:summarize`、`security_agent`、`memory_agent`）。

### 8.3 配置管理（多环境）
- 三源：`config.yaml`（AppConfig，mtime 热重载）+ `extensions_config.json`（MCP/技能，显式 reload）+ 环境变量（`.env` 经 load_dotenv；`$VAR` 占位符在加载期展开——app_config 缺变量抛错、extensions 填空串）。
- ContextVar 覆盖栈（`push/pop_current_app_config`）支持按请求/协程注入配置（优先级最高）。
- 目录类环境变量：`DEER_FLOW_PROJECT_ROOT/HOME/HOST_BASE_DIR/CONFIG_PATH/EXTENSIONS_CONFIG_PATH/SKILLS_PATH/SANDBOX_HOST/SANDBOX_BIND_HOST`。
- 双通道单例（AppConfig 字段 + 模块级 get_xxx）由 `from_file` 同步刷新。

### 8.4 权限与安全控制
- **用户数据隔离**：`runtime/user_context.py` ContextVar 三态（AUTO/str/None）——数据库属主过滤（4 个 Repository + DbRunEventStore）与文件分桶（`get_effective_user_id()` → `users/{uid}/...`，无用户落 default 桶）双轨。
- **沙箱防线**（自内向外）：挂载内 resolve+relative_to 防逃逸（local_sandbox.py:136-139）→ 工具层虚拟路径白名单+拒 `..`（tools.py:585-636）→ bash 命令白名单/分词校验（:891-930，自述 best-effort）→ host-bash 默认禁用（security.py:35-45）→ 输出脱敏回掩（宿主路径零泄漏）→ 审计中间件分级拦截。
- **上传防护**：O_NOFOLLOW + lstat/fstat 双校验 + 硬链接数==1（uploads/manager.py:118-165）。
- **技能防护**：安装期字段白名单/hyphen-case/禁尖括号 + zip 穿越与炸弹防御 + LLM 安全扫描 fail-closed（block 兜底；`scripts/` 必须 allow）。
- **护栏**：guardrails Provider（OAP 对齐）在工具执行前裁决，默认 fail-closed。
- **认证**：users 表 + app 层 JWT/bcrypt（范围外），`token_version` 支持吊销。

### 8.5 并发与异步处理模式
- **防抖队列**（memory）：滑动窗口 Timer + 按 thread 合并 + 单飞处理。
- **隔离事件循环**（subagents）：持久守护线程 loop，同步 API 在事件循环内被调用时投递执行；`context.run` 保持 ContextVar。
- **同步跑 async 的三态适配**（mcp/cache.py:82-130）：loop 运行中→线程池 asyncio.run；未运行→run_until_complete；无→asyncio.run。
- **事件循环感知的阻塞调度**（memory updater）：运行中 loop 内提交专用线程池。
- **协作式取消**：Run 的 abort_event（worker 每 chunk 检查）与子代理 cancel_event（迭代边界检查）。
- **线程安全原语**：双检锁单例（memory storage/tracing/skills storage）、WeakValueDictionary 锁（文件操作/技能管理）、PortAllocator、threading.Lock 串行容器 shell。
- **批量刷写防并发**：RunJournal 的 in-flight 跳过 + 事件 seq 的事务分配 + SQLite 唯一约束兜底。

### 8.6 缓存
- MCP 工具会话缓存（进程级 + extensions mtime 失效，mcp/cache.py）。
- enabled-skills 后台缓存（版本号收敛 + lru_cache 提示段，lead_agent/prompt.py:20-142）。
- 记忆 mtime 缓存（FileMemoryStorage）。
- warm pool（容器沙箱保温复用）。
- agent 惰性重建（client 的 config key 比对）。

### 8.7 定时/后台任务
- 容器沙箱 idle checker 守护线程（60s 周期，销毁前锁内二次确认）+ 孤儿对账（启动时）。
- 记忆防抖 Timer（daemon）；subagent 调度线程池(3) + atexit 注册（executor/线程池/MCP 均注册 atexit 关闭）。
- bridge.cleanup 延迟 60s（`create_task`）；RunManager.cleanup(delay=300) 已实现但网关未调用。
- **无 cron 类定时任务**；`RunStore.list_pending` 为未来的僵尸 run 清理预留（暂无消费者）。

---

## 9. 外部依赖说明

| 依赖名 | 用途 | 在哪些文件中使用 | 替代/关键实现 |
|---|---|---|---|
| `langchain` (>=1.2.15) | Agent 核心：`create_agent`/`AgentMiddleware`/内置 Summarization、TodoList 中间件 | agents/ 全部、subagents/executor.py、tools/ | 框架基石，不可替代 |
| `langgraph` (>=1.1.9) | 图执行、checkpointer/store、Runtime 注入、Command | runtime/、thread_state、middlewares、sandbox/tools | 不可替代 |
| `langchain-openai/anthropic/deepseek/google-genai` | 各家官方 ChatModel | models/（基类与 patched_*） | 经 `use` 字段可换任意 BaseChatModel 子类 |
| `pydantic` (>=2.12) | 全部配置与 extensions 模型 | config/、guardrails、tools | — |
| `sqlalchemy[asyncio]` + `aiosqlite`/`asyncpg` | 应用数据 ORM | persistence/、runtime/events/store/db.py | thread_meta 有 LangGraph Store 实现可替换 SQL |
| `alembic` | 迁移（versions 目前为空，建表靠 create_all） | persistence/migrations/ | — |
| `langgraph-checkpoint-sqlite/postgres` | checkpointer/store 后端 | runtime/checkpointer、runtime/store | memory 后端零依赖 |
| `langchain-mcp-adapters` | MCP 工具加载（可选依赖，缺失降级空列表） | mcp/tools.py | — |
| `agent-client-protocol` | ACP 外部 agent 子进程调用（可选依赖） | tools/builtins/invoke_acp_agent_tool.py | — |
| `agent-sandbox` | AIO 容器 HTTP 客户端 | community/aio_sandbox/aio_sandbox.py | LocalSandbox 为本地替代 |
| `httpx` / `requests` | HTTP 客户端 | mcp/oauth、serper、jina、infoquest、codex_provider、backend.py | — |
| `tiktoken` | 记忆注入 token 计数（未装回退 `len//4`） | agents/memory/prompt.py | — |
| `markitdown[all,xlsx]` / `pymupdf4llm`(可选) | 文档→Markdown | utils/file_conversion.py | 双转换器互为回退 |
| `readabilipy` + Node Readability.js | HTML 正文提取 | utils/readability.py | 纯 Python 模式回退 |
| `markdownify` | HTML→Markdown | utils/readability.py | — |
| `ddgs` / `tavily-python` / `firecrawl-py` / `exa-py` | 搜索 SDK | community/ 各工具包 | 同名工具互换（web_search/web_fetch 共名） |
| `langfuse` (>=3.4) | LLM 观测 | tracing/factory.py | LangSmith 经 langchain_core 内置 |
| `duckdb` | 依赖声明（供 skills 相关分析场景预留） | pyproject 声明，包内无直接 import | 推断为间接/预留（见存疑清单） |

---

## 10. 新人上手路径

### 10.1 建议阅读顺序（由浅入深）
1. `config/app_config.py` + `config/paths.py` —— 理解配置体系与数据目录/虚拟路径（一切行为的地基）。
2. `agents/thread_state.py`（56 行）+ `agents/factory.py` —— 最小可组装视图：状态 schema 与 14 段声明式链。
3. `models/factory.py` + `reflection/resolvers.py` —— 理解 "use 字符串 → 反射实例化" 插件化模式（后续 sandbox/skills/guardrails 全同构）。
4. `agents/lead_agent/agent.py` + `prompt.py` —— 生产链路真实组装（19 段链 + 系统提示）。
5. `agents/middlewares/` 按装配顺序逐个读（先读 `tool_error_handling_middleware.py`——它是共享链构建器）。
6. `sandbox/sandbox.py` → `sandbox/local/` → `sandbox/tools.py`（挑 bash_tool 与 write_file_tool 精读安全链）。
7. `tools/tools.py`（四来源聚合）→ `tools/builtins/task_tool.py` → `subagents/executor.py`。
8. `runtime/user_context.py` → `runtime/serialization.py` → `runtime/stream_bridge/` → `runtime/runs/worker.py`。
9. `persistence/`（engine → 任一 Repository）→ `runtime/events/store/`。
10. `agents/memory/`（一个完整子系统样例）→ `skills/` → `mcp/` → `community/`（按需）。
11. `client.py` —— 嵌入式视角把全链路串一遍。

### 10.2 常见修改需求的切入点
- **改/加一个 LLM 后端**：config.yaml `models:` 加条目（自定义类放 `models/`，`use` 指向它）；无需改工厂代码。
- **加一个工具**：实现 `@tool`（参考 `community/*/tools.py`），config.yaml `tools:` 加 `{name, group, use: "模块:工具变量"}`；若需条件注入改 `tools/tools.py` 的 builtin 分支。
- **加一个中间件**：实现 AgentMiddleware 钩子；lead 链改 `agents/lead_agent/agent.py:_build_middlewares`（注意排序注释 :228-237 与 "Clarification 恒最后" 不变量）；SDK 链改 `factory.py:_assemble_from_features` 并可用 `@Next/@Prev` 声明位置。
- **加一个搜索源**：在 `community/<provider>/tools.py` 写 `@tool("web_search")`（保持共名互斥约定与 `"Error: ..."` 错误风格）。
- **加一个子代理类型**：config.yaml `subagents.custom_agents:` 加条目（description/system_prompt/tools/model）；或代码方式加 `subagents/builtins/` 并注册 `BUILTIN_SUBAGENTS`。
- **改持久化表结构**：改 `persistence/*/model.py` → 生产环境补 alembic 迁移（当前 versions 为空，开发靠 create_all）。
- **加配置项**：小——找对应 `config/*_config.py` 加字段；新域——新建模块并接入 `AppConfig.from_file` 的单例刷新序列（app_config.py:161-201）。
- **改系统提示**：`agents/lead_agent/prompt.py` 的 `SYSTEM_PROMPT_TEMPLATE`（:341-530）与各条件段构造函数。

### 10.3 隐性约定与易踩坑点
1. **ClarificationMiddleware 必须是链尾**——两条建链路径都有不变量修复代码；自定义中间件插错位置会被强制调整。
2. **循环依赖靠函数内延迟 import** 是常态——新增模块 import 报环时，学 `client.py:257` 的写法而不是重构。
3. **`BASIC_MODEL` 已不存在**：默认模型 = `config.yaml models[0]`；别按旧版文档找环境变量覆盖。
4. **本地沙箱默认禁 host bash**：bash 工具直接返回禁用消息；需 `sandbox.allow_host_bash: true`（仍自述非安全边界）。
5. **ContextVar 不跨线程**：Timer/线程池里的代码拿不到用户上下文——memory 队列的解法是**入队时显式捕获 user_id**；后台任务需要干净上下文时用 `contextvars.copy_context()`。
6. **aiosqlite 不能绑定原生 UUID**：属主列是 String(64)，边界处必须 `str(user.id)`（user_context.py:160-166 有专门注释；漏掉会静默回滚导致 worker 挂起）。
7. **`timeout` 是死枚举、`list_by_thread` 注释与实现不一致**（manager.py:118-120 声称 newest-first 但未反转）——读代码勿轻信注释，以本报告行号引用为准的同样要复核。
8. **JSONL 事件存储是同步文件 IO**（阻塞事件循环）且多进程 seq 会冲突；生产多副本请用 db 后端。
9. **StreamBridge/checkpointer 单例绑定事件循环**：MemoryStreamBridge 与同步 `get_checkpointer` 不要跨 loop 复用；redis 桥与 `get_store` 同步族均为预留/未接线 API。
10. **extensions_config.json 无热重载**：改完必须 `reload_extensions_config()`（skill_manage_tool 与网关路由都会顺带刷新技能提示缓存）。
11. **两个文件行数陷阱**：`sandbox/tools.py` 实际约 1583 行（部分统计口径得 1294）、`subagents/executor.py` 约 791 行——检索行号时以实际文件为准。
12. **上传产物联动**：删除可转换文件会连带删同名 `.md`；`<uploaded_files>` 会被记忆系统过滤，不会进长期记忆。
13. **worker 的 run 状态值是 `success/error/interrupted`**（非 succeeded/failed/cancelled），对接前端时勿想当然。

---

## 附录 A：全报告总目录（章节 ↔ 批次对照）

| 章节 | 内容 | 所在批次 |
|---|---|---|
| 术语表 / 批次计划 | 概念与交付计划 | 批次 1 |
| 第 1 章 | 项目概述（用途/技术栈/运行方式） | 批次 1 |
| 第 2 章 | 整体架构（分层图/依赖/核心数据流） | 批次 1 |
| 第 3 章 | 目录结构详解 | 批次 1 |
| 第 5 章 | 文件清单总表（195+1 文件全覆盖） | 批次 1 |
| 第 4 章 4.1~4.4 | 基础层：config / reflection / utils / uploads | 批次 2 |
| 第 4 章 4.5~4.8 | 能力层：models+tracing / sandbox / community / mcp | 批次 3 |
| 第 4 章 4.9~4.12 | 能力层：skills / tools / guardrails / subagents | 批次 4 |
| 第 4 章 4.13~4.15 | 组装层：agents 核心 / middlewares / memory | 批次 5 |
| 第 4 章 4.16~4.17 | 运行时层：persistence / runtime | 批次 6 |
| 第 6 章 | 关键函数深度解析（8 个函数带行号片段） | 批次 7 |
| 第 7 章 | 端到端调用链（网关 SSE + 嵌入式两场景） | 批次 7 |
| 第 8~10 章 | 横切机制 / 外部依赖 / 新人上手 | 批次 7 |
| 附录 B/C | 完成度自检 / 存疑清单 | 批次 7（收尾） |

## 附录 B：完成度自检表

| 检查项 | 结果 |
|---|---|
| 生产 .py 文件数 | 195（PowerShell 递归统计） |
| 第 5 章覆盖数 | 195 个 .py + `migrations/alembic.ini` = **196 行，全覆盖** |
| 模块级分析覆盖 | 17 个顶层目录/模块全部含 4.x 小节（config、reflection、utils、uploads、models+tracing、sandbox、community、mcp、skills、tools、guardrails、subagents、agents 核心、agents/middlewares、agents/memory、persistence、runtime）+ 根 client.py（第 6.1/7.2 节展开） |
| 函数级深度解析 | 8 个核心函数（6.1~6.8）+ 各模块小节内关键函数签名与行号 |
| 交叉验证 | 入口链（langgraph.json → make_lead_agent → create_agent）、网关链（run_agent → bridge → SSE）、嵌入式链（client.stream）均沿调用方代码走通 |
| 未覆盖说明 | `persistence/migrations/versions/.gitkeep`（空占位）；`app/`（网关）、`tests/`、`docs/`、`scripts/` 按排除范围未做逐文件分析，仅作调用方引用 |

## 附录 C：存疑与待确认清单

| # | 事项 | 依据 | 性质 |
|---|---|---|---|
| 1 | `duckdb>=1.4.4` 在 pyproject 声明但包内无直接 import | 全包 grep 无 `import duckdb` | 推断：间接/预留依赖（可能供 skill 脚本或规划中功能） |
| 2 | `kubernetes>=30` 同上，包内无 import | pyproject.toml:12 | 推断：为远程沙箱 provisioner 场景预留 |
| 3 | `RunStatus.timeout` 全仓库无赋值点 | schemas.py:13 | 事实：死枚举（预留） |
| 4 | `RunManager.list_by_thread` 注释称 newest-first 但实现未反转 | manager.py:118-120 | 事实：注释与实现不一致（疑似 bug 或依赖插入序） |
| 5 | `runtime/converters.py` 无生产调用方 | grep 仅 tests 引用；journal.py:8-13 docstring 自述未接线 | 事实：预留模块 |
| 6 | `runtime/store/provider.py` 同步 get_store/store_context 无生产调用 | grep 确认 | 事实：预留 API |
| 7 | `utils/readability.py` 的 `Article.url` 声明未赋值，`to_message` 会 AttributeError | readability.py:14/:44 | 事实：潜在 bug（现调用方只调 to_markdown 未触发） |
| 8 | `MemoryStreamBridge.close()` 不唤醒等待中的订阅者 | memory.py:131-133 | 事实：关闭语义缺口（进程退出场景无碍） |
| 9 | worker.py:150/152 重复 `journal = None` 两行 | 源码 | 事实：冗余赋值（无功能影响） |
| 10 | `clarification_middleware._is_chinese` 定义未调用 | clarification_middleware.py:47-56 | 事实：死代码 |
| 11 | skill_manage_tool 的同步壳依赖 `mcp/tools._make_sync_tool_wrapper` 私有函数 | skill_manage_tool.py:15 | 事实：跨模块私有耦合（重构敏感点） |
| 12 | `UserRow` 的 oauth 部分唯一索引用 `sqlite_where`，仅 SQLite 生效 | user/model.py:51-59 | 事实：postgres 下唯一性语义差异需迁移时注意 |
| 13 | `thread_meta` SQL 实现的 metadata 过滤为 Python 端大窗口过滤 | thread_meta/sql.py:126-134（TODO 注释） | 事实：已知性能债，Phase 2 计划换 JSON 操作符 |
| 14 | 行数口径差异（如 sandbox/tools.py 1294 vs 1583） | 不同统计工具对空行/编码处理不同 | 提示：引用行号时以实际文件为准 |

---

*报告完。生成于 2026-10-08；基于 `deer-flow-backend-2.0-m1-rc0` 源码静态分析与交叉验证。*
