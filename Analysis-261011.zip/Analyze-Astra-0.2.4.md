# Astra 0.2.4 生产项目代码分析报告

> **分析对象**：`Astra-0.2.4/`（github.com/matrixorigin/Astra，v0.2.4，Apache-2.0）
> **报告生成日期**：2026-10-07
> **分析方法**：纯静态阅读（未执行构建与运行）；覆盖全部生产源代码文件的清单级分析 + 核心业务链路的函数级深度解析；所有结论均引用 `文件路径:行号`（相对 `Astra-0.2.4/` 仓库根）。
> **报告规模说明**：本项目纳入范围的生产源文件超过 1400 个（Rust ≈1252 个、约 120 万行；TypeScript 189 个），远超单次输出容量，已按「分批输出策略」以 9 个批次组织生产并汇编为本文件一次性交付。各批次状态见下方批次计划表。

---

## 0. 术语表

| 术语 | 含义 |
|---|---|
| **Turn（回合）** | 一次"用户输入 → 模型决策 → 工具执行 → 助手输出"的完整循环，是编排的最小单位（实现于 `astra-turn-core`） |
| **Run（运行）** | 一次可控的执行尝试，拥有所有权与终态（queued/running/waiting/paused/blocked/cancelling/cancelled/completed/failed） |
| **Session（会话）** | 跨界面（CLI/TUI/Web/SDK）持久的用户-代理关系载体 |
| **Work（工作）** | 长生命周期目标，超越单次聊天，带版本化任务图（`/v1/works` API） |
| **Context Pipeline（上下文管线）** | 在每次模型边界前，把系统契约/历史/记忆/工具结果等结构化输入装配为有预算上下文的管线（Plan→Bind→Optimize→Serialize，`astra-turn-core/src/context/pipeline.rs`） |
| **Admission（准入）** | 工具可见性与执行共用的生命周期：Projection → Admission → Execution → Result；含权限裁决与 LLM 提供商限流准入 |
| **Runner / User Runner / Edge** | Runner=执行边界契约；User Runner=绑定用户身份与工作区的 Runner；Edge=把 Runner 部署在私有环境旁的拓扑。当前由 `astra-edge` 与 CLI 本地运行时承担 |
| **BYOK** | Bring Your Own Key：用户自带模型 API 密钥，密钥以 Fernet 加密存储于服务端（`services/byok_endpoint`） |
| **MatrixOne** | MySQL 协议兼容的分布式数据库，Astra 的持久层（经 sqlx MySql 驱动访问） |
| **Memoria** | 语义记忆服务（存储/检索/嵌入），服务端依赖（`astra-memoria` 端口 + `services` 侧 HTTP 实现） |
| **Explain / EXPLAIN ANALYZE** | 把一次 Turn 的上下文来源、预算、实际开销、丢弃原因投影为可读 DAG 的观测机制 |
| **Trace / Introspect / Reflect / Audit** | 观测平面四组件：执行事实记录 / 当前状态结构化 / 用户侧解释 / 策略反思（只建议不授权）/ 问责记录 |
| **Skill（技能）** | 可发现的打包能力（manifest + 提示/脚本），由 `astra-skills` 加载执行 |
| **MCP** | Model Context Protocol，外部工具/数据源集成协议（`astra-mcp`，基于 rmcp） |
| **Harness** | 生产运行时的预算/停滞/成本/委派守护，兼作评测基础设施（`astra-harness`） |
| **Checkpoint / Outbox** | 检查点=可恢复快照；Outbox=先落库再投递的可靠消息模式（`services/sync_outbox`） |
| **SSE** | Server-Sent Events，聊天流式传输协议（服务端 `/chat/stream`，Web 与 CLI 均消费） |
| **TUI / app-server** | 终端交互界面（ratatui）；`astra serve stdio` 提供的换行分隔 JSON-RPC 长连接模式 |
| **MOI** | Memoria 账户体系身份域（与本地凭据身份域严格隔离，见第 10 章坑点） |
| **thin-client** | `astra-thin-client`：CLI/Edge/Web 共用的无状态 HTTP+SSE 客户端（约 80 条路由封装） |

---

## 批次计划表

本项目触发分批条件（生产文件 > 40、模块 > 6）。因最终交付物为单一 Markdown 文件，9 个批次已全部完成并汇编如下；章节编号全局连续。

| 批次 | 覆盖模块/目录 | 覆盖章节 | 涉及文件数 | 状态 |
|------|--------------|----------|-----------|------|
| 1 | 全局总览（workspace、入口、配置） | 第 1~3 章 + 第 5 章（清单层）+ 本计划 | 全部（清单层） | 已完成 |
| 2 | 基础库层 + 共享内核（astra-logging/text-utils/config/runtime-env/credentials、core） | 第 4 章 §4.1~4.2 | 63 | 已完成 |
| 3 | 能力层 + 协议集成层（astra-tools/skills/pipeline/plan/prompts/sandbox、server-types/sync-protocol/messaging/memoria/thin-client/mcp/harness） | 第 4 章 §4.3~4.4 | 159 | 已完成 |
| 4 | Turn 编排核心（astra-turn-types、astra-turn-core） | 第 4 章 §4.5 | 250 | 已完成 |
| 5 | 持久化服务层（services） | 第 4 章 §4.6 | 150 | 已完成 |
| 6 | 服务器运行时（runtime） | 第 4 章 §4.7 | 281 | 已完成 |
| 7 | 交互层（astra-cli、astra-edge） | 第 4 章 §4.8 | 327 | 已完成 |
| 8 | 前端与 SDK + 评测（web、packages/sdk、astra-test-harness） | 第 4 章 §4.9~4.10 | 211 | 已完成 |
| 9 | 横切机制与收尾 | 第 6~10 章 + 附录 A/B/C | 核心链路抽样 | 已完成 |

---

## 1. 项目概述

### 1.1 项目用途与业务背景

Astra 是一个**自托管的企业级 AI Agent 运行时**：把"模型 + 工具"的循环升级为带治理的长周期工作系统。其产品主张（README.md:24-32、82-84）可归纳为一条核心不变式：

```text
enterprise agent = durable Work + governed context + authorized execution + verifiable evidence
```

围绕该主张，代码库实现了五个运行时子系统（README.md:108-114，与代码结构互相印证）：

| 运行时职责 | 企业问题 | 对应实现（代码位置） |
|---|---|---|
| Durable Work（持久工作） | 工作如何跨请求/重连/重试存活 | Agent Kernel：Session/Run/Turn/Work、检查点、恢复（`services` + `astra-turn-core`） |
| Context（上下文治理） | 此刻模型应该知道什么 | Context Pipeline：装配/优先级/溯源/预算/压缩/缓存稳定（`astra-turn-core/src/context`） |
| Control（控制） | 该身份被允许做什么 | 权限裁决、LLM 提供商准入、审批门（`astra-turn-core/src/permission`、`runtime` admission） |
| Execution（执行） | 动作应在哪里发生 | Server 提供者、User Runner（`astra-edge`/CLI 本地）、MCP、沙箱（`astra-sandbox`） |
| Evidence（证据） | 发生了什么、为何、下一步 | Trace/Introspect/Explain/Reflect/Audit（`runtime/src/observability`、`astra-turn-core/src/explain` 等） |

Astra 的学术背景是 ContextPipe 论文（arXiv:2609.00749，ADS 2026/VLDB），其五阶段上下文装配在 `crates/astra-turn-core/src/context/pipeline.rs` 落地。发布形态为一个 Rust 二进制家族（`astra` CLI/TUI/serve、`astra-server`、`astra-edge`）+ Next.js Web 控制台 + TypeScript SDK，支持三种运行形态：CLI+Server、Server-only、Server+Edge/User Runner。

### 1.2 技术栈清单

**后端（Rust workspace，25 个 crate）**

| 类别 | 技术 | 版本 | 证据 |
|---|---|---|---|
| 语言/工具链 | Rust（edition 2024） | 1.97.0 | `rust-toolchain.toml:2`、`Cargo.toml:35` |
| 异步运行时 | tokio（multi-thread） | 1.47.1 | `Cargo.toml:87` |
| Web 框架 | axum（含 ws 特性） | 0.8.6 | `Cargo.toml:64` |
| 数据库 | MatrixOne（MySQL 协议）× sqlx | sqlx 0.8.6 | `Cargo.toml:86`、`crates/core/src/lib.rs:12` |
| HTTP 客户端 | reqwest（rustls、socks） | 0.12.23 | `Cargo.toml:79` |
| 序列化 | serde / serde_json / serde_yaml_ng / toml | 1.x / 1.1.2 | `Cargo.toml:80-82,129` |
| 认证加密 | jsonwebtoken、bcrypt、fernet、hmac/sha2 | 10.3.0 / 0.17.1 / 0.2.2 | `Cargo.toml:66,70,76,83` |
| 观测 | tracing + tracing-subscriber + OpenTelemetry(OTLP) 0.32/0.33 | — | `Cargo.toml:94-118` |
| CLI 解析 | clap（derive+env） | 4 | `Cargo.toml:124` |
| 终端 UI | ratatui + crossterm（**本地 vendor 补丁**，SIGINT/DA1 启动查询优化） | 0.29 | `Cargo.toml:141-143`、`vendor/crossterm/ASTRA-PATCH.md` |
| WS 客户端 | tokio-tungstenite（rustls） | 0.26 | `Cargo.toml:121` |
| 其他 | uuid(v4/v7)、chrono、thiserror、similar、nix、flate2/tar、fs2 | — | `Cargo.toml:72-92` |

**前端与 SDK（TypeScript）**

| 类别 | 技术 | 版本 | 证据 |
|---|---|---|---|
| Web 框架 | Next.js（App Router）+ React | 16.3.4 / 19.2.7 | `web/package.json:33-35` |
| UI | Tailwind CSS 3.4 + Radix UI + lucide-react + @xyflow/react | — | `web/package.json:23-65` |
| SDK | 零依赖风格 TS SDK（@astra/sdk，本地 file: 引用） | 0.2.4 | `web/package.json:17` |
| 测试 | vitest + Playwright + Testing Library | — | `web/package.json:51-67` |

**构建/包管理**：Cargo workspace（`resolver = "2"`）、npm；`Makefile` 承载 dev/test/deploy 编排；Docker（`Dockerfile`、`Dockerfile.prebuilt`）与 Kubernetes（`deployment/kubernetes/chart`）。

### 1.3 如何运行

**二进制入口（3 个生产二进制 + 1 个测试辅助）**：

| 二进制 | 入口 | 作用 |
|---|---|---|
| `astra` | `crates/astra-cli/src/main.rs:18` → `astra_cli::entrypoint::run()` | CLI/TUI/`astra serve`（HTTP+SSE/stdio app-server）；33 个子命令（`cli_args.rs:152`） |
| `astra-server` | `crates/runtime/src/main.rs:14` → `astra_runtime::serve(addr)` | Axum API 服务器（默认 `127.0.0.1:17001`） |
| `astra-edge` | `crates/astra-edge/src/main.rs` | User Runner：在本机执行 Server 下发的工具调用，WS 连回 Server |
| `mock_mcp_server`（测试辅助） | `crates/astra-cli/src/bin/mock_mcp_server.rs` | MCP 集成测试桩 |

入口公共前置逻辑（两个 main 完全一致）：`astra_sandbox::run_invocation_supervisor_if_requested()`（进程监督器，须在任何线程/日志之前）→ `build_info::write_json_if_requested` → 正常启动（`astra-cli/src/main.rs:5-18`、`runtime/src/main.rs:8-14`）。

**源码启动路径**（README.md:417-483）：

```bash
cp .models.yaml.example .models.yaml   # 配置模型提供商
make dev-init                          # 初始化（含 MatrixOne/Memoria 依赖）
make build-cli-debug && make dev-start # 起 Server(17001) + Web(3536)
astra admin register                   # 引导管理员账户
astra admin model load .models.yaml --update-existing && astra admin model check <NAME>
astra chat -m "..."                    # 首个 agent 回复即闭环成功
```

**环境配置三层**（承载运行逻辑的配置文件，纳入分析范围）：

1. **`.env`**（模板 `.env.example`，238 行）：MatrixOne 连接、JWT/加密三密钥（生产必填，`ASTRA_ALLOW_INSECURE_DEFAULTS=1` 仅开发）、API 主机端口/CORS、Memoria（含嵌入提供者 mock/openai）、BYOK 端点策略（DNS 钉扎/出口代理）、Edge 注册、CLI 覆盖项等。
2. **`.models.yaml`**（模板 `.models.yaml.example`）：模型端点、密钥、能力、定价、fallback 链，经 `astra admin model load` 导入数据库。
3. **`config/server.toml`**（模板 `config/server.toml.example:3-6`）：系统级 `/etc/astra/server.toml` < 用户级 `~/.astra/server.toml` < `ASTRA_*` 环境变量（最高优先级）。

另有 CLI 侧运行时配置 `astra-config`（18 节五层加载：默认 < 用户 TOML < 项目 TOML < `ASTRA_*` env < CLI overlay，见 §4.1）。

---

## 2. 整体架构

### 2.1 架构风格与分层

Astra 是**分层单体 + 多二进制 + 边缘执行**的架构：单一 Cargo workspace 内严格按依赖方向分层（基础层→编排核心→服务层→组合层→交互层），编译产出多个二进制；执行容量可在服务器本地、用户 Runner（Edge/CLI）或 MCP/沙箱之间切换，但身份、策略与证据始终归属服务端骨干。

```text
┌────────────────────────── 体验层（Experience） ──────────────────────────┐
│  astra CLI/TUI (crates/astra-cli)   Web 控制台 (web/, Next.js)           │
│  TypeScript SDK (packages/sdk)      astra serve stdio (app-server)       │
└───────────────┬─────────────────────────────────────────────────────────┘
                │  HTTP+SSE / WebSocket（经 astra-thin-client 或 Web 代理）
┌───────────────▼─────────────── 服务器组合层 ─────────────────────────────┐
│  runtime (crates/runtime)                                                │
│  serve() → build_server_state() → Axum Router（六组路由）                │
│  agentic_loop / turn/llm 模型客户端 / ToolExecutionService 执行路由      │
│  provider 准入 / capability_registry / observability / self_model        │
└───────┬────────────────────────┬────────────────────────────────────────┘
        │                        │
┌───────▼──────────┐   ┌─────────▼───────── Turn 编排核心（库，无基础设施依赖）
│ services         │   │ astra-turn-core / astra-turn-types
│ 持久化域服务      │   │ Turn 生命周期·agentic 循环·权限引擎·审批门
│ auth/admin/models│   │ Context Pipeline(Plan→Bind→Optimize→Serialize)
│ session族/runs/  │   │ token 预算/压缩/KV-cache 布局/SSE 事件模型
│ work/sync_engine │   └─────────┬───────────────────┬──────────────────┘
│ audit/byok代理    │             │                   │
└───────┬──────────┘   ┌─────────▼─────────┐   ┌─────▼──────────────────┐
        │              │ 能力层              │   │ 协议与集成层            │
        │              │ astra-tools(工具契约)│  │ astra-server-types     │
        │              │ astra-skills(技能)  │   │ astra-sync-protocol    │
        │              │ astra-pipeline(恢复) │  │ astra-messaging        │
        │              │ astra-plan/prompts  │   │ astra-memoria(记忆端口) │
        │              │ astra-sandbox(沙箱) │   │ astra-mcp / harness    │
        │              └─────────┬──────────┘   └─────┬──────────────────┘
┌───────▼────────────────────────▼────────────────────▼──────────────────┐
│ 共享内核 core (astra-core)：AppSettings 配置 / SharedPool 连接池 /        │
│ identity / MatrixOne 兼容技巧 / history-work 基线 / process_runtime      │
│ 基础库：astra-logging(日志) astra-config(CLI运行时配置)                    │
│         astra-runtime-env(工具面模型) astra-text-utils astra-credentials │
└───────────────────────────────┬─────────────────────────────────────────┘
                                │
              ┌─────────────────▼──────────────────┐
              │ 外部系统：MatrixOne(MySQL协议,6001)  │
              │ Memoria 语义记忆(8100)  LLM 提供商   │
              │ Edge/User Runner(用户环境, WS 反连)  │
              └────────────────────────────────────┘
```

（分层依据根 `Cargo.toml` 的 workspace 依赖声明与各 crate 实际引用关系归纳；`vendor/crossterm` 为本地补丁依赖，不属于分层。）

### 2.2 模块依赖关系

依赖方向自上而下单向流动（上层依赖下层，禁止反向）：

- **全部 crate → core / astra-logging / astra-text-utils**：`core` 是共享内核（17 个 crate 依赖它，84 个文件直接使用 `SharedPool`——grep 统计）。
- **runtime → services + astra-turn-core + 能力层 + 集成层**：runtime 是纯组合层，自身不定义域规则；`runtime/src/lib.rs:104` 直接 `pub use astra_core::*` 转出口内核原语。
- **astra-turn-core → astra-turn-types + astra-tools（+少量基础层）**：其 lib.rs:2-6 自述"不依赖 runtime 基础设施（AppState、数据库、Axum 等），可独立编译测试"。
- **services → core（+astra-server-types 等）**：持久化域服务，经 `with_pool()` 显式注入 `SharedPool`（`services/src/lib.rs:95-102`），不自行建连。
- **astra-cli / astra-edge → astra-thin-client + runtime（复用 agentic loop）+ edge_tools 本地执行**：CLI 的聊天循环体 `run_agentic_loop_with_host` 实际复用 astra-runtime（§4.8.2），即"库内无 while 本体、宿主拥有循环"的设计（§4.5）。
- **web → @astra/sdk（file:../packages/sdk）→ 后端 HTTP API**：Web 的 `/api/*` route handler 代理到 Server 根路径路由（注意：**Server 路由本身无 `/api` 前缀**，§4.7.1）。

### 2.3 核心数据流：一次聊天请求的完整路径

以 `astra chat -m "Run ls *.sh | wc -l"`（CLI 一次性命令，经 Server 执行，工具在 CLI 本地执行）为例，主干如下（函数级细节见第 7 章）：

```text
用户
 │ astra chat -m "..." -y
 ▼
CLI main → entrypoint::run → command_router(Chat) → execute_basic_cli_turn
 │  组装 host/state（本地工具执行器 + 审批 sink）
 ▼
stream_chat_sse ──POST /chat/stream──▶ Server (runtime)
                                        │ ① JWT 认证 + 会话活性 + 配额
                                        │ ② resolve_or_create_chat_session（fencing）
                                        │ ③ 持久化 Run 起点 + owner lease
                                        │ ④ spawn agentic_loop，返回 event_rx
                                        ▼
                              run_agentic_loop_impl（循环：prepare→execute_turn→tool_phase）
                                        │ Context Pipeline 装配（预算/压缩/cache 布局）
                                        │ LLM 提供商准入（三级节流）→ durable 推理台账 → reqwest
                                        ▼
                              模型返回工具调用 → 权限裁决 evaluate_permission
                                        │ 准予：ToolExecutionService 路由
                                        │   ├─ LocalRoute → CLI/Server 本地执行（沙箱边界内）
                                        │   └─ EdgeBound  → insert_dispatch → WS 下发
                                        │                  → astra-edge journal.prepare
                                        │                  → 本地执行 → 结果先落 outbox
                                        │                  → WS 回发 → /tools/result 回调
                                        │                  → ToolResultAck 后清 outbox
                                        ▼
                              结果回填上下文 → 下一轮（无工具调用即终答）
◀──────────── SSE 事件流（delta/工具卡片/审批请求/usage）────────────────┘
 │ CLI consume_turn_sse 渲染（审批经 TUI ApprovalQueue；无 sink 则 fail-closed）
 ▼
Turn 终态 CAS 落库（agent_runs/agent_run_events）→ 审计/Trace/Explain DAG → 会话日志
```

**关键架构不变式**（各层代码反复强化）：

1. **服务端拥有循环与真相**：agentic while 循环在宿主（runtime/CLI），库只提供钩子；Server 执行的循环结果对客户端仅观测、禁止本地重放（§4.5）。
2. **审批先于工具**：`flush_pending_via_host` 保证审批事件必先于工具执行事件（§4.5）。
3. **先落库再投递**：推理先写 durable 台账再发请求；Edge 结果先进 outbox 待 ACK 才删除（§4.7、§4.8.5）。
4. **fail-closed 默认**：无审批通道、MCP 工具名冲突、协议版本不匹配等情况一律拒绝而非降级放行。

---

## 3. 目录结构详解

> 以下仅列出纳入分析范围的目录；`docs/`（纯文档）、`fixtures/`、`vendor/`（补丁依赖）、`.github/`、`.agent|.claude|.cursor|.kiro`（AI 协作指令）等按排除规则不逐文件分析。

### 3.1 仓库根

| 路径 | 职责 | 关键内容 |
|---|---|---|
| `Cargo.toml` / `Cargo.lock` | workspace 清单与锁定 | 25 个成员 crate、workspace 级依赖版本、`[patch.crates-io] crossterm`（`Cargo.toml:141-143`）、release strip 符号 |
| `rust-toolchain.toml` | 工具链钉扎 | Rust 1.97.0 minimal + clippy/rustfmt |
| `Makefile` | 构建/开发/部署编排入口 | `dev-init/dev-start/dev-stop/build-cli-debug/test-offline/test-contract/check/stack-*` 等目标 |
| `.env.example` / `.env.production.example` | 环境变量模板（运行行为配置） | 见 §1.3 |
| `.models.yaml.example` | 模型提供商清单模板 | 端点/密钥/定价/fallback |
| `config/server.toml.example` | 服务端 TOML 基线 | 三级加载顺序说明（`config/server.toml.example:3-6`） |
| `Dockerfile` / `Dockerfile.prebuilt` | 容器构建 | 源码构建版 / 预构建二进制版 |
| `README.md`、`CONTRIBUTING.md`、`SECURITY.md`、`SUPPORT.md`、`CITATION.cff`、`LICENSE` | 项目文档（理解参考） | — |
| `AGENTS.md` / `CLAUDE.md` / `.nvmrc` / `.editorconfig` 等 | AI 协作与编辑器配置（排除范围） | — |

### 3.2 `crates/`——25 个 workspace 成员

| Crate | 分层 | 职责 | 生产文件数 / 约行数 |
|---|---|---|---|
| `core`（astra-core） | 共享内核 | AppSettings 配置装配、SharedPool、identity、MatrixOne 兼容、history-work 基线、process_runtime | 34 / 19.0k |
| `astra-logging` | 基础库 | 进程级 tracing 订阅器（TTY/json 自适应、脱敏、OTLP） | 2 / 0.4k |
| `astra-text-utils` | 基础库 | CJK 分词/去重/截断/编码等零依赖文本工具 | 8 / 2.7k |
| `astra-config` | 基础库 | CLI 侧 RuntimeConfig（18 节五层合并）+ 配置版本库 + 治理变更 | 9 / 6.6k |
| `astra-runtime-env` | 基础库 | 能力驱动的工具面模型（provider×绑定×策略→可见工具），50+ 内置工具注册表 | 9 / 7.4k |
| `astra-credentials` | 基础库 | 多 profile 凭据文件（旁路锁+原子写+0600） | 1 / 0.6k |
| `astra-server-types` | 协议集成 | Server API 契约 + Edge WS 协议/连接池/worktree 隔离 | 10 / 6.6k |
| `astra-sync-protocol` | 协议集成 | 边云同步 HMAC 签名 + ACK 线协议 | 1 / 0.1k |
| `astra-messaging` | 协议集成 | 传输无关消息框架（tokio 进程内 + DB 持久双传输，ack 重试/DLQ） | 10 / 6.2k |
| `astra-memoria` | 协议集成 | 语义记忆规范端口（fail-closed 召回校验） | 1 / 1.1k |
| `astra-thin-client` | 协议集成 | CLI/Edge/Web 共用 HTTP+SSE 客户端（约 80 条路由） | 9 / 7.7k |
| `astra-mcp` | 协议集成 | 基于 rmcp 的四传输 MCP 客户端 | 7 / 2.8k |
| `astra-harness` | 协议集成 | 预算/停滞/成本/委派守护运行时 + 能力矩阵评测 | 20 / 5.4k |
| `astra-tools` | 能力层 | 工具契约（ToolExecutor trait）+ 共享执行器（准入/互斥/执行/结算四段式） | 38 / 58.9k |
| `astra-skills` | 能力层 | 技能 manifest/loader/provider/executor（inline+fork） | 31 / 12.4k |
| `astra-pipeline` | 能力层 | 学习/恢复管线（检查点+崩溃恢复+trace；注意：**不是** Context Pipeline） | 11 / 13.1k |
| `astra-plan` | 能力层 | 计划模式模型 + SQLx 持久化 | 6 / 3.0k |
| `astra-prompts` | 能力层 | 记忆协议常量 + 多代理提示模板 | 7 / 2.6k |
| `astra-sandbox` | 能力层 | 路径/命令/进程三层安全边界 + InvocationSupervisor | 8 / 10.8k |
| `astra-turn-types` | 编排核心 | Turn 相关纯类型与契约 | 27 / 12.5k |
| `astra-turn-core` | 编排核心 | Turn 生命周期/agentic 循环钩子/权限引擎/Context Pipeline/SSE 模型 | 223 / 142.4k |
| `services`（astra-services） | 服务层 | 全部持久化域服务（~120 张表的 DDL 与访问） | 150 / 207.8k |
| `runtime`（astra-runtime） | 服务器组合层 | Axum 服务器、路由、AppState 组装、agentic loop 宿主、LLM 客户端、执行路由 | 281 / 361.9k |
| `astra-cli` | 交互层 | `astra` 二进制：33 子命令 CLI、ratatui TUI、本地工具执行、SSE 消费 | 322 / 277.5k |
| `astra-edge` | 交互层 | User Runner 二进制：WS 反连、工具本地执行、outbox/journal | 5 / 4.6k |
| `astra-test-harness` | 评测 | 评测用 harness 二进制与库（cases/ 为用例数据） | 22 / 26.6k |

### 3.3 前端与 SDK

| 路径 | 职责 | 关键内容 |
|---|---|---|
| `web/` | Next.js 16 控制台（App Router，默认 :3536） | `(workspace)` 路由组（chats/projects/works/harnesses/now/artifacts）、`app/api/**` 代理层（chats/projects/works/harnesses/runtime-auth/models/edges/skills/search/sidebar）、`lib/runtime-client`（SSE 客户端）、`lib/auth`、composer 组件族；174 个生产 TS/TSX |
| `web/public/fonts/` | 自托管字体 | inconsolata、newsreader |
| `packages/sdk/` | TypeScript SDK（@astra/sdk） | `AstraClient`（约 90 方法）、SSEClient、AstraWebSocket、useAstraChat hooks、work-wire 严格解码器；15 个生产 TS |

### 3.4 运维与脚本（目录级说明，不逐文件分析）

| 路径 | 职责 |
|---|---|
| `scripts/` | 开发/CI/e2e/运维 shell 与 Rust 脚本（`dev/run-web-dev.sh` 被 web/package.json 引用；`install-astra.sh` 安装器；`stack-*` 引导部署） |
| `deployment/` | all-in-one Compose、Kubernetes chart、监控部署示例 |
| `monitoring/` | Grafana dashboards 等监控资产 |
| `.cargo/` | cargo 构建配置 |
| `fixtures/` | 契约/ harness 测试夹具（排除范围） |
| `docs/` | 设计契约与指南（`docs/design/ARCHITECTURE.md` 为权威架构文档，分析时作交叉参考） |

---

## 4. 核心模块详解

本章按依赖方向自底向上（基础层 → 共享内核 → 能力层 → 协议集成层 → Turn 编排核心 → 持久化服务层 → 服务器运行时 → 交互层 → 前端/SDK/评测）逐模块展开。每节包含模块职责、文件组成、关键类型/函数解析（签名、实现方式、副作用、调用关系）与对外接口。章节编号与批次计划表对应（§4.1~4.2=批次2，§4.3~4.4=批次3，§4.5=批次4，§4.6=批次5，§4.7=批次6，§4.8=批次7，§4.9~4.10=批次8）。

---

### 4.1 基础库层（astra-logging / astra-text-utils / astra-config / astra-runtime-env / astra-credentials）

本层是 workspace 最底部的五个无（或少）基础设施依赖的 crate，合计 29 个生产 `.rs` 文件。它们被上层广泛复用：按各消费者 Cargo.toml 统计，`astra-runtime-env` 被 7 个 crate 依赖（astra-cli、astra-edge、astra-skills、astra-thin-client、astra-turn-core、runtime、services），`astra-text-utils` 被 5 个（astra-cli、astra-messaging、astra-pipeline、astra-turn-core、runtime），`astra-config` 被 3 个（astra-cli、runtime、services），`astra-logging` 被 4 个（astra-cli、astra-edge、runtime、services，后三者可透传 `otel` feature），`astra-credentials` 被 3 个（astra-cli、astra-edge、astra-test-harness）。

#### 4.1.1 astra-logging（2 文件）——全局 tracing 订阅器初始化与 OTel 导出

**模块职责**：为所有 Astra 二进制（server、edge、CLI）提供"一次安装"的 `tracing_subscriber` 全局订阅器，统一日志格式选择（JSON/人读）、UTC RFC3339 时间戳、stderr 输出，以及可选的 OpenTelemetry OTLP 追踪导出。位于进程启动的最前端——任何 crate 只要 `tracing::info!` 即可受益，无需各自初始化。

**关键类型与函数**：

- `LogInitConfig<'a>`（`crates/astra-logging/src/lib.rs:29`）：仅两个字段——`default_filter`（RUST_LOG 未设置/非法时的兜底过滤表达式）与可选 `service_name`。builder 风格 `with_service_name`（lib.rs:44）。调用方：astra-cli/runtime/services 的 main。
- `resolve_format()`（lib.rs:50-82）：读取 `ASTRA_LOG_FORMAT`（json/pretty/compact，大小写不敏感）；**未设置或非法值时按 `io::stderr().is_terminal()` 自动选择——TTY→pretty，非 TTY→json**（容器/CI 友好），非法非空值额外 `eprintln!` 警告。这是"同一二进制本地开发好看、在 Docker 里机器可解析"的实现机制。
- `init_from_env(config) -> Result<(), InitError>`（lib.rs:97-112）：进程入口。`InitError = Box<dyn std::error::Error + Send + Sync>`（lib.rs:92，本 crate 唯一不用 thiserror 的地方，因为是安装全局订阅器的通用错误）。启用 `otel` feature 且 `wants_otel_export()` 为真时走 `otel::init_with_otel`，**OTLP 初始化失败降级为纯 stderr 日志而非崩溃**（lib.rs:102-107）。
- `init_fmt_only`（lib.rs:114-147）：`EnvFilter::try_from_default_env()` 失败回退 `config.default_filter`；`tracing_subscriber::fmt()` 统一配置 `with_timer(UtcTime::rfc_3339())`、`with_writer(io::stderr)`、关闭 thread id/file/line（压缩日志体积），按 format 分派 `.json()/.pretty()/.compact()` 的 `try_init()`。成功后若解析出服务名（`ASTRA_SERVICE_NAME` 环境变量优先于 config 传入，lib.rs:137-140）发一条 `target: "astra.logging"` 的 INFO。
- `redact_known_secret_patterns(s) -> String`（lib.rs:159-192）：对 `sk-`、`Bearer `、`key-` 前缀后的值替换为 `[REDACTED]`，用自定义 `boundary`（空白/引号/逗号/右括号）确定值结尾。算法是**多前缀并行扫描取最左匹配**（lib.rs:168-175）再顺序拷贝。供 provider/verifier 错误字符串在写日志前脱敏。
- `shutdown_otel()`（lib.rs:150）：优雅退出时 flush OTLP 批量导出器；`kill -9` 可能丢尾部批次（模块文档 lib.rs:17-18）。
- `otel.rs`（feature `otel` 专用）：
  - `wants_otel_export()`（otel.rs:26-37）：`ASTRA_OTEL_ENABLED=1` 或 `OTEL_EXPORTER_OTLP_ENDPOINT`/`OTEL_EXPORTER_OTLP_TRACES_ENDPOINT` 非空即激活。
  - `TRACER_PROVIDER: OnceLock<Mutex<Option<SdkTracerProvider>>>`（otel.rs:19）：用 `OnceLock<Mutex<Option<..>>>` 模式持有全局 provider，`shutdown_tracer_provider`（otel.rs:166-177）`take()` 后调用 `provider.shutdown()` 做一次性 flush。
  - `install_otlp_tracer`（otel.rs:54-71）：构建 tonic `SpanExporter` + `SdkTracerProvider`（batch exporter）+ `global::set_tracer_provider`，并塞入静态槽。
  - `build_resource`（otel.rs:39-51）：`Resource::builder_empty()` 叠加 `SdkProvidedResourceDetector` + `EnvResourceDetector`（标准 `OTEL_*` 资源属性），service_name 取 config 或 env。
  - `registry_with_fmt`（otel.rs:78-136）：`Registry` 上叠加 `OpenTelemetryLayer` 与 fmt layer，**两层各自 `.with_filter(filter.clone())`**（per-layer filtering），保证同一 EnvFilter 同时作用于 OTel 与 stderr——这是 tracing-subscriber 分层过滤的标准用法，三个 format 分支各写一遍（显式但不抽象）。
  - `init_with_otel`（otel.rs:139-163）：组装上述并输出 "logging initialized (OTLP + stderr)"。

**对外接口**：`init_from_env`、`shutdown_otel`、`redact_known_secret_patterns`、`LogInitConfig`。副作用：安装全局订阅器（每进程仅一次，二次调用报 "already been set"，lib.rs:96）、设置全局 OTel tracer provider。

#### 4.1.2 astra-text-utils（8 文件）——纯文本处理工具集

**模块职责**：从 runtime crate 抽出的"零运行时基础设施依赖"文本工具（`crates/astra-text-utils/src/lib.rs:1-4`）：CJK 感知分词、词法语义去重、输出风格注册表、Unicode 安全截断、XML 转义等。被 pipeline（上下文压缩）、turn-core（工具调用去重）、messaging（消息预览）、runtime 消费。

**关键类型与函数**：

- `text_tokenize.rs`：
  - `tokenize(text) -> Vec<String>`（text_tokenize.rs:15-41）：**单遍字符扫描**。CJK 区间（U+4E00–U+9FFF）每个字符出一元 gram，且与前一个 CJK 字符拼出二元 gram（"记忆"→`["记","忆","记忆"]`）；ASCII 侧缓冲后按非字母数字（`_` 除外）切词，词长 ≥2 保留，**并同时输出词干形式**（stem 结果不同于原词时两个都发，使 "prefer" 与 "preferences" 有共同 token，text_tokenize.rs:57-60）。
  - `build_tf(&[String]) -> HashMap<String, f64>`（text_tokenize.rs:44）：词频表，供余弦相似度使用。
  - `stem(word)`（text_tokenize.rs:71-154）：**刻意简化**的后缀剥离器（非 Porter/Snowball，注释明确为避免 "community"→"commit" 类误伤），按长后缀优先处理 `-ation/-tion/-ment/-ness/-ings/-ences/-ance/-ing/-ers/-ed/-es/-ly/-s`，`-ing/-ed` 带双写辅音收敛（"committing"→"commit"，text_tokenize.rs:113-121）。
- `semantic_dedup.rs`（本 crate 最复杂模块，2040 行中约 1140 行为测试）：
  - 三层去重架构（模块文档 semantic_dedup.rs:1-8）：Tier 1 精确匹配在 runtime 的 chat_stream；Tier 2 参数感知语义键；Tier 3 输出 token 余弦相似度。**无 embedding、无 IDF、无模型调用——纯字符串处理**。
  - `semantic_call_key(tool_name, &Value) -> Option<String>`（semantic_dedup.rs:38-157）：按工具名 match 的规范化键生成。规则体现语义等价：路径去尾部 `/`（normalize_path:171）、repo 小写（normalize_repo:197）、git ref 缺省 "HEAD"、`git diff` 的 pathspec 排序去重后进键（semantic_dedup.rs:254-255）、`read_file` 的行区间与 outline 标志进键（175-186）。**写入类工具（write_file、普通 bash、memory 的 write 动作）返回 None——不可去重**（semantic_dedup.rs:84、143-154、1122）；`semantic_bash_git_key`（324-355）把无 shell 元字符的裸 `git status/diff [--stat|--cached] [-- path]` 命令规范化为与结构化 `git` 工具相同的键，跨工具命中缓存。
  - `token_cosine_similarity(a, b) -> f64`（semantic_dedup.rs:403-442）：TF 向量余弦；短于 `MIN_OUTPUT_LEN=30` 字节直接 0.0，相等直接 1.0。
  - `SemanticDedup`（semantic_dedup.rs:447-464）：三块有界状态——`param_cache: HashMap<key,(turn,tool,generation)>`（上限 512，FIFO `param_order` 驱逐，497-523）、`output_log`（上限 50 条，输出按 2000 字节 UTF-8 字符边界截断，681-690）、`dedup_audit`（上限 256 条按签名聚合计数，525-543）。
  - `pre_check_block[_with_generation]`（semantic_dedup.rs:554-608）：**执行前硬阻断**——同键、同 `context_generation`、跨 turn 命中且 output_log 有真实输出时返回 `(prev_turn, cached_output)` 供调用方直接复用。三个放行例外（测试注释称否则长会话会死锁，1866-1893）：输出以 `[Cleared`/`(cached` 开头（microcompact 清除后的桩）→ 强制重执行；**只读工具**且输出 <20 字符 → 便宜重跑；写工具的短输出照样返回缓存以免重复副作用（592-604，`is_read_only_tool` 368-401 是白名单谓词）。
  - `check_and_record[_with_generation]`（semantic_dedup.rs:616-703）：**执行后记录 + 检测**。Tier 2 同键同代跨 turn 命中报 `param_match`；Tier 3 仅在同语义键内比较输出余弦（651-653 注释：否则不同 read_file 区间会互相误伤）。`context_generation` 由调用方在 workspace 变更后推进，使旧观察全部失效（566-570）。
  - `append_near_duplicate_hint_for_observation_with_generation`（semantic_dedup.rs:741-764）：把原始 observation 记账、把提示追加到模型可见的转换后文本——**原始与可见文本分离**（测试 1378-1410 验证缓存放的是 raw observation）。
  - `context_inventory()`（semantic_dedup.rs:786-881）：把 param_cache 反解析成 "Files/Searches/Git/GitHub/Memory" 人类可读清单（>5 文件截断为 "+N more"），注入对话帮助模型规划；`has_file`/`has_grep_in`（885-898）用键前缀匹配。
  - `clear_observation_cache()`（491-495）：清 param/output 缓存但保留审计。
- `output_style.rs`：输出风格系统。
  - `OutputStyle{name,description,prompt,source,keep_coding_instructions}`（output_style.rs:18-29）与 `StyleSource{BuiltIn,User,Project}`（33-40）。
  - 内置 4 风格：default（空 prompt）、explanatory、concise、verbose（86-135，prompt 为硬编码 markdown 常量）。
  - `load_styles_from_dir`（143-169）：目录内每个 `.md` 文件即一个风格，文件名去扩展为风格名；`parse_style_file`（182-204）用**手写极简 frontmatter 解析**（`---` 定界，只提取 `description:` 行），无 YAML 依赖。
  - 三级优先级注册表：`STYLE_REGISTRY: OnceLock<HashMap<..>>`（234），`get_style_registry`（244-260）按 内置 < 用户（`~/.astra/output-styles/`，受 `ASTRA_LOCAL_STATE_ROOT` 重定向，207-224）< 项目（`.astra/output-styles/`，227）顺序 insert 覆盖。**进程首次访问后固化**（OnceLock）。
  - `get_output_style`（266-281）：`"default"`/空 → None（无附加指令）；未知风格 eprintln 警告后回退 None。`current_output_style`（284-288）读 `ASTRA_OUTPUT_STYLE`。
- `str_preview.rs`：全部按 **Unicode 标量** 而非字节计数，UTF-8 安全。`truncate_str`（10）、`truncate_line`（24，先取首行再截断，`…` 计入预算）、`shorten_path`（44-71，保文件名、目录前缀折叠为 `.../parent/file`；58 行注释专门解释为何用 `>` 而非 `>=` 的边界 bug）、`github_repo_display`（75）、`prefix_chars`（5）。
- `xml_escape.rs`：`xml_escape_attr`（7，转义 `&<>"'`）与 `xml_escape_text`（20，仅 `&<>`，**元素文本中引号合法**）。实现（24-44）先 `bytes().any()` 探测，无需转义时返回 `Cow::Borrowed` 零分配快速路径（工具/技能描述的常见情形）。
- `url_component.rs`：`encode_url_component`（14-28）RFC 3986 组件编码（非 form 编码，空格→`%20`），仅 unreserved 集合 `A-Za-z0-9-._~` 直通，大写十六进制——保证值无法伪造额外查询参数（模块文档 1-7）。
- `tool_name.rs`：`normalize_ascii_tool_name`（1-8）trim + ASCII 小写，空串 → None。

**对外接口**：7 个 pub module 的全部公共项。核心被引用项：`SemanticDedup`、`semantic_call_key`、`tokenize`/`build_tf`、`get_output_style`/`current_output_style`、`truncate_*`/`shorten_path`、`xml_escape_*`。

#### 4.1.3 astra-config（9 文件）——运行时配置、版本化与治理变更

**模块职责**：定义并加载 `RuntimeConfig`（18 个分节的巨大配置结构），实现"内置默认 → 用户 TOML → 项目 TOML → 环境变量 → CLI overlay"五层合并；提供内容寻址的配置版本存储（`cfg_` + SHA-256 前缀）、治理式字段变更（范围 + 漂移上限 + 不变量）、JSON 点路径编辑，以及用户画像/场景意图类型。依赖 `astra-core`（local_state、runtime_limits、TraceCategory/TraceLevel）与 `astra-turn-types`（ObjectiveRelation/UserFeedback）。

**关键类型与函数**：

- `runtime_config.rs`（3926 行，tests 自 2723 行起）：
  - `RuntimeConfig`（runtime_config.rs:22-108）：version、compression、memory、tool_selection、tool_policy、trace、token_budget、verification、memory_pressure、context_window、adaptive_tuning、adaptive_runtime、safety、fork_prefix、tool_surface、runtime_limits、agent_binding_registry、budget_policy 共 18 节。**几乎所有字段 `#[serde(default ...)]`**——这是部分反序列化（partial TOML/JSON overlay）能工作的前提。
  - **配置加载优先级**（模块文档 8-13，`load()` 实现 1995-2051）：①`RuntimeConfig::default()` → ②用户级 `~/.astra/config/runtime.toml`（可被 `astra_core::local_state::local_state_root_override()` 即 `ASTRA_LOCAL_STATE_ROOT` 重定向，1954-1968）→ ③项目级 `.astra/config/runtime.toml`（**相对当前工作目录**，2018）→ ④`apply_env_overrides()`（2033；2671-2715 支持 `ASTRA_MAX_HISTORY_TOKENS`、`ASTRA_COMPRESSION_THRESHOLD`、`ASTRA_RETRIEVAL_TOP_K`、`ASTRA_MAX_TURN_INPUT_TOKENS`、`ASTRA_AGENT_BINDING_MAX_AGENT_MD_BYTES`、`ASTRA_CAPTURE_TRACES=1/true` 全类别 trace、`ASTRA_CAPTURE_FULL_LLM` 追加 LlmExchanges 类别）→ ⑤CLI `--settings` overlay。**TOML 解析失败只 `tracing::warn!` 并沿用已合并值**（2005-2013 注释称静默回退曾是 P1 评审头号坑）。最后应用压缩策略预设（2043-2046）与 trace normalize（2048）。
  - `set_cli_overlay`/`CLI_OVERLAY`（1932-1952）：进程级 `OnceLock<RwLock<Option<RuntimeConfig>>>`，存**已解析**的 RuntimeConfig 使后续 `load()` 不可能再因格式失败——CLI 边界集中承担解析错误。
  - `RuntimeConfig::cached()`（1985-1988）：`OnceLock` 进程级缓存，热路径（每 turn/每工具调用）避免重复同步 IO+解析；代价是**配置在进程生命周期内视为静态**，改文件需重启。
  - `merge(mut self, other)`（2074-2668）：核心合并语义由 `merge_if_non_default<T: PartialEq>(slot, incoming, default)`（1916-1920）实现——**仅当 incoming 值 ≠ 该字段默认值时覆盖**。推论（在 config_overlay.rs:88-90 明说）：把字段改回默认值与"未设置"不可区分。三处刻意例外：`safety.trust_mode` 是 `Option`，三态（None=未提及 / Some(Strict) / Some(Trusted)）**最后显式层获胜**（2623-2629，项目层可把用户层的 Trusted 收紧回 Strict）；`tool_surface.pinned_tools` 非空即**整节替换**（2639-2646，跨层原子而非累加，但单文件内 `-grep` 前缀语法是增删语义，见 340-375 文档）；`model_profiles` 非空整表替换（2317-2321）。
  - `load_with_version(store, meta)`（2064-2071）：`load()` 后立刻 `store.put()` 进版本库，返回 `(config, VersionId)`——每个 session 启动应走的"正门"。
  - 工具策略双轨：`ToolSelectionConfig`（815-962）与 `ToolPolicyConfig`（571-648）字段几乎重复（推断为历史演进遗留，两者均被 merge 处理）。所有阈值字段采用 **"0 表示用默认值"哨兵** + `resolve_threshold(value, default, floor)`（1242-1244）统一解析并设下限。`effective_max_identical_calls` 默认 3、下限 2（1036-1042，注释记录 2026-04-27 从 2 提到 3 的原因：read→edit→re-check 是合法流）。
  - 按模型策略：`ModelPolicyProfile`（969-1005，5 个可覆盖阈值）+ `resolve_for_model`（1052-1084）：**用户 profile（大小写不敏感子串匹配，`model_profile_matches` 1290-1298，非空 pattern <3 字符视为误配忽略，MIN_MODEL_MATCH_LEN=1281）→ 内置 profile → 全局默认**。内置四档（1092-1136）：opus/sonnet-4/gpt-5（max_tools_per_turn 18-20）、haiku（12，更保守）——"强模型多给绳子，弱模型早踩闸"。`parallel_batching_force_streak` 有独立的最小/默认/最大三元组 7/8/50（1255-1263），硬纠正必须严格晚于 prompt 层软提示（=6），防止级联倒置。
  - `SessionTraceConfig`（1444-1626）：profile（production/dev/custom）+ min_level + categories + sinks（Journal/Stderr/Otlp）+ sampling_rate；`normalize()` 排序去重并 clamp（1548-1559）；`apply_profile` 覆写（1562-1582，Dev=Trace 全类别双 sink）；`with_cli_overrides`/`from_cli`（1591-1625）消费 `--trace-*` 标志，任何 level/cat 覆写自动降级为 Custom。
  - `SafetyConfig`（269-293）：trust_mode Option 三态 + `resolved_trust_mode()` 应用 Strict 默认；`TrustModeSerde`（301-309）snake_case、Copy+Hash+Ord。
  - `RuntimeLimitsConfig::resolve_turn_ceiling`（203-218）：config>0 覆盖 env 驱动的 `astra_core::RuntimeLimits`，plan 子任务依次回退 plan_subtask→max_turns→env。
- `config_overlay.rs`：`--settings` overlay 与 `/config` 编辑面。
  - `parse_settings_source`（72-81）：**以 `{` 开头（跳过空白）判内联 JSON，否则当文件路径读**——刻意不解决以 `{` 开头的病态文件名。
  - `apply_settings_json(base, json)`（91-94）：JSON 整体反序列化为 RuntimeConfig（全 default 字段）后走 `merge`，省略字段保留 base 值。
  - `effective_budget_for_model`（106-118）：模型上下文窗口 × `MODEL_CONTEXT_INPUT_BUDGET_RATIO` 与配置 cap 取 min，未知模型回退 `RuntimeLimits::global()`。
  - `SettingKind{Bool,Number{min,max,allow_fraction},Enum}`（124-134）与 `build_settings_catalog`（162-345）：**手写清单即 `/config edit` 唯一可达面**（约 21 项：token 预算、context window 开关、压缩、memory top-k、trace 开关、runtime limits），注释要求新增旋钮必须同时改 catalog 与 `apply_edit`，回归测试 `every_catalog_item_is_editable_via_apply_edit` 强制两侧同步（157-161）。
  - `apply_edit(config, id, new_value)`（394-711）：typed 写入——`as_u32` 接受整值浮点（UI round-trip，407-427）、`ensure_range` 区间校验、`ensure_threshold_order` 跨字段不变量（446-453）；所有 trace 类编辑后 `mark_trace_custom`（464-467）脱离预设并 normalize；未知 id → `OverlayError::UnknownPath`。
- `config_versions.rs`：内容寻址配置版本库。
  - `VersionId`（44）：`cfg_` + SHA-256(TOML 字节) 前 16 个十六进制字符（`from_toml_bytes` 54-60）。**序列化字节即身份**——结构相等但序列化不同的两个 config 得到不同 id（put 注释 319-323）。`from_wire_string`（76）接受外部 id 不校验格式，完整性由 `put_raw_toml` 的哈希复核承担。
  - 磁盘布局（10-17）：`<root>/cfg_<hex>.toml`（每内容一 blob，put 幂等）+ `index.jsonl`（**每次 put 都追加**，重复内容也会记录"第二个 session 也用了这份配置"这一事实）。默认根 `~/.astra/config/versions/`（161-163）。
  - `append_index`（180-213）：**fs2 `lock_exclusive` 全程持锁**再 `write_all`——注释指出 O_APPEND 单独无法保证多进程并发下一行一条记录。`read_index`（215-262）：逐行严格解析失败后走**流式反序列化恢复路径**（243-253），兼容旧版本跨进程 `writeln!` 竞态产生的 `{...}{...}` 连排行。
  - `put_raw_toml`（277-312）：`astra config sync pull` 落云端口径字节；**校验 body 哈希必须等于 id**，拒绝破坏内容寻址不变量（283-290）。
  - trait `ConfigVersionStore`（134-145）：put/get_toml/list，为后续云镜像实现留缝。
- `config_version_cli.rs`：`astra config version` 子命令的纯展示层（`fn(&store,...)->Result<String,_>`，便于不捕获 stdout 的测试）。`resolve_prefix`（34-53）前缀唯一性解析（0 个→NotFound，多个→Ambiguous）；`format_version_list`（64-99）定宽表；`format_version_diff`（128-163）把两份 TOML 解析为 `toml::Value` 后 `walk_diff`（168-203）锁步递归输出 `path: a → b` 叶级差异；`format_current`（223-227）无副作用地哈希当前生效配置。
- `governed_mutation.rs`：治理变更面——只开放 5 个白名单路径（`GovernedConfigPath::ALL` 15-21），每路径带 (min,max,是否整数) 边界（33-41）。`apply_governed_config_mutation(config, path, value, force, drift_ceiling)`（227-325）：**clone→校验→提交** 原子模式（317-318，不变量失败时原 config 不动，测试 463-482 验证）；`normalized_config_drift`（173-182）相对漂移 `|new-old|/max(|old|,|new|)`，非 force 且超 ceiling 报 `DriftCeilingExceeded`；`validate_governed_config_candidate`（205-225）检查两族跨字段不变量：verification 的 min≤strictness≤max 且全在 [0,1]，compression 阈值与 context_window min/max 嵌套一致。错误枚举带 `to_json()`（99-150）直接产出 API 可返回的结构化错误。
- `json_mutation.rs`：点路径 JSON 叶读写。`replace_existing_json_path`（65-84）**只替换已存在的叶、绝不创建**，先 `locate_existing_json_path`（19-53）完整验证（空路径/空段/未知段/父非对象/未知叶五类 typed 错误）再写入，失败零副作用（测试 107-151 断言原子性）。
- `lock_ext.rs`：`RwLockExt` trait（10-16）的 `read_or_recover`/`write_or_recover`（21-34）——poison 时 `e.into_inner()` 恢复数据并 `astra_core::agent_warn!("lock", ...)` 带 `#[track_caller]` 调用点。为自适应引擎组件统一锁中毒可观测性。
- `user_profile.rs`（1194 行，tests 自 983 行起）：M5 用户画像系统。
  - `UserProfile`（26-47）+ `apply_judged_turn_intent`（74-89）：**场景状态唯一写入方是类型化 TurnIntent**——查询文本/工具观察无写入路径；被禁场景可清空当前场景。
  - `TurnIntent`（533-577，`deny_unknown_fields`）：LLM judge 产出的结构化意图——domain/communicative_act/requested+prohibited scenarios/objective_relation/work_lifecycle/feedback/workspace_mutation/mutation_completion_scope/browser_verification_required。配套语义：`MutationCompletionScope::requires_workspace_receipt`（439-441）**Unknown 也要求回执（fail-closed）**，仅 External 豁免；`TurnCommunicativeAct::uses_tool_surface`（523-525）Acknowledgement/Social 关工具面，Unknown 保持可用；`WorkLifecycleIntent`（502-515）区分"一次性任务"与"需要持久任务图"。builder 方法链 `with_*`（581-632）。
  - `Scenario`（357-390）12 场景 + `suggested_tools`（661-676）+ `strategy_hints`（679-769）返回 `ScenarioStrategy{max_tools_per_turn, prefer_read_only, detail_level, memory_top_k, verification_strictness}`——QuickAnswer 故意最紧（max 20 工具/轮，751-760 注释防止 37 token 提问滚成 23 工具探索）。
  - `UserPreferences`（111-160）：verbosity/language_style/response_length/blocked_tools/config_overrides/custom_prompt_suffix，各 enum 有 `prompt_instruction()` 生成系统提示片段（200-209、247-283、345-351）。注意 `config_overrides` 仅两个 key 被实现（163-179，未知 key 静默忽略）。
  - `UserProfileStore`（833-941）：`RwLock<HashMap>` + 可选 JSON 持久化；`persist`（920-939）temp+rename 原子写、失败仅 eprintln。`UserProfileManager`（946-979）的 `observe_query`/`observe_tool` 刻意"不解读语义"只计数。

**对外接口**（lib.rs:15-27 re-export）：`RuntimeConfig`、`set_cli_overlay`、治理变更五件套、`read/replace_existing_json_path`、配置版本库全套、`UserProfile*`/`TurnIntent` 等。

#### 4.1.4 astra-runtime-env（9 文件）——能力驱动的运行环境模型

**模块职责**：定义 Astra 的**能力/绑定/策略三层解耦**模型。lib.rs 顶部（crates/astra-runtime-env/src/lib.rs:5-15）给出中心规则：

```
visible(tool) = provider 声明 offer && provider 类型匹配工具归属 && binding/runtime 能执行效果 && policy 允许
selected(tool) = 在 prompt 组装前确定性选定 provider offer
```

Prompt 可见的 schema 保持字节稳定；路由元数据是运行时证据而非模型面契约。所有子模块 `pub use module::*` 扁平 re-export（lib.rs:27-34）。

**关键类型与函数**：

- `tool.rs`（3542 行，tests 自 1617 行起）——工具注册表与能力检查：
  - `ToolLoadPolicy`（tool.rs:19-31）：AlwaysLoad（进默认 `tools[]`）/ Deferred（延迟目录，经 `tool_search` 激活）/ RequestScoped（请求级权限验证后才装）/ Internal（运行时实现细节，不给模型）。
  - `ToolRequirements`（126-326）：18 个 const 构造器（`control_plane`/`service_executor`/`project_read`/`project_write`/`shell`/`git_read`/`git_write`/`git_clone`/`git_remote_write`/`lsp`/`background_*`…）。值得注意的语义决策：`shell()` 只要求 **ReadOnly** workspace（245-260 注释：shell 是执行能力，诊断/构建/测试/认证 CLI 读都需要它，物理写权限由挂载/沙箱兜底）；`project_script()` 因脚本内容不可做参数级效果分类而**预先要求可写**（272-278）。
  - `WorkExecutionRole`（76-89）+ `WorkExecutionContext`（96-100）：Work 生命周期角色授权——Coordinator（作者/派发图）/ CoordinatorOrPrimaryAttempt / Attempt（恰好一个被选中的 WorkItem 尝试），`permits_work_execution_context`（384-408）做角色×上下文矩阵判定，`start_work` 不出现在被委派尝试的面（测试 1657-1706）。
  - `ToolRegistry::builtins()`（357 + builtin_tool_specs 420-524）：50+ 内置工具的单一事实来源，含每个工具的 load_policy 与注释里的设计理由（如 `agent`/`agent_fanout` 是执行拓扑而非第二 Work 图，425-434）。`tool_contract_version(name)`（412-417）：**对单个 ToolSpec 序列化字节做 SHA-256**——无关工具增删不会使既有工具的持久化调用失效。
  - `CapabilityResolver`（619-1101）：
    - `available_tool_surface_impl`（632-711）：先并入 provider 声明的动态（MCP）工具 spec（644-655），再逐 spec 判定 provider 冲突→admission（是否可见/选中 offer/候选与落选原因）→能力检查，**三列表均排序保证序列化确定性**（702-705，HashMap 迭代序不确定）。
    - `selected_provider_for_tool`（1125-1153）+ `provider_selection_rank`（1194-1224）：候选按 (rank, provider_type 字符串, provider_id) 全序排序取第一——ServiceOrRuntime 优先 runtime executor，RuntimeExecutor 内 CliLocal(0)<Edge(1)<Sandbox(2)<Orchestrator(3)。
    - `provider_conflicting_tools`（1260-1302）：四类冲突整体拒绝——重复 provider_id、同工具 schema digest 不一致（`provider_schema_digest_conflicts` 1316）、动态工具名撞内置名、provider 选择歧义（同 rank 并列，`provider_selection_is_unambiguous` 1327-1362）。
    - `check(spec, capabilities)`（947-1100）：链式验证 executor 类别 → workspace 存在性/读写（不可读时进一步区分"policy 拒绝"与"workspace 缺失"两种拒绝原因，996-1015）→ filesystem 读写 policy+process（1026-1051，注释声明这是对 from_bindings 推导的纵深防御）→ process/shell/git/lsp → network 分级 → credentials。每类失败产出结构化 `ToolUnavailableReason`。
    - `check_tool_call`（902-929）：**参数感知升级**——`git` 的 action 为 commit/stash/revert_commit/push/clone 时按 `git_write` 检查、push 再升 `git_remote_write`（909-917 + 1459-1468）；`lsp` 的 `dry_run=false` 升 `project_write`（919-921）。
- `binding.rs`——三类绑定与 RunBinding 组装：
  - `WorkspaceBinding`（30 + 构造器 39-88）：kind（None/LocalFilesystem/EdgeWorkspace/ServerSandbox/CloudWorkspace）× authority（None/ReadOnly/ReadWrite）× cwd × persistent。
  - `ExecutorBinding`（127 + 136-184）：kind（ControlPlane/ServerRuntime/LocalCli/EdgeAgent/OrchestratorManaged/Mcp）× transport（InProcess/EdgeWebSocket/EdgeLedger/GatewayRelay/SandboxResidentAgent/McpHttp）× status。
  - `RuntimeBinding`（312 + 328-439）：session_manager×isolation_backend×launch_driver 三元组 + platform + interaction_channels。六个预制构造器：none/host_process/gvisor/nvidia_openshell/kubernetes/oci_container——NVIDIA OpenShell 声明全部 7 种交互通道但 `supports_long_sessions=false`（380-401，须由运行时证据推翻）；OCI/gVisor 只声明 Exec+StdinPipe（796-823 测试：提供者通道需显式证据）。
  - `runtime_execution_provider_type`（193-212）：**workspace kind × executor kind 配对**→provider 类型（LocalFilesystem+LocalCli=CliLocal 等），错配返回 Unknown（不给推断所有权，测试 856-914）。
  - `RunBinding::resolve[_with_provider_declarations]`（463-501）：capability 推导 + `CapabilityResolver.available_tool_surface_for_providers` + `apply_policy_tool_allowlist`。四个场景预设：`cloud_control_plane`（无工作区）、`local_developer`、`edge_developer`、`read_only_snapshot`（503-541）。
  - `apply_policy_tool_allowlist`（621-682）：policy 白名单过滤工具面，denials 用 BTreeMap 合并排序去重——**输出确定可序列化**。
  - `RuntimeEnvironmentAdvertisement`（684-698）：schema_version=1 的结构化 JSON 广告；配合 `AvailableToolSurface.admissions` 的 `#[serde(default, skip_serializing)]`（tool.rs:582），**admissions 不进序列化**——路由证据不得扰动 prompt 字节（binding.rs 测试 706-729）。
- `capability.rs`：`EffectiveCapabilitySet::from_bindings`（74-195）——纯函数把四类输入折叠为四组布尔/枚举能力。关键推导：workspace 可读 = 绑定且有 authority 且 policy 允许读（97-102）；runtime 拓扑已知 = 三元组均非 None/Unknown（106-115）；`runtime_has_git/lsp = process && workspace_readable`（181-182）；executor 各能力 = 可达 && transport 已知 && kind 匹配（149-177）。
- `policy.rs`：`IsolationIntent` 六级 + `satisfies`（41-49，**ProviderEnforced 是授权委托而非隔离级别，不满足任何具体要求**，只能自等）；`ResourceLimits::interactive()`（30s/1MiB）与 `long_session()`（1800s/8MiB/86400s 后台，108-125，注释：长任务不能因旧的 5 分钟交互上限被砍）；手写 Deserialize（167-190）强制 f64 有限性、NaN 感知 PartialEq（144-165）；`ToolName` newtype 拒绝空与 `"*"`（通配哨兵，230-287）；`PolicyIntent`（306-393）四个预设：cloud_control_plane（ProviderEnforced+NoAccess+AllowList+Disabled 凭据）、local_developer（Process+ReadWrite+Open+UserApproved+long_session）、read_only_review、strict_orchestrator（GVisor+ScopedInjection）。`allows_tool`：**空白名单=全放行**（383-388）。
- `provider.rs`：`CapacityProviderType` 9 值（14-25）；`CapacityProviderDeclaration`（130-137）持有 tool_names 集合与逐工具 schema digest；**wire 侧 TryFrom 校验**（150-189）：provider id 合法性、MCP 类型必须命名空间化工具名（`mcp__` 前缀）、digest 键不得引用未声明工具、旧 `dynamic_prefixes` 字段被 deny_unknown_fields 显式拒绝（787-802 测试）。digest 计算 `canonical_sha256_digest`（317-326）：域分隔（kind + `\0`）+ **递归排序 JSON 对象键**（328-342）后 SHA-256——键序无关（测试 988-1020）。`runtime_workspace_provider_declares_tool`（529-552）：`display_sixel` 仅 CliLocal（终端渲染是访问面能力）、`powershell` 由 RuntimePlatform 事实门控（用户说 "Windows" 不算证据）。构造器对非法 id **panic**（620-630，canonical helpers 是唯一事实源）。
- `runtime_environment.rs`：会话与调用契约。`PolicyRevision`（21-29，saturating next）；`CompiledRuntimePolicy::require_runtime`（66-82）用 `isolation_enforceable` 矩阵（99-138）判定 runtime 能否执行隔离意图（GVisor 意图只有 GVisorRunsc 满足）；`requires_session_recreate_from`（84-90）：update_mode 或 isolation/filesystem/credentials 任一变化需重建会话。`RuntimeToolOutcome::completed/failed_after_start`（396-441）与 `RuntimeError`（522-644）构成**错误恢复契约**：kind（27 个 snake_case 可序列化变体，446-503）+ retryable + execution_started + side_effects_maybe + `RuntimeRecoveryAction`（507-518，如 InspectEffectsBeforeRetry/RecreateRuntimeSession）——传输中断类错误自动标 retryable+副作用未定（579-587）。`runtime_result_fields*`（646-686）向每个工具结果 metadata 注入三个键（runtime_environment_advertisement / runtime_session / runtime_policy_evidence）。`RuntimeEnvironment` async trait（756-790）：prepare_session/execute_tool/update_policy/destroy_session 四操作。校验函数（688-753）先 policy 白名单再 surface 准入再能力检查。
- `workspace.rs`：`WorkspaceSource` 13 变体 tagged serde（21-57，LocalPath/EdgePath/ServerSandbox/GitCheckout/UploadedSnapshot/Template/DatasetBundle/ArtifactBundle/Scratch/PersistentVolume/ProviderManaged）；`WorkspaceProvisionRequest::validate`（96-116）检查 id 安全性（`validate_workspace_id` 290-299 仅 `[A-Za-z0-9_-]`，防路径穿越）与 source-kind 配对（`source_matches_kind` 336-385）；`WorkspaceRecord::mount_plan`（150-179）要求绝对路径挂载点（387-397）；`WorkspaceProvisioner` async trait（270-288）。
- `local_state.rs`：**纯 re-export** astra_core::local_state（3-5），使本 crate 成为本地状态路径策略的稳定门面。

**对外接口**：全部扁平 re-export。核心消费面：RunBinding/RuntimeEnvironment trait/ToolRegistry/PolicyIntent/RuntimeError——被 astra-turn-core（会话执行）、runtime（实现）、services/astra-edge（服务端）、astra-skills/astra-thin-client（能力查询）使用。

#### 4.1.5 astra-credentials（1 文件）——CLI 凭据存储

**模块职责**：多 profile 的本地凭据文件（`~/.astra/credentials.json`）读写，跨进程锁 + 原子写 + Unix 0600 权限，以及 profile 解析与本地属主派生。被 astra-cli、astra-edge、astra-test-harness 消费。

**关键类型与函数**（crates/astra-credentials/src/lib.rs）：

- `CredentialsFile`（30-36）：`current_profile` + `profiles: HashMap<String, Profile>`；`Profile`（39-55）含 username/account_id/access_token/refresh_token/last_session_id/memoria_api_key，**手写 Debug 把敏感字段打成 `***`**（57-71）。
- `local_profile_owner_id(profile_name, account_id)`（79-99）：**域分隔 SHA-256**（`"astra-cli-local-owner-v1\0profile\0"...\0account\0"`）→ `cli-profile-v1:<hex>`——本地工件属主 id；account_id 入哈希使同名 profile 换账号后不共享本地会话状态（username 仅显示属性，不可作所有权边界，43-46 注释）。空名/空 account_id 报错。
- `CredentialStore::resolve_profile_name[_with_default]`（122-145）：**优先级 cli_override > `ASTRA_PROFILE` 环境变量 > 文件 current_profile > 兜底默认**（"default" 或调用方旧默认如 "admin"）。
- `load()`（152-168）：文件不存在直接返回默认且**不创建锁文件**（纯读者不在凭据目录留垃圾，149-151 注释）；存在则取 `.json.lock` 共享锁后读取。
- `mutate(f)`（186-252）：**读-改-写事务**。独占锁加在**旁路锁文件** `credentials.json.lock` 上而非数据文件（198-199 注释：rename 原子性会使旧 fd 指向已 unlink 的 inode）；随后读当前数据→应用闭包→`write_private_file` 写 `json.tmp`（Unix 0600 + fsync，274-298）→rename 原子替换；任一步失败 best-effort 删除 tmp（敏感字节不留尸，236-248）。**Windows 分支是显式 TODO**（299-327）：无 ACL 限制、无 flush-before-rename 保证，代码注释承认共享 Windows 机器上 tmp 可能被其他用户读取。
- `test_override` 模块（341-418）：进程级凭据目录覆盖（`set_test_credentials_dir` 返回 RAII `CredentialsDirOverrideGuard`），**用 Mutex+Condvar 串行化替代曾被使用的环境变量方案**——env 是进程全局且并行测试下改写不安全（330-335 注释）；等待前一个 guard 5 秒超时即 panic（防泄漏 guard）。
- `default_path()`（423-435）：test 覆盖 > `ASTRA_CLI_CREDENTIALS_DIR` > `~/.astra/credentials.json`。

### 4.2 共享内核（crates/core，包名 astra-core）

astra-core 是整个 workspace 的最底层共享 crate：不含业务执行逻辑，只提供"契约 + 基础设施"——配置装配（`AppSettings`/`ServerConfig`）、MatrixOne 连接池与兼容性技巧（`SharedPool`、null-shape 注释、`UNION ALL` 绑定）、统一错误分类（`ErrorKind`）、身份与路径校验、运行时限额（`RuntimeLimits`）、日志宏、以及 Phase-0 history-work 计量与生产基线契约。Cargo.toml（`crates/core/Cargo.toml:8-22`）声明 14 个直接依赖（sqlx/mysql、axum、tokio、reqwest、serde、toml、sha2、tracing 等），自身依赖极薄（不依赖任何兄弟 crate），因此能被所有上层 crate 引用；据 grep 统计，workspace 中 17 个 crate 的 Cargo.toml 声明依赖 astra-core（推断，含少量噪声）。`lib.rs:598` 还 `pub use sqlx;`，让上层无需直接声明 sqlx 依赖即可使用池类型。

模块组织上 `lib.rs` 除模块声明与再导出外，本身承载了三类内容：(1) MatrixOne 兼容辅助（`lib.rs:14-91`）；(2) 全局连接配额（`lib.rs:192-309`）与 `SharedPool`（`lib.rs:757-878`）；(3) Web 层共享契约：`ErrorResponse` 与 `error_response*` 辅助（`lib.rs:881-955`）、`SubRunState` 委托子运行状态机（`lib.rs:639-755`）、`bearer_token`/`is_duplicate_key_error`/`canonical_json_string`（`lib.rs:134-177, 959-990`）、worktree 基路径常量（`lib.rs:604-609`）。

#### 配置装配（config.rs，约 1700+ 行）

核心结构 `AppSettings`（`config.rs:964-982`）聚合 `MatrixOneSettings`、`JwtSettings`、`ApiSettings`、`MemoriaSettings`、`runtime_root_secret`、`token_encryption_key`、provider_request_auth / edge_token_auth / external_providers、部署级 `provider_capabilities` / `disabled_tool_offers` / `provider_allowed_tools`。手工实现 `Debug` 把所有秘密字段打码为 `[REDACTED]`（`config.rs:984-998`；`MatrixOneSettings`/`JwtSettings`/`AuthConfig` 等同样打码，`config.rs:1179-1197, 1428-1440, 435-458`）。

配置优先级链（关键设计）：`AppSettings::from_env`（`config.rs:1001-1007`）→ 若 `ASTRA_CONFIG_SOURCE` 未设为 `explicit-env` 则先 `dotenvy::dotenv()` 加载 `.env`（`config.rs:1002-1004`；`explicit_env_config_requested` 在 `config.rs:24-37` 对未知取值 fail-closed 报错）→ `ServerConfig::load()`（`config.rs:836-877`）依次叠加：内置默认值 → `/etc/astra/server.toml`（系统级）→ `~/.astra/server.toml`（用户级，经 `local_state::local_state_root()`，可被 `ASTRA_LOCAL_STATE_ROOT` 重定向）→ `apply_env_overrides()` 环境变量最高优先级 → `validate()`。TOML 解析先经 `reject_deprecated_auth_toml` 拒绝旧式 auth 键（`config.rs:899-908`）；`DeploymentConfig` 用 `#[serde(deny_unknown_fields)]`（`config.rs:111-112`）拒绝未知键。随后 `from_server_config`（`config.rs:1014-1063`）用一个闭包 `lookup` 把"ServerConfig 已解析值（TOML+env 已合并）"映射回 env 键名视角，再落入统一的 `from_lookup`（`config.rs:1082-1157`）；lookup 未覆盖的其余键回退 `env::var`（`config.rs:1047`）。最终装配后再跑三组部署校验（provider_capabilities / disabled_tool_offers / provider_allowed_tools，`config.rs:1057-1061`）。`from_map`（`config.rs:1065-1067`）允许测试/调用方直接注入键值表。

必需键与不安全默认值：`required_value`（`config.rs:1638-1661`）对 `MATRIXONE_PASSWORD`、`ASTRA_RUNTIME_ROOT_SECRET`、`ASTRA_JWT_SECRET` 实行"缺失即 `MissingRequiredKey` 错误，除非 `ASTRA_ALLOW_INSECURE_DEFAULTS=1`（打 `tracing::error!` 警告）"的策略。`JwtSettings::from_lookup`（`config.rs:1443-1482`）额外强制：默认占位 secret `change-me-in-production` 与长度 <32 的 secret 在未开启 insecure 开关时直接 `ConfigError::Validation` 失败（`config.rs:1467-1479`）；JWT access TTL 默认 10080 分钟（7 天，注释说明旧值 60 分钟对开发太短），refresh 默认 30 天（`config.rs:1451-1460`）。数据库逻辑名由 `resolve_database_name(_or)`（`config.rs:1601-1620`）解析：`ASTRA_DATABASE_PREFIX` 非空时拼 `{prefix}{ASTRA_DATABASE}`，默认基名 `astra_runtime`，用于 dev/CI/prod 隔离。数值解析 `parse_or_default`（`config.rs:1663-1674`）失败报 `InvalidInteger`。

`MatrixOneSettings`（`config.rs:1161-1177`）含 host/port/user/password/database 与 5 个池参数；`validate`（`config.rs:1362-1388`）校验库名 1..=64 字节、min≤max、各超时 >0。`database_url_with_password`（`config.rs:1392-1401`）用 `encode_mysql_url_component`（`config.rs:1404-1418`）做百分号编码后拼 `mysql://` URL（专供建池，禁止打日志）；`database_url`（`config.rs:1345-1353`）返回密码打码版本。`mysql_cmd`（`config.rs:1224-1235`）构造 `mysql` CLI 命令，密码经 `MYSQL_PWD` 环境变量传递以避开 `ps` 泄露，并带 `--connect-timeout=5`（常量 `MO_CLI_CONNECT_TIMEOUT_SECS`，`config.rs:1200`）。三个入口：`from_env`（dev 安全回退，密码回退 `"111"`，`config.rs:1242-1274`）、`from_env_strict`（生产，缺 `MATRIXONE_PASSWORD` 即 Err，`config.rs:1280-1315`）、`mock`（仅 test/dev-defaults，`config.rs:1324-1339`）。`ServerRuntimeConfig`（`config.rs:698-816`）承载 9 个运行时限额（TOML `<Option>` 字段 + 默认值访问器 + env 覆盖 `ASTRA_MAX_TURNS` 等，`config.rs:799-815`），默认值常量来自 runtime_limits.rs。

#### SharedPool 与全局连接配额（lib.rs）

`matrixone_pool_options`（`lib.rs:14-28`，私有）把 `MatrixOneSettings` 翻译成 `MySqlPoolOptions`：max/min connections、`test_before_acquire(true)`、acquire/idle/max_lifetime 时长。进程级配额：`GLOBAL_CONNECTION_ALLOCATED: AtomicU64`（`lib.rs:206`）+ 上限 `DEFAULT_GLOBAL_MAX_CONNECTIONS=500`（`lib.rs:195`，可用 `ASTRA_DB_GLOBAL_MAX_CONNECTIONS` 覆盖，经 `LazyLock` 只读一次，`lib.rs:210-219`）。`try_allocate_with_cap`（`lib.rs:259-283`）用 CAS 循环原子预留，饱和加法防溢出；`release_global_connections`（`lib.rs:289-309`）CAS 释放并在下溢时 `tracing::warn!`。副作用与坑：计数器是进程本地的，多实例同库部署需自行按实例数折小 cap（`lib.rs:200-205` 文档明示，属事实）。

`SharedPool`（`lib.rs:793-800`）= `Arc<Pool<MySql>>` + settings 副本 + `quota_released: Arc<AtomicBool>`。`SharedPool::new`（`lib.rs:810-834`）先原子预留配额，建池失败立即回滚配额（`lib.rs:823-827`）；`get/settings/stats`（`lib.rs:836-850`）提供访问器（stats 返回 size/num_idle）；`close`（`lib.rs:852-855`）关池后释放配额。`Drop`（`lib.rs:858-869`）只在 `Arc::strong_count(&self.pool)==1`（最后一个包装者）时释放配额——因为 SharedPool 会被 clone 进大量 service 结构体，任意 clone 析构即释放会让计数器说谎；`release_quota`（`lib.rs:871-878`）用 `AtomicBool::swap` 保证 close()+Drop 不会双重释放。另有底层 `connect_matrixone`（`lib.rs:773-790`）给"确实想要独占池"的调用点，但文档明确：调用者必须自行 `release_global_connections`，忘记即永久泄漏配额（`lib.rs:757-772`）。调用关系：SharedPool 是服务层标准注入物，workspace 中约 84 个 .rs 文件引用（grep 计数，推断）；上层应注入 SharedPool 而非在 service 方法内隐式重连。

#### MatrixOne 兼容技巧（lib.rs）

两个针对性 workaround（均附版本注释，事实）：

1. **null-shape 注释**：`matrixone_statement_with_null_shape(sql, nullable_values_present)`（`lib.rs:47-55`）在 SQL 尾部追加 `matrixone_null_shape_comment`（`lib.rs:59-68`）生成的 ` /* astra-null-shape:0101... */` 注释。动机（`lib.rs:39-46` 注释）：MatrixOne 4.2 的缓存 prepared statement 会保留首次执行时的 NULL 位，复用该语句写入非 NULL 值会存成 NULL；给每种"可空参数形态"一个不同 SQL 文本 = 不同语句缓存身份，从而在 4.1.4 与 4.2 上保持同一写契约，且不必全局关闭语句缓存。副作用：SQL 文本必须与实际绑定值的 null 布局同步生成，否则兼容性失效（推断）。
2. **UNION ALL 绑定集合**：`push_matrixone_bound_string_set`（`lib.rs:76-91`）向 `QueryBuilder` 追加 `(SELECT CAST(? AS CHAR) AS value UNION ALL SELECT CAST(? AS CHAR) AS value ...)`。动机（`lib.rs:70-75` 注释）：MatrixOne 4.2 对跨 join 的 prepared `IN (?, ...)` 谓词可能只返回匹配行前缀；改为派生 `UNION ALL` 关系让每个值保持绑定，两个版本都能返回完整结果。

调用关系（grep 事实）：这两个 helper 被 `crates/astra-plan/src/repository.rs`、`crates/runtime/src/data_layer/storage.rs`、`crates/services/src/{runs,events,event_ingestion,inference_execution,prompt_delta,state_projection,session_context_coordinator,work/events_repository}.rs` 等持久层广泛使用；配套集成测试 `crates/services/tests/matrixone_prepared_statement_compat_db_it.rs`。

#### 身份与路径契约（identity.rs、session_id.rs、build_info.rs、local_state.rs、model_override.rs）

- `identity.rs` 全文仅 9 行：`USER_ID_MAX_LEN=128` 与 `USERNAME_MAX_LEN`（`identity.rs:5-8`）——身份"模型"刻意收窄为长度契约：provider 授权主体含 provider+外部 subject，故比内部 UUID 更宽。真正的身份体系（用户表、principal 解析）在 services 层，core 只固化持久化边界。
- `session_id::validate`（`session_id.rs:17-52`）：session ID 作为文件路径组件的唯一校验源——仅 ASCII、≤200 字节、禁 `/` `\` `..` 控制字符、`Path::components()==1`，显式防御 Unicode 不可见字符/RTL 覆盖/homoglyph（`session_id.rs:9-16` 注释）。
- `build_info`（`build_info.rs`）：编译期注入 `ASTRA_BUILD_TARGET/PROFILE/GIT_SHA/GIT_DIRTY`，`current()`（`:21-29`）产出 schema 化 `astra.build_info.v1` JSON；`write_json_if_requested`（`:36-48`）仅在 argv 恰为 `--build-info-json` 一个参数时输出——入口在任何初始化之前调用的零副作用探针。
- `local_state`（`local_state.rs`）：`ASTRA_LOCAL_STATE_ROOT` 显式根（空值视为未设，`:31-33`），默认 `~/.astra`（`:35-39`）；外部编排器用它而不是改写 `HOME`。
- `model_override`（`model_override.rs:10-31`）：`normalize_model_override` 把 `default`/空白/含控制字符的模型名折叠为 `None`（符号性 default 不得持久化或作为 override 发送），`missing_model_selection_error` 产出 `ErrorKind::MissingModelSelection` 的 `ClassifiedError`。

#### history-work 计量与生产基线（history_work.rs、history_work_baseline.rs、src/bin/*）

`history_work.rs` 是 Phase-0 低基数 O(history) 计量：`HistoryWorkSite` 枚举 154 个埋点位（`history_work.rs:19-174`，`COUNT=154` 于 `:177`），每 site 8 个 `AtomicU64` 静态计数器（events/bytes/rows/admission_units/queue current/peak/accounting_errors，`history_work.rs:836-849`）。公开 API：`record_bytes/record_rows/record_admission_units/record_operation`（`:1170-1191`）、`serialized_bytes/record_serialized_value`（`:1318-1346`，serde_json 测量）、`QueueBytesReservation`（`:1408-1553`，RAII 队列驻留字节记账，Drop 时 CAS 释放并对下溢记 accounting_error + `tracing::error!`）。`HistoryWorkScenario::begin/finish`（`:1055-1124`）提供独占进程内测量区间（拒绝嵌套，begin 持锁清 `ACTIVE_SCENARIO_ID` 使 finish 后的记录归属下一场景，`:1102-1106`），未 finish 的场景在 Drop 中清理并 warn（`:1127-1144`）。覆盖完整性由 `HISTORY_WORK_COVERAGE_COMPLETE=true` 编译期断言兜底（`:818-819`），已知豁免清单为空数组（`:834`）。隐私约束：绝不记录消息内容或 session/request ID（`:1-6` 模块注释）。开关 `instrumentation_enabled()` 读 `ASTRA_HISTORY_WORK_TRACE`（`:1161-1168`，env 名定义于 `:15`）。

`history_work_baseline.rs` 是 fail-closed 的基线"契约"层：自身不执行工作负载、无递增计数器 API（`:1-6` 注释）。`ProductionProcessCaptureGuard::from_env`（`:185-266`）在真实 CLI/Server/Edge 进程内由 `ASTRA_HISTORY_WORK_BASELINE_FRAGMENT` 触发，强制要求 TRACE=1 + run_id + git_sha + scope 四个 env 并校验构建 attestation（`verify_current_build_attestation`，`:470+`，比较 `env!("ASTRA_BUILD_GIT_SHA")`、拒绝 dirty 构建）；`finish`（`:268-305`）对快照求 delta 并经 `write_json_atomic`（`:393`；临时文件 + `sync_all` + rename + 父目录 fsync 的 `AtomicWriteStage`，`:308-377`）落盘。`ProductionBaselineArtifact::verify`（`:1259+`）逐条验证 provenance/时间窗/场景绑定/相关性/provider 用量/cache/projection/compaction/fairness 证据。三个 `src/bin/` 二进制为开发者基线工具（详见文件清单表）。

#### work_unit（异步工作观察契约）

`work_unit.rs` 定义跨 CLI/Server/Edge 的异步工作观察协议：`WorkUnitStatus`（10 态，`:15-26`）、`WorkUnitObservationMode`（Transition/Current/Wait/Historical/Diagnostic，`:79-90`，只有前三者算 live 进度）、`WorkUnitWakePolicy`（谁拥有下一次用户可见更新，默认 None，`:105-119`）。`WorkUnitObservation`（`:128-186`）要求 producer 单调 `revision>0`，序列化进工具结果保留字段 `work_unit_observation`（`:11`）。`WorkUnitObservationTracker::observe`（`:236+`）按 revision 拒绝乱序/回退，终态进 tombstone 防止迟到的快照"复活"已完成工作（`:241-256`）；`ActiveWorkRegistry`（`:389-411`）用 Mutex + `sync_poison` 包装成会话级权威，并实现 `ActiveWorkProvider` async trait（`:413-423`，async-trait 依赖的唯一生产使用点）。

#### 其余模块速览

- **error_kind.rs**（约 1100 行）：统一错误分类。`ErrorKind` 26+ 变体（`error_kind.rs:23-103`）覆盖 LLM provider/流式/连接池/预算/网络/工具/领域（`DatabaseError` 区分于 `Network`；`Stall` 表示 agent 侧停滞；`MissingModelSelection` 禁止运行时擅自选模型）。字符串边界的三级兜底分类器：`classify_llm_error_message`（`:675`）、`classify_model_resolution_error_message`（`:722`）、`classify_tool_output`（`:759`），以及 `is_llm_context_window_error`（`:622`）。`ClassifiedError`（`:547`）= kind+message 载体；`ToolFailureEvidence`（`:143-159`）附 `ToolFailureCause`（10 类，`:110-125`）、retryable、建议性 `ToolRecoveryAction`（`:129-140`，文档强调是证据不是执行命令）。
- **observation.rs**（约 1500 行）：回合指标"镜子而非教师"（`:1-14` 注释）。`TurnMetrics`（`:49-77`）聚合回合数/工具调用按 family 分布/变异计数/错误连击等；`classify_tool_family`（`:113+`）把工具名归入 Read/Write/Git/Shell/Other 五族；另有 `Urn`/`EvidenceRef`/`ObservationRecord` 等观察面类型与 `push_graph_node/push_graph_edge` 图投影辅助。
- **observation_journal.rs**：跨回合环形日志（容量 16，`observation_journal.rs:35`）。`JournalEntry` 从 `&TurnMetrics` 转换（`:145`）；`ObservationJournal`（`:221`）计算趋势（≥3 条起，`:38`）与策略验证；分层原则：core 只报告 `JournalFacts` 事实，策略决策在 `astra_runtime::turn::runtime_policy`（`:8-27` 注释）。`render_compact_status`（`:581`）产出紧凑状态行。
- **composite_snapshot.rs**（约 900 行）：组合快照 = 五维状态引用的"引用包"（SessionState/DataSnapshot/MemorySnapshot/GitCommit/WorkspaceState，`composite_snapshot.rs:38-58`），引用只定位不载入；时间戳格式刻意对齐底层数据源（MatrixOne ISO8601、Memoria epoch，`:19-27` 注释）；`CompositeSnapshotBuilder`/`SnapshotSpec`/`DataSnapshotProvider`（`:634+` 为 async provider trait，`:695` Noop 实现）支撑 fork/rollback。
- **runtime_limits.rs**：`RuntimeLimits`（`:44-66`）9 字段 + `OnceLock` 全局单例 `global()`（`:114-116`）；`from_config_with_env`（`:93-111`）TOML 基础上 env 再覆盖；`MODEL_CONTEXT_INPUT_BUDGET_RATIO=0.80`（`:35`）把模型上下文窗口的 80% 作为输入预算；`context_window_for_model*`（`:192-210`）刻意不按模型名猜测窗口，只透传注册表覆盖值；`require_admitted_model_input_tokens`（`:169-183`）要求已准入模型必须带正 context_window 元数据（fail-closed）。`DEV_MATRIXONE_PASSWORD="111"` 与 `warn_default_credentials_once` 被 `dev-defaults` feature 门控（`:226-242`），生产二进制无法链接该回退。
- **net.rs**：三层代理策略（`net.rs:1-24` 注释）：内部恒本地流量用 `build_internal_http_client`（`:33-56`，强制 `.no_proxy()`，失败回退极简 no-proxy 客户端）；目标相关流量用 `client_builder_for_target`（`:140-147`，loopback 绕过代理、远程尊重环境——强制出稿代理沙箱依赖此语义）；外部 provider 流量用 `apply_env_proxy`（`:69-110`，HTTPS_PROXY>https_proxy>ALL_PROXY>all_proxy 优先级，坏 URL warn 跳过）。`url_is_loopback`（`:114-130`）识别 localhost/*.localhost/环回 IP。
- **model_wire.rs + model_wire/thinking.rs**：聊天推理线缆规则。`apply_chat_output_token_limit`（`model_wire.rs:12-22`）按协议（非模型名）选择 `max_tokens`（anthropic/deepseek）或 `max_completion_tokens`（openai 系）并移除废弃字段。`thinking.rs`：`ThinkingProtocol` 5 值（`thinking.rs:8-17`，Unknown 表示"无适配知识"而非"禁用推理"）；`apply`（`:31-77`）先清除全部 thinking 相关键再按协议写入，Unknown 不动 body；`canonical_zero_temperature`（`:82-104`）仅对三个官方域名且 URL 形状精确匹配才默认零温度（防止网关标签误伤）；`canonical_thinking_protocol`（`:108+`）按 provider+host 给维护内适配默认，显式配置优先。
- **feedback.rs**：反馈信号只做观察存储、不改运行时策略（`:1-5` 注释）；`FeedbackSignalStore` 环形有界（默认 1000，`:14`；批量持久化间隔 10，`:198`）。
- **delegation.rs**：`DelegationOutcomeTracker` 按 (scenario, pattern) 嵌套 BTreeMap 统计委托成败（`:44-48`，避免拼接键碰撞），容量超限驱逐观察数最少的条目（`:89-107`），持久化 best-effort（错误只记 stderr 不上抛，`:109-112` 注释）。
- **drift.rs**：焦点漂移证据类型——`DriftCause`（压缩丢失/记忆未命中/话题漂移/预算压力/歧义指令/未知，`drift.rs:8-43`）、`DriftEvidence` 携带 `ConfidenceInterval`（`:47-59`）。
- **confidence.rs**：`ConfidenceInterval`（point/lower/upper，构造器钳制保持 `0≤lower≤point≤upper≤1`，`confidence.rs:22-58`）取代裸 f64，防不确定性信息静默丢失。
- **tool_offer.rs / tool_schema.rs / canonical_names.rs**：工具面契约。`tool_offer_id` 拼 `<tool>@<provider>` 并 debug_assert 双方合法（`tool_offer.rs:5-15`）；`is_valid_*` 校验器限定 ASCII 字母数字/`_`/`-`（provider 额外允许 `.` `:`，拒绝 `@` 与路径形状，`:56-64`）；MCP 命名空间前缀 `mcp__` 仅是名称形状谓词（`:24-31`）。`tool_schema.rs:30` `tool_schema_name` 对非 `"function"` 类型 fail-closed、接受省略 type 的简写形状（`:1-17` 注释）；另有排序/按名过滤/冲突名提取（`:45-85`）。`canonical_names.rs` 提供名称去重规范化与事件元数据的 canonical 字段提取（`metadata_tool_name` 只认显式 `tool_name` 不认歧义的 `name`，`:46-52`）。
- **trace_types.rs**：`TraceCategory` 16 类可按会话开关的追踪类别（`trace_types.rs:13-44`）+ `TraceLevel/TraceVerbosity`。
- **log.rs**：`agent_error!/agent_warn!/agent_info!/agent_debug!` 宏统一 target `astra.agent` + component 字段（`log.rs:10-57`）；`agent_persist_fail!`/`log_persist!`（best-effort 持久化记日志不上抛，`:61-81`）；`agent_escalation!`（`:85-95`）。宏经 `#[doc(hidden)] pub use tracing`（`lib.rs:566-568`）让调用方无需直接依赖 tracing。
- **session_env_overlay.rs**：进程级线程安全 env 叠加层（静态 `RwLock<Option<HashMap>>`，`:11`），避免 Rust 2024 下 `std::env::set_var` 的不健全性；`get` 叠加层优先回退真实 env（`:30-38`），`None` 值表示删除；`apply_to_command` 把叠加应用到子进程（`:77-91`）。
- **sync_poison.rs**：三个 `recover_*_lock` 辅助，锁中毒时 `into_inner()` 恢复并 `agent_warn!`（`sync_poison.rs:7-36`）——项目约定：锁中毒不视为致命，恢复并留痕。
- **process_runtime.rs**：`build_process_runtime`（`:15-21`）构建多线程 Tokio runtime，worker 栈固定 16 MiB（`PROCESS_WORKER_STACK_BYTES`，`:13`）并命名 `astra-worker`——深层组合 future 在平台默认栈下会栈溢出中止进程，故显式约定（`:1-7` 注释）。

### 4.3 能力层（astra-tools / astra-skills / astra-pipeline / astra-plan / astra-prompts / astra-sandbox）

能力层是 Astra v0.2.4 中"agent 能做什么"的载体：工具契约与执行（astra-tools）、技能系统（astra-skills）、执行观测与崩溃恢复管线（astra-pipeline）、计划模式（astra-plan）、提示词模板（astra-prompts）、托管执行安全边界（astra-sandbox）。共 6 个 crate、101 个生产 `.rs` 文件（38+31+11+6+7+8）。

> **术语约定**：本节"turn"指一轮用户消息触发的 agent 循环；"workspace"指当前会话绑定的可变工作区根（可与 project_root 不同）；"receipt"（回执）指执行器签发的结构化执行事实（如 workspace_mutation_receipt）；"convergence"（收敛）指"目标状态已达成"的类型化判定。

> **重要事实澄清（与任务假设的差异）**：任务背景中"Context Pipeline（学术论文 ContextPipe 对应实现）位于 astra-pipeline"的说法与代码不符。`astra-pipeline` 的 Cargo.toml 自述为 "Astra agent learning pipeline — calibration, routing, patterns"，其内容是 **Step Protocol v2 + 检查点/事件日志/崩溃恢复/工具健康度**；而 Plan→Bind→Optimize→Serialize 的上下文装配管线位于 **`crates/astra-turn-core/src/context/pipeline.rs:1-4`**（模块头注释明确写 "Plan -> Bind -> Optimize -> Serialize -> Explain/Metrics"，由 `ContextPipeline::run`（pipeline.rs:92）与 `run_adaptive`（pipeline.rs:100）驱动）。本片段以代码为准，并在 4.3.3 与 CH7 中对两者分别说明。

#### 4.3.1 astra-tools — 工具契约与共享执行（38 文件）

**crate 定位**（lib.rs:1-9）：从 CLI 抽出的纯工具执行库，CLI（`CliToolExecutor`）与 Server（`ServerToolExecutor`/`RuntimeToolExecutor`）都通过组合其 `DefaultToolExecutor` 来获得完整工具集。依赖 astra-sandbox（路径/命令策略）、astra-core（RuntimeLimits/ToolFailureEvidence）、astra-memoria、astra-prompts、astra-services、astra-turn-types。

##### 核心契约（lib.rs）

- **`ToolResult`**（lib.rs:76-88）：工具执行的统一返回值。四字段：`output`（给 LLM 与用户的主文本）、`metadata: Option<Map<String,Value>>`（结构化元数据，供 tool_call_end 事件等）、`is_error`、`exit_semantics: Option<ExitSemantics>`（把"语义性非错误结果"如 grep 无匹配、diff 有差异、test false 与真正的执行失败区分开）。builder 链式方法：`text`（lib.rs:92）、`error`（lib.rs:102）、`with_failure_evidence`（lib.rs:114，附带源码作者声明的恢复证据，不授权重试）、`with_exit_semantics`（lib.rs:128）、`with_workspace_mutation_applied`（lib.rs:146）、`with_workspace_desired_state_converged`（lib.rs:157）、`with_workspace_mutation_partial`（lib.rs:176，多目标写入部分提交时打 quarantine 标记并附 `workspace_mutation_partial_receipt.v1` 回执）、`with_result_class`（lib.rs:210）、`with_exit_code`（lib.rs:220）。
- **`ToolExecutor` trait**（lib.rs:275-320）——工具执行的核心抽象：
  - `async fn execute(&self, name: &str, args: &Value) -> ToolResult`（lib.rs:278）：按名分发；
  - `async fn execute_with_cancel(..., cancel_token: Option<&CancellationToken>)`（lib.rs:284-299）：默认实现用 `tokio::select!` 把 `execute` 与取消令牌竞速，取消时返回 `cancelled_tool_result`；
  - `fn tool_schemas(&self) -> Vec<Value>`（lib.rs:302）：返回 OpenAI function-calling 格式的 JSON Schema 列表；
  - `fn project_root(&self) -> &Path` / `fn workspace_root(&self) -> &Path`（lib.rs:305/311，后者默认等于前者，server 模式下可窄化为会话工作区）；
  - `async fn execute_with_metadata(...)`（lib.rs:317）：默认委托 `execute`，供需要回滚 journal 等扩展元数据的包装器覆写。
  - 取消是**终态控制结果**而非未分类失败：`cancelled_tool_result`（lib.rs:237-271）产出 `status=cancelled / error_kind=cancelled / retryable=false / next_action=stop_or_resume_parent_turn` 的稳定 JSON 信封（常量 `TOOL_ERROR_KIND_CANCELLED`，lib.rs:235）。
- **`SandboxConfig`**（lib.rs:327-341）：project_root、allowed_paths、`IsolationLevel`（重导出自 astra-sandbox，lib.rs:322）、max_output_bytes（200KB）、command_timeout（120s）、network_allowed。`standard()`（lib.rs:357，网络允许）与 `strict()`（lib.rs:377，网络禁止）两个预设。
- **`ToolContext`**（lib.rs:396-423）：所有工具模块的统一执行上下文——project_root / workspace_root / user_id / session_id / sandbox / http_client / logger（`ToolLogger` trait，lib.rs:463；服务端用 `TracingLogger`、CLI 用 `StderrLogger`，抽取出的工具代码**禁止 eprintln!**）/ cancel_token / detach_shell_handle（bash 可后台化的可续充槽位）。
- **审批与人机交互门**：`ToolApprovalGate` trait（lib.rs:553-583，`request_approval` 阻塞等待用户决定；`requires_approval_for` 默认 OR 上参数敏感的 `tool_requires_approval`）；`APPROVAL_REQUIRED_TOOLS`（lib.rs:659-667：bash、write_file、str_replace、multi_edit、delete_file、两个 rollback 工具）；`tool_requires_approval(name,args)`（lib.rs:670-699）对 git 按动作细分（commit/revert/push/stash(mutating)=需审批，status/diff/log 等只读=免审批），github 仅 create_issue 需审批。`AskUserGate`（lib.rs:602）与 `ProviderInteractionGate`（lib.rs:622）分别路由问卷与 provider 交互到前端。
- **`ToolProgressCallback`** trait（lib.rs:636-656）：tool_started / tool_output_delta / tool_completed / ask_user_resolved，用于向 WebSocket/SSE 流式转发工具进度。
- **输出预算**（lib.rs:703-751）：`global_output_limit` / `tool_output_limit` 读 astra-core 的 RuntimeLimits（可被 `ASTRA_GLOBAL_OUTPUT_LIMIT`/`ASTRA_TOOL_OUTPUT_LIMIT` 覆盖）；`per_tool_output_limit`（lib.rs:714，grep≤10KB、glob≤100KB、find_definition/find_references≤15KB）；聚合预算 `AGGREGATE_OUTPUT_BUDGET=200_000` 与软阈值 120_000（lib.rs:725-732）；`truncate_output`（lib.rs:736）先做凭据脱敏再在换行边界截断。
- Journal trait：`FileEditJournal`（lib.rs:511，record_before/after、undo_file/undo_turn，文件编辑撤销）与 `GitRollbackJournal`（lib.rs:523，commit/stash 回滚）。

##### DefaultToolExecutor — 共享执行器（executor.rs）

**结构**（executor.rs:111-126）：持有 ToolContext、可选审批门/进度回调/GitHubClient、**bash 只读去重缓存**（`Arc<Mutex<HashMap<BashCacheKey,BashCacheEntry>>>`）、**workspace_generation**（`Arc<AtomicU64>`，任何成功变更后自增以失效缓存）、`DesiredStateConvergenceTracker`（收敛追踪器）与 authority（UUID）、bash 缓存 TTL（默认 30s，executor.rs:168）、`filesystem_write_boundary`（Edge 请求级只读边界）。

构造：`new(ctx)`（executor.rs:208）；`for_workspace`（executor.rs:240，本地/Edge：构建 HTTP client、发现 host GitHub 凭据）；`for_server_workspace`（executor.rs:253，多租户：**不**读进程级凭据，凭据型工具必须后续由认证的 capability binding 注入）。

**`execute` 主流程**（executor.rs:359-762，实现 `ToolExecutor`）：
1. **参数校验**：`schemas::validate_tool_arguments`（executor.rs:360）失败即返回错误结果；
2. **审批门**（executor.rs:365-387）：Denied 时返回带"用户已拒绝、勿原样重试"指令的错误；
3. **进度通知 + 取消预检**（executor.rs:390-403）；
4. **host-owned 写边界校验**（executor.rs:405-410，`validate_host_owned_write_boundary` executor.rs:1218）；
5. **bash 只读缓存**（executor.rs:412-448）：仅当 `bash_cache_safety::bash_command_is_cache_safe` 判定为纯读命令（executor.rs:828-885 的 key = workspace_root + generation + command + env 指纹(PATH/HOME/LANG/TZ…) + stdin 哈希）且非 verify 模式、非 force；命中加 `cached=true` 标记（executor.rs:1145）直接返回；
6. **工作区互斥**（executor.rs:453-531）：类型化写工具与 bash 观测窗口共享同一 per-root 租约（`acquire_workspace_mutation_lease_with_options`，120s，可取消），防并发写被误归因；`run_script` 额外取 `begin_workspace_writer` 写者纪元，且**禁止 run_script 递归再起 run_script**（executor.rs:453-458）；
7. **分发**（`dispatch`，executor.rs:887-1063）：`tokio::select!` 取消 + 60s `TOOL_TIMEOUT` 超时包裹（executor.rs:99、536-559）——但 **bash 与 run_script 豁免**统一超时（它们自己管子进程超时/取消，避免 future 被 drop 后丢失部分写的事后回执）；
8. **协调完整性核验**（executor.rs:560-595）：租约/纪元 guard 若在执行中被破坏（integrity_valid=false），则剥离全部 mutation/observation 元数据、置错并在 workspace 上标 unsettled（`mark_workspace_observation_unsettled`）；
9. **收敛与回执投影**（executor.rs:596-670）：消费 `workspace_desired_state_converged` 标记、为已应用的类型化写附加 typed workspace 回执、经 `project_typed_workspace_convergence` 附加 convergence/observation 回执；
10. **脱敏 + 截断**（executor.rs:676-693）：所有原始输出过 `credential_redaction::redact_credentials_for_display`；超过 `MAX_TOOL_OUTPUT_BYTES=64KB`（executor.rs:103）截断；
11. **缓存写入与代际失效**（executor.rs:695-754）：成功的只读 bash 结果入缓存；类型化写工具（`is_workspace_mutation_tool`，executor.rs:1176-1216：write_file/str_replace/multi_edit/delete_file/rollback_*/rename_symbol/…、git 的 commit/revert/push/mutating-stash/worktree、lsp 非 dry_run）或带 changed 回执的 bash、或"可能已启动"的 run_script（`run_script_may_have_mutated`，executor.rs:1157，除非 `execution_started=false`）→ `workspace_generation.fetch_add(1)` 保守失效读缓存；
12. **完成回调**（executor.rs:756-759）。

**dispatch 路由表**（executor.rs:887-1063）：文件操作→`fs_ops`（read_file:893 / write_file 含 delete 分支与 formatter 边界变体:894-906 / str_replace:907 / delete_file:914 / list_dir:915 / multi_edit:918）；shell→`shell_ops`（bash 带/不带文件系统边界:927-933、grep:934、glob:935）；git→`git_gix::git_dispatch`:939；github→`github_tool_contract` 解析后 `dispatch_github_action`:942/1066（无 token/无 HTTP 时返回带修复指引的结构化错误）；symbols→tree-sitter 大纲:948/1110；web_search:951（cache_scope=user:session）；tool_search:957；env:961；config:962；sleep:968（上限 300s）；web_fetch:984；display_sixel:991；memory:1001（session_audit 走本地 journal 清单，其余动作在未配置 memoria endpoint 时返回带配置指引的错误）；run_script:1036（仅 Unix，UDS RPC 桥）；未知工具报错:1059。`tool_schemas`（executor.rs:786）在宿主无 process scope（cgroup/supervisor 不可用）时移除 run_script。

**ToolEngine（第二套分发内核）**（tool_engine.rs）：面向"宿主本地 handler"的泛型注册表。`ToolHandler<C>`（tool_engine.rs:53）按名执行；`DynamicToolHandler<C>`（tool_engine.rs:73）按前缀匹配动态名（如 `mcp__server__tool`，可带名字校验器，tool_engine.rs:177）。`ToolEngine::execute_invocation`（tool_engine.rs:246-295）用 `AssertUnwindSafe(...).catch_unwind()` 把 panic 转成 `ToolResult::error("Internal error: tool panicked")`——**panic 不穿透 async 运行时**。注册时若 `schema_exists_for_tool` 为 false 会告警 schema↔handler 失配（tool_engine.rs:152-159）。`ToolInvocationMetadata`（tool_engine.rs:42）把 run_id/turn_chain_id/tool_call_id/admission_source/expected_control_epoch 作为**可信调用身份**与模型参数分离传递（防止内部身份污染 provider schema）。

**其余模块速览**（详见 CH5 清单）：`schemas.rs` 提供 all_tool_schemas 与带 `x-astra-per-action-*` 扩展键的动作级参数校验（schemas.rs:12-17、396、838）；`fs_ops.rs` 含沙箱化路径解析 `resolve_path_sandboxed`（fs_ops.rs:303）与写前准备结构（PreparedWriteFile 等）；`shell_ops.rs` 的 `execute_bash`（shell_ops.rs:860）执行命令分类（shell_ops.rs:228）、超时推断（shell_ops.rs:441）、scope 隔离结算（shell_ops.rs:1136/1682）；`git_gix.rs` 用 gix 库实现 git 全套只读+写动作（status:863/log:947/show:1022/blame:1321/diff:1540…）；`workspace_observation.rs`（267KB）实现租约/写者纪元/回执/收敛追踪的整套"工作区观测协议"；`credential_redaction.rs`（71KB）凭据模式与 PEM 块脱敏；`run_script.rs`+`rpc_bridge.rs` 实现 Python 程序化工具调用（生成 Python stub、UDS JSON-RPC、RPC_ALLOWED_TOOLS 白名单 run_script.rs:76、UNSAFE_IN_STRICT=["bash"] run_script.rs:98）；`exit_semantics.rs` 退出码语义分类；`build_test.rs` 构建输出解析与自动修复建议；`code_intel.rs` tree-sitter 符号/调用/成员提取（7 语言）；`memoria.rs` 内存服务网关（熔断器 MemoryCircuitBreaker memoria.rs:389、快照/回滚 memoria.rs:2482/2491）；`web_fetch.rs` SSRF 防护（is_private_host web_fetch.rs:436）与缓存；`ask_user.rs` 问卷模型与答案规范化；`patch_materialization.rs` git patch 物化/审查提交/对账；`source_preimage.rs` 命令前置源快照（content-addressed blob）；`fuzzy_replacer.rs` 8 种模糊替换锚定策略；`detach.rs` bash 后台化（SIGKILL 进程组、领养握手）；`tool_search.rs` 工具发现；`bash_cache_safety.rs` 缓存安全分类学；`env_tools.rs` 会话环境覆盖层；`passive_cargo_check.rs`/`passive_tsc_check.rs` 被动诊断；`display_sixel.rs` 终端图像；`internal_artifacts.rs` 内部工件引用拦截；`config_tool.rs`/`char_boundary.rs`/`relevance_score.rs` 小工具。

#### 4.3.2 astra-skills — 技能发现与执行（31 文件）

**crate 定位**（lib.rs:1-27）：技能框架类型与 provider。技能 = 带 manifest（YAML frontmatter）的指令文档（SKILL.md），可 inline 注入会话或 fork 成隔离子代理循环。`UnifiedSkillRegistry` 聚合多 provider（架构图 lib.rs:18-27）。`has_inline_shell`（lib.rs:65-77）检测指令中以 `!` 开头的行内 shell。

**核心 trait**（traits.rs）：
- `SkillProvider`（traits.rs:16-28）：`source_kind()` / `discover()`（仅元数据）/ `load(name)`（全文）/ `refresh()`；
- `SkillExecutor`（traits.rs:67-77）：`execute(&LoadedSkill, &SkillExecutionContext) -> SkillExecutionResult` + `supports(&ExecutionContext)`；`SkillExecutionResult`（traits.rs:48-63）含 output/tokens_used/turns/duration_ms/success/verification_results/error_category；
- `SkillResolver`（traits.rs:134-154）：`resolve(name) -> ResolvedSkill`（traits.rs:109-130，含 instructions/allowed_tools/hooks/success_criteria/composition/trust_tier 等 18 字段）、`resolve_for_execution`（远程目录懒加载覆写点）、`available_skills()`（供 schema 生成）、`execution_topology()`（只信 manifest 元数据、不解析指令散文取执行权威）；
- 生态 trait：`SkillInstaller`（traits.rs:171，install/upgrade/rollback/uninstall/check_upgrade）与 `SkillMarketplace`（traits.rs:224，search/publish/download/get_info）；
- `SkillError`（traits.rs:246-265）九类错误（NotFound/LoadFailed/ParseFailed/VersionConflict/DependencyError/ExecutionFailed/PermissionDenied/BudgetExceeded/Internal）。

**manifest.rs**：`SkillManifest`（manifest.rs:163）——name/description/version/allowed_tools/when_to_use/arguments/execution_context/max_tokens/hooks/composition/dependencies/trust_tier/publisher 等。`ExecutionContext::{Inline,Fork}`（manifest.rs:134）；`EffortLevel`（manifest.rs:295）；`SkillComposition`+`PipelineStep`（manifest.rs:346/369）；`TrustTier`（manifest.rs:392，被 astra-sandbox 重导出使用）；`SkillErrorKind`（manifest.rs:450，含 Interrupted/Cancelled）；`validate_skill_manifest_core`（manifest.rs:668）核心校验。

**发现与加载流程**（loader.rs）：`parse_skill_md`（loader.rs:110）拆 YAML frontmatter+正文；`load_skill_from_path`（loader.rs:274）→ 内部先 `reject_path_traversal`（loader.rs:310）→ `validate_skill_name`（loader.rs:327）→ 加载资源（`load_skill_resources` loader.rs:394，带尺寸上限）；`load_skill_from_path_confined`（loader.rs:283）额外 `verify_confinement`（loader.rs:375）把技能目录限制在 root 内。搜索路径 `skill_search_paths`（loader.rs:511）覆盖 `.astra/skills/`、`~/.astra/skills/`、walk-up（loader.rs:653）与隔离项目模式（loader.rs:585）。`discover_skills_in_dir`（loader.rs:456）枚举目录内技能。

**Provider 矩阵**（providers/）：`LocalSkillProvider`（local.rs:14，文件系统）；`BundledSkillProvider`（bundled.rs:24，编译内置，含 dynamic_skills）；`McpSkillProvider`（mcp.rs:37，MCP `skill://` 资源，**inline shell 被禁**）；`DatabaseSkillProvider`（database.rs:18，SQLx 数据库，依赖 astra-services）。`providers/dynamic_skills/`：7 个 Rust 函数生成的内置技能（debug/reflect/remember/review/skillify/stuck/verify），`all_dynamic_skills()`（mod.rs:20-30）返回 frontmatter+body 字符串，常量编译期内置避免漂移；`skillify.rs` 是"把本次会话流程固化为新 SKILL.md"的元技能。

**执行流程**（executor/）：
- `InlineSkillExecutor`（inline.rs:16-79）：把技能指令经 `substitute_arguments`（arguments.rs:54，支持 $ARGUMENTS/${NAME}/${SKILL_DIR}）参数化后格式化为 `# Skill: <name>` 工具结果注入**同一会话**（inline.rs:43-61 附 Task context 与 Allowed tools）；MCP 来源且含行内 shell 直接 `PermissionDenied`（inline.rs:25-29）；tokens_used=len/4 估算。
- `IsolatedSkillExecutor`（isolated.rs:115-289）：fork 模式。把执行委托给 `SkillSubRunExecutor` trait（isolated.rs:37-54，CLI 与 Server 各有实现），携带 skill 名/指令/任务上下文/max_tokens/allowed_tools/递归深度/effort/agent_type/invocation_id/expected_control_epoch/parent_turn_chain_id。子运行返回 `SubRunResult{output,tokens_used,turns,outcome}`，其中 **`SubRunOutcome`（isolated.rs:62-98：Completed/Interrupted/Cancelled/Failed）是权威终态**，与文本输出分离（部分输出不等于成功）。可选 `SkillCheckpointManager`（crash-recovery feature，isolated.rs:131-140）在执行前后落检查点（SkillCheckpoint，见 astra-pipeline）。产出 `## Skill Result:` 格式的结果与 error_category 映射（isolated.rs:256-283）。
- `SkillExecutionRouter`（isolated.rs:292-338）：按 `manifest.is_isolated()` 路由——fork 且有 isolated 执行器则隔离执行，否则**告警并回退 inline**（isolated.rs:322-327）。

**外围机制**：`auto_invoke.rs`——`AutoInvokeGate`（auto_invoke.rs:101）基于会话信号（停滞计数≥STALL_TRIGGER_COUNT=5、上下文压力≥0.85，auto_invoke.rs:91-93）自动触发诊断技能，产出 `SkillDiagnosis`（auto_invoke.rs:254，schema_version=2，带 headline/findings/criteria 上限）；`activation.rs`——`ConditionalSkillTracker`（activation.rs:69）按 glob 路径匹配（activation.rs:12）跟踪条件激活；`composition.rs`——组合校验（深度≤3，composition.rs:12）与 input/output schema 校验（composition.rs:189/239）；`hooks.rs`（115KB）——`SkillHooks`/`ToolEventHook`（hooks.rs:44/153）与 pre/post 工具钩子评估（`evaluate_pre_tool_hooks` hooks.rs:731、`evaluate_post_tool_hooks` hooks.rs:885），shell 钩子有风险审查（hooks.rs:184-300）与 stdout 256KB 上限（hooks.rs:690）；`health_ranking.rs`——按工具健康度调整技能排序乘数（0.2~1.5，health_ranking.rs:46-50）；`improvement.rs`——每 5 turn（TURN_BATCH_SIZE，improvement.rs:14）分析并改写技能内容；`pack.rs`——tar.gz 打包/解包（pack_skill pack.rs:50）；`quality.rs`——成功率追踪；`verify.rs`——`SkillVerifier` 按 success_criteria 校验；`version.rs`——语义化版本与约束解析（Version version.rs:13、VersionConstraint version.rs:177）。

#### 4.3.3 astra-pipeline — 执行观测/检查点/崩溃恢复管线（11 文件）

**crate 定位**（Cargo.toml description: "agent learning pipeline — calibration, routing, patterns"；lib.rs:1）：**不是**上下文装配（见本节开头澄清），而是把一轮 agent 执行记录为可恢复、可查询、可学习的 Step 事件与检查点。上下文装配管线（Plan→Bind→Optimize→Serialize→Explain，astra-turn-core/src/context/pipeline.rs:1-4、`ContextPipeline::run` pipeline.rs:92）位于 turn-core，消费本 crate 之外的产物。

**Step Protocol v2**（step_protocol.rs:1-36 模块头）：三类关注点分层——`StepDescriptor`（step_protocol.rs:209，调度层：step_id/task_id/dag_node_id/action/`SchedulingContract`，创建后不可变；契约含 priority/timeout_ms/per_tool_timeout/max_retries/指数退避 backoff_ms:187/有效工具超时下限 30s:195-204）；`StepExecution`（step_protocol.rs:224，运行层：cursor/execution_slots/result/`MemoryContext`）；`StepCheckpoint`（持久层，两级：Light≈1KB 每 tool 完成后写、Heavy≈10-100KB 每 turn 判定后写）。协议版本 `major*1000+minor`（PROTOCOL_VERSION=2000，step_protocol.rs:45-47），`VersionPolicy::{Strict,Compatible}`（step_protocol.rs:51）+ 协商链（check_protocol_version_with_policy step_protocol.rs:69）。`MemoryContext`（step_protocol.rs:239）携带 PERCEIVE 阶段检索的记忆 ID/域提示/provenance/治理动作/集群洞察/快照 ID——这是"感知→行动→评估"记忆流的类型载体。另有 slot 状态机游标、幂等键（含 workspace_version+memory_snapshot_id 的语义幂等）、`WaitTrigger`（User/Webhook/Timer+continuation_token）、`IdempotencyCache`/`StepEventStore` trait（内存或 MatrixOne 后端）。

**记录与持久化**：`StepRecorder`（step_recorder.rs:295）包住 chat_stream 执行环，把隐式阶段映射为显式 StepAction 事件（模块头用法示例 step_recorder.rs:9-29：begin_turn→record_plan→begin_tool/complete_tool→record_verdict→finalize）；落盘前对工具输出做**存储级脱敏**（redact_credentials_for_storage step_recorder.rs:41-90，覆盖 JWT/AKIA/ghp_/xox 等前缀与 PEM 块）。`step_checkpoint.rs` 把检查点写到 `~/.astra/sessions/v1/users/b64-<uid>/sessions/<sid>/step_checkpoints/<n>-<tier>.json` 与事件 JSONL（step_checkpoint.rs:4-7）；Light 保留上限 50（:58）；恢复读取有 8MB/4096 事件窗口上限（:54-55）；写耐久度分 Buffered（热路径不 fsync）与 Durable（turn 级强制 fsync）（:61-71）。

**崩溃恢复**：`crash_recovery.rs` 的 `recover_from_crash(user_id,session_id)`（crash_recovery.rs:60）是主入口——状态机 Idle→Scanning→Replaying→Recovered/Failed（:15-19）：检测无 SessionEnd 的会话→读最新 Heavy 检查点→只流式加载检查点之后的恢复窗口事件（:86-90）→把每个工具调用分类为 Replay/Skip/RequireUser（按 `classify_tool_idempotency`，:32）→重放确定性步骤。覆盖的失败面：无检查点/JSON 损坏/版本失配/journal 空洞/崩溃时在飞的工具调用/部分执行的副作用工具/恢复哈希失配/二次崩溃（:22-31）。`step_restore.rs` 的 `RestoredSession`/`CacheRestoreReport`（step_restore.rs:33-51）明确区分"审计投影"与"重放权威"——未验证条目**不**进入执行缓存。`skill_checkpoint.rs`：子代理技能级检查点（SkillCheckpoint skill_checkpoint.rs:30；Running/Completed/Failed 状态 skill_checkpoint.rs:56）。

**查询与共享类型**：`trace_query.rs` 统一三层事件（内存 EventLog / JSONL StepRecorder / SQL TraceEvent）以 canonical UUID v7 关联（trace_query.rs:1-9），`StepLatencyBreakdown`（:43）做逐步延迟归因（pre_tool_wait vs tool_execution）；`event.rs` 是精简事件日志（`EventKind` event.rs:52-121：PhaseTransition/BudgetSet/LlmChunk/LlmRequest/ToolCallStarted|Completed|Output/MemoryQuery|Retrieved/SkillStarted|Completed/PromptAssembled；输出预览 500 字符上限 event.rs:14）；`output_stream.rs` 字节偏移的追加式输出流（长任务不驻留内存）；`tool_health_types.rs` 跨会话工具健康度（每签名保留 8 次结果的环形，TOOL_OUTCOME_RING_CAPACITY tool_health_types.rs:6；失败率而非连续计数，:42-44）。

#### 4.3.4 astra-plan — 计划模式（6 文件）

**crate 定位**（lib.rs:1）：Plan Mode 的共享状态、执行辅助与持久化边界（"breaks complex goals into subtasks"）。

- `model.rs`：`TaskStatus`（model.rs:9，pending/in_progress/paused/completed/failed/cancelled，is_terminal:43）；`SubtaskPlan`（model.rs:50，id/title/depends_on/status/effort/files/**acceptance_checks: Vec<VerifierKind>**——验收检查直接类型化为验证器）；`TaskPlan`（model.rs:72）+`ready_subtasks()`（:78，依赖全 Completed 才 ready）+`progress_pct()`（:92）。
- `state.rs`：`PlanPhase`（state.rs:11，planning→refining→executing→completed，由进度推断 infer_phase:64）；`PlanModeState`（state.rs:83：goal/plan/plan_md/modified/timeline/**version 乐观并发控制**:97-100/created_by）；`generate_plan_id`（state.rs:132，goal 前三词 slug+时间哈希）；`ExecutionTimeline`（state.rs:216）记录 SubtaskRewound/SubtaskRedone（state.rs:173-188）。
- `execution.rs`：`format_subtask_prompt_with_operator_notes`（execution.rs:9）构造子任务执行提示（内嵌"必须用工具落盘而非贴 markdown 代码块"等反幻觉守则 :57-75，以及 operator 暂停/纠偏备注块 :80-86）；`analyze_parallelism`（execution.rs:108）按就绪+文件冲突（FileConflict :101）求可并行分组（ParallelGroups :91）。
- `repository.rs`：`PlanRepository` trait（repository.rs:144，save/load/list/bind active_plan/step-run 生命周期 NewStepRun:89/RecordCompletedStepRun:101/FinalizeStepRun:113）；`CloudPlanRepository`（:346，SQLx/MatrixOne 实现，含 plan_id 校验:420 与 owner 校验:435）；`InMemoryPlanRepository`（:1335，测试用）。
- `resume.rs`：`plan_resume_prompt_hint`（resume.rs:53）生成"[plan-resume] goal=… draft=…"的恢复提示（目标 160/草稿 320 字符截断 :5-6）；**`plan_mode_authoring_active` 恒返回 true**（resume.rs:67-69）——注释明言：审批是显式控制面转换，从任务进度推断审批会造成第二权威并静默释放写守卫（fail-closed 设计）；`plan_resume_snapshot_for_session`（resume.rs:78）在 DB 故障时降级为无提示但保留写守卫（:103-111）。

#### 4.3.5 astra-prompts — 提示词模板（7 文件）

**crate 定位**（lib.rs:1）：LLM 提示模板与指令构造器，仅依赖 astra-core+serde（最轻的能力层 crate）。

- `extraction.rs`：`COMPACT_UNIFIED_PROMPT`（extraction.rs:7）——会话压缩的统一抽取提示；`CompactResponse`/`CompactSummary`/`CompactFact`（:44-70）与 `parse_compact_response`（:146）解析模型输出（评分择优 :234）。
- `memory_proto.rs`（50KB）：记忆协议常量库——版本 "v1.1"（:132）、层分隔符（overview/detail :139-149）、摘要长度带 30-150 字符（:155-164）、九个记忆命名空间 NS_TASK/NS_PLAN/NS_FACT/NS_EPISODE/NS_PREF/NS_SWAP/NS_INSIGHT/NS_KNOWLEDGE/NS_LESSON/NS_FEEDBACK（:167-177）、生命周期状态 pending/active/done/archived/summary/superseded/disputed/expired（:193-204）、`is_prompt_recallable_status`（:209，prompt 只召回可召回态）。
- `memory_ns.rs`：六命名空间与 memoria type 的映射（memory_ns.rs:7-33）。
- `memory_types.rs`：`MemoryCategory`（memory_types.rs:12）+ encode/decode 前缀编码（:112/:118）+ `build_memory_prompt`（:147，按 MemoryPromptMode 生成记忆读写提示）。
- `skills.rs`：系统技能指令——`SystemSkill`（skills.rs:29）、内置 markdown/concise 两技能（:37/:58）、`build_skill_instructions`（:80）。
- `team_prompts.rs`：多代理编排提示——fan_out_agent_prompt（team_prompts.rs:10）、sequential_stage_prompt（:71）、adversarial_producer/reviewer_prompt（:116/:160）、fork_child_prompt（:183）、budget_awareness_prompt（:207）、wrap_task_with_coordination（:241）。

#### 4.3.6 astra-sandbox — 托管执行边界（8 文件）

**crate 定位**（lib.rs:1-9）：agent 工具执行的安全边界，三层：路径校验（canonicalize+项目边界）、命令沙箱（env 过滤、资源上限、受限 bash）、策略引擎（per-session 规则）。

**策略层**（policy.rs）：`IsolationLevel`（policy.rs:36-43，有序 Permissive<Standard<Strict）；`SandboxPolicy`（policy.rs:55-79，isolation/project_root/allowed_paths/env_allowlist/max_execution_secs/max_output_bytes/network_allowed；注释 :46-53 说明 ulimit 被移除，资源控制改靠并发上限+超时）；`ENV_BASELINE`（:82-118，PATH/HOME/git/构建工具/MatrixOne 变量白名单）；**绝对禁止**的 env 键模式（SECRET/TOKEN/PASSWORD/API_KEY/…，:123-134，Permissive 也不放行）；敏感路径子串黑名单（/etc/shadow、.ssh/id_、.aws/credentials、.env、.gnupg/…，:141-160 起）。`is_sensitive_path`/`is_never_readable_path` 由 lib.rs:32-34 导出。

**路径层**（path.rs）：`validate_path`（path.rs:82）canonicalize 并对照 policy 边界；`normalize_path`（:150）词法归一（防符号链接绕过先用 canonicalize-parent 兜底 :183）；`SandboxPathError`（:8）分类（Escape/Sensitive/NotFound/…）。

**命令层**（command.rs + bash_ast.rs + shell_hardening.rs + git_safety.rs）：`sandbox_command`（command.rs:41）按隔离级别包装命令；`filter_environment`（:79）应用 env 白/黑名单；`analyze_command_risks_in_workspace`（:220）产出 `CommandRisk` 枚举（:1168，如写越界、凭据访问、网络外传）；`is_rm_catastrophic_rm_path`（:116）识别灾难性 rm 目标。`bash_ast.rs` 用 tree-sitter-bash 做真 AST 解析（parse_bash :6、parse_plain_bash_commands :20、analyze_bash_risks_ast :481，能穿透 env/nohup/timeout 等"透明启动器"与 xargs/find -exec 嵌套命令 :709-1500）。`shell_hardening.rs`：`build_hardened_command`（:95）注入 stdin 重定向等加固；`scrub_secrets_from_env`（:270）；DANGEROUS_FILE_PATHS/SENSITIVE_ENV_VARS 常量（:15/:40）；`is_internal_safe_path`（:497）识别 Astra 内部会话工件路径防止自我污染。`git_safety.rs`：`validate_git_command`（git_safety.rs:143）检查 force-push/hook-skip/--exec 注入/amend/强删分支等违规（`GitSafetyViolation` :9，软/硬分级 is_soft_violation :128）；`is_bare_git_repo`（:172）。

**进程隔离层**（process_isolation.rs）——本 crate 的核心：
- `IsolationConfig`（process_isolation.rs:66-86）：pid/mount/net namespace 开关 + cgroup 内存/CPU 配额 + 超时 + 输出上限 + read_only_paths。四预设：`strict`（:90，全 namespace+512MB+1CPU）、`sandboxed`（:105，仅 cgroup 1GB+2CPU）、`disabled`（:120，仍保留资源上限的向后兼容）、`filesystem_boundary`（:140，mount namespace 写边界：宿主视图只读、工作区读写、指定 lane 再只读）。
- `IsolatedOutput`（:157-187）：执行结果带**执行事实**字段——timed_out/cancelled/execution_started/stdout_capped/namespace_active/cgroup_active/scope_settled/scope_ownership/descendants_terminated。
- **进程归属三级**（`ScopeOwnership` :192-203）：`InvocationCgroup`（委托 cgroup，权威）> `InvocationSupervisor`（子 subreaper，权威，可管住 setsid/双 fork 逃逸的子孙）> `ForegroundProcessGroup`（弱回退，管不住 setsid）。`ScopeSettlement`（:211）与 `BashInvocationOwner`（:223，Edge 与共享执行器共用的选择器：prepare→install→started→request_supervised_termination→settle_after_exit_detailed :232-366）。
- **InvocationSupervisor（调用监督器）**（:383-677）：解决"bash 子进程 daemon 化后脱离控制、且多会话并发时无法归因"的问题。机制：监督器是**当前 Astra 二进制的一次全新 exec**（self re-exec，prepare :419-446 要求 main 早已注册入口点，否则 Unsupported 错误 :425-430）；父进程创建两根 CLOEXEC 管道（control/receipt :459-461），`install`（:484-524）通过私有 env（_ASTRA_INTERNAL_PROCESS_* :43-53）传目标程序/参数 JSON/fd 号/nonce，pre_exec 只翻转两个协议 fd 的 CLOEXEC（:508-513，async-signal-safe 仅 fcntl）；`start`（:536-571）等待 `ASTRA_PROCESS_SUPERVISOR <ver> READY <nonce> <pid>` 行，验证 nonce 后回写单字节 `S` 才允许目标启动；`request_termination`（:576）写 `C` 请监督器清场（**唯一安全的超时/取消路径**——先杀 helper 会把 daemon 子孙放生给容器 init）；`finish_detailed`（:599-630）验证唯一终局回执 `SETTLED_ECHILD <nonce> <pid> <terminated?>` 且之后必须立即 EOF，多余消息按协议违规 fail-closed。
- **监督器子进程侧**（`run_invocation_supervisor` :710-837）：读私有 env → 解析 fd（校验两 fd 不同 :720）→ `prctl(PR_SET_DUMPABLE,0)`（:741，防同 uid 目标经 /proc 窥探 receipt fd）→ `prctl(PR_SET_CHILD_SUBREAPER,1)`（:744，成为子收割者）→ 发 READY → 等单字节 `S` 授权 → **从目标 env 中剥除全部 6 个私有协议键**（:767-769）→ 目标放入独立前台进程组（process_group(0) :772）→ 轮询 try_wait+control（:778-804），收到终止指令则 `kill(-pid,SIGKILL)` 组杀（:806-811）→ `settle_subreaper_children`（:908，waitpid 收割全部被收养子孙，2s 超时 :57）→ 写 SETTLED_ECHILD → 退出码 130（终止）/目标码 clamp 0-255（:828-836）。
- **入口分发**：`invocation_supervisor_is_requested`（:683-692，检查 `_ASTRA_INTERNAL_PROCESS_SUPERVISOR` env 是否匹配协议版本）；`run_invocation_supervisor_if_requested`（:694-707）——**被 `crates/runtime/src/main.rs:8` 在 main 的第一行调用**（先于日志/异步运行时/配置/网络/数据库，注释见 main.rs:5-7）：非监督器模式则置 `SUPERVISOR_ENTRYPOINT_READY=true`（供 prepare 校验）返回 None 正常启动；监督器模式则整体替代进程行为并 `std::process::exit(code)`。
- 其余：`CgroupGuard`（:1472，cgroup 创建/挂子进程/Drop 清理）与便捷函数 `apply_cgroup`（:1690）、`apply_process_scope`（:1733）、`process_scope_available`（:1770，DefaultToolExecutor 据此裁剪 run_script schema）、`execute_isolated`/`execute_isolated_with_cancel`（:1968/:2104，unshare 包装的隔离执行 + 流泵采集 + 退出后 owner 结算 settle_isolated_owner_after_exit :1976）。

### 4.4 协议与集成层（astra-server-types / astra-sync-protocol / astra-messaging / astra-memoria / astra-thin-client / astra-mcp / astra-harness）

本层 7 个 crate 构成 Astra"服务器协调 + 边缘执行"架构的契约与集成平面：`astra-server-types` 定义 Server 全部对外 API 类型与 Edge 连接池；`astra-sync-protocol` 是边缘→云端同步的 HMAC 签名线协议；`astra-messaging` 是 agent 间消息传递框架（进程内/DB 双传输）；`astra-memoria` 是语义记忆的规范端口（并非 HTTP 客户端本体，HTTP 实现在其他 crate）；`astra-thin-client` 是 CLI/Edge/Web 共用的无状态 HTTP+SSE 客户端；`astra-mcp` 封装 MCP 客户端（stdio/SSE/StreamableHTTP/WS 四种传输）；`astra-harness` 是运行时"仪表/守护"系统——钩子、验证器、轨迹与能力矩阵。以下行号均相对各文件。

#### 4.4.1 astra-server-types —— 服务器 API 类型 + Edge 连接池

**模块职责**：Server 的请求/响应 wire 契约、浏览器 WebSocket 消息、Edge(远程执行器) WS 协议与连接池、多 agent 团队编排的类型/_trait_、git worktree 隔离与 LLM 冲突解决。默认 feature `server` 打开大部分模块；关闭后仅保留 `completions`/`edge_ws_protocol`/`session_run_tree` 与部分 Work 类型（thin-client 以 `default-features=false` 依赖之，避免拉入 axum/tokio）。这是一个刻意的"轻契约 + 重服务端扩展"双层设计。

**lib.rs（1981 行）**
- 版本协商头：`WORK_API_MAJOR_HEADER="x-astra-work-api-major"`（值 "1"，lib.rs:52-53）、`AGENT_INTERACTION_API_MAJOR_HEADER`（值 "3"，"版本 3 携带 server 主导的 Edge 命令超时上限"，lib.rs:58-59）。不匹配视为部署不匹配而非可恢复错误。
- Work 任务板投影：`WorkTaskBoardUpdateV1`（schema v1）+ `WorkTaskBoardChangeV1::{Snapshot,Upsert}`（lib.rs:89-116）。文档注释明确"事件投影而非第二任务权威：仅在对应 Work 变更持久化后发出"。文本上限 `WORK_TASK_BOARD_TEXT_MAX_BYTES=512`（lib.rs:77）。
- Work 读写契约：`WorkCreateRequestV1{request_id, goal, criteria}`（调用方生成请求 ID 实现精确重试幂等，"换 goal 复用 request_id 会 fail closed"，lib.rs:492-502）、`WorkTurnRequestV1`、`WorkBranchControlCommandV1::{AcquireBranchControl, ForceTakeover(带 reauthentication_proof), ReleaseBranchControl}`（lib.rs:412-435）。全部 `deny_unknown_fields`。
- `ChatRequest`（lib.rs:710-786）：约 40 个字段，涵盖模型选择、agent 绑定、运行时 MCP 绑定、执行预算/时限/策略、`interactive_client`（能否处理 ask_user/审批回调）、`conversation_authority`（"省略于初次准入；无签名与属主校验绝不信任"）。`chat_request_into_data`（lib.rs:1893-1956）转换为服务层 `ChatRequestData`，其中 `edge_executor_id` 回退到 `capability_descriptors.edge_agent.id`（lib.rs:1902-1908）。
- 浏览器 WS 消息：`WsClientMessage`（Auth 必须为第一帧且携带 interaction_api_major，凭据"绝不进 URL"lib.rs:1534-1536；ChatMessage/CancelRun/ToolApproval/Ping）与 `WsServerMessage`（auth_ok/run_started/run_finished/tool_approval_request/user_prompt_request/tool_output_delta/error{retryable}/closing 等，lib.rs:1358-1532）。
- SSE 错误语义（lib.rs:1629-1651）：`sse_error_code_for_status`（401/403→AUTH_ERROR、404→NOT_FOUND、422→VALIDATION_ERROR、其余 INTERNAL_ERROR）；`sse_retryable_for_status`（≥500 或 429）；`build_sse_error_event_payload` 组装 `{"type":"error","code","retryable","message"}`。这是全系统流式错误分类的单一来源。
- 分页游标辅助：`SessionListQuery::cursor`/`RunListQuery::cursor`/`SessionArtifactListQuery::cursor` 要求成对字段并校验时间戳格式（lib.rs:826-839、1115-1136、900-939）。

**completions.rs（320 行）——辅助推理代理契约**
- `CompletionOperation`（5 种：memory_extraction / memory_retrieval_rerank / turn_intent / skill_auto_route / verification_judge，completions.rs:15-21），每个变体固定 `InferencePurpose` 与持久 `operation_id`（"completion_proxy:*"，:38-46）——客户端只能给会话坐标，不能冒充 run 或指定 provider URL/密钥。
- `CompletionRequest`：默认 `max_tokens=512`、`temperature=0.1`、`timeout_ms=120_000`；`validate()` 强制 `1..=MAX_COMPLETION_OUTPUT_TOKENS(8192)`（:144-151）。`from_session_scope` 只接受 `Session` 作用域，其它返回错误（:103-127）——把内部类型化作用域转换为公网线格式而不泄露作用域本身。

**edge_ws_protocol.rs（542 行）——Server↔Edge 双向 JSON 帧协议**
- 常量：`EDGE_TOOL_TIMEOUT_SECS=300`、`MAX_EDGE_TOOL_TIMEOUT_SECS=1800`（30 分钟"公共监护窗口"）、`EDGE_TOOL_RESULT_GRACE_SECS=10`（传输结算时间，非执行时间）、`EDGE_AUTH_TIMEOUT_SECS=30`、`EDGE_HEARTBEAT_INTERVAL_SECS=30`（:73-92）。
- `EdgeClientMessage::{Auth, ToolResult{identity, delivery_generation, …}, Ping}`、`EdgeServerMessage::{AuthOk/AuthError, ToolRequest, Pong, Closing, ToolCancel{delivery_generation}, ToolResultAck}`（:95-196）。HTTP 层先完成鉴权，应用帧内"绝不重复密钥"；`deny_unknown_fields` 拒绝已退役字段（如内联 token，测试 :263-289）。
- 进程授权能力：`supports_runtime_process_authorization` 读取 capabilities 的 `protocol_capabilities.runtime_process_authorization_v1==true`（:38-44）；`runtime_process_authorization_applies_to_tool` 目前仅 `bash`（:50-52）。`RuntimeProcessAuthorizationContext` 手写 `Debug` 只打印 `authorization_present`，防日志泄密（:64-70）。
- `ToolResultAck` 语义：Edge 必须保留并重放已完成结果直到服务端确认（:189-195）。

**edge_connection_pool.rs（1053 行）——内存连接池（Server AppState 持有）**
- 结构：`DashMap<String /*"{user_id}:{edge_agent_id}"*/, EdgeConnection>`；每个连接含单调递增 `generation`、容量 256 的 mpsc sender（`EDGE_WS_CHANNEL_CAPACITY`）、`pending_results: DashMap<request_id, {delivery_generation, oneshot}>`（:80-104、169-199）。
- 事务化重连：`begin_reconnect` 设置 intent 并在连接分片锁内捕获 pending map（保证与 cleanup 原子），DB 注册期间旧连接保持可用；`commit_reconnect` 继承 pending map；`abort_reconnect`/`ReconnectReservation::drop`（含 panic 路径）失败所有等待者（:107-151、359-446）。`reconnect_locks` per-key tokio Mutex 串行化并发重连，`gc_reconnect_lock` 用 `Arc::strong_count<=2` 安全回收（:226-250）。
- `unregister_generation` 只移除注册者自己的 incarnation，且重连期间不清 pending map（:450-473）——防止旧 socket 清理误杀新 socket 的在途结果。
- 工作区隔离 fail-closed：`find_edge_by_agent_id`/`get_user_edges` 要求 (请求 ws, edge ws) 严格匹配——请求无 workspace 只能命中无 workspace 的 edge（:495-528、557-587），防止"provider 授权 turn 无 workspace 上下文时静默解析到共享沙箱 edge"。
- 执行路径 `execute_durably_admitted_invocation_on_connection_with_cancel`（:631-784）：超时 clamp 到 `[1,1800]`；登记 pending、发送 `ToolRequest`；等待 `timeout+10s` grace；`tokio::select!` 响应 CancellationToken——取消/超时都向 Edge 发 `ToolCancel`（"防止放弃后 bash 仍写文件"，:737-782）。
- 去重账本：`pending_requests`（全局 1000 / 每用户 100，TTL 3×(1800+10)s），三结构（map/按用户索引/全局 FIFO）在 `pending_request_order` Mutex 临界区内一致插入（:854-899）；`insert_pending_request` 注释明确把 per-user 逐出放在 order 锁外避免重入死锁（:856-862）。`ack_completed_for_user` 由心跳的 `last_seen_request_ids` 驱动（:1021-1032）；`drain()` 广播 `Closing` 并按 generation 注销（:962-999）。
- `deliver_tool_result` 校验 `delivery_generation` 匹配后才唤醒 oneshot，否则丢弃并 warn（供运维关联"迟到结果与冲突写"）（:787-827）。

**session_run_tree.rs（231 行）**：`SESSION_RUN_TREE_SCHEMA_VERSION=5`；`SessionRunLifecycleStatus` 8 态（Delegated/Interrupted 为独立终态，:12-31）；`SessionRunNode::is_agent_run` 以 `agent_id` 非空为准，"不从 parentage/depth/显示名/runtime profile 标签推断"（:101-110）；`snapshot_revision` 哈希在仅 `observed_at` 变化时保持稳定，客户端可跳过重渲染（:112-123）。

**team_orchestrator_traits.rs / team_orchestrator_types.rs（143+430 行）**：三个解耦 trait——`DelegationExecutor`（执行多 agent 委派并回报进度）、`DelegationTracking`（子 run 层级/暂停/恢复）、`RunPersistence`（其中 `persist_status_if_current` 是 CAS 写："过期 worker 不能覆盖并发的暂停/取消/终态决定"，traits.rs:104-112）。types 侧提供 `run_status_kind` 12 态分类法与 done/failed/active 分组、`ExecutionPhase` 进度枚举、`derive_team_status`（结合合并冲突数推导 TeamExecutionStatus）、`sum_usage`、`summarize_unsuccessful_agents`（最多列 3 个失败 agent + "+N more"）与 `warn_persist!` 宏（best-effort 持久化失败仅告警）。

**worktree_isolation.rs（866 行）+ conflict_resolver.rs（306 行）——多 agent 并行编辑隔离**
- `WorktreeManager`：`create_worktrees` 为每个 agent 建 `agent/{safe_id}-{delegation_id前8位}` 分支 + worktree（重复 agent_id 提前拒绝；`sanitize_agent_id` 只留字母数字-/_，:30-40、185-266）；全程持 `RepoLock(Arc<Mutex<()>>)` 串行化同仓库 git 操作（:318）。
- `merge_worktrees` 按 `merge_order` 顺序 `git merge --no-ff`；冲突时若有 `ConflictResolver` 先 `extract_file_conflicts`（`git show :1/:2/:3:path` 取 base/ours/theirs，conflict_resolver.rs:79-117）→ LLM 解决 → `apply_resolutions`（写文件+git add+验证无 unmerged+commit，:123-194）；仍失败则记录带 `CompositeSnapshot`（指回 pre-merge HEAD）的 `ConflictInfo` 并 `git merge --abort` 继续后续合并（:413-435）。cleanup 逐项 `git worktree remove --force` + `git branch -D`，仅当全部失败才报错（:446-513）。
- 测试桩 `TheirsWinsResolver`/`FailingResolver`。

**ws_progress_callback.rs（241 行）**：`WebSocketProgressCallback` 实现 `astra_tools::ToolProgressCallback`，用 `mpsc::try_send` 把 `ProgressEvent::{Started,Delta,Completed,UserPromptResolved}` 转发到 WS handler 的轮询循环——"fire-and-forget"，通道满或关闭即丢弃不阻塞（:53-92，测试 :227-239 验证满通道丢事件）。

#### 4.4.2 astra-sync-protocol —— 边云同步线协议（单文件，89 行）

- `sync_outbox_request_signature(token, body)`：HMAC-SHA256（密钥=token）对 `astra_core::canonical_json_string(body)` 签名，输出 `sha256=<hex>`，置于头 `x-astra-sync-outbox-signature`（lib.rs:8-16）。规范化 JSON 保证字段序无关（测试 :68-79 验证 {"b":2,"a":1} 与 {"a":1,"b":2} 同签名）。
- `SyncOutboxAck{schema_version=1, record_id, payload_hash, ingestion_status: Created|IdempotentReplay}`；`confirms()` 要求版本、ID、哈希三者全中（lib.rs:34-61）——幂等重放的判定标准。

#### 4.4.3 astra-messaging —— agent 间消息传递框架

**架构**：`MessageTransport` trait（transport.rs:71-123：register/unregister/subscribe/resolve_agent/list_agents/send/broadcast/health_check/shutdown）+ 两个实现——`InProcessTransport`（tokio 通道，CLI 单进程）与 `DatabaseTransport`（MySQL/MatrixOne 持久化，云端多进程）。`AgentMailboxRouter` 在其上做目标解析（Direct/Broadcast/Parent）。

- **types.rs**：`AgentAddress{run_id, agent_id}`（Display 去重嵌入的 run 后缀，:31-43）；`MessagePayload::{Text,Progress,Request,Response,Signal,Ack,Nack}`（tagged `"type"`）；`AgentMessage{requires_ack, ack_message_id(持久化投递重封套后的逻辑ID), ttl_ms, correlation_id}` + `is_expired`/`make_ack`/`make_nack`（:158-386）；`MailboxError` 12 变体（含 `AgentIdentityConflict`、`AckTimeout{attempts}`）；`agent_communication_event` 把消息转成 `astra_turn_types::AgentCommunicationEvent` 审计证据，摘要按字符截断到 1000+省略号（:187、292-301）。
- **router.rs（核心，~900 行）**：`AgentMailbox` 持 mutex 包裹的流 + `buffered` 双端队列（等待相关响应时暂存无关消息）；`request_permission`（:189-264）发送 `Request{ToolPermission}` 并带超时轮询，非匹配消息进 skipped 队列最终还原，响应到达即 `stream.acknowledge`（持久传输的消费确认）；`Drop` 实现 best-effort spawn 反注册（:277-295）。`AgentMailboxRouter.send` 对 `Parent` 目标：先 delegation tracker 找父 run → `parent_delivery_aliases`（turn 级父 run → 会话级稳定信箱）→ 地址注册表 → tracker agent_id 合成；全失败显式 `Protocol` 错误而非猜根标签（"DB 传输会把消息持久化给永不注册的信箱"，:538-589）。发送遇 `AgentNotFound` 时在 `registration_gate` 内重试或入 `pending_parent_messages`（上限 256 run × 256 条，:646-663），父信箱再注册时重放并改写目标地址、丢弃过期消息（:380-426）。
- **ack_tracker.rs**：`PendingAckTracker`（默认 ack 超时 30s、重试 3 次、扫描 5s，:35-41）；`sweep()` 把超时项升级为 Retry（attempts+1）或 Failed，Rejected 单列；`AckSweepHandle` Drop 中止扫描任务。
- **dead_letter.rs**：有界环形 DLQ（默认 1024，容量 clamp 1..4096）；`DeadLetterReason::{AckTimeout,Rejected,TransportFailure,Expired}`；`take_for_retry`/`drain_all`/`purge_all`/`reason_summary` 运维接口。
- **in_process.rs**：直发 mpsc 每 agent 容量 4096（`try_send` 满→背压错误而非阻塞，:216-249）；广播通道每委派组容量 256；`InProcessStream::recv` 用 `biased` select 优先直发消息，广播 Lagged 计数后继续（:308-330）。
- **db_transport.rs（约 2030 行，最大文件）**：
  - 表结构（文档 :27-62）：`agent_message_queue`（主键 message_id，status pending/claimed/acked/failed，claimed_by/claim_token/attempt_count，两组覆盖索引）+ `agent_message_broadcast_delivery`（每消费者投递行）+ `agent_mailbox_directory`（30s 租约、10s 续期，DB 时间 `UNIX_TIMESTAMP(NOW(6))*1000` 避免应用时钟漂移，:82-84）。
  - `ensure_schema` 运行时建表/补列（:143 起）。`send` = INSERT + `wake_local_consumer`（Notify 立即唤醒同进程消费者，:876-905）；`subscribe` 为每个信箱 spawn `poll_loop` 任务（100ms 轮询、批 100、空闲退避到 2s、错误指数退避 200ms→10s、连续 30 次告警，:77-103、1548），通过 256 容量本地 mpsc 喂给同步 `try_recv`。
  - 可见性超时 60s、最多投递 5 次；`reclaim_stale_in_pool` 回收超时 claim（attempt+1，超限转 failed）；`CleanupScheduler`（默认 5min）：回收 stale → TTL 清理 → 终态行 >1h 清理 → 孤儿广播投递行清理，每语句批 1000（:1772-1894）。
  - `DatabaseMessageStream::acknowledge` 走 `mark_direct_acked`/广播 ack；`shutdown` 释放全部 claim 并按 `owner_instance_id` 删除目录行（:949-997）。
- **metrics.rs**：原子 `LatencyTracker`（min/max/sum/count 无直方图）+ `MessagingMetrics` 聚合计数 + `MessagingEventHandler`/`StderrEventHandler` 事件钩子。

#### 4.4.4 astra-memoria —— Memoria 语义记忆规范端口（单文件，约 1000 行）

**定位修正（事实）**：该 crate 不是 HTTP 客户端，而是"CLI/Edge/Server 共享的规范 Memoria 边界"（lib.rs:1-7）——端口 trait + 校验 + 会话运行时状态；具体 HTTP 实现在其它 crate（thin-client 提供 `/memory/*` 代理路由与 `get_url` 直连 Memoria health）。

- `MemoriaToolTransport{base_url, credential, owner_user_id, owner_scoped_master}`：每次操作重新解析的短命凭据；`authorization_header()` 在 `Memoria-Owner`（衰减式 owner-only 方案）与 `Bearer` 之间选择（:22-40）。
- `MemoryScope{user_id, session_id}`：两个身份严格区分（"绝不许用 owner 顶替 session id"），构造时拒绝空白/首尾空格/控制字符（:48-72）。
- **fail-closed 严格召回校验**：`validate_strict_recall_payload` 接受顶层数组或 `{memories|items}`，要求每条记忆回显 user_id+session_id，缺失即 `memory_scope_violation`（:80-115）；`merge_strict_recall_working_memory` 做 read-your-writes 投影（working 型记忆置顶、按 memory_id 去重、受调用方上限约束，:128-172）；`validate_strict_memories` 为类型化等价。
- `MemoriaPort` trait（:249-388）：`admits_operation`（先于一切读写裁决同意）、`bind_owner`（多租户 Server 必须先绑定 owner，不支持时显式报错而非"静默复用别家租户凭据"）、`resolve_tool_transport`、`retrieve_for_prompt/retrieve/retrieve_ext/retrieve_scoped_typed`、`store`、`purge_working/purge_memory_types`、`store_episode/store_scene`、`reflect_session`（反思合成，返回 `ReflectSummary`+候选，`parse_reflect_candidates` 解析 :405-439）、`feedback`。
- `MemoriaMemory`：`age_days/age_label/freshness_suffix`（委托 `astra_turn_types::freshness_suffix_for`，信任层级参与新鲜度后缀，:460-481）。
- `MemoriaRuntimeState`（进程本地、按持久 session id 键控，全局单例 `memoria_runtime_state()` OnceLock，:916-919）：已见记忆环形 512、召回账本 16 条/快照 64 ID、全局 1024 会话、24h 空闲 TTL（:509-514）；`begin_recall` 发 UUIDv7 令牌并立即作废旧选择、`complete_recall_for_producer` 校验令牌后入账（晚到的完成被忽略，:660-763）、`drain_recalls_for_producer` 消费型取回（`latest_recall` 则非消费型，供后续指代回合使用）、`acknowledge_removed` 在生产者确认删除后清理身份。

#### 4.4.5 astra-thin-client —— 无状态 HTTP + SSE 瘦客户端

**分层**（lib.rs:1-10）：paths（URL 常量）/ protocol（请求体与 StreamEvent 分类）/ edge（执行器元数据）/ sse（增量解析器）/ client（reqwest 传输）。刻意不依赖 `runtime`/`services`，前端可依赖而不拖入认知引擎。

- **paths.rs（约 758 行）**：约 80 个路由常量/函数，覆盖 auth、sessions（含 `/sessions/{id}/device/{enroll,challenge,trust,revoke}` 四段设备协议族）、chat run 控制（pause/resume/delegate/delegations）、Work API（`/v1/works/...` 全部经 `is_safe_path_segment` 白名单——仅 `[A-Za-z0-9._-]` 且拒绝 `.`/`..`，返回 Option 让不安全 ID 在传输前失败，:239-245、测试 :721-756）、models（`model_segment` 对 NON_ALPHANUMERIC 减 `-._~` 百分号编码，防 provider 模型名中的 `/?#` 改变路由身份，:8-17）、memory 代理、`/v1/chat/completions`、admin、audit、`/sync/outbox/events`。
- **protocol.rs（约 1050 行）**：`ChatStreamRequest`；`ToolResultRequest`（Edge 回投结果，含 `edge_agent_id`、`result_hash`）；`compute_result_hash` 构造 `{"schema":"astra.tool_result_hash.v2", …}` 后做**递归键排序的规范化 JSON SHA-256**（`hash_canonical_json` 手写序列化器保证对象键排序稳定，:270-380），工厂 `new_with_hash` 强制所有调用点带哈希——"结果回执不是挂在幂等回调旁的无签名单通道"；`tool_result_status_is_error` 封闭词表（completed=成功；failed/partial_failure/denied/rejected/cancelled/interrupted/timeout=失败；未知=None 拒绝，:387-394）；`ApprovalRespondRequest{decision: Allow|Deny|AllowSession, approval_kind: Standard|Explicit}`；`UserPromptRespondRequest`（answers 留作 JSON，由服务端按持久 prompt 校验）；`EdgeHeartbeatRequest{pending_request_count, last_seen_request_ids}` 与 `EdgeHeartbeatResponse{unresolved_request_ids, replay_policy: DurableResultReconciliationRequired(唯一变体), ack_request_ids}`——"挂起传输状态不能证明副作用可以安全重放"（:486-533）；`StreamEvent` 封闭分类 + `Other` 兜底 + `classify_stream_event`。
- **sse.rs**：`SseParser` 字节缓冲增量解析 `\n\n`/`\r\n\r\n` 分隔的 `data:` 帧（多行 data 拼接），`finish()` 处理无尾分隔器的末帧。
- **device_proof.rs**：设备挑战证明——`canonical_device_proof_message` 以 `"astra-device-proof-v1\n"` 域前缀 + 7 个长度前缀字段（防标点歧义）构造消息（:40-62）；`device_challenge_proof` = HMAC-SHA256(key=SHA256(device_key), msg 含 SHA256(challenge)) 的 base64url（:70-95）；设备密钥与原始挑战绝不进结果；有 golden vector 测试锁定跨端一致性。
- **edge.rs**：`ASTRA_EDGE_ID_HEADER="X-Astra-Edge-Id"`；`builtin_capability_preset()=["bash","fs","git","code_intel"]`；`edge_runtime_environment_capabilities` 用 `astra_runtime_env::RunBinding::resolve`（edge_workspace 读写 + edge_agent 执行器 + host_process 运行时 + local_developer 策略）生成结构化能力广告（:38-57）。
- **work.rs（约 700 行）**：Work 任务图 V2 严格契约（`deny_unknown_fields` + 上限：项 256、边 1024、页 8/128、`MAX_SAFE_INTEGER=2^53-1`，:11-17）；`WorkTaskGraphPageV2::validate` 起始的校验链逐层检查 basis/cursor/item/delivery/verification 的一致性（含 execution.terminal 与状态终态一致、run 存在性、修订单调等，:351-595）——"解码即拒绝撕裂分页与不协调事实"。
- **client.rs（生产约 2035 行，含 wiremock 测试共 3751 行）**——`ThinClient{http, http_stream, base, bearer_token}`：
  - 双客户端：`http` 常规；`http_stream` 专用于 SSE——**关闭自动解压**（防 Content-Encoding 导致 reqwest 缓冲破坏流式）+ 连接超时 60s（响应体不限时，"聊天回合可持续数分钟"）（:143-157）。**回环地址强制 `no_proxy`**（localhost/*.localhost/127.0.0.1 绕过继承的代理变量，防本地控制面被劫持到基础设施代理；远程地址保留环境代理行为，:110-141）。
  - 认证：`bearer_headers`/`auth_headers_for`（per-request token override 优先于构造时默认 bearer）；Work 请求额外带 `x-astra-work-api-major: 1`（`work_api_headers`，:225-232）。
  - 响应处理三态：`text_or_api`（非 2xx → `Api{status, body}`）、`json_or_error`（空体→Null）、`callback_ack_or_error`（**控制面回调以成功状态码为确认边界**，不等待可选响应体，防已提交决策被延迟体误判失败，:255-267）。
  - `post_developer_loop`（:1186-1223）：POST `/chat/stream`，成功时校验响应头 `x-astra-agent-interaction-api-major=="3"` 否则 `IncompatibleRuntime`（提示"先重启/升级 Server"）——协议大版本门禁在拿到 SSE 体之前完成。`post_developer_loop_retry_429`（:1230-1283）：仅在响应头到达前重试；429 用 `Retry-After`（clamp 1..120s）否则 2^n 指数退避；传输类错误（connect/timeout/request）1^n 退避重试。
  - `chat_stream`（:1286-1376）：async_stream + SseParser；跟踪 `saw_terminal`（TurnComplete/RunFinished/RunCancelled/RunError/RunInterrupted/RunPaused/RunWaiting/Done/不可重试 Error，:45-61）；终态后的流错误静默收尾，**EOF 无终态事件则报错**（:1368-1373）。
  - 控制回调族（tool result/approval/user-prompt respond，:1837-1971）：统一 10s 超时 × 2 次尝试，仅对 connect/timeout/request 类传输错误重试同一请求体（依赖服务端幂等）。
  - `post_sync_outbox_event_json`：以 `sync_outbox_request_signature` 签名 + 校验 `SyncOutboxAck::confirms`（依赖 astra-sync-protocol）。其余覆盖 sessions/runs/delegations/transcript（scope=Session|RootConversation|Run）、artifacts 下载（解析 Content-Disposition 文件名）、models 分页、memory 代理、edge 注册/心跳（带 X-Astra-Edge-Id）。

#### 4.4.6 astra-mcp —— MCP 客户端集成

**职责**（lib.rs:1-6）：CLI（edge agent）与 server 运行时共用的 MCP 连接、工具发现、schema 转换与分发。基于 `rmcp` 1.3（官方 Rust MCP SDK），超时常量 `MCP_CONNECT_TIMEOUT_SECS=30`、`MCP_TOOL_CALL_TIMEOUT_SECS=120`（lib.rs:30-33）。

- **types.rs**：`Transport::{Stdio{command(首元素为程序,其余为参数), args, env}, Sse, StreamableHttp, Ws}`（Sse/HTTP/WS 均带可选 auth_token+headers）；`RetryConfig` 默认 5 次/1000ms 起/30s 封顶。
- **error.rs**：`McpError::side_effects_maybe()` 区分"结果未知"（TransportSend/TransportClosed/UnexpectedResponse/Cancelled/Timeout/ConnectionLost——重试可能重复外部副作用，须保留为结果未知证据）与"派发前失败"（ToolNotFound 等终态）（:37-53）。
- **connection.rs（约 880 行）**：`ChangeHandler` 实现 rmcp `ClientHandler`——声明 roots 能力、`on_tool_list_changed` 等通知置 AtomicBool（下次 `refresh_tools_if_changed` 才拉取）、日志消息转 tracing、`list_roots` 返回共享根列表（:62-143）。`McpConnection` 缓存工具清单，`call_tool_with_metadata`（:243-344）：非对象参数包成 `{"input": …}`；120s 超时→`ServiceError::Timeout`；`is_error=true` 计为 acknowledged failure；每次调用记录延迟/错误/环形调用日志（100 条）。`discover_skill_resources` 发现 `skill://` 资源（:432-448）。`connect_to_server` 指数退避重试（`initial×2^(n-1)` 封顶 max_delay；`InvalidConfig` 不重试，:458-496）。四条连接路径：
  - `connect_stdio`：`TokioChildProcess` + **危险环境变量过滤**（`is_dangerous_env_var`，:574-580）；
  - `connect_sse`：自研 `ClassicSseTransport`；
  - `connect_streamable_http`：rmcp 官方 transport，`reinit_on_expired_session=true`，auth_header/自定义头（:669-739）；
  - `connect_ws`：tokio-tungstenite 握手（手写 Sec-WebSocket-Key 等头）后用两个 64KB `tokio::io::duplex` 把"文本帧↔换行分隔 JSON"桥接到 rmcp 的 async-rw 传输，读写桥任务在 `MpConnection::drop` 中止（:764-861）。
- **classic_sse.rs**：手写经典 SSE 传输（兼容 mcp-go 服务端）——GET 打开事件流，等待 `endpoint` 事件解析消息端点（**强制同源**，跨源报 `CrossOriginEndpoint`），其后 `message` 事件按行 JSON-RPC 解析，请求经 POST 发到消息端点；端点等待 30s 超时；drop 中止读任务（:49-175）。
- **manager.rs（约 620 行）**：`McpClientManager`（连接表 + 状态机 + `tool_routes_by_public_name` 路由索引 + 冲突记录 + 共享 roots）。两阶段接入 `prepare_connection`/`install_prepared_connection`——握手（进程启动/网络 IO）不持管理器锁，发布为短临界区（:95-118）。公开工具名 `mcp__{server}__{tool}`（`sanitize_tool_name` 归一），**同名冲突 fail-closed**：冲突工具从 schema 快照与路由中剔除并记录 `McpToolCollision`（:519-546）。`call_tool_by_mcp_name(_with_metadata)` 解析路由→执行→`extract_tool_call_result`。`refresh_changed_tools` 用 `Arc::get_mut` 独占刷新并原子重建路由索引（:311-331）。
- **tools.rs（约 570 行）**：schema 转 OpenAI function-calling 格式（描述截断 2048、结果文本截断 100 000 带 `[truncated]` 标记）；provider snapshot 的 checked 投影支持从工具 `_meta` 发布稳定别名（`STABLE_TOOL_ALIAS_METADATA_KEY`）；`extract_tool_call_result` 产出 `{output(拼接文本), structured_content, protocol_metadata(结果 meta 透传), is_error}`；环境变量黑名单：前缀 `LD_*/DYLD_*/SUDO_*/SSH_AUTH_SOCK` + 精确 `IFS/BASH_ENV/ENV/CDPATH/GLOBIGNORE/SHELLOPTS/BASHOPTS/PROMPT_COMMAND/PYTHONPATH/NODE_PATH/JAVA_TOOL_OPTIONS/HOME/XDG_*/DISPLAY/RUST_BACKTRACE`（:464-499）。

#### 4.4.7 astra-harness —— 运行时守护/评测 harness

**运行模型**：agentic 循环在 7 个 `HookPoint`（SessionStart/PreLlmRequest/PostLlmResponse/PreToolBatch/PostToolBatch/PostTurn/SessionEnd，lib.rs:171-180）向 kernel 提交 `DecisionRecord{session_id, turn, point, 快照}`；kernel 先写 `SnapshotSink`，再逐个运行 `Verifier::check` 产出 `Violation{severity, recovery_threshold}`，聚合为 `HookVerdict::{Continue, Block{reason}, Pause{reason, recovery_threshold}}`（lib.rs:186-229）。`RuntimeSnapshot`（schema v3，lib.rs:31-109）是约 40 字段的只读计数器集（上下文窗口、token 四桶含 cache、内循环 turns_used 与外层 session_turn 分离、`settlement_rounds_reserved` 显式保留结算回合——注释强调"不得从 turns_limit 变化推断结算授权"（lib.rs:47-53）、工具使用、行为信号 read_only_round_streak/redundant_read_count、委派深度、连续错误数、causal_chain_id）。

- **kernel.rs**：`StandardKernel::configured` 组装默认 6 验证器（Budget/TurnGuard/Delegation/Confidence/Progress/Completion）+ 可选 Cost（配了 max_session_cost_usd 才装）/ToolGuard（配了调用上限才装）（:32-65）。`on_record` 用 `catch_unwind` 包裹每个 verifier：`is_critical()`（Budget/Cost）panic → Block（fail-closed），其余 panic 记日志跳过（fail-open）（:170-191）；Fatal 立即 Block；首个 Pause 携带 `recovery_threshold` 返回（恢复后用更严阈值）。`HarnessProfile::{Default, Swebench}`——SWE-bench 离线跑关闭只读检查点（streak/redundant 置 0），"跑到出 patch、结束或 runner 超时"（:136-147）。
- **verifiers/**（8 个）：
  - `BudgetVerifier`（critical；PostLlmResponse/PostTurn）：turns/tokens/duration 超限 Fatal；`settlement_rounds_reserved` 加到 turns 上限（budget.rs:27）。
  - `CompletionVerifier`（SessionEnd）：`completed` 但无最终文本 → Fatal（"拒绝空成功"）；`empty` 终态 → Fatal；interrupted 缺 kind 或 kind 属异常集（BudgetExhausted/EmptyCompletion/StreamTransport/StreamIdle/AuthFailure/HarnessBlocked/HarnessPaused，来自 `astra_turn_core::InterruptionKind`）→ Error（completion.rs:18-95）。
  - `ConfidenceVerifier`：连续错误 ≥3 Error；同工具重复+有错误 Warning。
  - `CostVerifier`（critical）：按四桶 token × 单价估算，超限 Fatal、超 80% Warning（cost.rs:40-67）。
  - `DelegationVerifier`：每 turn 委派 >5 或递归深度 >3 Fatal。
  - `ProgressVerifier`（PostTurn）：只读连续 ≥32 轮**且**冗余读 ≥6 才 Pause（区分"高效探索"与"卡死循环"），冗余读 ≥4 Warning；恢复阈值 16 且 clamp 到 max-1；终态快照跳过（progress.rs:20-96）。
  - `ToolGuardVerifier`：敏感工具 Warning、会话调用超限 Fatal。
  - `TurnGuardVerifierAdapter`：同工具签名连续 ≥3 Warning、≥5 Fatal。
- **trace.rs**：`SessionTrace`（serde、VecDeque 记录、`dropped_records` 逐出计数）+ 查询 API；`save_to_file/save_jsonl` 均 tmp+rename 原子写（:104-138）；`PrivacyPolicy::{Full, MetadataOnly, Redacted(默认)}`——Redacted 用手写 FNV-1a 64 位哈希工具/模型名、截断 session id（"不用 DefaultHasher，跨 Rust 版本稳定"，:158-235）；`RecordingKernel` 包装内层 kernel 记录全部 DecisionRecord（上限 10000 环形、session_id 晚绑定且不匹配即置 outcome=Error 拒收、SessionStart/End 记账、内层 Block → outcome=Blocked，:243-348）。
- **外围工具**：`adjust.rs`（std mpsc 双通道：运行中调预算/断点/敏感工具名单）、`query.rs`（Latest/History/Diff 查询通道）、`debug.rs`（`DebugKernel` 断点：AtTurn/AtHookPoint/Token/ToolCall/ContextUtilization 阈值，命中 Pause；内层 Block 优先）、`forensics.rs`（`forensics_summary`：上下文 >90%、同工具 ≥3、token 3 倍跳变告警）、`rollback.rs`（`assess_rollback`：目标回合后的 token/工具差值、使用过的工具列表、按硬编码可变更工具表判 Safe/HasSideEffects/InvalidTarget）、`scenario.rs`（Assertion DSL：MinRecords/Outcome/TurnRange/MaxTokens/HookFiredAtLeast/NoForensicsWarning/MaxDurationMillis/Custom fn 指针）、`snapshot_diff.rs`（相邻快照增量）。
- **capability_matrix.rs（约 900 行）**：`CAPABILITY_CASES` 37 条产品能力清单（id/quadrant/topology/kind/boundary/system_test/model_validation），10 个象限、3 种拓扑（CliServer/ServerOnly/EdgeServer）、Happy/Unhappy、`ModelValidation::{Probe, DeterministicOnly}`——协议竞态/租户隔离/幂等/故障注入"刻意仅确定性验证，让 LLM 判这些边界只会产生无证据的信心"（:38-54）。`validate_capability_matrix` 校验清单自洽（ID 唯一、字段完整、每象限 Happy+Unhappy 齐备、每拓扑有覆盖）（:370-450）；`verify_trace_contract` 对任意模型产生的轨迹检查确定性不变量（无逐出、非空、会话身份存在且稳定、快照与记录身份一致、turn 单调、单调时钟有序、LLM/工具批配对平衡、计数器单调、终态一致），"不检查任何 assistant 散文或 prompt 措辞"（:458+）。

**在产品中的角色**（综合事实）：harness 是运行时的预算/停滞/委派/成本守护（StandardKernel 挂进 agentic 循环，Pause 对应 CLI 的 decision checkpoint、Block 对应 budget_exhausted/harness_blocked 中断类型——与 turn-core 的 InterruptionKind 对齐）；同时是评测基础设施——capability_matrix + scenario + trace + Swebench profile 支撑 SWE-bench 与能力矩阵回归，RecordingKernel/PrivacyPolicy 负责证据留存与脱敏导出。

### 4.5 Turn 编排核心（astra-turn-types / astra-turn-core）

Astra 的"一次对话回合（Turn）"智识核心由两个 crate 构成：

- **astra-turn-types**（27 文件）：零 I/O 的版本化契约层。所有跨进程、跨层传输的 Turn 语义事实（工具调用身份、会话游标、分叉清单、恢复投影、提供方声明等）在此定义为带 `SCHEMA_VERSION` 常量的纯类型 + 校验函数。依赖仅 serde/serde_json/sha2/thiserror/regex/astra-prompts。
- **astra-turn-core**（223 文件）：Turn 执行引擎的"纯函数 + 薄基础设施"层。`lib.rs:1-6` 自述"从 runtime crate 抽出的核心类型、契约与纯助手，不依赖 AppState / 数据库 / Axum 等运行时设施"。它把 agentic 循环控制、权限裁决、上下文装配管线（Plan→Bind→Optimize→Serialize）、SSE 流消费、审批门、工具策略、压缩与恢复做成可独立测试的模块群；真正的宿主循环（CLI `stream_chat_sse`、runtime server_loop）通过 trait 回调（`SseStreamHost`、`ApprovalSink`、`ToolApprovalGate`）接入。

术语约定：**Edge** 指 CLI/本地执行侧，**Cloud/Server** 指云端编排侧；**§5.5** 指项目设计文档的"云→边工具投递协议"章节（见 `cloud/tool_delivery.rs`、`edge_ledger.rs` 注释）；**CSL**（Conversation State Log）是追加式会话状态日志；**PTL** = prompt-too-long（上下文超限错误）。

#### 4.5.1 Turn 状态机与生命周期

Turn 没有一个显式的 `enum TurnState`；其状态机由**三类正交状态**组合而成，这是本 crate 最重要的架构事实：

1. **管线恢复状态**（`recovery_state.rs:14` `RecoveryState`）：`consecutive_ptl_errors` / `has_attempted_reactive_compact` / `max_output_escalation_count` / `consecutive_same_errors`。`record_ptl_error()`（:28）递增；`reset_on_success()`（:44）在成功回合清零但保留升级历史；`should_abort()`（:58）在连续 3 次 PTL 后要求中止——这是管线侧的"熔断阈值"，由 `context/pipeline.rs:138` 在 Plan 之前检查（`PipelineAbort::ConsecutivePtlExhausted`）。
2. **循环摄入结果**（`agentic/turn_ingest.rs:99` `AgenticTurnIngestOutcome`）：`Break`（无工具调用 → 终答）、`Continue`、`Fatal(ClassifiedError)`、`HasToolCalls`（进入工具执行轮）。每轮模型响应后由 `ingest_agentic_turn_stream()`（:130）产出，`map_ingest_outcome_to_iteration_control()`（:116）映射为宿主的迭代控制枚举——**循环控制在库内是纯函数判定，在宿主是迭代器驱动**。
3. **阶段回执**（turn-types `phase_receipt.rs`：`TurnPhaseReceiptV1` / `TurnPhaseKindV1`）：版本化、传输安全的阶段完成回执，供 live 交付、持久重放、trace 与 CLI Explain 用同一协议校验。

生命周期（推断自调用关系，见 CH7）：用户消息 → payload 组装（`chat_turn_payload`）→ 上下文管线 `run_turn`（Plan/Bind/Optimize/Serialize）→ 请求发出 → SSE 消费（`consume_sse_stream_cancellable`）→ 审批/工具 Edge 执行（`flush_pending_via_host`）→ 结果回填（`headless/assembly` 配对 + `set_payload_tool_results_if_non_empty`）→ `ingest_agentic_turn_stream` 判定继续或终止 → `complete::TurnCompletionFacts` + CSL 持久化（`conversation_log/manager.rs:174 persist_turn`）。

关键细节：**只有无工具调用的纯文本才算终答**。`turn_ingest.rs:161-166` 明确注释：伴随工具调用的文本是"中间前导（preamble）"，若误当终答会让中断/预算耗尽的回合看起来成功完成（测试 `tool_turn_draft_text_does_not_become_final_output` 锁定该行为）。另有 `should_preserve_prior_final_after_runtime_scaffolding_retry()`（:340）：runtime 注入消息后的无工具重试不覆盖既有终答。

#### 4.5.2 agentic 循环（模型→工具→再模型）

`agentic/` 目录（9 文件）刻意**不包含循环本体**——宿主（CLI/runtime）持有 while 循环，本 crate 提供四个循环钩子函数：

- **轮前**：`agentic/turn_flow.rs:14 agentic_round_stall_preflight()` 把 server tool_calls 与 edge 轮次行合并为 stall-guard 形状后调 `apply_cli_agentic_stall_preflight`（`agentic/stall_preflight.rs:30`）：记录每轮工具签名集（name+args），3 轮完全相同 → `sig_stall` 事件（`stall.rs:23 SERVER_STALL_WINDOW=3`）；5 轮相同 → 一次性 `repetition_threshold` **咨询性**事件（`stall.rs:36`，注释引用真实会话 05e63cac：`cargo clippy` 连跑 4 次烧尽 token）。重要原则（`post_tool_policy.rs:1-7`）："行为信号是证据不是权威"——stall/divergence 只产生 advisory，真正的停止权在预算与安全边界。
- **轮中**：`prepare_payload.rs:10 attach_filtered_edge_tools_to_payload()` 把经 restricted_tools 过滤的 schema 挂到 `/chat` payload；`recursion_guard.rs:6` 定义绝对递归上限 `ABSOLUTE_MAX_AGENT_RECURSION_DEPTH=8`（产品层 profile 可更低）。
- **轮后**：`post_tool_policy.rs:85 apply_agentic_post_tool_policy()` 记录 TurnGuard 观测、写重 checkpoint、产出 `PolicyAdvisory`（带 ttl_rounds/dedupe_key 的衰减建议，序列化为 `policy_advisory.v1` 注入消息）。
- **摄入**：`turn_ingest.rs:130 ingest_agentic_turn_stream()`（CH6 详解）汇总 token 四桶、维护 `consecutive_context_window_errors`（成功即清零，防止陈旧计数在后续无关错误上误升级压缩，:259-263）、错误分类（优先宿主预分类 `error_kind`，否则字符串分类 `classify_llm_error_message`）、终答守卫 `apply_response_guards`（`response_guard.rs`：系统提示泄漏/内部协议 XML/回声/重复循环检测，触发则替换文本并以 `RESPONSE_GUARD_REDACTED_FINISH_REASON` 终止）。
- **Server-owned 循环**：当云端代理执行整个循环时，`ServerLoopExecutionSummary`（`chat_turn_sse_dispatch.rs:384`）作为"仅观测汇总"到达 Edge——这些调用已在远端执行，绝不能变成新的本地工作（`turn_ingest.rs` 测试 `server_execution_summary_is_observed_without_replaying_remote_work` 用 `panic!("...must not request an Edge tool")` 闭包锁定）。

辅助：`turn_telemetry.rs`（首命中延迟 + 工具面报告捕获）、`verdict_audit.rs`（非健康 TurnGuard 裁决的结构化审计行，只 Debug 不序列化）。

#### 4.5.3 权限与审批门（permission + approval + plan_mode_policy）

这是全 crate 工程化程度最高的子系统（permission/ 16 文件 + approval/ 6 文件）。

**单一裁决器**：`permission/engine.rs:1-47` 的模块注释是一份安全债清偿记录——历史上 CLI（Flow A，完整硬拒绝链）与 runtime 子代理门（Flow B，仅 deny→allow→mode→mailbox，**缺失 git 破坏性防护、敏感路径、沙箱扩展、会话覆盖、显式审批门**）是两个裁决器，任何只进 Flow A 的检查都会成为子代理的旁路。修复即 `evaluate_permission()`（engine.rs:394）及其带 provider policy 的变体 `evaluate_permission_with_provider_policy()`（:407，CH6 详解）：**纯函数**，输出 `DecisionEnvelope`（decision + source + trace + will_save + risk_tags）。

**14 槽固定判定序**（engine.rs:204 `EVALUATION_ORDER`，由 pinning 测试冻结）：SchemaIdentity → DenyRules → SafetyMiddleware → GitSafety → ExecuteHardDeny → SensitivePath → SandboxExpand → ToolAllowlist → AskRules → ReadShortCircuit → SessionOverride → ExplicitApproval → AllowRules → Mode。每步向 `trace` 写 `DecisionTraceStep`（Skipped/Matched），支撑 `/permissions why` 可解释性。要点：
- **auto 模式放松**：`shell_obfuscation` 类软违规在 auto 模式继续放行（engine.rs:492-502），但 catastrophic（rm -rf /、fork 炸弹）与破坏性 SQL 永远硬拒。
- **Plan 模式是覆盖层不是能力面**（`plan_mode_policy.rs:1-5`）：保留完整工具面供探索，`is_plan_mode_blocked_tool()`（:71）做 args 级判定——`bash git status` 放行、`bash touch x` 拒绝（`is_plan_read_only_bash` :42 白名单 ls/grep/git status/cargo check 等）；plan 控制工具（enter/exit_plan_mode）与 plan 内部著作（memory/task_list 等）永远放行。
- **读短路**：`is_read_only_tool_with_args`（parallel_tool_exec.rs:217）+ provider policy `is_read_only()` 命中即 Allow（engine.rs:816-835），Deny 模式除外。
- **动态工具风险标签**：`RiskTag`（engine.rs:230）13 种多标签分类；MCP 工具用 `ToolCapabilityMetadata`（:288，destructive/readOnly/openWorld hint），无注解即 `MCPUnknownCapability`；传入 descriptor 级 `ResolvedInvocationPolicy` 时会**丢弃从公共别名推断的标签**（:422-441），防止 `mcp__*` 名字与实际执行用的 descriptor 矛盾。

**三种 NeedExternal 出口**（`approval/sink.rs`）：`ApprovalSink` trait（:66，async）+ 三实现——TUI 队列、父代理 mailbox、`HeadlessFailClosedSink`（:96，无交互面时一律 Deny 并给出 "--mode auto" 修复指引，保证 `astra -p`/`astra exec` 不会静默挂起）。`ApprovalResponse`（:44）三值：AllowOnce/AlwaysAllow/Deny（P0 移除了翻转全会话的 AutoRunSession）。

**审批身份体系**（approval/）：`request_key.rs`（严格请求同一性，队列去重 + 陈旧重验）、`fingerprint.rs:85+`（内容感知指纹——`bash("git status")` ≠ `bash("rm -rf /")`，支持 shell 前缀/文件 glob 匹配及 DenialLimits 拒绝节流）、`batch_group.rs`（UI 批量分组键）、`base_digest.rs`（宿主生成的文件摘要做陈旧重验）、`scope.rs`（五档 Always 作用域）。会话内覆盖经 `fingerprinted_override`（engine.rs:892）进入 SessionOverride 槽。

**权限模式模型**（`permission/types.rs:25`）：Auto/Bypass/Plan/AcceptEdits/Prompt(默认)/Deny 六模式；`ChildPermissionMode`（:57）**类型级排除 Bypass**——根用户的"别打断我"不能变成可传递的子代理安全策略。父子同步经 `permission/sync.rs:263 PermissionRequestHandler`（async `handle_request` :279）与 `InheritedPermissions`（types.rs:759，含 `for_child` :1206 收敛）。

支撑件：`rule_grammar.rs`（fail-closed 的 `.astra/permissions.json` 规则语法）、`path_glob.rs`（gitignore 风格匹配）、`path_sensitivity.rs`（敏感路径单一策略边界）、`compound_command.rs`（复合命令拆分展示）、`script_preview.rs`（本地脚本预览防"名字无害内容有害"）、`cwd_root.rs`（包根定位）、`redact.rs`（审批卡密钥脱敏）、`memory_profile.rs`（memory 工具写入路径解析）、`audit.rs`（三事件审计轨迹）、`notice.rs`（跨纯文本终端的结构化通知）、`match_target.rs`（作用域匹配目标）。WS 侧还有 `ws_approval_gate.rs` / `ws_user_prompt_gate.rs`（经 §5.5 edge 回调账本桥接 WebSocket 审批/提问门）。

#### 4.5.4 上下文装配与压缩（context/ + compaction + working_memory + token_accounting）

这是"每次模型调用前发生什么"的完整答案，采用**两遍 Plan 的五阶段管线**（`context/pipeline.rs:1-4`：Plan → Bind → Optimize → Serialize → Explain/Metrics）：

- **Plan**（`context/planner.rs:68 plan_turn()`，CH6 详解，纯函数零 I/O）：读 `TokenAccounting`、`RecoveryState`、`SessionLatches`、`PipelineStats`，产出 `ContextPlan`（sections 清单 + `TokenBudget` + `CompactionTier` + `CacheStrategy` + pressure/reserves）。压力分层（`context/budget.rs:14-18`）：≥0.60 TrimSchemas、≥0.75 CompactHistory、≥0.90 AggressivePrune；`select_tier_gated`（:42）保证预测压力只能**升级**不能降级；`escalate_for_recovery` 按 PTL 次数再升级。预算分配（budget.rs:63 `TokenBudget::allocate`）：Identity/Constraints 各 min(10%,2000)，Memory 按 tier 15%/12%/8%/5% 并用 EMA 历史收缩（下限 256），剩余按 `SectionKind::all_planned()` 均分（新增枚举变体是编译错误而非静默零预算）。
- **Bind**（`context/binder.rs:32 bind_all` / :59 `bind_sections`）：把 PlannedSection 解析成 BoundSection；运行时已预取外部数据，绑定是纯内存变换。Section 顺序有缓存语义：Global（Identity/Constraints）→ Session（SelfModel/ProjectContext/Skills/RuntimeIdentity）→ None（RuntimeVolatile，每轮漂移的内容必须在第二个缓存标记之后）。
- **两遍测量**（pipeline.rs:161-201）：先初步 Plan+Bind，用 `estimate_bound_input_tokens`（:279，sections 实测 + messages/tool_schemas 全 JSON 序列化估算，注释明确"提供方 tokenizer 才是权威"）得到 measured 值再最终 Plan——因为"提供方 usage 是计费台账，不一定是本请求的上下文占用"（:168-171）。
- **Optimize**（`context/optimizer.rs:91 optimize_with_spill`）：在 `OptimizeLimits`（`optimize_limits.rs`，每变换独立布尔门，关闭即 trace 记 skipped）内做缓存对齐、预算适配的变换；超限内容经 `SpillBackend`（`spill_backend.rs`）外存为 SpillReference。`HistoryOptimizationOwner`（pipeline.rs:39）确保管线与下游语义压缩器**只有一层**做有损历史削减。自适应门（`run_adaptive` :100）：变换门由最终实测 plan 推导，压缩级联激活时抑制 tool_result 清理防死循环。
- **Serialize**（`context/serializer/mod.rs:33 serialize_provider_request()`）：产出 `SerializedProviderRequest`（system_blocks + messages + tool_schemas + cache_markers）。Anthropic 协议下系统块最多放 **1 个** `cache_control` 标记（:190-230 `remap_cache_markers_to_blocks`，选最深块使缓存前缀最长），预算分配为 1 system + 1 tools + 2 messages（注释：丢系统标记损失约 200 缓存 token，丢消息标记损失整个会话前缀）；标记用 `{"type":"ephemeral"}`（:291，Bedrock 不传播 ttl beta header）。`wire_cache_annotations.rs` 处理 tools[]/messages[] 级标记；曾导出的 `cache_edits`/`cache_reference` 已删——Anthropic `/v1/messages` 对未知字段返回 400（注释引 2026-05-08 会话）。

**压缩三层体系**：
1. **microcompact**（`microcompact.rs`，2375 行）：每轮 LLM 调用前就地清理旧工具结果，双触发（数量 > KEEP_RECENT 或 token 超 TOKEN_BUDGET）。占位符分 provider 策略（`CompactStrategy` :32）：Normalized（`[Cleared: tool key=value — re-run if needed]`，稳定前缀利于 OpenAI/GLM/DeepSeek 前缀缓存）vs Minimal（`[Cleared]`，Anthropic 协议级缓存不占心占位符内容）；`STABLE_ARG_KEYS`（:120）只保留 path/pattern/url 等稳定键。`PromptCacheProtocol` 与 `ProviderCacheStrategy::from_cache_capability`（:73）从 `cache_placement::CacheCapability` 推导。
2. **compaction_types / compression_types / cloud/compact_prompt / cloud/summary**：`CompactionTier` 四档类型；`cloud/summary.rs generate_compact_summary` 在 tier ≥ AggressivePrune 时用 LLM 生成稠密摘要；`cloud/compact_prompt.rs` 是压缩提示模板；`cloud/grouping.rs` 按 API 轮次分组消息使 PTL 重试能整轮丢弃；`cloud/attachments.rs` 压缩后重注入显式附件（活动技能、会话计划）。
3. **working_memory**（`working_memory.rs:41 WorkingMemoryState`）：必须**在压缩与 checkpoint 恢复中存活**的 prompt 面状态——decisions（cap 8）/blockers（cap 6）/next_action 的有界队列；`apply_user_correction`（:101）清空 blockers 与 resume 动作并把纠正确立为新决策；`render_prompt_section`（:157）渲染为 prompt 节。

**token_accounting**（`token_accounting.rs:16`）：四个**不相交桶** prompt/cache_read/cache_creation/completion（总和=计费总量），替换 AgenticLoopState 裸 4×u64；`total_input_u32_saturating()`（:48）在 u64→u32 边界饱和而非截断，防病态计数回绕成低压力；`cache_hit_ratio()`（:56）供诊断。配套 turn-types `context_window.rs`（上下文占用事实，与计费分离）与 `NormalizedPromptCacheUsage`。

**会话横向状态**：`session_latches.rs:30 SessionLatches`——一次性闩锁（beta header / cache scope / provider feature 首次触发后**会话内永不变化**），防止中途模式切换打断 KV 缓存前缀；`any_flipped_this_turn`（:99）让优化器在刚翻转的轮次抑制缓存标记。`pipeline/stats.rs PipelineStats` 跨轮累计（响应 token 估计、节 token EMA、缓存命中率）；`context/feedback.rs` 把 API 响应反馈回流 stats；`pipeline/session.rs:262 PipelineSession::run_turn` 是运行时每轮 LLM 请求前的唯一入口（:294 `run_turn_adaptive` 为推荐入口）。

#### 4.5.5 工具注册表与策略（tool/）

`tool/` 目录（33 文件）分层：

- **categories/mod.rs**（2377 行）：**工具行为元数据的单一事实源**——文件头明确列出曾被硬编码工具名列表污染的 8 个模块（stall/turn_guard/parallel_tool_exec/microcompact/headless_assembly/safety_middleware/cloud_approval_policy/concurrency_safety）全部收敛于此。`classify(tool, args)` 是 args 感知的（`git status` vs `git push` 不同类）。`surface.rs` 按能力（`capability.rs:Capability`）解析工具可见面：`visible(tool) = surface_admits(tool.scope, surface)`；`workaround.rs` 在工具被限时给出安全替代建议。
- **registry/**：`meta.rs:102 TOOL_CATALOG` 静态目录（name/description/**中英双语 triggers**/intents/scope/requires/schema_tokens——刻意不用嵌入模型，可调试零延迟）；`plugin.rs` 运行时注册插件/技能清单工具；`chain.rs` 工具编排链（模板变量引用前步输出）；`report.rs ToolSelectionReport` 记录"模型本次看见了哪些工具"供 journal 与质量分析。
- **policy/**：`mod.rs:62 is_tool_concurrency_safe()` 动作感知并发分类（memory 的 recall/expand/profile、agent 的 spawn/get_result、git/github 只读 action 并发安全；send_message 可能重排序保持串行）；`TOOL_BATCH_COALESCE_MS=25ms`（:18，env `ASTRA_TOOL_BATCH_COALESCE_MS` 可调、上限 250ms）是 SSE 相邻并发安全 tool_request 的合批窗口。`hooks.rs` pre/post 工具钩子框架（观察/修改/否决，全局注册表）；`preview.rs` 工具调用一行预览的统一渲染器。
- **args/**：`hints.rs` 只读**规范键**（path/command，不读 file_path/cmd 别名）；`shape.rs tool_call_name/canonicalize_tool_call_for_execution` 兼容 OpenAI 嵌套与内部扁平两种 tool_call 形状。
- **result/**：`sanitize.rs` 发往模型前剥离 CLI 专属载荷；`compression.rs` 类型感知压缩（截断会变"哈希沙拉"时保结构）；`dedup.rs` 无副作用调用短窗去重缓存；`semantics.rs` 输出解读与稳定调用键（§5.5 去重）；`storage.rs` 超阈值结果落盘 `~/.astra/sessions/<id>/tool-results/`，内存留预览。
- **schema/**：`prune.rs` 压力下修剪 schema（阈值与 budget.rs 共享 `PRESSURE_TRIM_SCHEMAS`）并保留已调用过的工具；`surface_subset.rs` 为结果轮规划工具子集。
- **health/**：`mod.rs` 会话内每工具错误预算追踪（连续失败超阈值 → 建议换路）；`persistence.rs` 跨会话存 `~/.astra/tool-health/<profile>.json`。
- 其他：`deferred_activation.rs`（延迟工具激活契约：`tool_search(query="select:NAME")` 后才有完整 schema）、`runtime_binding.rs`（MCP 名空间工具需活绑定才可执行）。
- **tool_allowlist.rs:30 compute_effective_allowlist()**：请求级与技能级允许表 **AND 交集**（None=无意见，空 Some=显式全拒），规范化名称后求交。

#### 4.5.6 SSE 事件流（sse/ + chat_turn_sse_dispatch + sse_events + stream_events）

双层结构：**协议层**（`sse/blocks.rs` 空行分帧的 SSE 事件块；`sse/data_lines.rs` OpenAI 风格逐行 `data:`；两者互补）、**语义层**（`chat_turn_sse_dispatch.rs`，4135 行）。

`dispatch_chat_turn_sse_event_block()`（chat_turn_sse_dispatch.rs:1568）解析块内多 `data:` 行，`[DONE]` 终止（:1581），JSON 解析失败写入可见的合成错误而非静默忽略（:1589-1596），然后逐事件 `apply_one_event`（:677）：text_delta/thinking_delta 累积到 `ChatTurnSseAccum`（:188）；`reasoning_done` 捕获 Bedrock thinking signature 供下轮回放（:745-756，缺失会被 Bedrock 400 拒绝）；`session_info`/`run_started` 经 `StreamRootIdentity`（:120）绑定**物理根身份**——后代 run 的 run_id 不得替换根（:130 `observe_event` 对中途换根报 `Invalid SSE root identity`）；`user_intent_applied` 只对根 run 生效（:762-769）。工具调用规范化拒绝空名（`record_invalid_tool_call` :615）。`ContextCompactionObservation`（:64）带 `is_consistent()`（:85）结构性校验（计数互相吻合）。`InjectionChannelFingerprint`（:34）只传哈希不传原文——注释记录了一次真实泄露事故（wip-7 之前原文经 `transform_run_event_for_client` 泄露学习到的反馈规则与 memoria 摘要）。

**消费循环**：`sse/stream_host.rs:458 consume_sse_stream_cancellable()`（CH7/CH6 素材）是宿主中立的状态机：`SseStreamHost` trait（:255）提供渲染回调（on_render_effects/on_tool_call_complete/on_idle_tick...）与三个能力洞（execute_tool :352、resolve_approval :367、execute_tools_batch :411）。特性：双档空闲超时（首帧前紧、有进展后宽，:133/:138）；`DurableTerminalProbe` 在字节层先行探测失败终态以及时取消（:552-562）；工具合批窗口（:612-635）只对已判定并发安全的请求等待 25ms 让兄弟调用（尤其 agent spawn）加入同一批；`prioritize_skill_tools`（:1266）稳定分区把 skill 工具排前。取消/超时走"墓碑"路径：清 partial 状态、丢弃 pending、合成错误。

`sse_events.rs`（Server→Edge 事件信封，版本号 `major*1000+minor`）与 `stream_events.rs`（流事件类型）是两个独立的事件协议层。

#### 4.5.7 云侧协作（cloud/）

`cloud/`（10 文件）实现 **§5.5 云→边工具投递**：`tool_delivery.rs`（2853 行）是协议边界——可选 approval 门 → `tool_request` → 工具结果账本，使审批与回调行为无需 provider I/O 即可测试。`approval_policy.rs:cloud_gated_tool_kind(_with_args)` 判定哪些边工具需 `approval_required` 往返，且与 CLI 权限提示共用图标分类防漂移。`session_facts.rs`（L1a 系统跟踪会话事实，纯模型在 turn-types）、`session_memory_extract.rs`（轮中抽取变化状态为规范工作内存快照）、`summary.rs`/`compact_prompt.rs`/`grouping.rs`/`attachments.rs`（见 4.5.4）、`cache_diagnostics.rs`（提示缓存断裂原因检测：系统提示变更/工具 schema 变更/模型切换）。

#### 4.5.8 安全（safety_middleware、guardrails、circuit_breaker、rate_limit_cooldown）

- **safety_middleware**（2730 行）：权限引擎第 3 槽的执行者。`evaluate_tool_safety_request()`（被 engine.rs:479 调用）输出 `SafetyMiddlewareDecision::Allow/Deny(reason)`。内容：命令替换 `$(...)` 内只允许 `SAFE_SUBST_COMMANDS`（:17）；zsh 专有危险内建（`zmodload`/`zpty`/`ztcp`... :32）与预命令修饰符跳过检测的对抗；提示注入模式两级（`INJECTION_PATTERNS_EXACT` :49 精确子串——"ignore previous instructions"、`<|im_start|>` 等 LLM 控制 token；`INJECTION_PATTERNS_CONTEXTUAL` :72 带验证器防误报，如 `[inst]` 后必须非字母数字避免匹配 `[install]`）；破坏性 SQL 关键字（:10）；凭据脱敏转发自 astra-tools。软硬分级：`shell_obfuscation` 软违规可被 auto 模式放松，catastrophic 永远硬拒（见 4.5.3）。
- **guardrails/mod.rs** 是域重组门面：聚合 `error_recovery` + `turn_guard` + `verdict_audit` + `explain_report_lines`——"回合开始失速或工具失败累积时协同工作的部件"。`turn_guard.rs`（2466 行）`TurnGuard` 聚合 stall/divergence/工具健康/错误恢复为每轮 `TurnVerdict` 咨询证据（`record_tool_calls` :269、`record_tool_result_with_kind` :316 等）。
- **circuit_breaker.rs:19 CircuitBreaker**：edge→cloud 桥的标准三态断路器（CLOSED/OPEN/HALF_OPEN；默认 5 失败/30s 恢复/半开 3 成功）， Mutex 保护状态迁移 + 原子计数器，目的注释明确："持续云故障触发快速拒绝而非 240s 超时"。`allow_request()`（:74）/`record_success`（:97）/`record_failure`（:112）。
- **rate_limit_cooldown.rs**：429/529 连发冷却（默认 30s、上限 2min、Retry-After<20s 直接重试）；连续 3 次 529 触发**降级模型回退**；`ASTRA_DEFAULT_RETRY_AFTER_MS` env 供 E2E 测试加速；6 个 Prometheus 指标（:68-78）。
- 另有 `loop_circuit_breaker.rs:153 LoopCircuitBreaker`（agentic 循环异常断路器，"默认无限运行，只在失速或退步时触发"，`observe(RoundSignal)` :248 产出 BreakerAction）与 `response_guard.rs`（输出侧守卫，见 4.5.2）。

#### 4.5.9 astra-turn-types 契约层要点（27 文件）

按编号分层组织：L1a `session_facts`（系统跟踪零 LLM）；L2 `memory_structure`（持久记忆类型结构门——semantic/episodic/procedural 持久化必须校验，working 自动清理）；L3 `memory_ranking`（Memoria 结果整形；注释记录了"客户端再加 tier 乘数=双重计分"的已修复 bug）。核心契约族：
- **provider_contract.rs**：协议无关的提供方发现与工具身份（ProviderClaim/Trust、ResolvedToolDescriptor、StableToolAlias、NativeToolId、语义缓存契约）——适配器只解码事实，**不决定**权限/重试/缓存/提示位置策略。
- **tool_invocation.rs**：持久工具调用身份与状态机（TOOL_INVOCATION_RESULT_MAX_BYTES 等字节上限常量族、`canonical_public_arguments_hash`）；与 `tool_idempotency.rs`（重试安全分类）分离。
- **session_cursor.rs / session_coordination.rs / session_fork.rs / session_handoff.rs**：会话游标（ConversationCommitV1/DeltaV1、`canonical_conversation_identity`）、多写者协调（ConversationWriterLeaseV1、SignedExecutionGrantV1、TurnReservationV1）、分叉清单（ForkBasisDimensionV1）、交接（ManifestDeltaV1、`valid_transition`）。
- **runtime_scaffolding.rs**：runtime 拥有消息的类型化标记（`is_runtime_owned_message` 等——协议状态不能从自然语言推断）；**resume.rs**：恢复投影集（ResumeBundleV1、`select_resume_bundle`）；**phase_receipt.rs** / **turn_provenance.rs** / **user_intent.rs**：阶段回执、消息来源标记（`_astra_turn_provenance`）、用户意图语义（`_astra_user_turn_semantics`，judge 拥有的 objective 关系）。
- **provider_canonical_transition.rs**：提供方请求拥有的规范消息的 WAL（write-ahead）身份——HTTP 授权前提交物理尝试准入，恢复绝不从 wire role/模型名/提示文本推断所有权。

#### 4.5.10 其余模块速览

`orchestration/`（9 文件）：子代理编排——`builtin_agents`（内置代理类型）、`team_config.rs`（YAML 自定义代理类型 `~/.astra/teams/`）、`spawn_tool.rs`（spawn schema + ForkPrefix 继承请求）、`fanout_group.rs`（扇出组槽位纯核算）、`progress.rs`（子代理进度事件）、`context_cache.rs`（跨代理文件内容/知识片段两级缓存）、`agent_result_wire.rs`（结果线格式）。`fork/`（7 文件）：ForkPrefix 原语——`prefix.rs`（父轮可缓存前缀的冻结字节级快照，使子代理首次请求复用父 prompt cache）、`capture`/`reconstruct`/`resolve`/`prefix_store`（有界容量+软 TTL）/`cache_event`（遥测）。`headless/`（7 文件）：§5.5 无头工具轮——`assembly.rs`（云 tool_calls 与 edge 执行行配对、超时中止名单、幂等缓存命中消息）、`postprocess.rs`（错误/限额富集 + TurnGuard 质量）、`journal.rs`（ToolCallRecord 行）、`body_preview`/`status_display`/`stderr_lines`（展示层）。`conversation_log/`（4 文件）：CSL 追加日志——`mod.rs` 定义 CslEntry（Snapshot+TurnDelta），`file_store.rs`（JSONL，边侧）/`db_store.rs`（SQL 表复合主键 (user_id,session_id,seq)，feature `db-store`）/`manager.rs`（统一管理器：load/persist_turn/fork/reset）。`introspect`（根 + 3 子文件）：`introspect` 工具的自省——budget 自适应深度、`cache_diagnosis.rs` 四条纯函数缓存诊断规则、`observation.rs`（观测平面归一化）。`pipeline/`（7 文件）见 4.5.4 + `journal.rs`（管线 journal 事件）、`metrics.rs`（零依赖 Prometheus 兼容注册表）。其他值得注意：`interruption.rs`（每条早退路径产出 InterruptionRecord：为何停 + 如何恢复，双写重 checkpoint 与轻 trace）；`emergent_context.rs`（Execute(N)→Bind(N+1) 回流，防陈旧附件累积）；`file_edit_journal.rs`（文件前态日志支持回滚）；`edge_ledger.rs`（§5.5 回调账本：HTTP 插入、消费者取走，至多一次交付）；`injection_tracking.rs`（每通道新鲜度，动机是真实会话 f85a02bb：注入的 meta 数十轮不换实已陈旧）；`e2e_hooks.rs`（feature 门控的全栈确定性测试钩）；`xml_tool_call_fallback.rs`（模型在文本里发 `<invoke>` XML 或 ```json 代码块时的降级解析）。

### 4.6 持久化服务层（crates/services，包名 astra-services）

`astra-services` 是 Astra workspace 中最大的业务 crate（src 下 **150 个生产 .rs 文件**，`dir /s` 计 151 个 .rs，其中 `byok_endpoint/proxy/tests.rs` 为测试文件），承载几乎全部数据库（MatrixOne，MySQL 协议）与本地文件持久化域服务。`src/lib.rs:1-80` 声明约 80 个模块，并在 `lib.rs:112-415` 以大量 `pub use` 把各域的 trait / record / 服务类型平铺到 crate 根命名空间。

**组装方式（SharedPool 显式注入）**：所有 `Database*Service` 构造时 `pool: Option<SharedPool>` 为空，必须由上层在组装期调用 `.with_pool(shared_pool)` 注入；运行期 `get_pool()` 走 `lib.rs:95-102` 的 `require_shared_pool`，未注入则直接返回 `sqlx::Error::Configuration`（错误信息明确要求"wire .with_pool(...) at composition time"，见 `lib.rs:82-93`）。实际组装点在 `crates/runtime/src/server/state_builder/core.rs:24-262`：例如 `DatabaseAuthService::new(...).with_pool(shared_pool.clone())`（core.rs:25-26）、`DatabaseSessionService::new(...).with_pool(...)`（core.rs:109）、`DatabaseModelService::new(..., encryptor).with_pool(...)`（core.rs:124-125）等，随后以 `Arc<dyn XxxService>` 装入 `AppState`（`runtime/src/app_state.rs:159,176`）。每个域通常提供三实现：`Database*`（MatrixOne）、`Unconfigured*`（返回统一的 unconfigured 错误）、部分域另有 `InMemory*`/`Local*`/`Noop*`。

#### 认证与账户（auth/、admin、admin_config）

- `auth/mod.rs`（3459 行）定义 `AuthService` trait（`auth/mod.rs:402-582`）：register/login/refresh/logout/current_user/current_principal/外部 provider 登录/edge 令牌绑定/重认证等。`DatabaseAuthService`（`auth/mod.rs:717-741`）持有 JWT 设置、可选 Fernet 加密器、外部 provider 列表、edge 令牌 HMAC 配置及三类防重放缓存。登录核心 `login`（`auth/mod.rs:1699-1767`）：bcrypt 校验（cost 由 `ASTRA_BCRYPT_COST` env 控制，`auth/mod.rs:25-34`）→ 生成 session_id → 签发 access/refresh JWT → 事务内 `UPDATE auth_users SET last_login_at` + `INSERT auth_refresh_tokens`（只存 token 的 SHA-256 哈希 `token_hash`）。`register`（1586-1697）事务写 `auth_users` + `auth_user_roles`，重复键兜底判定。`refresh`（1781-1909）轮换刷新令牌：`SELECT ... FOR UPDATE` 锁用户行 + 比较并吊销旧 token（rows_affected!=1 即并发已吊销）再插入新 token。`current_principal`（2102-2218）验证 access JWT → 查 `auth_refresh_tokens` 会话活性（`refresh_session_is_active`，1256-1271）→ Memoria 绑定检查。另有 moi-backend 签发的 `moi-user-token-v1` 边缘令牌本地 HMAC 校验（`verify_user_token`，120-169）+ fail-closed 远端吊销检查（`check_edge_token_revoked_cached`，1048-1103，30s 正向缓存 + per-JTI in-flight 合并）；`moi-provider-v1` 一次性 HMAC 请求令牌（`verify_provider_request_hmac_token`，194-259，绑定 method/path/body_digest/nonce，DB 唯一键 `auth_provider_request_replay` 防重放，1175-1209）。`map_auth_sqlx`（1524-1559）把池超时映射为 503。
- `auth/jwt.rs`：HS256/384/512 JWT 签发与解码（`create_jwt_token` 66-83，jti 用 Uuid 保证同秒唯一；`decode_jwt_claims` 21-26）。claims 含 sub/username/type(access|refresh)/sid/origin。
- `auth/session.rs`：`SessionService` trait（L32）+ `DatabaseSessionService`；`create_session`（468-513）在事务内先 `storage::lock_agent_session_write_fence`（写栅栏）再 `INSERT INTO agent_sessions`（L486），同事务回读（规避 MatrixOne 旧快照），提交后 `log_session_audit("session_create")`（L511）。还含 delete（级联硬删，见 session_lifecycle）、设备租约（session_device_leases）、列表游标分页。
- `auth/external.rs`：外部认证 provider（OAuth 式 `ExternalAuthProviderConfig`、`HttpExternalProviderClient`、authorize_request 会话句柄加密存储 `auth_external_sessions`、edge 令牌吊销检查 HTTP 客户端）。
- `auth/memoria.rs`：Memoria 托管身份 provider（`MemoriaProvider`、凭据解析器、`ACCESS_TTL_SECONDS` 令牌寿命、重认证 proof 哈希）。
- `auth/encryption.rs`：`FernetTokenEncryptor`（加密 provider 会话句柄）+ `sha256_hex`。
- `auth/admin.rs`：`DatabaseAdminAuthorizer/Initializer/TokenReader/TokenWriter/AuditReader/FeedbackStatsReader/UserRoleManager`（基于 `auth_roles`/`auth_user_roles`/`auth_tokens`/`auth_audit_logs`）；`admin.rs`（src 根）定义对应 trait 与 `AuthenticatedUser`。
- `admin_config.rs`：`admin_config` KV 表的 `DatabaseAdminConfigService`（如 `reasoning_offering_id`），带允许键白名单 `ADMIN_CONFIG_ALLOWED_KEYS`。
- `resource_governor.rs`：按用户日限额（会话创建数/工具调用/token）`ResourceGovernor` trait（L117）+ `DatabaseResourceGovernor`（L205），HTTP 层会话创建前调用（见 CH7）。

#### 会话 / 运行 / 回话日志与恢复（session 族、runs、storage、event_ingestion）

- `session_journal.rs`（7200+ 行，本地文件）：每会话一个 JSONL journal（`~/.astra/sessions/v1/users/<owner>/...`），`JournalWriter`（2296）`append`（2364-2382）单次 `write_all` + `fsync`（O_APPEND 原子性说明见 2354-2363 注释）；`append_canonical_commit_cas`（2451-2473）在排他文件锁内完成"比较-追加-持久化-世代确认"，配合 `SessionExecutionLease`（2030，文件锁租约）防止陈旧写者二次提交同一 turn。`JournalEvent`（1548）+ `JournalEventType`（1719，80+ 事件类型）覆盖 turn/tool_call/approval/delegation/checkpoint 等；`TurnEventBuffer`（2929）在回合内缓存事件批量 flush；`state_delta` 子模块（771-966）提供基于版本的会话状态 CRDT 式累加器。读取侧有 `read_journal*`、tail、approval/ask_user 查询、会话归档与维护（`run_session_maintenance` 7183）。
- `session_checkpoint.rs`：会话检查点（owner 目录下 `checkpoints/<n>-<slug>.md` Markdown 摘要，非数据库）。
- `session_restore.rs`：跨 MatrixOne + 本地文件的会话恢复（先证明会话属主，再拉本地 journal/检查点与云端工件）。
- `session_lifecycle.rs`（pub(crate)）：会话硬删除：`SessionDeleteStatement` 表驱动地按序删除 30+ 张表中的会话数据（含 `session_deletion_tombstones` 墓碑）。
- `session_fork_coordinator.rs`：O(1) 会话分叉——固定父 manifest + 各状态维度证据，激活只装"共享前缀指针 + 新子头"（表 `session_forks`/`session_fork_events`）。
- `session_handoff.rs`：跨部署位置的会话接管（attach=只读；handoff 经 `SessionContextCoordinator` fence 成为写者；持久 `Fencing` 转移先于 fence 写入，崩溃可幂等重试；表 `session_handoffs`/`session_handoff_events`/`session_handoff_slots`）。
- `session_context_coordinator.rs`：数据库级 canonical 会话协调（单分支头 + 单写者 + turn 预留；`session_context_heads`）。
- `session_artifact_store.rs`：`OwnerScope`（local/user/...）抽象 + 本地/数据库会话工件存储边界。
- `runs.rs`（35000+ 行）：`RunLifecycleService` trait（L50）与 `RunStateStore` trait（L3557，含防陈旧执行者的 durable owner capability）。核心 `insert_run_record`（11087-11300+）：补全 root_run_id/ancestor_path/depth（父 run 查询）→ 事务内 `storage::admit_session_scoped_run_write`（会话准入）→ `SELECT session_id FROM agent_runs ... FOR UPDATE` 锁 run 身份（跨会话重用 run_id 直接拒绝）→ `INSERT INTO agent_sessions/agent_runs`（11239/11373，按 NULL 形状分两条 SQL）→ 初始事件行。事件持久化 `insert_run_event_rows_tx`（10545，`INSERT INTO agent_run_events`）与投影 `run_display_projections`（10505/10779）；状态机更新族 `update_run_status*_if_current`（compare-and-set，防止旧世代覆盖）；工具输出批 `insert_tool_output_batch`（10173，`session_tool_output_batches`/`session_tool_outputs`）；检查点（16440，`run_checkpoints`）；执行槽 `agent_session_execution_slots`（9732/9806）。附带 `InMemoryRunStateStore` 与事件客户端投影函数 `transform_run_event_for_client`。
- `storage.rs`（9100+ 行）：schema 引导 `ensure_core_schema`（3323-3391，进程内互斥 + 数据库级 `astra_schema_bootstrap_leases` 租约 + 单连接池 DDL + 可见性等待）；内嵌 **约 120 张表的 CREATE TABLE DDL**（L125-8825）与表契约（`astra_schema_table_contracts`，733）。会话写准入：`admit_session_event_write`（1077）、`admit_session_scoped_run_write`（1161）、`lock_agent_session_write_fence`（1385）、`bump_agent_session_event_count`（1218）、事件 DAG 边 `insert_agent_event_edges*`（1480/1521）。审计 `log_session_audit`（8968，`INSERT INTO auth_audit_logs`，best-effort 失败仅 warn）。清理 `cleanup_expired_data`（9095）。
- `event_ingestion.rs`：journal 事件异步摄入 MatrixOne `agent_events` 表（优先级队列、字节预算预约 `IngestionQueueReservation`、内容脱敏 `redacted_content_marker`）。
- `session_audit.rs` / `session_analytics.rs` / `session_memory_inventory.rs` / `session_workspace.rs` / `session_identity.rs`：云侧审计查询（turn/tool/session 级视图）、journal 统计、记忆投影清单、工作区元数据、会话 ID 规范校验（`MAX_PERSISTED_SESSION_ID_BYTES`）。
- `db_row.rs`：`RowExt`/`RowDecoder`——统一 DATETIME/TIMESTAMP 时间列解码（MatrixOne 与 MySQL 线上类型不一致）。
- `snapshot_sql.rs`：MatrixOne 快照 SQL（validate identifier / create / restore）。

#### 模型注册与 BYOK 代理（models、byok_endpoint/、llm_trusted_domains、models/thinking_probe）

- `models.rs`（4300+ 行）：`ModelService` trait + `DatabaseModelService`。部署级目录 `infra_llm_models`（L3200 写入）与用户 BYOK `user_llm_models`。`create_user_model`（2776-2862）：校验别名/密钥 → `openai-compatible` provider 走 `byok_endpoint::require_endpoint_policy`（2804-2808）→ Fernet 加密 api_key（2810-2813）→ `validate_connectivity` 真连一次 provider（2814-2828）→ 事务内清默认 + `INSERT INTO user_llm_models`（2842）。解析链 `resolve_active_llm_model/offering`（1456/1529）带进程内 fresh/stale 双档缓存（`ActiveLlmModelResolutionCache`，969-1008，失败允许降级用 stale 缓存的策略在 816/1065）。思考能力探测 `probe_thinking_behavior*`（4179-4270+，协议感知、30s 预算、结果持久化 `thinking_probe_json`）。
- `byok_endpoint.rs`：用户自配 OpenAI 兼容端点的网络安全策略。`parse_endpoint`（65-95）强制 HTTPS、无凭据/query/fragment、公共主机、拒绝 `%` 编码路径；`public_ip`（97-124）排除私网/环回/链路本地/CGNAT/文档段（V4）与非全局单播（V6）。两种策略（`EndpointPolicy`，48-63）：`public-https`（默认，仅 URL 校验）与 `trusted-domains`（查 `runtime_llm_trusted_domains` 表，148-166）。核心 `endpoint_client`（196-205）：解析 URL → 解析 `ASTRA_BYOK_PROXY_URL` 出口代理 → DNS 解析 → 校验全部公共 IP → 有代理则 `proxy::client` 建本地 CONNECT 隧道适配器，否则 `resolve_to_addrs` DNS 钉扎的 reqwest client。
- `byok_endpoint/dns.rs`：hickory 直连配置的 DNS（`ASTRA_BYOK_DNS_SERVERS`，支持 tcp:// 前缀避免透明代理 Fake-IP UDP 应答），禁 hosts 文件、保持用户提供的 server 顺序（16-92）。
- `byok_endpoint/proxy.rs`：请求内拥有的 CONNECT 适配器——`EgressProxy::parse`（41-91）校验 http/https/socks5 代理 URL；`client`（265-313）在 127.0.0.1 随机端口起本地 TcpListener，构造仅指向它的 reqwest Proxy（随机 Basic 凭据）；`bridge`（209-263）只接受目标 authority 匹配且带该凭据的 CONNECT，把已验证 IP（绝不上送 provider 主机名）经上游代理 CONNECT/SOCKS5 打通后双向转发（端到端 TLS 由 reqwest 保持原主机 SNI；360s 截止）。
- `llm_trusted_domains.rs`：`runtime_llm_trusted_domains` 管理（管理员）。
- `models/thinking_probe.rs`：可持久化、绑定配置的思考探测观察类型（不在模型解析/推理路径做 I/O）。

#### 多智能体与 work（multi_agent/、work、work.rs、coordination、inference_execution、tool_invocation_ledger）

- `multi_agent/`：`edge_registry.rs`（边缘 agent 注册表：`edge_agent_registry` 表、注册租约 `EdgeRegistrationLease`、心跳）；`edge_dispatch.rs`（跨 pod 派发：`edge_pending_dispatch` 表、`EdgeDispatchWakeHub` 唤醒协调、backlog 指标）；`metrics.rs`（多智能体延迟/成功率指标，`MultiAgentMetrics`）。
- `work.rs` + `work/`（46 个子模块）：Work 是"用户可见工作的公共产品身份"，`WorkBranchRecord` 恰好绑定一个内部会话（work.rs 头注释与 1800）；域类型带强校验（`WorkGoal`/`WorkChangeReason` 等 newtype + `WorkDomainError`，1642-1760）。子模块成对出现：域逻辑（`criteria.rs`、`proposal.rs`、`evidence.rs`、`graph.rs`、`observation.rs`、`acceptance.rs`、`attention.rs`、`basis.rs`、`delivery_selection.rs`、`subject.rs`、`events.rs`）与 `*_repository.rs`（SQL 持久化）；操作型模块 `branch_creation_operation` / `branch_deletion_operation` / `control_operation` / `patch_commit` / `patch_materialization`（补丁物化到会话）/ `attempt_settlement`（执行尝试结算）/ `plan_context` / `criteria_proposal` / `proposal_queue` / `branch_catalog` / `branch_comparison` / `branch_retention` / `catalog`；`repository.rs` 汇总 `WorkRepository` trait；`runtime_event_outbox.rs` 从 `work_runtime_event_outbox_slots` 投影待处理运行时事件。
- `coordination.rs`：多智能体协调框架类型（AgentProfile/tier、CoordinationPattern、聚合策略），纯类型无 SQL。
- `inference_execution.rs`：推理调用持久化状态机（`inference_invocations`/`inference_provider_attempts`/canonical transition WAL；准入 `admit_inference_invocation*`、结算 `declare_inference_settlement*`、对账 `reconcile_inference_settlements`，签名见 lib.rs:201-216）。
- `tool_invocation_ledger.rs`：工具调用持久账本（`tool_invocation_ledger` + 归档块 `tool_invocation_archive_chunks`，原子 CAS）。
- `verification.rs`：Work/skill/harness 共享的验证契约（`VerificationCriterion`/`VerifierKind`/`LlmJudge`/`VerificationRunner`）。

#### 审计与治理（session_audit、execution_grant、weighted_admission、service_error、pagination、runtime_maintenance）

- `session_audit.rs`：`agent_events` 之上的结构化审计查询层（turn/tool/session 级）。
- `execution_grant.rs`：HMAC-SHA256 签名的执行授权（`ExecutionGrantSigner::issue` L52 / `verify` L116，claims 来自 astra-turn-types，防跨 run 提权）。
- `weighted_admission.rs`：字节/token 加权多租户准入（内存 `WeightedAdmissionController` + 分布式 `DatabaseWeightedAdmissionController`：`session_weighted_admission_gates` `FOR UPDATE` + `session_weighted_admission_reservations` 插入/续约/释放，try_reserve L139、gate 锁 L412-413、INSERT L515）。
- `service_error.rs`：`ServiceError`/`ServiceErrorKind` 结构化错误（替代 `Result<_, String>`）。
- `pagination.rs`：HTTP 列表上限（`MAX_API_LIST_LIMIT=200` L5、`MAX_API_LIST_OFFSET=1_000_000` L9、admin audit 500 L13）+ clamp 函数。
- `runtime_maintenance.rs`：后台维护扫描（`sweeper_leases`/`maintenance_sweep_cursors`）。

#### 同步引擎（sync_engine、sync_outbox、state_sync、state_projection、config_version_cloud、edge_context）

- `sync_engine.rs`：统一 SyncOrchestrator（598）：`SyncDomain`（39，Learning/Events/Tasks/Templates 等）× `DomainAdapter`（299，各域自定义合并/冲突策略）× `CloudTransport`（375，MatrixOne/S3/HTTP/Noop）；`SyncEnvelope`（115）统一协议，local-first push/pull。
- `sync_outbox.rs`：本地 journal→云端摄取之间的持久队列（头注释）：稳定逻辑 event id + 独立 payload hash + 重试/退避 + 连续 ack 水位 + 毒丸隔离；`SyncOutboxStore`（301）。
- `state_sync.rs`：edge 本地文件与 MatrixOne 间元数据/偏好同步（`MatrixOneSyncService` L409、`LocalOnlySyncService` L370；审计缓冲 `spawn_audit_flusher` L74）。
- `state_projection.rs`：会话状态投影（`session_state_items`/`session_state_item_events`，写校验 `validate_state_mutation`，压缩不变量 SQL 常量 `COMPACTION_INVARIANT_SQL`）。
- `config_version_cloud.rs`：内容寻址配置版本云存储拉取。
- `edge_context.rs`：云侧处理用的类型化 edge 上下文（替代松散 JSON map）。

#### 技能 / MCP 注册（skills、skill_config、personal_skills、marketplace、marketplace_stats、mcp_registry）

- `skills.rs`：`skills_registry` 表 CRUD；`skill_config.rs`：`skill_settings` 配置校验/读写；`personal_skills.rs`：个人技能源/版本/评估/激活（`user_skill_sources`/`user_skill_versions`/`user_skill_evaluations`，SKILL.md 规范化 + 内容哈希）。
- `marketplace.rs`/`marketplace_stats.rs`：技能市场安装（`skill_installations`）与跨用户质量统计/搜索（`skill_metrics`）。
- `mcp_registry.rs`：MCP 服务器/绑定/发现工具注册（`mcp_servers`/`mcp_bindings`/`mcp_tools`，schema hash 与工具命名空间）。

#### 其他域

`agents.rs`（agent_agents）、`agent_bindings.rs`（agent_bindings）、`agent_lessons.rs`（跨会话经验类型）、`branches.rs`（会话分支）、`context.rs`（ctx_snapshots）、`context_manifest.rs`（context_manifests/items + 预算分配）、`data_versioning.rs`（data_versioning_checkpoints）、`decisions.rs`（ctx_decision_audits）、`delegated_findings.rs`（委派发现截断）、`events.rs`（事件 API）、`external_artifacts.rs`、`artifact_policy.rs`（预签名下载 HMAC）、`harness.rs`（harness_* 6 表 + skillify 流水线）、`interaction_contract.rs`（审批/ask_user 语义契约，不建统一表）、`introspection/`（get_agent_info 云侧数据 + 打分）、`jobs.rs`（内存 job）、`model_request_context.rs`（无内容的模型请求可观测性）、`prompt_delta.rs`（prompt_request_records/prompt_deltas）、`reflect.rs`+`reflect/`（反思报告：错误模式/决策聚合）、`replay.rs`（会话重放对比）、`sandbox.rs`（infra_sandbox_metadata）、`self_surface.rs`（"自我"面板聚合）、`semantic_read_observation_store.rs`（语义读观察缓存）、`skill_auto_route_judge.rs` 与 `turn_intent_judge.rs`（LLM 判定 prompt 构造/解析）、`team_persistence.rs`（team_* 3 表）、`triggers.rs`（wf_triggers）、`workflows.rs`、`workspace_records.rs`（工作区记录/清理债）、`evaluation/`（eval_* 5 表的评估服务）、`registry_payload.rs`（pub(crate) 注册端点 URL 校验）。

### 4.7 服务器运行时（crates/runtime，包名 astra-runtime）

astra-runtime 是 workspace 最大的 crate（281 个生产 .rs 文件，约 36 万行），同时产出二进制 `astra-server`（src/main.rs）与库 `astra_runtime`。它是 Axum HTTP 服务器与运行时组合层：向上暴露 HTTP/SSE/WebSocket API，向下组合 astra-services（持久化）、astra-turn-core（turn 编排契约）、astra-tools/skills/mcp/sandbox（能力）、astra-edge（边缘执行对接）。

**入口**：`main()`（main.rs:5）先处理沙箱 invocation supervisor 与 build_info 探针，再 `AppSettings::from_env()` 解析 `host:port`，调 `astra_runtime::serve(addr)`（main.rs:25）。

#### 4.7.1 HTTP 服务器与路由（server/router_builder）

- `serve(addr: SocketAddr)`（server/mod.rs:251）：
  1. `astra_logging::init_from_env`（OnceLock 一次性初始化 tracing/OTLP，服务名 `astra-server`，默认过滤 `warn,astra_runtime=info,astra.http.access=info`）；
  2. `apply_safety_config_from_runtime_config`（lib.rs:117）——在任意请求到达前把 runtime.toml 的 `safety.trust_mode` 写入全局安全门（Strict/Trusted），明确注释"从用户输入调用是 bug"；
  3. `AppSettings::from_env()` → `state_builder::build_server_state(settings).await`（见 4.7.2）；
  4. `TcpListener::bind(addr)` 后 spawn 一组后台任务（bg_cancel CancellationToken 统一取消）：Memoria 健康探测（15s）、过期数据清理（6h）、edge dispatch 孤儿清理（15min/1h 过期）、edge 积压指标刷新（15s）、模型请求指标聚合（15s）、work 运行时事件投影、work 分支删除/补丁物化/补丁提交三个恢复任务、cleanup 债务重试、`sweeper_lease::spawn_runtime_sweepers`（多 pod 租约选主，TTL 60s，server/sweeper_lease.rs）；
  5. `axum::serve(listener, build_app(state)).with_graceful_shutdown(http_shutdown_signal())`（SIGTERM/Ctrl+C，server/mod.rs:416）；
  6. `finish_server_shutdown`（server/mod.rs:187）按固定顺序排水：edge WS 发 Closing → run_lifecycle 30s 排水（超时再 10s 强停）→ `turn::llm::durable::drain_provider_settlement_coordinator` 10s（推理台账结算）→ 停 sweeper → Matrix 摄取排水 → `astra_logging::shutdown_otel()` 最后冲刷 OTLP → 关闭数据库连接池。
- `build_app(state)`（server/mod.rs:155）：`router_builder::build_router(state)` 叠加 `DefaultBodyLimit::max(4MB)`、`request_trace::request_trace_middleware`（x-request-id 透传与错误体注入，server/request_trace.rs）、CORS（tower_http，origins 白名单或 `*`）。`build_test_router`（:151）为测试裸 Router。
- `build_router(state)`（server/router_builder.rs:10）：`Router::new()` 依次经 realtime → sessions → admin → automation → catalog → operations 六个 `add_routes`，最后 `.with_state(state)`。**所有路由注册在根路径，无 /api 前缀**（与任务提示中的"/api/chats"不同，以代码为准）。路由分组（均带行号出处）：
  - **元信息/健康/指标**（router_builder/realtime.rs:7-11）：`/`、`/live`、`/ready`、`/health`、`/metrics`（meta_handlers，/metrics 返回 Prometheus 文本）。
  - **认证**（realtime.rs:12-27）：`/auth/register|login|methods|memoria|refresh|logout|reauthenticate|me`（auth_handlers，1305 行）。
  - **Memoria 记忆代理**（realtime.rs:28-113）：`/memory/store|retrieve|search|purge|expand|correct|feedback|{id}|profile|reflect|snapshots|branches|health|governance|consolidate`——服务端代理 Memoria HTTP API。
  - **聊天/推理入口**（realtime.rs:114-139）：`POST /chat`（同步创建 run）、`POST /chat/stream`（**SSE 流式主入口**，chat_handlers::chat_stream_handler）、`POST /v1/chat/completions`（OpenAI 兼容代理，completions.rs）、`GET /chat/ws`（WebSocket 双向通道，ws_handler.rs，3368 行）。
  - **Run 控制**（realtime.rs:166-214）：`/chat/runs/{run_id}` GET/DELETE、`/projection`(+`/repair`)、`/stream`（SSE 重连/游标续读，run/handlers）、`/pause|resume|cancel|intents`、`/delegate`、`/delegations(/pause|/resume)`（delegation/handlers）。
  - **WebSocket/边缘**（realtime.rs:156-165, 250-257）：`GET /edge/ws`（edge_ws_handler，边缘代理注册+能力宣告+工具下行）、`/edges/status`、`/service/edges/status`；回调端点 `POST /tools/result`、`/approval/respond`、`/user-prompts/respond`、`/provider-interactions/respond`、`/agents/edge/heartbeat`、`/agents/edge`（edge_callback_handlers，4010 行）。
  - **团队/反射/能力/绑定**（realtime.rs:117-135, 215-257）：`/teams` CRUD+`/execute`+`/snapshots`（team/handlers）、`/chat/session/{id}/reflect|decision-trace`、`/runtime/capabilities`、`/agent-bindings`、`/api/v1/mcp/register-or-update`。
  - **会话域**（router_builder/sessions.rs:5-200）：`/sessions` CRUD、`/state`、`/runs`（run 树）、`/transcript`、`/turns/{turn_id}/trace`、`/devices`+`enroll|challenge|revoke|trust|events`、`/close|resume|cancel|attachments`、`/context/segments:batchGet|:upload`、`/execution-grants`、`/handoffs/{id}(/transitions|/fence|/activate)`、`/forks(/prepare|/activate|/abort)`、`/activity`、`/artifacts(/latest/{kind}|/{id}(/download))`、嵌套 `/sessions/{id}/harness(/snapshot|/history|/diff|/stream)`（feature harness）、`/replay(/compare)`、审计 `/sessions/{id}/audit/summary|turns|context-traces|tools|errors|promotions` 与跨会话 `/audit/sessions|stats|tools|promotions`（session/session_handlers.rs 4733 行 + audit_handlers）。
  - **管理域**（router_builder/admin.rs）：`/admin/register|init|audit|feedback/(stats|export)|prompts/optimize|users/(grant|revoke)-role|tokens|cleanup|config(/{key})|resources/limits/{user_id}|tool-offers/disabled|llm/trusted-domains(/{id})`、`/admin/harness/sessions`——全部经 `AdminAuthorizer::require_admin`（config_admin/admin_config.rs 头注释）。
  - **自动化域**（router_builder/automation.rs）：`/agents` CRUD、`/events(/causal-chain/{id}|/session/{id})`、`/sync/outbox/events`、`/context`（快照）、`/decisions(/{id}/audit)`、`/triggers(/{id}/fire)`、`/workflows`、`/sandbox`、`/branches(/diff|/merge|/cost-estimate)`、`/data-versioning/checkpoints|lineage|sandbox`（service_handlers/* 与 data_layer/versioning.rs）。
  - **目录域**（router_builder/catalog.rs）：`/me/models(/validate-endpoint|/{id}(/check))`、`/model-access`、`/models(/memory|/{name}(/check))`、`/skills(/status|/publish|/user/...|/{name}/info|/{id}/versions|/{name}/unpublish|/{name}/config(/validate|/{setting}|/resources))`、`/marketplace(/install|/uninstall|/upgrade|/rollback|/installed|/credentials|/quality-report|/stats/{name}|/search)`（data_layer/models.rs + skills/* + service_handlers/marketplace.rs）。
  - **运维域**（router_builder/operations.rs = harnesses+work+insights）：insights 为 `/evaluation/*`（quality/drift/gates/calibration/slo/trust-report/training-data 等 17 端点）与 `/introspection/*`（decision-trace/tool-history/drift-check/skills/context/*）、`/platform/snapshot`；work 为 `/v1/works` 全生命周期（session-bindings、branches、patch-artifacts/materializations/commits、forks、task-graph、criteria-proposals、transcript、attachments、control-operations 等，work_handlers.rs 6282 行）+ `/runs` 列表 + `/preferences` + `/resources/usage|limits`；harnesses 为 `/harnesses/templates|node-catalog|skillify/runs|runs/{id}/items|skill-drafts|publish`（product_harness_handlers）。

#### 4.7.2 AppState 组装（server/state_builder、app_state.rs）

- `AppState`（app_state.rs，1559 行）：字段即"服务目录"——`auth_service`、`session_service`、`model_service`、约 40 个 `with_*` 链式装配方法，子结构 `execution`（run_lifecycle_service、edge registry/dispatch、tool_execution_service）、`turn_persistence`（7 个事件写入器）、`admin`（8 个管理服务）、`edge_connection_pool`、`matrix_cloud_runtime`，另含 `HealthChecker`/`MemoriaHealth`/`MemoriaForwarder`。
- `build_server_state(settings)`（state_builder.rs:20）流程（builder 模式逐层叠加）：
  1. `ensure_core_schema`（MatrixOne 核心表）→ 拆分连接池：shared_pool + control_pool（`control_pool_max_connections = (total/20).clamp(0,4)`，:99，保证 auth/health 在共享池打满时仍有 lane）；
  2. `FernetTokenEncryptor::from_key`（token 加密）→ `core::build_auth_service`（state_builder/core.rs:19，DatabaseAuthService + provider_request_auth/edge_token_auth/external_providers）；
  3. `core::build_core_state`（core.rs:68）：`derive_runtime_subkey(root_secret, b"execution-grant")`（SHA256 域分离子钥，core.rs:8）→ ExecutionGrantSigner、SessionContextCoordinator/HandoffService/ForkCoordinator、CloudPlanRepository，然后一口气挂 30+ DatabaseXxxService（session/agent/event/context/decision/model/job(InMemory)/trigger/workflow(Unconfigured)/sandbox/branch/data_versioning/marketplace/replay/session_audit/skill/skill_config/mcp_registry/agent_binding/llm_trusted_domain/evaluation/introspection/reflect）；
  4. `install_turn_persistence_services`（core.rs:191）：TurnCoreEventWriter/TurnToolEventWriter/TurnHookDbWriter/TurnReflectionLessonWriter/TurnObserverWorker/TurnAuxiliaryEventWriter/TurnSessionActivityWriter；
  5. `install_admin_services`（core.rs:227，走 control_pool）+ `install_execution_services`（core.rs:266）：EdgeRegistryService、EdgeDispatchService、`build_shared_tool_execution_service`（core.rs:286，ToolExecutionService.builder() 注入 edge 池/dispatch/registry/deployment_tool_policy 的 provider_capabilities、disabled_tool_offers、provider_allowed_tools）；
  6. `runtime::build_runtime_wiring`（state_builder/runtime.rs:4）：DatabaseRunStateStore + DatabaseStateProjectionStore → `RunEngine::new`（run/engine.rs）→ `recover_active_runs()`（启动时恢复孤儿 run 并分类：paused-continuation/failed，runtime.rs:163）→ AgentProfileRegistry（orchestrator/coder/reviewer/writer 四个内置 profile，runtime.rs:217）→ DelegationTracker + AgentMailboxRouter（astra_messaging DatabaseTransport）→ MatrixCloudRuntime::attach（含 MemoriaPort 模板）→ ServerSubRunExecutor → DelegationEngine → ResourceGovernor（Database + ensure_tables）→ `AgenticRunLifecycleService::new`（run/lifecycle/mod.rs:5080）挂 mailbox/delegation/edge/workspace/skill/model/mcp/agent_binding/writers/`run_concurrency_limit`（env `ASTRA_RUN_CONCURRENCY_LIMIT`，默认 50，runtime.rs:116-119）/metrics/tool_execution_service；同时初始化 llm_provider_admission schema（fail-open 时仅告警，runtime.rs:99-114）；
  7. 派生 `artifact-signing` 子钥 → 逐项 `with_run_lifecycle_service / with_agent_profile_registry / with_delegation_engine / with_team_store / with_resource_governor / with_auxiliary_pools / with_matrix_cloud_runtime` 返回。

#### 4.7.3 Turn 执行（turn/agentic_loop、server/server_loop_host）

- **循环骨架**（本 crate 内实现，host trait + 泛型驱动）：`AgenticLoopHost` trait（turn/agentic_loop/host.rs:427）约 30 个钩子——核心是 `execute_turn(&mut self, state) -> HostTurnResult`（:524，"构建 payload → POST → 消费 SSE"）；其余如 `admit_tool_calls`、`handle_admitted_tool_calls`、`judge_turn_intent`、`judge_skill_auto_route`、`on_committed_work_task_board_update`、`memory_recall_scope`、`continuation_authority` 等。服务器实现为 `ServerAgenticLoopHost`（server/server_loop_host.rs:2530，31949 行巨型文件）+ `ServerAgenticLoopHostBuilder`（:3059，约 50 个 with_*）。
- 入口 `run_agentic_loop_with_host`（turn/agentic_loop/finalization.rs:490）：建 `UnattributedRecallRunBoundary` → `run_agentic_loop_impl`（host.rs:4318）→ 出口统一处理取消溯源（`resolve_cancellation_origin`）、级联取消子代理、SessionEnd harness 钩子、错误时 best-effort 冲刷 turn 观测事件。
- `run_agentic_loop_impl`（host.rs:4318）：`run_loop_preamble`（lifecycle.rs:3446）→ harness SessionStart（Block/Pause 直接中断）→ `while turn_index < state.max_turns`：`prepare_turn_iteration`（lifecycle.rs:3663，暂停/取消/续跑判定）→ `execute_turn_and_ingest_phase`（execution_phase.rs，19522 行——LLM 回合执行与结果摄取）→ harness PostLlmResponse → harness PreToolBatch → `execute_tool_phase`（tool_phase.rs:1883，工具批执行，含"text-only 边界被无视"的两级封锁协议 ：1929-2008）→ `complete_turn_phase`（host.rs:309）→ 终局 `finalize_and_render`（finalization.rs:623）。
- `ServerAgenticLoopHost::execute_turn`（server_loop_host.rs:11823）单回合内部（顺序，行号为实现处）：
  1. Work 图变更和解 + `hydrate_provider_canonical_transitions`（:11885，恢复门：拒绝过期 owner 的重复投递）→ 语义 Work 预检（:11894）；
  2. **模型解析** `resolve_llm_config_for_state`（:6182）：含 fallback_chain 与 `rate_limit_cooldown()` 本地冷却（:11933-12019，Wait/UseFallback/Reject 三态）；
  3. **上下文管线** `run_turn_pipeline_with_model_limits_and_session_memory`（:12136，context_pipeline_adapter.rs 桥接 astra-pipeline：系统提示、压缩分层、工具 schema 修剪的唯一事实源）→ Memoria 压缩 `compact_messages_via_memoria`（:12196，turn/cloud/memoria_compact.rs）→ `assemble_llm_messages`（:12344，turn/wire_assembly.rs）→ 粘性工具 schema/缓存标注（`stabilize/annotate_tool_schemas_for_cache`，turn/llm/context.rs）；
  4. **DB 准入** `crate::llm_provider_admission::admit_llm_provider_request`（server_loop_host.rs:12585，RPM/TPM 固定窗口 + TAT pacing，见 4.7.4）；
  5. **物理尝试循环**（:12540 `let mut result = loop`）：经 `call_llm_and_collect_*` 调用 turn/llm/client.rs，流式回调即时产出 `text_delta` 等事件；finish_reason=length 时最多一次 output-cap 探测。
- **LLM 客户端** `turn/llm/client.rs`（17206 行）：`call_llm_and_collect`（:4545）族全部汇聚到 `call_llm_and_collect_with_total_budget`（:4682）：`consolidate_system_messages_for_provider` → `build_provider_request_body_with_cache_capability`（按 provider 协议 OpenAiCompatible/AnthropicMessages/BedrockConverse/DashscopeThinking 生成 body，:620-643 协议判定）→ `PreparedProviderRequest`（不可变 wire 回执+指纹，:553）→ `llm_request_url` → 重试环（`LLM_MAX_RETRIES`、指数退避、`stream_idle_timeout` 前后双档，:1454-1470）：`observer.begin_attempt`（经 turn/llm/durable.rs 写**持久推理台账**，"route/invocation admission 先于任何 provider I/O"）→ `global_llm_client()`（:639 静态 reqwest::Client）`client.post(url)` + `apply_provider_auth`，`tokio::select! { wait_llm_cancel, timeout(request_deadline, send) }`（:4982）→ 成功后按协议分派：Bedrock 走 `crate::turn::bedrock::transport::collect_bedrock_stream_for_wire`（:5086，AWS eventstream 解码见 turn/bedrock/eventstream.rs），其余消费标准 SSE；取消/超时被分类为 Cancelled/ProviderDeadline/StreamIdle 并以 `finish_observed_provider_delivery_unknown` 落账（:4989-4995）。
- **headless 工具管线** turn/headless_tool_pipeline.rs（4827 行）+ execute/policy/record 子模块：thin-client 驱动的无头工具执行记录与策略；turn/agentic/* 提供 tool_interception（admit_tool_calls 共享准入，:489 默认实现）、delegate_interception（spawn 委派拦截）、turn_intent、adaptive_runtime 等回合级横切。

#### 4.7.4 Provider 准入（llm_provider_admission.rs、server/model_execution_admission.rs）

- `admit_llm_provider_request(pool, provider, model, estimated_tokens)`（llm_provider_admission.rs:559）：读 env 配置（`ASTRA_LLM_PROVIDER_ADMISSION_MODE`：disabled / db_fixed_window；RPM/TPM 限值 env），db_fixed_window 模式在 MatrixOne 两张表（`llm_provider_admission_windows` 固定窗口计数、`llm_provider_admission_pacing` TAT 起搏，:44-78 DDL）上做原子 CAS 计数；被拒时返回带 retry_after 的 ClassifiedError；DB 故障按 `fail_open` 决定放行/拒绝（handle_admission_error，:650）。校准指标（estimated vs actual tokens）单独记录（:457）。每次 LLM 物理请求前调用（server_loop_host.rs:12585），是防雪崩的核心闸门。
- `server/model_execution_admission.rs`（307 行）：请求级模型执行准入（AdmittedModelExecution，与 astra-services 的 Offering 治理对接）；`provider_runtime_context.rs`（613 行）在 chat 请求进入时注入有效 runtime context；`llm_trusted_domains_handlers.rs` 管理 provider 出站可信域白名单（SSRF 防护面）。

#### 4.7.5 能力注册（capability_registry、tool_registry、provider/）

- `provider/` 抽象（mod.rs:13 导出）：`CapabilityProvider` trait（traits.rs:143：kind/capabilities/health_check/execute/priority/isolation_level/storage_accessible）+ `ToolRequest/ToolResult/ProviderError`（traits.rs:20-82）；三个实现：`server_builtin.rs`（服务端内建工具，经 `ServerToolRuntime::execute_local_tool` 委托给 RuntimeToolExecutor，traits.rs:126）、`edge_connection.rs`（边缘远端执行）、`sandbox_runner.rs`（沙箱）。
- `capability_registry.rs`（901 行）：注册 provider 并按 capability/storage/isolation/priority 解析最优路由——中央工具路由机制；`capability_endpoint_pool.rs`：每 endpoint URL 的并发 RPC 信号量。
- `tool_registry/`（registry.rs 587 行）：包装 astra-runtime-env 的 `ToolRegistry`（内建 bash/read_file/write_file/git 等）与 tool surface 投影；`server/tool_binding_projection.rs`（1791 行）按 agent-binding 过滤出 provider 可见 schema；`capabilities.rs`（1343 行）统一 Web/CLI 回合能力目录（工具 schema + skill manifest，"边界不是 web vs cli，而是执行发生在哪"）。
- `server/tool_admission.rs`（1452 行）：CapacityProvider 声明与准入（provider_capabilities/provider_allowed_tools/disabled_tool_offers 三态策略），管理端 `/admin/tool-offers/disabled` 实时生效（ToolExecutionService 持有 RwLock 句柄，tool_execution_service.rs:259-267）。

#### 4.7.6 数据层（data_layer、storage、tool_database_snapshots）

- `data_layer/storage.rs`（761 行）：turn 事件持久化函数族——`ensure_core_schema`、`insert_core_turn_event`、`insert_tool_turn_event`、`insert_turn_decision_audit`、`insert_turn_skill_selection`、`resolve_active_skill_versions`、`update_snapshot_llm_ids`（lib.rs:52-56 再导出）；MatrixOne 方言适配（`matrixone_statement_with_null_shape`）。
- `data_layer/models.rs`（704 行）：`/models`、`/me/models` 全部 HTTP handler（模型 CRUD/校验/check/memory model），委托 astra_services::models。
- `data_layer/versioning.rs`（111 行）：数据版本化 checkpoint/lineage handler。
- `storage/mod.rs`（50 行）：沙箱/边缘工作区存储类型（MountType 等）。
- 持久化路径上的其它关键件：`server/run/lifecycle/persistence.rs`（6193 行，run 终态 CAS/事件 delta 落库）、`turn/canonical_commit.rs`（canonical 消息提交）、`server/tool_invocation_runtime.rs`（2598 行，durable invocation ledger 的运行时适配与 ToolResult→typed outcome 投影）、`turn/llm/exchange_capture.rs`（930 行，按 session 元数据开关的完整请求/响应捕获入库）。

#### 4.7.7 观测（observability、self_model/introspection、request_trace）

- `observability/`（mod.rs 12 行注释）：把 M1 上下文组装遥测 / M2 决策解释器 / M3 RuntimeConfig / M5 用户画像 / M6 自适应信号挂进 agentic loop 生命周期；hub.rs（500 行）= ObservabilityHub（journal writer + user profile 聚合），session.rs（560 行）= ObservabilitySession（每会话上下文 trace 信号），types.rs = 共享类型。
- `self_model/model.rs`（2251 行）：SelfModel 只读快照——聚合 ObservabilitySession/ToolHealthTracker/RuntimeConfig/反馈信号为"agent 对自身状态的统一视图"，用于动态系统提示段与 `get_agent_info`；`self_model/introspection.rs`（224 行）：`/introspection/*` HTTP handler，类型/trait/DB 实现在 astra_services::introspection。
- tracing/OTLP：`astra_logging::init_from_env`（serve 内），target 命名规范 `astra_runtime::*`；`request_trace.rs`（342 行）中间件给 4xx/5xx JSON 错误体补 request_id；`server/interaction_metrics.rs`、`meta_handlers::publish_model_request_metrics`（serve 每 15s 从 DB 聚合刷新 /metrics）。

#### 4.7.8 其他模块速览

- **orchestration/**：spawner.rs（13465 行）DynamicAgentSpawner——LLM 运行时动态 spawn 子代理（前缀捕获、fork 缓存、取消级联）；agent_tool.rs（5968 行）合并的 `agent` 工具（spawn/get_result 契约，CLI/Server 共用）；ProgressBroadcaster 进度扇出；fork_cache_probe fork 探测。
- **server/delegation/**：engine.rs（9867 行）DelegationEngine——多代理子 run 派发（深度限制、父子追踪、CheckpointGate/DefaultQualityGate/VerificationGate 质量门，lib.rs:239-242 导出）；handlers.rs 为 `/chat/runs/{id}/delegate` HTTP 面。
- **server/team/**：orchestrator.rs（1703 行）4 阶段（Prepare→…）把 `/teams/{name}/execute` 桥到 DelegationEngine（worktree、durable run）。
- **server/run/**：engine.rs（8847 行）RunEngine——durable run 的权威（状态/重放/列表/重启恢复、owner lease 心跳与 execution authority 确认）；handlers.rs（2355 行）run HTTP+SSE；binding_resolution.rs / cloud_workspace_provisioning.rs / workspace_provisioning.rs 执行绑定与工作区供给；lifecycle/ 见 4.7.3 与第 7 章调用链。
- **server/edge/**：edge_ws_handler.rs（1920 行）边缘 WS 主循环；edge_callback_handlers.rs（4010 行）工具结果/审批/用户追问/provider 交互四类回调（durable ledger 对账）。
- **server/runtime_mcp.rs**（2611 行）：请求级 MCP wiring——chat 请求携带的 MCP endpoint+凭据仅驻内存发现工具。
- **session_memory/**：service.rs（3376 行）MemoryExtractionService——每 turn 一个统一 L1 markdown 工件写 Memoria（session-memory 约定）；runner.rs（3610 行）后台 worker；gate/health/activity 门控与冷却。
- **skills/**：registry.rs（1636 行）统一 skill 注册（优先级 local > bundled > database > mcp > plugin，含健康排序 rank_multiplier）；watcher.rs（notify 文件监听热载）；catalog/handlers。
- **learning/**：extractor.rs（SessionSummary→Vec<NewLesson> 纯映射）、synthesizer.rs（Memoria L3 回流提示词）、checkpoint.rs（用户纠正/失速恢复/计划完成的增量提取点）。
- **evaluation/handlers.rs**（197 行）：17 个 `/evaluation/*` handler，逻辑在 astra_services::evaluation。
- **config_admin/**：admin_config.rs（`/admin/config` 键值，需 astra_admin 角色）、guardrail.rs（auto-reflection 阈值的滚动统计自适应：有界 ±1、钳位、迟滞）、skill.rs（per-skill 配置/资源绑定 handler）。
- **memory_hooks/**：relevance.rs（695 行）用最便宜 selector 模型过滤召回记忆降噪；inference.rs 两个推理客户端（Direct/Durable）。
- **prompts/**：system.rs（3077 行）集中全部系统提示词（SYSTEM_PROMPT_BASE 等）；context.rs（1066 行）Unicode 感知 token 估算（CJK 3/2 字符比、JSON ~2B/token）。
- **deployment/mod.rs**（389 行）：部署 profile（可用执行后端及配置，YAML 装载）。
- **matrix_cloud_runtime.rs**（454 行）：MatrixCloudRuntime——SharedPool + journal 摄取 + sync 持久化 + 关停追踪，AppState 与 CLI 共用 Arc 附件。
- **messaging/mod.rs**：astra-messaging 再导出（AgentMailboxRouter/DatabaseTransport 邮箱路由）。
- **capacity_model.rs**（570 行）：多 pod 扩容的容量方程与 rollout 门（把"运行 admission 信号量/工具信号量/endpoint RPC 拒绝/限流熔断"四类机制统一成可评估数学模型）。
- **服务面薄层**：service_handlers/*（agents/events/context/decisions/triggers/sandbox/branches/marketplace/replay/workflows，每文件几十到三百行，纯 astra_services 转发）；bash_intent.rs（bash 读意图分类统一）；auto_invoke_handler.rs（AutoInvokeGate 与诊断 skill 的生产胶水）。

### 4.8 交互层（astra-cli / astra-edge）

astra-cli 是 workspace 的门面 crate：单个 `astra` 二进制（`src/main.rs` → `astra_cli::entrypoint::run()`）同时承载 clap 子命令、ratatui TUI、`astra serve`（HTTP/stdio app-server）与 mock 测试二进制。它不直接访问数据库，一切云端交互经 `astra-thin-client`（reqwest 封装）完成；本地工具执行由 `edge_tools::ToolExecutor` 在 CLI 进程内完成。astra-edge 是另一个独立二进制：WebSocket 长连接的 "User Runner"，在用户机器上接收 Server 下发的工具调用并本地执行。

#### 4.8.1 入口与 CLI 子命令（entrypoint、admin_cli、cli/）

**进程入口** `src/main.rs:1-24`：
```rust
fn main() -> Result<(), Box<dyn std::error::Error>> {
    if let Some(exit_code) = astra_sandbox::run_invocation_supervisor_if_requested() { std::process::exit(exit_code); }
    if astra_core::build_info::write_json_if_requested()? { return Ok(()); }
    astra_cli::cli::stream::output_sink::configure_process_output_signals()?;   // SIGPIPE 策略先于一切线程
    let process_capture = ProductionProcessCaptureGuard::from_env(ProductionProcessRole::Cli)?;
    let exit_code = astra_cli::entrypoint::run();
    ...
    let exit_code = output_sink::resolved_exit_code(exit_code);                  // 管道关闭转 141/3
    std::process::exit(exit_code);
}
```
main 只做四件事：沙箱 invocation supervisor 短路、build-info 短路、进程级输出信号配置（output_sink.rs:35-48 在 Unix 上重设 `SIG_IGN(SIGPIPE)`）、再调 `entrypoint::run()`。

**`entrypoint::run()`**（entrypoint.rs:115-123）构建 process runtime 后 `block_on(run_async())`。`run_async()`（entrypoint.rs:125-477）是 CLI 总装线：
1. `Cli::try_parse()`（entrypoint.rs:136），clap 错误经 output_sink 输出（help 走 stdout records，错误走 stderr）；
2. `--settings` 内联 JSON/文件 解析为 `RuntimeConfig` overlay 并延迟到首次 `RuntimeConfig::load()` 前安装（entrypoint.rs:170-217 `set_cli_overlay`，注释明确"累积与安装贴近，防止读到旧配置"）；trace 三标志经 `apply_trace_cli_overlay`（entrypoint.rs:61-76）；
3. `resolve_api_url`（--api-url > ASTRA_API_URL > 配置文件）→ `astra_thin_client::ThinClient::new(&base, None)`（entrypoint.rs:222-248）；
4. `configure_cli_profile_identity` 绑定本地 profile/account 身份（entrypoint.rs:280-292，按子命令的 `profile_identity_admission` 决定是否强制绑定账号）；
5. `CliContext::from_launch_options`（cli_context.rs）收集 allowed/disallowed tools、--add-dir、--session-id、--yes 等启动上下文；`--yes` 时 unsafe set_var `ASTRA_CLI_AUTO_APPROVE=1`（entrypoint.rs:313-317）；
6. `--print` 无头单发（entrypoint.rs:387-405 → `command_router::run_print_mode`）；`-c/-r` 恢复会话（entrypoint.rs:409-457，云端 `validated_resumable_last_session_id` 优先、本地 credentials 的 last_session_id 兜底 → `interactive_chat::run_interactive_chat`）；
7. 其余交给 `execute_cli_command`（entrypoint.rs:459-476）。

**命令分发** `cli/command_router.rs`：`execute_cli_command`（:752-776）是对 `execute_cli_command_impl`（:858）的 `Box::pin` 包装——注释说明巨型分发 future 若内联会撑爆 Tokio 测试线程栈。`execute_cli_command_impl` 的 `match command`（:868）覆盖全部子命令（行号见 grep）：`None|Interactive` → `run_interactive_chat`（:870-883）；`Serve`（:885-906，Http → `start_http_server`（:80-93 调 `astra_runtime::serve`）、Stdio → `app_server::run_stdio_app_server`（app_server.rs:160，Codex 风格 JSON-RPC 行协议））；`Admin`（:908）；`Message` 外部简写（:915）；`Chat`（:1353）；`Replay`（:1960）；`Session List/Show/Close/Cancel/Delete/Capture`（:1985-2110，session_id 先经 `validate_cli_session_id` 防路径穿越）；`SelfInspect`（:2111）；`Model List/Add/Show/Probe/Delete`（:2118-2287，`find_personal_model_id`（:778）查 `/me/models`，inquire 交互式录入 provider model id/alias）；`Skill`（:2288-2339）；`Audit`（:2340-2429）；`Journal Digest/Tree/Diff`（:2430-2444）；`Mcp`（:2446）；`Completion`（:2452）；`Doctor`（:2461）；`Config`（:2467）。

**Command 枚举**（cli/cli_config/cli_args.rs:152-242）共 33 个变体：Interactive(默认)、Serve、Register、Login、Whoami、Refresh、Logout、Health、Chat、Replay、Session、SelfInspect、Model、Skill、Audit、Journal、Mcp、Config、Admin、Completion、Doctor、Team、Work、Memory、Review、Grep、Diff、Permissions、Debug、Bug、Agent、Messaging、Context、Message(allow_external_subcommands)。`run_print_mode`（command_router.rs:2723）实现 `-p` 无头路径：stdin/命令词取消息 → token → `resolve_one_shot_session_routing` + 执行租约（`RequestSessionExecutionLease`）→ `PermissionManager::with_load_policy(HeadlessSafe)`（剥除项目 allow 规则，注释引 issue #326）→ `execute_basic_cli_turn`（:2855）→ 按 output_format（text/stream-json）输出。

**admin_cli/**（7 文件）是 `astra admin` 的自治子系统：`run_from_env`/`run`（mod.rs）、AdminArgs+Command（cli_args.rs）、guided setup 向导（setup.rs，秘密不进命令行参数）、交互式管理 REPL（interactive.rs）、prompt 输入（input.rs）、HTTP 错误映射（http_helpers.rs）、api url 解析（config.rs）。

#### 4.8.2 聊天与流式（chat_stream/sse_loop、turn、stream、slash）

**分层**：`cli/turn/` 是回合状态机（auth retry → stream → settlement → commit → report → post-commit），`cli/chat_stream/` 是单次 SSE 循环适配器，`cli/stream/` 是渲染/输出底座，`cli/slash/` 是 24 个斜杠命令。

- 交互回合入口 `turn_entry::handle_chat_input_with_ui`（turn_entry.rs:245）：`classify_shell_passthrough` 处理 `!cmd` shell 直通（:252-282）→ `ensure_interactive_session_identity`（:293）→ `acquire_interactive_turn_admission`（:298）→ `run_chat_turn`（:146，Box 包装 `execute_stream_turn`）→ `TurnDispatch` 结算。
- `turn_stream_runner::execute_stream_turn`（turn_stream_runner.rs:58-77）：准备 cancel token / incremental state / LocalRunControl → `build_turn_stream_params`（:106）→ `await_stream_with_interrupts` → 返回 `TurnAttempt::Completed|Interrupted`（用户取消与正常完成共用同一持久化路径）。
- `chat_stream::stream_chat_sse`（sse_loop/mod.rs:208-1380）单函数 ~1170 行，见 CH6 深读。核心：模型选择强制（无 offering_id/context_window 拒绝开局，:234-302）→ 构建 `edge_tools::ToolExecutor`（:356-459，接 file journal、git stash/commit/worktree journal、bg task、spawn context 等十余个 with_*）→ 组装 `CliServerAdmissionHost`（server_admission_host.rs）+ `AgenticLoopState`（:696-1094）→ `run_agentic_loop_with_host(&mut host, &mut state)`（:1129，循环本体在 astra-runtime）→ 失败/成功两侧 finalize、`build_stream_result`（agentic_sse_loop.rs:284）。
- **每轮 SSE 请求**由 host 的 `execute_turn`（server_admission_host.rs:649-909）发起：权限模式变更、plan 模式 volatile 注入、restricted_tools 三层合并（session 持久 + 交互模式作用域 + 请求 allowlist）→ 宏 `fetch_turn_sse!`（:821-907）调 `fetch_chat_turn_sse`。
- `fetch_chat_turn_sse`（agentic_loop_turn.rs:1673）：`chat_turn_post_payload_after_prepare`（:1591-1671）→ `prepare_chat_turn_payload`（:674，上下文组装、技能选择、schema 剪枝）→ `server_loop_admission_payload_with_execution_time_budget`（:527）→ **`api.post_developer_loop_retry_429(token, &server_payload, CHAT_TURN_POST_MAX_RETRIES, quiet)`**（:1652；thin-client client.rs:1230，POST `paths::CHAT_STREAM` = `/chat/stream`，传输层 429 重试不暴露为独立 exchange）→ `consume_turn_sse`（:1878；实现于 stream_render.rs:7858）。
- `consume_turn_sse` 把 reqwest 字节流交给 runtime 的 `consume_sse_stream_cancellable`，以 `CliSseStreamHost::from_edge_ctx_with_auth`（stream_render.rs:1427）为回调：`on_accepted_sse_event`（:3776）分发 JSON 事件；token 增量经 `push_text`（:1756）/markdown 渲染器；工具事件 → `execute_tool`（:4139）/`execute_tools_batch`（:5296）/`execute_transactional_batch`（:2757）；edge 工具结果经 `finish_edge_tool`（:1855）→ `post_tool_result_with_auth_retry`（:1628-1664，401 时 `refresh_edge_token_after_401` 刷新后重试一次）→ `api.post_tool_result`（client.rs:1837）；审批 → `resolve_approval`（:5121）/`resolve_approvals_batch`（:5192）→ `post_approval_with_auth_retry`（:1666）→ `api.post_approval`（client.rs:1886）。
- **审批交互**：`resolve_cloud_approval_via_tui`（stream_render.rs:3365-3464）优先级：`exit_plan_mode` 走 `resolve_remote_plan_review` 四选一（:3379-3391）→ `PermissionManager::preflight_cloud_approval_decision`（模式/Bypass/会话内 allow 规则可直接裁决，:3393-3402）→ 无 TUI sink 则**自动拒绝**（:3404-3410，fail-closed）→ 否则 oneshot + `ApprovalRequest`（含 risk_tags、batch_group_key、ApprovalRequestKey 等 metadata）经 `enqueue_interactive_request` 送 TUI（:3412-3460）。
- TUI 侧在 `run_tui_session` 建 `approval_tx/approval_rx` 等三条 mpsc 通道（event_loop.rs:5028-5042），select 分支 `approval_rx.recv()`（event_loop.rs:7284-7330）把请求 `bottom_pane.enqueue_approval*` 入队，由 `tui/approval/queue.rs` 的 `ApprovalQueue`（非阻塞队列，monotonic id）+ `history_cell/approval.rs` 内联审批卡 + `approval/button_row.rs` 按钮行渲染，用户选择后经 oneshot 回传 `ApprovalResponse`。
- **stream-json 机读协议**：`StreamJsonEmitter`（stream/stream_json.rs）逐行立即写 stdout，`--stream-events` 另有 `stream_events_writer.rs`（JSONL 到显式文件，stderr 永不污染协议）。
- **slash**：`handle_slash_command`（slash/slash_router.rs:72）是 TUI 之外（headless/测试）的回退路由；TUI 内由 `tui/slash_dispatch.rs` 原生处理、`command_registry.rs` 提供命令元数据单一来源。24 个 slash_*.rs 一一对应 /model /agent /bug /cache /config /debug /health /info /inspect /mcp /memory /messaging /plan /profile /session /skill /state /stats /sync /team /telemetry /tools /account /sync。

#### 4.8.3 本地执行（edge_tools）

`edge_tools.rs`（顶层）定义 `ToolExecutor` 聚合类型与工具目录：bash、read_file(outline 模式)、write_file、str_replace(模糊匹配)、list_dir、grep、glob、git、github、web_fetch、mo_query。`edge_tools/` 目录 25 文件按工具族拆分：
- 文件族：fs.rs（读写/目录）、file_state.rs（mtime 追踪防覆盖用户编辑+内容缓存）、notebook_edit.rs（Jupyter 单元格编辑）、worktree.rs（git worktree 会话 enter/exit）；
- shell/git 族：shell.rs（shell_escape、check_dangerous_command）、git_gix.rs（委托 astra_tools::git_gix，保留 CLI journal 包装）、github.rs（gh 集成）；
- 代码智能族：code_analysis.rs（symbols/find_definition/rename 等 12 工具，tree-sitter）、lsp_tools.rs + lsp_stdio_session.rs（Content-Length 帧 stdio LSP 客户端）、passive_lsp.rs（rust-analyzer/ts-language-server opt-in 常驻）；
- 代理协作族：agent_spawning.rs（spawn/get_result 桥接 astra_runtime::orchestration）、agent_messaging.rs（agent.send_message 邮箱上下文）、ask_user.rs（ask_user 参数解析）、context_sharing.rs/context_tools.rs（share_context/query_context）、session_state.rs（会话状态回滚 journal）；
- 外部服务族：mcp_dispatch.rs（MCP 路由+自动重连）、memoria.rs（记忆服务 HTTP 客户端+熔断）、mo_tools.rs（MatrixOne SQL+回滚）、github.rs、tool_search.rs（静态目录+MCP 动态 schema 联合检索）、config_tool.rs、diagnose.rs、self_mod_tools.rs、code_analysis。

关键机制：`ToolExecutor::execute_with_metadata`（&self + Sync，支持并行工具调用）在 stream_render.rs:5515/6096 被包装为 `execute_with_metadata_responsive`（stream_render.rs:7593，bash 等可流式输出进度的工具走 spawn_blocking + 进度 sink）；沙箱拒绝统一经 `sandbox_retry.rs` 重走审批/扩沙箱；`tool_safety_guard.rs` 提供 run-chain 步数上限（MAX_RUN_CHAIN_STEPS=16）与 SQL 安全检查重导出。

#### 4.8.4 TUI（tui/ 组件族——组件清单+代表组件解析）

tui/ 共 121 个生产文件（不含 snapshots/tests），架构按 `docs/design/tui-refactor.md`：**HistoryCell trait + TurnEvent schema + 单 ChatWidget 路由器**。

- **外层**：`event_loop.rs`（4902 行的 `run_tui_session`）——业务 bootstrap 在进 TUI 前完成（auth、state、startup trace，:4927-4959）；终端接管分两段（`StartupTerminal::begin` → `TerminalGuard::init`，失败时回收 heartbeat/spawner，:4961-4994）；建 stream_bridge 通道 + approval/ask_user/plan_review 三通道（:5022-5042）；`tokio::select!` 覆盖键盘、draw tick、审批、turn 中 app 事件。`can_run_tui()`（:4895）做 TTY 门禁。
- **ChatWidget**（chat_widget/mod.rs）：唯一事件路由器，`handle_event` 一个大 match（设计注释明确否决 reducer 抽象）。拥有 `history: Vec<Arc<dyn HistoryCell>>` + `active_cell`。`bridge.rs` 把传输层 `TuiAppEvent` 翻译为视图层 `AppEvent`；`resume.rs::load`（:12）从 canonical journal 重建 scrollback；`turn_driver.rs` 为 cfg(test) 端到端 harness。
- **HistoryCell 族**（history_cell/）：user/assistant/reasoning/system/tool/task/approval/turn_summary 九种 cell；`turn_event.rs` 定义紧凑重建 payload（"TUI 是投影，不是第二持久层"）。
- **BottomPane 族**（bottom_pane/ 26 文件）：composer(textarea+paste_burst 粘贴突发检测)、plan_review_view（exit_plan_mode 四选一）、login_view、session_picker_view、config_edit_view（两列 list+detail）、in_flight_agents_view（Ctrl+G 代理导航）、background_task_view（4 文件）、transcript/root_transcript/agent_transcript、context_panel_view、help/info/list_selection/skill_popup/ask_user/timeline/worktrees/task_detail 等子视图 + `view.rs` 的 `BottomPaneViewAction` 语义结果。
- **审批代表组件**：`approval/queue.rs`（ApprovalQueue：pending 队列、focus 模型、monotonic id、respond_*），`approval/button_row.rs`（纯逻辑按钮行，多队列时前插 "Deny all/Allow all"），`history_cell/approval.rs`（composer 上方内联审批卡，Cursor/Copilot 视觉语言）。
- **timeline 代表组件**：`timeline/model.rs` 纯只读模型（每 turn 的 token/tool/时长累计，镜像 journal ToolCallRecord），`timeline/view.rs` 双栏（左列表右快照），`bottom_pane/timeline_view.rs` 为 BottomPaneView 包装。
- **渲染底座**：`draw.rs`（ActiveView 优先级解析器 + do_draw）、`render/`（highlight/line_utils/renderable——FlexRenderable 移植自 Codex MIT）、`custom_terminal.rs`（派生自 ratatui::Terminal 的本地 Terminal）、`theme.rs`/`terminal_palette.rs`/`color.rs`、`markdown.rs`/`markdown_render.rs`、`wrapping.rs`（URL 感知换行）、`diff_render.rs`、`shimmer.rs`（动画时间原点）、`frame_rate_limiter.rs`/`frame_requester.rs`。
- **观察者/投影**：plan_task_observer（Work Task Graph 有界只读观察）、server_agent_observer（服务端 run 树）、local_agent_journal/local_agent_snapshot（本地代理持久索引与 50ms 共享快照）、work_board_projection、task_board_observer/task_board_events、agent_run_projection、bg_task_proxy/bg_task_rendering、background_tasks（后台 shell 任务注册表）。
- **弹出菜单**：slash_menu（纯逻辑 menu + popup widget + mod 的 `score_token` 模糊打分单一来源，经 tui/mod.rs:82 `score_slash_token` 供 CLI 层复用）、mention_menu（@文件补全，provider 抽象便于测试注入）、session_picker（discovery/view）。
- 其余：keymap.rs（AppAction/AppKeymap）、event.rs（TuiEventStream）、external_editor.rs（$EDITOR）、file_writer.rs（有序非阻塞文件效果）、insert_history.rs、plan_mode.rs、slash_dispatch.rs、status_indicator.rs、status_line/（line 纯组合 + context_bar 上下文容量轨）、stream_bridge.rs（SSE→TuiAppEvent 通道）、terminal.rs/terminal_startup.rs、ui_adapter.rs、task_status.rs、task_list/、worktrees/、agent_view.rs、board_pin.rs（任务板可见性状态机）、background_shortcut.rs、config_edit_router.rs、app_event.rs。

#### 4.8.5 User Runner（astra-edge）

5 文件，独立二进制。`main()`（main.rs:1361-1463）：ProductionProcessCaptureGuard(Role::Edge) → astra_logging init → `Args::parse`（--server-url/--token/--profile/--workspace-dir/--edge-id/--reconnect，:64-92）→ `resolve_config`（:385-487）→ `token_renewal::spawn_renewal_task`（:1396）→ 指数退避+jitter 重连循环（:1401-1451，1s 起、上限 60s，jitter∈[0.5x,1.5x)）。

**连接与会话** `run_edge_connection`（:899-1357）：
1. 代理选择（:907-929）：wss→https_proxy 优先；loopback 跳过；NO_PROXY 域后缀匹配（host_matches_no_proxy :669）；自定义 HTTP CONNECT 隧道 `connect_via_proxy`（:799-883，含 Basic Proxy-Authorization percent-decode 与隧道内 TLS 握手）。
2. `edge_ws_request` 注入 Bearer 头（:885-895）→ `connect_async` 或代理路径 → split 为 read/write。
3. **认证**：发送 `EdgeClientMessage::Auth{edge_agent_id, interaction_api_major, hostname, workspace_dir, capabilities}`（:971-983），capabilities 由 `edge_runtime_environment_capabilities`（:516-534）生成 RunBinding 广告并声明 `RUNTIME_PROCESS_AUTHORIZATION_V1_CAPABILITY`；等待 `AuthOk`（EDGE_AUTH_TIMEOUT_SECS），校验 interaction_api_major（不符→PermanentEdgeConnectionError 不再重连，:117-126），`token_manager.mark_proven(snapshot)` 持久化"已验证"令牌（:992-1008）。
4. `DefaultToolExecutor::for_workspace`（:1041-1047）+ 完成通道 mpsc(1024) + `EdgeExecutionBudget`（Semaphore(128) 并发上限，:44-61）+ `EdgeInvocationTracker`（request_id→generation+CancellationToken，:205-254）+ `EdgeInvocationJournal` 打开并**先重放 pending_results**（:1056-1080，断线重连首先回放未确认结果）。
5. 心跳 `tokio::time::interval(EDGE_HEARTBEAT_INTERVAL_SECS)`（:1083）。
6. **主 select 循环**（:1091-1352）：
   - `read.next()`：`decode_edge_server_message`（:173-198，对 edge_tool_request 做**未知字段拒绝**的严格解码）→ `ToolRequest`：先 `valid_runtime_process_authorization` fail-closed 校验（:160-171/:1111-1128）→ `journal.prepare`（幂等三态：`Replay`（已有结果→直接回放）/`Active`（重复投递并入在跑调用）/`Full|WalFull`（饱和拒绝）/`Execute`（放行），:1130-1205）→ `invocations.begin` → `tokio::spawn` 执行（:1217-1259）：有 runtime_process_authorization 时走 `runtime_process_authorization::execute_bash`（注入 `MOI_RUNTIME_AUTHORIZATION` env），否则 `ToolExecutor::execute_with_cancel`；`tokio::select!{ cancel.cancelled() → cancelled_tool_result, timeout(timeout_secs) → 超时 ToolResult::error }`。
   - `completed_rx.recv()`（:1310-1343）：`invocations.finish_if_current`（代际校验，过期完成事件丢弃）→ `journal.complete`（**结果先落盘**进 durable outbox）→ 从 pending_results 取回并回发 `client_message(request_id, identity, delivery_generation)`。
   - `ToolCancel`：按 running_execution_generation 匹配后 `cancel_if_current`（:1264-1278）；`ToolResultAck`：`journal.acknowledge`（:1279-1287，确认后才从 outbox 删除）；`Closing` 退出。
   - `heartbeat.tick()`：发 `Ping{}`，失败即断开（:1344-1350）。

**令牌体系**：`token_manager.rs` 单锁状态机（in-memory current / token file / one-shot fallback / 持久化脏标记，四类迁移全在锁内，令牌文件按 (iat,exp) 生成序绝不回退）；`token_renewal.rs` 针对 `moi-user-token-v1` 30 天注册令牌自续期（ASTRA_TOKEN_RENEW_URL，默认阈值 7 天，6 小时检查，transient 重试 30/60/120s）；`invocation_journal.rs` 是 WAL+状态双文件的持久调用日志（v3 格式，MAX_RECORDS=1024、结果≤256KB、WAL 256MB，压缩阈值 4096 条/8MB）。**隐性约定**：非 MOI 显式凭据与 MOI 令牌文件是不同身份域，绝不互为 fallback（resolve_config :402-474）。

### 4.9 Web 控制台与 TypeScript SDK（web/、packages/sdk）

#### 4.9.1 技术栈与应用骨架（Next.js App Router、认证流）

**技术栈（事实，`web/package.json:16-68`）**：Next.js `^16.3.4`（App Router）+ React `^19.2.7` + TypeScript `^5.8.3`；UI 用 Tailwind CSS `^3.4.17` + `@radix-ui/*`（dialog/dropdown-menu/popover/scroll-area/slot/tooltip）+ `@floating-ui/*` + `cmdk`（命令面板）+ `lucide-react`（图标）+ `@xyflow/react`（Work 任务图可视化）；消息渲染用 `react-markdown` + `rehype-highlight` + `rehype-katex`/`remark-math`/`remark-gfm`（代码高亮 + 数学公式）；表单校验 `zod ^4.5.4`；日期 `date-fns`。测试：vitest 4（jsdom）+ Playwright。SDK 通过 `"@astra/sdk": "file:../packages/sdk"` 注入。

**构建骨架**：
- `web/next.config.ts:5-11` 在服务端进程启动时向 `no_proxy/NO_PROXY` 注入 `localhost,127.0.0.1`，防止服务端 fetch 走 HTTP 代理导致连不上本地后端（与 `playwright.config.ts:5-15` 的同类防御呼应——这是一处隐性约定/坑）；`distDir` 可由 `ASTRA_NEXT_DIST_DIR` 覆盖；`outputFileTracingRoot` 指向仓库根（因为依赖了 monorepo 内的 SDK）。
- 根布局 `web/app/layout.tsx:9-19` 仅输出 `<html><body>`；真正的应用壳在路由组 `(workspace)/layout.tsx:5-12`：服务端 `getCurrentUser()`，未登录直接裸渲染 children（页面自身决定 404/落地页），登录则包进 `AppShell`（侧边栏 + 搜索 + Toast Provider，`web/components/app/app-shell.tsx:32`）。

**页面路由清单**（(workspace) 路由组）：`/`（落地/首页）、`/chats`、`/chats/[chatId]`、`/projects`、`/projects/new`、`/projects/[projectId]`、`/projects/[projectId]/chats/[chatId]`、`/works`、`/works/[workId]`、`/now`、`/harnesses`、`/overview`（重定向 `/`）、`/artifacts` 与 `/customize`（占位 EmptyState）；登录/注册在路由组外（`/login`、`/register`，不自带侧栏）。

**认证流（JWT 双令牌 + httpOnly Cookie，全部经由 Next 服务端代理）**：
1. **登录**：`web/app/api/runtime-auth/login/route.ts:58-92` 调 `runtimeLogin`（`web/lib/auth/runtime-auth-client.ts:195`，POST 后端 `/auth/login`，用 `WebRuntimeClient.fetchResponse(auth:"none")` 发请求），成功后把 `astra_api_url` / `astra_access_token` / `astra_refresh_token` 三枚 httpOnly+sameSite=lax cookie 写回浏览器，并删除 `astra_demo_mode`。另有等价的 Server Action 路径 `loginAction/registerAction`（`web/lib/auth/actions.ts:50/72`，cookie maxAge 1 年、生产环境 secure）。
2. **会话识别**：服务端组件/route handler 通过 `getCurrentUser()`（`actions.ts:134-159`）读 cookie → `runtimeMe`（GET `/auth/me`）；遇 401 自动用 refresh token 换新（`refreshTokenAction`）后重试一次。`getRuntimeConfig()`（`web/lib/runtime-config.ts:41-105`）统一解析配置：优先级 cookie > `ASTRA_API_URL`/`ASTRA_ACCESS_TOKEN` 环境变量 > 默认 `http://localhost:17001`；`ASTRA_WEB_DEMO=true` 或 demo cookie 进入 demo 模式（只读展示）。
3. **边缘中间件**：`web/proxy.ts`（Next `middleware`）对非公开路径（公开页 `/`、`/login`、`/register`；公开 API `/api/runtime-config`、`/api/runtime-auth/*`）检查 `astra_access_token`/`astra_refresh_token` cookie 是否存在（`hasAuthCredential`，proxy.ts:31），否则重定向登录——只判存在性，不验签（验签在后端）。
4. **API 鉴权**：route handler 统一先 `requireRuntimeUser()`（`web/lib/api/auth-guard.ts:13-26`，无用户返回 401 `AUTH_REQUIRED`）或 `requireRuntimeAuth()`（auth-guard.ts:5-11，要求 live 模式且有 access token）。转发后端时 `WebRuntimeClient` 附加 `Authorization: Bearer <jwt>` 与 `X-User-Id`（从 JWT `sub` 解出，`web/lib/runtime-client/server.ts:197-203`）；遇后端 401 且持有 refresh token 时自动刷新并重放一次请求（server.ts:137-145 → `refreshTokens()` server.ts:207-238，新令牌回写 cookie）。

#### 4.9.2 API 代理层（web/app/api/** route handlers）

所有 handler 遵循两种模式之一：
- **薄代理**：`requireRuntimeClient({auth:"required"})` → `runtime.get/post(后端路径)` → 错误时 `runtimeErrorDetail` + `RuntimeClientError.status ?? 502`（如 `harnesses/templates`、`edges/status`、`skills`、`runtime/capabilities`）。
- **带本地状态**：`requireRuntimeUser()` 后进入 `web-store.ts` 的按用户内存存储（`declare global { var __astraWebStores }`，web-store.ts:139-141；`getStore(ownerUserId)`），后者再按需与后端 session/run 同步（`syncBackendSessions`/`syncBackendTranscript`，web-store.ts:1987/2140）。

按资源分组（每条一行：文件 → 方法 → 后端目标）：

**chats（12 个）**
- `chats/route.ts`：GET 列表（web-store `listChats`，从后端 `/sessions`+`/runs` 同步投影）/ POST 用首条消息建会话（`createChatWithMessage` + 后端 `POST /sessions`）。
- `chats/[chatId]/route.ts`：GET 详情（`getChatHydrated`）/ PATCH（归档、模型、workspace 选择、移动）/ DELETE 删除。
- `chats/[chatId]/stream/route.ts`：POST 发起新回合 SSE 代理；GET（`?runId=&last_index=&assistantMessageId=`）重挂进行中的 run（详见 4.9.3 与 CH6）。后端 `POST /chat/stream` 与 `GET /chat/runs/{runId}/stream`。
- `.../input/route.ts`：POST 活跃 run 的"延迟输入"排队（≤20000 字符，`queueDeferredRunInput` → 后端 `/chat/runs/{runId}/input`，幂等键 runId+消息 id，web-store.ts:1084/1115）。
- `.../messages/route.ts`：POST 非流式发消息（web-store `sendMessage` → 后端 `/chat`）。
- `.../stop/route.ts`：POST 停止活跃 run（`stopActiveRun`，取消 ack 超时 1.5s 后乐观返回，`settleRuntimeCancel`）。
- `.../resume/route.ts`：POST 恢复暂停 run（后端 `/chat/runs/{runId}/resume`）。
- `.../approval/route.ts`：POST 工具审批决定（透传后端 approval 接口，allow/deny）。
- `.../insights/route.ts`：GET 聚合 `/sessions/{id}/audit/summary` + `/chat/session/{id}/reflect` + `decision-trace`（Promise.allSettled，部分失败降级为 warnings）。
- `.../work-surface/route.ts` 与 `.../work-surface/runs/[runId]/route.ts`：GET 从 run 投影 + run 事件重建"工作面"（工具/agent 活动、任务图）事件流。

**projects（5 个）**：`projects/route.ts`（GET/POST，纯 web-store 本地 CRUD）、`[projectId]/route.ts`（GET/PUT/DELETE）、`[projectId]/files/route.ts`（POST multipart 上传知识文件，web-store）、`files/[fileId]/route.ts`（DELETE）、`star/route.ts`（POST/DELETE 收藏）。

**works（1 个 SSE）**：`works/[workId]/branches/[branchId]/turns/route.ts`：POST 校验请求体（三字段精确匹配、message ≤256KiB、request_id ≤256B）后，以 `x-astra-work-api-major: 1` 头把 Work 分支回合 SSE 透传给后端 `/v1/works/{workId}/branches/{branchId}/turns`，边转发边按 SDK `decodeWorkTurnStreamEventV1` 校验事件（协议错误注入 `WORK_PROTOCOL_ERROR` error 事件）。

**harnesses（12 个，全部薄代理到后端 `/harnesses/*`）**：`templates`（GET 模板）、`node-catalog`（GET 节点目录）、`skillify/runs`（POST 创建 Skillify 运行）、`runs/[runId]`（GET 运行详情）、`runs/[runId]/items`（GET 条目）、`items/[itemId]/decision`（POST 人工决策）、`skillify/draft`（POST 生成草稿）、`skill-drafts`（GET 草稿列表）、`skill-drafts/[draftId]`（GET 详情）、`[draftId]/decision`（POST 接受/拒绝）、`[draftId]/publish`（POST 发布技能）、`[draftId]/rules/[ruleId]/decision`（POST 规则级决策）。

**runtime-auth（4 个）**：`login`（POST，见 4.9.1）、`logout`（POST：调后端 `/auth/logout` 吊销 refresh token + 清三枚 cookie）、`me`（GET：cookie → `/auth/me` 代理）、`refresh`（POST：cookie → `/auth/refresh`，回写新令牌）。

**其他**：`models/route.ts`（GET：SDK `listModels` 全量分页拉取 + `getModelAccess`，映射为带 access 状态的 `ModelSummary`）；`edges/status/route.ts`（GET：`/edges/status` 边缘执行器列表，失败返回空列表或透传状态码）；`skills/route.ts`（GET：`/skills` 分页游标透传）；`search/route.ts`（GET：web-store `searchData` 本地聊天/项目搜索）；`sidebar/route.ts`（GET：聚合侧栏数据 + 用 `/auth/me` 识别用户，附带 token 刷新）；`runtime/capabilities/route.ts`（GET：`/runtime/capabilities` 能力开关，决定 Web 搜索/GitHub 功能可用性）；`runtime-config/route.ts`（GET/POST：读写 API URL/token/demo cookie 的设置端点）。

#### 4.9.3 页面与组件（(workspace) 路由组、SSE 客户端、composer）

**服务端页面**：聊天页 `chats/[chatId]/page.tsx:6-17`（`getCurrentUser` → `getChatHydrated` → `<ChatView initial={detail}/>`）；`now/page.tsx` 直接服务端调 `runtime.sdk.listWorks({cursor,limit:20})` 游标分页；`works/[workId]/page.tsx` 服务端经 `lib/work-overview.ts` 组装 Work 快照（分支目录 + 标准 + 任务图 + 事件）交给 1541 行的 `WorkOverviewPage` 客户端组件。

**核心客户端组件链（聊天）**：`ChatView`（chat-view.tsx:60，1216 行，状态中枢）组合：
- `Composer`（composer.tsx，693 行）：`contentEditable` 富文本编辑器，实现 **skill 令牌**（`[data-composer-skill-token]` DOM 节点，不可编辑 chip）、`/` 斜杠命令面板（`SlashCommandPanel` + `lib/composer/slash-commands.ts`：skill/mode/action 三类）、模型切换（`ModelSwitcher`，从 `/api/models` 拉取目录并按 access 状态排序）、工作区选择 chip（`ComposerPlusMenu`，来自 `/api/edges/status` 的边缘工作区）；提交时产出 `{text, attachments, options:{model, activeSkills, activeTools, webSearch, thinking}}`。
- `MessageBubble`（message-bubble.tsx，917 行）：ReactMarkdown 渲染助手消息（GFM/数学/代码高亮），`splitThinkingTags` 拆分 `<thinking>/<think>` 标签渲染推理区，artifacts 下载卡片。
- `WorkSurfacePanel`（work-surface-panel.tsx，3058 行）：右侧"工作面"，消费 `lib/work-surface.ts` 的纯函数 reducer（`applyWorkSurfaceEvent`/`hydrateWorkSurface`/`resetWorkSurfaceForRun`）把 SSE 事件投影为工具面/agent 面条目与任务图（`work-task-graph.tsx` 用 @xyflow/react 渲染）。
- `useStreamLifecycle`（hooks/use-stream-lifecycle.ts:232，1710 行）：**Web 端流式生命周期核心 hook**——`startStream`（乐观插入 user/assistant 占位消息 → `streamChatMessage` SSE → 各回调写回状态）、`attachExistingRunStream`（GET 重挂，指数退避自动重试 ≤4 次 `scheduleAutoAttachRetry`，use-stream-lifecycle.ts:380-402）、`queueDeferredInput`、`stopActiveRun`（本地先标记 cancelling + 轮询和解）、`resumeActiveRun`、审批 `respondToApproval`；高频 delta 经 `createAssistantPatchController`（lib/api/assistant-patch-controller.ts，rAF 批量合并 patch）防抖渲染。

**浏览器端 SSE 客户端**（注意：不在 `lib/runtime-client` 里，后者是纯服务端 HTTP 客户端）：`lib/api/chats.ts` 的 `streamChatMessage`（763 行）/`streamExistingChatRun`（780 行）用 `fetch` + `response.body.getReader()` 手写 SSE 解析（`consumeChatStream`:670-761，`parseSseFrame`:261 按 `\r?\n\r?\n` 分帧、拼 `data:` 行、跳过 `[DONE]`），`applyStreamEvent`（339-668）把 60+ 种事件类型归约为回调（`onText/onReasoning/onArtifacts/onRunStarted/onApprovalRequired/...`），并维护 `nextEventIndex`（事件断点续传游标）。SDK 的 `SSEClient`（fetch 版，支持重试/心跳/terminal 检测）只在 Work 回合 composer（`work-turn-composer.tsx:222`）中使用。

**服务端 SSE 中转**（`lib/runtime-client` 的角色）：`WebRuntimeClient.fetchResponse`（server.ts:127-147）是发起后端 SSE POST/GET 的通道（带 Bearer + 401 自动刷新重放）；`stream/route.ts` 拿到后端 `Response.body` 后在 `proxyRunStream`（177-508 行）中逐 chunk 转发给浏览器，同时"旁路镜像"解析每帧更新 web-store（见 CH6）。

#### 4.9.4 TypeScript SDK（packages/sdk——客户端 API 面、SSE/WebSocket、与后端契约）

**包结构**（package.json）：ESM/CJS 双格式（tsup 构建，`index` 与 `react` 两个入口，tsup.config.ts），`react` 为可选 peer（≥18）。15 个源文件职责：`client.ts`（2771 行，`AstraClient` HTTP+SSE 门面 + `AstraApiError` + `chatRequestToWire`）、`types.ts`（2765 行，全部 wire 类型：60+ 种 StreamEvent、Work V1/V2 协议类型）、`paths.ts`（与 Rust `crates/astra-thin-client/src/paths.rs` 保持同步的路径常量与构造函数，带资源 id 合法性校验）、`http.ts`（错误解码 `readAstraError`、`headersInitToRecord`、**JWT 无依赖解码 `extractJwtSubject`**——atob/Buffer 双路径）、`sse-client.ts`（fetch 版 `SSEClient` + `parseSseDataEvents`）、`websocket.ts`（`AstraWebSocket` 事件发射器风格 WS 客户端，支持 `sendMessage`/`approveToolCall` 双向通信与重连）、`hooks.ts`（`useAstraChat`/`useAstraRun` React hooks，useReducer 聚合流事件为 messages/toolCalls/plan/usage）、`wire.ts`（`modelSelectionToWire` 严格校验：offeringId 必填、无多余字段、≤64 字节）、`work-wire.ts`（4156 行，Work API 全部响应的**严格解码器**——校验身份字段一致性/哈希/revision，不符即抛 TypeError）、`work-event-reconcile.ts`（纯序列协议 `reconcileWorkEventPageV1`：applied/duplicate/gap/expired 四态）、`lifecycle-utils.ts`（运行等待/阻塞语义投影，`EXECUTION_BOUNDARY_WAIT_REASONS` 与 Rust 常量同步）。

**AstraClient API 面**（按域，全部方法名引自 client.ts）：
- 认证：`register/login/logout/getMe/setTokens` + 敏感操作再认证 `getReauthenticationOptions/reauthenticate`（password 或 Memoria 证明，553-604 行）；401 自动 `tryRefreshToken` 并重放（659-690 行）。
- 会话：`createSession/getSession/listSessions/deleteSession/updateSession/closeSession/resumeSession/cancelSession/getSessionAudit/getSessionActivity/getSessionTranscript/listSessionArtifacts`（normalize snake_case → camelCase）。
- 运行/聊天：`createRun`（非流式 `POST /chat`）、`streamChat`（`POST /chat/stream`，返回 `SSEClient`，`requireTerminalEvent:true`）、`getRunStatus/cancelRun/pauseRun/resumeRun/submitRunInput/getRunEvents`（缓冲 SSE 全量拉取 + `last_index`）、`getRunProjection/repairRunProjection/listRuns`（durable 投影与修复）、`delegateRun/listDelegations/pauseDelegations/resumeDelegations`（多 agent 委派）。
- 观测：`getSessionReflect/getSessionDecisionTrace`（reflect 报告规范化 377-420 行）、`getSessionEvents/listEvents/getCausalChain`（事件管道）。
- 模型：`listModels/getModelAccess`——**分页拉取并做一致性自检**（cursor 环检测、total/revision 漂移检测、末尾计数核对，2401-2527 行）。
- 记忆/技能/绑定：`memoryStore/Search/Retrieve/Purge`、`listRuntimeSkills/listSkills/registerSkill/publishSkill/getSkill/unpublishSkill`、`createAgentBinding/getAgentBinding/disableAgentBinding`。
- Work API（`/v1/works`，全部强制 `x-astra-work-api-major: 1` 头，请求前客户端侧校验 + 响应后解码器校验"回执身份必须与请求一致"）：`listWorks/createWork/getWorkOverview/listWorkBranches/compareWorkBranches/forkWorkBranch/deleteWorkBranch/archiveWorkBranch/restoreWorkBranch/attachWorkBranch/detachWorkBranch/controlWorkBranch/getWorkCriteria(Proposals)/resolveWorkCriteriaProposal/selectWorkDeliveryBranch/exportWorkPatchArtifact/getWorkPatchArtifact(Content)/materializeWorkPatch/commitWorkPatch/advanceWorkReadCursor/listWorkEvents/getWorkTaskGraph/getWorkBranchTranscript/getWorkSessionBinding/continueWorkBranch`（Work 回合 SSE，解码失败注入 `WORK_PROTOCOL_ERROR`）。
- §5.5 边缘回调：`postToolResult/postApprovalRespond/registerEdge/postEdgeHeartbeat`（`x-astra-edge-id` 头）；task lease 四个方法已标注 `@deprecated`（当前运行时未注册这些路由）。

**与后端契约要点**：① wire 全部 snake_case，SDK 内部归一为 camelCase；② 认证统一 `Authorization: Bearer`，无独立 API key 机制；③ SSE 终止事件集合 = `turn_complete/run_finished/run_cancelled/run_error/run_interrupted/run_paused/run_waiting/不可重试 error`（sse-client.ts:53-64），terminal 之后的 socket reset 视为噪声不重试（sse-client.ts:186-195 注释）；④ Work API 用主版本头协商 + revision/哈希乐观锁（expected_* 字段），SDK 拒绝"服务器回执与请求身份不一致"的响应；⑤ `chatRequestToWire`（422-477 行）是 Web 与 SDK 共用的请求编码函数。

### 4.10 评测 harness（crates/astra-test-harness）

**定位**（lib.rs:1-36 文档）：声明式 CLI 端到端测试框架——YAML 用例 × 模型矩阵，通过子进程执行真实 `astra chat --json`，捕获 session journal（`~/.astra/sessions/<id>.jsonl`），用"确定性判据优先、LLM judger 兜底"的评分栈打分并输出报告。二进制名 `astra-test`（Cargo.toml `[[bin]]`）。

**执行管线**（main.rs:750 行 CLI 装配 + suite.rs 编排）：
`main.rs`（clap Args：suite 目录、`--models` 回退列表、`--filter` glob、`--parallel` 信号量并发、`--runs N` 重复跑测抖动、`--circuit-breaker N` 连续基础设施失败熔断、`--judger-model/--judger-n/--judger-agg`、`--format text|json`、`--live-dashboard` 等）→ `preflight::run_preflight`（二进制存在、服务器健康、认证、模型连通性快失败）→ `suite::SuiteRunner::run_all`（suite.rs:116；`ScopedDiskSessionLoader` 按 `resolve_runner_profile_owner`（runner.rs:33-56）解析的 profile 本地 owner + 账号 server owner 两个命名空间加载 journal，避免多用户环境猜错会话身份）→ 每个用例经 `exec::CaseExecutor` trait（生产实现 `AstraCliExecutor` spawn 子进程，超时合成 exit_code=124）产出 `runner::RunOutcome`（`#[non_exhaustive]` 序列化兼容外部报告消费者，含 token 四桶：prompt/cached_input/cache_creation/completion、turn_rounds、cache_hits，runner.rs:66-100）→ `criteria::evaluate_deterministic[_with_session]` → 未定再走 `judger::Judger`（`AstraCliJudger` 借 `astra chat` 让 LLM 打分 `SCORE: <f32∈[0,1]>`；支持 `QuorumJudger` 多次取中位、`ExternalCmdJudger` 外部命令）→ 失败时 `digest::AstraCliDigestCollector` 子进程调 `astra journal digest` 把聚合指标嵌进报告 → `report::render`（text/json）→ 可选 `summarizer`（LLM 总结）与 `eval::evaluate`（多维数值评分：能力/运行时健康/效率，供 CI 门槛与趋势对比）。

**关键模块**：`case.rs`（YAML 加载，`Case{name,steps,models,criteria,prompt_variants,debug_log}` + `expand_prompt_variants` 同义改写复测）；`criteria.rs`（4200+ 行判据库：`ToolCalled/ExitCode/FinalState/ToolsCountBetween/StderrMatches/TextContains/TextNotContains/TextEquals/TextJsonValue(RFC6901)/TextJsonDag/SessionEventCount/JournalJsonPredicate...` + `Judger` 变体；`requires_session_capture` 决定是否加载 journal）；`session_capture.rs`（逐行松解析 journal 为 `Value + type` 索引）；`classify.rs`（失败分桶驱动重试：rate_limit/infra/protocol 等）；`capability_coverage.rs`（产品能力清单与模型探针防漂移桥接，`--audit-capabilities`）；`model_profiles.rs`（模型缓存复用能力画像：IntraTurnRounds/ConversationTurns）；`pipeline_analysis.rs`（从 journal 的 pipeline_feedback/alert/compaction 事件提取上下文管道健康趋势）；`session_identity.rs`（只信任 CLI 生命周期流里服务器签发的 session id，禁止从列表猜）；`artifacts.rs`（`<artifacts>/<case>/<model>/<run>/` 落盘 stdout/stderr/report/digest）；`dashboard.rs`（内嵌 axum + WebSocket 实时仪表盘，`DashboardEvent` 广播，dashboard.html 单页消费）；`test_support.rs`（overlay fs 的 ETXTBSY 防御：先写临时文件再原子 rename+chmod）。

**数据与适配**：`cases/` 58 个 YAML 用例（覆盖缓存复用、多轮上下文保留、fanout 真值、反幻觉、Work 分解/分支/交付、工具可见性矩阵、introspection 边界等，数据目录不逐文件展开）；`harbor_adapter.py`/`harbor_adapter_env.py` 把真实 Astra CLI 接入 Harbor 基准评测容器（适配器不含任何基准特定提示词，只做环境与产物搬运）；`tests/`：`real_journal_wire_shape.rs`（用 fixtures/ 下与真实 journal 结构一致的合成 jsonl 钉死 wire 契约）、`shipped_cases_smoke.rs`（加载全部 shipped YAML，防字段改名后静默失效）。


---

## 5. 文件清单总表

下表覆盖**全部**纳入范围的生产源文件，合计 **1441 个**（Rust 1252 + TypeScript 189），按 crate/分组列表；路径基准在各分组标题注明（多数为仓库根相对路径，`services`/`runtime`/`web` 分组为 crate/应用根相对路径）。"关键导出"仅列代表性项；"主要依赖"为 crate 间直接协作对象或关键第三方库。计数口径：排除 `tests/`、`src/tests/`、文件名含 `test` 的模块、`benches/`、`fixtures/`、`testdata/`、`snapshots/`、`__tests__`、`e2e`；边界情形（如 `test_utils.rs`、`mock_mcp_server.rs`、`core/src/bin/*`）在各分组注明。完整性与差异说明见附录 B。

---

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| crates/astra-logging/src/lib.rs | astra-logging | 全局 tracing 订阅器安装、格式选择、秘密脱敏 | `init_from_env`、`LogInitConfig`、`redact_known_secret_patterns`、`shutdown_otel` | tracing、tracing-subscriber |
| crates/astra-logging/src/otel.rs | astra-logging（feature `otel`） | OTLP 追踪导出：tracer provider 生命周期、Registry 分层 | `init_with_otel`、`shutdown_tracer_provider`、`wants_otel_export`（crate 内） | opentelemetry、opentelemetry_sdk、opentelemetry-otlp、tracing-opentelemetry |
| crates/astra-text-utils/src/lib.rs | astra-text-utils | 模块声明与 re-export 门面 | 7 个 pub 子模块 | serde、serde_json、dirs |
| crates/astra-text-utils/src/output_style.rs | astra-text-utils | 输出风格系统：内置/用户/项目三级注册表 | `OutputStyle`、`StyleSource`、`get_style_registry`、`get_output_style`、`current_output_style`、`list_styles` | serde、dirs |
| crates/astra-text-utils/src/semantic_dedup.rs | astra-text-utils | 三层工具调用语义去重（参数键/输出余弦）与上下文清单 | `SemanticDedup`、`semantic_call_key`、`token_cosine_similarity`、`DedupAuditRecord` | serde、serde_json |
| crates/astra-text-utils/src/str_preview.rs | astra-text-utils | Unicode 标量安全的字符串/路径截断预览 | `truncate_str`、`truncate_line`、`shorten_path`、`prefix_chars`、`github_repo_display` | 无（std only） |
| crates/astra-text-utils/src/text_tokenize.rs | astra-text-utils | CJK 感知分词、词干化、词频表 | `tokenize`、`build_tf`、`stem` | std |
| crates/astra-text-utils/src/tool_name.rs | astra-text-utils | 工具名 trim + ASCII 小写规范化 | `normalize_ascii_tool_name` | 无 |
| crates/astra-text-utils/src/url_component.rs | astra-text-utils | RFC 3986 URL 组件百分号编码 | `encode_url_component` | 无 |
| crates/astra-text-utils/src/xml_escape.rs | astra-text-utils | XML 属性/文本转义（零分配快速路径） | `xml_escape_attr`、`xml_escape_text` | std（Cow） |
| crates/astra-config/src/lib.rs | astra-config | 模块声明与 re-export 门面 | `RuntimeConfig`、治理变更/JSON 路径/运行时配置类型 re-export | astra-core、astra-turn-types 等 |
| crates/astra-config/src/runtime_config.rs | astra-config | RuntimeConfig 18 节定义、五层加载合并、模型策略、trace 配置 | `RuntimeConfig`（load/merge/cached/to_toml/load_with_version）、`set_cli_overlay`、`ToolSelectionConfig`、`ToolPolicyConfig`、`SessionTraceConfig`、`SafetyConfig`、`EffectiveToolPolicy`、`ModelPolicyProfile` | serde、toml、tracing、astra-core、dirs |
| crates/astra-config/src/config_overlay.rs | astra-config | `--settings` JSON overlay 与 `/config` 编辑目录/编辑执行 | `apply_settings_json`、`parse_settings_source`、`build_settings_catalog`、`apply_edit`、`filter_settings`、`OverlayError`、`effective_budget_for_model` | serde_json、thiserror、astra-core |
| crates/astra-config/src/config_versions.rs | astra-config | 内容寻址配置版本库（blob + append-only 索引） | `VersionId`、`PutMetadata`、`IndexEntry`、`ConfigVersionStore`（trait）、`LocalFileStore`、`StoreError` | sha2、fs2、chrono、serde、toml、dirs |
| crates/astra-config/src/config_version_cli.rs | astra-config | `astra config version` 子命令展示层（list/show/diff/current） | `resolve_prefix`、`format_version_list`、`format_version_show`、`format_version_diff`、`format_current`、`ResolveError` | toml、thiserror |
| crates/astra-config/src/governed_mutation.rs | astra-config | 白名单路径的治理式配置变更（边界/漂移/不变量） | `apply_governed_config_mutation`、`validate_governed_config_candidate`、`GovernedConfigMutation(Error)`、`normalized_config_drift` | serde_json |
| crates/astra-config/src/json_mutation.rs | astra-config | 点路径 JSON 叶原子读写（只改不建） | `read_existing_json_path`、`replace_existing_json_path`、`JsonPathMutationError` | serde_json、thiserror |
| crates/astra-config/src/lock_ext.rs | astra-config | RwLock 中毒恢复扩展 trait（带告警日志） | `RwLockExt`（read_or_recover/write_or_recover） | astra-core（agent_warn） |
| crates/astra-config/src/user_profile.rs | astra-config | 用户画像、偏好、场景/TurnIntent 类型、画像存储 | `UserProfile`、`UserProfileStore`、`UserProfileManager`、`TurnIntent`、`Scenario`、`UserPreferences`、`WorkspaceMutationIntent` 等 | serde、serde_json、astra-turn-types |
| crates/astra-runtime-env/src/lib.rs | astra-runtime-env | 模块声明、可见性中心规则文档、扁平 re-export | 全部子模块公共项 | astra-core、serde、serde_json、sha2、thiserror、async-trait |
| crates/astra-runtime-env/src/binding.rs | astra-runtime-env | Workspace/Executor/Runtime 三类绑定与 RunBinding 解析 | `RunBinding`（resolve/预设）、`WorkspaceBinding`、`ExecutorBinding`、`RuntimeBinding`、`RuntimeEnvironmentAdvertisement`、`runtime_execution_provider_type` | serde |
| crates/astra-runtime-env/src/capability.rs | astra-runtime-env | 绑定+策略 → 有效能力集的纯推导 | `EffectiveCapabilitySet::from_bindings`、`NetworkCapability`、四组 Capabilities 结构 | serde |
| crates/astra-runtime-env/src/local_state.rs | astra-runtime-env | astra-core 本地状态路径策略的兼容 re-export 门面 | `local_state_root`、`local_state_root_override`、`ASTRA_LOCAL_STATE_ROOT_ENV` | astra-core |
| crates/astra-runtime-env/src/policy.rs | astra-runtime-env | 策略意图：隔离分级/文件系统/网络/凭据/审批/资源/审计 | `PolicyIntent`（4 预设）、`IsolationIntent`、`ResourceLimits`、`ToolName`、`AuditPolicy` | serde |
| crates/astra-runtime-env/src/provider.rs | astra-runtime-env | 容量 provider 声明、规范摘要、能力标签与构造器 | `CapacityProviderDeclaration`、`CapacityProviderType`、`CapacityProviderCoverageEntry`、`server_service_provider`、`runtime_workspace_provider`、`canonical_tool_schema_digest`、`tool_offer_id` | serde、serde_json、sha2、astra-core |
| crates/astra-runtime-env/src/runtime_environment.rs | astra-runtime-env | 运行时会话/调用/结果契约与错误恢复契约 | `RuntimeEnvironment`（trait）、`RuntimeSessionSpec/Handle`、`CompiledRuntimePolicy`、`RuntimeToolInvocation/Outcome`、`RuntimeError(Kind)`、`RuntimeRecoveryAction` | async-trait、serde、thiserror |
| crates/astra-runtime-env/src/tool.rs | astra-runtime-env | 内置工具注册表、能力解析器与工具面裁决 | `ToolRegistry`、`ToolSpec`、`ToolRequirements`、`CapabilityResolver`、`AvailableToolSurface`、`ToolUnavailableReason` | serde、serde_json、sha2、thiserror、astra-core |
| crates/astra-runtime-env/src/workspace.rs | astra-runtime-env | 工作区供给请求/记录/挂载计划与校验 | `WorkspaceProvisionRequest`、`WorkspaceRecord`、`WorkspaceMountPlan`、`WorkspaceProvisioner`（trait）、`validate_workspace_id` | async-trait、serde、thiserror |
| crates/astra-credentials/src/lib.rs | astra-credentials | 多 profile 凭据文件：锁、原子写、权限、profile 解析、测试隔离 | `CredentialStore`（load/mutate/resolve_profile_name）、`CredentialsFile`、`Profile`、`local_profile_owner_id`、`set_test_credentials_dir` | serde、serde_json、thiserror、fs2、sha2、dirs |

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| crates/core/src/lib.rs | crate 根 | MatrixOne 兼容辅助、全局连接配额、SharedPool、ErrorResponse/SubRunState/状态常量、canonical JSON | `matrixone_statement_with_null_shape`, `push_matrixone_bound_string_set`, `SharedPool`, `connect_matrixone`, `SubRunState`, `ErrorResponse`, `canonical_json_string`, `bearer_token` | sqlx, axum, serde, tracing |
| crates/core/src/build_info.rs | build_info | 编译期构建身份（git_sha/dirty/target/profile），零副作用 `--build-info-json` 探针 | `BuildInfo`, `current`, `write_json_if_requested`, `BUILD_INFO_SCHEMA` | serde_json, history_work_baseline |
| crates/core/src/canonical_names.rs | canonical_names | 工具/代理名规范化去重；事件元数据 canonical 字段提取 | `append_unique_names`, `normalize_name(_list)`, `metadata_tool_name`, `metadata_tool_call_id`, `metadata_duration_ms` | serde_json |
| crates/core/src/composite_snapshot.rs | composite_snapshot | 五维状态引用组合快照（会话/数据/记忆/git/工作区）与差异、索引、构建器 | `SnapshotRef`, `CompositeSnapshot`, `CompositeSnapshotDiff`, `CompositeSnapshotBuilder`, `DataSnapshotProvider`, `SnapshotSpec` | serde, serde_json, uuid, chrono |
| crates/core/src/confidence.rs | confidence | 带上下界的置信区间类型，钳制不变量 | `ConfidenceInterval`（`new/exact/symmetric/is_high/is_uncertain`） | serde |
| crates/core/src/config.rs | config | 配置装配：ServerConfig(TOML) 三级加载 + env 覆盖 → AppSettings；MatrixOne/JWT/API/Memoria 设置 | `AppSettings`, `ServerConfig`, `MatrixOneSettings`, `JwtSettings`, `ApiSettings`, `MemoriaSettings`, `ConfigError`, `resolve_database_name` | serde, toml, dotenvy, tracing, local_state, runtime_limits |
| crates/core/src/delegation.rs | delegation | 委托 (scenario, pattern) 成败统计与最佳模式选择，有界+best-effort 持久化 | `DelegationOutcomeTracker`, `OutcomeStats` | serde, sync_poison |
| crates/core/src/drift.rs | drift | 焦点漂移原因与证据类型 | `DriftCause`, `DriftEvidence`, `EvidenceType` | serde, confidence |
| crates/core/src/error_kind.rs | error_kind | 统一错误分类 + 字符串边界兜底分类器 + 工具失败证据 | `ErrorKind`, `ClassifiedError`, `ToolFailureEvidence`, `classify_llm_error_message`, `classify_tool_output`, `is_llm_context_window_error` | serde, reqwest(URL 判定) |
| crates/core/src/feedback.rs | feedback | 用户/运行时反馈信号的环形有界存储（只观察不调参） | `FeedbackSignal`, `FeedbackSignalStore`, `SignalType`, `AdaptationHint`, `StreamingSpeculationStats` | serde, sync_poison |
| crates/core/src/history_work.rs | history_work | Phase-0 O(history) 低基数计量：154 埋点位×8 原子计数器、场景区间、队列字节 RAII | `HistoryWorkSite`, `record_*`, `serialized_bytes`, `QueueBytesReservation`, `HistoryWorkScenario`, `HistoryWorkSnapshot/Delta` | serde, serde_json, tracing |
| crates/core/src/history_work_baseline.rs | history_work_baseline | fail-closed 生产基线契约：进程捕获守卫、原子写、attestation、证据校验 | `ProductionProcessCaptureGuard`, `ProductionBaselineArtifact`, `write_json_atomic`, `verify_current_build_attestation`, `BUILD_GIT_SHA` | serde, sha2, history_work |
| crates/core/src/identity.rs | identity | 用户主体/用户名持久化长度契约 | `USER_ID_MAX_LEN`, `USERNAME_MAX_LEN` | （无） |
| crates/core/src/local_state.rs | local_state | Astra 本地文件根路径策略（env 重定向优于改 HOME） | `local_state_root`, `local_state_root_override`, `ASTRA_LOCAL_STATE_ROOT_ENV` | dirs |
| crates/core/src/log.rs | log | 统一 target=`astra.agent` 的结构化日志宏族 | `agent_error!`, `agent_warn!`, `agent_info!`, `agent_debug!`, `agent_persist_fail!`, `log_persist!`, `agent_escalation!` | tracing |
| crates/core/src/model_override.rs | model_override | 模型覆盖规范化（`default` 为符号请求不得持久化） | `normalize_model_override(_owned)`, `missing_model_selection_error` | error_kind |
| crates/core/src/model_wire.rs | model_wire | 聊天推理线缆规则：按协议施加输出 token 上限 | `apply_chat_output_token_limit` | serde_json |
| crates/core/src/model_wire/thinking.rs | model_wire::thinking | OpenAI-chat 思考协议适配（5 协议）与端点形状精确判定 | `ThinkingProtocol`, `canonical_thinking_protocol`, `canonical_zero_temperature`, `configured_temperature` | serde, serde_json, reqwest |
| crates/core/src/net.rs | net | 三层 HTTP 代理策略与 loopback 判定 | `build_internal_http_client`, `apply_env_proxy`, `client_builder_for_target`, `url_is_loopback` | reqwest, tracing |
| crates/core/src/observation.rs | observation | 回合指标纯数据采集（TurnMetrics）、工具族分类、观察图/URN/证据引用类型 | `TurnMetrics`, `ToolFamily`, `classify_tool_family`, `Urn`, `EvidenceRef`, `ObservationRecord`, `push_graph_node/edge` | serde, serde_json |
| crates/core/src/observation_journal.rs | observation_journal | 跨回合计量环形日志（容量 16）、趋势与策略验证、事实快照 | `ObservationJournal`, `JournalEntry`, `JournalFacts`, `MetricTrend`, `render_compact_status` | serde, observation |
| crates/core/src/process_runtime.rs | process_runtime | CLI/独立服务器共享的进程级 Tokio runtime 构建（16MiB worker 栈） | `build_process_runtime`, `PROCESS_WORKER_STACK_BYTES` | tokio |
| crates/core/src/runtime_limits.rs | runtime_limits | 集中式运行时限额（OnceLock 全局单例）、上下文窗口预算比 | `RuntimeLimits`, `context_window_for_model(_with_override)`, `MODEL_CONTEXT_INPUT_BUDGET_RATIO`, `warn_default_credentials_once`(dev) | config, tracing |
| crates/core/src/session_env_overlay.rs | session_env_overlay | 线程安全进程 env 叠加层（避免 set_var 竞态），可应用到子进程 | `get`, `set`, `remove`, `merged_pairs`, `apply_to_command` | log(宏) |
| crates/core/src/session_id.rs | session_id | session ID 作为路径组件的唯一校验源（ASCII/长度/遍历防御） | `validate` | （std only） |
| crates/core/src/sync_poison.rs | sync_poison | std 锁中毒恢复（into_inner + 警告日志） | `recover_mutex_lock`, `recover_rwlock_read/write` | log(宏) |
| crates/core/src/test_paths.rs | test_paths（cfg(test/dev-defaults） | 工作区根定位（找含 [workspace]+crates+fixtures 的目录） | `workspace_root`, `workspace_path`, `try_workspace_root_from` | （std only） |
| crates/core/src/tool_offer.rs | tool_offer | 工具 offer id 形状契约与 MCP 命名空间判定 | `tool_offer_id`, `is_valid_tool_offer_id`, `is_valid_provider_id`, `is_mcp_namespaced_tool_name` | （std only） |
| crates/core/src/tool_schema.rs | tool_schema | OpenAI function 工具 schema 名称提取/过滤/排序（fail-closed） | `tool_schema_name`, `tool_names_from_schemas`, `retain_tool_schemas_by_names`, `sort_tool_schemas_by_name` | serde_json |
| crates/core/src/trace_types.rs | trace_types | 管道事件追踪类别/级别/详细度类型 | `TraceCategory`, `TraceLevel`, `TraceVerbosity` | serde |
| crates/core/src/work_unit.rs | work_unit | 异步工作观察契约：状态/模式/唤醒策略/revision 单调 + 会话级注册表 | `WorkUnitObservation`, `WorkUnitObservationTracker`, `ActiveWorkRegistry`, `ActiveWorkProvider`, `WorkUnitStatus` | serde, serde_json, async-trait, chrono(测试) |
| crates/core/src/bin/history-work-instrumentation-probe.rs | bin（开发工具） | 合成专用进程的 Phase-0 计量探针：3 个锚点负载（128k/10t、200k/50t、1m/100t）×30 采样，产出机器可读 artifact（schema v1），显式声明"不是基线" | `main`（CLI：种子/采样数/输出路径） | astra_core::history_work, serde, sha2 |
| crates/core/src/bin/history-work-production-baseline.rs | bin（开发工具） | 组装真实进程基线：读取 --scenario/--capture 片段 + 三角色可执行文件，git attestation、聚合 site_totals、`artifact.verify()` 通过才原子写出 | `main`（CLI：--scenario/--capture/--cli(server,edge)-executable/--output） | astra_core::history_work_baseline, serde, sha2 |
| crates/core/src/bin/history-work-production-baseline-verify.rs | bin（开发工具） | fail-closed 基线验证器：`--input artifact.json` → 构建 attestation + `artifact.verify()`，打印场景/埋点数 | `main` | astra_core::history_work_baseline, serde |

（共 34 个生产 .rs 文件 = src 下 31 个（含 model_wire/thinking.rs 与 dev 门控的 test_paths.rs）+ src/bin 下 3 个；不含 tests/ 与内联 #[cfg(test)] 模块。）

### 文件清单（能力层 6 crate，共 101 个生产文件）

> 路径均相对 `Astra-0.2.4/crates/`；`关键导出`仅列代表性项；`主要依赖`指 crate 内/跨 crate 的直接协作对象。

### astra-tools（38 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| astra-tools/src/lib.rs | crate 根 | 工具契约核心：ToolResult/ToolExecutor trait、SandboxConfig、ToolContext、审批/问答/进度门 trait、输出预算 | `ToolResult`(L76)、`ToolExecutor`(L275)、`SandboxConfig`(L327)、`ToolContext`(L396)、`tool_requires_approval`(L670)、`truncate_output`(L736) | astra-sandbox(IsolationLevel)、astra-core、tokio-util |
| astra-tools/src/executor.rs | crate 根 | DefaultToolExecutor：共享工具执行器（审批→缓存→租约→分发→回执→脱敏截断→代际失效） | `DefaultToolExecutor`(L111)、`execute`(L359)、`dispatch`(L887)、`is_workspace_mutation_tool`(L1176)、`SERVER_DIRECT_DEFAULT_EXECUTOR_TOOL_NAMES`(L27) | schemas/fs_ops/shell_ops/git_gix/github/workspace_observation/credential_redaction |
| astra-tools/src/tool_engine.rs | crate 根 | 泛型 handler 注册表（宿主本地工具+前缀动态工具），panic 捕获、调用身份信封 | `ToolEngine`(L109)、`ToolHandler`(L53)、`DynamicToolHandler`(L73)、`ToolInvocationMetadata`(L42)、`execute_invocation`(L246) | schemas(schema_exists_for_tool)、futures(catch_unwind) |
| astra-tools/src/schemas.rs | crate 根 | 全部工具 JSON Schema 与动作级参数校验（x-astra-per-action-* 扩展） | `all_tool_schemas`(L838)、`validate_tool_arguments`(L396)、`schema_exists_for_tool`(L914)、`project_action_schemas_for_surface`(L927) | serde_json、astra-core |
| astra-tools/src/fs_ops.rs | crate 根 | 文件读写/替换/删除/列目录（沙箱路径解析、写前准备、格式化钩子） | `read_file`(L523)、`write_file`(L1097)、`str_replace`(L1386)、`multi_edit`(L1757)、`delete_file`(L1667)、`list_dir`(L1688)、`resolve_path_sandboxed`(L303) | astra-sandbox、credential_redaction、fuzzy_replacer |
| astra-tools/src/shell_ops.rs | crate 根 | bash/grep/glob 执行：命令分类、超时推断、scope 结算、后台任务契约校验 | `execute_bash`(L860)、`execute_bash_with_filesystem_boundary`(L1615)、`grep`(L1836)、`glob`(L2183)、`classify_bash_command`(L228) | astra-sandbox、detach、exit_semantics、source_preimage、workspace_observation |
| astra-tools/src/git_gix.rs | crate 根 | 基于 gix 的 git 工具（status/log/show/blame/diff/commit/stash/worktree…）与请求校验、回滚 journal | `git_dispatch`、`ToolExecutionOutcome`(L87)、`validate_git_request`(L396)、`GitStashRollbackJournal`(L663)、`status`(L863)、`diff`(L1540) | gix、git_tool_contract、credential_redaction |
| astra-tools/src/github.rs | crate 根 | GitHub REST 客户端（PR/Issue/CI/统计）与 token/远程发现 | `GitHubClient`(L34)、`resolve_github_tokens`(L164)、`detect_github_remote_repos`(L1976)、`extract_github_owner_repo`(L1954) | reqwest、github_tool_contract |
| astra-tools/src/code_intel.rs | crate 根 | tree-sitter 代码智能：符号/大纲/调用点/作用域/文档注释/成员（Rust/Py/TS/Go/Java/C++/Ruby） | `Symbol`(L18)、`detect_language`(L71)、`extract_symbols`(L137)、`extract_calls`(L932)、`extract_members`(L1525) | tree-sitter 系列 |
| astra-tools/src/memoria.rs | crate 根 | memoria 记忆服务网关：熔断器、快照/回滚、召回校验、fire-and-forget 治理 | `MemoriaToolGateway`(L467)、`MemoryCircuitBreaker`(L389)、`memoria_snapshot_create`(L2482)、`memoria_cloud_request`(L2443) | reqwest、astra-memoria、memory_tool_contract |
| astra-tools/src/run_script.rs | crate 根 | Python 程序化工具调用：stub 生成、超时/上限、UDS RPC 循环（仅 Unix） | `run_script`(L845)、`handle_run_script_with_cancel`(L1442)、`RunScriptConfig`(L143)、`RPC_ALLOWED_TOOLS`(L76)、`build_run_script_schema`(L561) | rpc_bridge、astra-sandbox(隔离执行)、schemas |
| astra-tools/src/rpc_bridge.rs | crate 根 | run_script 的 UDS JSON-RPC 服务端/协议帧/输出截断脱敏（仅 Unix） | `handle_rpc_connection`(L415)、`is_run_script_rpc_dispatch`(L51)、`truncate_head_tail`(L245) | run_script、credential_redaction、tokio |
| astra-tools/src/web_fetch.rs | crate 根 | HTTP GET 工具：SSRF 防护（私网 IP 拦截）、内容转换、缓存 | `fetch_with_cache_scope`(L230)、`FetchConfig`(L68)、`is_private_host`(L436) | reqwest、scraper、url |
| astra-tools/src/web_search.rs | crate 根 | web_search 工具（委托外部搜索后端，带缓存 scope） | `perform_web_search`(L113)、`web_search`(L10) | reqwest、web_fetch |
| astra-tools/src/workspace_observation.rs | crate 根 | 工作区观测协议：互斥租约、写者纪元、mutation/observation 回执、收敛追踪、隔离检疫 | `WorkspaceObservationLease`(L432)、`WorkspaceWriterGuard`(L194)、`OBSERVED_FIELD`(L50)等常量、`DesiredStateConvergenceTracker` | fs2(文件锁)、astra-core |
| astra-tools/src/credential_redaction.rs | crate 根 | 凭据脱敏：正则模式库、PEM 块、JSON 字段、截断保持标记完整 | `redact_credentials_in_text`(L285)、`redact_credentials_for_display`(L322)、`truncate_redacted_output`(L708)、`safe_output_window`(L940) | regex、bytes-regex |
| astra-tools/src/exit_semantics.rs | crate 根 | 退出码语义学：把非零退出区分为语义非错误（grep 无匹配等）与执行失败 | `ExitSemantics`(L12)、`CommandResultClass`(L48)、`classify_exit`(L93)、`classify_command_result`(L151) | astra-core(ToolFailureEvidence) |
| astra-tools/src/bash_cache_safety.rs | crate 根 | bash 只读缓存安全分类学（哪些命令输出仅依赖 fs+env） | `bash_command_is_cache_safe`(L33) | 无（纯函数） |
| astra-tools/src/build_test.rs | crate 根 | 构建/测试输出解析（cargo/pytest/jest/go）、错误分组、自动修复建议与追踪 | `parse_build_test_output`(L1354)、`BuildTestTracker`(L1021)、`apply_auto_fixes`(L213)、`is_build_test_command`(L1308) | exit_semantics |
| astra-tools/src/patch_materialization.rs | crate 根 | git patch 物化/导出/审查提交/对账（SHA256 内容哈希、工作区锁） | `materialize_git_patch`(L162)、`export_git_worktree_patch`(L258)、`commit_reviewed_git_patch`(L311)、`reconcile_reviewed_git_patch_commit`(L525) | tokio、sha2、git_gix |
| astra-tools/src/source_preimage.rs | crate 根 | 命令执行前源文件快照（content-addressed blob 存储与恢复回执） | `prepare`(L235)、`prepare_inferred`(L337)、`restore_receipt`(L638)、`SOURCE_ARTIFACTS_FIELD`(L21) | sha2、fs2 |
| astra-tools/src/fuzzy_replacer.rs | crate 根 | str_replace 的 8 级模糊锚定（行号剥离/引号归一/缩进弹性/Levenshtein…） | `fuzzy_find_replacement`(L43)、`preserve_quote_style`(L594)、`STRATEGY_QUOTE_NORMALIZED`(L24) | 无 |
| astra-tools/src/tool_search.rs | crate 根 | tool_search 工具：按查询选工具/紧凑化 schema 输出 | `tool_search`(L22) | schemas、relevance_score |
| astra-tools/src/relevance_score.rs | crate 根 | 通用相关性评分与排序（Scoreable trait） | `Scoreable`(L9)、`relevance_score`(L26)、`rank_by_relevance`(L71) | 无 |
| astra-tools/src/ask_user.rs | crate 根 | ask_user 问卷模型：解析/答案规范化/遥测/审计 | `AskUserPrompt`(L30)、`parse_ask_user_prompt`(L104)、`normalize_ask_user_answers`(L506)、`summarize_ask_user_tool_call`(L704) | serde_json |
| astra-tools/src/detach.rs | crate 根 | bash 后台化：DetachShell 槽位/handle/listener、进程组 SIGTERM/SIGKILL、领养 ACK | `DetachShellSlot`/`DetachShellHandle`(L278)/`DetachShellListener`(L312)、`new_slot_with_handle`(L343)、`sigkill_process_group`(L135) | tokio(watch)、nix/libc |
| astra-tools/src/display_sixel.rs | crate 根 | 终端 Sixel 图像渲染工具（能力探测/缓存/TUI 挂起队列） | `display_sixel`(L206)、`probe_sixel_support`(L111)、`set_sixel_supported`(L61) | 无（外部 img2sixel） |
| astra-tools/src/env_tools.rs | crate 根 | env 工具与会话级环境覆盖层（overlay 应用到子进程） | `env_tool`(L71)、`session_env_overlay_set`(L34)、`apply_overlay`(L64)、`is_sensitive_var`(L266) | astra-sandbox(SENSITIVE_ENV_VARS) |
| astra-tools/src/passive_cargo_check.rs | crate 根 | 编辑 Rust 文件后的被动 cargo 诊断（限流/截断/消息队列） | `should_schedule_passive_cargo`(L42)、`take_passive_cargo_messages`(L61) | tokio |
| astra-tools/src/passive_tsc_check.rs | crate 根 | 编辑 TS/JS 文件后的被动 tsc 诊断 | `should_schedule_passive_tsc`(L50)、`take_passive_tsc_messages`(L80) | tokio |
| astra-tools/src/internal_artifacts.rs | crate 根 | 检测并拦截对内部工具结果工件的引用（防自我指涉） | `references_internal_tool_result_artifact`(L9)、`internal_tool_result_artifact_access_error`(L27) | 无 |
| astra-tools/src/config_tool.rs | crate 根 | config 工具（查询/调整输出限制的只读视图） | `config_tool`(L13) | astra-core(RuntimeLimits) |
| astra-tools/src/char_boundary.rs | crate 根 | UTF-8 字符边界扩展 trait（截断防 panic） | `CharBoundaryExt`(L6) | 无 |
| astra-tools/src/agent_tool_contract.rs | crate 根 | agent/agent_fanout 工具的动作契约与错误文案 | `AGENT_ACTIONS`(L4)、`agent_action_from_args`(L84)、`agent_fanout_action_from_args`(L119) | serde_json |
| astra-tools/src/git_tool_contract.rs | crate 根 | git 工具动作/stash/worktree 子动作枚举与参数解析 | `GitAction`(L34)、`git_action_from_args`(L136)、`git_stash_sub_action_from_args`(L187) | serde_json |
| astra-tools/src/github_tool_contract.rs | crate 根 | github 工具动作枚举与解析 | `GithubAction`(L18)、`github_action_from_args`(L56) | serde_json |
| astra-tools/src/memory_tool_contract.rs | crate 根 | memory 工具动作枚举与解析 | `MemoryAction`(L20)、`memory_action_from_args`(L62) | serde_json |
| astra-tools/src/session_tool_contract.rs | crate 根 | session 工具动作枚举与解析 | `SessionAction`(L20)、`session_action_from_args`(L64) | serde_json |

### astra-skills（31 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| astra-skills/src/lib.rs | crate 根 | 模块清单与核心再导出、行内 shell 检测 | `has_inline_shell`(L65)、再导出 SkillProvider/SkillExecutor 等 | 全部子模块 |
| astra-skills/src/traits.rs | crate 根 | 框架 trait：Provider/Executor/Resolver/Installer/Marketplace 与 SkillError | `SkillProvider`(L16)、`SkillExecutor`(L67)、`SkillResolver`(L134)、`ResolvedSkill`(L109)、`SkillError`(L246) | manifest |
| astra-skills/src/manifest.rs | crate 根 | 技能清单类型与核心校验 | `SkillManifest`(L163)、`ExecutionContext`(L134)、`TrustTier`(L392)、`EffortLevel`(L295)、`SkillComposition`(L346)、`validate_skill_manifest_core`(L668) | serde_yaml_ng、astra-core |
| astra-skills/src/loader.rs | crate 根 | SKILL.md 解析、路径遍历防护、限定加载、搜索路径、目录发现 | `parse_skill_md`(L110)、`load_skill_from_path`(L274)、`load_skill_from_path_confined`(L283)、`discover_skills_in_dir`(L456)、`skill_search_paths`(L511) | manifest、walkdir |
| astra-skills/src/executor/mod.rs | executor | 执行器模块聚合 | 再导出 Inline/Isolated/Router | inline、isolated |
| astra-skills/src/executor/inline.rs | executor | inline 执行：指令参数替换后注入当前会话 | `InlineSkillExecutor`(L16)、`execute`(L20)、`supports`(L76) | arguments、manifest、lib(has_inline_shell) |
| astra-skills/src/executor/isolated.rs | executor | fork 执行：委托 SkillSubRunExecutor 子运行、检查点、终态映射、路由回退 | `IsolatedSkillExecutor`(L115)、`SkillSubRunExecutor`(L37)、`SubRunOutcome`(L62)、`SkillExecutionRouter`(L292) | traits、manifest、astra-pipeline(feature) |
| astra-skills/src/providers/mod.rs | providers | provider 聚合 | Local/Bundled/Mcp/Database 再导出 | 各 provider |
| astra-skills/src/providers/local.rs | providers | 文件系统技能源 | `LocalSkillProvider`(L14)、SkillProvider impl(L65) | loader |
| astra-skills/src/providers/bundled.rs | providers | 编译内置技能源（含 dynamic_skills 内容） | `BundledSkillProvider`(L24)、SkillProvider impl(L98) | dynamic_skills、loader |
| astra-skills/src/providers/mcp.rs | providers | MCP skill:// 资源源 | `McpSkillProvider`(L37)、SkillProvider impl(L96) | manifest |
| astra-skills/src/providers/database.rs | providers | 数据库技能源（SQLx） | `DatabaseSkillProvider`(L18)、SkillProvider impl(L92) | astra-services、axum(错误) |
| astra-skills/src/providers/dynamic_skills/mod.rs | providers/dynamic | 7 个 Rust 生成的内置技能聚合 | `all_dynamic_skills`(L20) | 7 个技能文件 |
| astra-skills/src/providers/dynamic_skills/debug.rs | providers/dynamic | 内置 debug 技能内容 | `skill_content()`(L1) | 无 |
| astra-skills/src/providers/dynamic_skills/reflect.rs | providers/dynamic | 内置 reflect 技能内容 | `skill_content()`(L1) | 无 |
| astra-skills/src/providers/dynamic_skills/remember.rs | providers/dynamic | 内置 remember 技能内容 | `skill_content()`(L1) | 无 |
| astra-skills/src/providers/dynamic_skills/review.rs | providers/dynamic | 内置 review 技能内容（allowed_tools=bash/read_file/write_file） | `skill_content()`(L1) | 无 |
| astra-skills/src/providers/dynamic_skills/skillify.rs | providers/dynamic | 元技能：把会话流程固化为 SKILL.md | `skill_content()`(L1) | 无 |
| astra-skills/src/providers/dynamic_skills/stuck.rs | providers/dynamic | 内置 stuck（脱困）技能内容 | `skill_content()`(L1) | 无 |
| astra-skills/src/providers/dynamic_skills/verify.rs | providers/dynamic | 内置 verify 技能内容 | `skill_content()`(L1) | 无 |
| astra-skills/src/activation.rs | crate 根 | 条件激活：glob 路径匹配跟踪器 | `ConditionalSkillTracker`(L69)、`path_matches_skill`(L12) | manifest |
| astra-skills/src/arguments.rs | crate 根 | 技能参数替换（$ARGUMENTS/${NAME}/${SKILL_DIR}）与解析 | `substitute_arguments`(L54)、`parse_arguments`(L138) | 无 |
| astra-skills/src/auto_invoke.rs | crate 根 | 自动触发：停滞/压力门控 + SkillDiagnosis 诊断契约 | `AutoInvokeGate`(L101)、`AutoInvokeCause`(L35)、`SkillDiagnosis`(L254)、`SKILL_DIAGNOSIS_SCHEMA_VERSION`(L178) | serde_json |
| astra-skills/src/composition.rs | crate 根 | 技能组合：深度限制、上下文构造、输入/输出 schema 校验 | `CompositionContext`(L16)、`validate_input`(L189)、`validate_output`(L239)、`MAX_COMPOSITION_DEPTH`(L12) | serde_json |
| astra-skills/src/health_ranking.rs | crate 根 | 按工具健康度对技能排序的乘数模型 | `rank_multiplier`(L76)、`sort_by_health_rank`(L110)、`MIN/MAX_HEALTH_BOOST`(L46/L50) | 无 |
| astra-skills/src/hooks.rs | crate 根 | 技能/工具事件钩子：注册表、pre/post 评估、shell 钩子风险审查 | `SkillHooks`(L44)、`ToolEventHookRegistry`(L405)、`evaluate_pre_tool_hooks`(L731)、`evaluate_post_tool_hooks`(L885) | tokio、serde_yaml_ng |
| astra-skills/src/improvement.rs | crate 根 | 技能自改进：批次分析提示、改写提示、内容提取与应用 | `ImprovementTracker`(L40)、`build_analysis_prompt`(L78)、`apply_improvement`(L211)、`TURN_BATCH_SIZE`(L14) | serde_json |
| astra-skills/src/pack.rs | crate 根 | 技能 tar.gz 打包/解包/检视 | `pack_skill`(L50)、`unpack_skill`(L114)、`inspect_bundle`(L216) | tar、flate2 |
| astra-skills/src/quality.rs | crate 根 | 技能质量追踪（成功率条目与更新） | `SkillQualityTracker`(L94)、`SkillQualityEntry`(L14)、`SkillOutcome`(L99) | serde_json |
| astra-skills/src/verify.rs | crate 根 | SkillVerifier：按 success_criteria 校验执行结果 | `SkillVerifier`(L15) | serde_json |
| astra-skills/src/version.rs | crate 根 | 语义化版本与约束（>=,~,^,<,=…）解析比较 | `Version`(L13)、`VersionConstraint`(L177)、`ConstraintOp`(L113) | serde |

### astra-pipeline（11 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| astra-pipeline/src/lib.rs | crate 根 | 模块清单与工具健康类型再导出 | 模块声明(L5-15)、`TOOL_OUTCOME_RING_CAPACITY` 等 | 全部子模块 |
| astra-pipeline/src/step_protocol.rs | crate 根 | Step Protocol v2：描述子/执行/检查点三层、版本协商、调度契约、幂等、记忆上下文 | `PROTOCOL_VERSION`(L45)、`StepDescriptor`(L209)、`StepExecution`(L224)、`SchedulingContract`(L155)、`MemoryContext`(L239)、`check_protocol_version_with_policy`(L69) | serde、astra-text-utils |
| astra-pipeline/src/step_recorder.rs | crate 根 | 观测层：把 chat_stream 执行映射为 Step 事件（含存储脱敏） | `StepRecorder`(L295)、`redact_credentials_for_storage`(L41) | step_protocol、step_checkpoint、regex |
| astra-pipeline/src/step_checkpoint.rs | crate 根 | 检查点/事件 JSONL 持久化（Light/Heavy 两级、耐久度分级、修剪） | `FileBackedEventStore`、`read_latest_heavy_checkpoint`、`STEP_EVENT_RECOVERY_MAX_BYTES`(L54)、`WriteDurability`(L61) | astra-services(工件存储)、serde |
| astra-pipeline/src/step_restore.rs | crate 根 | 会话恢复：Heavy 检查点+事件重放→完成工具审计（不授予重放权威） | `RestoredSession`、`CacheRestoreReport`(L33)、`CACHE_RESTORE_REPORT_VERSION`(L30) | step_checkpoint、step_protocol |
| astra-pipeline/src/crash_recovery.rs | crate 根 | 崩溃恢复状态机：检测/定位/分类(Replay/Skip/RequireUser)/重放 | `recover_from_crash`(L60)、`CrashRecoveryManager`、`RecoveryError` | step_checkpoint、step_restore、astra-turn-types(幂等分类) |
| astra-pipeline/src/skill_checkpoint.rs | crate 根 | 技能（子代理）级检查点管理 | `SkillCheckpoint`(L30)、`SkillExecutionState`(L56)、`SkillCheckpointManager` | serde、thiserror |
| astra-pipeline/src/event.rs | crate 根 | 精简内存事件日志（因果链 EventId、UUID v7 关联） | `EventKind`(L52)、`TurnEvent`(L37)、`EventId`(L33)、`clip_output_preview`(L21) | astra-core(Trace 类型)、uuid |
| astra-pipeline/src/output_stream.rs | crate 根 | 字节偏移追加式输出流（长任务不驻内存） | `OutputStream`(L38)、`OutputStreamError`(L12) | std |
| astra-pipeline/src/trace_query.rs | crate 根 | 跨层事件统一查询与逐步延迟归因 | `UnifiedEvent`(L32)、`StepLatencyBreakdown`(L43) | event、step_protocol |
| astra-pipeline/src/tool_health_types.rs | crate 根 | 跨会话工具健康度类型（环形结果、失败率） | `ToolHealthEntry`(L32)、`ToolOutcome`(L10)、`ToolOutcomeCacheEntry`(L24)、`TOOL_OUTCOME_RING_CAPACITY`(L6) | serde |

### astra-plan（6 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| astra-plan/src/lib.rs | crate 根 | 模块清单与再导出 | 再导出 TaskPlan/PlanModeState/PlanRepository 等 | 全部子模块 |
| astra-plan/src/model.rs | crate 根 | 计划数据模型：任务状态/子任务/依赖就绪 | `TaskStatus`(L9)、`SubtaskPlan`(L50)、`TaskPlan`(L72)、`ready_subtasks`(L78) | astra-services(VerifierKind) |
| astra-plan/src/state.rs | crate 根 | 计划模式状态：阶段推断、乐观并发版本、时间线 | `PlanModeState`(L83)、`PlanPhase`(L11)、`ExecutionTimeline`(L216)、`generate_plan_id`(L132) | model |
| astra-plan/src/execution.rs | crate 根 | 执行期辅助：子任务提示构造、并行分组分析 | `format_subtask_prompt_with_operator_notes`(L9)、`analyze_parallelism`(L108)、`ParallelGroups`(L91) | model、astra-services |
| astra-plan/src/repository.rs | crate 根 | 计划持久化：trait + SQLx 云实现 + 内存实现（step-run 生命周期） | `PlanRepository`(L144)、`CloudPlanRepository`(L346)、`InMemoryPlanRepository`(L1335)、`NewStepRun`(L89) | sqlx、astra-services |
| astra-plan/src/resume.rs | crate 根 | 计划恢复摘要与提示（审批 fail-closed） | `plan_resume_prompt_hint`(L53)、`plan_mode_authoring_active`(L67)、`plan_resume_snapshot_for_session`(L78) | repository、state |

### astra-prompts（7 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| astra-prompts/src/lib.rs | crate 根 | 模块清单 | 6 个模块声明 | 无 |
| astra-prompts/src/extraction.rs | crate 根 | 会话压缩抽取提示与响应解析 | `COMPACT_UNIFIED_PROMPT`(L7)、`CompactResponse`(L44)、`parse_compact_response`(L146) | serde |
| astra-prompts/src/memory_ns.rs | crate 根 | 记忆命名空间常量与映射 | `PREFERENCE` 等 6 常量(L7-17)、`to_memory_type`(L20)、`ALL`(L33) | 无 |
| astra-prompts/src/memory_proto.rs | crate 根 | 记忆协议常量库：版本/分层/命名空间/状态/召回规则 | `VERSION`(L132)、`NS_*`(L167-177)、`ST_*`(L193-204)、`is_prompt_recallable_status`(L209) | 无 |
| astra-prompts/src/memory_types.rs | crate 根 | 记忆类别编码与记忆提示构造 | `MemoryCategory`(L12)、`encode`(L112)、`decode`(L118)、`build_memory_prompt`(L147) | chrono |
| astra-prompts/src/skills.rs | crate 根 | 系统技能指令与内置技能 | `SystemSkill`(L29)、`builtin_system_skills`(L75)、`build_skill_instructions`(L80) | 无 |
| astra-prompts/src/team_prompts.rs | crate 根 | 多代理编排提示（扇出/串行/对抗/子代理/预算感知） | `fan_out_agent_prompt`(L10)、`fork_child_prompt`(L183)、`budget_awareness_prompt`(L207) | 无 |

### astra-sandbox（8 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| astra-sandbox/src/lib.rs | crate 根 | 分层定义与统一再导出 | 再导出 policy/command/path/git_safety/process_isolation/shell_hardening/bash_ast 公共项(L22-46) | astra-skills(TrustTier)、astra-core |
| astra-sandbox/src/policy.rs | policy | 隔离级别、沙箱策略、env 基线与禁配模式、敏感路径 | `IsolationLevel`(L36)、`SandboxPolicy`(L55)、`ENV_BASELINE`(L82)、`is_sensitive_path` 等 | path |
| astra-sandbox/src/path.rs | path | 路径校验与归一（防逃逸/防符号链接绕过） | `validate_path`(L82)、`normalize_path`(L150)、`canonicalize_parent_and_append`(L183)、`SandboxPathError`(L8) | policy |
| astra-sandbox/src/command.rs | command | 命令沙箱包装、env 过滤、命令风险分析（写目标/凭据访问推断） | `sandbox_command`(L41)、`filter_environment`(L79)、`analyze_command_risks_in_workspace`(L220)、`CommandRisk`(L1168)、`is_rm_catastrophic_rm_path`(L116) | policy |
| astra-sandbox/src/bash_ast.rs | bash_ast | tree-sitter-bash AST 解析与风险分析（穿透启动器/xargs/find） | `parse_bash`(L6)、`parse_plain_bash_commands`(L20)、`analyze_bash_risks_ast`(L481)、`strip_benign_bash_redirects`(L148) | tree-sitter-bash、command(CommandRisk) |
| astra-sandbox/src/shell_hardening.rs | shell_hardening | 命令加固构造、危险路径/敏感 env 常量、内部工件路径识别 | `build_hardened_command`(L95)、`scrub_secrets_from_env`(L270)、`DANGEROUS_FILE_PATHS`(L15)、`is_internal_safe_path`(L497) | astra-core(session_id 校验) |
| astra-sandbox/src/git_safety.rs | git_safety | git 命令安全审查（force-push/hook 跳过/exec 注入/amend…） | `validate_git_command`(L143)、`GitSafetyViolation`(L9)、`is_soft_violation`(L128)、`is_bare_git_repo`(L172) | 无 |
| astra-sandbox/src/process_isolation.rs | process_isolation | Linux namespace/cgroup 隔离执行、进程归属（cgroup/监督器/进程组）、InvocationSupervisor 自 re-exec 监督协议 | `IsolationConfig`(L66)、`execute_isolated`(L1968)、`BashInvocationOwner`(L223)、`InvocationSupervisor`(L392)、`run_invocation_supervisor_if_requested`(L694)、`process_scope_available`(L1770) | libc、tokio、uuid |

### 本章文件清单（协议与集成层，58 个生产 .rs 文件）

### astra-server-types（10）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
| --- | --- | --- | --- | --- |
| crates/astra-server-types/src/lib.rs | 根 | Server API 请求/响应类型、WS 消息、Work 契约、SSE 错误语义、版本头 | ChatRequest, WsClientMessage, WsServerMessage, WorkTaskBoardUpdateV1, WorkCreateRequestV1, WORK_API_MAJOR, AGENT_INTERACTION_API_MAJOR, sse_error_code_for_status | serde, serde_json, astra-turn-types; (server) axum, astra-core, astra-services, astra-tools |
| crates/astra-server-types/src/completions.rs | 根 | 辅助推理代理契约（5 种受控操作） | CompletionRequest, CompletionOperation, CompletionResponse, MAX_COMPLETION_OUTPUT_TOKENS | serde, serde_json, astra-turn-types |
| crates/astra-server-types/src/conflict_resolver.rs | server feature | LLM 辅助 git 合并冲突解决 | ConflictResolver, FileConflict, extract_file_conflicts, apply_resolutions, TheirsWinsResolver | tokio(process/fs), async-trait |
| crates/astra-server-types/src/edge_connection_pool.rs | server feature | Edge WS 连接池：注册/事务重连/工具派发与结果路由/去重账本 | EdgeConnectionPool, EdgeConnection, ReconnectReservation, EdgeToolResult, DispatchedToolRequest | dashmap, tokio, tokio-util(CancellationToken), serde, edge_ws_protocol |
| crates/astra-server-types/src/edge_ws_protocol.rs | 根 | Server↔Edge 双向 JSON 帧协议与常量 | EdgeClientMessage, EdgeServerMessage, RuntimeProcessAuthorizationContext, EDGE_TOOL_TIMEOUT_SECS, MAX_EDGE_TOOL_TIMEOUT_SECS | serde, serde_json, astra-turn-types(ToolInvocationIdentity) |
| crates/astra-server-types/src/session_run_tree.rs | 根 | 会话运行树快照（投影契约） | SessionRunTreeSnapshot, SessionRunNode, SessionRunLifecycleStatus, SESSION_RUN_TREE_SCHEMA_VERSION | serde |
| crates/astra-server-types/src/team_orchestrator_traits.rs | server feature | 团队编排依赖解耦 trait | DelegationExecutor, DelegationTracking, RunPersistence, SubRunRecord, DelegationProgress | async-trait, astra-core, astra-services, tokio-util |
| crates/astra-server-types/src/team_orchestrator_types.rs | server feature | 编排纯类型与辅助函数、warn_persist! | RunStatusKind, run_status_kind, ExecutionPhase, TeamExecutionStatus, derive_team_status, warn_persist! | astra-services(coordination) |
| crates/astra-server-types/src/worktree_isolation.rs | server feature | git worktree 多 agent 并行编辑隔离与合并 | WorktreeManager, WorktreeInfo, MergeResult, ConflictInfo, WorktreeError, RepoLock | tokio(process/fs/sync), astra-core(composite_snapshot), conflict_resolver |
| crates/astra-server-types/src/ws_progress_callback.rs | server feature | WS 工具进度回调（mpsc 转发） | WebSocketProgressCallback, ProgressEvent | async-trait, tokio(mpsc), serde, astra-tools(ToolProgressCallback) |

### astra-sync-protocol（1）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
| --- | --- | --- | --- | --- |
| crates/astra-sync-protocol/src/lib.rs | 根 | 边云同步 HMAC 签名与出箱 ACK 线协议 | sync_outbox_request_signature, SyncOutboxAck, SyncOutboxIngestionStatus, SYNC_OUTBOX_SIGNATURE_HEADER | hmac, sha2, serde, serde_json, astra-core(canonical_json) |

### astra-messaging（10）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
| --- | --- | --- | --- | --- |
| crates/astra-messaging/src/lib.rs | 根 | crate 门面与再导出 | (re-export 各模块关键类型) | — |
| crates/astra-messaging/src/types.rs | types | 消息词汇：地址/目标/载荷/信箱错误/审计事件 | AgentAddress, AgentMessage, MessagePayload, MessageTarget, AgentSignal, MailboxError, agent_communication_event | serde, chrono, uuid, astra-turn-types |
| crates/astra-messaging/src/transport.rs | transport | 传输抽象 trait | MessageTransport, MessageStream | async-trait, types |
| crates/astra-messaging/src/delegation.rs | delegation | 委派层级查询 trait | DelegationLookup, SubRunInfo | async-trait |
| crates/astra-messaging/src/router.rs | router | 信箱与目标解析路由（Parent/Broadcast/延迟父投递） | AgentMailbox, AgentMailboxRouter, PermissionOutcome | tokio, uuid, transport, delegation, types |
| crates/astra-messaging/src/ack_tracker.rs | ack_tracker | requires_ack 消息的确认跟踪与重试 | PendingAckTracker, AckConfig, AckOutcome, AckSweepHandle | tokio(RwLock), types |
| crates/astra-messaging/src/dead_letter.rs | dead_letter | 有界死信队列 | DeadLetterQueue, DeadLetter, DeadLetterReason, DeadLetterSummary | tokio(RwLock), types |
| crates/astra-messaging/src/in_process.rs | in_process | 进程内 tokio 通道传输 | InProcessTransport, InProcessMetrics | tokio(mpsc/broadcast/RwLock), async-trait, transport, types |
| crates/astra-messaging/src/db_transport.rs | db_transport | MySQL/MatrixOne 持久化传输（轮询/claim/回收/清理） | DatabaseTransport, CleanupScheduler, TransportMetrics, ensure_schema | sqlx(MySql), tokio, uuid, tracing, async-trait |
| crates/astra-messaging/src/metrics.rs | metrics | 统一可观测性：计数/延迟/事件钩子 | MessagingMetrics, LatencyTracker, MetricsSnapshot, MessagingEventHandler, StderrEventHandler | tokio(RwLock), types |

### astra-memoria（1）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
| --- | --- | --- | --- | --- |
| crates/astra-memoria/src/lib.rs | 根 | Memoria 规范端口：传输凭据、严格召回校验、端口 trait、会话运行时状态 | MemoriaPort, MemoriaToolTransport, MemoryScope, MemoriaMemory, MemoriaRuntimeState, validate_strict_recall_payload, merge_strict_recall_working_memory, memoria_runtime_state | async-trait, serde, serde_json, chrono, uuid, astra-turn-types |

### astra-thin-client（9）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
| --- | --- | --- | --- | --- |
| crates/astra-thin-client/src/lib.rs | 根 | crate 门面、分层文档、再导出 | ThinClient, ThinClientError, StreamEvent, (re-export server-types Work/Completion/RunTree 类型) | astra-server-types, astra-sync-protocol 等 |
| crates/astra-thin-client/src/paths.rs | paths | 全部 URL 路径常量/构造器与路径段安全校验 | CHAT_STREAM, SESSIONS, WORKS, session(), work(), work_branch_turns(), model(), is_safe_path_segment(私有) | percent-encoding |
| crates/astra-thin-client/src/protocol.rs | protocol | 请求/响应体类型与 StreamEvent 分类、工具结果规范化哈希 | ChatStreamRequest, ToolResultRequest(new_with_hash/compute_result_hash), ApprovalRespondRequest, UserPromptRespondRequest, EdgeRegisterRequest, EdgeHeartbeatRequest/Response, StreamEvent, classify_stream_event, tool_result_status_is_error | serde, serde_json, sha2, hex, astra-turn-types(ModelSelection) |
| crates/astra-thin-client/src/sse.rs | sse | 增量 SSE 解析器（data: JSON 帧） | SseParser, parse_sse_body | protocol, error, serde_json |
| crates/astra-thin-client/src/error.rs | error | 客户端错误类型与传输类判定 | ThinClientError, is_transport | thiserror, reqwest, serde_json |
| crates/astra-thin-client/src/device_proof.rs | device_proof | 设备挑战 HMAC 证明与 canonical 消息 | device_challenge_proof, canonical_device_proof_message, DeviceProofPurpose, ASTRA_DEVICE_*_HEADER | hmac, sha2, base64, serde |
| crates/astra-thin-client/src/edge.rs | edge | Edge 执行器能力广告与注册体构造 | advertise_executor, builtin_capability_preset, edge_register_with_capabilities, edge_runtime_environment_capabilities, ASTRA_EDGE_ID_HEADER | astra-runtime-env, protocol, serde_json |
| crates/astra-thin-client/src/work.rs | work | Work 任务图 V2 严格解码契约与校验链 | WorkTaskGraphPageV2(validate), WorkTaskGraphItemV2, WorkItemExecutionStatusV2, WorkTaskCheckV2 等 | serde, chrono |
| crates/astra-thin-client/src/client.rs | client | reqwest 双客户端、认证头、全部 API 方法、SSE 流、429 重试、控制回调 | ThinClient, post_developer_loop(_retry_429), chat_stream, post_tool_result, post_approval, post_user_prompt_response, post_agents_edge_heartbeat, post_sync_outbox_event_json | reqwest, futures-util, async-stream, serde_json, astra-server-types, astra-sync-protocol, tokio, tracing |

### astra-mcp（7）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
| --- | --- | --- | --- | --- |
| crates/astra-mcp/src/lib.rs | 根 | crate 门面、超时常量 | MCP_CONNECT_TIMEOUT_SECS, MCP_TOOL_CALL_TIMEOUT_SECS, McpConnection, McpClientManager, McpTool | rmcp, 各子模块 |
| crates/astra-mcp/src/types.rs | types | 服务器配置/传输枚举/状态机/重试配置 | McpServerConfig, Transport, ConnectionState, RetryConfig | serde |
| crates/astra-mcp/src/error.rs | error | 错误类型与副作用未知判定 | McpError, side_effects_maybe, is_timeout | thiserror, rmcp |
| crates/astra-mcp/src/connection.rs | connection | rmcp 连接封装：客户端 handler、调用/超时/日志、四传输连接与退避重试、WS 桥 | McpConnection, CallLogEntry, connect_to_server, ChangeHandler(私有) | rmcp, tokio, tokio-tungstenite, reqwest, tracing, tools, classic_sse |
| crates/astra-mcp/src/classic_sse.rs | classic_sse | 经典 SSE 传输（endpoint 协商+POST 消息） | ClassicSseTransport(pub(crate)) | reqwest, rmcp, tokio, futures-util |
| crates/astra-mcp/src/manager.rs | manager | 多服务器管理：路由索引/冲突 fail-closed/两阶段接入/刷新 | McpClientManager, PreparedMcpConnection, McpToolCollision, call_tool_by_mcp_name | rmcp(model), tokio, connection, tools, types |
| crates/astra-mcp/src/tools.rs | tools | 工具名清洗、OpenAI schema 转换、结果提取、环境变量黑名单 | sanitize_tool_name, mcp_tool_to_schema, tools_to_schemas_checked, extract_result_text, McpToolCallResult, is_dangerous_env_var, MAX_RESULT_CONTENT_LENGTH | rmcp(model), serde_json, astra-turn-types |

### astra-harness（20）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
| --- | --- | --- | --- | --- |
| crates/astra-harness/src/lib.rs | 根 | 快照/钩子/裁决/验证器 trait、内存 sink | RuntimeSnapshot, HookPoint, DecisionRecord, HookVerdict, Verifier, SnapshotSink, InMemorySnapshotSink, HarnessKernel, Violation, Severity | serde, serde_json, tracing |
| crates/astra-harness/src/kernel.rs | kernel(私有) | 标准内核：验证器组装与 panic 隔离裁决 | StandardKernel, HarnessLimits, HarnessProfile | lib(核心类型), verifiers |
| crates/astra-harness/src/trace.rs | trace | 会话轨迹：记录内核、查询、原子持久化、隐私脱敏 | SessionTrace, TraceOutcome, RecordingKernel, PrivacyPolicy | serde, serde_json, tracing |
| crates/astra-harness/src/verifiers/mod.rs | verifiers | 验证器子模块门面 | BudgetVerifier, CompletionVerifier, ConfidenceVerifier, CostVerifier, DelegationVerifier, ProgressVerifier, ToolGuardVerifier, TurnGuardVerifierAdapter | — |
| crates/astra-harness/src/verifiers/budget.rs | verifiers | turns/tokens/时长预算（Fatal, critical） | BudgetVerifier | lib |
| crates/astra-harness/src/verifiers/completion.rs | verifiers | 终态可分类性（拒绝空成功） | CompletionVerifier | lib, astra-turn-core(InterruptionKind) |
| crates/astra-harness/src/verifiers/confidence.rs | verifiers | 连续错误/停滞+错误的自知信号 | ConfidenceVerifier | lib |
| crates/astra-harness/src/verifiers/cost.rs | verifiers | 四桶 token 成本估算（critical） | CostVerifier | lib |
| crates/astra-harness/src/verifiers/delegation.rs | verifiers | 委派频次/递归深度守护 | DelegationVerifier | lib |
| crates/astra-harness/src/verifiers/progress.rs | verifiers | 只读停滞检查点与冗余读告警 | ProgressVerifier | lib |
| crates/astra-harness/src/verifiers/tool_guard.rs | verifiers | 敏感工具告警与会话调用上限 | ToolGuardVerifier | lib |
| crates/astra-harness/src/verifiers/turn_guard.rs | verifiers | 同工具签名停滞检测桥接 | TurnGuardVerifierAdapter | lib |
| crates/astra-harness/src/adjust.rs | adjust | 运行中参数调整命令通道 | AdjustCommand, AdjustSender/Receiver, adjust_channel | std mpsc, debug(Breakpoint) |
| crates/astra-harness/src/query.rs | query | 外部快照查询通道 | HarnessQuery, HarnessQuerySender/Receiver, query_channel | std mpsc, lib, snapshot_diff |
| crates/astra-harness/src/debug.rs | debug | 断点内核（5 种断点条件→Pause） | DebugKernel, Breakpoint | lib, std RwLock |
| crates/astra-harness/src/forensics.rs | forensics | 轨迹取证摘要与自动告警 | ForensicsSummary, TurnContext, WarningKind, SessionTrace::forensics_summary | trace, serde |
| crates/astra-harness/src/rollback.rs | rollback | 回滚可行性评估 | RollbackAssessment, RollbackFeasibility, SessionTrace::assess_rollback | trace, HookPoint, serde |
| crates/astra-harness/src/scenario.rs | scenario | 断言 DSL 与场景结果 | Scenario, Assertion, ScenarioResult, AssertionResult | trace, forensics |
| crates/astra-harness/src/snapshot_diff.rs | snapshot_diff(私有) | 相邻快照增量 | SnapshotDiff | lib, serde |
| crates/astra-harness/src/capability_matrix.rs | capability_matrix | 37 条能力矩阵清单与清单/轨迹契约校验 | CAPABILITY_CASES, CapabilityCase, CapabilityQuadrant, Topology, ModelValidation, validate_capability_matrix, verify_trace_contract, MatrixIssue, TraceContractViolation | serde, trace |

### 5.5 文件清单（astra-turn-types 27 + astra-turn-core 223 = 250 个生产 .rs 文件）

路径相对 `Astra-0.2.4/`。`关键导出`列为主要 pub 类型/函数（节选）；`主要依赖`列出显著外部 crate 或内部模块。

#### astra-turn-types/src（27 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| crates/astra-turn-types/src/lib.rs | crate 根 | 契约层门面，re-export 全部类型 | 模块声明+pub use | - |
| crates/astra-turn-types/src/agent_communication.rs | 代理通信 | 代理间通信事件契约（方向/方/载荷种类） | AGENT_COMMUNICATION_SCHEMA_VERSION, AgentCommunicationEvent | serde |
| crates/astra-turn-types/src/agent_transcript_evidence.rs | 转录证据 | 随单代理转录内联展示的持久非会话证据 | AgentTranscriptEvidence | serde, agent_communication |
| crates/astra-turn-types/src/agent_transcript_location.rs | 转录位置 | 一次代理运行规范会话的权威存储位置 | AgentTranscriptLocation | serde |
| crates/astra-turn-types/src/canonical_tool_pairing.rs | 工具配对 | 提供方中立规范工具证据的确定性校验（只查协议身份与顺序） | validate_canonical_tool_pairing | serde, thiserror |
| crates/astra-turn-types/src/context_identity.rs | 上下文身份 | 内容寻址提示前缀与产物证据契约 | PromptCacheIdentityV1, LlmArtifactEvidenceManifestV1 | sha2, serde |
| crates/astra-turn-types/src/context_window.rs | 上下文窗口 | 类型化窗口占用事实（与计费分离） | ContextWindowUsage, RequestTokenUsage | serde |
| crates/astra-turn-types/src/inference.rs | 推理 | 推理调用范围/目的/模型选择；客户端直执行字段拒绝 | InferencePurpose, ModelSelection, CLIENT_DIRECT_EXECUTION_FIELDS | serde |
| crates/astra-turn-types/src/memory_ranking.rs | 记忆 L3 | Memoria 召回整形（不再叠加 tier 乘数） | RankableMemory, sort_by_retrieval_score | serde |
| crates/astra-turn-types/src/memory_structure.rs | 记忆 L2 | 持久记忆类型结构门与内容校验 | should_store_persistent_memory, PERSISTENT_MEMORY_TYPES | astra-prompts, regex |
| crates/astra-turn-types/src/phase_receipt.rs | 阶段回执 | 版本化传输安全的 Turn 阶段完成回执 | TurnPhaseReceiptV1, TurnPhaseKindV1 | serde |
| crates/astra-turn-types/src/provider_canonical_transition.rs | 提供方 WAL | 规范消息写前日志身份（HTTP 授权前提交） | ProviderCanonicalTransitionV2, MAX_*_BYTES 常量族 | serde, thiserror |
| crates/astra-turn-types/src/provider_contract.rs | 提供方契约 | 协议无关提供方发现/工具身份/声明信任 | ProviderClaim, ResolvedToolDescriptor, StableToolAlias | serde, thiserror |
| crates/astra-turn-types/src/result_quality.rs | 结果质量 | 工具结果超越成败的分级 | ResultQuality, classify_result, quality_feedback | - |
| crates/astra-turn-types/src/resume.rs | 恢复投影 | 恢复束/候选/因果投影与选择 | ResumeBundleV1, select_resume_bundle | serde, thiserror, session_cursor |
| crates/astra-turn-types/src/runtime_scaffolding.rs | runtime 脚手架 | runtime 拥有消息的类型化标记与追加只读权限帧 | is_runtime_owned_message, mark_runtime_owned_message | serde |
| crates/astra-turn-types/src/semantic_read_cache.rs | 语义读缓存 | 提供方中立的纯读复用身份（需修订事实+属主范围） | SemanticReadCacheKey, SemanticReadObservation | serde, thiserror |
| crates/astra-turn-types/src/session_coordination.rs | 会话协调 | 多写者租约/执行授权/轮预约契约 | ConversationWriterLeaseV1, SignedExecutionGrantV1 | serde, sha2, thiserror |
| crates/astra-turn-types/src/session_cursor.rs | 会话游标 | 提交/增量/分支的规范身份与序列化长度 | SessionCursorV1, ConversationCommitV1, canonical_conversation_identity | serde, sha2 |
| crates/astra-turn-types/src/session_facts.rs | 会话事实 L1a | 系统跟踪会话事实纯模型与确定性渲染 | SessionFacts（pub mod） | serde |
| crates/astra-turn-types/src/session_fork.rs | 会话分叉 | 分叉清单（维度处置/证据/排除权威） | SessionForkManifestV1, SharedManifestPrefixV1 | serde, thiserror |
| crates/astra-turn-types/src/session_handoff.rs | 会话交接 | 交接记录/附件模式/清单增量与合法迁移 | SessionHandoffRecordV1, valid_transition | serde, thiserror |
| crates/astra-turn-types/src/token_estimate.rs | token 估计 | 版本化 tokenizer 无关权重（诊断用，不替代提供方 usage） | 估计器常量与函数 | serde |
| crates/astra-turn-types/src/tool_idempotency.rs | 工具幂等 | 重试安全分类（pipeline 与 turn-core 共享） | ToolIdempotency, classify_tool_idempotency | serde_json |
| crates/astra-turn-types/src/tool_invocation.rs | 工具调用身份 | 持久调用身份/状态机/结果字节上限 | ToolInvocationRecord, canonical_public_arguments_hash | serde, thiserror |
| crates/astra-turn-types/src/turn_provenance.rs | 轮来源 | 消息级 Turn 来源标记（_astra_turn_provenance） | TurnMessageProvenanceV1, mark_turn_message | serde_json, thiserror |
| crates/astra-turn-types/src/user_intent.rs | 用户意图 | judge 拥有的用户轮与目标关系语义 | UserTurnSemantics, mark_user_turn_semantics | serde_json |

#### astra-turn-core/src 根（96 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| crates/astra-turn-core/src/lib.rs | crate 根 | 模块声明与新旧路径 re-export 映射表 | 100+ 模块声明、别名 re-export | - |
| crates/astra-turn-core/src/action_compensation.rs | 行为补偿 | 显式审批理由与动作补偿判定 | explicit_approval_reason, primary_approval_reason | cloud::approval_policy |
| crates/astra-turn-core/src/active_conversation.rs | 活跃会话 | 会话游标/提交/增量的活跃视图管理 | ActiveConversation | astra-turn-types |
| crates/astra-turn-core/src/activity.rs | 活动 | 会话活动更新计划类型 | SessionActivityUpdatePlan | serde |
| crates/astra-turn-core/src/agent_live_event.rs | 代理直播 | 子代理直播事件流（输出/思考/工具/终止） | AgentLiveEvent, AgentLiveEventKind | serde |
| crates/astra-turn-core/src/alert_dispatcher.rs | 告警分发 | Phase13 webhook 告警通道（失败吞掉不崩溃） | AlertDispatcher | reqwest, tracing |
| crates/astra-turn-core/src/cache.rs | 会话缓存 | 基于 LruMap 的会话级缓存 | SessionCache | lru_map |
| crates/astra-turn-core/src/cache_diagnostics.rs | 缓存诊断 | 提示缓存断裂检测（系统/schema 哈希跨轮对比） | CacheBreakReason | serde_json |
| crates/astra-turn-core/src/cache_placement.rs | 缓存放置 | 提供方感知的易变提示内容放置与 CacheCapability | CacheCapability, CacheProtocol | - |
| crates/astra-turn-core/src/canonical_json.rs | 规范 JSON | crate 内规范 JSON 序列化 | to_string (pub(crate)) | serde_json |
| crates/astra-turn-core/src/capability.rs | 能力 | 能力驱动的工具面解析（LSP/git 可用性等） | Capability | - |
| crates/astra-turn-core/src/chat_history_openai.rs | 历史 | REPL 历史对 + 当前行 → OpenAI messages | build_openai_history | serde_json |
| crates/astra-turn-core/src/chat_turn_api_error.rs | API 错误 | 云 /chat 失败的用户可见串与重试常量 | CHAT_TURN_POST_MAX_RETRIES | - |
| crates/astra-turn-core/src/chat_turn_edge_profile.rs | 边缘画像 | /chat edge_profile 组装（cwd/git/技能清单） | edge_profile 构建函数族 | serde_json |
| crates/astra-turn-core/src/chat_turn_explain_wire.rs | explain 线格式 | edge /chat payload 的 explain 字段序列化 | explain 序列化函数 | serde_json |
| crates/astra-turn-core/src/chat_turn_heuristics.rs | 回合画像 | 回合执行 profile、会话错误分类、记忆仓抽取（不做关键词意图推断） | TaskExecutionProfile 等 | astra-core |
| crates/astra-turn-core/src/chat_turn_payload.rs | 回合载荷 | /chat JSON 体骨架与 edge_tools/tool_results 装配 | chat_turn_base_payload, attach_filtered_edge_tools, set_payload_tool_results_if_non_empty | serde_json |
| crates/astra-turn-core/src/chat_turn_sse_dispatch.rs | SSE 语义分发 | /chat/turn SSE 事件块 JSON 分派与累加器（4135 行） | ChatTurnSseAccum, dispatch_chat_turn_sse_event_block, ChatTurnSseFramer | serde_json, astra-thin-client |
| crates/astra-turn-core/src/chat_turn_step_plan.rs | 步计划 | payload 组装后的 StepRecorder Plan 阶段 | record_agentic_step_plan_after_payload_prep | astra-pipeline |
| crates/astra-turn-core/src/circuit_breaker.rs | 断路器 | edge→cloud 桥三态断路器 | CircuitBreaker, allow_request | astra-core(sync_poison) |
| crates/astra-turn-core/src/compaction_types.rs | 压缩类型 | CompactionTier/Kind 等跨 crate 压缩类型 | CompactionTier | serde |
| crates/astra-turn-core/src/complete.rs | 回合完成 | 回合完成事实与 turn_complete 事件构建 | TurnCompletionFacts, build_turn_complete_event | serde_json, stall |
| crates/astra-turn-core/src/compression_types.rs | 压缩契约 | 从 context_compression 抽出的纯类型与 trait | 压缩 trait 族 | serde |
| crates/astra-turn-core/src/concurrency_safety.rs | 并发安全 | 动态/MCP 工具的进程级并发安全注册表 | DynamicToolConcurrencyRegistry | dashmap |
| crates/astra-turn-core/src/confidence_contract.rs | 置信契约 | 工具面路由低置信时的显式回退契约与遥测 | ConfidenceFallback | serde_json |
| crates/astra-turn-core/src/contracts.rs | 契约 | turn 核心服务契约 trait（活动更新/快照链接） | trait 契约 | async-trait |
| crates/astra-turn-core/src/decision_explainer.rs | 决策解释 | 工具选择/历史压缩等决策的人类可读解释 | explain 函数族 | serde_json |
| crates/astra-turn-core/src/delegation_tree.rs | 委派树 | 代理层级 ASCII 树渲染 | render_delegation_tree | std |
| crates/astra-turn-core/src/e2e_hooks.rs | E2E 钩子 | feature 门控确定性全栈测试钩（无真实 LLM） | e2e 钩子类型 | serde_json |
| crates/astra-turn-core/src/edge_ledger.rs | 边缘账本 | §5.5 回调账本：键与至多一次消费语义 | EdgeCallbackLedger | serde_json |
| crates/astra-turn-core/src/edge_prompt_context.rs | 边缘提示 | CLI 与 bridge 共享的 edge_profile.workspace/文件上下文 | make_args_preview | tool::args::hints |
| crates/astra-turn-core/src/emergent_context.rs | 涌现上下文 | Execute(N)→Bind(N+1) 回流与陈旧防护 | EmergentContext | serde |
| crates/astra-turn-core/src/error_recovery.rs | 错误恢复 | 错误分类委托、指数退避重试、替代工具建议 | should_retry_with_hint, suggest_alternatives | astra-core, fastrand |
| crates/astra-turn-core/src/evaluation.rs | 回合评估 | 多信号回合成功/质量评估引擎（5756 行） | 评估器类型族 | serde_json |
| crates/astra-turn-core/src/execution_state.rs | 执行状态 | 执行状态 Map 规范化（blocked_tools 等） | normalize_execution_state | serde_json |
| crates/astra-turn-core/src/explain.rs | explain 事件 | explain JSON 事件构建 | build_explain_event | serde_json |
| crates/astra-turn-core/src/explain_report_lines.rs | explain 报告 | --explain stderr 纯文本行 | EXPLAIN_REPORT_HEADER 等常量 | - |
| crates/astra-turn-core/src/file_edit_journal.rs | 编辑日志 | 文件变更前态日志支持轮/文件级回滚 | FileEditJournal | serde_json, chrono |
| crates/astra-turn-core/src/followup_suggestion.rs | 后续建议 | 验证/提交/推送建议枚举与构建 | FollowupSuggestionKind | serde_json |
| crates/astra-turn-core/src/history.rs | 历史 | 工具结果哨兵标签与历史消息共享助手 | find_tool_call_safe_split 等 | serde_json |
| crates/astra-turn-core/src/hook_plans.rs | 钩子计划 | 快照链接计划类型 | SnapshotLinkPlan | serde |
| crates/astra-turn-core/src/hydrate_reflect.rs | reflect 补水 | 无头路径 reflect 占位输出替换为真实获取 | hydrate 反思函数 | astra-thin-client |
| crates/astra-turn-core/src/injection_tracking.rs | 注入跟踪 | 每通道新鲜度跟踪（防陈旧注入长期滞留） | InjectionChannelState | serde_json |
| crates/astra-turn-core/src/interaction_types.rs | 交互类型 | 从 agentic_loop_host 抽出的交互模式共享类型 | TurnInteractionMode, tool_counts_as_external_observation | serde_json |
| crates/astra-turn-core/src/interruption.rs | 中断记录 | 每条早退路径的结构化中断记录（可恢复） | InterruptionRecord, InterruptionReason | serde |
| crates/astra-turn-core/src/introspect.rs | 自省工具 | budget 自适应的 introspect 工具主体（2385 行） | introspect 执行 | astra-core, introspect/* |
| crates/astra-turn-core/src/invocation_ledger.rs | 调用账本 | 纯持久调用账本状态机（prepare/CAS 契约） | InvocationLedger | serde_json |
| crates/astra-turn-core/src/liquid_step_signals.rs | 步信号 | 轮内每工具调用结果信号收集与适应触发 | StepOutcome, AdaptationTrigger | serde_json |
| crates/astra-turn-core/src/liquid_tactical.rs | 战术适应 | 评估步信号产出有界轮内变异（带阻尼） | TacticalAdapter | liquid_step_signals |
| crates/astra-turn-core/src/llm_request_dump.rs | 请求转储 | 错误时全量 LLM 请求落盘+云事件 | dump 函数 | serde_json, dirs |
| crates/astra-turn-core/src/loop_circuit_breaker.rs | 循环断路器 | agentic 循环异常断路（失速/退步才介入） | LoopCircuitBreaker, BreakerAction | serde_json |
| crates/astra-turn-core/src/lru_map.rs | LRU | crate 内 LRU Map 原语 | LruMap (pub(crate)) | std |
| crates/astra-turn-core/src/microcompact.rs | 微压缩 | 每轮调用前清理旧工具结果（双触发、provider 策略占位符，2375 行） | CompactStrategy, PromptCacheProtocol, is_cleared_content | serde_json, cache_placement |
| crates/astra-turn-core/src/observer.rs | 观察者 | 结构化检测消息是否调用 memory 工具（知识抽取面） | observer 谓词 | serde_json |
| crates/astra-turn-core/src/optimize_limits.rs | 优化门限 | 每优化变换独立布尔门的门限集 | OptimizeLimits, for_tier, all_closed | - |
| crates/astra-turn-core/src/parallel_tool_exec.rs | 并行工具执行 | 读/写分类、进程级信号量、并行轮执行（D-1） | execute_parallel_round, is_read_only_tool_with_args, shared_tool_semaphore | tokio, serde_json |
| crates/astra-turn-core/src/plan_mode_policy.rs | 计划模式策略 | 纯 plan 模式 args 感知工具阻断策略 | is_plan_mode_blocked_tool, is_plan_control_tool | tool::categories |
| crates/astra-turn-core/src/prepare_turn_explain_text.rs | explain 文本 | payload 准备期 --explain 文本行 | 有限工具集文本函数 | std |
| crates/astra-turn-core/src/prompt_facing.rs | 提示面投影 | 会话消息到稳定提示输入的规范化（剔执行痕迹） | prompt-facing 转换 | astra-turn-types |
| crates/astra-turn-core/src/provider_resolution.rs | 提供方解析 | 发现声明→不可变语义描述符（唯一可信赋层） | ResolvedInvocationPolicy | astra-turn-types |
| crates/astra-turn-core/src/rate_limit_cooldown.rs | 限流冷却 | 429/529 冷却与模型回退 + 指标 | RateLimitCooldown, CooldownReason | pipeline_metrics |
| crates/astra-turn-core/src/reasoning_capabilities.rs | 推理能力 | 提供方/模型感知的推理重放策略推导 | ReasoningReplayPolicy | serde |
| crates/astra-turn-core/src/recent_arg_hints.rs | 参数提示 | 近期工具参数滑窗提取注入（复用已知好参数） | RecentArgHints 提取 | serde_json |
| crates/astra-turn-core/src/recovery_state.rs | 恢复状态 | PTL/升级/压缩尝试计数，供 Plan 升级 | RecoveryState, should_abort | serde, tracing |
| crates/astra-turn-core/src/response_guard.rs | 响应守卫 | 泄漏/回声/重复/内部协议输出的检测与替换 | apply_response_guards, PROMPT_LEAK_FALLBACK | tool::args::shape |
| crates/astra-turn-core/src/resume_hydration.rs | 恢复补水 | 不依赖可选工具的确定性续会提示 | build_resume_hints | astra-turn-types |
| crates/astra-turn-core/src/retrieval.rs | 检索 | 词法检索打分助手 | 检索函数族 | astra-text-utils |
| crates/astra-turn-core/src/routing.rs | 路由 | 跳过路由的元数据构建 | build_skipped_routing_metadata | serde_json |
| crates/astra-turn-core/src/runtime_scaffolding.rs | runtime 脚手架 | 技能自动路由等 runtime 注入消息构造 | skill-auto-route 前缀与构造器 | astra-turn-types |
| crates/astra-turn-core/src/safety_middleware.rs | 安全中间件 | shell 混淆/zsh 危险/注入模式/破坏 SQL 判定（2730 行） | evaluate_tool_safety_request, SafetyMiddlewareDecision | astra-sandbox, astra-tools |
| crates/astra-turn-core/src/section_types.rs | 节类型 | SectionKind/CacheScope/压缩优先级与 token 估算 | SectionKind, estimate_text_tokens, BoundSection | serde |
| crates/astra-turn-core/src/semantic_read_cache.rs | 语义读缓存 | 有界语义读观测缓存状态机（填充围栏+限额） | 语义缓存状态机 | astra-turn-types |
| crates/astra-turn-core/src/session_latches.rs | 会话闩锁 | 一次性会话稳定闩（防缓存前缀断裂） | SessionLatches, latch_header | serde |
| crates/astra-turn-core/src/spill_backend.rs | 溢出后端 | 超限节内容外存为引用（管线保持纯） | SpillBackend trait | serde |
| crates/astra-turn-core/src/sse_events.rs | SSE 事件 | Server→Edge 事件信封与版本编码 | 事件信封类型 | base64, serde |
| crates/astra-turn-core/src/stall.rs | 失速检测 | 签名/名称失速、发散、奖励作弊启发 | SERVER_STALL_WINDOW, detect_cli_tool_sig_stall, trailing_identical_sig_depth | serde_json |
| crates/astra-turn-core/src/state.rs | 状态 | 新会话 state JSON 条目 | new_session_entry | serde_json |
| crates/astra-turn-core/src/stream_events.rs | 流事件 | 流事件类型（与 sse_events 分离的协议层） | StreamEvent 族 | serde |
| crates/astra-turn-core/src/streaming_tool_exec.rs | 流式工具执行 | 只读工具流中投机执行（D-9，env 门控） | should_speculate, StreamingToolExecutor | tokio, parallel_tool_exec |
| crates/astra-turn-core/src/sync_utils.rs | 同步工具 | 毒化 RwLock 恢复助手 | rwlock_read_clone_or_default 等 | std |
| crates/astra-turn-core/src/tail_persist.rs | 尾持久化 | turn hook 参数构建 | build_turn_hook_args | serde_json |
| crates/astra-turn-core/src/thinking_config.rs | 思考配置 | 提供方无关 thinking/扩展推理配置（1369 行） | ThinkingConfig | serde |
| crates/astra-turn-core/src/token_accounting.rs | token 台账 | 四不相交桶结构与比率 | TokenAccounting, cache_hit_ratio | astra-turn-types |
| crates/astra-turn-core/src/tool_allowlist.rs | 工具允许表 | 请求级×技能级 AND 交集允许表 | compute_effective_allowlist, normalize_tool_name | astra-text-utils |
| crates/astra-turn-core/src/tool_ledger_receipt.rs | 工具账本回执 | server 拥有执行账本的有界终态证明（滚动根摘要） | ToolLedgerReceipt, EMPTY_TOOL_LEDGER_ROOT | serde |
| crates/astra-turn-core/src/trace_alert.rs | trace 告警 | 每回合 trace 上的自动告警规则（非异常） | TraceAlert, 规则评估 | serde |
| crates/astra-turn-core/src/trace_event.rs | trace 事件 | DB Web 会话可追溯的进程内 trace 事件 | TraceEvent trait | async-trait, chrono, uuid |
| crates/astra-turn-core/src/turn_event_sink.rs | 回合事件槽 | 中断可恢复的增量回合状态共享槽 | TurnEventSink | tokio, serde_json |
| crates/astra-turn-core/src/turn_guard.rs | 回合守卫 | 组合式非幸福路径评估（失速/发散/健康/恢复，2466 行） | TurnGuard, TurnVerdict, VerdictSeverity | astra-turn-types |
| crates/astra-turn-core/src/turn_metrics.rs | 回合指标 | 质量载荷小助手 | build quality payload | serde_json |
| crates/astra-turn-core/src/turn_trace_collector.rs | trace 收集器 | 线程安全 trace 聚合与会话 journal 落盘 | TurnTraceCollector | tokio, serde_json |
| crates/astra-turn-core/src/view.rs | 视图 | 最新用户查询提取等视图助手 | extract_latest_user_query | serde_json, history |
| crates/astra-turn-core/src/working_memory.rs | 工作记忆 | 跨压缩存活的有界决策/阻碍/下一步状态 | WorkingMemoryState, apply_user_correction, render_prompt_section | astra-turn-types |
| crates/astra-turn-core/src/ws_approval_gate.rs | WS 审批门 | WebSocket 工具审批门桥（mpsc+回调账本） | WsApprovalGate | astra-tools, tokio, edge_ledger |
| crates/astra-turn-core/src/ws_user_prompt_gate.rs | WS 提问门 | WebSocket ask_user 门桥 | WsUserPromptGate | astra-tools, tokio, edge_ledger |
| crates/astra-turn-core/src/xml_tool_call_fallback.rs | XML 回退 | 文本形式工具调用降级解析（invoke XML/JSON 块，1430 行） | 解析函数族 | regex, serde_json |

#### astra-turn-core/src/agentic（9 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| crates/astra-turn-core/src/agentic/mod.rs | agentic | 模块声明 | - | - |
| crates/astra-turn-core/src/agentic/post_tool_policy.rs | agentic | 工具轮后 TurnGuard 观测+checkpoint+衰减建议 | apply_agentic_post_tool_policy, PolicyAdvisory | astra-pipeline, turn_guard |
| crates/astra-turn-core/src/agentic/prepare_payload.rs | agentic | schema 解析后给 /chat payload 挂受限过滤 edge_tools | attach_filtered_edge_tools_to_payload | chat_turn_payload |
| crates/astra-turn-core/src/agentic/recursion_guard.rs | agentic | 代理递归绝对上限 8 | ABSOLUTE_MAX_AGENT_RECURSION_DEPTH, checked_child_recursion_depth | - |
| crates/astra-turn-core/src/agentic/stall_preflight.rs | agentic | 轮前签名失速预检（3 轮 stall/5 轮咨询） | apply_cli_agentic_stall_preflight, REPETITION_THRESHOLD_EVENT | stall, turn_guard |
| crates/astra-turn-core/src/agentic/turn_flow.rs | agentic | ingest/预检/explain 聚合的粘合层 | agentic_round_stall_preflight, append_explain_turn_batch | stall_preflight, turn_guard |
| crates/astra-turn-core/src/agentic/turn_ingest.rs | agentic | 单轮流结果并入循环态并判定控制流 | ingest_agentic_turn_stream, AgenticTurnIngestOutcome | astra-core, response_guard, astra-pipeline |
| crates/astra-turn-core/src/agentic/turn_telemetry.rs | agentic | 首命中延迟与工具面报告遥测捕获 | 遥测结构 | tool::registry::report |
| crates/astra-turn-core/src/agentic/verdict_audit.rs | agentic | 非健康裁决的结构化审计行（不序列化） | AgenticVerdictAuditEvent | turn_guard |

#### astra-turn-core/src/approval（6 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| crates/astra-turn-core/src/approval/mod.rs | approval | 模块声明 | - | - |
| crates/astra-turn-core/src/approval/base_digest.rs | approval | 宿主生成文件摘要做陈旧重验 | BaseDigest 函数族 | - |
| crates/astra-turn-core/src/approval/batch_group.rs | approval | 审批卡 UI 批量分组键 | ApprovalBatchGroupKey | - |
| crates/astra-turn-core/src/approval/fingerprint.rs | approval | 内容感知审批指纹与拒绝节流（843 行） | ApprovalFingerprint::shell/file_op/bare, DenialTracker | serde_json |
| crates/astra-turn-core/src/approval/request_key.rs | approval | 严格请求同一性（队列去重+陈旧重验） | ApprovalRequestKey | serde_json |
| crates/astra-turn-core/src/approval/sink.rs | approval | NeedExternal 出口 trait + 三种 sink | ApprovalSink, ApprovalResponse, HeadlessFailClosedSink | async-trait, permission::engine |

#### astra-turn-core/src/cloud（10 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| crates/astra-turn-core/src/cloud/mod.rs | cloud | 模块声明 | - | - |
| crates/astra-turn-core/src/cloud/approval_policy.rs | cloud | 需 approval_required 往返的边工具分类（2066 行） | CloudGatedToolKind, cloud_gated_tool_kind_with_args | serde_json |
| crates/astra-turn-core/src/cloud/attachments.rs | cloud | 压缩后附件恢复重注入 | 附件恢复函数 | serde_json |
| crates/astra-turn-core/src/cloud/cache_diagnostics.rs | cloud | 提示缓存断裂原因检测与诊断日志 | CacheBreak 诊断 | serde_json |
| crates/astra-turn-core/src/cloud/compact_prompt.rs | cloud | 压缩提示模板 | 模板常量/构建 | - |
| crates/astra-turn-core/src/cloud/grouping.rs | cloud | 按 API 轮次分组消息（PTL 重试整轮丢弃） | 分组函数 | serde_json |
| crates/astra-turn-core/src/cloud/session_facts.rs | cloud | SessionFacts 的 journal 记录摄取适配 | 摄取函数 | astra-turn-types, astra-services |
| crates/astra-turn-core/src/cloud/session_memory_extract.rs | cloud | 轮中将变化状态抽取为规范工作内存快照 | 抽取函数 | astra-turn-types |
| crates/astra-turn-core/src/cloud/summary.rs | cloud | LLM 稠密会话摘要（tier≥AggressivePrune） | generate_compact_summary | astra-thin-client |
| crates/astra-turn-core/src/cloud/tool_delivery.rs | cloud | §5.5 云→边工具投递协议（审批门+tool_request+账本，2853 行） | 投递协议类型族 | serde_json |

#### astra-turn-core/src/context（12 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| crates/astra-turn-core/src/context/mod.rs | context | 模块声明 | - | - |
| crates/astra-turn-core/src/context/assembly_trace.rs | context | 装配深度可观测（系统分解/历史选择/丢弃） | AssemblyTrace | serde |
| crates/astra-turn-core/src/context/binder.rs | context | Bind 阶段：计划节→具体内容（纯内存） | bind_all, bind_sections | section_types |
| crates/astra-turn-core/src/context/budget.rs | context | 压缩档选择与分节 token 预算分配 | select_compaction_tier, select_tier_gated, TokenBudget::allocate | compaction_types |
| crates/astra-turn-core/src/context/feedback.rs | context | API 响应反馈回流 PipelineStats | RuntimeFeedbackFrame | serde, cache_diagnostics |
| crates/astra-turn-core/src/context/optimizer.rs | context | Optimize 阶段：缓存对齐预算适配变换（1772 行） | optimize, optimize_with_spill, rehydrate_sections | optimize_limits, spill_backend |
| crates/astra-turn-core/src/context/pipeline.rs | context | 管线编排（两遍 Plan 的 Plan→Bind→Optimize→Serialize） | ContextPipeline::run/run_adaptive, PipelineAbort | planner, binder, optimizer, serializer |
| crates/astra-turn-core/src/context/planner.rs | context | Plan 阶段纯函数：压力/tier/预算/缓存策略/节清单 | plan_turn, ContextPlan, PlanInput | budget, pressure, recovery_state |
| crates/astra-turn-core/src/context/pressure.rs | context | 原始/预测压力与 token 预留 | ContextPressure, ContextReserves | serde |
| crates/astra-turn-core/src/context/serializer/mod.rs | context | Serialize 阶段：provider 请求形状与缓存标记 | serialize_provider_request, system_blocks_to_anthropic_message | optimizer, pipeline_config |
| crates/astra-turn-core/src/context/serializer/wire_cache_annotations.rs | context | tools[]/messages[] 级 Anthropic 缓存注解 | annotate_last_message_cache_breakpoint | serde_json |
| crates/astra-turn-core/src/context/sources.rs | context | 管线类型化数据源目录（信息模式） | ContextSources | serde_json |

#### astra-turn-core/src/conversation_log（4 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| crates/astra-turn-core/src/conversation_log/mod.rs | conversation_log | CSL 追加日志类型（Snapshot+TurnDelta） | CslEntry, CslStore trait | serde |
| crates/astra-turn-core/src/conversation_log/db_store.rs | conversation_log | SQL 后端 CslStore（复合主键，feature db-store） | DbCslStore | sqlx(optional) |
| crates/astra-turn-core/src/conversation_log/file_store.rs | conversation_log | JSONL 后端 CslStore（边/CLI） | FileCslStore | tokio, serde_json |
| crates/astra-turn-core/src/conversation_log/manager.rs | conversation_log | 统一管理器：store+seq+快照+GC（1851 行） | CslManager::load/persist_turn/fork/reset | file_store, db_store |

#### astra-turn-core/src/fork（7 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| crates/astra-turn-core/src/fork/mod.rs | fork | 模块声明 | - | - |
| crates/astra-turn-core/src/fork/cache_event.rs | fork | fork 前缀缓存结果遥测事件 | ForkCacheEvent | serde |
| crates/astra-turn-core/src/fork/capture.rs | fork | 父轮可缓存前缀快照的捕获点纯函数 | capture 函数 | prefix |
| crates/astra-turn-core/src/fork/prefix.rs | fork | ForkPrefix 冻结字节级前缀快照（1182 行） | ForkPrefix | serde_json |
| crates/astra-turn-core/src/fork/prefix_store.rs | fork | 前缀存储（按父 run 键、有界+软 TTL） | PrefixCaptureSink | prefix, tokio |
| crates/astra-turn-core/src/fork/reconstruct.rs | fork | 由前缀重建子代理首请求消息数组 | reconstruct 函数 | prefix |
| crates/astra-turn-core/src/fork/resolve.rs | fork | spawn 侧继承规格解析（能否安全复用） | resolve 函数 | prefix_store |

#### astra-turn-core/src/guardrails（1 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| crates/astra-turn-core/src/guardrails/mod.rs | guardrails | 域重组门面（error_recovery/turn_guard/verdict_audit/explain_report_lines） | re-export | crate 内部 |

#### astra-turn-core/src/headless（7 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| crates/astra-turn-core/src/headless/mod.rs | headless | 模块声明 | - | - |
| crates/astra-turn-core/src/headless/assembly.rs | headless | 云 tool_calls 与 edge 执行行配对（§5.5，1489 行） | canonicalize_provider_tool_batch, take_edge_output_for_tool_call_with_duration, tool_calls_for_stall_guard | serde_json |
| crates/astra-turn-core/src/headless/body_preview.rs | headless | stderr 富预览（读体/统一 diff） | 预览类型 | tool::result::sanitize |
| crates/astra-turn-core/src/headless/journal.rs | headless | 早退路径 ToolCallRecord 行 | journal 记录函数 | astra-services |
| crates/astra-turn-core/src/headless/postprocess.rs | headless | 错误/限额富集与 TurnGuard 质量 | 后处理函数 | guardrails::error_recovery |
| crates/astra-turn-core/src/headless/status_display.rs | headless | 工具参数一行预览与执行后摘要 | 显示函数族 | astra-text-utils |
| crates/astra-turn-core/src/headless/stderr_lines.rs | headless | 无头工具轮纯 stderr 行 | 行文本函数 | - |

#### astra-turn-core/src/introspect（3 文件，另 introspect.rs 在根）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| crates/astra-turn-core/src/introspect/cache_diagnosis.rs | introspect | introspect(facet=cache) 四条纯函数诊断规则 | 规则函数族 | cache_diagnostics |
| crates/astra-turn-core/src/introspect/observation.rs | introspect | 观测平面归一化（深度/地平线/主题） | 观测类型族 | astra-core |
| crates/astra-turn-core/src/introspect/request.rs | introspect | introspect 参数解析为类型化观测请求 | 解析函数 | astra-core |

#### astra-turn-core/src/orchestration（9 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| crates/astra-turn-core/src/orchestration/mod.rs | orchestration | 模块声明 | - | - |
| crates/astra-turn-core/src/orchestration/agent_result_wire.rs | orchestration | 代理结果线格式（中断判定/完成原因） | 线格式类型族 | serde |
| crates/astra-turn-core/src/orchestration/builtin_agents.rs | orchestration | 内置代理类型定义 | 内置类型表 | std |
| crates/astra-turn-core/src/orchestration/context_cache.rs | orchestration | 跨代理文件内容+知识片段两级共享缓存 | ContextCache | tokio |
| crates/astra-turn-core/src/orchestration/fanout_group.rs | orchestration | 扇出组槽位纯核算（重试/失败/用户意图不变量） | AgentFanoutGroup | serde |
| crates/astra-turn-core/src/orchestration/progress.rs | orchestration | 子代理进度事件 | ProgressEvent | serde |
| crates/astra-turn-core/src/orchestration/spawn_tool.rs | orchestration | spawn 工具 schema 与继承前缀请求类型 | SpawnAgentRequest | serde |
| crates/astra-turn-core/src/orchestration/team_config.rs | orchestration | YAML 自定义代理类型（teams 目录） | TeamConfig 加载 | serde_yaml_ng |
| crates/astra-turn-core/src/orchestration/types.rs | orchestration | 零依赖纯类型（状态/指标/取消来源） | AgentStatus, CancellationOrigin | serde |

#### astra-turn-core/src/permission（16 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| crates/astra-turn-core/src/permission/mod.rs | permission | 模块声明 | - | - |
| crates/astra-turn-core/src/permission/audit.rs | permission | 三事件审计轨迹 | 审计事件构建 | serde_json |
| crates/astra-turn-core/src/permission/compound_command.rs | permission | 复合 shell 命令拆分为子命令展示 | split_compound_command | - |
| crates/astra-turn-core/src/permission/cwd_root.rs | permission | cwd 感知权限作用域的包根定位 | locate_package_root | std |
| crates/astra-turn-core/src/permission/engine.rs | permission | 共享纯权限评估引擎（14 槽判定序，3375 行） | evaluate_permission, HardDecision, DecisionEnvelope, RiskTag, EVALUATION_ORDER | astra-sandbox, safety_middleware |
| crates/astra-turn-core/src/permission/match_target.rs | permission | 作用域审批的未来请求匹配目标 | allow_rule_for_match_target | serde_json |
| crates/astra-turn-core/src/permission/memory_profile.rs | permission | memory 工具写入路径解析 | resolved_write_path | astra-sandbox |
| crates/astra-turn-core/src/permission/notice.rs | permission | 跨纯文本终端的结构化权限通知 | format_auto_approved_permission | - |
| crates/astra-turn-core/src/permission/path_glob.rs | permission | gitignore 风格路径 glob 匹配 | glob 匹配函数 | - |
| crates/astra-turn-core/src/permission/path_sensitivity.rs | permission | 敏感路径单一策略边界（.env/id_rsa/pem，1141 行） | sensitive_path_token_for_tool_args | serde_json |
| crates/astra-turn-core/src/permission/redact.rs | permission | 审批卡中密钥样值脱敏 | redact 函数族 | regex |
| crates/astra-turn-core/src/permission/rule_grammar.rs | permission | permissions.json 规则语法（fail-closed） | 规则解析/匹配 | serde |
| crates/astra-turn-core/src/permission/scope.rs | permission | 五档 Always 作用域策略 | AllowScope | serde |
| crates/astra-turn-core/src/permission/script_preview.rs | permission | 本地脚本调用内容预览 | 脚本预览 | std |
| crates/astra-turn-core/src/permission/sync.rs | permission | 父子权限同步消息与处理器 | PermissionRequestHandler | astra-messaging, types |
| crates/astra-turn-core/src/permission/types.rs | permission | 权限模式/继承/判定类型（1630 行） | PermissionMode, InheritedPermissions, PermissionDecision, PermissionSyncContext | serde, astra-messaging |

#### astra-turn-core/src/pipeline（7 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| crates/astra-turn-core/src/pipeline/mod.rs | pipeline | 模块声明 | - | - |
| crates/astra-turn-core/src/pipeline/config.rs | pipeline | 管线配置与 ProviderCachePolicy | PipelineConfig, ProviderCachePolicy | serde, microcompact |
| crates/astra-turn-core/src/pipeline/journal.rs | pipeline | 每回合 journal 事件（观测/审计） | PipelineJournalEvent | serde |
| crates/astra-turn-core/src/pipeline/metrics.rs | pipeline | 零依赖 Prometheus 兼容指标注册表 | MetricsRegistry | std |
| crates/astra-turn-core/src/pipeline/session.rs | pipeline | 会话级管线编排器（跨轮状态唯一入口，1589 行） | PipelineSession::run_turn/run_turn_adaptive, record_feedback | context::pipeline |
| crates/astra-turn-core/src/pipeline/session_serde.rs | pipeline | checkpoint 恢复 PipelineSession 的序列化助手 | 恢复函数 | serde_json |
| crates/astra-turn-core/src/pipeline/stats.rs | pipeline | 跨轮统计（响应估计/节 EMA/命中率） | PipelineStats | serde |

#### astra-turn-core/src/sse（5 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| crates/astra-turn-core/src/sse/mod.rs | sse | 模块声明 | - | - |
| crates/astra-turn-core/src/sse/blocks.rs | sse | 空行分帧 SSE 事件块缓冲（有损 UTF-8 容错） | SseBlankLineUtf8Buf, drain_complete_sse_event_blocks | - |
| crates/astra-turn-core/src/sse/data_lines.rs | sse | 逐行 data: 解析为 JSON（OpenAI 风格） | json_events_from_sse_event_block | serde_json |
| crates/astra-turn-core/src/sse/edge_stderr_lines.rs | sse | tool_request 实时与失败后纯 stderr 行 | 行文本函数 | - |
| crates/astra-turn-core/src/sse/stream_host.rs | sse | 宿主中立 SSE 消费状态机与 SseStreamHost trait（3925 行） | consume_sse_stream_cancellable, SseStreamHost, flush_pending_via_host | tokio, tokio-util, chat_turn_sse_dispatch |

#### astra-turn-core/src/stop_hooks（3 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| crates/astra-turn-core/src/stop_hooks/mod.rs | stop_hooks | 模块声明 | - | - |
| crates/astra-turn-core/src/stop_hooks/stop_hooks_yaml.rs | stop_hooks | .astra/stop-hooks.yaml 声明式停止钩加载合并分类 | load/merge/classify | serde_yaml_ng |
| crates/astra-turn-core/src/stop_hooks/types.rs | stop_hooks | 停止钩类型（注入用户消息走 bash 工具验证） | StopHook 类型族 | serde |

#### astra-turn-core/src/tool（33 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| crates/astra-turn-core/src/tool/mod.rs | tool | 模块声明 | - | - |
| crates/astra-turn-core/src/tool/deferred_activation.rs | tool | 延迟工具激活契约（select:NAME 后可执行） | 激活判定 | serde_json |
| crates/astra-turn-core/src/tool/runtime_binding.rs | tool | 需活运行时绑定的工具判定（MCP 名空间） | 判定函数 | capability, astra-core |
| crates/astra-turn-core/src/tool/args/mod.rs | tool::args | 模块声明 | - | - |
| crates/astra-turn-core/src/tool/args/hints.rs | tool::args | 规范键参数读取（path/command only）与权限提示细节 | path_hint_from_args, command_hint_from_args | serde_json |
| crates/astra-turn-core/src/tool/args/shape.rs | tool::args | tool_call 形状归一（嵌套/扁平、执行规范化） | tool_call_name, canonicalize_tool_call_for_execution | astra-core |
| crates/astra-turn-core/src/tool/categories/mod.rs | tool::categories | 工具行为元数据单一事实源（args 感知，2377 行） | classify, registry() | serde_json |
| crates/astra-turn-core/src/tool/categories/surface.rs | tool::categories | 能力驱动工具面解析 | surface 解析 | serde_json |
| crates/astra-turn-core/src/tool/categories/workaround.rs | tool::categories | 工具被限时的安全替代建议 | workaround 建议 | serde_json |
| crates/astra-turn-core/src/tool/health/mod.rs | tool::health | 每工具错误预算追踪（2262 行） | ToolHealthTracker | serde_json |
| crates/astra-turn-core/src/tool/health/persistence.rs | tool::health | 跨会话健康快照持久化 | 健康持久化 | serde_json, dirs |
| crates/astra-turn-core/src/tool/policy/mod.rs | tool::policy | 共享执行策略：并发分类与合批窗口 | is_tool_concurrency_safe, tool_batch_coalesce_duration | serde_json |
| crates/astra-turn-core/src/tool/policy/hooks.rs | tool::policy | pre/post 工具钩子框架（观察/修改/否决） | ToolHookRegistry, global_run_pre | async-trait, tokio |
| crates/astra-turn-core/src/tool/policy/preview.rs | tool::policy | 工具调用一行预览统一渲染（1199 行） | render 预览 | serde_json |
| crates/astra-turn-core/src/tool/registry/mod.rs | tool::registry | 模块声明 | - | - |
| crates/astra-turn-core/src/tool/registry/chain.rs | tool::registry | 工具组合链（模板变量数据流） | ToolChain | serde_json |
| crates/astra-turn-core/src/tool/registry/meta.rs | tool::registry | 静态 TOOL_CATALOG（中英触发词，1065 行） | TOOL_CATALOG, ToolMeta, IntentType | capability |
| crates/astra-turn-core/src/tool/registry/plugin.rs | tool::registry | 插件/技能清单动态注册 | PluginToolRegistry | serde_json |
| crates/astra-turn-core/src/tool/registry/report.rs | tool::registry | 工具面选择报告（journal 持久化） | ToolSelectionReport | serde |
| crates/astra-turn-core/src/tool/result/mod.rs | tool::result | 模块声明 | - | - |
| crates/astra-turn-core/src/tool/result/compression.rs | tool::result | 类型感知语义压缩（保结构，372 行） | compress_tool_result | serde_json |
| crates/astra-turn-core/src/tool/result/dedup.rs | tool::result | 无副作用调用短窗去重缓存 | ToolResultDedup | serde_json |
| crates/astra-turn-core/src/tool/result/sanitize.rs | tool::result | 剥离 CLI 专属载荷再上模型 API | sanitize 函数族 | regex |
| crates/astra-turn-core/src/tool/result/semantics.rs | tool::result | 边缘输出共享解读与稳定调用键（§5.5 去重） | tool_dedup_signature | serde |
| crates/astra-turn-core/src/tool/result/storage.rs | tool::result | 超阈值结果落盘+内存预览 | 持久化函数 | tokio, dirs |
| crates/astra-turn-core/src/tool/schema/mod.rs | tool::schema | 模块声明 | - | - |
| crates/astra-turn-core/src/tool/schema/prune.rs | tool::schema | 压力下 schema 修剪与已调用工具保留（882 行） | prune 函数族, PLAN_MODE_REQUIRED_TOOLS | serde_json |
| crates/astra-turn-core/src/tool/schema/surface_subset.rs | tool::schema | 结果轮工具子集规划 | plan_tool_subset_for_result_turn | std |

（注：tool 目录共 28 文件 = 根 3（mod/deferred_activation/runtime_binding）+ args 3 + categories 3 + health 2 + policy 3 + registry 5 + result 6 + schema 3。核心 crate 合计 223 文件 = 根 96 + agentic 9 + approval 6 + cloud 10 + context 12 + conversation_log 4 + fork 7 + guardrails 1 + headless 7 + introspect 3 + orchestration 9 + permission 16 + pipeline 7 + sse 5 + stop_hooks 3 + tool 28。）

按域分组的文件清单（共 **150** 个生产文件，路径相对 `crates/services/src/`；`byok_endpoint/proxy/tests.rs` 为测试已排除）：

**根模块（76）**

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| lib.rs | 根 | ~80 个模块声明与平铺 re-export；SharedPool 注入辅助 | `require_shared_pool`(L95) | astra-core |
| admin.rs | 认证与账户 | 管理端 trait 与 DTO 定义 | `AuthenticatedUser`, `AdminAuthorizer` 等 7 trait | axum |
| admin_config.rs | 审计与治理 | `admin_config` KV 表读写（白名单键） | `DatabaseAdminConfigService` | sqlx |
| agents.rs | 其他域 | agent_agents 表 CRUD（AgentService） | `DatabaseAgentService` | sqlx |
| agent_bindings.rs | 多智能体与 work | agent_bindings 表（agent↔会话/工具绑定） | `DatabaseAgentBindingService` | sqlx |
| agent_lessons.rs | 其他域 | 跨会话经验（lesson）类型与 prompt 净化 | `Lesson`, `sanitize_for_prompt` | serde_json |
| artifact_policy.rs | 审计与治理 | 工件预签名下载 URL 与 HMAC 签名 | `build_presigned_artifact_download` | hmac/sha2 |
| branches.rs | 会话族 | 会话分支服务（create/diff/merge/delete） | `DatabaseBranchService` | sqlx |
| byok_endpoint.rs | 模型与 BYOK | BYOK 端点 URL 校验/公共 IP 策略/DNS 钉扎客户端 | `endpoint_client`(L196), `require_endpoint_policy`(L126) | reqwest/hickory |
| config_version_cloud.rs | 同步引擎 | 内容寻址配置版本云存储 pull | `pull_all_into_local_store` | sqlx |
| context.rs | 会话族 | ctx_snapshots 上下文快照 CRUD | `DatabaseContextService` | sqlx |
| context_manifest.rs | 会话族 | 上下文清单存储与预算分配（8k 预算/委派预算） | `DatabaseContextManifestStore`, `BudgetV1_8k` | sqlx |
| coordination.rs | 多智能体与 work | 多智能体协调框架纯类型（profile/pattern/聚合） | `AgentProfileRegistry`, `aggregate_results` | 无（serde） |
| data_versioning.rs | 其他域 | 数据版本检查点（data_versioning_checkpoints） | `DatabaseDataVersioningService` | sqlx |
| db_row.rs | 横切 | MySQL 行解码统一（DATETIME/TIMESTAMP 差异） | `RowExt`, `RowDecoder` | sqlx |
| decisions.rs | 其他域 | 决策记录（ctx_decision_audits） | `DatabaseDecisionService` | sqlx |
| delegated_findings.rs | 多智能体与 work | 委派子代理发现的截断/封包 | `DelegatedFinding`, `truncate_chars` | serde_json |
| edge_context.rs | 同步引擎 | 类型化边缘上下文（profile/skill ref） | `EdgeContext`, `EdgeProfile` | serde |
| events.rs | 审计与治理 | 事件 API 服务（agent_events 写入侧） | `DatabaseEventService` | sqlx |
| event_ingestion.rs | 会话族 | journal→agent_events 异步摄入（优先级/预算/脱敏） | `IngestionSender`, `IngestionQueueReservation` | astra-core(history_work) |
| execution_grant.rs | 审计与治理 | HMAC 签名执行授权（run 身份防伪造） | `ExecutionGrantSigner::issue/verify`(L52/116) | hmac/sha2 |
| external_artifacts.rs | 其他域 | 外部工件 JSON 投影 | `project_external_artifacts` | serde_json |
| harness.rs | 其他域 | harness_* 6 表 + skillify 草稿/发布流水线 | `DatabaseHarnessService`, `SkillifyAgentExecutor` | sqlx |
| inference_execution.rs | 模型与 BYOK | 推理调用持久状态机（准入/尝试/结算/对账） | `admit_inference_invocation` 等（lib.rs:201-216） | sqlx |
| interaction_contract.rs | 会话族 | 审批/ask_user 阻塞交互语义契约（不建表） | `InteractionContract`, `InteractionStatus` | astra-turn-types |
| jobs.rs | 其他域 | 内存 job 队列 | `InMemoryJobService` | 无 |
| llm_trusted_domains.rs | 模型与 BYOK | runtime_llm_trusted_domains 管理 | `DatabaseLlmTrustedDomainService` | sqlx |
| marketplace.rs | 技能/MCP | 技能市场安装/凭据（skill_installations） | `DatabaseMarketplaceService` | sqlx |
| marketplace_stats.rs | 技能/MCP | 跨用户技能质量统计与搜索（skill_metrics） | `DatabaseMarketplaceStatsService` | sqlx |
| mcp_registry.rs | 技能/MCP | MCP 服务器/绑定/工具注册 | `DatabaseMcpRegistryService`, `mcp_schema_hash` | sqlx |
| models.rs | 模型与 BYOK | 模型目录（infra/user_llm_models）+ 解析/缓存/连通性探测 | `resolve_active_llm_model`(L1456), `DatabaseModelService` | sqlx/reqwest/fernet |
| model_request_context.rs | 模型与 BYOK | 单次物理模型请求的类型化无内容观测 | `MODEL_REQUEST_CONTEXT_SCHEMA`, `aggregate_model_request_metrics` | sqlx |
| pagination.rs | 横切 | 列表分页上限与 clamp | `MAX_API_LIST_LIMIT`, `clamp_api_list_pagination` | 无 |
| personal_skills.rs | 技能/MCP | 个人技能源/版本/评估/激活 | `DatabasePersonalSkillStore`, `normalize_skill_md` | sqlx |
| prompt_delta.rs | 模型与 BYOK | prompt 请求计划/持久化/计数（prompt_request_records） | `persist_prompt_request`, `plan_prompt_request` | sqlx |
| reflect.rs | 其他域 | 反思报告聚合（错误模式/决策/交付 rollup） | `DatabaseReflectService`, `ReflectReport` | sqlx |
| registry_payload.rs | 技能/MCP | (crate) 注册端点 URL 校验 | `validate_registered_endpoint_url` | regex |
| replay.rs | 会话族 | 会话重放与对比 | `DatabaseReplayService` | sqlx |
| resource_governor.rs | 认证与账户 | 按用户资源限额（会话/工具/token 日额） | `DatabaseResourceGovernor`, `LimitCheck` | sqlx |
| runs.rs | 会话族 | Run 生命周期/状态机/事件/投影持久化 | `RunStateStore`(L3557), `insert_run_record`(L11087) | sqlx/astra-turn-types |
| runtime_maintenance.rs | 审计与治理 | 后台维护扫描（sweeper_leases 游标） | `maintain_runtime_storage` | sqlx |
| sandbox.rs | 其他域 | 沙箱元数据（infra_sandbox_metadata） | `DatabaseSandboxService` | sqlx |
| self_surface.rs | 其他域 | "自我"面板聚合（预算/健康/日志等 surface） | `LocalSelfSurfaceService` | 无（读 journal） |
| semantic_read_observation_store.rs | 会话族 | 语义读观察缓存（会话行串行化） | `DatabaseSemanticReadObservationStore` | sqlx |
| service_error.rs | 横切 | 结构化服务错误 | `ServiceError`, `ServiceErrorKind` | thiserror |
| session_analytics.rs | 会话族 | journal 事件统计（会话/工具画像） | `compute_session_stats` | session_journal |
| session_artifact_store.rs | 会话族 | OwnerScope 抽象 + 本地/DB 工件存储 | `LocalSessionArtifactStore`, `OwnerScope` | sqlx/fs |
| session_audit.rs | 审计与治理 | agent_events 之上的 turn/tool/session 审计视图 | `TurnSummary`, `SessionAuditSummary` | sqlx |
| session_checkpoint.rs | 会话族 | 会话检查点 Markdown 文件写入/读取 | checkpoint 函数族 | fs |
| session_context_coordinator.rs | 会话族 | canonical 会话写者/turn 预留（session_context_heads） | `DatabaseSessionContextCoordinator` | sqlx |
| session_fork_coordinator.rs | 会话族 | O(1) 会话分叉（session_forks） | `DatabaseSessionForkCoordinator`, `PrepareSessionForkV1` | sqlx |
| session_handoff.rs | 会话族 | 跨位置会话 attach/handoff（session_handoffs） | `DatabaseSessionHandoffService` | sqlx/astra-turn-types |
| session_identity.rs | 会话族 | 持久化会话 ID 规范校验 | `validate_persisted_session_id` | 无 |
| session_journal.rs | 会话族 | 本地 JSONL 会话日志（事件/写入器/CAS/租约） | `JournalWriter`(L2296), `JournalEvent`(L1548) | fs2/serde_json |
| session_lifecycle.rs | 会话族 | (crate) 会话硬删除表驱动清删 | `SessionDeleteStatement` | sqlx |
| session_memory_inventory.rs | 会话族 | 会话记忆投影生命周期清单 | `load_database_session_memory_inventory` | sqlx/session_journal |
| session_restore.rs | 会话族 | MatrixOne+本地文件会话恢复 | `restore_session` | sqlx/fs |
| session_workspace.rs | 会话族 | 会话工作区元数据与上下文 trace 信号 | workspace 元数据类型 | session_journal |
| skills.rs | 技能/MCP | skills_registry CRUD | `DatabaseSkillService` | sqlx |
| skill_auto_route_judge.rs | 技能/MCP | LLM 技能自动路由判定 prompt/解析 | `SkillAutoRouteJudge`, `parse_skill_auto_route_response` | serde_json |
| skill_config.rs | 技能/MCP | skill_settings 配置校验/读写 | `DatabaseSkillConfigService` | sqlx |
| snapshot_sql.rs | 其他域 | MatrixOne 快照 SQL 生成/恢复 | `create_snapshot_for_db_sql` | sqlx |
| state_projection.rs | 同步引擎 | 会话状态投影写校验（session_state_items） | `validate_state_mutation`, `COMPACTION_INVARIANT_SQL` | sqlx |
| state_sync.rs | 同步引擎 | edge↔云元数据/偏好同步 | `MatrixOneSyncService`, `StateSyncService` | sqlx |
| storage.rs | 横切 | schema 引导（~120 表 DDL）+ 会话写准入 + 审计 | `ensure_core_schema`(L3323), `log_session_audit`(L8968) | sqlx |
| sync_engine.rs | 同步引擎 | 统一同步编排器（域适配器×云传输） | `SyncOrchestrator`(L598), `SyncEnvelope` | sha2 |
| sync_outbox.rs | 同步引擎 | 持久 edge→云 outbox（hash/重试/毒丸） | `SyncOutboxStore`(L301), `SyncOutboxRecord` | session_journal |
| team_persistence.rs | 多智能体与 work | team_definitions 等团队配置持久化 | `TeamPersistenceService` trait | sqlx |
| tool_invocation_ledger.rs | 多智能体与 work | 工具调用持久账本 + 归档（CAS） | `DatabaseToolInvocationLedger` | sqlx |
| triggers.rs | 其他域 | wf_triggers 触发器 CRUD | `DatabaseTriggerService` | sqlx |
| turn_intent_judge.rs | 技能/MCP | LLM 回合意图判定与 work 准入 | `TurnIntentJudge`, `parse_work_admission_response` | serde_json |
| verification.rs | 多智能体与 work | 验证契约与执行（LLM judge） | `VerificationRunner`, `VerifierKind` | async-trait |
| weighted_admission.rs | 审计与治理 | 加权分布式准入（gates/reservations） | `DatabaseWeightedAdmissionController` | sqlx |
| work.rs | 多智能体与 work | Work 域边界：域类型+不变量+子模块声明 | `WorkRecord`(L1766), `WorkBranchRecord`(L1800) | thiserror/chrono |
| workflows.rs | 其他域 | 工作流定义/运行记录 | `WorkflowService` trait | sqlx |
| workspace_records.rs | 会话族 | 工作区记录与清理债存储 | `DatabaseWorkspaceRecordStore` | sqlx |

**auth/（10）**

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| auth/mod.rs | 认证与账户 | AuthService trait + DatabaseAuthService（登录/注册/刷新/吊销/边缘令牌） | `DatabaseAuthService`, `login`(L1699) | bcrypt/jsonwebtoken/sqlx |
| auth/jwt.rs | 认证与账户 | HS256/384/512 JWT 签发与解码 | `create_jwt_token`(L66), `decode_jwt_claims` | jsonwebtoken |
| auth/session.rs | 认证与账户 | SessionService + DatabaseSessionService（agent_sessions） | `DatabaseSessionService`, `create_session`(L468) | sqlx |
| auth/external.rs | 认证与账户 | 外部 provider 客户端/会话句柄加密/边缘吊销检查 | `HttpExternalProviderClient` | reqwest/fernet |
| auth/memoria.rs | 认证与账户 | Memoria 托管身份 provider 与凭据解析 | `MemoriaProvider`, `MemoriaCredentialResolver` | reqwest |
| auth/encryption.rs | 认证与账户 | Fernet 令牌加密器 + sha256_hex | `FernetTokenEncryptor` | fernet/sha2 |
| auth/admin.rs | 认证与账户 | 管理端数据库实现（角色/令牌/审计/统计） | `DatabaseAdminAuthorizer` 等 7 个 | sqlx/hmac |
| auth/provider_request.rs | 认证与账户 | provider 请求描述符与授权结果类型 | `ProviderRequestDescriptor` | serde |
| auth/validation.rs | 认证与账户 | 注册请求字段校验 | `validate_register_request` | 无 |
| auth/verified.rs | 认证与账户 | 已验证身份（Memoria）绑定辅助 | (内部类型) | 无 |

**byok_endpoint/（2，不含 proxy/tests.rs）**

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| byok_endpoint/dns.rs | 模型与 BYOK | 直连配置 DNS 解析（防 Fake-IP） | `resolve`(L71) | hickory-resolver |
| byok_endpoint/proxy.rs | 模型与 BYOK | 出口代理 CONNECT/SOCKS5 本地适配器 | `client`(L265), `EgressProxy` | rustls/tokio |

**evaluation/（6）**

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| evaluation/mod.rs | 其他域 | evaluation 域聚合声明 | `DatabaseEvaluationService` | — |
| evaluation/service.rs | 其他域 | EvaluationService trait | `EvaluationService` | async-trait |
| evaluation/database.rs | 其他域 | eval_* 表数据库实现（趋势/门禁/质量） | `DatabaseEvaluationService`(L1289) | sqlx |
| evaluation/types.rs | 其他域 | 漂移/变更/循环/导出类型 | `DriftSeverity`, `QualityTrendQuery` | serde |
| evaluation/noop.rs | 其他域 | 未配置空实现 | `UnconfiguredEvaluationService` | — |
| evaluation/utils.rs | 其他域 | 评估辅助函数 | (内部) | — |

**introspection/（3）**

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| introspection/mod.rs | 其他域 | introspection 域聚合 | `DatabaseIntrospectionService` | — |
| introspection/database.rs | 其他域 | get_agent_info 云侧数据库查询 | `DatabaseIntrospectionService`(L26) | sqlx |
| introspection/scoring.rs | 其他域 | 上下文健康/区域平衡/污染打分（纯 Rust 数值） | `ContextHealthResult`, `ZoneBalanceResult` | — |

**models/（1）**

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| models/thinking_probe.rs | 模型与 BYOK | 可持久化思考探测观察类型（显式检查才做 I/O） | thinking probe record 类型 | serde |

**multi_agent/（4）**

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| multi_agent/mod.rs | 多智能体与 work | 域聚合 + re-export | `EdgeRegistryService` 等 | — |
| multi_agent/edge_registry.rs | 多智能体与 work | 边缘 agent 注册/租约/心跳（edge_agent_registry） | `DatabaseEdgeRegistryService`(L530) | sqlx |
| multi_agent/edge_dispatch.rs | 多智能体与 work | 跨 pod 派发与唤醒（edge_pending_dispatch） | `DatabaseEdgeDispatchService`, `EdgeDispatchWakeHub` | sqlx/tokio |
| multi_agent/metrics.rs | 多智能体与 work | 多智能体延迟/吞吐指标 | `MultiAgentMetrics`(L91) | 无 |

**reflect/（2，reflect.rs 在根）**

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| reflect/observation.rs | 其他域 | 反思观察记录类型/解析 | (内部类型) | serde |
| reflect/request.rs | 其他域 | 反思请求 DTO | `ReflectRequest`(L11) | serde |

**work/（46）**

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| work/repository.rs | 多智能体与 work | WorkRepository 总仓储 trait 与错误分类 | `WorkRepositoryError`(L92) | thiserror/sqlx |
| work/acceptance.rs | 多智能体与 work | 交付验收域类型 | acceptance 类型 | thiserror |
| work/acceptance_repository.rs | 多智能体与 work | 验收记录 SQL 持久化 | (repository impl) | sqlx |
| work/attempt_settlement.rs | 多智能体与 work | 工作项执行尝试的终态结算逻辑 | settlement 类型/函数 | sqlx |
| work/attention.rs | 多智能体与 work | 关注项（attention）域类型 | attention 类型 | serde |
| work/attention_repository.rs | 多智能体与 work | 关注项 SQL 持久化 | (repository impl) | sqlx |
| work/basis.rs | 多智能体与 work | 基准（basis）域类型 | basis 类型 | serde |
| work/basis_repository.rs | 多智能体与 work | 基准 SQL 持久化 | (repository impl) | sqlx |
| work/branch_catalog.rs | 多智能体与 work | Work 分支目录视图 | branch catalog 类型 | sqlx |
| work/branch_comparison.rs | 多智能体与 work | 分支间对比 | comparison 类型 | sqlx |
| work/branch_creation_operation.rs | 多智能体与 work | 分支创建操作（含会话绑定不变量） | creation operation | sqlx |
| work/branch_deletion_operation.rs | 多智能体与 work | 分支删除操作（保留约束） | deletion operation | sqlx |
| work/branch_retention.rs | 多智能体与 work | 分支保留策略类型 | retention 类型 | serde |
| work/branch_retention_repository.rs | 多智能体与 work | 保留策略 SQL 持久化 | (repository impl) | sqlx |
| work/catalog.rs | 多智能体与 work | Work 目录类型 | catalog 类型 | serde |
| work/catalog_repository.rs | 多智能体与 work | 目录 SQL 持久化 | (repository impl) | sqlx |
| work/control_operation.rs | 多智能体与 work | 控制/暂停/恢复操作 | control operation | sqlx |
| work/criteria.rs | 多智能体与 work | 验收标准域类型与校验 | criteria 类型 | thiserror |
| work/criteria_proposal.rs | 多智能体与 work | 标准变更提案域类型 | proposal 类型 | thiserror |
| work/criteria_proposal_acceptance_repository.rs | 多智能体与 work | 提案接受 SQL 持久化 | (repository impl) | sqlx |
| work/criteria_proposal_repository.rs | 多智能体与 work | 标准提案 SQL 持久化 | (repository impl) | sqlx |
| work/criteria_read_repository.rs | 多智能体与 work | 标准只读查询 | (repository impl) | sqlx |
| work/delivery_selection.rs | 多智能体与 work | 交付选择域类型 | delivery selection | serde |
| work/delivery_selection_repository.rs | 多智能体与 work | 交付选择 SQL 持久化 | (repository impl) | sqlx |
| work/events.rs | 多智能体与 work | Work 事件域类型 | work events | serde |
| work/events_repository.rs | 多智能体与 work | Work 事件 SQL 持久化 | (repository impl) | sqlx |
| work/event_read_repository.rs | 多智能体与 work | Work 事件只读查询 | (repository impl) | sqlx |
| work/evidence.rs | 多智能体与 work | 证据（evidence）域类型 | evidence 类型 | thiserror |
| work/evidence_repository.rs | 多智能体与 work | 证据 SQL 持久化 | (repository impl) | sqlx |
| work/graph.rs | 多智能体与 work | Work 图（目标/任务关系）域类型 | work graph | serde |
| work/graph_repository.rs | 多智能体与 work | Work 图 SQL 持久化 | (repository impl) | sqlx |
| work/observation.rs | 多智能体与 work | 观察记录域类型（含截断约束） | observation 类型 | thiserror |
| work/observation_repository.rs | 多智能体与 work | 观察 SQL 持久化 | (repository impl) | sqlx |
| work/patch_artifact.rs | 多智能体与 work | 补丁工件域类型 | patch artifact 类型 | serde |
| work/patch_artifact_repository.rs | 多智能体与 work | 补丁工件 SQL 持久化 | (repository impl) | sqlx |
| work/patch_commit.rs | 多智能体与 work | 补丁提交（原子落库）操作 | patch commit 操作 | sqlx |
| work/patch_materialization.rs | 多智能体与 work | 补丁物化到目标会话/提供方 | `WorkPatchMaterializationRequest` | sqlx |
| work/plan_context.rs | 多智能体与 work | 计划上下文（plan 绑定） | plan context 类型 | sqlx |
| work/plan_context_repository.rs | 多智能体与 work | 计划上下文 SQL 持久化 | (repository impl) | sqlx |
| work/proposal.rs | 多智能体与 work | Work 提案域类型 | proposal 类型 | thiserror |
| work/proposal_acceptance_repository.rs | 多智能体与 work | 提案接受 SQL 持久化 | (repository impl) | sqlx |
| work/proposal_queue.rs | 多智能体与 work | 提案队列（出队/排序） | proposal queue | sqlx |
| work/proposal_repository.rs | 多智能体与 work | 提案 SQL 持久化 | (repository impl) | sqlx |
| work/runtime_event_outbox.rs | 多智能体与 work | work_runtime_event_outbox_slots 事件投影 | `project_pending_runtime_events`(L156) | sqlx |
| work/subject.rs | 多智能体与 work | Work 主体（subject）域类型 | subject 类型 | serde |
| work/subject_repository.rs | 多智能体与 work | 主体 SQL 持久化 | (repository impl) | sqlx |

按模块分组的文件清单（共 281 个生产 .rs 文件；路径相对 `crates/runtime/src/`；行数为实测）。

### 根模块（src/，12 个文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| main.rs | bin astra-server | 进程入口：沙箱 supervisor→build_info→process runtime→serve | `main`,`run` | astra_core, astra_sandbox |
| lib.rs | crate root | 模块声明、astra_services/astra_turn_core 大规模再导出、trust_mode 应用 | `serve`(再导出),`apply_safety_config_from_runtime_config` | astra_services, astra_turn_core, astra_config |
| app_state.rs | 根 | AppState 定义与全部 with_* 服务装配、HealthChecker、Memoria 转发 | `AppState`,`HealthChecker`,`MatrixOneHealthChecker`,`MemoriaForwarder` | astra_services, turn/services |
| auto_invoke_handler.rs | 根 | AutoInvokeGate→诊断 skill 的生产胶水 | `AutoInvokeHandler` | skills, astra_skills |
| bash_intent.rs | 根 | bash 命令读意图统一分类 | `classify_bash_intent` 等 | 无重依赖 |
| capabilities.rs | 根 | Web/CLI 回合能力目录（工具 schema+skill manifest） | `TurnCapabilities` 等 | astra_skills, astra_turn_core |
| capability_endpoint_pool.rs | 根 | 每 endpoint 并发 RPC 信号量 | `CapabilityEndpointPool` | tokio |
| capability_registry.rs | 根 | provider 注册与工具请求最优路由 | `CapabilityRegistry` | provider/, storage |
| capacity_model.rs | 根 | 多 pod 容量方程与 rollout 门 | `CapacityModel` | astra_turn_core(pipeline_metrics) |
| db_row.rs | 根 | 再导出 RowExt | `RowExt` | astra_services |
| llm_provider_admission.rs | 根 | LLM RPM/TPM DB 准入+TAT 起搏+校准指标 | `admit_llm_provider_request`,`ensure_llm_provider_admission_schema_if_configured` | sqlx, astra_core |
| matrix_cloud_runtime.rs | 根 | Matrix 摄取/sync/关停的共享运行时附件 | `MatrixCloudRuntime`,`matrix_settings_from_env` | astra_services(event_ingestion) |

### config_admin/（4）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| config_admin/mod.rs | config_admin | 模块声明 | — | — |
| config_admin/admin_config.rs | config_admin | /admin/config 键值管理（需 admin 角色） | `list/get/set/delete_admin_config_handler` | astra_services(AdminConfigService) |
| config_admin/guardrail.rs | config_admin | auto-reflection 阈值自适应（滚动统计±1、钳位、迟滞） | `GuardrailThreshold` | 无 |
| config_admin/skill.rs | config_admin | per-skill 配置/资源绑定 handler | `get/set/delete_setting_handler` 等 | astra_services(skill_config) |

### data_layer/（4）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| data_layer/mod.rs | data_layer | 模块声明 | — | — |
| data_layer/models.rs | data_layer | /models、/me/models HTTP handler（CRUD/校验/check） | `list_models_handler`,`create_user_model_handler` 等 | astra_services(models), axum |
| data_layer/storage.rs | data_layer | turn 事件/审计/skill 选择持久化函数族 | `ensure_core_schema`,`insert_core_turn_event`,`insert_tool_turn_event` | sqlx, astra_turn_core(contracts) |
| data_layer/versioning.rs | data_layer | 数据版本化 checkpoint/lineage handler | `create_checkpoint_handler` 等 | astra_services(data_versioning) |

### deployment/ evaluation/ learning/ memory_hooks/ messaging/ observability/（19）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| deployment/mod.rs | deployment | 部署 profile 类型与 YAML 装载 | `DeploymentProfile` | serde_yaml_ng |
| evaluation/mod.rs | evaluation | 模块声明 | — | — |
| evaluation/handlers.rs | evaluation | 17 个 /evaluation/* handler | `drift_handler`,`slo_dashboard_handler` 等 | astra_services(evaluation) |
| learning/mod.rs | learning | 模块声明与再导出 | `extract_lessons`,`LessonCheckpointer` | — |
| learning/checkpoint.rs | learning | 会话内增量课程提取（纠正/失速恢复/计划完成） | `LessonCheckpointer` | learning/extractor |
| learning/extractor.rs | learning | SessionSummary→NewLesson 纯映射 | `SessionSummary`,`extract_lessons` | astra_services |
| learning/synthesizer.rs | learning | Memoria L3 回流合成（纯提取不调 HTTP） | `ExtractedLesson`,`LESSON_SYNTHESIS_PROMPT` | 无 |
| memory_hooks/mod.rs | memory_hooks | 模块声明 | — | — |
| memory_hooks/inference.rs | memory_hooks | Direct/Durable 记忆推理客户端 | `DurableMemoryInferenceClient` | astra_memoria |
| memory_hooks/relevance.rs | memory_hooks | selector 廉价模型过滤召回记忆 | `filter_relevant_memories` | astra_turn_core |
| messaging/mod.rs | messaging | astra-messaging 再导出+集成测试挂载 | `AgentMailboxRouter` 等 | astra_messaging |
| observability/mod.rs | observability | 模块声明与说明 | — | — |
| observability/hub.rs | observability | ObservabilityHub：journal+用户画像聚合 | `ObservabilityHub` | astra_services(session_journal) |
| observability/session.rs | observability | 每会话上下文 trace 信号（M1-M6 挂点） | `ObservabilitySession` | astra_config(runtime_config) |
| observability/types.rs | observability | 观测共享类型 | `ContextTrace*` 等 | serde |
| orchestration/agent_result_status.rs | orchestration | 子代理结果状态机 | `AgentResultStatus` | astra_core |
| orchestration/agent_tool.rs | orchestration | 合并 agent 工具（spawn/get_result 契约） | `handle_agent_tool` | messaging, turn_core |
| orchestration/agent_trace_status.rs | orchestration | 代理 trace 状态 | `AgentTraceStatus` | serde |
| orchestration/fork_cache_probe.rs | orchestration | fork 缓存探测 | `ForkCacheProbe` | astra_turn_core |

### orchestration（续） prompts/ provider/ self_model/（15）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| orchestration/mod.rs | orchestration | 模块声明 | `AgentRegistry`,`ProgressBroadcaster` | — |
| orchestration/spawner.rs | orchestration | DynamicAgentSpawner：动态子代理创建/生命周期/取消级联 | `DynamicAgentSpawner` | astra_messaging, turn_core |
| prompts/mod.rs | prompts | 集中提示词入口与再导出 | `SYSTEM_PROMPT_BASE` 等 | astra_prompts |
| prompts/context.rs | prompts | Unicode 感知 token 估算与上下文预算 | `estimate_tokens`,`budget_for_model_with_metadata` | 无 |
| prompts/system.rs | prompts | 全部系统提示词常量与构建器 | `SYSTEM_PROMPT_BASE`,`build_system_prompt` | — |
| provider/mod.rs | provider | 能力驱动工具路由抽象层 | `CapabilityProvider`,`ProviderKind` | — |
| provider/edge_connection.rs | provider | 边缘连接 provider 实现 | `EdgeConnectionProvider` | provider/traits |
| provider/sandbox_runner.rs | provider | 沙箱 runner provider 实现 | `SandboxRunnerProvider` | astra_sandbox |
| provider/server_builtin.rs | provider | 服务端内建工具 provider（委托 RuntimeToolExecutor） | `ServerBuiltinProvider` | provider/traits |
| provider/traits.rs | provider | CapabilityProvider trait 与 ToolRequest/Result | `CapabilityProvider`,`ServerToolRuntime` | astra_runtime_env |
| provider/types.rs | provider | ProviderKind/ToolCapability/ToolCategory | `ToolCapability` | serde |
| self_model/mod.rs | self_model | 模块声明 | — | — |
| self_model/introspection.rs | self_model | /introspection/* handler 与再导出 | `get_decision_trace_handler` 等 | astra_services(introspection) |
| self_model/model.rs | self_model | SelfModel 只读自省快照 | `SelfModel` | observability, astra_config |
| storage/mod.rs | storage | 沙箱/边缘存储类型（MountType 等） | `MountType`,`StorageAccess` | serde |

### server/ 根（88）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| server/mod.rs | server | serve/build_app/build_test_router、后台 sweeper spawn、优雅关停 | `serve`,`build_app`,`build_server_state` | axum, tokio, tower_http |
| server/admin_handlers.rs | server | /admin/register/init/audit/feedback/tokens/cleanup 等 handler | `admin_register_handler` 等 | astra_services(admin) |
| server/agent_binding_handlers.rs | server | /agent-bindings CRUD handler | `create_agent_binding_handler` 等 | astra_services |
| server/agent_binding_skill_runtime.rs | server | agent-binding 模式下的 skill 运行时组装 | `AgentBindingSkillRuntime` | skills, capabilities |
| server/artifact_retention_sweeper.rs | server | 产物保留期清扫 sweeper | `spawn_artifact_retention_sweeper` | sqlx |
| server/audit_handlers.rs | server | 会话审计与跨会话统计 handler | `audit_summary_handler` 等 | astra_services(session_audit) |
| server/auth_handlers.rs | server | /auth/* 与 /memory/* Memoria 代理 handler | `auth_login_handler`,`memory_proxy_store_handler` 等 | astra_services(auth) |
| server/capability_handlers.rs | server | /runtime/capabilities handler | `runtime_capabilities_handler` | capabilities |
| server/chat_handlers.rs | server | /chat、/chat/stream 入口与 authority 校验 | `chat_handler`,`chat_stream_handler`,`validate_conversation_authority` | server/run, http_helpers |
| server/cleanup_retry.rs | server | 工作区清理债务后台重试 | `spawn_cleanup_retry` | astra_services |
| server/conflict_resolver.rs | server | 再导出冲突解决器 | `ConflictResolver` | astra_server_types |
| server/completions.rs | server | /v1/chat/completions OpenAI 兼容代理 | `completions_handler` | llm_provider_admission |
| server/deployment_tool_policy.rs | server | 部署级工具策略装载 | `load_deployment_tool_policy`,`apply_deployment_tool_policy` | serde_yaml_ng |
| server/device_lease_sweeper.rs | server | 设备租约 sweeper | `spawn_device_lease_sweeper` | sqlx |
| server/header_utils.rs | server | 请求头透传收集 | `collect_forward_headers` | axum |
| server/http_helpers.rs | server | SSE 响应构造（心跳/终端宽限/投影） | `sse_streaming_response`,`sse_json_response` | async_stream, run/handlers |
| server/inference_settlement_sweeper.rs | server | 推理结算 sweeper 入口 | `spawn_inference_settlement_sweeper` | turn/llm/durable |
| server/interaction_metrics.rs | server | 交互指标定义 | `InteractionMetrics` | astra_turn_core |
| server/llm_trusted_domains_handlers.rs | server | /admin/llm/trusted-domains handler | `list/upsert/delete_llm_trusted_domain_handler` | astra_services |
| server/mcp_handlers.rs | server | /api/v1/mcp/register-or-update handler | `register_or_update_handler` | astra_services(mcp_registry) |
| server/meta_handlers.rs | server | / /live /ready /health /metrics handler 与模型指标发布 | `health_handler`,`metrics_handler` | astra_turn_core(metrics) |
| server/model_execution_admission.rs | server | 请求级模型执行准入（Offering 治理） | `AdmittedModelExecution` 相关 | astra_services |
| server/platform_handlers.rs | server | /platform/snapshot handler | `platform_snapshot_handler` | astra_services |
| server/preferences_handlers.rs | server | /preferences 键值 handler | `list_preferences_handler` | astra_services |
| server/product_harness_handlers.rs | server | /harnesses/* 产品化 harness handler | `create_skillify_harness_run_handler` 等 | astra_services(harness) |
| server/provider_runtime_context.rs | server | chat 请求注入有效 runtime context | `inject_effective_runtime_context` | astra_services |
| server/reflect_handlers.rs | server | /chat/session/{id}/reflect handler | `reflect_session_handler` | astra_services(reflect) |
| server/request_trace.rs | server | x-request-id 中间件与错误体注入 | `request_trace_middleware`,`RequestTrace` | axum |
| server/resource_handlers.rs | server | /resources/usage|limits handler | `get_resource_usage_handler` | astra_services(resource_governor) |
| server/router_builder.rs | server | build_router 组合六组路由 | `build_router` | router_builder/* |
| server/runtime_maintenance_sweeper.rs | server | 运行时维护 sweeper 入口 | `spawn_runtime_maintenance_sweeper` | sweeper_lease |
| server/runtime_mcp.rs | server | 请求级 MCP wiring（schema/连接仅驻内存） | `RuntimeMcpBundle`,`install_runtime_tool_schemas` | astra_mcp |
| server/runtime_tool_executor.rs | server | 服务端工具执行器（本地工具/审批/沙箱/MCP/work 绑定） | `RuntimeToolExecutor`(impl ToolExecutor) | astra_tools, tool_execution_service |
| server/semantic_read_freshness.rs | server | 语义读新鲜度判定 | `SemanticReadFreshness` | 无 |
| server/semantic_read_observation_runtime.rs | server | 语义读观测运行时 | `SemanticReadObservationRuntime` | sqlx |
| server/server_bash_execution.rs | server | 服务端 bash 执行与退出语义分类 | `execute_server_bash` | astra_tools(exit_semantics) |
| server/server_loop_host.rs | server | ServerAgenticLoopHost：execute_turn/工具面/结算 | `ServerAgenticLoopHost(Builder)` | turn/llm, wire_assembly |
| server/server_skill_subrun.rs | server | 服务端 skill Fork 子 run 执行器 | `ServerSkillSubRunExecutor` | turn/agentic_loop |
| server/session_turn.rs | server | session turn 序号推断 | `infer_session_turn` | sqlx |
| server/skillify_agent_executor.rs | server | skillify LLM 执行器（harness 用） | `RuntimeSkillifyAgentExecutor` | astra_services(harness) |
| server/state_builder.rs | server | build_server_state 组装入口 | `build_server_state` | state_builder/core,runtime |
| server/sweeper_lease.rs | server | sweeper TTL 租约选主（60s） | `spawn_runtime_sweepers`,`SweeperLease` | uuid, sqlx |
| server/tool_admission.rs | server | CapacityProvider 声明与工具准入三态策略 | `resolve_tool_admission_for_binding*` | astra_runtime_env |
| server/tool_agent_info.rs | server | get_agent_info 工具支撑 | `tool_agent_info` | self_model |
| server/tool_agent_runtime.rs | server | 代理工具运行时绑定 | `ToolAgentRuntime` | orchestration |
| server/tool_approval_preflight.rs | server | 工具审批预检 | `approval_preflight` | astra_tools |
| server/tool_ask_user.rs | server | ask_user 服务端实现 | `handle_ask_user` | run/lifecycle |
| server/tool_binding_projection.rs | server | 按 agent-binding 投影工具 schema | `capability_filtered_server_tool_schemas` | astra_runtime_env |
| server/tool_database_snapshots.rs | server | 工具触发的 DB 快照 | `DatabaseSnapshotTool` | sqlx |
| server/tool_edge_selection.rs | server | 边缘执行器选择 | `select_edge_executor` | astra_server_types |
| server/tool_edge_transport.rs | server | EdgeBound 执行（durable admission+WS 下发+等结果） | `execute_edge_bound` | tool_transport_plan |
| server/tool_execution_binding.rs | server | Workspace/Executor 绑定类型 | `ToolExecutionRequest`,`ExecutionBindingSnapshot` | astra_runtime_env |
| server/tool_execution_result.rs | server | 工具执行结果元数据 | `ToolExecutionResultMeta` | serde |
| server/tool_execution_service.rs | server | 共享工具执行服务（路由分发/策略闸门） | `ToolExecutionService::execute_with_cancel` | tool_edge_transport, tool_local_transport |
| server/tool_external_transport.rs | server | 外部网关中继传输 | `ExternalTransport` trait | async_trait |
| server/tool_file_runtime.rs | server | 服务端文件工具运行时（read/write/str_replace） | `execute_file_tool` | astra_tools |
| server/tool_introspect.rs | server | introspect 工具 | `handle_introspect` | self_model |
| server/tool_invocation_compactor.rs | server | 工具调用记录压缩 | `ToolInvocationCompactor` | serde_json |
| server/tool_invocation_decision.rs | server | 工具调用决策审计 | `ToolInvocationDecision` | sqlx |
| server/tool_invocation_runtime.rs | server | durable invocation ledger 适配与结果投影 | `ToolInvocationRuntime` | astra_turn_types |
| server/tool_local_execution.rs | server | 本地工具执行封装 | `execute_local_tool` | runtime_tool_executor |
| server/tool_local_transport.rs | server | ServerLocalToolTransport trait | `ServerLocalToolTransport` | astra_tools |
| server/tool_plan_gate.rs | server | 计划门（工具执行前 plan 校验） | `ToolPlanGate` | astra_plan |
| server/tool_route_boundary.rs | server | 工具路由边界（请求+路由原子体） | `ToolRouteBoundary` | tool_execution_binding |
| server/tool_route_runtime.rs | server | 路由运行时辅助 | `ToolRouteRuntime` | tool_route_selection |
| server/tool_route_selection.rs | server | 路由判定（工作区/执行器→RouteKind） | `routing_decision_for_binding`,`ToolExecutionRouteKind` | astra_runtime_env |
| server/tool_session_config.rs | server | 工具会话配置状态机 | `ToolSessionConfig` | sqlx |
| server/tool_session_history.rs | server | 工具会话历史读写 | `ToolSessionHistory` | sqlx |
| server/tool_session_runtime.rs | server | 工具会话运行时门面 | `ToolSessionRuntime` | tool_session_config |
| server/tool_session_state_rollback.rs | server | 工具会话状态回滚 | `SessionStateRollback` | sqlx |
| server/tool_transport.rs | server | 工具传输层门面（再导出聚合） | `ToolExecutionService`,`ToolExecutionRequest` 等 | 各 tool_* 子模块 |
| server/tool_transport_errors.rs | server | 传输错误类型常量 | `TOOL_ERROR_KIND_*` | serde |
| server/tool_transport_metadata.rs | server | 绑定事件字段与错误元数据 | `binding_event_fields` | serde_json |
| server/tool_transport_plan.rs | server | EdgeBound 执行计划（超时/身份/授权上下文） | `EdgeBoundExecutionPlan` | tool_execution_binding |
| server/tool_workspace_path_guard.rs | server | 工作区路径守卫 | `WorkspacePathGuard` | std::path |
| server/tool_work_criteria.rs | server | Work 完成判据 | `WorkCriteria` | astra_server_types |
| server/tool_work_lifecycle.rs | server | Work 任务板生命周期 V1 | `WorkTaskBoardUpdateV1` 处理 | astra_server_types |
| server/tool_work_plan.rs | server | Work 计划提案/物化 | `WorkPlanRuntime` | astra_plan |
| server/tool_work_proposal.rs | server | Work 提案类型 | `WorkProposal` | serde |
| server/tool_work_surface_events.rs | server | Work 面事件投影 | `WorkSurfaceEvents` | serde_json |
| server/user_skill_handlers.rs | server | /skills/user handler | `create_user_skill_handler` 等 | astra_services(skills) |
| server/work_branch_deletion_runtime.rs | server | work 分支删除恢复任务 | `spawn_work_branch_deletion_recovery` | sqlx |
| server/work_context.rs | server | canonical work 上下文注入 | `install_canonical_work_context` | serde_json |
| server/work_handlers.rs | server | /v1/works 全生命周期 handler | `post_work_handler`,`get_work_handler` 等 | astra_services(runs/work) |
| server/work_patch_commit_runtime.rs | server | 补丁提交恢复任务 | `spawn_work_patch_commit_recovery` | sqlx |
| server/work_patch_export_runtime.rs | server | 补丁导出 | `export_work_patch` | tar, flate2 |
| server/work_patch_materialization_runtime.rs | server | 补丁物化恢复任务 | `spawn_work_patch_materialization_recovery` | sqlx |
| server/ws_handler.rs | server | /chat/ws WebSocket 双向 handler（审批门/取消传播） | `ws_chat_handler` | run/lifecycle, axum(ws) |

### server/ 子目录（42）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| server/delegation/mod.rs | server::delegation | 模块声明 | — | — |
| server/delegation/engine.rs | server::delegation | 子 run 派发引擎（深度限制/质量门/追踪） | `DelegationEngine`,`DelegationTracker`,`GateVerdict` | run/engine, astra_services |
| server/delegation/handlers.rs | server::delegation | /chat/runs/{id}/delegate handler | `delegate_run_handler` | delegation/engine |
| server/edge/mod.rs | server::edge | 模块声明 | — | — |
| server/edge/edge_callback_handlers.rs | server::edge | 工具结果/审批/追问/provider 回调（durable 对账） | `post_tool_result_handler`,`post_approval_respond_handler` | astra_server_types |
| server/edge/edge_service_status_handler.rs | server::edge | /service/edges/status | `edge_service_status_handler` | astra_services(multi_agent) |
| server/edge/edge_status_handler.rs | server::edge | /edges/status | `edge_status_handler` | edge_connection_pool |
| server/edge/edge_ws_handler.rs | server::edge | 边缘代理 WS 注册/心跳/工具下行 | `edge_ws_handler` | edge_connection_pool |
| server/harness/mod.rs | server::harness | 模块声明 | — | — |
| server/harness/handlers.rs | server::harness | harness snapshot/history/diff/stream handler | `get_harness_snapshot`,`stream_harness_snapshots` | astra_harness |
| server/harness/server_sink.rs | server::harness | 内存+SSE 广播快照 sink | `ServerHarnessSink` | tokio |
| server/router_builder/admin.rs | server::router_builder | /admin 路由组 | `add_routes` | admin_handlers |
| server/router_builder/automation.rs | server::router_builder | 自动化域路由组（agents/events/…） | `add_routes` | service_handlers |
| server/router_builder/catalog.rs | server::router_builder | 目录域路由组（models/skills/marketplace） | `add_routes` | data_layer/models |
| server/router_builder/operations.rs | server::router_builder | 运维域组合入口 | `add_routes` | operations/* |
| server/router_builder/realtime.rs | server::router_builder | 实时域路由组（chat/ws/auth/memory/run/teams/edge） | `add_routes` | chat_handlers, ws_handler |
| server/router_builder/sessions.rs | server::router_builder | 会话域路由组（sessions/audit/harness） | `add_routes`,`harness_routes` | session/* |
| server/router_builder/operations/harnesses.rs | server::router_builder::operations | /harnesses 路由组 | `add_routes` | product_harness_handlers |
| server/router_builder/operations/insights.rs | server::router_builder::operations | /evaluation /introspection 路由组 | `add_routes` | evaluation, self_model |
| server/router_builder/operations/work.rs | server::router_builder::operations | /v1/works /runs /preferences /resources 路由组 | `add_routes` | work_handlers |
| server/run/mod.rs | server::run | 模块声明 | — | — |
| server/run/binding_resolution.rs | server::run | 请求→执行绑定解析（workspace/executor） | `resolve_request_execution_bindings` | tool_execution_binding |
| server/run/cloud_workspace_provisioning.rs | server::run | 云工作区供给记录 | `provision_cloud_workspace_record` | astra_services |
| server/run/engine.rs | server::run | durable RunEngine（状态/重放/owner lease/恢复） | `RunEngine` | astra_services(runs) |
| server/run/handlers.rs | server::run | run HTTP/SSE handler 与事件客户端投影 | `stream_run_handler`,`transform_stream_run_events_for_client` | run/lifecycle |
| server/run/workspace_provisioning.rs | server::run | 服务端本地工作区供给 | `provision_persisted_server_workspace` | astra_services |
| server/run/lifecycle/mod.rs | server::run::lifecycle | AgenticRunLifecycleService（create/stream/cancel/pause）+门/信道 | `AgenticRunLifecycleService`,`DurableRunApprovalGate` | server_loop_host, run/engine |
| server/run/lifecycle/admission.rs | server::run::lifecycle | run 启动准入辅助 | `RunStartIdempotency` 相关 | — |
| server/run/lifecycle/persistence.rs | server::run::lifecycle | 终态 CAS/事件 delta/transcript 落库 | `persist_session_transcript_items` | sqlx |
| server/run/lifecycle/projection.rs | server::run::lifecycle | run 投影修复 | `repair_run_projection` | astra_services |
| server/run/lifecycle/run_state.rs | server::run::lifecycle | 进程内 run 状态与控制标志 | `TrackedRunState`,`RunStatus` | tokio_util |
| server/runtime_tool_executor/tool_handlers.rs | server::runtime_tool_executor | 内建工具 handler 表（memory/task/session/web…） | `execute_builtin_tool` | runtime_tool_executor |
| server/session/mod.rs | server::session | 模块声明 | — | — |
| server/session/session_handlers.rs | server::session | /sessions 全量 handler（设备/交接/fork/附件/审计） | `create_session_handler`,`request_session_handoff_handler` 等 | astra_services |
| server/session/session_quota.rs | server::session | 会话创建资源配额 | `create_session_with_resource_quota` | astra_services |
| server/session/session_run_tree.rs | server::session | 会话 run 树视图 | `get_session_run_tree_handler` | run/lifecycle |
| server/session/session_trace.rs | server::session | 会话 turn trace 视图 | `get_session_turn_trace_handler` | orchestration |
| server/state_builder/core.rs | server::state_builder | 核心服务装配与子钥派生 | `build_core_state`,`derive_runtime_subkey` | astra_services |
| server/state_builder/runtime.rs | server::state_builder | 运行时 wiring（RunEngine/Delegation/Matrix/lifecycle） | `build_runtime_wiring`,`default_agent_profile_registry` | run/lifecycle |
| server/team/mod.rs | server::team | 模块声明 | — | — |
| server/team/handlers.rs | server::team | /teams CRUD/execute/snapshots handler | `execute_team_handler` | team/orchestrator |
| server/team/orchestrator.rs | server::team | 4 阶段团队执行编排 | `TeamOrchestrator` | delegation/engine |

### service_handlers/（11）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| service_handlers/mod.rs | service_handlers | 模块声明 | — | — |
| service_handlers/agents.rs | service_handlers | /agents CRUD handler | `create_agent_handler` 等 | astra_services(agents) |
| service_handlers/branches.rs | service_handlers | /branches handler | `create_branch_handler` 等 | astra_services(branches) |
| service_handlers/context.rs | service_handlers | /context 快照 handler | `create_snapshot_handler` | astra_services(context) |
| service_handlers/decisions.rs | service_handlers | /decisions handler | `record_decision_handler` | astra_services(decisions) |
| service_handlers/events.rs | service_handlers | /events 与 /sync/outbox handler | `create_event_handler` | astra_services(events) |
| service_handlers/marketplace.rs | service_handlers | /marketplace 安装/升级/凭据 handler | `install_skill_handler` | astra_services(marketplace) |
| service_handlers/replay.rs | service_handlers | /sessions/{id}/replay handler | `replay_session_handler` | astra_services(replay) |
| service_handlers/sandbox.rs | service_handlers | /sandbox handler | `create_sandbox_handler` | astra_services(sandbox) |
| service_handlers/triggers.rs | service_handlers | /triggers handler（含 webhook fire） | `fire_webhook_handler` | astra_services(triggers) |
| service_handlers/workflows.rs | service_handlers | /workflows 列表 handler | `list_workflows_handler` | astra_services(workflows) |

### session_memory/ skills/ tool_registry/（15）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| session_memory/mod.rs | session_memory | 模块声明（finalize_and_render 触发的后台提取） | — | — |
| session_memory/activity.rs | session_memory | 后台活动 broker | `BackgroundActivityBroker` | tokio |
| session_memory/gate.rs | session_memory | 提取门控 | `extraction_gate` | — |
| session_memory/health.rs | session_memory | 提取健康冷却（selector/Memoria） | `MemoryIoCooldown` | — |
| session_memory/request.rs | session_memory | 提取请求类型 | `ExtractionRequest` | serde |
| session_memory/runner.rs | session_memory | run_extraction worker 本体 | `run_extraction` | astra_memoria, turn_core |
| session_memory/service.rs | session_memory | MemoryExtractionService 协调者 | `MemoryExtractionService` | runner, astra_services |
| skills/mod.rs | skills | 模块声明与说明 | — | — |
| skills/catalog.rs | skills | skill 目录视图 | `SkillCatalog` | skills/registry |
| skills/handlers.rs | skills | /skills handler | `list_skills_handler` | astra_services(skills) |
| skills/registry.rs | skills | 统一注册表（local>bundled>db>mcp>plugin） | `SkillRegistry` | astra_skills |
| skills/watcher.rs | skills | 文件热载监听 | `spawn_skill_watcher` | notify |
| tool_registry/mod.rs | tool_registry | 模块声明 | — | — |
| tool_registry/registry.rs | tool_registry | ToolRegistry 包装（内建工具） | `ToolRegistry` | astra_runtime_env |
| tool_registry/surface.rs | tool_registry | 工具面投影 | `ToolSurface` | astra_turn_core |

### turn/ 根（30）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| turn/mod.rs | turn | 模块声明 | — | — |
| turn/budget_messaging.rs | turn | 预算消息文案 | `budget_message` | — |
| turn/canonical_commit.rs | turn | canonical 消息提交 | `commit_canonical_messages` | astra_turn_core |
| turn/chat_turn_budget_pressure.rs | turn | 回合预算压力信号 | `BudgetPressure` | — |
| turn/compaction_replay.rs | turn | 压缩后回放 | `replay_after_compaction` | turn/cloud |
| turn/context_pipeline_adapter.rs | turn | AgenticLoopState→ContextSources 唯一桥 | `PipelineTurnOutcome`,`run_turn_pipeline` | astra_pipeline |
| turn/deferred_tools_edge_profile.rs | turn | 边缘延迟工具 profile | `DeferredEdgeTools` | serde_json |
| turn/harness_adapter.rs | turn | harness_at! 宏适配 | `harness_at` | astra_harness |
| turn/headless_tool_pipeline.rs | turn | 无头工具管线主体 | `run_headless_pipeline` | astra_thin_client |
| turn/inspection_service.rs | turn | 回合巡检服务 | `TurnInspectionService` | astra_services |
| turn/local_provider.rs | turn | LocalSessionProvider（三合一只读状态提供者） | `LocalSessionProvider` | turn/providers |
| turn/loop_dispatcher.rs | turn | 循环分派器 | `LoopDispatcher` | turn/agentic_loop |
| turn/memory_prefetch.rs | turn | Memoria 预取 | `prefetch_memoria` | astra_memoria |
| turn/model_cooldown.rs | turn | 模型限流冷却全局状态 | `rate_limit_cooldown` | — |
| turn/permission_gate.rs | turn | 权限门（工具授权） | `PermissionGate` | astra_tools |
| turn/plan_mode_guard.rs | turn | 计划模式守卫 | `plan_mode_guard` | — |
| turn/prompt_cache.rs | turn | 提示缓存（cache_control 命中优化） | `PromptCacheConfig` | astra_turn_core(cache) |
| turn/providers.rs | turn | 观测面 provider traits | `LiveRuntimeProvider` 等 | — |
| turn/runtime_policy.rs | turn | JournalFacts→RuntimePolicyEvidence 策略引擎 | `RuntimePolicyEngine` | astra_turn_core |
| turn/run_control.rs | turn | 运行控制动作解析 | `RunControlAction` | astra_server_types |
| turn/services.rs | turn | turn 持久化服务 DB 实现（7 个 Writer） | `DatabaseTurnCoreEventWriter` 等 | data_layer/storage |
| turn/session_current_date.rs | turn | 会话当前日期解析 | `resolve_session_current_date_for_user` | chrono |
| turn/session_end_debounce.rs | turn | 会话结束去抖 | `SessionEndDebounce` | tokio |
| turn/skill_tool.rs | turn | skill 工具（LLM 调 skill） | `SkillTool` | skills |
| turn/terminal_control.rs | turn | 终端控制（typed 终止取代工具调用） | `TerminalControlOutcome` | astra_turn_types |
| turn/token_usage.rs | turn | token 用量聚合 | `TokenUsage` | serde |
| turn/tool_completion.rs | turn | 工具完成事件构建 | `build_tool_completion` | astra_turn_core |
| turn/tool_side_effects.rs | turn | 工具副作用登记 | `ToolSideEffects` | — |
| turn/turn_trace_collector.rs | turn | 回合 trace 收集 | `TurnTraceCollector` | observability |
| turn/wire_assembly.rs | turn | Memoria 压缩+LLM 消息装配共享原语 | `assemble_llm_messages`,`observe_context_compaction` | turn/cloud, llm/context |

### turn/agentic + agentic_loop（16）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| turn/agentic/mod.rs | turn::agentic | 模块声明 | — | — |
| turn/agentic/adaptive_runtime.rs | turn::agentic | 自适应运行时信号 | `AdaptiveRuntimeSignals` | — |
| turn/agentic/delegate_interception.rs | turn::agentic | delegate 拦截（spawn→子 run） | `intercept_delegate` | orchestration |
| turn/agentic/headless_round.rs | turn::agentic | 无头轮 stderr 样式 | `HeadlessStderrStyle` | — |
| turn/agentic/strategy_application.rs | turn::agentic | 策略应用 | `apply_strategy` | — |
| turn/agentic/tool_interception.rs | turn::agentic | 工具调用共享准入 | `admit_tool_calls` | astra_turn_types |
| turn/agentic/turn_intent.rs | turn::agentic | 回合语义意图判定 | `TurnIntentJudgeOutcome` | astra_services |
| turn/agentic_loop/mod.rs | turn::agentic_loop | 模块声明 | — | — |
| turn/agentic_loop/execution_phase.rs | turn::agentic_loop | LLM 回合执行+摄取阶段（含验证钩子） | `execute_turn_and_ingest_phase` | agentic_loop/host |
| turn/agentic_loop/finalization.rs | turn::agentic_loop | 循环入口包装+终局渲染 | `run_agentic_loop_with_host`,`finalize_and_render` | agentic_loop/lifecycle |
| turn/agentic_loop/guards.rs | turn::agentic_loop | 循环守卫 | `LoopGuards` | — |
| turn/agentic_loop/host.rs | turn::agentic_loop | AgenticLoopHost trait+循环实现 | `AgenticLoopHost`,`run_agentic_loop_impl` | turn_core |
| turn/agentic_loop/lifecycle.rs | turn::agentic_loop | 回合准备/取消溯源/工作区观察判定 | `prepare_turn_iteration`,`run_loop_preamble` | — |
| turn/agentic_loop/source_recovery.rs | turn::agentic_loop | 源恢复 | `recover_source` | — |
| turn/agentic_loop/tool_phase.rs | turn::agentic_loop | 工具批执行阶段（text-only 封锁协议） | `execute_tool_phase` | astra_turn_core(parallel_tool_exec) |
| turn/agentic_loop/tool_support.rs | turn::agentic_loop | 工具支撑辅助 | `tool_support_fns` | — |

### turn/bedrock + cloud + headless_tool_pipeline + llm（25）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| turn/bedrock/mod.rs | turn::bedrock | 模块声明 | — | — |
| turn/bedrock/eventstream.rs | turn::bedrock | AWS vnd.amazon.eventstream 解码 | `EventStreamFrame` | flate2/crc32fast |
| turn/bedrock/stream.rs | turn::bedrock | Converse 流累积器 | `BedrockStreamAccumulator` | bedrock/eventstream |
| turn/bedrock/transport.rs | turn::bedrock | Bedrock 传输与 SigV4 | `collect_bedrock_stream_for_wire` | hmac, sha2 |
| turn/cloud/mod.rs | turn::cloud | 多层渐进上下文压缩说明 | — | — |
| turn/cloud/analytics.rs | turn::cloud | 压缩事件/微压缩/轮数触发分析 | `apply_micro_compact`,`evaluate_turn_count_trigger` | — |
| turn/cloud/compaction.rs | turn::cloud | 压缩边界/熔断器/触发器 | `CompactBoundary`,`CompactCircuitBreaker` | — |
| turn/cloud/compaction_engine.rs | turn::cloud | 压缩引擎编排 | `CompactionEngine` | cloud/compaction |
| turn/cloud/helpers.rs | turn::cloud | 压缩辅助 | `compact helpers` | — |
| turn/cloud/memoria_compact.rs | turn::cloud | Memoria 压缩端口与检索 | `compact_with_memoria`,`UserScopedMemoriaPort` | astra_memoria |
| turn/cloud/session_end_governance.rs | turn::cloud | 会话结束治理 | `SessionEndGovernance` | — |
| turn/cloud/layers/mod.rs | turn::cloud::layers | 压缩层声明 | — | — |
| turn/cloud/layers/duplicate_read_elimination.rs | turn::cloud::layers | 重复读消除层 | `DuplicateReadElimination` | — |
| turn/cloud/layers/reactive_compact.rs | turn::cloud::layers | 反应式压缩层 | `reactive_compact` | — |
| turn/cloud/layers/tiered_compaction.rs | turn::cloud::layers | 分层压缩层 | `tiered_compaction` | — |
| turn/cloud/layers/tool_result_truncation.rs | turn::cloud::layers | 工具结果截断层 | `tool_result_truncation` | — |
| turn/headless_tool_pipeline/execute.rs | turn::headless_tool_pipeline | 执行阶段 | `execute_headless` | headless_tool_pipeline |
| turn/headless_tool_pipeline/policy.rs | turn::headless_tool_pipeline | 策略阶段 | `HeadlessPolicy` | — |
| turn/headless_tool_pipeline/record.rs | turn::headless_tool_pipeline | 记录阶段 | `HeadlessRecord` | astra_services |
| turn/llm/mod.rs | turn::llm | 模块声明 | — | — |
| turn/llm/client.rs | turn::llm | 模型调用客户端（重试/预算/台账观察/SSE 消费） | `call_llm_and_collect*`,`global_llm_client` | reqwest, durable |
| turn/llm/context.rs | turn::llm | 缓存敏感的上下文装配入口 | `consolidate_system_messages_for_provider` | astra_turn_core |
| turn/llm/durable.rs | turn::llm | 持久推理台账边界（admission→I/O→terminal） | `ProviderAttemptObserver` 实现,`drain_provider_settlement_coordinator` | sqlx |
| turn/llm/exchange_capture.rs | turn::llm | 会话级完整请求/响应捕获 | `session_full_llm_capture_enabled` | astra_services |
| turn/llm/summary_client.rs | turn::llm | 摘要 LLM 客户端实现 | `SummaryLlmClient` 实现 | astra_turn_core |

（合计 12+4+4+1+2+4+3+1+4+6+3+6+3+1+88+42+11+15+30+16+25 = 281 个文件。）

按模块分组的文件清单（astra-cli 322 + astra-edge 5 = 327 个生产 .rs；已排除 tests/、src/tests/、snapshots、*test*、fixtures；`src/bin/mock_mcp_server.rs` 为测试辅助二进制，`tui/chat_widget/turn_driver.rs` 为 cfg(test) harness）：

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| crates/astra-cli/src/main.rs | bin(astra) | 进程入口：supervisor 短路、SIGPIPE 配置、capture guard、调 entrypoint::run | fn main | astra-sandbox、astra-core、output_sink |
| crates/astra-cli/src/lib.rs | crate 根 | 库入口、stdout_print! 宏（免分配 stdout 边界）、模块声明 | stdout_print!/stdout_println!、entrypoint、cli、tui | output_sink |
| crates/astra-cli/src/entrypoint.rs | 入口 | run()/run_async()：参数解析、overlay、ThinClient、print/-c/-r 分流 | run() | clap、astra-thin-client、cli |
| crates/astra-cli/src/background_task_error.rs | 顶层工具 | 后台任务错误枚举 | BackgroundTaskError | serde、thiserror |
| crates/astra-cli/src/diff_utils.rs | 顶层工具 | unified diff hunk 头解析与行号计算 | parse hunk 工具函数 | — |
| crates/astra-cli/src/edge_tools.rs | edge_tools | ToolExecutor 聚合定义与本地工具目录（bash/read/write/…） | ToolExecutor、local_tool_schemas | astra-tools、edge_tools/* |
| crates/astra-cli/src/explain_dag.rs | 顶层工具 | /explain 回合 DAG 与 explain 报告渲染 | ExplainTurnMeta、render_explain_dag | serde_json |
| crates/astra-cli/src/git_branch_cache.rs | 顶层工具 | TUI footer 用的 git 分支缓存（进程级） | 分支查询缓存 | gix、once_cell 语义 |
| crates/astra-cli/src/lock_recovery.rs | 顶层工具 | poisoned Mutex 无 panic 恢复 trait | LockRecovery | std |
| crates/astra-cli/src/manifest_loader.rs | 顶层工具 | manifest.yaml mcp_servers 与 .astra/mcp.json 发现 | MCP 配置发现 | serde_yaml_ng |
| crates/astra-cli/src/mcp_client.rs | 顶层工具 | CLI 侧 MCP 适配：重导出共享客户端类型+技能注册 | connect/register | astra-mcp |
| crates/astra-cli/src/mock_mcp_server_impl.rs | 测试辅助 | mock MCP stdio 服务器实现（供 e2e） | run_mock_mcp_server | rmcp、tokio |
| crates/astra-cli/src/sandbox_retry.rs | 顶层工具 | 沙箱拒绝后的重提示/扩沙箱重试（顺序/并行共用） | 重试 helper | astra-tools、permission_manager |
| crates/astra-cli/src/tool_safety_guard.rs | 顶层工具 | run-chain 步数上限与 SQL 安全检查入口 | MAX_RUN_CHAIN_STEPS、check_sql_safety | astra-turn-core |
| crates/astra-cli/src/bin/mock_mcp_server.rs | 测试辅助二进制 | mock_mcp_server bin 薄入口（清单注记：非生产路径） | fn main | mock_mcp_server_impl |
| crates/astra-cli/src/admin_cli/mod.rs | admin_cli | astra admin 子系统入口、run_from_env | run(args,…) | astra-thin-client |
| crates/astra-cli/src/admin_cli/cli_args.rs | admin_cli | admin clap 参数与 Command 枚举 | AdminArgs、Command | clap |
| crates/astra-cli/src/admin_cli/config.rs | admin_cli | admin 配置读取与 api url 解析 | read_config_api_url、resolve_api_url | — |
| crates/astra-cli/src/admin_cli/http_helpers.rs | admin_cli | thin client 错误映射与 API 错误压缩 | read_api_error、map_thin_err | astra-thin-client |
| crates/astra-cli/src/admin_cli/input.rs | admin_cli | 交互式 prompt（含秘密输入） | prompt_or、prompt_secret | rpassword |
| crates/astra-cli/src/admin_cli/interactive.rs | admin_cli | admin 交互式 REPL | run_interactive | inquire、astra-thin-client |
| crates/astra-cli/src/admin_cli/setup.rs | admin_cli | 首跑引导向导（秘密不入命令行） | setup 流程 | admin_cli/* |
| crates/astra-cli/src/cli/mod.rs | cli | cli 子模块声明汇总 | pub mod ×49 | — |
| crates/astra-cli/src/cli/agent_loader.rs | cli | 从 Markdown+YAML frontmatter 装载自定义 agent 档案 | load_and_merge | serde_yaml_ng |
| crates/astra-cli/src/cli/agent_runtime.rs | cli | 交互 REPL 的多代理运行时初始化 | bind_skill_resolver 等 | astra-runtime |
| crates/astra-cli/src/cli/app_server.rs | cli | Codex 风格 stdio JSON-RPC app-server（astra serve stdio） | run_stdio_app_server(:160) | tokio、serde_json |
| crates/astra-cli/src/cli/arg_render.rs | cli | 参数结构体反向渲染为命令行文本 | render_*_args | cli_args |
| crates/astra-cli/src/cli/auth_flow.rs | cli | login/register/登出/令牌解析与刷新 | do_login、do_register、parse_auth_tokens | astra-thin-client、rpassword |
| crates/astra-cli/src/cli/cloud_sync.rs | cli | 云端偏好同步（仅经 /preferences REST，禁直连 MatrixOne） | post_auth_cloud_resync | astra-thin-client |
| crates/astra-cli/src/cli/command_registry.rs | cli | slash 命令元数据注册表（名称/分组/补全） | registry | — |
| crates/astra-cli/src/cli/command_router.rs | cli | 全量子命令分发 + 一次性 chat/-p 路径 + 墙钟预算常量 | execute_cli_command(:752)、run_print_mode(:2723) | clap、astra-thin-client、cli/turn |
| crates/astra-cli/src/cli/command_usage.rs | cli | 命令使用计数/加权（模糊排序用） | usage_count、record_command_use | astra-services |
| crates/astra-cli/src/cli/config_manager.rs | cli | 设置读取/写入/list/get/set/show 与 capture 下载 | execute_config_command | astra-thin-client |
| crates/astra-cli/src/cli/context_dump.rs | cli | /context dump 全量 JSON 快照 | write_dump_for_repl | tui、serde_json |
| crates/astra-cli/src/cli/context_references.rs | cli | @file/@folder/@diff/@staged 内联上下文展开 | 解析/展开函数 | diff_utils |
| crates/astra-cli/src/cli/delegate_subrun.rs | cli | delegate 工具的子运行执行器（真实 agentic loop） | CliDelegateSubRunExecutor | astra-runtime、chat_stream |
| crates/astra-cli/src/cli/diagnostic_log.rs | cli | --diagnostic-log/--log-file 结构化日志 | init_cli_observability | tracing-appender |
| crates/astra-cli/src/cli/diff_presenter.rs | cli | 终端彩色 diff 展示（DiffSink 扩展点） | TerminalDiffSink | crossterm |
| crates/astra-cli/src/cli/edge_lifecycle.rs | cli | 云端 edge 注册+心跳（§5.5 Phase 3） | register_edge_once(:256)、spawn_edge_heartbeat(:289) | astra-thin-client |
| crates/astra-cli/src/cli/execution_state_summary.rs | cli | 注入系统提示的紧凑执行态摘要 | format_for_session_state | session |
| crates/astra-cli/src/cli/exit_code.rs | cli | CLI 退出码枚举 | ExitCode | — |
| crates/astra-cli/src/cli/followup_suggestion.rs | cli | 回合后后续建议（转发 turn-core 实现） | suggest_followup | astra-turn-core |
| crates/astra-cli/src/cli/history_work.rs | cli | 全历史工作计量（进程级门控） | record_json_history | astra-core |
| crates/astra-cli/src/cli/http_team_store.rs | cli | HTTP 后端 team 持久化（进程内存注册表+REST） | TeamStore | astra-thin-client |
| crates/astra-cli/src/cli/interactive_chat.rs | cli | 交互聊天统一启动器（TTY 门禁→run_tui） | run_interactive_chat(:10) | tui |
| crates/astra-cli/src/cli/journal_diff.rs | cli | journal diff A B 会话对比 | 对比函数 | astra-services |
| crates/astra-cli/src/cli/journal_digest.rs | cli | journal digest 本地摘要 | digest | astra-services |
| crates/astra-cli/src/cli/journal_tree.rs | cli | journal tree 委派/派生树渲染 | tree 渲染 | astra-services |
| crates/astra-cli/src/cli/mcp_config.rs | cli | MCP JSON 配置管理（增删查改+启动装载） | load_mcp_configs、execute_mcp_command | astra-mcp |
| crates/astra-cli/src/cli/mock_llm.rs | cli | 进程内 axum mock LLM（POST /chat/stream 脚本 SSE） | mock server | axum |
| crates/astra-cli/src/cli/notifications.rs | cli | 桌面通知（osascript/notify-send/bell） | 通知函数 | std::process |
| crates/astra-cli/src/cli/one_shot_session_routing.rs | cli | 一次性请求的会话路由/恢复元数据 | resolve_one_shot_session_routing、OneShotSessionRouting | astra-thin-client |
| crates/astra-cli/src/cli/permission_command.rs | cli | /permissions 与 astra permissions 解析 | parse_permission_command | permission_manager |
| crates/astra-cli/src/cli/permission_manager.rs | cli | 权限模式（Prompt/Auto/Bypass/Plan/Deny/AcceptEdits）与规则装载/会话覆盖 | PermissionManager、PermissionMode、preflight_cloud_approval_decision | serde_json、workspace_trust |
| crates/astra-cli/src/cli/preferences_client.rs | cli | /preferences REST 客户端（代理 pull/push） | pull/push | astra-thin-client |
| crates/astra-cli/src/cli/project_instructions.rs | cli | .astra/instructions.md 与知识注入发现 | discover_project_instructions、resolve_system_prompt(@file) | dirs |
| crates/astra-cli/src/cli/self_command.rs | cli | astra self 检查/身份视图/变更预览 | IdentityView、CheckResult | astra-thin-client |
| crates/astra-cli/src/cli/skill_catalog.rs | cli | skill list/show/status（分页上限防护） | list/load_skill_record | astra-skills |
| crates/astra-cli/src/cli/skill_subrun.rs | cli | Fork 型技能子运行执行器（含子取消作用域） | CliSkillSubRunExecutor、child_cancellation_scope | astra-skills、chat_stream |
| crates/astra-cli/src/cli/spawn_subrun.rs | cli | agent spawn 工具的 CLI 执行器 | SpawnAgentExecutor 实现 | astra-runtime |
| crates/astra-cli/src/cli/sse_utils.rs | cli | SSE text_delta 解析单一实现 | collect_sse_text、stream_sse_markdown | futures-util |
| crates/astra-cli/src/cli/startup_trace.rs | cli | 启动分相计时并写 Bootstrap journal | StartupTracer | astra-services |
| crates/astra-cli/src/cli/terminal_hyperlinks.rs | cli | OSC8 超链接构造与净化 | osc8_link | — |
| crates/astra-cli/src/cli/terminal_region.rs | cli | diff 式终端区域渲染（Ink 风格原子更新） | TerminalRegion | crossterm |
| crates/astra-cli/src/cli/theme.rs | cli | CLI 语义配色中心（含 stderr 主题） | current_stderr | crossterm |
| crates/astra-cli/src/cli/tool_call_groups.rs | cli | 工具调用记录分组 | group_tool_calls | astra-services |
| crates/astra-cli/src/cli/tool_result_status.rs | cli | 工具结果状态判定（skip/fail/success） | tool_result_status_* | — |
| crates/astra-cli/src/cli/tool_surface_injection.rs | cli | 注入工具 schema 到可见工具面 | install_injected_tool_schema | serde_json |
| crates/astra-cli/src/cli/ui_adapter.rs | cli | 终端输出抽象 trait（行模式 vs TUI 通道） | ReplUiAdapter、LineUiAdapter | tui/ui_adapter |
| crates/astra-cli/src/cli/work_command.rs | cli | astra work start/show/continue 处理 | work 命令实现 | astra-thin-client |
| crates/astra-cli/src/cli/workspace_trust.rs | cli | 工作区信任账本（.astra/permissions.json 防篡改） | trust ledger | serde_json |
| crates/astra-cli/src/cli/chat_stream/mod.rs | chat_stream | SSE 聊天循环门面与再导出 | ChatTurnParams、stream_chat_sse | sse_loop |
| crates/astra-cli/src/cli/chat_stream/params.rs | chat_stream | 回合参数、StreamEvent 枚举、审批/ask_user 通道类型、ExecutionTimeBudgetClock、ToolProgressSink | ChatTurnParams、StreamEvent、ApprovalRequest | tokio、astra-turn-core |
| crates/astra-cli/src/cli/chat_stream/edge_executor.rs | chat_stream | 进程级 edge_executor_id（ASTRA_EDGE_EXECUTOR_ID 可覆写） | edge_executor_instance_id | astra-turn-core |
| crates/astra-cli/src/cli/chat_stream/explain_reports.rs | chat_stream | explain/verdict 报告文本渲染 | print_explain_report、render_explain_report_text | explain_dag |
| crates/astra-cli/src/cli/chat_stream/sse_loop/mod.rs | chat_stream/sse_loop | stream_chat_sse 主编排（host+state 组装、循环、finalize） | stream_chat_sse(:208) | astra-runtime、edge_tools |
| crates/astra-cli/src/cli/chat_stream/sse_loop/agentic_loop_turn.rs | chat_stream/sse_loop | /chat/stream 载荷准备+POST+SSE 消费入口 | fetch_chat_turn_sse(:1673)、server_loop_admission_payload、turn_policy_from_payload_edge_tools | astra-thin-client、stream_render |
| crates/astra-cli/src/cli/chat_stream/sse_loop/agentic_sse_loop.rs | chat_stream/sse_loop | 循环后 sidecar 输出与 StreamResult 组装 | build_stream_result(:284)、eprint_stream_loop_sidecars | streaming_types |
| crates/astra-cli/src/cli/chat_stream/sse_loop/server_admission_host.rs | chat_stream/sse_loop | Server-owned 回合宿主：execute_turn、审批权限刷新、沙箱 guard | CliServerAdmissionHost（execute_turn :649） | astra-runtime host trait |
| crates/astra-cli/src/cli/chat_stream/sse_loop/deferred_activation_state.rs | chat_stream/sse_loop | 延迟激活工具名跨回合快照/恢复 | restore_into_executor、snapshot_from_executor | edge_tools |
| crates/astra-cli/src/cli/cli_config/mod.rs | cli_config | 子模块声明 | — | — |
| crates/astra-cli/src/cli/cli_config/cli_args.rs | cli_config | Cli 顶层参数与 33 个 Command 变体 | Cli、Command | clap |
| crates/astra-cli/src/cli/cli_config/cli_context.rs | cli_config | 启动上下文（tools/add-dir/session/审批模式） | CliContext::from_launch_options | — |
| crates/astra-cli/src/cli/cli_config/cli_formatting.rs | cli_config | 截断/路径缩短/字节/时长/差异格式化 | 格式化函数 | — |
| crates/astra-cli/src/cli/cli_config/cli_output.rs | cli_config | 结构化 CLI 输出（成功/警告/错误，全走 stderr） | 输出 helper | crossterm |
| crates/astra-cli/src/cli/cli_config/cli_utils.rs | cli_config | 凭据装载、profile 令牌、session id 校验、journal 追加等杂项 | get_profile_and_token、validate_cli_session_id、map_thin_err | astra-credentials |
| crates/astra-cli/src/cli/effects/mod.rs | effects | 视觉效果子系统骨架 | — | — |
| crates/astra-cli/src/cli/effects/spinner.rs | effects | 经典 stderr braille spinner | Spinner::start_immediate | crossterm、std::thread |
| crates/astra-cli/src/cli/effects/prep_spinner.rs | effects | 请求准备行 spinner（Plan 组装行/ChatTurnPrepLineGuard） | ChatTurnPrepLineGuard | terminal_region |
| crates/astra-cli/src/cli/effects/plan_spinner.rs | effects | 计划执行活动 spinner（ETA） | PlanSpinner | — |
| crates/astra-cli/src/cli/effects/tool_spinner.rs | effects | 工具运行 spinner（stderr 行/ stdout 动画两型） | ToolRunningLineSpinner 等 | terminal_region |
| crates/astra-cli/src/cli/effects/ttft_spinner.rs | effects | 首字节等待 spinner | TTFT spinner | — |
| crates/astra-cli/src/cli/effects/thinking_pane.rs | effects | 思维预览窗（增长到上限后折叠） | ThinkingPane | — |
| crates/astra-cli/src/cli/plan/mod.rs | plan | plan 子模块声明 | — | — |
| crates/astra-cli/src/cli/plan/plan_lifecycle.rs | plan | 本地 plan 模式入口/清理（Server 拥有持久 plan 审批） | looks_like_pending_local_plan_entry | slash_plan |
| crates/astra-cli/src/cli/session/mod.rs | session | 子模块声明 | — | — |
| crates/astra-cli/src/cli/session/session_state.rs | session | SessionState 中枢（模型/历史/权限/技能/通道） | SessionState、ExplainMode、SkillDevState | permission_manager |
| crates/astra-cli/src/cli/session/session_runtime.rs | session | 会话初始化、fresh token、pipeline 模块、默认模型解析 | initialize_session_state、fresh_access_token、resolve_server_default_model | astra-thin-client |
| crates/astra-cli/src/cli/session/session_startup.rs | session | TUI 启动编排（SessionStartupArtifacts） | complete_session_startup(:668) | edge_lifecycle、session_restore |
| crates/astra-cli/src/cli/session/session_input.rs | session | 输入准备（系统技能路由出用户消息） | prepare_input、FinalizedInput | prompts |
| crates/astra-cli/src/cli/session/session_projection.rs | session | 展示历史→messages 投影、续跑锚点 | history_as_messages、build_continuation_anchor | serde_json |
| crates/astra-cli/src/cli/session/session_continuation.rs | session | 从持久对话投影/journal 载入续跑历史 | recover_or_initialize_active_conversation | astra-services |
| crates/astra-cli/src/cli/session/session_adaptation.rs | session | 回合前后自适应准备/收尾 | prepare_turn_adaptation、finalize_turn_adaptation | session |
| crates/astra-cli/src/cli/session/session_checkpointing.rs | session | 用户触发 checkpoint（heavy→markdown 顺序） | checkpoint 构建 | session_recovery |
| crates/astra-cli/src/cli/session/session_cleanup.rs | session | 会话终态：journal session_end、workspace 收尾 | finalize_session_*_boundary | astra-services |
| crates/astra-cli/src/cli/session/session_compaction.rs | session | /compact 压缩后锚点记忆回补 | compaction helper | memoria |
| crates/astra-cli/src/cli/session/session_diagnosis.rs | session | 每回合自动诊断门（skill auto-invoke） | 诊断 handler | skills |
| crates/astra-cli/src/cli/session/session_execution_lease.rs | session | 请求级会话执行租约（首个 SSE 帧绑定身份） | RequestSessionExecutionLease | astra-services |
| crates/astra-cli/src/cli/session/session_guard.rs | session | panic/信号安全会话 guard | ShutdownSignal | libc/nix |
| crates/astra-cli/src/cli/session/session_lessons.rs | session | 跨会话课程检查点（写 Memoria fire-and-forget） | 课 checker | memoria |
| crates/astra-cli/src/cli/session/session_memory_inference.rs | session | Server 类型化记忆推理适配器 | 推理适配 | astra-turn-types |
| crates/astra-cli/src/cli/session/session_restore_client.rs | session | 云端会话快照恢复客户端 | cloud_resume_client、restore_session_snapshot_with_client | astra-thin-client |
| crates/astra-cli/src/cli/session/session_side_effects.rs | session | one-shot journal 事件追加等副作用 | append_one_shot_journal_events | astra-services |
| crates/astra-cli/src/cli/session/session_stats_scan.rs | session | 本地会话统计扫描（不可读 journal 标记） | RecentSessionStatsScan | astra-services |
| crates/astra-cli/src/cli/session/session_recovery/mod.rs | session_recovery | 恢复子系统声明（checkpoint/CSL/io/workspace） | — | — |
| crates/astra-cli/src/cli/session/session_recovery/checkpoint.rs | session_recovery | heavy/composite checkpoint 构建、持久、回滚 | build_manual_heavy_step_checkpoint、rollback_recovery_checkpoint(:341) | astra-pipeline |
| crates/astra-cli/src/cli/session/session_recovery/csl.rs | session_recovery | CSL（会话状态日志）load/rebuild/snapshot | CSL 操作 | astra-services |
| crates/astra-cli/src/cli/session/session_recovery/io.rs | session_recovery | 原子写/文件锁/路径原语 | io 原语 | fs2 |
| crates/astra-cli/src/cli/session/session_recovery/workspace.rs | session_recovery | workspace 元数据同步（resume 字段） | sync workspace | serde_yaml_ng |
| crates/astra-cli/src/cli/slash/mod.rs | slash | 24 个 slash 子模块声明 | — | — |
| crates/astra-cli/src/cli/slash/slash_router.rs | slash | headless/测试 slash 回退路由 | handle_slash_command(:72) | slash/* |
| crates/astra-cli/src/cli/slash/slash_account.rs | slash | /account 账户管理 | handle_account_command | astra-thin-client |
| crates/astra-cli/src/cli/slash/slash_agent.rs | slash | /agent list/tree/watch 代理检视 | 处理函数 | session |
| crates/astra-cli/src/cli/slash/slash_bug.rs | slash | /bug 诊断报告（print/copy/save） | handle_bug_command | clipboard |
| crates/astra-cli/src/cli/slash/slash_cache.rs | slash | /cache prompt 缓存诊断 | handle_cache_command、load_cache_rounds | astra-turn-core |
| crates/astra-cli/src/cli/slash/slash_config.rs | slash | /config 面板/子命令 + 展示用模型全局态 | handle、set_active_model_for_display | astra-config |
| crates/astra-cli/src/cli/slash/slash_debug.rs | slash | /debug 回合检查器（heavy checkpoint 优先） | handle_debug_command | astra-services |
| crates/astra-cli/src/cli/slash/slash_health.rs | slash | /health 兜底（同步状态/工具健康） | handle、display_sync_status | astra-services |
| crates/astra-cli/src/cli/slash/slash_info.rs | slash | 剪贴板复制工具（/info 支撑） | copy_to_clipboard | std::process |
| crates/astra-cli/src/cli/slash/slash_inspect.rs | slash | 工作台检查器事实模型 | InspectFact | session |
| crates/astra-cli/src/cli/slash/slash_mcp.rs | slash | /mcp 解析与动态子命令 | parse_mcp_command、build_mcp_extra_subcommands | astra-mcp |
| crates/astra-cli/src/cli/slash/slash_memory.rs | slash | /memory browse/search/stats 域命令 | handle_memory_domain_command | astra-thin-client |
| crates/astra-cli/src/cli/slash/slash_messaging.rs | slash | /messaging 指标/DLQ/邮箱状态 | handle_messaging_command | astra-messaging |
| crates/astra-cli/src/cli/slash/slash_plan.rs | slash | /plan 本地模式覆层（不造第二远端生命周期） | enter_local_plan_mode_with_goal | permission_manager |
| crates/astra-cli/src/cli/slash/slash_profile.rs | slash | /profile show/edit/scenario | handle | preferences_client |
| crates/astra-cli/src/cli/slash/slash_session.rs | slash | /session 列表/导出/journal 目标解析 | resolve_journal_target_session | astra-services |
| crates/astra-cli/src/cli/slash/slash_skill.rs | slash | /skill 装载/列出 | handle_skill_command | astra-skills |
| crates/astra-cli/src/cli/slash/slash_state.rs | slash | /state 命令上下文 | StateCommandContext | session |
| crates/astra-cli/src/cli/slash/slash_stats.rs | slash | /stats 会话/历史统计兜底 | handle_stats_command | session_analytics |
| crates/astra-cli/src/cli/slash/slash_sync.rs | slash | /sync 本地 durable outbox 视角 | handle（无直连 DB） | astra-services |
| crates/astra-cli/src/cli/slash/slash_team.rs | slash | /team CRUD/快照/历史 | TeamHistoryEntry 等 | http_team_store |
| crates/astra-cli/src/cli/slash/slash_telemetry.rs | slash | /telemetry 回合时序/漂移 | handle | observability |
| crates/astra-cli/src/cli/slash/slash_tools.rs | slash | /tools 工具画像兜底 | handle_tools_command | session_analytics |
| crates/astra-cli/src/cli/stream/mod.rs | stream | 子模块声明 | — | — |
| crates/astra-cli/src/cli/stream/output_sink.rs | stream | 进程级 stdout 边界：SIGPIPE 策略、Open/Closed/Failed 状态、退出码映射 | write_stdout*、resolved_exit_code、StdoutState | std::io、nix |
| crates/astra-cli/src/cli/stream/stream_render.rs | stream | SSE 消费宿主 CliSseStreamHost：事件分发、edge 工具执行/批处理/事务、审批、令牌刷新、StreamRenderState、consume_turn_sse(:7858) | consume_turn_sse、execute_tool(:4139)、resolve_approval(:5121)、EdgeToolCache | astra-thin-client、edge_tools、crossterm |
| crates/astra-cli/src/cli/stream/streaming_md.rs | stream | 增量 markdown 流渲染（稳定/不稳定块切分） | StreamingMd | — |
| crates/astra-cli/src/cli/stream/streaming_types.rs | stream | StreamResult/TurnFailure/PartialTurnData 等桥接类型 | StreamResult、TurnFailure | astra-turn-types |
| crates/astra-cli/src/cli/stream/stream_json.rs | stream | --output-format stream-json 严格机读流（逐行即写） | StreamJsonEmitter | output_sink、serde_json |
| crates/astra-cli/src/cli/stream/stream_events_writer.rs | stream | --stream-events JSONL 事件文件写入 | writer | tokio |
| crates/astra-cli/src/cli/surface/mod.rs | surface | 子模块声明 | — | — |
| crates/astra-cli/src/cli/surface/agent_journal_event_surface.rs | surface | 代理 spawned/terminated journal 投影 | AgentSpawnedProjection 等 | serde_json |
| crates/astra-cli/src/cli/surface/delegation_event_surface.rs | surface | 委派 started/sub-run 投影 | Delegation*Projection | serde_json |
| crates/astra-cli/src/cli/surface/health_status_surface.rs | surface | 健康状态语义分类 | HealthStatusKind | — |
| crates/astra-cli/src/cli/surface/run_status_surface.rs | surface | run 状态语义分类（是否终态） | RunStatusKind | — |
| crates/astra-cli/src/cli/surface/self_surface.rs | surface | /self 会话表面渲染 | render_surface_for_session | astra-thin-client |
| crates/astra-cli/src/cli/surface/session_source_surface.rs | surface | 会话来源（local/cloud/…）分类 | SessionSourceKind | — |
| crates/astra-cli/src/cli/surface/session_workspace_status_surface.rs | surface | workspace 状态分类 | SessionWorkspaceStatusKind | — |
| crates/astra-cli/src/cli/surface/skill_install_status_surface.rs | surface | 技能安装状态分类 | SkillInstallStatusKind | — |
| crates/astra-cli/src/cli/turn/mod.rs | turn | 回合管线声明 + facade 再导出 | execute_basic_cli_turn | — |
| crates/astra-cli/src/cli/turn/turn_entry.rs | turn | 交互回合入口：shell 直通、会话身份、准入、派发结算 | handle_chat_input(:229)、run_chat_turn(:146) | turn/* |
| crates/astra-cli/src/cli/turn/turn_facade.rs | turn | 一次性/无头回合薄门面（session-not-found 重试保留续跑消息） | execute_basic_cli_turn(:303) | chat_stream |
| crates/astra-cli/src/cli/turn/turn_stream_runner.rs | turn | 执行流回合并收集 StreamResult（中断区分） | execute_stream_turn(:58)、TurnAttempt | chat_stream |
| crates/astra-cli/src/cli/turn/turn_auth_retry.rs | turn | 鉴权失败回合重试 | 重试逻辑 | auth_flow |
| crates/astra-cli/src/cli/turn/turn_retry.rs | turn | 可恢复失败重试编排 | 重试编排 | turn_* |
| crates/astra-cli/src/cli/turn/turn_session_retry.rs | turn | session-not-found 重试准备与状态清理 | 重试准备 | one_shot_session_routing |
| crates/astra-cli/src/cli/turn/turn_cancellation.rs | turn | 取消后 drain helper | drain_after_cancel | tokio-util |
| crates/astra-cli/src/cli/turn/turn_settlement.rs | turn | 流结果→已提交状态迁移 | settle_turn_attempt(:21) | streaming_types |
| crates/astra-cli/src/cli/turn/turn_commit.rs | turn | 持久提交：journal/workspace/checkpoint/边车 | commit 函数 | session_recovery |
| crates/astra-cli/src/cli/turn/turn_post_commit.rs | turn | 已持久回合的延迟投影 | post-commit | turn_commit |
| crates/astra-cli/src/cli/turn/turn_success.rs | turn | 成功回合状态应用 | apply | session |
| crates/astra-cli/src/cli/turn/turn_failure_reporting.rs | turn | 失败回合用户态报告 | 报告函数 | exit_code |
| crates/astra-cli/src/cli/turn/turn_reporting.rs | turn | 终态报告/状态行/摘要渲染 | 报告函数 | crossterm |
| crates/astra-cli/src/cli/turn/turn_learning.rs | turn | 回合前后学习/反馈快照 | 快照函数 | astra-turn-core |
| crates/astra-cli/src/cli/turn/turn_runtime_state.rs | turn | 跨回合运行时 checkpoint 状态 | RuntimeStateCarrier | serde_json |
| crates/astra-cli/src/cli/turn/local_run_control.rs | turn | 本地运行控制（暂停/取消信号共享） | LocalRunControl | tokio-util |
| crates/astra-cli/src/edge_tools/fs.rs | edge_tools | 文件读写/目录工具实现（ToolExecutor 方法族） | execute_* | astra-tools |
| crates/astra-cli/src/edge_tools/shell.rs | edge_tools | shell 转义与危险命令检测、bash 执行 | shell_escape、check_dangerous_command | astra-sandbox |
| crates/astra-cli/src/edge_tools/file_state.rs | edge_tools | mtime/内容缓存防陈旧覆盖 | FileState 缓存 | std |
| crates/astra-cli/src/edge_tools/git_gix.rs | edge_tools | git 工具（委托 astra_tools::git_gix + CLI journal 包装） | git action 分发 | astra-tools、gix |
| crates/astra-cli/src/edge_tools/github.rs | edge_tools | github 工具（issue/PR 动作） | github 工具 | reqwest |
| crates/astra-cli/src/edge_tools/worktree.rs | edge_tools | git worktree enter/exit 会话管理 | worktree 工具 | gix |
| crates/astra-cli/src/edge_tools/code_analysis.rs | edge_tools | 12 个代码分析工具（tree-sitter） | symbols/find_definition/rename… | tree-sitter ×7 |
| crates/astra-cli/src/edge_tools/lsp_tools.rs | edge_tools | 统一 LSP 工具接口 | lsp 工具 | lsp_stdio_session |
| crates/astra-cli/src/edge_tools/lsp_stdio_session.rs | edge_tools | stdio LSP 客户端（Content-Length 帧/诊断订阅） | LspSession | tokio |
| crates/astra-cli/src/edge_tools/passive_lsp.rs | edge_tools | 常驻 rust-analyzer/tsserver（opt-in） | passive LSP | lsp_stdio_session |
| crates/astra-cli/src/edge_tools/mcp_dispatch.rs | edge_tools | MCP 工具路由+自动重连 | dispatch | astra-mcp |
| crates/astra-cli/src/edge_tools/memoria.rs | edge_tools | Memoria HTTP 客户端（熔断） | memoria 调用 | reqwest |
| crates/astra-cli/src/edge_tools/mo_tools.rs | edge_tools | MatrixOne SQL 查询/回滚 | mo_query | sqlx |
| crates/astra-cli/src/edge_tools/agent_spawning.rs | edge_tools | agent spawn/get_result CLI 桥（协议在 runtime） | spawn 上下文 | astra-runtime |
| crates/astra-cli/src/edge_tools/agent_messaging.rs | edge_tools | agent.send_message 邮箱运行上下文 | SendMessageRuntimeContext | astra-messaging |
| crates/astra-cli/src/edge_tools/ask_user.rs | edge_tools | ask_user 参数解析（原生前端） | 解析函数 | serde_json |
| crates/astra-cli/src/edge_tools/context_sharing.rs | edge_tools | share_context/query_context 实现 | 两个工具实现 | session |
| crates/astra-cli/src/edge_tools/context_tools.rs | edge_tools | 上下文工具集合（share/query/brief） | 工具入口 | context_sharing |
| crates/astra-cli/src/edge_tools/context_analysis.rs | edge_tools | LLM 可调用深度上下文分析 | analysis 工具 | astra-turn-core |
| crates/astra-cli/src/edge_tools/config_tool.rs | edge_tools | config 工具委托 | 委托 | astra-tools |
| crates/astra-cli/src/edge_tools/diagnose.rs | edge_tools | 系统诊断工具 | diagnose 工具 | sysinfo 类 |
| crates/astra-cli/src/edge_tools/notebook_edit.rs | edge_tools | Jupyter 单元格编辑 | notebook_edit | serde_json |
| crates/astra-cli/src/edge_tools/self_mod_tools.rs | edge_tools | 自修改类工具 | self-mod 工具 | — |
| crates/astra-cli/src/edge_tools/session_state.rs | edge_tools | 会话状态回滚 journal | SessionStateRollbackJournal | serde_json |
| crates/astra-cli/src/edge_tools/tool_search.rs | edge_tools | tool_search(select:) 静态+动态联合 | tool_search | astra-tools |
| crates/astra-edge/src/main.rs | astra-edge | Edge 主程序：配置/代理/WS 连接/认证/心跳/工具分发/重连 | run_edge_connection(:899)、main(:1361) | tokio-tungstenite、astra-tools |
| crates/astra-edge/src/invocation_journal.rs | astra-edge | 持久调用日志（WAL+状态、ack 前保留） | EdgeInvocationJournal、DurableEdgeResult、PrepareOutcome | tokio、fs2 |
| crates/astra-edge/src/token_manager.rs | astra-edge | 单锁令牌状态机（current/file/fallback/脏标记） | TokenManager（mark_proven/snapshot/swap_to_fallback） | tokio |
| crates/astra-edge/src/token_renewal.rs | astra-edge | moi-user-token-v1 自续期任务 | spawn_renewal_task、parse_moi_token_claims | reqwest |
| crates/astra-edge/src/runtime_process_authorization.rs | astra-edge | 带运行时进程授权的 bash 执行（注入 env） | execute_bash | astra-tools |

TUI（tui/，121 文件）：

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| crates/astra-cli/src/tui/mod.rs | tui | 模块声明、slash 模糊打分/截断工具、run_tui 再导出 | run_tui、score_slash_token、truncate_ellipsis | event_loop |
| crates/astra-cli/src/tui/event_loop.rs | tui | TUI 外层事件循环（bootstrap→终端接管→select 驱动） | run_tui_session(:4902)、can_run_tui(:4895) | crossterm、stream_bridge |
| crates/astra-cli/src/tui/event.rs | tui | 终端事件流（draw tick+键盘聚合） | TuiEventStream | crossterm |
| crates/astra-cli/src/tui/keymap.rs | tui | 键位映射（AppAction） | AppKeymap、AppAction | crossterm |
| crates/astra-cli/src/tui/draw.rs | tui | 帧组合：ActiveView 优先级 + do_draw | active_viewport、do_draw | ratatui |
| crates/astra-cli/src/tui/app_event.rs | tui | SSE 桥/内部动作 → 主循环事件 | TuiAppEvent | turn_event |
| crates/astra-cli/src/tui/stream_bridge.rs | tui | SSE→TuiAppEvent 通道创建与翻译 | create_channels | app_event |
| crates/astra-cli/src/tui/turn_event.rs | tui | 紧凑会话重建 payload（journal→cell） | TurnEvent | serde_json |
| crates/astra-cli/src/tui/terminal.rs | tui | TerminalGuard 终端生命周期 | TerminalGuard | ratatui、custom_terminal |
| crates/astra-cli/src/tui/terminal_startup.rs | tui | 首帧前的终端查询（DA1/调色板，echo 抑制） | StartupTerminal | crossterm(vendor) |
| crates/astra-cli/src/tui/terminal_palette.rs | tui | 终端调色板探测 | palette 探测 | crossterm |
| crates/astra-cli/src/tui/custom_terminal.rs | tui | 派生自 ratatui::Terminal 的本地终端 | Terminal 定制 | ratatui |
| crates/astra-cli/src/tui/frame_requester.rs | tui | 帧请求聚合（去抖调度） | FrameRequester | tokio broadcast |
| crates/astra-cli/src/tui/frame_rate_limiter.rs | tui | 帧率限制 | limiter | std |
| crates/astra-cli/src/tui/chat_widget/mod.rs | tui/chat_widget | ChatWidget：历史+活动流唯一事件路由 | ChatWidget、AppEvent/WireEvent | history_cell |
| crates/astra-cli/src/tui/chat_widget/bridge.rs | tui/chat_widget | TuiAppEvent→AppEvent 纯翻译边界 | translate、TurnContext | app_event |
| crates/astra-cli/src/tui/chat_widget/resume.rs | tui/chat_widget | 恢复会话的 canonical journal 重建 scrollback | load(:12) | astra-services |
| crates/astra-cli/src/tui/chat_widget/agent_control_surface.rs | tui/chat_widget | 代理控制（spawn/终止/收结果）表面 | AgentControlSurface/Occupancy | agent_run_projection |
| crates/astra-cli/src/tui/chat_widget/turn_driver.rs | tui/chat_widget | cfg(test) 端到端回合 harness（清单注记：仅测试编译） | 测试 driver | chat_widget |
| crates/astra-cli/src/tui/history_cell/mod.rs | tui/history_cell | HistoryCell trait 家族 | HistoryCell | — |
| crates/astra-cli/src/tui/history_cell/user.rs | tui/history_cell | 用户回合 cell（引用块） | UserCell | — |
| crates/astra-cli/src/tui/history_cell/assistant.rs | tui/history_cell | 助手答复 cell（markdown 源+布局缓存） | AssistantCell | markdown_render |
| crates/astra-cli/src/tui/history_cell/reasoning.rs | tui/history_cell | 思维 cell（流式滚动窗/完成折叠） | ReasoningCell | — |
| crates/astra-cli/src/tui/history_cell/system.rs | tui/history_cell | 系统提示 cell（note/result/warn/error） | SystemCell | — |
| crates/astra-cli/src/tui/history_cell/tool.rs | tui/history_cell | 工具 cell（Running/Ran/流计数三态） | ToolCell | shimmer |
| crates/astra-cli/src/tui/history_cell/task.rs | tui/history_cell | Task 容器 cell（头+子事件） | TaskCell | tool |
| crates/astra-cli/src/tui/history_cell/approval.rs | tui/history_cell | 内联审批卡（composer 上方） | ApprovalCell | approval |
| crates/astra-cli/src/tui/history_cell/turn_summary.rs | tui/history_cell | 回合后指标带 cell | TurnSummaryCell | — |
| crates/astra-cli/src/tui/approval/mod.rs | tui/approval | 非阻塞审批队列门面 | ApprovalQueue、ButtonRow | queue |
| crates/astra-cli/src/tui/approval/queue.rs | tui/approval | 审批队列+焦点模型+metadata 构造器 | ApprovalQueue、ApprovalView、PendingApproval | oneshot |
| crates/astra-cli/src/tui/approval/button_row.rs | tui/approval | 按钮行纯逻辑（焦点/批量项） | ButtonRow、ButtonAction | — |
| crates/astra-cli/src/tui/bottom_pane/mod.rs | tui/bottom_pane | 底栏容器与子视图声明 | BottomPane、BottomPaneAction | view |
| crates/astra-cli/src/tui/bottom_pane/view.rs | tui/bottom_pane | BottomPaneView trait 与语义动作 | BottomPaneViewAction | ratatui |
| crates/astra-cli/src/tui/bottom_pane/textarea.rs | tui/bottom_pane | 多行文本编辑器 | TextArea | unicode-width |
| crates/astra-cli/src/tui/bottom_pane/chat_composer.rs | tui/bottom_pane | 聊天输入组合器 | ChatComposer | textarea、mention_menu |
| crates/astra-cli/src/tui/bottom_pane/paste_burst.rs | tui/bottom_pane | 粘贴突发检测（防误提交） | burst 状态机 | — |
| crates/astra-cli/src/tui/bottom_pane/footer.rs | tui/bottom_pane | StatusLine 兼容 shim | Footer | status_line |
| crates/astra-cli/src/tui/bottom_pane/help_view.rs | tui/bottom_pane | 帮助视图 | HelpView | view |
| crates/astra-cli/src/tui/bottom_pane/info_view.rs | tui/bottom_pane | 信息视图 | InfoView | view |
| crates/astra-cli/src/tui/bottom_pane/list_selection_view.rs | tui/bottom_pane | 通用列表选择视图 | ListSelectionView | view |
| crates/astra-cli/src/tui/bottom_pane/login_view.rs | tui/bottom_pane | /login、/register 表单视图 | LoginView | auth_flow |
| crates/astra-cli/src/tui/bottom_pane/ask_user_view.rs | tui/bottom_pane | ask_user 问题表单视图 | AskUserView | view |
| crates/astra-cli/src/tui/bottom_pane/plan_review_view.rs | tui/bottom_pane | exit_plan_mode 四选一评审覆层 | PlanReviewView | markdown |
| crates/astra-cli/src/tui/bottom_pane/config_edit_view.rs | tui/bottom_pane | /config edit 两列 list+detail 编辑器 | ConfigEditView | astra-config |
| crates/astra-cli/src/tui/bottom_pane/context_panel_view.rs | tui/bottom_pane | /context 面板包装（滚动） | ContextPanelView | context_panel |
| crates/astra-cli/src/tui/bottom_pane/session_picker_view.rs | tui/bottom_pane | 会话恢复选择器包装 | SessionPickerView | session_picker |
| crates/astra-cli/src/tui/bottom_pane/skill_popup.rs | tui/bottom_pane | 技能弹窗 | SkillPopup | view |
| crates/astra-cli/src/tui/bottom_pane/task_detail_view.rs | tui/bottom_pane | TaskCell 明细钻入 | TaskDetailView | task cell |
| crates/astra-cli/src/tui/bottom_pane/timeline_view.rs | tui/bottom_pane | /timeline 面板包装 | TimelineView | timeline |
| crates/astra-cli/src/tui/bottom_pane/transcript_view.rs | tui/bottom_pane | 共享 transcript 交互面 | TranscriptView | turn_event |
| crates/astra-cli/src/tui/bottom_pane/root_transcript_view.rs | tui/bottom_pane | 根会话 transcript 浏览（分页） | RootTranscriptView | transcript_view |
| crates/astra-cli/src/tui/bottom_pane/agent_transcript_view.rs | tui/bottom_pane | 代理范围 transcript 加载/分页 | AgentTranscriptView | transcript_view |
| crates/astra-cli/src/tui/bottom_pane/agent_guide_view.rs | tui/bottom_pane | 单代理运行引导输入 | AgentGuideView | view |
| crates/astra-cli/src/tui/bottom_pane/in_flight_agents_view.rs | tui/bottom_pane | Ctrl+G 多代理导航器 | InFlightAgentsView | agent_run_projection |
| crates/astra-cli/src/tui/bottom_pane/worktrees_view.rs | tui/bottom_pane | /worktrees 面板包装 | WorktreesView | worktrees |
| crates/astra-cli/src/tui/bottom_pane/background_task_view/mod.rs | tui/bottom_pane | 后台任务切换器入口 | BackgroundTaskView | types |
| crates/astra-cli/src/tui/bottom_pane/background_task_view/types.rs | tui/bottom_pane | 后台任务视图类型 | 行/动作类型 | bg_task_proxy |
| crates/astra-cli/src/tui/bottom_pane/background_task_view/list_render.rs | tui/bottom_pane | 列表模式渲染 | 行布局/绘制 | ratatui |
| crates/astra-cli/src/tui/bottom_pane/background_task_view/detail_render.rs | tui/bottom_pane | 详情模式渲染（输出尾部/计时） | 详情绘制 | ratatui |
| crates/astra-cli/src/tui/bottom_pane/background_task_view/fanout_header.rs | tui/bottom_pane | 扇出组头计算与渲染 | header | ratatui |
| crates/astra-cli/src/tui/context_panel/mod.rs | tui/context_panel | /context 面板：token 预算可视化 | ContextPanel | context_assembly_trace |
| crates/astra-cli/src/tui/context_panel/model.rs | tui/context_panel | /context 纯数据模型（格+图例+子区） | grid model | astra-turn-core |
| crates/astra-cli/src/tui/context_panel/view.rs | tui/context_panel | /context 渲染层 | view | ratatui |
| crates/astra-cli/src/tui/session_picker/mod.rs | tui/session_picker | 会话恢复选择器（分层） | SessionDiscovery | discovery |
| crates/astra-cli/src/tui/session_picker/discovery.rs | tui/session_picker | 纯发现模型（模糊过滤/预计算年龄） | ResumableSession | — |
| crates/astra-cli/src/tui/session_picker/view.rs | tui/session_picker | 双栏选择器 widget | view | ratatui |
| crates/astra-cli/src/tui/slash_menu/mod.rs | tui/slash_menu | 斜杠菜单纯逻辑（打开规则/打分） | SlashMenu、score_token | — |
| crates/astra-cli/src/tui/slash_menu/menu.rs | tui/slash_menu | 两级补全菜单逻辑 | menu 状态机 | command_registry |
| crates/astra-cli/src/tui/slash_menu/popup.rs | tui/slash_menu | 斜杠弹出 widget | popup | ratatui |
| crates/astra-cli/src/tui/mention_menu/mod.rs | tui/mention_menu | @-mention 菜单（触发规则） | MentionMenu | provider |
| crates/astra-cli/src/tui/mention_menu/menu.rs | tui/mention_menu | 纯逻辑 mention 菜单 | menu | — |
| crates/astra-cli/src/tui/mention_menu/popup.rs | tui/mention_menu | mention 弹出 widget | popup | ratatui |
| crates/astra-cli/src/tui/mention_menu/provider.rs | tui/mention_menu | 文件枚举抽象（测试注入） | FileProvider | std::fs |
| crates/astra-cli/src/tui/status_line/mod.rs | tui/status_line | 状态行组合框架 | StatusLine | line |
| crates/astra-cli/src/tui/status_line/line.rs | tui/status_line | 纯状态行组合（StatusContext→行） | StatusContext | theme |
| crates/astra-cli/src/tui/status_line/context_bar.rs | tui/status_line | 上下文容量轨（composer 上方） | context rail | theme |
| crates/astra-cli/src/tui/status_indicator.rs | tui | 回合运行中单行活动指示 | StatusIndicator | glyphs |
| crates/astra-cli/src/tui/task_list/mod.rs | tui/task_list | Tier1 会话任务板渲染 | TaskList | work_board_projection |
| crates/astra-cli/src/tui/task_status.rs | tui | 任务状态类型 | TaskStatus | serde |
| crates/astra-cli/src/tui/task_board_observer.rs | tui | Work Task Graph 锁一致读模型 | TaskBoardObserver | task_board_events |
| crates/astra-cli/src/tui/task_board_events.rs | tui | 任务板 diff 事件（新增/翻转/删除闪烁） | BoardDiffEvent | — |
| crates/astra-cli/src/tui/plan_task_observer.rs | tui | 会话 Work Task Graph 有界只读观察 | PlanTaskObserver | astra-services |
| crates/astra-cli/src/tui/plan_mode.rs | tui | plan 模式 UI 助手（切换通知/目标解析） | plan helpers | permission_manager |
| crates/astra-cli/src/tui/board_pin.rs | tui | 任务板可见性状态机（用户 pin vs 自动） | board pin 状态 | — |
| crates/astra-cli/src/tui/background_shortcut.rs | tui | Ctrl+B 后台化快捷处理 | 快捷逻辑 | background_tasks |
| crates/astra-cli/src/tui/background_tasks.rs | tui | 后台 shell 任务注册表（spawn/kill/文件捕获） | BackgroundTaskRegistry | tokio-util |
| crates/astra-cli/src/tui/bg_task_proxy.rs | tui | 后台任务数据投影/持久化（纯数据层） | proxy 函数 | background_tasks |
| crates/astra-cli/src/tui/bg_task_rendering.rs | tui | 后台任务渲染（行/XML/视图编排） | 渲染函数 | bg_task_proxy |
| crates/astra-cli/src/tui/agent_view.rs | tui | 代理视图打开/刷新/管理 helper | agent view 函数 | event_loop 上下文 |
| crates/astra-cli/src/tui/agent_run_projection.rs | tui | 代理监视投影类型（状态×置信度） | AgentRunState/Status/Confidence | serde |
| crates/astra-cli/src/tui/agent_control_status.rs | tui | 代理控制状态计算 | 控制状态 | agent_run_projection |
| crates/astra-cli/src/tui/local_agent_journal.rs | tui | 从 canonical journal 重建本地代理索引 | journal 索引 | astra-services |
| crates/astra-cli/src/tui/local_agent_snapshot.rs | tui | 本地代理运行时有界快照（50ms 节流） | snapshot | spawn_subrun |
| crates/astra-cli/src/tui/server_agent_observer.rs | tui | 服务端 run 树非阻塞观察（TUI tick 外网络） | observer | astra-thin-client |
| crates/astra-cli/src/tui/work_board_projection.rs | tui | Work 图纯展示投影（无存储 API） | 投影类型 | astra-services |
| crates/astra-cli/src/tui/markdown.rs | tui | markdown 文本模型 | md 工具 | pulldown-cmark |
| crates/astra-cli/src/tui/markdown_render.rs | tui | markdown→终端行渲染 | 渲染器 | markdown、ratatui |
| crates/astra-cli/src/tui/diff_render.rs | tui | diff 渲染（对齐行号/沟槽符号） | diff 渲染 | wrapping |
| crates/astra-cli/src/tui/wrapping.rs | tui | URL/路径感知换行 | wrap | textwrap |
| crates/astra-cli/src/tui/render/mod.rs | tui/render | 渲染底座声明 | — | — |
| crates/astra-cli/src/tui/render/renderable.rs | tui/render | FlexRenderable 布局（移植 Codex MIT） | FlexRenderable | ratatui |
| crates/astra-cli/src/tui/render/line_utils.rs | tui/render | 行工具（终端清洗等） | sanitize_lines_for_terminal | unicode-width |
| crates/astra-cli/src/tui/render/highlight.rs | tui/render | 语法高亮 span | highlight | tree-sitter |
| crates/astra-cli/src/tui/theme.rs | tui | TUI 语义配色唯一来源（含浅色端适配） | Theme、current_stderr | terminal_palette |
| crates/astra-cli/src/tui/color.rs | tui | 颜色转换/工具 | to_crossterm_color | ratatui |
| crates/astra-cli/src/tui/style.rs | tui | 样式工具 | style helper | ratatui |
| crates/astra-cli/src/tui/glyphs.rs | tui | 终端安全字形档（Unicode/ASCII） | glyphs | — |
| crates/astra-cli/src/tui/shimmer.rs | tui | 动画时间原点/闪烁效果 | init_time_origin | std |
| crates/astra-cli/src/tui/path_style.rs | tui | 路径 dim 目录+bright 文件名拆分 | path spans | — |
| crates/astra-cli/src/tui/insert_history.rs | tui | 历史 cell 插入 helper | 插入函数 | history_cell |
| crates/astra-cli/src/tui/file_writer.rs | tui | 有序非阻塞文件效果 worker | spawn | tokio mpsc |
| crates/astra-cli/src/tui/external_editor.rs | tui | $EDITOR 外部编辑 | 打开编辑器 | std::process |
| crates/astra-cli/src/tui/slash_dispatch.rs | tui | TUI 原生 slash 分发（不切出 TUI） | dispatch | bottom_pane |
| crates/astra-cli/src/tui/config_edit_router.rs | tui | ConfigEditView 完成结果的 TOML 写回 | 完成路由 | toml、astra-config |
| crates/astra-cli/src/tui/ui_adapter.rs | tui | ReplUiAdapter 的 TUI 实现（事件入通道不写终端） | TuiUiAdapter | app_event |
| crates/astra-cli/src/tui/timeline/mod.rs | tui/timeline | /timeline 面板门面 | Timeline、JournalTurnSource | model |
| crates/astra-cli/src/tui/timeline/model.rs | tui/timeline | 纯只读 timeline 模型（每回合指标） | Timeline | astra-services |
| crates/astra-cli/src/tui/timeline/view.rs | tui/timeline | 双栏 timeline widget | view | ratatui |
| crates/astra-cli/src/tui/worktrees/mod.rs | tui/worktrees | /worktrees 面板门面 | Worktrees | model |
| crates/astra-cli/src/tui/worktrees/model.rs | tui/worktrees | 纯 worktree 列表模型 | model | gix |
| crates/astra-cli/src/tui/worktrees/view.rs | tui/worktrees | 双栏 worktree widget | view | ratatui |

### 附表一：web/ 文件清单（174 个生产 TS/TSX/配置文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
| --- | --- | --- | --- | --- |
| web/app/(workspace)/artifacts/page.tsx | 页面 | Artifacts 占位页（EmptyState） | ArtifactsPage | ui/empty-state |
| web/app/(workspace)/chats/[chatId]/page.tsx | 页面 | 聊天详情服务端入口：鉴权+注水 ChatView | ChatPage | auth/actions, web-store, chat-view |
| web/app/(workspace)/chats/page.tsx | 页面 | 全部聊天列表 | ChatsPage | chats-list |
| web/app/(workspace)/customize/page.tsx | 页面 | Customize 占位页 | CustomizePage | ui/empty-state |
| web/app/(workspace)/harnesses/page.tsx | 页面 | Harness 评测页外壳 | Page | harnesses-page |
| web/app/(workspace)/now/page.tsx | 页面 | "Now" 工作收件箱：服务端 listWorks 游标分页 | NowPage | runtime-client, @astra/sdk, work-now-page |
| web/app/(workspace)/overview/page.tsx | 页面 | 重定向到 / | OverviewRedirectPage | next/navigation |
| web/app/(workspace)/projects/new/page.tsx | 页面 | 新建项目表单页 | NewProjectPage | create-project-form |
| web/app/(workspace)/projects/[projectId]/chats/[chatId]/page.tsx | 页面 | 项目作用域聊天页（校验 chat.projectId） | ProjectChatPage | auth/actions, web-store, chat-view |
| web/app/(workspace)/projects/[projectId]/page.tsx | 页面 | 项目详情服务端入口 | ProjectPage | auth/actions, web-store, project-detail |
| web/app/(workspace)/projects/page.tsx | 页面 | 项目列表（Suspense） | ProjectsPage | projects-list |
| web/app/(workspace)/works/[workId]/actions.ts | server actions | Work 详情页全部服务端动作（transcript 分页、分支控制/fork/删除/归档、标准提案决策、补丁导出/物化/提交、读游标、任务图） | loadWorkTranscriptPageAction, markWorkSeenAction 等 | @astra/sdk, runtime-client, work-overview |
| web/app/(workspace)/works/[workId]/page.tsx | 页面 | Work 概览服务端入口（分支目录+快照） | WorkPage | runtime-client, work-overview, work-overview-page |
| web/app/(workspace)/works/actions.ts | server actions | startWorkAction 等（严格输入校验后 createWork） | StartWorkResult, startWorkAction | runtime-client, work-action-error |
| web/app/(workspace)/works/page.tsx | 页面 | Work 起始页（输入 goal） | WorksPage | work-start-page |
| web/app/(workspace)/layout.tsx | 布局 | 已登录包 AppShell，未登录裸渲染 | WorkspaceLayout | app-shell, auth/actions |
| web/app/(workspace)/page.tsx | 页面 | 落地页/登录后首页分流 | HomePage | landing-screen, home-screen, auth/actions |
| web/app/api/chats/[chatId]/approval/route.ts | API | 工具审批 allow/deny 透传 | POST | auth-guard, web-store, runtime-client |
| web/app/api/chats/[chatId]/input/route.ts | API | 活跃 run 延迟输入排队（≤20k 字符、工作区不可变校验） | POST | auth-guard, web-store, workspace-authority |
| web/app/api/chats/[chatId]/insights/route.ts | API | 聚合审计摘要+reflect+决策链（allSettled 降级） | GET | auth-guard, web-store, runtime-client, @astra/sdk |
| web/app/api/chats/[chatId]/messages/route.ts | API | 非流式发消息 | POST | auth-guard, web-store |
| web/app/api/chats/[chatId]/resume/route.ts | API | 恢复暂停 run | POST | auth-guard, web-store |
| web/app/api/chats/[chatId]/stop/route.ts | API | 停止活跃 run（1.5s cancel ack 超时乐观返回） | POST | auth-guard, web-store, runtime-client |
| web/app/api/chats/[chatId]/stream/route.ts | API | 聊天 SSE 代理：POST 新回合 / GET 重挂 run（见 CH6） | POST, GET | auth-guard, web-store, stream-event-handler, runtime-client, @astra/sdk |
| web/app/api/chats/[chatId]/work-surface/runs/[runId]/route.ts | API | 单个 run 的工作面事件重建 | GET | auth-guard, web-store, work-surface, @astra/sdk |
| web/app/api/chats/[chatId]/work-surface/route.ts | API | 聊天工作面（活动 run 投影+事件） | GET | auth-guard, web-store, work-surface, @astra/sdk |
| web/app/api/chats/[chatId]/route.ts | API | 聊天详情 GET / PATCH（归档/模型/工作区/移动）/ DELETE | GET, PATCH, DELETE | auth-guard, web-store, runtime-client |
| web/app/api/chats/route.ts | API | 聊天列表 GET / 新建聊天 POST | GET, POST | auth-guard, web-store, runtime-client |
| web/app/api/edges/status/route.ts | API | 边缘执行器状态透传（失败返回空） | GET | @astra/sdk, runtime-client |
| web/app/api/harnesses/node-catalog/route.ts | API | Harness 节点目录薄代理 | GET | runtime-client |
| web/app/api/harnesses/runs/[runId]/items/[itemId]/decision/route.ts | API | 用例条目人工决策薄代理 | POST | runtime-client |
| web/app/api/harnesses/runs/[runId]/items/route.ts | API | 运行条目列表薄代理 | GET | runtime-client |
| web/app/api/harnesses/runs/[runId]/skill-drafts/[draftId]/decision/route.ts | API | 技能草稿接受/拒绝薄代理 | POST | runtime-client |
| web/app/api/harnesses/runs/[runId]/skill-drafts/[draftId]/publish/route.ts | API | 技能草稿发布薄代理 | POST | runtime-client |
| web/app/api/harnesses/runs/[runId]/skill-drafts/[draftId]/rules/[ruleId]/decision/route.ts | API | 草稿规则级决策薄代理 | POST | runtime-client |
| web/app/api/harnesses/runs/[runId]/skill-drafts/[draftId]/route.ts | API | 技能草稿详情薄代理 | GET | runtime-client |
| web/app/api/harnesses/runs/[runId]/skill-drafts/route.ts | API | 技能草稿列表薄代理 | GET | runtime-client |
| web/app/api/harnesses/runs/[runId]/skillify/draft/route.ts | API | 创建 Skillify 草稿薄代理（201） | POST | runtime-client |
| web/app/api/harnesses/runs/[runId]/route.ts | API | Harness 运行详情薄代理 | GET | runtime-client |
| web/app/api/harnesses/skillify/runs/route.ts | API | 创建 Skillify 运行薄代理（201） | POST | runtime-client |
| web/app/api/harnesses/templates/route.ts | API | Harness 模板薄代理 | GET | runtime-client |
| web/app/api/models/route.ts | API | 模型目录：SDK 分页聚合+access 映射为 ModelSummary | GET | @astra/sdk, runtime-client |
| web/app/api/projects/[projectId]/files/[fileId]/route.ts | API | 删除项目知识文件（本地 store） | DELETE | auth-guard, web-store |
| web/app/api/projects/[projectId]/files/route.ts | API | multipart 上传知识文件（本地 store） | POST | auth-guard, web-store |
| web/app/api/projects/[projectId]/star/route.ts | API | 项目收藏/取消 | POST, DELETE | auth-guard, web-store |
| web/app/api/projects/[projectId]/route.ts | API | 项目详情 GET / PUT / DELETE | GET, PUT, DELETE | auth-guard, web-store |
| web/app/api/projects/route.ts | API | 项目列表 GET / 创建 POST（纯本地 CRUD） | GET, POST | auth-guard, web-store |
| web/app/api/runtime/capabilities/route.ts | API | 运行时能力开关透传 | GET | @astra/sdk, runtime-client |
| web/app/api/runtime-auth/login/route.ts | API | 登录：调后端 /auth/login 并写三枚 httpOnly cookie | POST | runtime-auth-client, runtime-config |
| web/app/api/runtime-auth/logout/route.ts | API | 登出：吊销 refresh token + 清 cookie | POST | runtime-auth-client, runtime-config |
| web/app/api/runtime-auth/me/route.ts | API | cookie→/auth/me 代理 | GET | runtime-auth-client, runtime-config |
| web/app/api/runtime-auth/refresh/route.ts | API | cookie→/auth/refresh 换新并回写 | POST | runtime-auth-client, runtime-config |
| web/app/api/runtime-config/route.ts | API | 读写运行时连接配置（apiUrl/token/demo cookie） | GET, POST | runtime-config |
| web/app/api/search/route.ts | API | 本地聊天/项目搜索 | GET | auth-guard, web-store |
| web/app/api/sidebar/route.ts | API | 侧栏数据聚合 + 用户识别（含 token 刷新） | GET | runtime-auth-client, web-store, runtime-config |
| web/app/api/skills/route.ts | API | 技能目录分页（游标三字段）透传 | GET | @astra/sdk, runtime-client |
| web/app/api/works/[workId]/branches/[branchId]/turns/route.ts | API | Work 分支回合 SSE 代理（严格体积/字段校验+事件解码） | POST | @astra/sdk, runtime-client |
| web/app/login/page.tsx | 页面 | 登录表单（useActionState+loginAction，next 跳转） | LoginPage | auth-shell, auth/actions |
| web/app/register/page.tsx | 页面 | 注册表单（registerAction） | RegisterPage | auth-shell, auth/actions |
| web/app/global-error.tsx | 页面 | 全局错误边界（自带 html/body） | GlobalError（default） | react |
| web/app/layout.tsx | 布局 | 根布局（metadata+globals.css） | RootLayout（default） | next |
| web/app/not-found.tsx | 页面 | 404 页 | NotFound（default） | next/link |
| web/components/app/app-shell.tsx | 组件 | 应用壳：侧栏+Cmd+K 搜索+Toast Provider+快捷键 | AppShell | sidebar, search-modal, ui/toast |
| web/components/app/chat-actions-menu.tsx | 组件 | 聊天行操作菜单（归档/重命名/移动/导出/删除，带确认面板） | ChatActionsMenu | ui/menu, use-chat-lifecycle-actions |
| web/components/app/chat-dot-navigator.tsx | 组件 | 消息流右侧圆点导航（跳转锚点） | ChatDotNavigator | lib/utils/cn |
| web/components/app/chat-row.tsx | 组件 | 侧栏聊天行（勾选+菜单+TUI 标记） | ChatRow | chat-actions-menu, tui-entity-mark |
| web/components/app/chat-view.tsx | 组件 | 聊天页状态中枢（1216 行）：组合 composer/消息流/工作面/生命周期 hooks | ChatView | use-stream-lifecycle, use-chat-lifecycle-actions, work-surface-panel 等 |
| web/components/app/chats-list.tsx | 组件 | 聊天列表页（分页/搜索/批量归档） | ChatsList | ui/*, lib/api/chats |
| web/components/app/composer-plus-menu.tsx | 组件 | Composer "+" 菜单：工作区选择 chip、附件、能力开关 | ComposerPlusMenu, ComposerEnvironmentChip | @astra/sdk 类型, runtime-capabilities |
| web/components/app/composer.tsx | 组件 | contentEditable 输入框：skill 令牌、斜杠命令、模型切换、思考开关、停止按钮 | Composer, compactComposerPlaceholder | model-switcher, slash-command-panel, composer/slash-commands |
| web/components/app/create-project-form.tsx | 组件 | 新建项目表单（zod 校验） | CreateProjectForm | zod, ui/*, lib/api/projects |
| web/components/app/harnesses-page.tsx | 组件 | Harness 页（1245 行）：模板选择、运行创建、条目决策、Skillify 草稿审阅/发布 | HarnessesPage | lib/api/harnesses, ui/* |
| web/components/app/home-screen.tsx | 组件 | 登录后首页（最近项目/聊天/入口卡片） | HomeScreen | lib/api/*, ui/* |
| web/components/app/instructions-modal.tsx | 组件 | 项目指令编辑弹窗 | InstructionsModal | ui/modal, ui/textarea |
| web/components/app/knowledge-card.tsx | 组件 | 知识文件分组卡片容器 | KnowledgeCard | ui/card |
| web/components/app/knowledge-item.tsx | 组件 | 单个知识文件行（状态/删除） | KnowledgeItem | ui/icon-button |
| web/components/app/landing-screen.tsx | 组件 | 未登录落地页（功能介绍） | LandingScreen | next/link |
| web/components/app/message-bubble.tsx | 组件 | 消息气泡：ReactMarkdown+KaTeX+高亮、thinking 折叠、artifacts、复制/下载 | MessageBubble | react-markdown, rehype-*, lib/api/chats(splitThinkingTags) |
| web/components/app/model-switcher.tsx | 组件 | 模型选择下拉（access 状态排序、不可用原因提示） | ModelSwitcher | ui/popover, lib/api/models |
| web/components/app/move-chat-modal.tsx | 组件 | 移动聊天到项目弹窗 | MoveChatModal | ui/*, lib/api/* |
| web/components/app/project-card.tsx | 组件 | 项目卡片（收藏/打开） | ProjectCard | ui/card, ui/icon-button |
| web/components/app/project-detail.tsx | 组件 | 项目详情（聊天列表/知识/指令/编辑） | ProjectDetail | ui/*, lib/api/* |
| web/components/app/projects-list.tsx | 组件 | 项目列表（搜索/排序/新建） | ProjectsList | ui/*, lib/api/projects |
| web/components/app/search-modal.tsx | 组件 | Cmd+K 全局搜索（cmdk） | SearchModal | cmdk, lib/api/search |
| web/components/app/sidebar-section.tsx | 组件 | 转发 ui/sidebar-section | SidebarSection | ui/sidebar-section |
| web/components/app/sidebar.tsx | 组件 | 侧栏（导航、聊天分组、折叠持久化、生命周期事件刷新） | Sidebar | use-sidebar, use-chat-lifecycle-actions, lib/api/sidebar |
| web/components/app/skill-mention-text.tsx | 组件 | 消息文本中 skill @提及 高亮 | SkillMentionText | composer/skill-mentions |
| web/components/app/skill-picker-panel.tsx | 组件 | Composer 内技能选择面板（分页搜索） | SkillPickerPanel | use-skill-catalog |
| web/components/app/slash-command-panel.tsx | 组件 | "/" 命令下拉（skill/mode/action） | SlashCommandPanel | composer/slash-commands |
| web/components/app/tui-entity-mark.tsx | 组件 | TUI 风格实体字母标 | TuiEntityMark | lib/utils/cn |
| web/components/app/unified-diff-view.tsx | 组件 | 统一 diff 查看器（行高亮/折叠） | UnifiedDiffView | lib/utils/cn |
| web/components/app/user-badge.tsx | 组件 | 侧栏用户徽标（登出菜单） | UserBadge | ui/*, auth/logout-button |
| web/components/app/work-activity-card.tsx | 组件 | Work 事件活动卡（标记已读） | WorkActivityCard | works/[workId]/actions |
| web/components/app/work-now-page.tsx | 组件 | Now 收件箱渲染（服务端数据） | WorkNowPage | @astra/sdk 类型 |
| web/components/app/work-overview-page.tsx | 组件 | Work 概览（1541 行）：分支切换、标准提案、任务图、补丁审阅、对话 | WorkOverviewPage | works/[workId]/actions, work-*组件 |
| web/components/app/work-patch-review-card.tsx | 组件 | 补丁审阅卡：导出/物化/提交/中止流程 | WorkPatchReviewCard | works/[workId]/actions, unified-diff-view |
| web/components/app/work-start-page.tsx | 组件 | 新建 Work（goal 输入→startWorkAction） | WorkStartPage | works/actions |
| web/components/app/work-surface-panel.tsx | 组件 | 聊天右侧工作面（3058 行）：工具/agent/任务图/审批 tabs | WorkSurfacePanel | lib/work-surface, work-task-graph |
| web/components/app/work-task-graph.tsx | 组件 | 任务图 DAG 可视化（@xyflow/react） | WorkTaskGraph | @xyflow/react, @astra/sdk |
| web/components/app/work-transcript-card.tsx | 组件 | Work 分支对话记录分页卡 | WorkTranscriptCard | works/[workId]/actions |
| web/components/app/work-turn-composer.tsx | 组件 | Work 回合 composer：SDK SSEClient 直连 SSE 代理 | WorkTurnComposer | @astra/sdk(SSEClient) |
| web/components/auth/auth-shell.tsx | 组件 | 登录/注册页外壳排版 | AuthShell | — |
| web/components/auth/logout-button.tsx | 组件 | 登出按钮（logoutAction） | LogoutButton | auth/actions |
| web/components/auth/user-badge.tsx | 组件 | auth 区用户徽标 | （default 导出组件） | auth/actions |
| web/components/ui/avatar.tsx | UI | 头像 | Avatar | — |
| web/components/ui/button.tsx | UI | 按钮变体 | Button | — |
| web/components/ui/card.tsx | UI | 卡片容器 | Card | — |
| web/components/ui/empty-state.tsx | UI | 空状态占位 | EmptyState | lucide-react |
| web/components/ui/icon-button.tsx | UI | 图标按钮 | IconButton | — |
| web/components/ui/input.tsx | UI | 输入框 | Input | — |
| web/components/ui/list-item.tsx | UI | 列表行 | ListItem | — |
| web/components/ui/menu.tsx | UI | 下拉菜单（Radix 封装+确认面板） | Menu, MenuItem, MenuConfirmPanel, ConfirmMenuItem | @radix-ui/react-dropdown-menu |
| web/components/ui/modal.tsx | UI | 模态框（Radix Dialog） | Modal | @radix-ui/react-dialog |
| web/components/ui/page-header.tsx | UI | 页头 | PageHeader | — |
| web/components/ui/popover.tsx | UI | 弹出层（Radix） | Popover | @radix-ui/react-popover |
| web/components/ui/search-field.tsx | UI | 搜索输入 | SearchField | — |
| web/components/ui/sidebar-section.tsx | UI | 侧栏分区（标题+折叠） | SidebarSection | — |
| web/components/ui/textarea.tsx | UI | 多行输入 | Textarea | — |
| web/components/ui/toast.tsx | UI | Toast 通知（Provider+useToast） | ToastContainer, useToast, ToastProvider | react |
| web/hooks/use-async-data.ts | hooks | 通用异步数据加载（loading/error/reload） | useAsyncData | react |
| web/hooks/use-chat-lifecycle-actions.ts | hooks | 聊天归档/删除/清空（乐观+事件广播） | useChatLifecycleActions | lib/api/chats, chat-lifecycle-events |
| web/hooks/use-debounced-value.ts | hooks | 防抖值 | useDebouncedValue | react |
| web/hooks/use-keyboard-shortcut.ts | hooks | 全局键盘快捷键 | useKeyboardShortcut | react |
| web/hooks/use-sidebar.ts | hooks | 侧栏折叠（localStorage 持久化） | useSidebar | react |
| web/hooks/use-skill-catalog.ts | hooks | 技能目录分页加载 | useSkillCatalog | lib/api/skills |
| web/hooks/use-stream-lifecycle.ts | hooks | 流式生命周期核心 hook（start/attach/queue/stop/resume/审批） | useStreamLifecycle, canAttachRunStream, ATTACHABLE_RUN_STATUSES | lib/api/chats, assistant-patch-controller, work-surface |
| web/hooks/use-workspace-selection.ts | hooks | 工作区选择（edge 状态+聊天绑定+localStorage） | useWorkspaceSelection | lib/api/chats, ui/toast |
| web/lib/api/active-run-merge.ts | lib/api | 活跃 run 记录合并（来源优先级+nextEventIndex 单调） | makeActiveRunRecord, mergeStreamRunUpdate, maxNextEventIndex | types |
| web/lib/api/assistant-patch-controller.ts | lib/api | assistant 消息 rAF 批量 patch 控制器 | createAssistantPatchController | stream-artifacts |
| web/lib/api/auth-guard.ts | lib/api | route handler 鉴权守卫 | requireRuntimeAuth, requireRuntimeUser | runtime-config, auth/actions |
| web/lib/api/chats.ts | lib/api | 聊天客户端 API+SSE 消费（浏览器侧） | listChats, createChat, streamChatMessage, streamExistingChatRun, consumeChatStream, applyStreamEvent 等 | request, errors, stream-text, work-surface |
| web/lib/api/errors.ts | lib/api | Web API 错误类型 | WebApiError, isAuthRequiredError, isNotFoundError | — |
| web/lib/api/harnesses.ts | lib/api | Harness 客户端 API（模板/运行/条目/草稿） | listTemplates, createRun, decideItem 等 | request, types |
| web/lib/api/models.ts | lib/api | 模型目录客户端（目录+access 视图） | listModels, ModelCatalogResponse | request, @astra/sdk |
| web/lib/api/projects.ts | lib/api | 项目客户端 API | listProjects, createProject 等 | request |
| web/lib/api/request.ts | lib/api | 浏览器 fetch JSON 封装+查询串 | requestJson, toQuery | errors |
| web/lib/api/runtime-cancel-settlement.ts | lib/api | run 取消 settle 竞态处理（超时乐观返回） | settleRuntimeCancel | runtime-client/errors |
| web/lib/api/search.ts | lib/api | 搜索客户端 | searchWorkspace | request |
| web/lib/api/sidebar.ts | lib/api | 侧栏数据客户端 | getSidebarData | request |
| web/lib/api/skills.ts | lib/api | 技能列表客户端（分页聚合） | listSkills | request, @astra/sdk |
| web/lib/api/stream-artifacts.ts | lib/api | artifact 解析/合并/安全下载 URL | artifactsFromToolCallEnd, mergeChatArtifacts, safeArtifactDownloadUrl | @astra/sdk |
| web/lib/api/stream-event-handler.ts | lib/api | 服务端流事件→web-store 写入（镜像解析） | applyStreamEvent, StreamEventContext, StreamEventState | web-store, stream-text, run-status-messages |
| web/lib/api/stream-event-helpers.ts | lib/api | 事件字段小工具 | blockedWaitingFor, eventMessage, isRunBlockedEvent | run-status-messages |
| web/lib/api/stream-text.ts | lib/api | delta 合并+thinking 标签/DSML 工具块剥离 | mergeTextDelta, splitThinkingTags, stripDsmlToolCallBlocks | — |
| web/lib/api/types.ts | lib/api | Web 层全部类型（ChatDetail/ChatMessage/...） | 各类型定义 | @astra/sdk, work-surface |
| web/lib/api/web-store.ts | lib/api | 按用户内存存储+后端同步引擎（2700+ 行） | getChat, getChatHydrated, beginStreamingMessage, queueDeferredRunInput, stopActiveRun, ensureChatBackendSession, getSidebar 等 | @astra/sdk, runtime-client, chat-run-state |
| web/lib/auth/actions.ts | lib/auth | Server Actions：login/register/logout/refresh/getCurrentUser | loginAction, registerAction, logoutAction, getCurrentUser | runtime-auth-client, runtime-config |
| web/lib/auth/runtime-auth-client.ts | lib/auth | 后端 auth REST 封装+响应类型守卫 | runtimeLogin, runtimeRegister, runtimeRefresh, runtimeLogout, runtimeMe | @astra/sdk, runtime-client |
| web/lib/composer/skill-mentions.ts | lib/composer | skill @提及 文本拆分/规范化 | splitSkillMentions, normalizeSkillMentionNames | — |
| web/lib/composer/slash-commands.ts | lib/composer | 斜杠命令构建/过滤（skill→命令映射） | filterSlashCommands, skillToSlashCommand, SlashCommandItem | types |
| web/lib/runtime-client/errors.ts | lib/runtime-client | 运行时错误类型 | RuntimeClientError, readRuntimeErrorDetail, runtimeErrorDetail | @astra/sdk |
| web/lib/runtime-client/index.ts | lib/runtime-client | 桶导出 | （re-export） | errors, server |
| web/lib/runtime-client/server.ts | lib/runtime-client | 服务端运行时客户端：鉴权头/401 刷新重放/cookie 持久化 | WebRuntimeClient, getRuntimeClient, requireRuntimeClient, getRuntimeClientFromCookies | @astra/sdk, runtime-config |
| web/lib/utils/cn.ts | lib/utils | className 合并 | cn | clsx |
| web/lib/utils/time.ts | lib/utils | 相对时间格式化 | relativeTime 等 | date-fns |
| web/lib/chat-lifecycle-events.ts | lib | 聊天生命周期跨组件事件（CustomEvent 广播） | emitChatLifecycleChange, subscribeChatLifecycleChange | types |
| web/lib/chat-run-state.ts | lib | run 状态→UI 状态推导（可排队/可停/可恢复） | deriveChatRunUiState, isTerminalChatRunStatus, runBlocksChatTurn, activeRunPriority | @astra/sdk, run-status-messages |
| web/lib/chat-scroll-state.ts | lib | 聊天滚动锚定策略 | isChatScrolledToBottom, shouldAutoScrollChat | — |
| web/lib/logger.ts | lib | 单行 JSON 日志 | log, LogRecord | — |
| web/lib/run-status-messages.ts | lib | 运行等待/阻塞语义投影（转发 SDK lifecycle-utils） | projectRunWaitingState, extractWaitingReason 等（re-export） | @astra/sdk |
| web/lib/runtime-capabilities.ts | lib | 能力开关→Web/GitHub 可用性判定 | resolveWebAccessAvailability, resolveGitHubAccessAvailability | types |
| web/lib/runtime-config.ts | lib | 运行时连接配置解析（cookie>env>默认；demo 模式；cookie 常量与 token 掩码） | DEFAULT_API_URL, getRuntimeConfig, maskToken, ACCESS_TOKEN_COOKIE 等, RuntimeConfig | next/headers |
| web/lib/work-action-error.ts | lib | Work action 错误分类（AstraApiError/RuntimeClientError→统一形状） | classifyWorkActionError, WorkActionError | @astra/sdk, runtime-client |
| web/lib/work-overview.ts | lib | Work 概览快照组装（分支/标准/图/事件投影） | getWorkBranchPresentation, WorkOverviewSnapshot | @astra/sdk |
| web/lib/work-surface.ts | lib | 工作面纯函数 reducer（SSE 事件→面板状态） | applyWorkSurfaceEvent, hydrateWorkSurface, resetWorkSurfaceForRun, createEmptyWorkSurface, parseWorkSurfaceEvent | @astra/sdk |
| web/lib/work-task-presentation.ts | lib | 任务图节点展示语义（tone/verified/attention） | workTaskPresentation, workTaskCounts | @astra/sdk |
| web/lib/workspace-authority.ts | lib | 工作区选择规范化/绑定解析/越权校验 | normalizeWorkspaceSelection, resolveWorkspaceBindings, validateWorkspaceAuthority, sameWorkspaceSelection | @astra/sdk |
| web/lib/workspace-selection-server.ts | lib | 服务端校验所选边缘工作区仍在线 | verifyLiveWorkspaceSelection | @astra/sdk, runtime-client |
| web/next.config.ts | 配置 | Next 配置（no_proxy 注入/distDir/tracingRoot） | nextConfig | next |
| web/playwright.config.ts | 配置 | E2E 配置（loopback 代理旁路，:3536） | default | @playwright/test |
| web/proxy.ts | 配置 | Next middleware：cookie 存在性门禁+公开路径放行 | middleware（default export） | next/server, runtime-config |
| web/tailwind.config.ts | 配置 | Tailwind 主题（CSS 变量色板/圆角） | config | tailwindcss |
| web/test.setup.ts | 配置 | vitest setup（Node25 localStorage shim） | — | @testing-library/jest-dom |
| web/vitest.config.ts | 配置 | 单测配置（jsdom+@别名） | default | vitest, @vitejs/plugin-react |

### 附表二：packages/sdk 文件清单（15 个文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
| --- | --- | --- | --- | --- |
| packages/sdk/src/client.ts | core | AstraClient HTTP/SSE 门面（auth/session/run/work/model/skill/edge 全域） | AstraClient, AstraApiError, chatRequestToWire | sse-client, http, paths, wire, work-wire, types |
| packages/sdk/src/hooks.ts | react | useAstraChat/useAstraRun 流式状态聚合 hooks | useAstraChat, useAstraRun | react, client, lifecycle-utils |
| packages/sdk/src/http.ts | core | 错误解码/Header 合并/JWT sub 解码 | readAstraError, readAstraErrorDetail, headersInitToRecord, isHeadersLike, methodCanHaveJson, extractJwtSubject | — |
| packages/sdk/src/index.ts | 入口 | 桶导出（类型/常量/工具） | （re-export 全部公共面） | 各模块 |
| packages/sdk/src/lifecycle-utils.ts | core | run 等待/工具终态语义投影（与 Rust 常量同步） | EXECUTION_BOUNDARY_WAIT_REASONS, isExecutionBoundaryWait, normalizeToolStatus, toolTerminalStatus, projectRunWaitingState 等 | types |
| packages/sdk/src/paths.ts | core | 运行时路径常量+参数化构造（与 astra-thin-client/paths.rs 同步，id 合法性校验） | PATH_* 常量, sessionPath, chatRunStreamPath, workBranchesPath, joinApiPath, buildQueryString 等 | — |
| packages/sdk/src/react.ts | 入口 | React 子包入口 | useAstraChat, useAstraRun, AstraClient（re-export） | hooks, client, types |
| packages/sdk/src/sse-client.ts | core | fetch 版 SSE 客户端（重试/心跳/终止事件检测） | SSEClient, parseSseDataEvents, readHttpErrorMessage | types |
| packages/sdk/src/types.ts | core | 全部 wire 类型（60+ StreamEvent、Chat/Session/Run/Work V1-V2） | StreamEvent 等全部类型 | — |
| packages/sdk/src/websocket.ts | core | WebSocket 双向客户端（事件发射器+重连+审批回传） | AstraWebSocket, AstraWebSocketOptions, ToolApproval | wire, types |
| packages/sdk/src/wire.ts | core | 请求编码严格校验 | modelSelectionToWire, ModelSelectionWire | — |
| packages/sdk/src/work-event-reconcile.ts | core | Work 事件页游标对账纯函数 | reconcileWorkEventPageV1, WorkEventReconcileCursorV1/ResultV1 | types |
| packages/sdk/src/work-wire.ts | core | Work API 响应严格解码器（4156 行，身份/哈希/revision 一致性） | decodeWork* 系列 29 个解码函数 | types |
| packages/sdk/tsup.config.ts | 构建 | 双入口 ESM/CJS+dts 构建 | — | tsup |
| packages/sdk/vitest.config.ts | 测试 | node 环境单测+覆盖率阈值 | — | vitest |

### 附表三：crates/astra-test-harness 文件清单（src 22 个 .rs + 外围文件；cases/ 58 个 YAML 为数据目录）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
| --- | --- | --- | --- | --- |
| crates/astra-test-harness/Cargo.toml | 包清单 | bin=astra-test；依赖 astra-credentials/harness/pipeline/services/server-types/turn-core/turn-types + clap/tokio/axum 等 | — | workspace crates |
| crates/astra-test-harness/src/artifacts.rs | src | 按用例/模型/run 落盘 stdout/stderr/report/digest | 写盘函数 | report |
| crates/astra-test-harness/src/capability_coverage.rs | src | 产品能力清单与模型探针防漂移桥接 | 能力覆盖审计 | astra-harness(CAPABILITY_CASES), case |
| crates/astra-test-harness/src/case.rs | src | YAML 用例加载/过滤/prompt 变体扩展 | Case, CaseStep, expand_prompt_variants, matches_filter, load_dir | serde_yaml_ng |
| crates/astra-test-harness/src/classify.rs | src | 失败分桶（驱动重试与报告分组） | FailureClass, classify | runner, criteria |
| crates/astra-test-harness/src/criteria.rs | src | 判据枚举与确定性求值（JSON 指针/DAG/journal 断言等） | Criterion, CriterionResult, evaluate_deterministic(_with_session), requires_session_capture | runner, session_capture |
| crates/astra-test-harness/src/dashboard.rs | src | 内嵌 axum+WebSocket 实时仪表盘服务器 | DashboardServer, DashboardEvent, DashboardConfig | axum, tower-http, tokio |
| crates/astra-test-harness/src/digest.rs | src | 失败时子进程 astra journal digest 采集 | AstraCliDigestCollector | tokio/process |
| crates/astra-test-harness/src/eval.rs | src | 结构化多维评分（能力/健康/效率，供 CI 门槛） | EvalReport, evaluate | report |
| crates/astra-test-harness/src/exec.rs | src | CaseExecutor trait + AstraCliExecutor 子进程实现 | CaseExecutor, AstraCliExecutor | runner, tokio/process |
| crates/astra-test-harness/src/judger.rs | src | LLM 评分后端（CLI shell/外部命令/Quorum 聚合） | Judger, AstraCliJudger, QuorumJudger, ExternalCmdJudger, parse_score_from_response | runner |
| crates/astra-test-harness/src/lib.rs | src | crate 文档+模块声明+可编程扩展面 | pub mod *（全部模块） | — |
| crates/astra-test-harness/src/main.rs | src | clap CLI 装配：预检→SuiteRunner→报告/仪表盘 | Args, main | suite, case, exec, judger, preflight, report, dashboard |
| crates/astra-test-harness/src/model_profiles.rs | src | 模型缓存复用能力画像（IntraTurn/ConversationTurn） | ModelReuseSupport, profile 加载 | case, serde |
| crates/astra-test-harness/src/pipeline_analysis.rs | src | journal 中上下文管道（缓存/压缩/告警）健康分析 | 分析结构体与函数 | session_capture |
| crates/astra-test-harness/src/preflight.rs | src | 二进制/服务器/认证/模型连通性预检 | run_preflight | tokio/process |
| crates/astra-test-harness/src/report.rs | src | SuiteReport 折叠与 text/json 渲染 | SuiteReport, CaseRunReport, render, Format | serde |
| crates/astra-test-harness/src/runner.rs | src | RunOutcome 数据模型+`astra chat --json` 解析+模型矩阵解析 | RunOutcome, RunnerConfig, resolve_models, resolve_runner_profile_owner | case, astra-credentials/services |
| crates/astra-test-harness/src/session_capture.rs | src | session journal 松解析（Value+type 索引） | SessionCapture, 加载器 | tokio/fs |
| crates/astra-test-harness/src/session_identity.rs | src | 只信 CLI 流中服务器签发 session id 的收敛助手 | 身份提取/等待函数 | tokio/process |
| crates/astra-test-harness/src/suite.rs | src | 套件编排：并行信号量/熔断/限流重试 | SuiteRunner, SuiteConfig, SessionCaptureMode, ScopedDiskSessionLoader | case, exec, criteria, classify, tokio |
| crates/astra-test-harness/src/summarizer.rs | src | 可选 LLM 套件总结 | summarizer 函数 | report, judger |
| crates/astra-test-harness/src/test_support.rs | src(cfg test) | 子进程 fixture 确定性（ETXTBSY 防御） | 脚本安装工具 | std |
| crates/astra-test-harness/cases/*.yaml（58 个） | 数据 | 行为用例：缓存/多轮/fanout/反幻觉/Work 旅程/工具矩阵/隔离等 | —（数据） | — |
| crates/astra-test-harness/dashboard.html | 数据 | 仪表盘单页前端 | — | — |
| crates/astra-test-harness/harbor_adapter.py | 适配 | Harbor 基准容器内评估真实 Astra CLI（无基准特定提示词） | adapter 入口 | python stdlib |
| crates/astra-test-harness/harbor_adapter_env.py | 适配 | Harbor 环境构造辅助 | — | python stdlib |
| crates/astra-test-harness/tests/real_journal_wire_shape.rs | tests | 用合成 fixtures 钉死 journal wire 契约 | — | lib, fixtures |
| crates/astra-test-harness/tests/shipped_cases_smoke.rs | tests | 加载全部 shipped YAML 防字段漂移 | — | lib |
| crates/astra-test-harness/tests/test_harbor_adapter.py | tests | Harbor 适配器自测 | — | python |
| crates/astra-test-harness/tests/fixtures/*（2 jsonl+README） | 数据 | 真实 journal 结构等价合成样本 | — | — |
| crates/astra-test-harness/README.md / HACKING.md | 文档 | 使用与扩展指南 | — | — |

> 说明：任务口径称 harness"21 个文件"，实测 `src/` 为 22 个 .rs（含 `cfg(test)` 的 test_support.rs）；为不遗漏，上表列全 22 个 src 文件并附外围文件与数据目录。


---

## 6. 关键函数深度解析

本章选取覆盖核心业务链路的代表性函数，给出带行号引用的代码片段与逐段实现解读。选取原则：①位于请求主干（配置装配、认证、路由、Turn 循环、上下文装配、权限裁决、模型调用、工具执行、流式渲染、Edge 投递、Web 代理）；②体现项目关键设计模式（fail-closed、先落库再投递、CAS 终态、预算装配）。各片段由对应批次分析产出，按链路顺序排列。

### 6.1 配置装配（core · AppSettings::from_env）
#### 深度解析 1：`AppSettings::from_env` —— 配置装配与优先级链

```rust
// crates/core/src/config.rs:1001-1007
pub fn from_env() -> Result<Self, ConfigError> {
    if !explicit_env_config_requested()? {          // ASTRA_CONFIG_SOURCE != "explicit-env"
        dotenvy::dotenv().ok();                     // .env 只在这一处、且可被关闭
    }
    let server_config = ServerConfig::load()?;
    Self::from_server_config(&server_config)
}

// crates/core/src/config.rs:836-877（ServerConfig::load 节选）
pub fn load() -> Result<Self, ConfigError> {
    if explicit_env_config_requested()? { return Self::from_explicit_env(); }
    let mut config = Self::default();
    // 系统级: /etc/astra/server.toml
    if system_path.exists() { match Self::from_file(system_path) {
        Ok(system_config) => config.merge(system_config), /* 失败仅 warn 继续 */ } }
    // 用户级: local_state_root()/server.toml  (~/.astra，可被 ASTRA_LOCAL_STATE_ROOT 重定向)
    if user_path.exists() { match Self::from_file(&user_path) {
        Ok(user_config) => config.merge(user_config), /* 失败仅 warn 继续 */ } }
    config.apply_env_overrides();                   // 环境变量最高优先级
    config.validate()?;
    Ok(config)
}

// crates/core/src/config.rs:1017-1049（from_server_config 的 lookup 闭包节选）
let lookup = |key: &str| -> Option<String> {
    match key {
        "ASTRA_DB_POOL_MAX_CONNECTIONS" => Some(sc.database.max_connections().to_string()),
        "ASTRA_JWT_SECRET" => sc.auth.jwt_secret.clone(),
        "ASTRA_API_PORT" => Some(sc.api.port().to_string()),
        _ => env::var(key).ok(),                     // 其余键回退真实 env
    }
};
```

逐段解读：

- **第一段（from_env）**：入口只做两件事——决定是否加载 `.env`，然后把一切交给 `ServerConfig::load`。`explicit_env_config_requested`（`config.rs:24-37`）读 `ASTRA_CONFIG_SOURCE`：只有字面量 `explicit-env` 关闭 dotenv/文件加载；未知取值直接 `ConfigError::InvalidValue`（fail-closed，不给静默回退到宿主状态的机会）。这为外部编排器（容器/hermetic 进程）提供确定性配置面。
- **第二段（load 的优先级链）**：内置默认 → 系统级 TOML → 用户级 TOML → 环境变量，后者覆盖前者。`merge`（`config.rs:911-917`）逐节 `merge_from`，只取 `Some` 字段，因此高层文件可以只写个别键；`AuthConfig::merge_from` 对 `edge_token_auth` 做字段级合并，避免"上层只设 check_endpoint 就把下层设的 key 清空导致启动失败"（`config.rs:474-479` 注释，隐性坑的显式防御）。TOML 文件读取失败只 `tracing::warn!` 后继续用默认（`config.rs:846-854`）——坏配置文件不阻断启动，但解析出的非法值会被 `validate` 拦下。`apply_env_overrides`（`config.rs:920-926`）把 5 个池参数、auth、API、9 个 runtime 限额、`ASTRA_DISABLED_TOOL_OFFERS` 逐项从 env 打进 config；数值解析失败仅 warn 并保留原值（`apply_env_override`，`config.rs:67-76`）。
- **第三段（lookup 闭包）**：`from_server_config` 把已经"文件+env 合并完"的 `ServerConfig` 重新包装成 `Fn(&str)->Option<String>` 的 env 键视角，再走与纯 env 路径完全相同的 `from_lookup`（`config.rs:1082-1157`）。这一设计的意义是**单一装配管线**：无论配置来自 TOML、env 还是 `from_map` 的测试注入，字段解析、`required_value` 安全默认逻辑、`MatrixOneSettings::validate`、JWT 弱密检查只写一遍。副作用：`AppSettings` 构建过程可能发出 warn/error 日志（env 解析失败、不安全默认），并读取进程 env 与文件系统；无网络/DB 副作用。调用关系：`from_env` 是服务器/CLI 启动路径；`from_explicit_env`（`config.rs:1010-1012`）供编排器；`from_map` 供测试。

#### 深度解析 2：`matrixone_statement_with_null_shape` —— null-shape 判别注释

```rust
// crates/core/src/lib.rs:39-68
/// Give MatrixOne a distinct prepared-statement identity for each nullable
/// parameter shape used by one SQL statement.
/// MatrixOne 4.2 can retain a `NULL` bit from the first execution of a cached
/// prepared statement. Reusing that statement with a non-`NULL` value in the
/// same position then stores `NULL`. MatrixOne 4.1.4 accepts the distinct SQL
/// identities as normal statements, so this preserves one write contract on
/// both versions without disabling prepared-statement caching globally.
pub fn matrixone_statement_with_null_shape(
    sql: &str,
    nullable_values_present: impl IntoIterator<Item = bool>,
) -> String {
    let mut statement = String::with_capacity(sql.len() + 48);
    statement.push_str(sql);
    statement.push_str(&matrixone_null_shape_comment(nullable_values_present));
    statement
}

pub fn matrixone_null_shape_comment(
    nullable_values_present: impl IntoIterator<Item = bool>,
) -> String {
    let mut comment = String::from(" /* astra-null-shape:");
    for present in nullable_values_present {
        comment.push(if present { '1' } else { '0' });
    }
    comment.push_str(" */");
    comment
}
```

逐段解读：

- **问题本质**：sqlx 的 MySQL 驱动按 SQL 文本缓存 prepared statement；MatrixOne 4.2 的服务端对缓存语句保留了首次绑定的 NULL 位图——同一语句先用 NULL 再用具体值，具体值会被写成 NULL（数据损坏级 bug）。全局关闭语句缓存会伤所有路径的性能。
- **实现方式**：为每一种"可空参数形态"生成不同 SQL 文本（` /* astra-null-shape:01 */` 这类尾注释在 SQL 语法上无语义，但足以让语句缓存身份不同）。形态位图由调用方按每次执行的实参逐位给出（`nullable_values_present`），`true`=该位是 NULL。同一 SQL 的 `01` 与 `10` 形态断言为不同字符串（单测 `lib.rs:102-116`）。预分配 `sql.len()+48` 避免重分配。纯函数、零副作用；代价是语句缓存条目按形态数乘法增长（推断，注释未量化）。
- **配套机制 `push_matrixone_bound_string_set`**（`lib.rs:76-91`）：把有界内存标识集合展开为 `(SELECT CAST(? AS CHAR) AS value UNION ALL ...)` 派生关系供 join 使用——规避 4.2 跨 join 的 prepared `IN (?,...)` 只返回前缀行的 bug；每个值仍是绑定参数（不拼接 SQL 文本，无注入面）。
- **调用关系**（grep 事实）：`crates/astra-plan/src/repository.rs`、`crates/runtime/src/data_layer/storage.rs`、`crates/services/src/{runs,events,event_ingestion,inference_execution,prompt_delta,state_projection,session_context_coordinator,work/events_repository}.rs` 等所有"同一条语句、可空参数形态会变"的写入/查询点；回归由 `crates/services/tests/matrixone_prepared_statement_compat_db_it.rs` 守护。**隐性约定**：调用点必须保证传入的形态位图与实际绑定值一一对应——漏传或错序时函数本身无法察觉（这是该技巧最大的坑，属事实性约束：签名无编译期关联）。

### 6.2 工具契约与技能执行（能力层）
### 关键函数深度解析

### 1. astra-tools 工具执行核心：`ToolExecutor` trait + `DefaultToolExecutor::execute`

工具执行契约由两部分组成：trait 定义（astra-tools/src/lib.rs:275-320）与共享实现（astra-tools/src/executor.rs:359-762）。trait 部分见 4.3.1；这里剖析 execute 主链路中最能体现"执行契约"的准入—分发—结算三段：

```rust
// astra-tools/src/executor.rs:359-410（节选，注释为源码摘要）
async fn execute(&self, name: &str, args: &Value) -> ToolResult {
    if let Err(error) = crate::schemas::validate_tool_arguments(name, args) {
        return error.into_tool_result();                      // ① 契约前置：参数级校验
    }
    // ② 审批门：参数敏感（git commit vs git diff）由 gate 决定
    if let Some(gate) = &self.approval_gate
        && gate.requires_approval_for(name, args)
    {
        let decision = gate.request_approval(&request_id, name, args).await;
        match decision {
            crate::ApprovalDecision::Denied { reason } => { /* 返回"勿原样重试"错误 */ }
            crate::ApprovalDecision::Timeout => { /* 返回超时拒绝 */ }
            crate::ApprovalDecision::Approved => {}
        }
    }
    ...
    // ③ bash 只读缓存：key 含 workspace 代际，防跨编辑读到陈旧状态
    if name == "bash"
        && !crate::workspace_observation::is_explicit_workspace_verification_request(name, args)
        && !args.get("force").and_then(Value::as_bool).unwrap_or(false)
        && let Some(key) = self.bash_cache_key(args)
        && let Some(mut cached) = { /* 单临界区完成查+TTL+逐出 */ }
    {
        mark_result_cached(&mut cached);
        return cached;                                        // 缓存命中直接短路
    }
```

```rust
// astra-tools/src/executor.rs:532-559（分发与超时策略）
let dispatch = self.dispatch(name, args);
// Bash 和 run_script 自己拥有子进程超时/取消路径。不要把两者包进
// 通用 60s future 超时：drop 掉的 future 会丢掉部分写之后的事后回执。
let mut result = if name == "bash" || name == "run_script" {
    dispatch.await
} else if let Some(token) = self.ctx.cancel_token.as_ref() {
    tokio::select! {
        _ = token.cancelled() => crate::cancelled_tool_result(name, true),
        result = tokio::time::timeout(TOOL_TIMEOUT, dispatch) => match result {
            Ok(r) => r,
            Err(_) => ToolResult::error(format!("Tool '{name}' timed out after {}s", ...)),
        },
    }
} ...
```

```rust
// astra-tools/src/executor.rs:749-754 + 676-693（结算：代际失效与脱敏截断）
if (is_workspace_mutation_tool(name, args) && !exact_desired_state_noop)
    || observed_bound_workspace_mutation
    || run_script_may_have_mutated(name, &result)
{
    self.workspace_generation.fetch_add(1, Ordering::Relaxed); // ④ 保守失效读缓存
}
...
let result = {
    let (output, _) = crate::credential_redaction::redact_credentials_for_display(&result.output);
    ToolResult { output, ..result }                            // ⑤ 出口必脱敏
};
let result = if result.output.len() > MAX_TOOL_OUTPUT_BYTES { /* ⑥ 64KB 截断 */ ... };
```

**逐段解读**：
- **① 参数契约前置**：任何工具先过 `validate_tool_arguments`（含 per-action 必填校验），失败在进入业务逻辑前返回——模型参数错误不消耗执行资源，且错误信息带修复指引。
- **② 审批是参数敏感的**：`requires_approval_for` 默认实现 OR 上 `tool_requires_approval`（lib.rs:670），同一 `git` 工具 commit 需审批而 diff 不需要；Denied 文案显式指示模型"不要原样重试"（防止审批拒绝触发重试风暴）。
- **③ 缓存键包含 workspace 代际**：`BashCacheKey`（executor.rs:133-150）= root + generation + command + env 指纹 + stdin 哈希。generation 是"写工具成功即 +1"的单调计数，保证 `write_file` 后的 `ls` 不会命中编辑前的缓存；TTL（30s）兜底非工具途径的外部变更（编辑器、git pull）。查/过期/逐出在一个锁临界区完成，锁中毒有计数恢复（executor.rs:181-198）。
- **④ 超时豁免体现"回执优先"**：bash/run_script 的 future 被 60s 超时 drop 后，其子进程可能已部分写入工作区、事后回执（observation receipt）将永远无法送达——所以这两类工具绕过统一超时，由自身子进程边界管理（shell_ops 的超时推断 executor.rs 引 shell_ops.rs:441、process_isolation 的监督器）。
- **⑤⑥ 出口统一脱敏+截断**：任何工具输出的最后一道工序是凭据脱敏（display 级）与 64KB 截断，保证返回给 LLM 的文本不泄漏密钥、不撑爆上下文。部分写（`run_script_may_have_mutated`，executor.rs:1157：只要不能证明 `execution_started=false` 就算可能已变更）会保守推进代际——**宁可错杀缓存，不可服务陈旧读**。
- 整体契约可以概括为：`execute(name,args) -> ToolResult` 是一个带**准入（校验/审批/缓存）→互斥（租约/纪元）→执行（dispatch+取消/超时）→结算（完整性核验/回执投影/脱敏/截断/代际失效）**四段式的受监督副作用边界，所有"执行事实"都以 metadata 回执而非输出文本传达。

### 2. astra-skills 技能执行主流程：`SkillExecutionRouter::execute` → `IsolatedSkillExecutor::execute`

入口是 router（astra-skills/src/executor/isolated.rs:312-330），fork 技能的实际执行在 isolated.rs:145-284：

```rust
// astra-skills/src/executor/isolated.rs:312-330（路由：fork 优先，无执行器则回退 inline）
async fn execute(&self, skill: &LoadedSkill, context: &SkillExecutionContext)
    -> Result<SkillExecutionResult, SkillError> {
    if skill.manifest.is_isolated() {
        if let Some(ref isolated) = self.isolated {
            return isolated.execute(skill, context).await;
        }
        eprintln!("  ⚠ Skill '{}' requests isolated execution but no executor is available; \
                   falling back to inline", skill.manifest.name);   // 显式降级告警
    }
    self.inline.execute(skill, context).await
}
```

```rust
// astra-skills/src/executor/isolated.rs:150-209 + 246-283（隔离执行主体，节选）
async fn execute(&self, skill: &LoadedSkill, context: &SkillExecutionContext)
    -> Result<SkillExecutionResult, SkillError> {
    let start = std::time::Instant::now();
    #[cfg(feature = "crash-recovery")]
    if let Some(ref mgr) = self.checkpoint_manager {
        /* ① 执行前落 SkillCheckpoint（Running 态，含 instructions/allowed_tools/深度） */
    }
    let result = self.sub_run_executor.execute_skill_subrun(   // ② 委托宿主子运行
        &skill.manifest.name, &skill.manifest.instructions, &context.task,
        skill.manifest.max_tokens, &skill.manifest.allowed_tools,
        context.recursion_depth,
        /* effort/agent_type/invocation_id/expected_control_epoch/parent_turn_chain_id */
    ).await;
    #[cfg(feature = "crash-recovery")]
    if let Some(ref mgr) = self.checkpoint_manager {
        /* ③ 按 outcome 终态标记 completed/failed */
    }
    let result = result.map_err(SkillError::ExecutionFailed)?;
    ...
    let success = result.outcome.is_completed();                // ④ 终态权威判定
    let error_category = match result.outcome {
        SubRunOutcome::Completed => None,
        SubRunOutcome::Interrupted { .. } => Some(SkillErrorKind::Interrupted),
        SubRunOutcome::Cancelled { .. }  => Some(SkillErrorKind::Cancelled),
        SubRunOutcome::Failed { .. }     => Some(SkillErrorKind::ExecutionFailed),
    };
    let formatted_output = format!(                             // ⑤ 摘要回注父会话
        "## Skill Result: {}\n\n{}{}\n\n---\n*Executed in isolated sub-run: {} turns, {} tokens*",
        skill.manifest.name, result.output, outcome_note, result.turns, result.tokens_used);
    Ok(SkillExecutionResult { output: formatted_output, success, error_category, .. })
}
```

**逐段解读**：
- **路由层（第一段）**：`manifest.is_isolated()`（execution_context=Fork 或 isolated=true）决定路径；宿主未提供 isolated 执行器时**降级为 inline 并打印警告**——技能仍能跑，但隔离性承诺被显式打破（调用者可从 stderr/日志察觉）。
- **① 检查点先行**：crash-recovery feature 打开时，执行前把技能完整可恢复状态（指令、任务上下文、工具白名单、递归深度）写入 SkillCheckpoint（astra-pipeline/skill_checkpoint.rs:30），进程崩溃后可识别"中断的技能"。
- **② 子运行委托**：astra-skills 刻意不含 agent 循环——`SkillSubRunExecutor`（isolated.rs:37-54）是宿主注入的接缝：CLI 用 OwnedCliLoopHost、Server 用 ServerSubRunExecutor。透传的 11 个参数里，`parent_recursion_depth` 防无限递归、`expected_control_epoch` 是"原子动作准入的用户意图纪元"（与 astra-tools 的 ToolInvocationMetadata 呼应）、`__astra_invocation_id` 等三个以双下划线开头的参数通过 arguments HashMap 隐式传递（isolated.rs:196-207）。
- **③④ 终态与文本分离**：子运行的**部分输出不构成成功证据**——`SubRunOutcome`（isolated.rs:62-98）四态中只有 Completed 算 success；Interrupted（如 budget_exhausted）/Cancelled/Failed 分别映射到 SkillErrorKind。检查点也按终态分别 mark_completed/mark_failed（isolated.rs:213-244）。
- **⑤ 摘要回注**：只有格式化后的 `## Skill Result` 文本回到父会话（含 turns/tokens 脚注），子会话的完整历史不进入父上下文——这就是 fork 模式的上下文隔离本质。
- 对照 inline 模式（inline.rs:20-74）：无子进程、无检查点，把参数化后的指令原文塞进 `# Skill:` 模板直接作为工具结果；MCP 来源技能若含 `!` 行内 shell 直接 PermissionDenied（inline.rs:25-29），本地技能则允许——信任分级按 SkillSourceKind 实施。

### 6.3 Turn 编排核心（agentic 循环 / 权限裁决 / 上下文预算 / SSE 调度）
### 6.5 关键函数深度解析

#### A. agentic 主循环控制核心：`ingest_agentic_turn_stream`

位置：`crates/astra-turn-core/src/agentic/turn_ingest.rs:130`。宿主循环每完成一次模型流式响应后调用，把快照并入运行态并返回下一动作。

```rust
// turn_ingest.rs:130-165（节选）
pub fn ingest_agentic_turn_stream(
    snap: &AgenticTurnStreamSnapshot<'_>,
    edge_round_len: usize,
    mut edge_tool_name: impl FnMut(usize) -> String,
    message: &str, _recent_tools: &[String], _quiet: bool,
    mut st: AgenticTurnIngestMut<'_>,
) -> AgenticTurnIngestOutcome {
    if st.first_ttft_ms.is_none() { *st.first_ttft_ms = snap.ttft_ms; }
    if let Some(sid) = snap.session_id.as_ref() {
        *st.current_session_id = Some(sid.clone());
        st.step_recorder.attach_persistence_if_configured(sid);   // 会话 id 权威绑定持久化
    }
    let round_has_edge_work = !snap.tool_calls.is_empty() || edge_round_len > 0;
    // 只有纯文本响应才是终答；伴随工具调用的文本只是中间前导
    if !snap.full_text.is_empty() && !round_has_edge_work
        && !preserve_prior_final_after_runtime_scaffolding_retry(st.messages, st.final_text.as_str())
    {
        *st.final_text = snap.full_text.to_string();
    }
```

```rust
// turn_ingest.rs:265-301（节选）
    if let Some(err) = snap.error_message {
        let kind = if let Some(k) = snap.error_kind {
            if k == astra_core::ErrorKind::ContextWindow {
                *st.consecutive_context_window_errors =
                    st.consecutive_context_window_errors.saturating_add(1);
            } else { *st.consecutive_context_window_errors = 0; }
            k
        } else {
            if astra_core::is_llm_context_window_error(err) { /* 同上递增 */ }
            astra_core::classify_llm_error_message(err)         // 字符串兜底分类
        };
        return AgenticTurnIngestOutcome::Fatal(astra_core::ClassifiedError::new(kind, err.clone()));
    }
    if !round_has_edge_work {
        if !snap.full_text.is_empty() && !preserve_prior_final_after_runtime_scaffolding_retry(..) {
            persist_final_assistant_message(st.messages, st.final_text.as_str()); // 追加 assistant 消息
        }
        record_prompt_calibration_success(snap, &mut st);
        return AgenticTurnIngestOutcome::Break;             // 终答 → 跳出循环
    }
    record_prompt_calibration_success(snap, &mut st);
    AgenticTurnIngestOutcome::HasToolCalls                   // → 宿主执行工具后再来一轮
```

逐段解读：(1) 快照模式——库不持有循环状态，`AgenticTurnIngestMut` 把宿主的 17 个可变字段打包成结构体借用，函数本身保持可测试纯度；(2) `round_has_edge_work` 同时涵盖 server 下发的 tool_calls 与本地 edge 轮次，统一决定"是否还有工作"；(3) 错误优先走宿主预分类 `error_kind`（SSE 生产者已解码的类型是权威，缺失时才字符串分类，:69-71 注释强调"absence must not erase"）；(4) `consecutive_context_window_errors` 只在 ContextWindow 错误上递增、其他错误清零、成功清零（:259-263）——这是下游压缩升级的输入；(5) `record_prompt_calibration_success`（:305）用 `NormalizedPromptCacheUsage` 记录"本请求物理上下文占用"，且 server-owned 汇总的聚合子用量**不得**覆盖主机记录的单请求值（:316-321 注释+测试）。

#### B. 权限裁决核心：`evaluate_permission_with_provider_policy`

位置：`crates/astra-turn-core/src/permission/engine.rs:407`。所有入口（TUI/headless/子代理 mailbox）共用的纯函数裁决器。

```rust
// engine.rs:407-452（节选）
pub fn evaluate_permission_with_provider_policy(
    tool_name: &str, args: &Value,
    ctx: &PermissionSyncContext,
    provider_policy: Option<&crate::provider_resolution::ResolvedInvocationPolicy>,
) -> DecisionEnvelope {
    let mut trace = Vec::with_capacity(EVALUATION_ORDER.len());
    let mut risk_tags = risk_tags_for_request(tool_name, args);
    if let Some(policy) = provider_policy {
        // descriptor 是动态工具的能力权威：丢弃从公共别名/静态表推断的标签，
        // 保留内在守卫（显式 deny、git 安全）
        risk_tags.retain(|tag| !matches!(tag,
            RiskTag::MCPUnknownCapability | RiskTag::BashExecute
            | RiskTag::WritesSensitiveFile | RiskTag::WritesOutsidePackage));
        let provider_tag = if policy.is_read_only() { None }
            else if policy.effect == ResolvedToolEffect::Mutating { Some(RiskTag::ProviderSideEffect) }
            else { Some(RiskTag::ProviderUnknownCapability) };
        if let Some(tag) = provider_tag { push_risk_tag(&mut risk_tags, tag); }
    }
    let will_save = Some(allow_rule_preview(tool_name, args));  // "Always" 将保存的规则预览
    if ctx.is_denied_with_context(tool_name, &rule_match_context) {   // 槽2 DenyRules
        let decision = HardDecision::Deny { reason: format!("Tool '{tool_name}' denied by permission rules") };
        ...
        return envelope(decision, DecisionSource::DenyRule { .. }, trace, will_save, risk_tags);
    }
```

```rust
// engine.rs:479-503（节选，槽3 SafetyMiddleware 的 auto 模式放松）
    match evaluate_tool_safety_request(tool_name, args) {
        SafetyMiddlewareDecision::Allow => { push_skipped(.., "safety guards passed"); }
        SafetyMiddlewareDecision::Deny(reason) => {
            // auto 模式放松 shell 混淆（软）规则；灾难命令与破坏 SQL 仍硬拒
            if ctx.mode().relaxes_soft_shell_obfuscation()
                && reason.contains("shell_obfuscation") && !reason.contains("catastrophic")
            {
                push_matched(.., &HardDecision::Allow, &format!("auto mode relaxed: {reason}"));
                // 继续下一槽 —— 不提前返回
            } else {
                return envelope(HardDecision::Deny { reason: reason.clone() },
                    DecisionSource::SafetyMiddleware { reason }, trace, will_save, risk_tags);
            }
        }
    }
```

逐段解读：(1) 每个提前 return 都带完整 `DecisionEnvelope`（决策+来源+trace+will_save+risk_tags），UI 可以回答"为什么被拒"；(2) provider_policy 存在时以**实际执行所用的 descriptor** 为能力权威，静态名字推断让位——防 `mcp__*` 名字与真实 descriptor 矛盾；(3) 14 槽顺序固定且 pinning 测试冻结（`EVALUATION_ORDER` :204），中段 Plan 模式短路（:842-890 跳过 SessionOverride/ExplicitApproval/AllowRules 三槽并按 `plan_mode_policy::is_plan_mode_blocked_tool` args 级裁决）；(4) `NeedExternal` 只构造 `ApprovalPrompt` 不决定怎么问——路由到哪个 sink 是宿主的事（`approval/sink.rs`）。

#### C. 上下文装配/token 预算核心：`plan_turn`

位置：`crates/astra-turn-core/src/context/planner.rs:68`。Plan 阶段唯一入口，纯函数零 I/O。

```rust
// planner.rs:68-127（全文节选）
pub fn plan_turn(input: &PlanInput<'_>) -> ContextPlan {
    // 1. 由历史响应数据计算预留（输出/思考/schema 三类）
    let predicted_reserves = input.stats.response_token_estimates.reserve_for(
        input.model_id, input.query_source, input.recovery);
    let reserves = ContextReserves {
        output_tokens: predicted_reserves.output_tokens
            .saturating_sub(input.pre_reserved_output_tokens),  // 已被排除的不重复计费
        thinking_tokens: predicted_reserves.thinking_tokens,
        schema_tokens: predicted_reserves.schema_tokens,
    };
    // 2. 计算原始压力与预测压力
    let pressure = ContextPressure::compute(
        input.tokens.total_input_u32_saturating(),   // u64→u32 饱和，防回绕成低压力
        input.model_limit, reserves);
    // 3. 选择压缩档（门控：预测只能升档不能降档）+ 恢复升级
    let tier = select_tier_gated(pressure.raw, pressure.value)
        .escalate_for_recovery(input.recovery);
    // 4. 分配分节 token 预算
    let section_history = input.stats.section_token_history();
    let effective_input_limit = input.model_limit.saturating_sub(reserves.total()).max(1);
        // 钳到 1：零预算会产生难排查的空 prompt（:100-110 注释）
    let budget = TokenBudget::allocate(effective_input_limit, tier, &section_history);
    // 5. 由 provider 策略+会话闩锁选缓存策略
    let cache_strategy = plan_cache_strategy(input.provider_policy, input.latches);
    // 6. 构建节清单（Identity/Constraints 恒在；Memory 仅已有具体片段时）
    let sections = plan_section_manifest(&budget, input.has_memory);
    ContextPlan { sections, budget, compact_tier: tier, cache_strategy, pressure, reserves }
}
```

逐段解读：这是"预算感知的上下文规划"教科书实现——(1) 预留先行：先扣掉预测的输出/思考/schema 增长再算可用输入（`escalate_for_recovery` 会让 PTL 连发时逐级升档）；(2) `select_tier_gated`（budget.rs:42）取 raw 与 predictive 两压力档的 max，防临时虚高的预测导致欠压缩；(3) 预算下限 1 token 是可诊断性选择；(4) 缓存策略受 `SessionLatches` 约束：cache_scope 一旦闩死为非 Global，就不再尝试 global 作用域（planner.rs:130-141）；(5) 节清单的 scope 顺序（Global→Session→None）直接决定 serialize 阶段缓存标记能放在哪（4.5.4）。注意该函数在 `context/pipeline.rs` 里每回合被调用**两次**（先初步 Plan+Bind 实测 token，再最终 Plan），见 pipeline.rs:161-201。

#### D. SSE 分发与工具执行调度核心：`flush_pending_via_host`

位置：`crates/astra-turn-core/src/sse/stream_host.rs:1285`。消费循环把攒下的 pending（工具请求+审批请求）交给宿主执行的关键调度点。

```rust
// stream_host.rs:1299-1345（节选：分流）
    for item in items {
        match item {
            ChatTurnEdgePending::ToolRequest { session_id, run_id, request_id,
                schema_admitted_by_server, execution_deadline_unix_ms, ..tool, args } => {
                if request_id.is_empty() || tool.is_empty() { continue; }        // 无身份直接丢
                if !schema_admitted_by_server { continue; }                       // 未被 server 准入
                if let Err(error) = host.on_server_tool_surface_admission(&tool) {
                    // Edge 侧二次拒绝 → 立即合成 failed 结果回填
                    let result = EdgeToolExecResult { request_id, tool, args,
                        output: error, status: "failed".to_string(), duration_ms: 0, .. };
                    host.on_tool_result(&result); tool_results.push(result); continue;
                }
                tool_batch.push(ToolBatchRequest { session_id, run_id, .. });
            }
            ChatTurnEdgePending::ApprovalRequired { .. } => approval_requests.push(..),
            ChatTurnEdgePending::ApprovalBatchRequired { .. } => approval_requests.extend(..),
```

```rust
// stream_host.rs:1388-1446（节选：审批先于工具的不变量 + 批执行）
    // 审批必须在工具执行前解决——合批后两者可能同时在 pending 里，
    // 显式先跑审批以保持 approval_then_tool_request_same_id_both_processed 钉住的不变量
    // （否则 str_replace 的 tool_request 会先于用户授权执行编辑）
    let scoped_approval_groups =
        group_approval_requests(approval_requests, fallback_session_id, fallback_run_id);
    for (session_id, run_id, requests) in scoped_approval_groups {
        if host.should_abort_edge_work() { break; }
        if requests.len() > 1 {
            approval_results.extend(host.resolve_approvals_batch(&requests, ..).await);
        } else if let Some(request) = requests.into_iter().next() {
            approval_results.push(host.resolve_approval(&request.request_id, ..).await);
        }
    }
    if host.should_abort_edge_work() { return; }
    if !tool_batch.is_empty() {
        let results = host.execute_tools_batch(tool_batch).await;   // 宿主决定是否并行
        for result in results { host.on_tool_result(&result); tool_results.push(result); }
    }
```

逐段解读：(1) 调用时机由消费循环控制——非合批路径逐事件 flush，合批路径在 25ms 窗口（`pending_is_coalescible_tool_batch` + `tool_batch_coalesce_duration`）后 flush，让并发的 agent spawn 帧汇入同批；(2) `schema_admitted_by_server` 是 server 对工具面的准入戳，未准入静默丢弃、Edge 二次拒绝则**合成失败结果回填**（不悬挂 request_id）；(3) "审批先于工具"是被回归测试钉住的安全不变量，注释给出了反例（str_replace 在授权前执行）；(4) `group_approval_requests`（:1456）按生产者声明的持久属主（session/run）分组而非消费流，防止把审批 post 到错误的后代 run；(5) `execute_tools_batch` 是宿主能力洞——CLI 实现里接 `parallel_tool_exec::execute_parallel_round`（进程级信号量 + 读/写分区，兄弟中止语义）。

### 6.4 认证、会话持久化与 BYOK 代理（services）
### 关键函数深度解析

#### 1) 认证登录与令牌签发：`DatabaseAuthService::login`（auth/mod.rs:1699-1767）

```rust
// crates/services/src/auth/mod.rs:1699
async fn login(
    &self,
    request: AuthLoginRequestData,
) -> Result<AuthTokenRecord, (StatusCode, Json<ErrorResponse>)> {
    let pool = self.get_pool().await                      // :1703 require_shared_pool（control_pool 优先）
        .map_err(|e| map_auth_sqlx(e, "auth.get_pool", None))?;
    let user = self
        .fetch_user_by_username(&pool, &request.username) // :1708 SELECT ... FROM auth_users WHERE username=?
        .await ...?
        .ok_or_else(|| error_response(StatusCode::UNAUTHORIZED, "Invalid username or password"))?;

    if !bcrypt_verify(request.password.as_str(), &user.password_hash).unwrap_or(false) { // :1715
        return Err(error_response(StatusCode::UNAUTHORIZED, "Invalid username or password"));
    }
    if !user.is_active { ... }                            // :1721 403

    let session_id = Uuid::new_v4().to_string();          // :1725
    let access_token = self.create_access_token(&user.user_id, &user.username, &session_id, "internal")...;
    let refresh_token = self.create_refresh_token(&user.user_id, &session_id, "internal")...; // :1729
    let refresh_token_hash = sha256_hex(&refresh_token);  // :1732 只落哈希
    let expires_at = self.refresh_token_expires_at_string(Utc::now());

    let mut tx = pool.begin().await...;
    query("UPDATE auth_users SET last_login_at = NOW() WHERE user_id = ?")   // :1739
        .bind(&user.user_id).execute(&mut *tx).await...;
    query("INSERT INTO auth_refresh_tokens (token_id, user_id, session_id, token_hash, expires_at, is_revoked) \
           VALUES (?, ?, ?, ?, ?, 0)")                                       // :1744
        .bind(Uuid::new_v4().to_string()).bind(&user.user_id).bind(&session_id)
        .bind(&refresh_token_hash).bind(expires_at).execute(&mut *tx).await...;
    tx.commit().await...;                                 // :1756
    Ok(AuthTokenRecord { user_id: user.user_id, access_token, refresh_token,
                         token_type: "bearer".into(), expires_in: ... })
}
```

逐段解读：① `get_pool` 走 `lib.rs:95` 的 `require_shared_pool`，且 `DatabaseAuthService` 优先使用 `control_pool`（`auth/mod.rs:723-725` 注释：认证独享控制面连接池，防止大量 agent 持久化把登录饿死）；② 用户不存在与密码错误返回同一文案（防用户枚举），bcrypt 校验失败也按 `unwrap_or(false)` 闭门；③ 令牌由 `create_access_token/create_refresh_token`（913-963）委托 `jwt.rs:66 create_jwt_token` 签发——access 按 `access_token_expire_minutes`、refresh 按 `refresh_token_expire_days`，claims 携带 `sid`（会话）与 `origin`（internal/memoria/external），`jti` 用随机 Uuid 保证同一秒签发的令牌唯一（jwt.rs:274-291 回归测试）；④ 数据库只保存 refresh token 的 SHA-256 哈希，泄露库不等于泄露凭据；⑤ 事务内完成 last_login_at 与刷新令牌插入，commit 成功才返回。验证侧 `current_principal`（2102-2218）除验签外还查 `auth_refresh_tokens` 会话活性（`refresh_session_is_active`，1262-1270：`is_revoked=0 AND expires_at > NOW()`），使 logout/吊销能即时杀死 access token。

#### 2) 会话日志持久化：`JournalWriter::append` 与 CAS 提交（session_journal.rs:2364 / 2451）

```rust
// crates/services/src/session_journal.rs:2364
pub fn append(&self, event: &JournalEvent) -> std::io::Result<()> {
    use std::io::Write;
    let mut file = open_locked_journal_file(&self.path)?;              // :2366 打开并加文件锁
    let events = prepend_session_start_if_needed(&self.path, std::slice::from_ref(event))?; // :2367
    let buf = serialize_journal_events(events.as_ref())?;              // :2368 序列化为 JSONL
    if let Err(e) = file.write_all(&buf) { ... }                       // :2369 单次 write_all（O_APPEND 原子）
    file.sync_data()?;                                                 // :2379 fsync 保证崩溃持久
    update_cached_session_start_state_from_events(&self.path, events.as_ref());
    Ok(())
}

// crates/services/src/session_journal.rs:2451
pub fn append_canonical_commit_cas(
    &self,
    lease: &SessionExecutionLease,                 // :2454 必须持有匹配的执行租约
    expected_base_cursor: Option<&SessionCursorV1>,
    turn: u32,
    intended: &ConversationCommitV1,
    events: &[JournalEvent],
) -> CanonicalCommitCasOutcome {
    if lease.session_id != self.session_id
        || lease.lock_path != execution_lease_path(&self.path, &self.session_id) { // :2459 租约防陈旧写者
        return CanonicalCommitCasOutcome::NotCommitted(...);
    }
    self.append_canonical_commit_cas_locked(expected_base_cursor, turn, intended, events,
        &lease.created_parent_dirs)                                     // :2466 锁内 CAS
}
```

逐段解读：① `append` 是普通追加路径：`write_all` 一次写入"行+\n"，注释（2354-2363）解释了为何不用 `writeln!`——Linux O_APPEND 下 ≤PIPE_BUF 的单次写原子，分开写 `\n` 会产生并发交错；`sync_data` 每次 fsync 换取崩溃安全（`append_bulk_no_sync` 是被打断 turn 的降级路径）；② `prepend_session_start_if_needed`（342-387，带 `BoundedSessionCache` 有界缓存）保证 journal 首行一定是 session_start 事件；③ `append_canonical_commit_cas` 是 canonical 提交路径：先验证 `SessionExecutionLease`（2030，基于 `.lock` 文件的进程级租约）属于本会话本文件——陈旧执行者（例如 turn 被接管后仍残留的旧任务）连文件锁都拿不到；`append_canonical_commit_cas_locked`（2475 起）在 `fs2::FileExt::lock_exclusive` 排他锁内完成：校验批内"恰好一个目标 turn 提交、无其他 commit"（2491-2518）→ 打开并确认 inode 仍是当前文件（防 journal 被轮转后写进孤儿 inode）→ 与 `expected_base_cursor` 比较 → 追加 + 持久化栅栏 + 目录 fsync（`sync_creation_metadata_if_needed`，2411-2443）→ 回读确认精确提交。这是"本地文件系统上的乐观并发控制"，与数据库侧 `session_context_coordinator` 的写者 fence 互为犄角。

#### 3) BYOK 代理转发：`endpoint_client`（byok_endpoint.rs:196-205）与隧道 `bridge`（byok_endpoint/proxy.rs:209-263）

```rust
// crates/services/src/byok_endpoint.rs:196
pub async fn endpoint_client(raw: &str) -> Result<EndpointClient, String> {
    let url = parse_endpoint(raw)?;                                   // :197 URL 硬校验（HTTPS/公共域）
    let proxy = proxy::EgressProxy::parse(configured_value(proxy::PROXY_ENV)?.as_deref())?; // :198 ASTRA_BYOK_PROXY_URL
    let addresses = dns::resolve(&url, configured_value(dns::DNS_SERVERS_ENV)?.as_deref()).await?; // :199
    validate_addresses(&addresses)?;                                  // :200 全部地址必须公共 IP
    match proxy {
        Some(proxy) => proxy::client(&url, &addresses, proxy, transport_builder()).await, // :202
        None => pinned_client(&url, &addresses).map(EndpointClient::from),              // :203 resolve_to_addrs DNS 钉扎
    }
}

// crates/services/src/byok_endpoint/proxy.rs:209（节选）
async fn bridge(mut incoming: TcpStream, authority: &str, authorization: &str,
               targets: &[SocketAddr], proxy: &EgressProxy) -> io::Result<()> {
    let setup = tokio::time::timeout(CONNECT_TIMEOUT, async {
        let head = read_head(&mut incoming).await?;
        if lines.next() != Some(format!("CONNECT {authority} HTTP/1.1").as_str()) {
            return Err(failed("unadmitted tunnel destination"));       // :220 只允许已验证目标
        }
        let authenticated = ... proxy-authorization 匹配随机令牌 ...;  // :222-229
        if !authenticated { return Err(failed("unauthorized tunnel")); }
        for &target in targets {
            if let Ok(stream) = proxy.connect(target).await { return Ok(stream); } // :231 逐个已验证 IP
        }
        ...
    }).await;
    incoming.write_all(b"HTTP/1.1 200 Connection Established\r\n\r\n").await?; // :251
    tokio::time::timeout(Duration::from_secs(360),
        tokio::io::copy_bidirectional(&mut incoming, &mut upstream)).await ...; // :256-259 双向裸转发
}
```

逐段解读：① `endpoint_client` 是所有用户自配模型端点流量的唯一出口构造器（调用方：`models.rs:2764/4028/4230` 的端点验证与思考探测、`runtime/src/turn/llm/client.rs:4910/7107` 的实际推理转发）；② `parse_endpoint`（65-95）先拒绝非 HTTPS、带凭据/query/fragment、localhost、无点主机、`%` 编码路径；`dns::resolve` 用 hickory 直连指定 DNS（可用 `tcp://` 前缀规避透明代理的 Fake-IP UDP 应答），`validate_addresses` 要求每个 A/AAAA 都是 `public_ip`——请求期间 DNS 重绑定被 `resolve_to_addrs` 钉扎消灭（域名只解析一次，连接固定到已验证 IP，TLS 仍按原主机名校验/SNI）；③ 有出口代理时走更精巧的路径：`proxy::client`（265-313）在本地随机端口起一个只属于本次请求的 TcpListener，reqwest 的代理设置指向它并携带随机 Basic 凭据；`bridge` 只放行 CONNECT 目标等于已验证 authority 且凭据匹配的连接，再由 `EgressProxy::connect`（93-137，支持 HTTPS/SOCKS5/SOCKS5h 与 Basic 认证）把**IP**（不是主机名，防代理侧二次解析）连到上游，之后 360 秒内纯双向转发端到端 TLS 字节——代理认证头与模型 API key 都不会进入对端；`EndpointClient::drop` 中止隧道任务（byok_endpoint.rs:31-37）。整个机制结论：**BYOK 代理不是应用层 API 网关，而是"校验+钉扎+可选 CONNECT 隧道"的传输层安全边界**，业务层请求构造（注入加密存储的 api_key 等）由 models.rs 的 `AdmittedModelExecution`（含 `api_key/base_url/header_overrides`，models.rs:695-720）与 runtime 的 LLM client 完成。

### 6.5 服务器构建、聊天流入口、agentic 宿主与模型调用（runtime）
### 关键函数深度解析

#### 1) `serve()` — 服务器生命周期总控（crates/runtime/src/server/mod.rs:251）

```rust
pub async fn serve(addr: SocketAddr) -> Result<(), Box<dyn std::error::Error>> {
    static TRACING: std::sync::OnceLock<()> = std::sync::OnceLock::new();
    TRACING.get_or_init(|| {
        let _ = astra_logging::init_from_env(
            astra_logging::LogInitConfig::new("warn,astra_runtime=info,astra.http.access=info")
                .with_service_name("astra-server"),
        );
    });
    crate::apply_safety_config_from_runtime_config(
        &astra_config::runtime_config::RuntimeConfig::load(),
    );
    let settings = AppSettings::from_env()?;
    let state = state_builder::build_server_state(settings).await?;
    // ... http_proxy 告警、memoria 启动健康检查 ...
    let listener = tokio::net::TcpListener::bind(addr).await?;
    let bg_cancel = tokio_util::sync::CancellationToken::new();
    let mut bg_handles: Vec<tokio::task::JoinHandle<()>> = Vec::new();
    bg_handles.push(spawn_memoria_health_refresh(state.clone(), bg_cancel.clone()));
    if let Some(ref pool) = state.shared_pool {
        bg_handles.push(spawn_data_cleanup(pool.clone(), bg_cancel.clone()));
        // ...edge dispatch 清理/指标刷新/work 恢复任务/清理重试/租约 sweeper...
    }
    axum::serve(listener, build_app(state))
        .with_graceful_shutdown(http_shutdown_signal())
        .await?;
    finish_server_shutdown(bg_cancel, bg_handles, run_lifecycle, matrix_runtime, edge_pool).await;
    database_pool_owner.close_database_pools().await;
    Ok(())
}
```

**解读**：① OnceLock 保证多测/多入口下 tracing 只初始化一次，默认级别刻意压到 `warn`、只放行 `astra_runtime` 与 HTTP access 为 info；② trust_mode 必须在任何请求前应用（全局安全门是运行时可变状态，晚于请求会形成窗口）；③ `build_server_state` 是全部依赖注入的汇聚点（await 一次完成 schema、双连接池、40+ 服务）；④ 后台任务全部挂 CancellationToken，`finish_server_shutdown`（:187）的顺序有明确语义——先排空 edge WS（下游能力），再排 run（30s+10s），再排 provider 结算（保证推理台账闭合），最后才停 sweeper/Matrix/OTLP，任何一步超时都有对应 error 日志并继续降级；⑤ `axum::serve` 返回后仍持有 `database_pool_owner` 用于最终关池，防止早关导致排水失败。

#### 2) `chat_stream_handler` — 聊天 SSE 流式 HTTP 入口（crates/runtime/src/server/chat_handlers.rs:301）

```rust
pub(super) async fn chat_stream_handler(
    State(state): State<AppState>,
    trace: Option<Extension<RequestTrace>>,
    method: Method, uri: Uri, headers: HeaderMap, body: Bytes,
) -> Response {
    let request_id = trace.as_ref().map(|Extension(trace)| trace.request_id.clone());
    let principal = match state.auth_service
        .current_principal_for_request(&headers,
            external_request_descriptor(&method, &uri, &headers, "/chat/stream", &body)).await
    { Ok(principal) => principal,
      Err((status, error)) => return sse_error_response_from_error_with_request_id(status, error.0, request_id.as_deref()) };
    let request = match parse_chat_request_body(&body) { /* 同上，SSE 错误而非 JSON 错误 */ };
    let (resolved, runtime_context) = tokio::join!(
        resolve_or_create_chat_session(&state, &user, requested_session_id.clone(), requested_agent_id, false),
        inject_effective_runtime_context(&state, &principal, &mut chat_data),
    );
    // ...会话解析、authority 校验（validate_conversation_authority）、错误短路...
    match state.execution.run_lifecycle_service.stream_chat(user.user_id.clone(), chat_data).await {
        Ok(mut stream) => {
            if let Some(event_rx) = stream.event_rx.take() {
                sse_streaming_response(session_id, run_id, request_id.clone(), event_rx) // 增量 SSE
            } else {
                /* 批量回退（测试 stub）*/ sse_json_response(events)
            }
        }
        Err((status, error)) => sse_error_response_from_error_with_context(status, error.0, /* SseErrorContext */),
    }
}
```

**解读**：① 与 `/chat`（chat_handler :254，返回 Json）的差异在于**错误也要走 SSE**：认证失败/JSON 无效/会话冲突都返回 200+`event: error` 风格的 SSE 响应而非状态码，保证前端单连接消费；② `external_request_descriptor`（server/mod.rs:94）把 method/path/route/x-request-id/body sha256 打包传给 auth 服务——provider 请求鉴权（重放防护）依赖该描述符；③ `resolve_or_create_chat_session`（:149）无 session_id 时经 `create_session_with_resource_quota` 建会话，session 服务未配置时降级（返回 None 的 session，仍可执行）；④ `validate_conversation_authority`（:19）是 fencing 关键：客户端提供的 ConversationAuthority 信封必须在**同一 DB 快照**里验证 writer lease + ExecutionGrant 签名（writer_epoch/lease_id/run_generation）+ canonical head cursor/prompt_manifest_root，任一不匹配返回 409 `conversation_authority_fenced`——服务端自有 loop 可以不带授权启动（run lifecycle 内部获取），但带了就严格失败关闭；⑤ 会话解析与 runtime context 注入 `tokio::join!` 并行化降低首字节延迟；⑥ 返回的 `ChatStreamRecord.event_rx` 是 mpsc::Receiver<Value>，SSE body 由 `sse_streaming_response`→`sse_projected_streaming_response`（http_helpers.rs:258）以 async_stream 包装：先发 `session_info`，之后 select 事件/心跳（SSE_HEARTBEAT_INTERVAL_SECS 的 `ping`）/终端宽限定时器（SSE_DURABLE_TERMINAL_GRACE=5s，超时合成 `run_finished failed`），事件经 `transform_stream_run_events_for_client_with_pending` 投影为客户端形态。

#### 3) `ServerAgenticLoopHost::execute_turn` — 单个 LLM 回合核心（crates/runtime/src/server/server_loop_host.rs:11823，节选）

```rust
async fn execute_turn(&mut self, state: &mut AgenticLoopState)
    -> Result<HostTurnResult, astra_core::ClassifiedError> {
    // 0) Work 图和解 + 恢复门 + 语义预检（拒绝过期 owner 的重复投递）
    self.hydrate_provider_canonical_transitions(state).await?;
    // 1) 模型解析 + 本地限流冷却（Wait/UseFallback/Reject）
    let mut llm_cfg = self.resolve_llm_config_for_state(state).await?;
    let cooldown = rate_limit_cooldown();
    match cooldown.with(&llm_cfg.model_name, |c| c.check_request(has_fallback)) { /* ... */ }
    // 2) 上下文管线（系统提示/压缩分层/schema 修剪的唯一事实源）+ Memoria 压缩
    let turn_pipeline = self.run_turn_pipeline_with_model_limits_and_session_memory(
        state, context_tool_surface, &llm_cfg.provider, /* ... */).await;
    let compact_result = self.compact_messages_via_memoria(state, &pipeline_messages,
        &compaction_fixed_context, context_tool_surface, tier, &llm_cfg).await;
    let mut llm_messages = self.assemble_llm_messages(/* system, volatile, compacted, state, cfg */)?;
    // 3) 物理尝试循环：DB 准入 → 调用 → （finish_reason=length 时一次探测）
    let mut result = loop {
        match crate::llm_provider_admission::admit_llm_provider_request(
            self.shared_pool.as_ref(), &llm_cfg.provider, &llm_cfg.model_name,
            admission_estimated_tokens as u64).await
        { Ok(()) => { /* 记 admission=allowed 指标 */ }
          Err(error) => { /* 记指标并整回合失败 */ return Err(error); } }
        // ... call_llm_and_collect_*（带 stream_callback 即时产出 text_delta）...
    };
}
```

**解读**：这是"回合"的权威实现，三层节流依次生效——进程内 `rate_limit_cooldown`（模型粒度、支持同 owner fallback 链，:11933-12019）、跨请求 DB 准入 `admit_llm_provider_request`（:12585，RPM/TPM 窗口 + TAT 起搏，防止多副本同时打爆 provider）、以及请求内 `llm_total_budget` 墙钟预算（client.rs 内部）。上下文构造刻意"单一事实源"：pipeline 决定系统提示与分层裁剪，`stabilize/annotate_tool_schemas_for_cache` 保持工具 schema 前缀字节稳定以命中 provider prompt cache（Anthropic cache_control 见 turn/llm/context.rs）；`settlement_wire_tools`（:12087）处理 text-only 结算轮"schema 保留但 tool_choice=none"的兼容面。每次物理请求前 `PreparedProviderRequest` 生成 wire 指纹并交给 `ProviderAttemptObserver`（turn/llm/durable.rs）先落 durable 台账再发 HTTP——崩溃后可判定"已授权未送达/已送达未回包"的精确状态。

#### 4) `build_server_state` — AppState 组装（crates/runtime/src/server/state_builder.rs:20）

```rust
pub async fn build_server_state(settings: AppSettings)
    -> Result<AppState, Box<dyn std::error::Error>> {
    ensure_core_schema(&settings.matrixone, &settings.database_bootstrap_catalog).await?;
    let control_max = control_pool_max_connections(settings.matrixone.db_pool_max_connections); // (total/20).clamp(0,4)
    let shared_pool = SharedPool::new(&pool_settings_with_limit(&settings.matrixone, shared_max)).await?;
    let control_pool = /* 可选小控制面池 */;
    let shared_encryptor = Arc::new(FernetTokenEncryptor::from_key(settings.token_encryption_key.as_deref())?);
    let auth_service = core::build_auth_service(&settings, &shared_pool, control_pool.as_ref(), &shared_encryptor)?;
    let state = core::build_core_state(&settings, &shared_pool, control_pool.as_ref(), &shared_encryptor, auth_service);
    let state = core::install_turn_persistence_services(state, &settings, &shared_pool);
    let state = core::install_admin_services(state, &settings, &shared_pool, control_pool.as_ref())?;
    let state = core::install_execution_services(state, &shared_pool)
        .with_memoria_config(settings.memoria.base_url.clone(), settings.memoria.master_key.clone())
        .with_self_hosted_memoria_fallback(settings.memoria.allows_self_hosted_master_fallback());
    let state = install_skillify_harness_service(state, &settings, &shared_pool, &shared_encryptor);
    let wiring = runtime::build_runtime_wiring(&settings, &shared_pool, &shared_encryptor, &state).await?;
    let state = state
        .with_run_lifecycle_service(Arc::new(wiring.run_lifecycle))
        .with_delegation_engine(Arc::clone(&wiring.delegation_engine))
        .with_resource_governor(Arc::clone(&wiring.resource_governor))
        .with_auxiliary_pools(control_pool.into_iter().collect())
        .with_matrix_cloud_runtime(Some(Arc::clone(&wiring.matrix_rt)));
    Ok(state)
}
```

**解读**：装配是**线性分层**的：schema → 双池（控制面池最多 4 连接或 5%，保证 auth/健康检查在共享池饱和时不饿死，`control_pool_max_connections` :99）→ 加密器 → auth → 30+ CRUD 服务（core.rs:68-189 全部 `Database*Service::new(...).with_pool(...)` 模式）→ turn 持久化 7 写入器 → admin（走 control_pool）→ edge/工具执行（`build_shared_tool_execution_service` core.rs:286 注入部署策略的 provider 能力/禁用清单）→ skillify harness → 最后 `build_runtime_wiring`（runtime.rs:4）组装"有状态执行面"：RunEngine（并立即 `recover_active_runs` 恢复孤儿 run）、DelegationEngine、MatrixCloudRuntime、ResourceGovernor、AgenticRunLifecycleService。密钥用 `derive_runtime_subkey`（core.rs:8，SHA256("astra.runtime-root.v1\0"+purpose+"\0"+root)）域分离派生 execution-grant 签名钥与 artifact 签名钥，避免根密钥直接参与多用途签名。

### 6.6 CLI 分发、流式渲染与 Edge 投递（astra-cli / astra-edge）
关键函数深度解析（3 个）。

#### ① entrypoint::run 的命令分发（entrypoint.rs / command_router.rs）

```rust
// crates/astra-cli/src/entrypoint.rs:115-150（节选）
pub fn run() -> i32 {
    match astra_core::process_runtime::build_process_runtime() {
        Ok(runtime) => runtime.block_on(run_async()),
        Err(error) => { eprintln!("Error: unable to initialize Astra runtime: {error}"); 3 }
    }
}
async fn run_async() -> i32 {
    let cli = match Cli::try_parse() { Ok(cli) => cli, Err(error) => {
        let exit_code = error.exit_code();
        if error.use_stderr() { let _ = error.print(); }
        else { let _ = crate::cli::stream::output_sink::write_stdout_records(&rendered); } // :146
        return exit_code;
    }};
    ...
}

// crates/astra-cli/src/cli/command_router.rs:752-776
pub(crate) fn execute_cli_command<'a>(command: Option<Command>, ...) 
    -> std::pin::Pin<Box<dyn std::future::Future<Output = Result<ExitCode, String>> + 'a>> {
    // 巨型分发 future 在 API 边界擦除类型：内联 async fn 会把 Command
    // 与实现体嵌进每个调用者的状态机，撑爆 Tokio 测试线程栈（注释原文）
    Box::pin(execute_cli_command_impl(command, profile, global_model, ...))
}

// crates/astra-cli/src/cli/command_router.rs:868-906（分发头）
match command {
    None | Some(Command::Interactive) => { ... run_interactive_chat(...).await?; Ok(ExitCode::Success) }
    Some(Command::Serve(args)) => match args.mode {
        None => start_http_server(&args.host, &args.port).await?,         // :888
        Some(ServeMode::Http(http_args)) => start_http_server(...).await?,
        Some(ServeMode::Stdio) => crate::cli::app_server::run_stdio_app_server("stdio://", ...).await?,
    }
    ...
}
```
解读：(1) run() 只建 process runtime 并 block_on，运行时构造失败返回 3；(2) run_async 的 clap 错误分流——help/version 经 output_sink 的 `write_stdout_records` 逐记录写 stdout（让 `head`/pager 关闭可观测），错误走 stderr；(3) `--settings`/trace 覆盖先累积进局部 overlay，直到首次 `RuntimeConfig::load()` 前 `set_cli_overlay` 才安装（entrypoint.rs:215-217，注释明言防"读到旧配置"的窗口）；(4) execute_cli_command 的 Box::pin 是刻意的栈安全设计；(5) 分发顺序上 `-p` print 与 `-c/-r` resume 在 execute_cli_command **之前**短路（entrypoint.rs:387/409），因此这两类路径不受子命令 match 约束。

#### ② chat 流式循环（stream_chat_sse + fetch_chat_turn_sse + consume_turn_sse）

```rust
// crates/astra-cli/src/cli/chat_stream/sse_loop/mod.rs:208-233 + 1124-1135（节选）
pub(crate) async fn stream_chat_sse(mut p: ChatTurnParams<'_>) -> Result<StreamResult, crate::TurnFailure> {
    let start = Instant::now();
    p.model = normalize_turn_model(p.model);
    let default_model = if p.model.is_none() {
        match session_runtime::resolve_server_default_model(p.api, p.token).await {  // :215
            ServerDefaultModel::Selected(selection) => { model_context_window = selection.context_window;
                p.offering_id = Some(selection.offering_id); Some(selection.name) }
            ServerDefaultModel::NoModels | ServerDefaultModel::Unavailable => None,
        }
    } else { None };
    let Some(selected_model) = require_selected_turn_model(p.model, p.session_id, p.turn_index) else {
        return Err(missing_model_selection_turn_failure(p.session_id));   // 无 offering 拒绝开局 :234-243
    };
    ...  // 构建 edge ToolExecutor(:356-459) + CliServerAdmissionHost(:696) + AgenticLoopState(:818)
    let loop_result = run_agentic_loop_with_host(&mut host, &mut state).await;   // :1129 循环体在 astra-runtime
    ...
    let result = build_stream_result(StreamResultBuild { ... });               // :1322
    Ok(result)
}

// crates/astra-cli/src/cli/chat_stream/sse_loop/agentic_loop_turn.rs:1650-1654 + 1877-1890（节选）
let resp = api
    .post_developer_loop_retry_429(token, &server_payload, CHAT_TURN_POST_MAX_RETRIES, quiet)  // :1652
    .await.map_err(|e| e.to_string())?;
...
let turn = consume_turn_sse(prep_line, resp, render_md, term_width, render_policy,
    Some(edge_ctx), pre_clear_lines, auth_profile, cancel_token, stream_json_exchange).await;   // :1878

// crates/astra-cli/src/cli/stream/stream_render.rs:7874-7924（节选）
let mut byte_stream = Box::pin(resp.bytes_stream().map(|r| r.map(|b| b.to_vec()).map_err(|e| e.to_string())));
let mut host = CliSseStreamHost::from_edge_ctx_with_auth(ctx, term_width, ...);   // :7906
let (result, _abort) = consume_sse_stream_cancellable(&mut byte_stream, &mut host, idle,
    Some(&physical_stream_cancel), None).await;                                   // :7917 运行时通用 SSE 消费器
```
解读：(1) 模型选择三重强制——必须解析出具体 model 名、正 context_window、offering_id，任一缺失在开 SSE 前失败并记 journal（:1386-1454）；(2) "Server-owned admission" 架构：CLI 组装宿主与状态，续轮（模型/工具循环）由 Server 拥有，Edge 回调在唯一响应流打开期间完成（sse_loop/mod.rs:1-5 模块注释）；(3) POST 走 thin-client 的 429 传输重试，对 stream-json 观察者只算一个 exchange（:1639-1648 注释）；(4) consume_turn_sse 把 reqwest 字节流转为通用 chunk 流，`consume_sse_stream_cancellable`（astra-runtime）逐事件回调 `CliSseStreamHost`：`on_accepted_sse_event`（:3776）分发 JSON 事件、token 增量进 markdown/行渲染器、工具事件进 `execute_tool(s)_batch`，本地执行完经 `post_tool_result_with_auth_retry`（:1628）回传并在 401 时原地刷新令牌重试一次；(5) 流结束 `on_sse_done`/`build_stream_result` 汇总 token/工具/中断/服务端终态核验（tool_ledger 聚合不完整 ⇒ 标记 `execution_incomplete` 中断语义，agentic_sse_loop.rs:332-345）。

#### ③ astra-edge 的 Runner 主循环与工具执行分发

```rust
// crates/astra-edge/src/main.rs:1091-1259（节选）
loop {
    tokio::select! {
        msg = read.next() => {
            ...
            Ok(EdgeServerMessage::ToolRequest { request_id, identity, delivery_generation, tool,
                args: tool_args, runtime_process_authorization, runtime_process_authorization_required,
                timeout_secs }) => {
                if !valid_runtime_process_authorization(&tool, runtime_process_authorization_required,
                        runtime_process_authorization.as_deref()) {                    // fail-closed :1111
                    let message = rejected_tool_message(request_id, *identity, delivery_generation,
                        "Runtime process authorization is invalid");
                    write.send(Message::Text(serde_json::to_string(&message)?.into())).await?; continue;
                }
                let execution_permit = execution_budget.try_acquire();                 // 128 并发闸 :1129
                match journal.prepare(&request_id, &identity, delivery_generation, &tool,
                        &tool_args, execution_permit.is_some()).await {                // 持久日志三态 :1130
                    Ok(PrepareOutcome::Replay(result)) => { /* 已有结果 → 直接回放 */ }
                    Ok(PrepareOutcome::Active) => { /* 重复投递并入在跑调用 */ continue; }
                    Ok(PrepareOutcome::Execute) => {}
                    Err(JournalError::Full | JournalError::WalFull) => { /* 饱和拒绝 */ }
                }
                let cancel = invocations.begin(&request_id, delivery_generation)?;      // 代际注册 :1206
                tokio::spawn(async move {                                              // :1217
                    let execution = async {
                        if let Some(pa) = runtime_process_authorization.as_deref() {
                            runtime_process_authorization::execute_bash(executor.as_ref(), &tool_args, pa).await
                        } else {
                            astra_tools::ToolExecutor::execute_with_cancel(
                                executor.as_ref(), &tool, &tool_args, Some(&cancel)).await }
                    };
                    let result = tokio::select! {
                        _ = cancel.cancelled() => astra_tools::cancelled_tool_result(&tool, true),
                        result = tokio::time::timeout(Duration::from_secs(timeout_secs), execution) =>
                            match result { Ok(r) => r,
                                Err(_) => astra_tools::ToolResult::error(
                                    format!("Tool '{tool}' timed out after {timeout_secs}s")) }
                    };
                    let _ = completed_tx.send(CompletedEdgeInvocation { request_id,
                        generation: delivery_generation, result, duration_ms }).await;
                });
            }
        }
        Some(completed) = completed_rx.recv() => {                                     // :1310
            if !invocations.finish_if_current(&completed.request_id, completed.generation) { continue; }
            let result = journal.complete(&completed.request_id, completed.generation,
                DurableEdgeResult::from_tool_result(completed.result, completed.duration_ms)).await?;  // 先落盘
            let record = journal.pending_results()?.into_iter()
                .find(|p| p.request_id == completed.request_id)?;
            write.send(Message::Text(serde_json::to_string(&record.result.client_message(
                record.request_id, record.identity, record.delivery_generation)...)?.into())).await?;
        }
        _ = heartbeat.tick() => { write.send(Ping)… }                                  // :1344
    }
}
```
解读：(1) 每个工具调用带 `delivery_generation` 代际号，tracker 与 journal 双侧校验——重放、去重、过期取消/完成全部按代际判定，防 at-least-once 投递造成的重复执行；(2) 执行前 journal.prepare 先写 WAL，结果 complete 也先落 durable outbox，**只有收到 ToolResultAck（:1279 `journal.acknowledge`）才删除**，断线重连时 `pending_results` 全量重放（:1071-1080）——"先持久后发送"是投递语义核心；(3) 并发上限 128（信号量 try_acquire，饱和即拒绝而非排队）；(4) `runtime_process_authorization` 校验是 fail-closed：required 与 presence 必须严格相等且授权非空、工具必须匹配（bash），否则直接拒绝回包；(5) 心跳 Ping 失败立即断线，交给外层指数退避重连。

### 6.7 Web SSE 客户端与代理路由（web）
### 深度解析一：浏览器端 SSE 流处理（web/lib/api/chats.ts）

**消费循环**（`web/lib/api/chats.ts:670-746`，`consumeChatStream`）：

```ts
// lib/api/chats.ts:695-729（节选）
  const reader = response.body.getReader();
  const decoder = new TextDecoder();
  const state: ChatStreamState = { rawText: "", text: "", reasoning: "" };
  let buffer = "";
  let abortListener: (() => void) | undefined;

  try {
    if (handlers.signal) {
      abortListener = () => { void reader.cancel(); };
      handlers.signal.addEventListener("abort", abortListener, { once: true });
    }
    for (;;) {
      if (handlers.signal?.aborted) {
        await reader.cancel();
        throw new DOMException("The chat stream was aborted.", "AbortError");
      }
      const { value, done } = await reader.read();
      if (handlers.signal?.aborted) {
        throw new DOMException("The chat stream was aborted.", "AbortError");
      }
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const frames = buffer.split(/\r?\n\r?\n/);
      buffer = frames.pop() ?? "";
      for (const frame of frames) {
        const event = parseSseFrame(frame);
        if (event) applyStreamEvent(event, state, handlers);
      }
    }
```

逐段解读：
1. **不用 EventSource**：SSE 请求是 `POST /api/chats/{id}/stream`（带 JSON body），浏览器 `EventSource` 只支持 GET，故手写 `fetch`+`ReadableStream` 读取（`streamChatMessage`:763-778 设置 `Content-Type: application/json` 与 `signal`）。
2. **分帧**：按空行 `\r?\n\r?\n` 切帧，最后一段保留为 `buffer` 等下一 chunk 补全；流结束后 `decoder.decode()` 冲刷尾巴再解析残帧（731-740 行）。`parseSseFrame`（261-277 行）收集帧内所有 `data:` 行拼接后 `JSON.parse`，空数据与 `[DONE]` 直接丢弃——即代理层与后端之间不需要 event: 字段，只认 data-only 帧。
3. **可中止**：`AbortSignal` 双保险——监听器 `reader.cancel()` + 循环内主动检查并抛 `AbortError`，上层 `useStreamLifecycle.startStream` 捕获后静默返回（use-stream-lifecycle.ts:908-910）。
4. **事件归约**（`applyStreamEvent`:339-668）：每个事件先记录 `nextEventIndex = max(nextEventIndex, index+1)`（346-348 行，供断线重挂时作为 `last_index` 传给 GET）；然后按 `type` 分派：`local_messages`（代理层合成的本地占位消息替换）、`session_info/session_bound`（绑定后端会话）、`text_delta`（经 `mergeTextDelta` 幂等合并——若 delta 与当前尾部重复或整段重发则不重复追加，`stream-text.ts:28-36`——再 `splitThinkingTags` 拆 `<thinking>` 标签分流到 onText/onReasoning）、`run_started/run_input_queued/run_waiting/run_blocked/run_paused/run_resumed/run_interrupted`（投影 activeRun 状态机）、`approval_required`（弹审批 UI）、`tool_call_end`/`artifacts`（合并 artifacts）、`run_finished`（终态：cancelled/paused/failed 分流）。
5. **收尾判定**（748-760 行）：流结束后按 `state.error → 抛 WebApiError`、`cancelled → onCancelled`、`paused → onPaused`、否则 `onDone` 的顺序收敛；`useStreamLifecycle` 在 `onDone` 里 `flushNow()` 并把 assistant 消息置 `complete`。

### 深度解析二：stream route handler——SSE 代理与鉴权（web/app/api/chats/[chatId]/stream/route.ts）

**POST 主流程**（`route.ts:510-704`）：

```ts
// route.ts:510-529 + 593-599（节选合并）
export async function POST(request, context) {
  const auth = await requireRuntimeUser();
  if (auth.response) return auth.response;          // 401 AUTH_REQUIRED
  const ownerUserId = auth.user.user_id;
  const { chatId } = await context.params;
  const chat = getChat(ownerUserId, chatId);
  if (!chat) return NextResponse.json({ error: "chat not found" }, { status: 404 });
  if (chat.chat.archivedAt)
    return NextResponse.json({ error: "archived chat is read-only" }, { status: 409 });
  ...
  const started = beginStreamingMessage(ownerUserId, chatId, {   // 本地乐观建消息
    ...body, workspaceSelection: workspaceSelection ?? undefined,
  });
  ...
  return proxyRunStream({ backendResponse: async (emit) => {
      const runtime = await getStreamRuntime();    // requireRuntimeClient auth:"required"
      ...
      return runtime.fetchResponse(PATH_CHAT_STREAM, {   // POST 后端 /chat/stream
        method: "POST", auth: "required",
        signal: backendAbortController.signal,
        json: { message: body.content, parts: [], attachments: body.attachments ?? [],
          session_id: runtimeSessionId,
          model_selection: { offering_id: modelSelection.offeringId },
          allow_skills: activeSkills.length ? activeSkills : undefined,
          enabled_tools: activeTools,
          workspace_binding: workspaceBindings.workspaceBinding,
          executor_binding: workspaceBindings.executorBinding,
          context: { source: "web_v1", transport: "next_sse_proxy", ... } },
      });
    }, ... });
```

逐段解读：
1. **鉴权三层**：`requireRuntimeUser()`（Web 会话 cookie 有效）→ `beginStreamingMessage` 的 ownerUserId 作用域隔离（聊天只属于该用户，web-store.ts:954）→ 转发后端时 `WebRuntimeClient` 注入 `Authorization: Bearer` + `X-User-Id`（server.ts:197-203），后端再验 JWT。浏览器永远拿不到 token（httpOnly）。
2. **乐观本地状态**：`beginStreamingMessage` 在 store 里先落 user/assistant 两条消息（assistant 状态 streaming）与 activeRun 记录，随后通过 SSE 首帧 `local_messages` 把服务端的规范 id 发回浏览器替换乐观 id（route.ts:253-259，浏览器侧 use-stream-lifecycle.ts:736-782 做去重换 id）。
3. **请求改写**：Web 的 `SendMessageRequest{content, options{model, activeSkills, activeTools, webSearch, thinking}}` 被翻译为后端 `POST /chat/stream` wire：`model_selection.offering_id`（经 `resolveModelOfferingSelection` 校验）、`enabled_tools`（webSearch=true 时注入 `web_search`/`web_fetch`，route.ts:76-86）、workspace/executor binding（`resolveWorkspaceBindings`）、`context.source=web_v1` 遥测标记。`ensureChatBackendSession`（web-store.ts:1770）懒创建后端 `/sessions` 并把 backendSessionId 存回聊天记录；成功后先发 `session_bound` 合成事件（route.ts:639-643）。
4. **代理核心 `proxyRunStream`**（177-508 行）：构造 `ReadableStream`，`backendResponse` 可以是 Response 或"先 emit 后返回 Response"的工厂（POST 场景先用 emit 发 `session_bound`/`local_messages`）。随后：校验后端响应头 `x-astra-agent-interaction-api-major === "1"`（316-338 行，不匹配则中止并广播 `RUNTIME_PROTOCOL_MISMATCH` 错误事件——**Web 与 Server 的交互协议版本握手**）；逐 chunk `enqueueChunk(value)` 原样转发给浏览器，同时同一份数据进 `eventFromSseFrame` → `applyStreamEvent`（stream-event-handler.ts）**旁路镜像更新 web-store**（assistant 文本/reasoning/artifacts/activeRun），保证刷新页面后 `getChatHydrated` 能还原流中状态；流末若 `lastStatus==="complete"` 再调 `fetchSessionArtifacts` 拉增量 artifacts 并补发合成 `artifacts` 帧（447-464 行）。`cancel()` 回调双向联动：浏览器断开 → `backendAbortController.abort()` 中止后端流。
5. **GET 重挂**（706-791 行）：`?runId&last_index&assistantMessageId` → 后端 `GET /chat/runs/{runId}/stream?last_index=N` 续传事件索引之后的内容；`assistantMessageId` 三级回退（请求指定 → activeRun 绑定 → 最后一条 assistant 消息）。


---

## 7. 端到端调用链分析

本章选取三个典型业务场景，给出从入口到落库/返回的完整调用链（文件 + 函数级），并附时序图。三个场景共用同一条服务器主干（场景一详述），差异在客户端形态与工具执行位置。各层更细的链路素材（含行号）见 §7.4「各层调用链明细」。

### 7.1 场景一：CLI 一次性聊天（`astra chat -m "..." -y`，工具在 CLI 本地执行）

这是理解 Astra 的最短完整闭环：CLI 组装宿主 → Server 执行 agentic 循环 → 工具调用回投 CLI 本地执行 → SSE 回传渲染 → 持久化。

**① CLI 侧（发起与渲染）**

1. `crates/astra-cli/src/main.rs:18` — `astra_cli::entrypoint::run()`：进程入口（此前已先执行 sandbox supervisor 与 build_info 探针）。
2. `crates/astra-cli/src/entrypoint.rs:115` → `cli/cli_args.rs:152` 的 `Command` 枚举（33 个变体）解析；`-p`/`-c/-r` 在 `entrypoint.rs:387/409` 提前短路。
3. `crates/astra-cli/src/cli/command_router.rs:858` `execute_cli_command_impl` → `:1353` `Chat` 分支。
4. `crates/astra-cli/src/cli/turn/turn_facade.rs:303` `execute_basic_cli_turn`：组装 CLI 侧 host/state（本地 `edge_tools` 执行器、审批 sink、journal）。
5. `crates/astra-cli/src/cli/chat_stream/sse_loop/mod.rs:208` `stream_chat_sse`：**Server-owned admission** 模式——CLI 每轮通过 thin-client 发起请求，循环体本身复用 astra-runtime 的 `run_agentic_loop_with_host`。
6. `crates/astra-cli/src/cli/chat_stream/agentic_loop_turn.rs:1652`（429/传输错误指数退避重试，见 `crates/astra-thin-client/src/client.rs:1230` `post_developer_loop_retry_429`）→ POST `/chat/stream`。
7. SSE 事件经 `crates/astra-cli/src/cli/stream/stream_render.rs:7858` `consume_turn_sse` 回调式消费：增量文本渲染、工具卡片、审批请求入 `tui/approval` 的 `ApprovalQueue`（oneshot+mpsc，用户按键后 `post_approval` 回传）；**若无可达审批 sink 或授权缺失，一律 fail-closed 拒绝**（`stream_render.rs:3404`）。
8. 终答组装 `build_stream_result` → 会话日志/`journal` 持久化；崩溃/断线后经 `cli/session/session_startup.rs:668` `complete_session_startup` + `tui/chat_widget/resume.rs:12` 恢复。

**② Server 侧（请求主干）**

9. `crates/runtime/src/server/chat_handlers.rs:301` `chat_stream_handler`：路由入口（SSE）。
10. `chat_handlers.rs:262` `current_principal_for_request` → `crates/services/src/auth/mod.rs:2102`：JWT 验证 + 会话活性校验。
11. `crates/services/src/auth/session_quota.rs:13`：会话配额准入。
12. `resolve_or_create_chat_session`（`crates/services/src/auth/session.rs:468` `create_session`：fence + INSERT + `log_session_audit`）→ `crates/services/src/run/engine.rs:1128` `insert_run` → `crates/services/src/runs.rs:11087`（`admit_session_scoped_run_write` + `FOR UPDATE` + INSERT `agent_runs`/`agent_run_events`）。
13. `crates/runtime/src/server/run/lifecycle/mod.rs:14359` `stream_chat`：持久化 Run 起点 + owner lease；构建 host（`RuntimeToolExecutor`）并 spawn `agentic_loop_stream_chat` 任务，立即返回 `event_rx` 给 SSE 编码器（`crates/runtime/src/server/http_helpers.rs:258`）。
14. 后台先 `acquire_run_permit`（并发闸门，默认 50）→ `crates/runtime/src/turn/agentic_loop/host.rs:4318` `run_agentic_loop_impl`：循环 `prepare → execute_turn_and_ingest → tool_phase`。

**③ Turn 内部（模型与工具）**

15. `crates/runtime/src/turn/agentic_loop/server_loop_host.rs:11823` `ServerAgenticLoopHost::execute_turn`：三级节流（本地冷却 → `llm_provider_admission` DB 固定窗口+TAT → 请求内墙钟预算）。
16. 上下文装配（Context Pipeline，两遍 Plan）：`crates/astra-turn-core/src/context/session.rs:294` `PipelineSession::run_turn_adaptive` → `planner.rs:68` `plan_turn` → bind → optimize → serialize（预算三阈值 0.60/0.75/0.90 选档、KV-cache 标记布局）。
17. `crates/astra-turn-core/src/agentic/stream_host.rs:458` `consume_sse_stream_cancellable` → `dispatch/apply_one_event` → `:1285` `flush_pending_via_host`（**审批事件先于工具执行的不变量**）。
18. 模型调用：`crates/runtime/src/turn/llm/client.rs:4682` 统一重试环——**先写 durable 推理台账（`inference_invocations`）再发 reqwest**；Bedrock 走 eventstream。
19. 模型返回工具调用 → `crates/astra-turn-core/src/permission/engine.rs:407` `evaluate_permission`（14 槽冻结判定序，纯函数，全程 trace）→ NeedExternal 时经审批门（CLI 场景投递到 TUI ApprovalQueue）。
20. 工具执行：`crates/runtime/src/server/runtime_tool_executor`（ToolExecutionService）路由：
    - **LocalRoute**（CLI 场景）：`execute_local_route:956` → 下发回 CLI → CLI 本地 `edge_tools` 在 `astra-sandbox` 边界内执行（`astra-tools/src/lib.rs:275` `ToolExecutor::execute` 四段式：准入→互斥租约→执行→结算/脱敏/64KB 截断）→ `post_tool_result` 回传。
    - **EdgeBound**：见场景二。
21. 并行工具轮：`crates/astra-turn-core/src/parallel_tool_exec.rs:298` `execute_parallel_round`（全进程信号量限并发）→ headless/assembly 配对回填。
22. ingest 判定：`crates/astra-turn-core/src/agentic/turn_ingest.rs:99`（Break/Continue/Fatal/HasToolCalls）——**只有无工具调用的纯文本才是终答**（`turn_ingest.rs:161-166`）。
23. 终态提交：会话日志管理器 `persist_turn`（`crates/astra-turn-core/src/conversation_log/manager.rs:174`）+ `crates/services/src/runs/persistence.rs:255` + `session_journal.rs:2451` CAS 提交 → 事件异步入 `agent_events`（`services/src/event_ingestion`）→ 审计/Trace/Explain DAG。

### 7.2 场景二：Server + Edge——工具在用户 Runner 执行（Web 发起）

Server 侧 1-18 步与场景一相同（发起方换为 Web，见场景三），差异在工具路由与 Edge 协议：

1. `ToolExecutionService` 判定 EdgeBound → `crates/runtime/src/server/tool_edge_transport.rs:19` `execute_edge_bound`：**先 `insert_dispatch` 落库（`edge_pending_dispatch`）再经 WS `/edge/ws` 下发**。
2. `crates/astra-edge/src/main.rs:1091` select 循环收到 ToolRequest → `:1111` 授权校验（`runtime_process_authorization` 注入受控 env）→ `:1130` `journal.prepare` 三态判定（Replay/Active/Execute，由 `delivery_generation` 代际号驱动幂等）。
3. `:1231` spawn `execute_with_cancel` 本地执行 → `:1319` `journal.complete`（**结果先落 durable outbox**）→ `:1342` WS 回发 → Server `/tools/result` 回调 → `:1280` 收到 `ToolResultAck` 后才删除 outbox 条目；断线重连先重放未 ACK 结果。
4. 并发由 128 信号量限制；心跳 Ping 维持；`interaction_api_major` 协议校验不符即永久退出（fail-closed）。

### 7.3 场景三：Web 控制台聊天流

1. `web/components` Composer 提交 → `web/hooks`（`use-stream-lifecycle.ts:631` `startStream`）→ `web/lib/api/chats.ts:763` `streamChatMessage`。
2. POST `/api/chats/{chatId}/stream`（`web/app/api/chats/[chatId]/stream/route.ts:510`）：`requireRuntimeUser` 校验 httpOnly cookie 会话（浏览器永不见 token）→ `WebRuntimeClient` 附加 `Authorization: Bearer` + `X-User-Id`（JWT sub）转发到 Server `/chat/stream`（401 自动 refresh+重放）。
3. `beginStreamingMessage` + `ensureChatBackendSession` + `fetchResponse` 建立 SSE → `proxyRunStream` 双路（转发给浏览器 + 镜像写内存 store）。
4. 前端 `consumeChatStream/applyStreamEvent` → `assistantPatcher`（requestAnimationFrame 批量打补丁）→ `MessageBubble` 渲染。

### 7.4 时序图（场景一 + Edge 分支）

```text
用户      astra CLI         astra-server(runtime)      services/MatrixOne     LLM提供商     astra-edge
 │  chat -m │                      │                        │                  │              │
 ├─────────▶│ entrypoint::run      │                        │                  │              │
 │          │ command_router(Chat) │                        │                  │              │
 │          │ execute_basic_cli_turn (组装host+审批sink)      │                  │              │
 │          │ stream_chat_sse ────POST /chat/stream─────────▶│                  │              │
 │          │                      │ chat_stream_handler     │                  │              │
 │          │                      ├─JWT验证+配额+会话──────▶│ auth/session_quota/create_session   │
 │          │                      ├─insert_run(CAS)────────▶│ agent_runs/events│              │
 │          │                      │ spawn agentic_loop ◀─event_rx               │              │
 │          │                      │  ├ Context Pipeline 装配(预算/cache布局)    │              │
 │          │                      │  ├ provider准入(窗口+TAT)                   │              │
 │          │                      │  ├ 推理台账落库────────▶│ inference_invocations            │
 │          │                      │  ├ call_llm ──────────────────────────────▶│              │
 │          │                      │  ◀─ 工具调用(tool_call) │                  │              │
 │          │                      │  ├ evaluate_permission(14槽)                │              │
 │          │ [NeedExternal]◀─审批请求(SSE)                  │                  │              │
 │◀─审批卡片─│ ApprovalQueue        │                        │                  │              │
 │──批准───▶│ post_approval ──────▶│                        │                  │              │
 │          │                      │  ├ LocalRoute: 下发回CLI本地执行(sandbox边界) │              │
 │          │                      │  └ EdgeBound: insert_dispatch──▶edge_pending_dispatch      │
 │          │                      │    WS ToolRequest ───────────────────────────────────────▶│ journal.prepare
 │          │                      │                        │                  │   本地执行     │ execute_with_cancel
 │          │                      │                        │                  │   outbox落库   │ journal.complete
 │          │                      │  ◀─ /tools/result ────────────────────────────────────────│ WS回发
 │          │                      │    ToolResultAck(清outbox)                 │              │
 │          │  ◀═ SSE: delta/工具卡片/usage ═╗             │                  │              │
 │          │ consume_turn_sse 渲染 │                        │                  │              │
 │          │                      │  无工具调用→终答(ingest判定)                │              │
 │          │                      │  persist_turn+CAS终态─▶│ runs/journal/audit│             │
 │◀─回答+Explain DAG───────────────│                        │                  │              │
```

（实线=同步调用/请求，══=流式事件，虚线省略；行号见 §7.1-7.3 与 §7.5 各层明细。）

### 7.5 各层调用链明细

以下为各批次分析产出的函数级链路素材（含行号），按层排列。


**7.5.1 Turn 编排核心（astra-turn-core）**
#### 调用链素材：一条用户消息在 astra-turn-core 内的函数级路径

（标 ★ 的是库内纯函数/入口；宿主 while 循环在 astra-runtime/CLI，此处列库内函数。）

**阶段一：收到用户消息 → 模型请求发出（Edge 组装 + Server/本地上下文管线）**

1. `view::extract_latest_user_query` — crates/astra-turn-core/src/view.rs:9（提取当前用户查询）
2. `chat_history_openai::build_openai_history` — crates/astra-turn-core/src/chat_history_openai.rs:11（REPL 历史 → messages）
3. `chat_turn_payload::chat_turn_base_payload` — crates/astra-turn-core/src/chat_turn_payload.rs:41（/chat JSON 体骨架）
4. `chat_turn_payload::merge_active_skills_into_edge_profile` / `merge_invoked_skills_into_edge_profile` / `merge_edge_profile_extensions` — 同文件 :124/:138/:153（边缘画像合入）
5. `chat_turn_edge_profile` 系列构建 workspace/技能清单文本 — crates/astra-turn-core/src/chat_turn_edge_profile.rs（配合 edge_prompt_context.rs）
6. `agentic::prepare_payload::attach_filtered_edge_tools_to_payload` — crates/astra-turn-core/src/agentic/prepare_payload.rs:10（受限过滤后的工具 schema 挂载）
7. `chat_turn_step_plan::record_agentic_step_plan_after_payload_prep` — crates/astra-turn-core/src/chat_turn_step_plan.rs:7（StepRecorder 记 Plan 阶段）
8. ★ 上下文管线（Server 侧或本地双实现）：`pipeline::session::PipelineSession::run_turn_adaptive` — crates/astra-turn-core/src/pipeline/session.rs:294
9. → `context::pipeline::ContextPipeline::run_adaptive` / `run_with_limit_policy` — crates/astra-turn-core/src/context/pipeline.rs:100/:124（abort 门：`RecoveryState::should_abort` recovery_state.rs:58；两遍 Plan）
10. → `context::planner::plan_turn` — crates/astra-turn-core/src/context/planner.rs:68（压力/档位/预算/缓存策略/节清单）
11. → `context::binder::bind_sections`（内部 `bind_all` :32） — crates/astra-turn-core/src/context/binder.rs:59（节→内容）
12. → 回到 10 用实测 token 重 Plan（pipeline.rs:181-193）
13. → `context::optimizer::optimize_with_spill` — crates/astra-turn-core/src/context/optimizer.rs:91（门控变换 + spill）
14. → `context::serializer::serialize_provider_request` — crates/astra-turn-core/src/context/serializer/mod.rs:33（含缓存标记放置 :190/:261）
15. → `PipelineSession::finish_turn_output` — crates/astra-turn-core/src/pipeline/session.rs:335（快照 pending、清孤儿观测）
16. （每轮调用前）`microcompact` 就地清理旧工具结果 — crates/astra-turn-core/src/microcompact.rs（模块 doc :1-14 所述位置）

**阶段二：模型响应流 → 事件解析**

17. ★ `sse::stream_host::consume_sse_stream_cancellable` — crates/astra-turn-core/src/sse/stream_host.rs:458（空闲双档超时 :133/:138；DurableTerminalProbe 字节级终态探测）
18. → `chat_turn_sse_dispatch::ChatTurnSseFramer::push_bytes` — crates/astra-turn-core/src/chat_turn_sse_dispatch.rs:1643（空行分帧 + TTFT）
19. → `sse::stream_host::process_sse_event_block` — crates/astra-turn-core/src/sse/stream_host.rs:1079（agent_live 事件先分发 :1106-1135）
20. → `chat_turn_sse_dispatch::dispatch_chat_turn_sse_event_block` — crates/astra-turn-core/src/chat_turn_sse_dispatch.rs:1568（[DONE] 终止 :1581）
21. → `chat_turn_sse_dispatch::apply_one_event` — crates/astra-turn-core/src/chat_turn_sse_dispatch.rs:677（text/thinking/tool_call/approval_required/tool_request 逐类并入 accum 与 edge_pending；根身份绑定 :684-700）

**阶段三：审批门 → 工具执行**

22. ★ `sse::stream_host::flush_pending_via_host` — crates/astra-turn-core/src/sse/stream_host.rs:1285（CH6-D）
23. → `SseStreamHost::resolve_approval` / `resolve_approvals_batch` — crates/astra-turn-core/src/sse/stream_host.rs:367/:379（宿主洞；库内实现参考 `permission/sync.rs:279 PermissionRequestHandler::handle_request`）
24. ★ 权限裁决（Edge 执行前置）：`permission::engine::evaluate_permission_with_provider_policy` — crates/astra-turn-core/src/permission/engine.rs:407（14 槽；`plan_mode_policy::is_plan_mode_blocked_tool` plan_mode_policy.rs:71 在 Mode 槽被引用 :863）
25. → `approval::sink::ApprovalSink::resolve` — crates/astra-turn-core/src/approval/sink.rs:75（映射回 HardDecision；无交互面走 `HeadlessFailClosedSink::resolve` :106）
26. → `SseStreamHost::execute_tools_batch` — crates/astra-turn-core/src/sse/stream_host.rs:411（宿主洞）
27. → `parallel_tool_exec::execute_parallel_round` — crates/astra-turn-core/src/parallel_tool_exec.rs:298（`shared_tool_semaphore` :70 全进程信号量、`partition_tool_calls` :234 读写分区、sibling-abort）
28. （流中投机）`streaming_tool_exec::should_speculate` — crates/astra-turn-core/src/streaming_tool_exec.rs:57（只读+权限未知/Approve 才投机）
29. （每工具钩子）`tool::policy::hooks::ToolHookRegistry::run_pre/run_post` — crates/astra-turn-core/src/tool/policy/hooks.rs:218/:248

**阶段四：结果回填 → 下一轮请求**

30. `headless::assembly::canonicalize_provider_tool_batch` — crates/astra-turn-core/src/headless/assembly.rs:101（server tool_calls 与 edge 行对齐配对）
31. → `headless::assembly::take_edge_output_for_tool_call_with_duration` — 同文件 :384（按 call_id 或签名取 edge 输出；无匹配合成 `no_matching_edge_execution` 错误消息 :417）
32. → `headless::assembly::headless_*_openai_pair` 系列幂等/未知工具配对 — 同文件 :269-:287
33. → `chat_turn_payload::set_payload_tool_results_if_non_empty` — crates/astra-turn-core/src/chat_turn_payload.rs:237（canonical_tool_result_wire_row :187 fail-closed 规范化）
34. （策略整饰）`tool::result::sanitize` / `compression` / `dedup` — crates/astra-turn-core/src/tool/result/（进 payload 前的最后加工）
35. 回到阶段一第 6 步（下一轮 payload），上下文侧回到第 8 步

**阶段五：循环控制 → 回合完成**

36. ★ `agentic::turn_ingest::ingest_agentic_turn_stream` — crates/astra-turn-core/src/agentic/turn_ingest.rs:130（CH6-A；Break/Continue/Fatal/HasToolCalls）
37. → `agentic::turn_flow::agentic_round_stall_preflight` — crates/astra-turn-core/src/agentic/turn_flow.rs:14 → `agentic::stall_preflight::apply_cli_agentic_stall_preflight` — 同目录 stall_preflight.rs:30（sig_stall/repetition_threshold 证据）
38. → `agentic::post_tool_policy::apply_agentic_post_tool_policy` — crates/astra-turn-core/src/agentic/post_tool_policy.rs:85（TurnGuard 观测 + checkpoint + advisory）
39. → `response_guard::apply_response_guards` — crates/astra-turn-core/src/response_guard.rs（终答守卫，由 36 在 :172 调用）
40. → `complete::TurnCompletionFacts::build_turn_complete_event` — crates/astra-turn-core/src/complete.rs:34（完成事件）
41. → `turn_event_sink`（中断可恢复增量快照） + `conversation_log::manager::CslManager::persist_turn` — crates/astra-turn-core/src/conversation_log/manager.rs:174（CSL 追加持久化；fork 路径 :346）
42. → `pipeline::session::PipelineSession::record_feedback` — crates/astra-turn-core/src/pipeline/session.rs:456（token/缓存反馈回流 stats，供下一轮 Plan）

**7.5.2 服务器运行时（runtime）**
### 第 7 章调用链素材：一次 `POST /chat/stream` 的完整生命周期

（函数名 + file:line，按执行顺序；`crates/runtime/src/` 前缀省略）

**A. HTTP 接入与认证**
1. `main::run`（main.rs:17）→ `serve(addr)`（server/mod.rs:251）：状态已由 `build_server_state`（server/state_builder.rs:20）装配，`axum::serve` 接收连接。
2. `request_trace::request_trace_middleware`（server/request_trace.rs）分配/透传 `x-request-id`。
3. `chat_stream_handler`（server/chat_handlers.rs:301）被路由（server/router_builder/realtime.rs:115）。
4. `AuthService::current_principal_for_request`（astra_services::auth，经 server/chat_handlers.rs:312 调用）——JWT/edge token/外部 provider 多路认证；请求描述符由 `external_request_descriptor`（server/mod.rs:94，含 body sha256）提供重放防护。

**B. 会话/上下文准备（HTTP 线程内）**
5. `parse_chat_request_body`（chat_handlers.rs:9）。
6. `resolve_or_create_chat_session`（chat_handlers.rs:149）：已有 session 校验归属；否则 `create_session_with_resource_quota`（server/session/session_quota.rs）建会话；读取 `full_llm_capture` 开关（turn/llm/exchange_capture.rs）。
7. `validate_conversation_authority`（chat_handlers.rs:19）：客户端带授权信封时做 lease+grant 签名+head cursor 三重 fencing（409 拒绝）。
8. `inject_effective_runtime_context`（server/provider_runtime_context.rs）注入有效 runtime 上下文。
9. `AgenticRunLifecycleService::stream_chat`（server/run/lifecycle/mod.rs:14359）：
   - `require_invocation_composition` + `run_start_idempotency`（幂等键）+ `prepare_chat_request` + `validate_request_constraints`（:14364-14395）；
   - ResourceGovernor `check_run_start`（:14400-14406，用户级 run 配额）；
   - `load_active_personal_skills`、`validate_work_runtime_binding`、`extract_edge_context`、`prepare_runtime_capabilities`（:14435-14451，含请求级 MCP bundle）；
   - `persist_run_start`（ClaimOrReplay/Insert 两种模式，:14473-14519/15327-15363）——**durable run 先落库再执行**；`confirm_execution_authority` + `start_owner_lease_heartbeat`（run/engine.rs，owner 租约防多副本双跑）；
   - `provision_cloud_workspace_record` / `provision_persisted_server_workspace`（run/cloud_workspace_provisioning.rs / workspace_provisioning.rs）；
   - `prepare_canonical_turn`（:15003，canonical turn 准入：prior messages + cursor 预留）、`build_initial_state_inner`、CSL/step-checkpoint 历史恢复（:15122-15181）、plan resume；
   - `build_host`（:15187→server/server_loop_host.rs `ServerAgenticLoopHostBuilder::build`:3433）；
   - 建事件通道：`event_tx`(mpsc) + `live_tx`(broadcast) + 持久化 fanout 任务（"sse_fanout"，:14982——**每个 live 事件先落 run_events delta 再投递**）+ host_event_bridge（容量 256 + gap 追踪，:15208-15262）；
   - `DurableHostInteractionSink`（lifecycle/mod.rs:14990）作为审批/追问的 durable 汇；
   - 交互客户端时建 `DurableRunApprovalGate`（:15683）与 `DurableRunUserPromptGate`（:15701，兼 ProviderInteractionGate），通道挂入 service；
   - `RuntimeToolExecutor::new(...).with_*`（:15511-15762）：工作区、tool_execution_service（共享 ToolExecutionService 或按部署策略构建）、MCP manager、work 绑定、artifact store、plan repo、invocation ledger、审批/追问门、进度回调——`wire_executor_into_state`；
   - `spawn_observed("agentic_loop_stream_chat")`（:15819，带后台任务计数 guard）→ **HTTP 线程返回** `Ok(ChatStreamRecord{ session_id, run_id, event_rx })`（:16902）。

**C. SSE 回传面（与 D 并行）**
10. `sse_streaming_response`（server/http_helpers.rs:230）→ `sse_projected_streaming_response`（:258）：首帧 `session_info`，随后循环 select {event_rx.recv → `transform_stream_run_events_for_client_with_pending`（run/handlers.rs）投影 → `data: {json}\n\n`；心跳 ping；终端宽限 5s 合成 `run_finished` }。

**D. 后台 agentic loop（spawn 任务内）**
11. `persist_turn_start`（PostLoopPersistContext，:15840）→ `acquire_run_permit_with`（:15854，全局 FIFO 信号量，默认 50——多用户公平边界；取消/超时有完整终端清理路径）→ ResourceGovernor `check_token_budget`（:15973）→ `install_server_root_mailbox` + `start_active_run_control_watcher`（:16023-16038，watch /pause /cancel /intents）。
12. `run_agentic_loop_with_host_panic_safe`（lifecycle/mod.rs:3131，catch_unwind 包装）→ `run_agentic_loop_with_host`（turn/agentic_loop/finalization.rs:490）→ `run_agentic_loop_impl`（turn/agentic_loop/host.rs:4318）：
    - `run_loop_preamble`（agentic_loop/lifecycle.rs:3446）→ harness SessionStart；
    - 循环：`prepare_turn_iteration`（lifecycle.rs:3663）→ `execute_turn_and_ingest_phase`（agentic_loop/execution_phase.rs）→（harness PostLlmResponse / PreToolBatch）→ `execute_tool_phase`（agentic_loop/tool_phase.rs:1883）→ `complete_turn_phase`（host.rs:309）。
13. **单回合 LLM**：`ServerAgenticLoopHost::execute_turn`（server_loop_host.rs:11823）：
    - `resolve_llm_config_for_state`（:6182，模型/fallback/凭据）+ `rate_limit_cooldown().check_request`（:11934）；
    - `memory_context_for_turn` → `run_turn_pipeline_with_model_limits_and_session_memory`（:12136，经 turn/context_pipeline_adapter.rs 进 astra-pipeline）→ `compact_messages_via_memoria`（:12196，turn/cloud/memoria_compact.rs）→ `assemble_llm_messages`（:12344，turn/wire_assembly.rs）；
    - `llm_provider_admission::admit_llm_provider_request`（server_loop_host.rs:12585→llm_provider_admission.rs:559，DB 窗口+TAT）；
    - `turn::llm::client::call_llm_and_collect_with_total_budget`（turn/llm/client.rs:4682）：`observer.begin_attempt`（turn/llm/durable.rs 写推理台账）→ `global_llm_client().post(url)`（client.rs:4974-4998，select 取消/超时）→ Bedrock 走 `turn/bedrock/transport::collect_bedrock_stream_for_wire`（:5086），其余解析 SSE；流片段经 stream_callback → host `emit_*` → `event_tx` → C 步 SSE；`token_usage` 聚合（turn/token_usage.rs）。
14. **工具执行**（tool_phase 内，经 `admit_tool_calls` 准入后）：
    - 服务端工具：`RuntimeToolExecutor`（server/runtime_tool_executor.rs:543，impl `ToolExecutor`:4192）→ 内建表（runtime_tool_executor/tool_handlers.rs）或 `tool_file_runtime`/`server_bash_execution`（沙箱经 astra-sandbox，main.rs:8 的 invocation supervisor 即其子进程模式）；
    - 统一分发：`ToolExecutionService::execute_with_cancel`（server/tool_execution_service.rs:552）→ `routing_decision`（:486）→ `execute_with_route_and_cancel`（:584：runtime_process/edge_dispatch 授权检查、`authorize_tool_request`:863 能力校验、disabled_tool_offers 策略）→ 按路由：
      - `ServerLocal/ServerControlPlane/ServerRuntime/RequestScopedMcp` → `execute_local_route`（:956→local_transport=RuntimeToolExecutor；MCP 经 runtime_mcp.rs 的 manager）；
      - `GatewayRelay` → `tool_external_transport.rs` ExternalTransport；
      - `EdgeBound` → `execute_edge_bound`（server/tool_edge_transport.rs:19）：先 `EdgeDispatchService.insert_dispatch`（durable admission）再 `EdgeConnectionPool` 发 `ToolRequest`（WS），`wait_result` 等待（默认 300s）；结果由边缘代理 `POST /tools/result`（server/edge/edge_callback_handlers.rs:248 `post_tool_result_handler`）或 WS 回包交付；
    - 审批类工具：`DurableRunApprovalGate`（lifecycle/mod.rs:2054，impl ToolApprovalGate :2373）落库等待，`POST /approval/respond` 回调解决；ask_user 同理（:2668）。
15. **落库与终局**：循环退出 → `persist_settlement_started`（:16044）→ `host.settle_loop_turn`（server_loop_host.rs:7293）→ `finalize_run_events`（:16125）→ 终态 CAS 持久化（run/lifecycle/persistence.rs）+ 事件经 durable fanout 补投（`DURABLE_EVENT_COMMITTED_FIELD` 防重复审计，:16219）→ `schedule_post_loop_memory_cleanup`（:16869，session_memory/service.rs 后台记忆提取）→ 云工作区清理（:16881）→ `event_tx` drop → SSE 收尾（客户端收到 `run_finished`）。
16. **断线重连**：`GET /chat/runs/{run_id}/stream` → `stream_run`（lifecycle/mod.rs:17056）→ `stream_run_live`（:17071）从 durable run events 增量补发（last_index 游标），live broadcast lane 并行接续。

**非流式对照**：`POST /chat` → `create_run`（lifecycle/mod.rs:12669）同套准备后在 13677 行 `run_agentic_loop_with_host_panic_safe` 同步跑完再返回 run 记录；`GET /chat/runs/{id}` 轮询 `get_run_status`（:16910，直读 durable 快照）。

**7.5.3 持久化服务层（services）**
调用链素材（HTTP 请求 → services 层，函数名 + file:line；路径省略 `crates/` 前缀）：

**组装前置**（一次性）：
- `state_builder/core.rs:25-26` `DatabaseAuthService::new(...).with_pool(shared_pool)`；`core.rs:109` SessionService、`core.rs:124-125` ModelService、`core.rs:150` Replay、`core.rs:153` SessionAudit 等 30+ 服务注入 → `app_state.rs:159/176` `AppState { run_lifecycle_service, auth_service, ... }`。

**典型聊天请求链（POST /sessions/{id}/runs 或 /chat）**：
1. 认证：`runtime/src/server/chat_handlers.rs:262-263` `state.auth_service.current_principal_for_request(headers, descriptor)` → `services/src/auth/mod.rs:2220` `DatabaseAuthService::current_principal_for_request` →（边缘令牌）`principal_from_edge_token`（auth/mod.rs:1417）/（JWT）`current_principal`（auth/mod.rs:2102）→ `decode_jwt_claims`（auth/jwt.rs:21）→ `refresh_session_is_active`（auth/mod.rs:1256，SQL 查 auth_refresh_tokens）→ `fetch_user_by_id_or_username`（auth/mod.rs:870）。
2. 会话创建（若无会话）：`chat_handlers.rs:189` `create_session_with_resource_quota`（`runtime/src/server/session/session_quota.rs:13`）→ `resource_governor.rs` `check_session_create`（限额）→ `services/src/auth/session.rs:468` `DatabaseSessionService::create_session`：`storage.rs:1385 lock_agent_session_write_fence` → `INSERT INTO agent_sessions`（auth/session.rs:486）→ `storage.rs:8968 log_session_audit("session_create")`（INSERT auth_audit_logs，best-effort）。
3. Run 启动：`runtime/src/server/run/engine.rs:1030 start_run` → `start_run_ext`（:1055）→ `:1128 self.store.insert_run(record)` → `services/src/runs.rs:5622 DatabaseRunStateStore::insert_run` → `:11087 insert_run_record`：补全 lineage（11100-11108）→ `storage.rs:1161 admit_session_scoped_run_write`（事务内会话准入）→ `:11170 SELECT ... FOR UPDATE` 锁 run 身份 → `:11239/:11373 INSERT INTO agent_runs` → `:10545 insert_run_event_rows_tx`（INSERT agent_run_events，10555）→ `:10505 run_display_projections` 投影。
4. Turn 持久化（agentic loop 内）：`runtime/src/server/run/lifecycle/persistence.rs:255 persist_turn_start`（不可变根 turn 先行落库）→ 本地 journal：`services/src/session_journal.rs:2929 TurnEventBuffer::begin_turn` + `:3212 flush` → `JournalWriter::append_bulk`（:2402）/canonical 提交 `append_canonical_commit_cas`（:2451，持 `SessionExecutionLease`）；云端：`event_ingestion.rs:634 IngestionSender` 异步摄入 `agent_events`（`storage.rs:508` DDL）+ `agent_event_edges`（`storage.rs:1480`）。
5. 审计落库：每 turn 事件经 runs.rs 事件行（agent_run_events）+ `storage.rs:8968 log_session_audit`（会话生命周期动作）+ `session_audit.rs` 云侧查询视图（`TurnSummary` 等，session_audit.rs:2422+）；工具调用另有 `tool_invocation_ledger.rs:80 DatabaseToolInvocationLedger`（tool_invocation_ledger 表，CAS）。
6. 模型调用支线：`models.rs:1456 resolve_active_llm_model`（infra/user_llm_models + 缓存）→ `runtime/src/turn/llm/client.rs:4910` `astra_services::byok_endpoint::endpoint_client(&url)`（BYOK 安全出口）→ 推理持久化 `inference_execution.rs`（inference_invocations / inference_provider_attempts）。

**7.5.4 交互层（astra-cli / astra-edge）**
调用链素材（函数名 + file:line）。

**链路 A：`astra chat -m "..."` 一次性命令（main → thin-client 请求 → SSE 渲染）**

1. `astra_cli::main` — crates/astra-cli/src/main.rs:18 → `output_sink::configure_process_output_signals` — main.rs:12（output_sink.rs:35 SIGPIPE）
2. `entrypoint::run` — entrypoint.rs:115 → `run_async` — entrypoint.rs:125
3. `Cli::try_parse` — entrypoint.rs:136；`--settings` overlay — entrypoint.rs:170-217；`ThinClient::new` — entrypoint.rs:233
4. `execute_cli_command` — command_router.rs:752（Box::pin）→ `execute_cli_command_impl` — command_router.rs:858
5. `Command::Chat` 分支 — command_router.rs:1353：墙钟预算 `ExecutionTimeBudgetClock::new` — command_router.rs:1359-1365（常量 :63-74）；消息取自 `-m` — :1394
6. `fresh_access_token_or_error` — command_router.rs:95（→ session_runtime::fresh_access_token）
7. `resolve_one_shot_session_routing` — command_router.rs:1432（实现 one_shot_session_routing.rs；恢复模型/权限/续跑消息）
8. `RequestSessionExecutionLease::new` — command_router.rs:1452（session/session_execution_lease.rs；首个 SSE 帧绑定会话身份）
9. `resolve_one_shot_model` — command_router.rs:1478
10. `crate::cli::turn::execute_basic_cli_turn` — command_router.rs:1629（turn_future）→ turn/turn_facade.rs:303
11. `stream_chat_sse(params)` — turn_facade.rs:333（重试 :355）→ chat_stream/sse_loop/mod.rs:208
12. 模型/上下文解析：`resolve_server_default_model` — sse_loop/mod.rs:215、`resolve_server_model_selection` — :246（session_runtime.rs）
13. `edge_tools::ToolExecutor::new(...).with_cloud(...)...` — sse_loop/mod.rs:356-459
14. `CliServerAdmissionHost` 组装 — sse_loop/mod.rs:696；`AgenticLoopState` — :818
15. `run_agentic_loop_with_host` — sse_loop/mod.rs:1129（astra-runtime::turn::agentic_loop::finalization）
16. host `execute_turn` — server_admission_host.rs:649 → 宏 `fetch_turn_sse!` — :821-907
17. `fetch_chat_turn_sse` — agentic_loop_turn.rs:1673 → `chat_turn_post_payload_after_prepare` — :1591
18. `prepare_chat_turn_payload` — agentic_loop_turn.rs:674（上下文组装/技能/schema 剪枝）
19. **HTTP 发出**：`api.post_developer_loop_retry_429` — agentic_loop_turn.rs:1652 → astra-thin-client/src/client.rs:1230（POST `paths::CHAT_STREAM` = `/chat/stream`，client.rs:1191）
20. **SSE 接收渲染**：`consume_turn_sse` — agentic_loop_turn.rs:1878 → stream/stream_render.rs:7858 → `CliSseStreamHost::from_edge_ctx_with_auth` — stream_render.rs:1427 → `consume_sse_stream_cancellable` — stream_render.rs:7917；事件回调 `on_accepted_sse_event` — :3776；token 渲染 `push_text` — :1756 / streaming_md；TTFT spinner（effects/ttft_spinner.rs）
21. 本地工具回调：`execute_tool` — stream_render.rs:4139（`execute_with_metadata_responsive` — :7593 → edge_tools ToolExecutor）→ `finish_edge_tool` — :1855 → `post_tool_result_with_auth_retry` — :1628（client.rs:1837 `post_tool_result`）
22. 结果回填：`build_stream_result` — agentic_sse_loop.rs:284（stream_render.rs consume 返回 TurnResult → sse_loop/mod.rs:1322）→ StreamResult
23. 结算：`finalize_one_shot_stream_result_with_request_lease` — command_router.rs:2913（`persist_headless_session_state` — command_router.rs:201：`append_one_shot_journal_events` — session/session_side_effects.rs）；stream-json 输出 `StreamJsonEmitter::emit_result` — command_router.rs:2882
24. 退出码：`ExitCode` → main.rs:22 `resolved_exit_code`（output_sink.rs:62）

**链路 A′：会话恢复（-c/-r 及 TUI resume）**

- `-c`：`validated_resumable_last_session_id` — entrypoint.rs:417（cli_utils.rs，经 /sessions 校验）→ 本地 `local_resumable_last_session_id` 兜底 — entrypoint.rs:422
- → `run_interactive_chat` — interactive_chat.rs:10 → `tui::run_tui`（`run_tui_session` — event_loop.rs:4902）
- → `complete_session_startup` — session/session_startup.rs:668（`SessionStartupArtifacts` :29；内部走 `HybridRestoreService::restore_local_session`/云端 `restore_session_snapshot_with_client` — session/session_restore_client.rs，journal-only 降级路径见 entrypoint.rs 测试 :1293-1358）
- TUI scrollback 重建：`chat_widget::resume::load` — tui/chat_widget/resume.rs:12（读 canonical append-only transcript lane）
- checkpoint 恢复/回滚：`session_recovery/checkpoint.rs:99 load_previous_recovery_state`、`:341 rollback_recovery_checkpoint`

**链路 B：Server → Edge 下发工具调用 → 本地执行 → 结果回传（astra-edge）**

1. Server 经 `/edge/ws` WebSocket 推 `EdgeServerMessage::ToolRequest{request_id, identity, delivery_generation, tool, args, runtime_process_authorization?, timeout_secs}`
2. `run_edge_connection` select 读分支 — astra-edge/src/main.rs:1093；严格解码 `decode_edge_server_message` — :173（未知字段拒绝）
3. `valid_runtime_process_authorization` — :160（调用处 :1111，fail-closed）
4. `EdgeExecutionBudget::try_acquire` — :58（调用处 :1129，Semaphore(128)）
5. `EdgeInvocationJournal::prepare` — :1130（invocation_journal.rs；三态 Replay/Active/Execute）
6. `EdgeInvocationTracker::begin` — :1206（:211，代际 CancellationToken）
7. `tokio::spawn` 执行 — :1217：`astra_tools::ToolExecutor::execute_with_cancel` — :1231 或 `runtime_process_authorization::execute_bash` — :1224（runtime_process_authorization.rs，注入 `MOI_RUNTIME_AUTHORIZATION` env）；`tokio::select!` 取消/超时 — :1239-1251
8. 完成事件经 mpsc `completed_tx` — :1258 → 主循环 `completed_rx.recv()` — :1310
9. `journal.complete(...)` 先落 durable outbox — :1319；`journal.pending_results()` 取回 — :1334
10. `DurableEdgeResult::client_message` 回发 `EdgeClientMessage::ToolResult` — :1337-1342（经同一 WS write 半部）
11. Server 回 `ToolResultAck` → `journal.acknowledge` — :1280（确认后出队）；`ToolCancel` → `cancel_if_current` — :1264
12. 心跳：`heartbeat.tick()` → `EdgeClientMessage::Ping` — :1344-1350；连接断开 → main 重连循环 — :1401-1451（`swap_to_fallback` 令牌兜底 — :1423）

**7.5.5 Web 与 SDK（web / packages/sdk）**
**调用链素材：聊天页输入消息 → 后端 → SSE → 渲染**

1. 用户在 `Composer`（web/components/app/composer.tsx）编辑 contentEditable，Enter 提交 `onSubmit({text, attachments, options})`。
2. `ChatView.handleSubmit`（web/components/app/chat-view.tsx）→ `useStreamLifecycle.startStream({text, options, appendUser:true})`（web/hooks/use-stream-lifecycle.ts:631）。
3. `startStream` 乐观插入 user+streaming assistant 消息（648-721 行）→ 调 `streamChatMessage(chatId, payload, handlers)`（web/lib/api/chats.ts:763）。
4. `streamChatMessage` `fetch POST /api/chats/{chatId}/stream`（JSON body，AbortSignal）。
5. `POST` handler（web/app/api/chats/[chatId]/stream/route.ts:510）：`requireRuntimeUser`（web/lib/api/auth-guard.ts:13）→ `getChat`/`beginStreamingMessage`（web/lib/api/web-store.ts:954）→ `proxyRunStream` → `backendResponse` 回调内 `requireRuntimeClient({auth:"required"})`（web/lib/runtime-client/server.ts:272）→ `verifyLiveWorkspaceSelection`（web/lib/workspace-selection-server.ts）→ `ensureChatBackendSession`（web-store.ts:1770，必要时 `POST /sessions`）→ `resolveModelOfferingSelection`（web-store.ts:2661）→ `runtime.fetchResponse(PATH_CHAT_STREAM="/chat/stream")`（server.ts:127，带 Bearer JWT + X-User-Id）。
6. 后端 Axum `/chat/stream` 返回 SSE：`session_info/run_started/text_delta/reasoning_delta/tool_call_*/approval_required/.../turn_complete/run_finished`（事件类型清单见 packages/sdk/src/types.ts `StreamEventType`）。
7. `proxyRunStream` 读循环（route.ts:371-392）：chunk 双路——`enqueueChunk` 转发浏览器 + `eventFromSseFrame`/`applyStreamEvent`（web/lib/api/stream-event-handler.ts）镜像写 web-store。
8. 浏览器 `consumeChatStream`（web/lib/api/chats.ts:670）分帧 → `parseSseFrame`:261 → `applyStreamEvent`:339 → `handlers.onText/onReasoning`。
9. `onText` → `assistantPatcher.patchBatched`（web/lib/api/assistant-patch-controller.ts，rAF 合帧）→ `setDetail` 更新 `ChatView` 状态。
10. `MessageBubble`（web/components/app/message-bubble.tsx）ReactMarkdown 重渲染正文；`WorkSurfacePanel` 经 `onWorkSurfaceEvent → applyWorkSurfaceEvent`（web/lib/work-surface.ts）更新工具/agent 活动；`run_finished` → `onDone` → 消息置 complete。

**7.5.6 能力层视角（工具 / 技能 / 沙箱）**
### 能力层在"用户消息→模型→工具执行→回复"链路中的位置

链路主线（代码定位均在 `crates/` 下，runtime 与 astra-turn-core 不属于本片段范围，仅给入口坐标）：

1. **进程引导（最早的能力层触点）**：`crates/runtime/src/main.rs:5-11`——main 第一行调用 `astra_sandbox::run_invocation_supervisor_if_requested()`（process_isolation.rs:694）。普通模式置 `SUPERVISOR_ENTRYPOINT_READY=true` 后返回 None 继续；监督器模式则整个进程变为某次 bash 调用的子收割者并 exit（见 4.3.6）。
2. **上下文装配（模型调用前）**：`astra-turn-core/src/context/pipeline.rs:1-4、92、100` 的 `ContextPipeline::run/run_adaptive`（Plan→Bind→Optimize→Serialize→Explain/Metrics）。能力层的输入在这里汇入：astra-prompts 的记忆/团队提示模板、astra-plan 的 `plan_resume_hint_for_session`（astra-plan/src/resume.rs:119，恢复中的计划以系统提示段注入）、astra-skills 的 `SkillResolver::available_skills()`（traits.rs:147，生成 skill 工具 schema）。注意：这段在 turn-core，不在 astra-pipeline crate。
3. **模型返回 tool_calls → 工具执行（能力层主场）**：runtime 的 agentic loop（`crates/runtime/src/turn/agentic_loop/`）把工具调用交给 `RuntimeToolExecutor`（`crates/runtime/src/server/runtime_tool_executor.rs:543`，其内组合 `DefaultToolExecutor`——字段 default_executor:577、构造 for_server_workspace:754、execute:2644、ToolExecutor impl execute:4193/execute_with_cancel:4198）。共享执行入口即 `DefaultToolExecutor::execute`（astra-tools/src/executor.rs:359）与宿主本地 handler 的 `ToolEngine::execute_invocation`（astra-tools/src/tool_engine.rs:246）。沙箱约束在此生效：路径过 `astra_sandbox::validate_path`（path.rs:82）、命令过 `analyze_command_risks_in_workspace`（command.rs:220）、bash 经 `BashInvocationOwner`（process_isolation.rs:223）取得 cgroup/监督器归属。
4. **技能执行**：模型调用 skill 类工具 → `SkillExecutionRouter::execute`（astra-skills/src/executor/isolated.rs:313）路由 inline/isolated；isolated 经 `SkillSubRunExecutor` 递归进入一次子 agent 循环（深度由 recursion_depth 控制）。
5. **执行观测与恢复（贯穿）**：`StepRecorder`（astra-pipeline/src/step_recorder.rs:295）在 agentic loop 各节点记录事件与两级检查点；崩溃后 `recover_from_crash`（astra-pipeline/src/crash_recovery.rs:60）恢复会话；工具结果的健康度进入 `ToolHealthEntry`（tool_health_types.rs:32）反哺下次技能排序（astra-skills/health_ranking.rs:76）。
6. **回复生成**：工具结果（ToolResult.output，已脱敏/截断/带回执 metadata）作为 tool 消息回填对话 → 模型继续，直到无工具调用产出最终回复。取消路径统一为 `cancelled_tool_result`（astra-tools/src/lib.rs:237）的稳定 JSON 信封。

**一句话定位**：能力层占据链路的"模型决策之后、世界状态改变之时"——从 tool_calls 的参数校验、审批、沙箱准入，到副作用执行、执行事实回执与观测记录；并在模型调用之前以提示词/技能/计划三种子系统供给上下文。


---

## 8. 横切机制说明

本章综合各层分析，集中说明错误处理、日志、配置、安全、并发、缓存、定时任务/后台任务的实现位置与方式。§8.9 起为各层明细素材。

### 8.1 错误处理与异常体系

- **错误定义以 `thiserror` 为主**（workspace 依赖 `Cargo.toml:93`），无 anyhow 蔓延；关键设计是**恢复契约**：`astra-runtime-env` 的 `RuntimeError` 携带 `retryable / side_effects / next_action` 三元组，调用方可据其决定重试还是换路（§4.1）。
- **服务层错误未完全统一**（事实）：`services` 中 auth 域返回 HTTP 语义元组，而 runs/work 域仍返回 `String`；`services/src/service_error.rs` 提供了统一入口但尚未全量收编（§4.6，a6 分析指出）。
- **恢复路径是一等公民**：`astra-turn-core/src/error_recovery.rs`、`recovery_state.rs`（PTL 连发 ≥3 中止）、`stall.rs`（停滞检测）与 `astra-pipeline` 的崩溃恢复检查点共同构成"可从崩溃点续跑"的错误面；Edge 侧 journal 三态（Replay/Active/Execute）+ outbox 保证工具结果不丢不重（§4.8.5）。
- **fail-closed 默认**：权限无 sink、MCP 工具名冲突、协议 major 不匹配、headless 审批不可达等场景一律拒绝执行而非静默降级（§4.5、§4.4、§4.8）。

### 8.2 日志体系

- **服务端**：`astra-logging` 提供进程级 tracing 订阅器——TTY 环境自动 pretty、非 TTY 自动 JSON、支持 `RUST_LOG` 过滤、可选 OTLP 导出、**秘密脱敏**（§4.1）；`runtime` 的 `serve()` 以 `OnceLock` 保证全局只初始化一次（§4.7）。结构化日志 + OTel trace 双通道（workspace 依赖 `Cargo.toml:107-118`）。
- **CLI 端输出纪律**：`astra-cli/src/lib.rs:28` 起 `deny(clippy::print_stdout)` 全 crate 禁止裸 `println!`；所有 stdout 输出必须经 `cli/stream/output_sink`（`stdout_print!` 宏，lib.rs:33-47），保证机器可读协议（`--json` 等）与人类输出不互污染，退出码也经 `resolved_exit_code` 归一（`main.rs:22`）。
- **观测平面五件套**：Trace（执行事实）→ Introspect（当前状态）→ Explain（用户投影）→ Reflect（只建议不授权）→ Audit（问责），实现分布在 `runtime/src/observability`、`astra-turn-core/src/{introspect,explain,trace_event,turn_trace_collector}` 与 `services/src/session_audit`（§4.7、§4.5、§4.6）。

### 8.3 配置管理（多环境）

四套配置体系各司其职、优先级明确：

| 体系 | 范围 | 加载顺序（后覆盖先） |
|---|---|---|
| 服务端 `AppSettings` | astra-server 进程 | `.env`（仅 from_env 且未被显式 env 关闭）→ `ASTRA_*` 环境变量；`/etc/astra/server.toml` < `~/.astra/server.toml` < env（`config/server.toml.example:3-6`） |
| CLI 运行时 `RuntimeConfig` | CLI/TUI 进程 | 内置默认 < 用户 TOML < 项目 TOML < `ASTRA_*` env < CLI overlay（`astra-config/src/runtime_config.rs:1995`） |
| 模型目录 `.models.yaml` | 服务端（导入 DB） | 经 `astra admin model load` 落库，运行时读 `infra_llm_models`/`user_llm_models` |
| 凭据 `~/.astra/credentials.json` | CLI 多 profile | `astra-credentials`：旁路锁 + temp/rename 原子写 + Unix 0600（Windows ACL 为显式 TODO） |

开发态安全阀 `ASTRA_ALLOW_INSECURE_DEFAULTS=1`（`.env.example:54`）允许三密钥回退内置弱值，生产强制失败。注意坑：配置在进程内 `cached()` 固化，坏 TOML 仅 warn 降级（§4.1）。

### 8.4 权限/安全控制

安全面按"入口→执行"分层设防：

1. **身份**：JWT 双令牌（access/refresh，jsonwebtoken HS256/384/512）+ bcrypt 口令散列（`services/src/auth`）；弱 JWT 密钥直接启动失败；Web 端 token 全程 httpOnly cookie。
2. **工具权限**：`astra-turn-core/src/permission/engine.rs:407` `evaluate_permission` 单一纯函数裁决器（14 槽冻结判定序、13 种 RiskTag、全程 trace）；`ChildPermissionMode` 在类型级排除 Bypass 防越权传递；Plan 模式是 args 感知覆盖层（`bash git status` 放行、`touch` 拒绝）（§4.5）。
3. **执行边界**：`astra-sandbox` 路径/命令/进程三层边界 + InvocationSupervisor（main 中先于一切运行，`astra-cli/src/main.rs:5`）；`astra-tools` 四段式执行契约（准入→互斥租约→执行→结算核验）（§4.3）。
4. **出口安全（BYOK）**：`services/byok_endpoint` 硬校验端点、直连 DNS 防重绑定、公共 IP 强校验、禁重定向、可选运维代理只送已验证 IP、端到端 TLS；模型密钥 Fernet 加密落库（§4.6）。
5. **信任模式**：`safety.trust_mode` 只允许操作员在启动配置中设置——"Trusted 是运维的信任委托，不是 LLM 的"（`runtime/src/lib.rs:110-120` 注释即约束）。
6. **限流准入**：LLM 提供商三级节流（本地冷却→DB 固定窗口+TAT→请求内墙钟预算，`runtime/src/turn/agentic_loop/server_loop_host.rs:11823`；`.env.example:124-131` 开关）。

### 8.5 并发/异步处理模式

- 全栈 Tokio 多线程；服务端 run 级并发闸门默认 50（`acquire_run_permit`），工具并行轮用**全进程信号量**而非每批上限（`astra-turn-core/src/parallel_tool_exec.rs:298`），Edge 并发 128。
- **锁纪律**：`OnceLock` 进程单例（日志/信任模式）；`fs2` 跨进程文件锁（凭据/配置）；`SessionLatches` 一次性闩锁保 KV 前缀稳定；per-workspace 租约/写者纪元实现工具互斥；锁中毒恢复封装 `rwlock_write_reset_on_poison`（`astra-turn-core/src/lib.rs:93-95`）。
- **终态一致性**：Run/Turn 终态用 CAS（compare-and-set）提交（`services/src/session_journal.rs:2451`、runs 域）；Run 恢复器在启动时收殓孤儿 run（§4.7）。
- **优雅停机**：`serve()` 实现五阶段有序排水——edge WS → run → provider 台账 → sweeper → OTLP（§4.7）。

### 8.6 缓存

- **KV-cache 友好序列化**是 Context Pipeline 的一级目标：Anthropic 系统块只放 1 个 `cache_control`（4 标记预算=1+1+2）、microcompact 占位符按 provider 缓存协议二分、预测压力只升不降（§4.5）。
- **bash 只读缓存 + 部分写失效**：命令判定只读才缓存；`run_script` 仅 `execution_started=false` 可豁免失效（§4.3）。
- **语义读缓存/LRU**：`astra-turn-core/src/semantic_read_cache.rs`、`lru_map.rs`；dedup 缓存由调用方推进 `context_generation` 失效（§4.1 坑点）。
- **服务端容量模型**：`runtime/src/capacity_model.rs` 维护能力/健康状态驱动路由。

### 8.7 定时任务与后台任务

- `serve()` 启动**十余个 sweeper**（清扫器）后台任务（孤儿 run、准入窗口清理、outbox 重投等，`runtime/src/server/mod.rs:251` 起）——这是项目内"定时任务"的标准形态：常驻 tokio 任务 + 周期扫描，而非 cron。
- Edge 心跳（`ASTRA_EDGE_HEARTBEAT_SECS`，默认 120s，`.env.example:218`）；messaging DLQ + ack 重试（`astra-messaging`）。
- 事件异步入库：`services/src/event_ingestion` 把事件写答复与请求解耦。

### 8.8 协议版本治理

Web↔Server 有 `x-astra-agent-interaction-api-major` 握手（不匹配报 `RUNTIME_PROTOCOL_MISMATCH`）；Work API 强制 `x-astra-work-api-major: 1`；thin-client 的 chat 流前置校验 `interaction-api-major=="3"`；所有 wire 类型 `deny_unknown_fields`（加字段即破坏旧客户端）（§4.4、§4.9）。

### 8.9 各层横切机制明细

以下为各批次分析产出的横切机制素材（含行号），按层排列。


#### 8.9.1 基础库层（astra-logging / text-utils / config / runtime-env / credentials）
- **错误处理：边界 thiserror、跨边界结构化**。五个 crate 全部在公共 API 用 thiserror 定义 typed 错误：`OverlayError`/`StoreError`（crates/astra-config/src/config_overlay.rs:36、crates/astra-config/src/config_versions.rs:115）、`JsonPathMutationError`（crates/astra-config/src/json_mutation.rs:6）、`ToolUnavailableReason`/`RuntimeError`/`WorkspaceProvisionError`（crates/astra-runtime-env/src/tool.rs:605、runtime_environment.rs:522、workspace.rs:209）、`CredentialError`（crates/astra-credentials/src/lib.rs:14）。两处刻意例外：astra-logging 的 `InitError = Box<dyn Error + Send + Sync>`（crates/astra-logging/src/lib.rs:92）；治理变更错误带 `to_json()` 直接产出 API 结构化响应（crates/astra-config/src/governed_mutation.rs:99）。**runtime-env 的 RuntimeError 是"恢复契约"而非单纯错误**——携带 retryable/execution_started/side_effects_maybe/next_action（crates/astra-runtime-env/src/runtime_environment.rs:522-530），传输断连类构造器自动标注副作用未定（同文件 579-587）。无效输入 fail 拒绝而非静默：TOML 错误值不 parse（crates/astra-config/src/runtime_config.rs:278）、未知 trust_mode 拒绝（276-278 注释）、frontmatter 之外的无效 trace 类别显式报错（crates/astra-config/src/runtime_config.rs:1539-1541）。
- **日志：tracing 一次安装、stderr、格式自适应**。全局订阅器由 `astra_logging::init_from_env` 进程级安装一次（crates/astra-logging/src/lib.rs:97），统一 `UtcTime::rfc_3339` + stderr writer + 关闭 file/line（lib.rs:118-128）；`ASTRA_LOG_FORMAT` 未设时 TTY→pretty、非 TTY→json（lib.rs:57-63）；`RUST_LOG` 走 EnvFilter（lib.rs:115-116）。OTel 与 fmt 共用同一 per-layer filter（crates/astra-logging/src/otel.rs:91、101）。底层 crate 写日志走 `tracing::warn!`（如配置文件解析失败，crates/astra-config/src/runtime_config.rs:2008）或 astra-core 的 `agent_warn!` 宏（crates/astra-config/src/lock_ext.rs:23），少数工具型模块直接 eprintln（crates/astra-text-utils/src/output_style.rs:275、crates/astra-config/src/user_profile.rs:925）。
- **配置读取：五层优先级 + 0 哨兵 + 非默认即胜**。优先级 内置默认 < `~/.astra/config/runtime.toml`（可被 `ASTRA_LOCAL_STATE_ROOT` 整体重定向）< `.astra/config/runtime.toml`（CWD 相对）< `ASTRA_*` 环境变量 < CLI `--settings` overlay（crates/astra-config/src/runtime_config.rs:1990-2051，env 覆盖项清单 2671-2715）。合并语义 `merge_if_non_default`（runtime_config.rs:1916-1920）意味着**"改回默认值"不可表达**（crates/astra-config/src/config_overlay.rs:88-90 自认 caveat）。工具策略阈值普遍 "0=用默认" 哨兵 + floor/cap（`resolve_threshold` runtime_config.rs:1242；parallel_batching 三元组 7/8/50，1255-1263）。凭据 profile 另有独立四级解析 cli>env>file>default（crates/astra-credentials/src/lib.rs:122-145）。进程内快照：`RuntimeConfig::cached()` OnceLock 固化（runtime_config.rs:1985），CLI overlay 存"已解析结构"使后续 load 不可能失败（runtime_config.rs:1929-1931）。
- **并发/同步模式**：
  - 进程级单例一律 `OnceLock`：风格注册表（crates/astra-text-utils/src/output_style.rs:234）、配置缓存与 CLI overlay（crates/astra-config/src/runtime_config.rs:1986、1932，后者包 RwLock 支持运行中重设）、内置模型 profile 表（runtime_config.rs:695、1095）、OTel provider 槽（crates/astra-logging/src/otel.rs:19，OnceLock<Mutex<Option<..>>> 支持取出 shutdown）。
  - **跨进程互斥用 fs2 文件锁**：配置版本索引 append 全程独占锁（crates/astra-config/src/config_versions.rs:191-211），凭据读共享锁/写独占锁加在旁路 `.json.lock` 文件上避免 rename 使 fd 失效（crates/astra-credentials/src/lib.rs:176-208）。
  - **持久化原子写统一 temp+rename**：用户画像（crates/astra-config/src/user_profile.rs:929-938）、凭据（crates/astra-credentials/src/lib.rs:236-248，失败时清理 tmp 防敏感残留）。
  - **RwLock 中毒一律恢复不 panic**：`RwLockExt::read_or_recover/write_or_recover`（crates/astra-config/src/lock_ext.rs:21-34）与散见的 `unwrap_or_else(|e| e.into_inner())`（crates/astra-credentials/src/lib.rs:360-364）。
  - **确定性序列化**作为并发正确性延伸：工具面三列表排序（crates/astra-runtime-env/src/tool.rs:702-705）、schema digest 的键序无关规范化（crates/astra-runtime-env/src/provider.rs:328-342）、denials BTreeMap 归并（binding.rs:663-681）。
  - async 边界仅限两个 trait：`RuntimeEnvironment`（runtime_environment.rs:756）与 `WorkspaceProvisioner`（workspace.rs:270）；本层其余全部同步纯函数。

#### 8.9.2 共享内核（core）
- **配置管理（env + 默认值三级）**：`.env` 仅在 `ASTRA_CONFIG_SOURCE≠explicit-env` 时由 `AppSettings::from_env` 加载一次（`crates/core/src/config.rs:1001-1004`）；TOML 链 `/etc/astra/server.toml` → `~/.astra/server.toml` → env 覆盖（`config.rs:836-877`）；必需键（`MATRIXONE_PASSWORD`/`ASTRA_RUNTIME_ROOT_SECRET`/`ASTRA_JWT_SECRET`）缺失默认 fail-closed，`ASTRA_ALLOW_INSECURE_DEFAULTS=1` 才放行捆绑默认并 `tracing::error!`（`config.rs:1638-1661`）；JWT 弱密（占位符或 <32 字符）直接 Validation 错误（`config.rs:1467-1479`）；库名前缀隔离 `ASTRA_DATABASE_PREFIX`（`config.rs:1601-1612`）；运行时限额双通道：TOML `[runtime]` + env 再覆盖，`RuntimeLimits::global()` OnceLock 单例（`runtime_limits.rs:93-116`）；进程级 env 叠加层避免 `set_var` 竞态（`session_env_overlay.rs:11,30-52`）。
- **秘密处理约定**：所有含密配置结构手写 `Debug` 打码 `[REDACTED]`（`config.rs:984-998,1179-1197,1428-1440`）；连接串双版本——`database_url_with_password` 仅供建池、`database_url` 恒打码（`config.rs:1341-1401`）；mysql CLI 密码走 `MYSQL_PWD` 避开 ps（`config.rs:1224-1235`）。
- **错误处理**：单一分类点原则——错误在源头一次性分类为 `ErrorKind`，下游按 kind 匹配而非重解析字符串（`error_kind.rs:1-13` 模块注释）；字符串边界兜底分类器 `classify_llm_error_message`/`classify_model_resolution_error_message`/`classify_tool_output`（`error_kind.rs:675,722,759`）；`ConfigError` 四变体含行动指引文案（`config.rs:1562-1591`）；Axum 统一错误体 `ErrorResponse` + `error_response_coded[_with_metadata]` 附机器可读 error_code/metadata（`lib.rs:881-951`）；MatrixOne 重复键三形态识别 `is_duplicate_key_error`（1062/23000/消息文本，`lib.rs:959-973`）；连接配额错误 `ConnectionQuotaError` CAS 语义（`lib.rs:222-249`）。
- **日志**：全部 agent 诊断统一 target `astra.agent` + component 字段，运维可 `RUST_LOG=astra.agent=debug` 调节（`log.rs:1-57`）；best-effort 持久化专用 `log_persist!`/`agent_persist_fail!` 记 warn 不上抛（`log.rs:61-81`）；升级事件 `agent_escalation!`（`log.rs:85-95`）；计量/网络模块用各自 target（`astra::history_work`、`astra_core::net`、`astra_core::connection_quota`，如 `lib.rs:294-299`、`net.rs:40-45`）。
- **进程运行时（process_runtime）**：`build_process_runtime` 用 `new_multi_thread().enable_all().thread_stack_size(16 MiB).thread_name("astra-worker")` 显式构建（`process_runtime.rs:15-21`）——服务器 agent 循环深度组合的 future 在平台默认 worker 栈下会溢出并中止整个进程而非返回错误，故把栈预算固化为共享常量 `PROCESS_WORKER_STACK_BYTES`（`process_runtime.rs:8-13`），`astra serve`、独立服务器与嵌入式 CLI 共用以免分叉（文档明示）。
- **并发与锁约定**：std 锁中毒一律 `into_inner()` 恢复 + `agent_warn!`，不 panic（`sync_poison.rs:7-36`）；全局配额/计数器全部 CAS+饱和运算，溢出拒绝不 panic（`lib.rs:259-283`、`history_work.rs:1277-1289`）。
- **原子落盘**：基线/工件写采用临时文件(create_new,0600)+fsync+rename+父目录 fsync，失败 Drop 清理临时文件（`history_work_baseline.rs:308-393`）。

#### 8.9.3 能力层（tools / skills / pipeline / sandbox 等）
### 横切机制素材

### 沙箱/安全机制
- **三层纵深**：路径层 `validate_path`（astra-sandbox/src/path.rs:82，canonicalize+边界比对，`normalize_path`:150 防符号链接竞态）→ 命令层 `analyze_command_risks_in_workspace`（command.rs:220）与 tree-sitter AST 分析 `analyze_bash_risks_ast`（bash_ast.rs:481，能穿透 nohup/timeout/env 透明启动器与 xargs/find -exec）→ 进程层 namespace/cgroup（process_isolation.rs:66 `IsolationConfig` 四预设 :90-152）。
- **监督器协议防伪造**：READY/SETTLED_ECHILD 回执都绑定 UUID nonce + helper pid（process_isolation.rs:544-547、605-617）；终局回执后必须立即 EOF，多余消息按违规 fail-closed（:618-623）；目标 env 剥除全部 6 个私有协议键（:767-769）；`PR_SET_DUMPABLE=0` 防同 uid 经 /proc 复制 receipt fd（:741）；prepare 要求 main 已注册入口点（:425-430），防止被任意宿主滥用。
- **进程归属分级与诚实降级**：ScopeOwnership 三级（cgroup>supervisor>进程组，process_isolation.rs:192-203），弱回退（进程组）明确"管不住 setsid 逃逸"并在 IsolatedOutput.scope_ownership 里向消费者声明（:179-183）。
- **凭据防线多重**：env 侧 ALWAYS_DENIED 键模式（policy.rs:123-134）+ `scrub_secrets_from_env`（shell_hardening.rs:270）+ 工具输出侧 `redact_credentials_for_display`（astra-tools/credential_redaction.rs:322，executor 出口必经，executor.rs:676-680）+ 持久化侧 `redact_credentials_for_storage`（astra-pipeline/step_recorder.rs:41，覆盖 JWT/AWS/GitHub/Slack 前缀）+ 读取侧敏感路径黑名单（policy.rs:141 起，.env/.ssh/.aws 等 Permissive 也不可读）。
- **审批门参数敏感化**：`tool_requires_approval`（astra-tools/lib.rs:670-699）按 git/github 子动作区分读写； Denied 文案显式禁止原样重试（executor.rs:372-380）。
- **run_script 白名单**：RPC_ALLOWED_TOOLS（astra-tools/run_script.rs:76）限制 Python 侧可回调的工具集，bash 列入 UNSAFE_IN_STRICT（:98）；宿主无 process scope 时 schema 直接移除 run_script（executor.rs:786-794）。
- **技能信任分级**：MCP 技能禁行内 shell（astra-skills/executor/inline.rs:25-29）；TrustTier（manifest.rs:392）被 astra-sandbox 重导出（lib.rs:20）用于策略；技能加载限定根目录（loader.rs:283/375）防路径遍历（:310）。

### 错误处理
- **语义化退出码**：`ExitSemantics`（astra-tools/exit_semantics.rs:12）把 grep 无匹配/diff 有差异/test false 与真失败分开，`classify_command_result`（:151）结合命令族（:274）与输出启发（:500-577）判定。
- **取消即终态**：`cancelled_tool_result`（astra-tools/lib.rs:237-271）稳定 JSON 信封（retryable=false、next_action 指令），trait 默认实现 select 竞速（lib.rs:284-299），DefaultToolExecutor 用浅克隆共享缓存但换绑定调用者令牌（executor.rs:764-784）。
- **panic 围栏**：ToolEngine 对每个 handler `catch_unwind` 并转 `ToolResult::error`（tool_engine.rs:246-295）；DefaultToolExecutor 的锁中毒走 `recover_poisoned_lock` 计数恢复（executor.rs:181-205）。
- **失败面穷举的恢复**：CrashRecoveryManager 显式覆盖 9 种 unhappy path（astra-pipeline/crash_recovery.rs:22-31），恢复读取有 8MB/4096 事件窗口上限（step_checkpoint.rs:54-55）；`CacheRestoreReport`（step_restore.rs:33-51）区分审计投影与重放权威，未验证条目不进执行缓存。
- **降级不静默**：计划恢复 DB 故障→保留写守卫仅丢提示（astra-plan/resume.rs:103-111）；fork 无执行器→告警回退 inline（isolated.rs:322-327）；HTTP client 构建失败→工具返回带修复指引的结构化错误（executor.rs:1074-1093）。
- **SkillError 九类**（astra-skills/traits.rs:246-265）+ io::Error 到 NotFound/PermissionDenied 的映射（:291-299）。

### 并发模式
- **per-workspace 互斥租约**：类型化写工具与 bash 观测窗口共用文件锁租约（executor.rs:465-502 → workspace_observation.rs:432 `WorkspaceObservationLease`），run_script 另持写者纪元（WorkspaceWriterGuard workspace_observation.rs:194），防止并发写被误归因给 bash；租约竞争失败返回结构化错误而非死等（executor.rs:483-498）。
- **代际计数失效缓存**：`workspace_generation: AtomicU64`（executor.rs:117、753），写后 +1 使旧 bash 读缓存全部 miss；TTL 30s 兜底外部变更（executor.rs:168）。
- **协作取消全链路**：CancellationToken 从 ToolContext/调用者注入（lib.rs:284、executor.rs:764），贯穿 execute_with_cancel（tool_engine/sandbox 的 execute_isolated_with_cancel process_isolation.rs:2104）；监督器的 control 管道单字节 'C' 是子进程树的唯一安全终止路径（process_isolation.rs:576-589、806-811）。
- **两级检查点耐久度**：热路径 Buffered（不 fsync）与 turn 级 Durable（fsync）（step_checkpoint.rs:61-71），Light 保留 50 份滚动修剪（:58）。
- **bash 可detach化设计**：DetachShellSlot 可续充槽位由宿主在每次调用前重填（lib.rs:413-422、executor.rs:334-344），Ctrl+B 把活子进程移交给 BackgroundTaskRegistry（detach.rs:343）。
- **原子并发控制**：PlanModeState.version 乐观锁防丢写（astra-plan/state.rs:97-100）；patch 物化的工作区文件锁（patch_materialization.rs:953）；工具健康环形 8 条防无界增长（tool_health_types.rs:6）。

#### 8.9.4 协议与集成层（thin-client / mcp / messaging / harness 等）
### 横切机制素材（协议与集成层）

### 错误处理

- SSE 错误分类单一来源：`sse_error_code_for_status`/`sse_retryable_for_status` 把 HTTP 状态映射为 AUTH_ERROR/NOT_FOUND/VALIDATION_ERROR/INTERNAL_ERROR 与 retryable（≥500 或 429）——crates/astra-server-types/src/lib.rs:1629-1651。
- thin-client 区分传输错误与 API 错误：`ThinClientError::is_transport()`（connect/timeout/request）决定可否重试；非 2xx 统一 `Api{status, body}`——crates/astra-thin-client/src/error.rs:34-43、client.rs:238-245。
- 控制面回调以"成功状态码"为确认边界，不等待可选响应体（防已提交决策被延迟体误判）——crates/astra-thin-client/src/client.rs:255-267。
- Edge WS 协议 `deny_unknown_fields`：退役字段（内联 token、旧 tool_call_id）直接反序列化失败，即 fail-closed 演进——crates/astra-server-types/src/edge_ws_protocol.rs:59、96、137（测试 263-289）。
- MCP `side_effects_maybe()`：传输中断/超时类错误标记"结果未知"，调用方必须保留为证据、不得盲目重试（外部副作用可能已发生）——crates/astra-mcp/src/error.rs:37-53。
- Memoria 严格召回 fail-closed：任何条目缺少 user_id/session_id 回显即 `memory_scope_violation`；`bind_owner` 不支持时显式报错而非复用他人凭据——crates/astra-memoria/src/lib.rs:80-115、264-267。
- harness 验证器 panic 隔离：critical（Budget/Cost）panic→Block（fail-closed），普通 verifier panic→跳过（fail-open）——crates/astra-harness/src/kernel.rs:170-191。
- 消息层 `MailboxError::AckTimeout{attempts}`/`Rejected` 显式建模；DB 传输反序列化失败仅 debug 日志丢消息——crates/astra-messaging/src/types.rs:391-458、db_transport.rs:120-131。

### 重试 / 重连 / 幂等

- 开发者循环准入重试：仅响应头到达前；429 优先 `Retry-After`（clamp 1..120s）否则 2^n 指数退避；传输错误 1^n 退避——crates/astra-thin-client/src/client.rs:1230-1283、parse_retry_after 96-100。
- 控制回调（tool result/approval/user-prompt）：10s 超时 × 2 次相同请求体，仅传输类错误重试，依赖服务端幂等——crates/astra-thin-client/src/client.rs:41-42、1853-1884。
- Edge 连接事务化重连：`begin_reconnect`（intent+捕获 pending map 原子化）→ DB 注册期间旧连接可服务 → `commit_reconnect` 继承等待者 / `abort` 失败之；`ReconnectReservation::drop` 兜底 panic 路径；per-key Mutex 串行化并发重连——crates/astra-server-types/src/edge_connection_pool.rs:107-151、359-446、192-198。
- generation 双栅栏：连接 `unregister_generation` 只删自己的 incarnation；结果 `deliver_tool_result` 校验 `delivery_generation` 防迟到/跨代投递——edge_connection_pool.rs:450-473、799-809。
- 工具执行取消传播：等待 `timeout+10s` grace；取消/超时向 Edge 发 `ToolCancel{delivery_generation}` 防放弃后副作用继续——edge_connection_pool.rs:38-40、737-782；协议侧 ToolResultAck 要求 Edge 重放结果直到确认——edge_ws_protocol.rs:189-195。
- Edge 心跳对账：`last_seen_request_ids` → `ack_completed_for_user` 清去重账本；心跳响应 `unresolved_request_ids` 非空即需持久对账（replay_policy 仅 DurableResultReconciliationRequired）——edge_connection_pool.rs:1021-1032；crates/astra-thin-client/src/protocol.rs:486-533。
- 同步出箱幂等：请求 HMAC-SHA256(canonical JSON) 签名头 + ACK 的 schema_version/record_id/payload_hash 三重确认，IdempotentReplay 为显式状态——crates/astra-sync-protocol/src/lib.rs:8-16、42-61。
- MCP 连接指数退避（initial×2^(n-1) 封顶 30s；InvalidConfig 不重试）——crates/astra-mcp/src/connection.rs:458-496；工具调用 120s 超时→`ServiceError::Timeout`——connection.rs:268-286。
- 消息 DB 传输：轮询错误退避 200ms→10s（30 次连错告警）；空闲退避 100ms→2s；可见性超时 60s 回收 stale claim、投递上限 5 次；CleanupScheduler 5min 周期回收/清理（批 1000）——crates/astra-messaging/src/db_transport.rs:77-103、1548、1896+、1772-1894。
- ACK 跟踪与 DLQ：30s 无 ack 重试、3 次进 failed；DLQ 环形 1024——crates/astra-messaging/src/ack_tracker.rs:35-41、dead_letter.rs:20-21。
- 父信箱延迟投递：send 遇 AgentNotFound 在 registration_gate 内二次尝试或入 pending 队列（256 run × 256 条上限），注册时重放并丢弃过期消息——crates/astra-messaging/src/router.rs:618-664、380-426。

### 认证 / 令牌 / 凭据处理

- thin-client Bearer 双层：构造时默认 `bearer_token` + 每次 `token_override` 优先（`auth_headers_for`）；Work API 额外带 `x-astra-work-api-major: 1`——crates/astra-thin-client/src/client.rs:206-236。
- 交互协议大版本门禁：`post_developer_loop` 校验响应头 `x-astra-agent-interaction-api-major=="3"`，不符即 `IncompatibleRuntime`（提示升级 Server）——client.rs:1209-1221；常量定义 crates/astra-server-types/src/lib.rs:58-59。
- Edge WS：HTTP 升级前完成鉴权，应用帧内禁止重复密钥（`deny_unknown_fields` 拒绝旧 token 字段）——crates/astra-server-types/src/edge_ws_protocol.rs:100-102、263-289；浏览器 WS 同样要求凭据走类型化首帧而非 URL——server-types lib.rs:1534-1536。
- 请求级进程授权（bash）：`RuntimeProcessAuthorizationContext.authorization` 仅随单次 ToolRequest 下发，配套"required 无凭据绝不执行"的 replay 栅栏；Debug 实现脱敏——crates/astra-server-types/src/edge_ws_protocol.rs:58-70、159-165。
- 设备挑战证明：canonical 长度前缀消息 + HMAC-SHA256(SHA256(device_key))，设备密钥/原始挑战不进结果，golden vector 锁定——crates/astra-thin-client/src/device_proof.rs:40-95、102-116。
- 同步出箱 HMAC：以 token 为密钥对 canonical JSON 签名，置于专用头——crates/astra-sync-protocol/src/lib.rs:11-16。
- Memoria 凭据短命化：`MemoriaToolTransport` 每操作重新解析（撤销/同意变更即时生效）；master 密钥走 `Memoria-Owner` 衰减方案而非无限 Bearer——crates/astra-memoria/src/lib.rs:16-40。
- MCP 认证：auth_token 统一转 `Authorization: Bearer`（stdio 无、Sse/HTTP/WS 有）+ 自定义头校验（非法头名/值 fail-closed）——crates/astra-mcp/src/connection.rs:688-703、741-760、789-794；stdio 子进程环境变量黑名单防注入——crates/astra-mcp/src/tools.rs:464-499。
- 回环代理豁免：localhost/127.0.0.1/*.localhost 强制 `no_proxy`，防本地控制面被基础设施代理劫持——crates/astra-thin-client/src/client.rs:110-141。
- 重认证通道：`AuthReauthenticateRequest{password|memoria_proof, purpose}` 签发短时 proof，用于 ForceTakeover 等高敏操作——crates/astra-server-types/src/lib.rs:700-705、1028-1032；WorkBranchControlCommandV1::ForceTakeover 携带 reauthentication_proof——lib.rs:418-421。

#### 8.9.5 Turn 编排核心（astra-turn-core）
### 8.5 横切机制素材

**错误恢复（error_recovery / recovery_state / stall / interruption）**
- PTL 连发中止门：`RecoveryState::should_abort` — crates/astra-turn-core/src/recovery_state.rs:58（≥3 即中止），由 `ContextPipeline::run_with_limit_policy` — context/pipeline.rs:138 在耗算力前检查（`PipelineAbort::ConsecutivePtlExhausted`）。
- 工具重试退避：`should_retry_with_hint` — crates/astra-turn-core/src/error_recovery.rs:54（指数退避+抖动，服务端 Retry-After 钳到 [base,30s]；`max_tool_retries` 走 astra-core RuntimeLimits env）。
- 压缩升级链：`CompactionTier::escalate_for_recovery` — crates/astra-turn-core/src/context/budget.rs（budget.rs 测试 :175-188 锁定 1 次 PTL 升 Normal、2 次达 CompactHistory+）。
- 循环摄入侧计数：`consecutive_context_window_errors` 维护 — crates/astra-turn-core/src/agentic/turn_ingest.rs:259-285（成功清零防陈旧升级）。
- 失速证据：`stall.rs:23 SERVER_STALL_WINDOW=3`、`stall.rs:36 CONSECUTIVE_IDENTICAL_SIGS_ADVISORY_THRESHOLD=5`（真实会话 05e63cac 回归注释）；判定入口 `apply_cli_agentic_stall_preflight` — agentic/stall_preflight.rs:30。
- 结构化中断：`InterruptionRecord` — crates/astra-turn-core/src/interruption.rs:1295 行（每条早退路径记录为何停+如何恢复，双写重 checkpoint 与轻 trace）。
- 输出侧守卫：`apply_response_guards` — crates/astra-turn-core/src/response_guard.rs:696 行（泄漏/回声/重复/内部协议 XML 替换 + REDACTED finish reason）。
- 异常循环断路：`LoopCircuitBreaker::observe` — crates/astra-turn-core/src/loop_circuit_breaker.rs:248（"默认无限运行，只在失速/退步介入"设计哲学，模块头 :1-5）。

**并发安全（session_latches / concurrency_safety / parallel_tool_exec / streaming_tool_exec）**
- 一次性闩锁防缓存断裂：`SessionLatches` — crates/astra-turn-core/src/session_latches.rs:30（None→Some 后会话内永不变；`any_flipped_this_turn` :99 让优化器在翻转轮抑制标记）。
- 动态工具并发注册表：`concurrency_safety.rs` — crates/astra-turn-core/src/concurrency_safety.rs:1-7（MCP/插件工具的进程级注册表，静态工具归 `tool::categories::classify`）。
- 全进程工具并发上限：`shared_tool_semaphore` — crates/astra-turn-core/src/parallel_tool_exec.rs:70（`ASTRA_MAX_CONCURRENT_TOOL_EXECUTIONS` 默认 10；注释记录了"每批各建信号量导致 10×N 超卖"的已修复缺陷 :51-63）。
- 动作感知并发分类：`is_tool_concurrency_safe` — crates/astra-turn-core/src/tool/policy/mod.rs:62（memory/agent/git/github 按 action 分流，写串行）。
- 读/写分区并行 + 兄弟中止：`execute_parallel_round` / `partition_tool_calls` — crates/astra-turn-core/src/parallel_tool_exec.rs:298/:234（bash 失败则后续 mutating 中止）。
- 流中投机执行：`should_speculate` — crates/astra-turn-core/src/streaming_tool_exec.rs:57（只读且权限非 Deny/Escalate；env `ASTRA_STREAMING_TOOL_EXEC` 门控 :34）。
- 毒锁恢复：`sync_utils::rwlock_*` — crates/astra-turn-core/src/sync_utils.rs（毒化 RwLock 清标志重置默认值）；`astra_core::sync_poison::recover_mutex_lock` 用于 circuit_breaker.rs:75。
- 每轮次请求幂等：`ApprovalRequestKey` — crates/astra-turn-core/src/approval/request_key.rs（队列去重+陈旧重验）；`invocation_ledger.rs:1-5` prepare/CAS 语义契约。

**缓存（cache / semantic_read_cache / lru_map / fork / tool_result_dedup）**
- 会话 LRU：`cache.rs SessionCache`（基于 `lru_map.rs LruMap`，pub(crate)） — crates/astra-turn-core/src/cache.rs:8 / lru_map.rs:6。
- 缓存断裂诊断：`cache_diagnostics.rs:1-7` — 系统 prompt+工具 schema 哈希跨轮对比，按因分类并估 token 影响；云侧对应 cloud/cache_diagnostics.rs。
- 缓存放置策略：`cache_placement.rs:1-8` — 稳定内容（可缓存）与易变内容（Self-Awareness 前缀）分道；`ProviderCacheStrategy::from_cache_capability` — microcompact.rs:73。
- 序列化标记预算：单系统标记策略 — crates/astra-turn-core/src/context/serializer/mod.rs:190-260（Anthropic 4 标记上限下 1 system+1 tools+2 messages 的分配论证）。
- 语义读缓存状态机：`semantic_read_cache.rs:1-6` — 填充围栏+限额，纯读复用需修订事实与属主范围（契约在 turn-types semantic_read_cache.rs）。
- ForkPrefix 前缀复用：`fork/prefix.rs:1-6`（冻结字节级父前缀快照，子代理首请求复用 KV cache）+ `fork/cache_event.rs`（实测 cache_read tokens vs 估算遥测）。
- 工具结果去重：`tool/result/dedup.rs:1-6` — 无副作用同参短窗复用；结果外存 `tool/result/storage.rs`（超阈值落盘留预览）。

**流控（rate_limit_cooldown / circuit_breaker）**
- 429/529 冷却：`rate_limit_cooldown.rs:21-47`（默认 30s/上限 2min/Retry-After<20s 直retry/缺省回退 5s 可 env 覆盖）；连续 3 次 529 触发模型降级回退（:33 MODEL_FALLBACK_THRESHOLD）；6 个指标常量 :68-78。
- 云桥断路器：`CircuitBreaker::allow_request/record_success/record_failure` — crates/astra-turn-core/src/circuit_breaker.rs:74/:97/:112（默认 5 失败/30s 恢复/半开 3 成功；设计目的注释 :16-17 "持续云故障快速拒绝而非 240s 超时"）。
- SSE 空闲双档超时：`stream_idle_timeout` / `stream_idle_timeout_after_progress` — crates/astra-turn-core/src/sse/stream_host.rs:133/:138（首帧前紧、有进展后宽，防推理模型长停顿误杀）。
- 工具合批窗口：`TOOL_BATCH_COALESCE_MS=25ms` + 250ms 钳制 — crates/astra-turn-core/src/tool/policy/mod.rs:18-54（env `ASTRA_TOOL_BATCH_COALESCE_MS` 仅调试用途的论证注释）。
- 拒绝节流：`DenialTracker::record/should_prompt` — crates/astra-turn-core/src/approval/fingerprint.rs:417/:467（反复拒绝同一指纹后停止打扰）。

#### 8.9.6 持久化服务层（services）
横切机制素材：

- **错误体系（service_error）**：`service_error.rs:1-` 头注释明确"Replaces `Result<_, String>`"；`ServiceError` 携带机器可读 `kind` + 人类 `message` + 可选 `source` 链。但现状是**双轨**：auth 域直接用 `(StatusCode, Json<ErrorResponse>)` 元组（auth/mod.rs:83 `type AuthHttpError`），runs/work 用 `Result<_, String>`（如 runs.rs:11092），service_error 尚未统一铺开（事实：`pub use service_error::{ServiceError...}` 在 lib.rs:321，但主要 Database 服务签名仍以 String/HTTP 元组为主）。
- **SharedPool 注入约定**：`lib.rs:95-102 require_shared_pool`——所有服务拒绝隐式回退连接；auth 额外支持 `with_control_pool`（auth/mod.rs:983-986）独享控制面池；池超时映射 503（auth/mod.rs:1524-1559 `map_auth_sqlx`）。
- **事务模式**：显式 `pool.begin()` + 手工 SQL 绑定；关键处用 `SELECT ... FOR UPDATE` 串行化：refresh 令牌轮换锁用户行（auth/mod.rs:1861）、run 身份锁（runs.rs:11170）、加权准入 gate 锁（weighted_admission.rs:412-413）。会话写入一律先过写栅栏 `storage.rs:1385 lock_agent_session_write_fence` / `storage.rs:1299 lock_existing_agent_session_write_fence`，再 `admit_session_event_write`（:1077）校验会话归属与状态。
- **Outbox 模式（两处）**：① edge→云同步 `sync_outbox.rs:301 SyncOutboxStore`——稳定 event id（:1150 `sync_outbox_stable_event_id`）+ canonical payload hash（:127）+ 重试退避 + 连续 ack 水位 + 毒丸隔离（`SyncOutboxPoisonKind` :83）；② work 运行时事件 `work/runtime_event_outbox.rs:156 project_pending_runtime_events`（`work_runtime_event_outbox_slots` 表，runs.rs:34972 测试引用）。
- **schema 引导与契约**：`storage.rs:3323 ensure_core_schema`——进程内 tokio Mutex + 数据库 `astra_schema_bootstrap_leases` 租约 + 单连接池执行 ~120 张表 DDL，`astra_schema_table_contracts`（:733 `load_core_schema_table_contracts`）保存表契约做漂移检测；结束等待可见性（:3388 `wait_for_core_schema_visibility`，针对 MatrixOne 快照语义）。
- **权限/安全**：auth（bcrypt cost env 钳制 auth/mod.rs:25-34；密码 ≤72 字节 :94；统一错误文案防枚举）；`execution_grant.rs:52/116` HMAC 签名执行授权（run 身份防伪造，claims 见 astra-turn-types `ExecutionGrantClaimsV1`）；`weighted_admission.rs` 字节/token 加权准入（gates FOR UPDATE + reservations 插入 :515，租约续约 :229）；BYOK 网络策略（byok_endpoint.rs:139 `require_endpoint_policy_with_mode` 查 `runtime_llm_trusted_domains`）；journal 内容脱敏开关 `ASTRA_JOURNAL_CONTENT_REDACT`（session_journal.rs:7122-7160）与摄入侧 `redacted_content_marker`（event_ingestion.rs:111）。
- **分页**：`pagination.rs:5/9/13` 上限常量（200 / 1,000,000 / admin 500）+ `clamp_api_list_pagination`；游标分页普遍使用 keyset（session 列表 auth/session.rs:525-554 `(updated_at, session_id)` 游标 SQL；模型列表 models.rs:2734-2737 `(provider, model_name, model_id)` 游标）。
- **行解码容错**：`db_row.rs:16 RowExt`——MatrixOne 与 MySQL 对 `NOW(6)` 表达式回 DATETIME/TIMESTAMP 不一致，统一按有符号 epoch 读权威时钟。
- **幂等/防重放**：`auth_provider_request_replay` 唯一键（auth/mod.rs:1181-1197 重复键→"already used"）+ 内存兜底缓存（:1211-1228）；审批决策追加 `append_approval_decision_for_run_if_absent`（session_journal.rs:3899）。

#### 8.9.7 服务器运行时（runtime）
### 横切机制素材

- **错误处理**：SSE 路径错误统一走 `sse_error_response_from_error_with_context`（server/http_helpers.rs，附 request_id/session_id 的 SseErrorContext）；`(StatusCode, Json<ErrorResponse>)` 二元组是 handler 通用错误类型（astra_core::error_response）；`ClassifiedError{kind,message}` 贯穿 LLM/loop 层（ErrorKind: RateLimit/ProviderDeadline/StreamIdle/Cancelled…，turn/llm/client.rs:4843-5078 各分支定型）；`run_agentic_loop_with_host_panic_safe`（server/run/lifecycle/mod.rs:3131）catch_unwind 防 host panic 拖垮服务。
- **日志/tracing/OTLP**：`astra_logging::init_from_env`（server/mod.rs:253-258，service_name=astra-server）；target 约定 `astra_runtime::serve|run_lifecycle|llm_client|cleanup|metrics`（如 server/mod.rs:199、lifecycle/mod.rs:16081、client.rs:4962）；关停时 `shutdown_otel` 最后冲刷（server/mod.rs:248）；`/metrics` 端点（meta_handlers）由 15s 定时 DB 聚合刷新（server/mod.rs:626-665）。
- **配置**：`AppSettings::from_env`（astra-core，main.rs:22 / serve server/mod.rs:268）；运行时管理面 `/admin/config/{key}`（config_admin/admin_config.rs，需 astra_admin）；部署工具策略 `load_deployment_tool_policy`（server/deployment_tool_policy.rs，state_builder/core.rs:278 注入）；run 并发 `ASTRA_RUN_CONCURRENCY_LIMIT`（state_builder/runtime.rs:116）；LLM 预算类 env（client.rs:1629-1665 llm_connect/nonstream/total_budget）。
- **安全**：`apply_safety_config_from_runtime_config`（lib.rs:117）启动即固化 TrustMode；`validate_conversation_authority` 会话 fencing（chat_handlers.rs:19）；`ExecutionGrantSigner` 派生子钥签名（state_builder/core.rs:8,75-78）；`llm_provider_admission`（llm_provider_admission.rs:559）RPM/TPM 准入；`/admin/llm/trusted-domains` 出站白名单（router_builder/admin.rs:45-52）；`tool_workspace_path_guard.rs` 路径逃逸防护；`redact_provider_secrets`（turn/llm/client.rs:59）日志脱敏；`DurableRunApprovalGate` 工具审批（lifecycle/mod.rs:2054）。
- **并发**：run 全局 FIFO 信号量（默认 50，lifecycle/mod.rs:15854 acquire_run_permit_with，注释强调"多用户公平边界"）；每 session 单活跃 run 写锁（:15290-15300 防 TOCTOU）；控制面专用 DB 池（state_builder.rs:99）；`capability_endpoint_pool.rs` 每 endpoint 信号量；owner lease 心跳 + `confirm_execution_authority`（run/engine.rs）实现多副本执行权互斥；`DescendantCancellationScheduler`（lifecycle/mod.rs:4580）后代任务级联取消。
- **缓存**：prompt cache（turn/prompt_cache.rs 2664 行 + turn/llm/context.rs 的 `stabilize/annotate_tool_schemas_for_cache`，server_loop_host.rs:12303-12380 调用）；`CacheBreakDetector`/指纹 diff（astra-turn-core，lib.rs:281-283 再导出）；模型限流冷却 `rate_limit_cooldown`（turn/model_cooldown.rs + server_loop_host.rs:11933）；`fork_cache_probe.rs`（orchestration）；`capacity_model.rs` 把各并发机制统一成容量方程。
- **定时任务/后台 sweeper**（serve 内 spawn，server/mod.rs:291-353）：Memoria 健康探测 15s（:398）；数据清理 6h（:445，RetentionPolicy）；edge dispatch 孤儿清理 15min/1h（:509）；edge 积压指标 15s（:564）；模型请求指标 15s（:626）；work 事件投影/分支删除/补丁物化/补丁提交恢复（astra_services::work + server/work_*_runtime.rs）；cleanup 债务重试（server/cleanup_retry.rs）；租约选主 sweeper（server/sweeper_lease.rs，TTL 60s，:1-6）；产物保留清扫（server/artifact_retention_sweeper.rs）与设备租约清扫（server/device_lease_sweeper.rs）；会话结束后台记忆提取（session_memory/service.rs，lifecycle/mod.rs:16869 触发）。

#### 8.9.8 交互层（astra-cli / astra-edge）
横切机制素材：

- **输出隔离**：`lib.rs:28` `#![cfg_attr(not(test), deny(clippy::print_stdout))]` 禁止裸 println；`stdout_print!`/`stdout_println!` 宏（lib.rs:33-47）在非测试态强制走 `output_sink::write_stdout_fmt`（output_sink.rs:136），测试态回落 std::print 保留 libtest 捕获。`output_sink` 以 AtomicU8 维护 Open/Closed/Failed（output_sink.rs:16-60）：BrokenPipe→Closed，退出码映射 141（128+13）/3（output_sink.rs:62-71 `resolved_exit_code`，main.rs:22 消费）。人读输出/help=stdout（`write_stdout_records` output_sink.rs:92 逐记录写），状态/错误=stderr（cli_output.rs 模块注释：stdout 保留给管道/脚本）。
- **stream-json 与 UI 分离**：`stream_json.rs`（严格机读，逐行即写 stdout）与 `stream_events_writer.rs`（--stream-events JSONL 到显式文件）互不相染；TUI 模式 `tui_render_policy = RenderPolicy::Silent`（event_loop.rs:5023）令 SSE 渲染层静默，全部经 stream_bridge 走事件通道。
- **会话恢复**：三层——云端快照（`restore_session_snapshot_with_client` session_restore_client.rs）、本地 journal/workspace（`HybridRestoreService::restore_local_session`，workspace.yaml 损坏时降级 journal-only，entrypoint.rs:1293-1329 测试固化）、checkpoint（session_recovery/checkpoint.rs:341 回滚）。恢复后会话身份由 `RequestSessionExecutionLease`（session_execution_lease.rs，请求级租约）在首个 SSE `session_bound` 帧上绑定一次，终态校验 `validate_terminal_identity`（stream_render.rs:7936）。TUI scrollback 由 `chat_widget/resume.rs:12` 从 canonical transcript lane 重建（非渲染缓存）。
- **审批交互**：通道链 `CliSseStreamHost.approval_request_tx`（stream_render.rs）→ `enqueue_interactive_request`（chat_stream/params.rs）→ TUI `approval_rx`（event_loop.rs:7284）→ `BottomPane::enqueue_approval*` → `ApprovalQueue`（tui/approval/queue.rs）+ 内联审批卡（history_cell/approval.rs）+ 按钮行（approval/button_row.rs）→ oneshot 回 `ApprovalResponse` → `resolve_cloud_approval_via_tui`（stream_render.rs:3365）继续 `post_approval_with_auth_retry`（:1666 → client.rs:1886 post_approval）。关键策略：`preflight_cloud_approval_decision`（permission_manager.rs）先按权限模式/会话 allow 规则裁决；无 TUI sink 自动 Deny（stream_render.rs:3404-3410，fail-closed）；`exit_plan_mode` 专用四选一 plan review（:3379，plan_review_view.rs）；审批附带 `ApprovalRequestKey`/risk_tags/batch_group_key metadata（:3427-3446）支撑"always allow"范围化记忆（`persist_scoped_allow_rule` :616）。
- **权限模式与沙箱**：PermissionMode 六态（Prompt/Auto/Bypass/Plan/Deny/AcceptEdits，entrypoint.rs 测试 :1749）；Bypass 在 SSE host 安装无限沙箱 guard（server_admission_host.rs:788-795，turn 结束自动还原防泄漏）；Plan 模式不剪 schema 只拦变更调用（:709-717，保 prompt-cache 稳定）。
- **取消语义**：分层 CancellationToken——进程 shutdown（event_loop.rs:4995）→ 会话/回合 → "物理流"子作用域（stream_render.rs:7900 `child_token`：服务端终态可取消单条物理流而不扇出到兄弟流/后续回合）；edge 侧 `EdgeInvocationTracker` 按代际取消。
- **墙钟预算**：一次性 chat 的 `--max-wall-time-seconds` 由三常量切分（command_router.rs:63-74：终端结算储备 70s、请求安全余量 2s、服务端终态证明 5s），`ExecutionTimeBudgetClock`（chat_stream/params.rs:22-64）fetch_min 单调不回升，防重试放大预算。
- **令牌生命周期**：CLI 侧 SSE 401 时 `refresh_edge_token_after_401`（stream_render.rs:1600）原地刷新重试一次；edge 侧 token_manager 单锁状态机 + AuthOk heal-write + (iat,exp) 生成序防回退（token_manager.rs 模块注释）。
- **生产基线采集**：`ProductionProcessCaptureGuard::from_env`（main.rs:14-17 / astra-edge main.rs:1363-1372）在两个二进制入口对称安装。

#### 8.9.9 前端与 SDK（web / packages/sdk）
**横切机制素材**

- **前端认证（httpOnly 双令牌 cookie）**：`web/proxy.ts:1-38`——middleware 白名单（`/`、`/login`、`/register`、`/api/runtime-config`、`/api/runtime-auth/*`）+ cookie 存在性门禁，未带凭证的页面请求重定向登录；`web/app/api/runtime-auth/login/route.ts:75-90` 写 `astra_api_url`/`astra_access_token`/`astra_refresh_token` 三枚 httpOnly、sameSite=lax cookie；`web/lib/auth/actions.ts:36-48` `saveTokens`（maxAge 1 年，生产 secure）；`web/lib/runtime-client/server.ts:137-145` 转发遇 401 自动 `refreshTokens`（207-238 行）并重放请求，新令牌 `persistTokens` 回写 cookie（240-256 行）；`server.ts:197-203` 每个请求附加 `Authorization: Bearer` + `X-User-Id`（JWT sub 由 `extractJwtSubject` 解出，packages/sdk/src/http.ts:105-123）。
- **错误处理**：三层错误类型——浏览器侧 `WebApiError`（web/lib/api/errors.ts:2-14，`requestJson` 统一解析 `{error|detail}`，request.ts:12-21）；服务端代理侧 `RuntimeClientError`（web/lib/runtime-client/errors.ts:12-30，携带 operation/path/status/detail/code）；SDK 侧 `AstraApiError`（packages/sdk/src/client.ts:2757-2770，含 category/retryable/actionHints）。route handler 统一模式：`error instanceof RuntimeClientError && error.status ? error.status : 502`（如 web/app/api/harnesses/templates/route.ts:16-20）。SSE 内错误以 `{type:"error", message, status?, code?}` 帧下发（stream/route.ts:290），浏览器 `applyStreamEvent` 收尾时转 `WebApiError`（chats.ts:613-626, 748-750）。协议不兼容专门编码 `RUNTIME_PROTOCOL_MISMATCH`（stream/route.ts:331-336）。
- **样式方案**：Tailwind CSS 3 + CSS 变量主题（web/tailwind.config.ts:8-33——`bg/surface/border/text/accent/...` 全部映射 `rgb(var(--color-*) / <alpha>)`，暗色切换只改变量）；`cn()` 仅 clsx 无 tailwind-merge（web/lib/utils/cn.ts:1-3——推断：类冲突时靠约定避免）；交互原语自研 `components/ui` 包装 Radix（menu.tsx:Menu/MenuItem/MenuConfirmPanel 等）。
- **状态持久化的隐性约定（坑）**：聊天/项目主数据在**服务端内存** `__astraWebStores`（web/lib/api/web-store.ts:139-141，按 ownerUserId 分 scope），Next 进程重启即失；真相源是后端 `/sessions`+`/runs`+transcript，`syncBackendSessions/syncBackendTranscript`（web-store.ts:1987/2140）负责拉回，但 Web 自建字段（projectId 归属、归档状态、本地 pendingTurn）只存在内存/后端 session metadata（`workspace_selection` metadata key，web-store.ts:101）。
- **SSE 解析器三份实现**（隐性重复，修改帧格式需同步三处）：route handler `eventFromSseFrame`（stream/route.ts:47-65，服务端镜像）、浏览器 `parseSseFrame`（chats.ts:261-277）、SDK `processSSEChunk/parseSseDataEvents`（packages/sdk/src/sse-client.ts:30-51, 212-236）。
- **断线重挂协议**：事件带 `index`，前端维护 `nextEventIndex`（chats.ts:345-348），重挂 GET 用 `last_index` 续传（chats.ts:789-793 → route.ts:768-773）；自动重试指数退避上限 4 次（use-stream-lifecycle.ts:59, 380-402）；`stream_gap/agent_live_gap` 事件触发从 durable 投影修复工作面（use-stream-lifecycle.ts:435-461）。
- **no_proxy 防御**：`web/next.config.ts:5-11` 与 `web/playwright.config.ts:5-15` 都强制 loopback 绕过系统 HTTP 代理，否则服务端代理 fetch 会 503。
- **测试基建**：vitest jsdom（web/vitest.config.ts）+ Node 25 localStorage shim（web/test.setup.ts:4-17）。


---

## 9. 外部依赖说明

### 9.1 workspace 级关键依赖总表（根 `Cargo.toml`）

| 依赖 | 版本 | 用途 | 主要使用位置 |
|---|---|---|---|
| axum | 0.8.6（ws） | HTTP 框架：路由/SSE/WebSocket | runtime（服务器）、services（少量 handler 类型） |
| tokio / tokio-util | 1.47.1 | 异步运行时（rt-multi-thread/signal/process） | 全部后端 crate |
| sqlx | 0.8.6（mysql+tokio-rustls） | MatrixOne（MySQL 协议）访问：连接池/查询/DDL | core（SharedPool）、services（~120 表）、runtime（data_layer） |
| reqwest | 0.12.23（rustls/socks/stream） | HTTP 客户端：LLM 调用、BYOK 代理、thin-client | runtime/turn/llm、services/byok_endpoint、astra-thin-client |
| serde / serde_json / serde_yaml_ng / toml | 1.x | 序列化（配置/wire/模型协议） | 全部 |
| jsonwebtoken / bcrypt / fernet | 10.3 / 0.17.1 / 0.2.2 | JWT 签验、口令散列、模型密钥静态加密 | services/auth、services/models |
| tracing (+subscriber/appender) + opentelemetry 0.32 / tracing-opentelemetry 0.33 | — | 结构化日志与 OTLP trace 导出 | astra-logging、runtime/observability |
| clap | 4（derive+env） | CLI 参数解析 | astra-cli（33 子命令）、astra-edge、astra-test-harness |
| ratatui + crossterm（vendor 补丁） | 0.29 | TUI 渲染与终端事件（补丁：SIGINT/DA1 启动查询） | astra-cli/src/tui（约 170 组件）；`[patch.crates-io] Cargo.toml:141-143` |
| tokio-tungstenite + rustls + webpki-roots | 0.26 | Edge WS 反连（rustls TLS） | astra-edge、astra-thin-client、runtime（/edge/ws 服务端为 axum ws） |
| tower / tower-http | 0.5.2 / 0.6（cors） | 中间件与 CORS | runtime/server |
| uuid（v4/v7）/ chrono | 1.18.1 / 0.4.42 | ID 生成（v7 时序有序）与时间 | 全部后端 |
| thiserror | 1.0 | 错误定义 | 全部后端 |
| hmac / sha2 / hex / base64 | — | HMAC 签名（同步协议）、摘要（工具结果规范化哈希） | astra-sync-protocol、thin-client、services |
| nix（unix）/ libc | 0.31 | Unix 信号/终端/文件系统（UDS 等） | astra-sandbox、astra-cli（部分功能仅 Unix，如 run_script UDS） |
| similar | 2.7 | 文本 diff | astra-cli/diff_utils、edit 工具 |
| flate2 / tar / fs2 | — | 压缩打包（工件）、跨进程文件锁 | 工件存储、astra-credentials/astra-config |
| hickory（经 services 引入，DNS） | — | BYOK 直连 DNS 钉扎防重绑定 | services/byok_endpoint/dns |
| rmcp | — | MCP 协议实现（四传输） | astra-mcp |
| insta / tempfile / temp-env / dotenvy | — | 快照测试/临时环境/.env 加载（dev） | 测试与 `core` 的 dotenvy |

**替代关键实现提示**：sqlx+MySQL 驱动是唯一持久通道（MatrixOne 兼容层在 `core` 做了 null-shape 注释与 UNION ALL 绑定两项补丁，`crates/core/src/lib.rs:47-91`）；crossterm 不可直接换回 crates.io 版本（行为依赖本地补丁）；OTel 版本线必须 0.32/0.33 配套（`Cargo.toml:105-107` 注释）。

### 9.2 前端与 SDK 关键依赖（`web/package.json`）

| 依赖 | 用途 |
|---|---|
| next 16.3.4 + react 19.2 | App Router 控制台（route handlers 兼作后端代理） |
| @astra/sdk（file:../packages/sdk） | 与后端契约对齐的客户端（SSE/WS/Work wire 解码） |
| tailwindcss 3.4 + radix-ui + lucide-react + cmdk | 样式与 UI 组件 |
| @xyflow/react | 图视图（DAG/流程） |
| react-markdown + remark-gfm/math + rehype-highlight/katex | 聊天 Markdown/公式/代码高亮渲染 |
| zod 4 | route handler 入参校验 |
| vitest / playwright / testing-library | 测试（排除范围） |

### 9.3 各 crate 依赖使用明细

以下为各批次分析产出的依赖使用明细（依赖 | 用途 | 使用文件），按层排列。


#### 9.3.1 基础库层
| 依赖 | 用途 | 使用文件 |
|---|---|---|
| tracing | 结构化日志宏（warn!/info!，RUST_LOG 生态） | crates/astra-logging/src/lib.rs、otel.rs；crates/astra-config/src/runtime_config.rs、lock_ext.rs（经 astra-core agent_warn） |
| tracing-subscriber | 全局订阅器、EnvFilter、fmt/json/pretty 输出、分层 Registry | crates/astra-logging/src/lib.rs、otel.rs |
| opentelemetry / opentelemetry_sdk | 追踪 API 与 SDK（TracerProvider、Resource 检测器） | crates/astra-logging/src/otel.rs |
| opentelemetry-otlp | OTLP gRPC(tonic) SpanExporter | crates/astra-logging/src/otel.rs |
| tracing-opentelemetry | tracing layer 桥接 OpenTelemetry | crates/astra-logging/src/otel.rs |
| tokio（optional） | otel feature 下的异步运行时 | crates/astra-logging（otel.rs 间接） |
| serde / serde_json | 全层数据结构序列化、JSON overlay/编辑、wire 校验 | 五个 crate 几乎所有文件 |
| dirs | 跨平台 home 目录定位（`~/.astra` 根） | crates/astra-text-utils/src/output_style.rs；crates/astra-config/src/runtime_config.rs、config_versions.rs；crates/astra-credentials/src/lib.rs |
| toml（preserve_order） | runtime.toml 解析/序列化、版本 blob、diff 树 | crates/astra-config/src/runtime_config.rs、config_versions.rs、config_version_cli.rs |
| thiserror | 边界 typed 错误派生 | crates/astra-config/src/config_overlay.rs、config_versions.rs、json_mutation.rs、user_profile.rs（间接）；crates/astra-runtime-env/src/tool.rs、runtime_environment.rs、workspace.rs；crates/astra-credentials/src/lib.rs |
| sha2 | 内容寻址摘要（cfg_ 版本 id、cli-profile 属主、工具契约/schema digest） | crates/astra-config/src/config_versions.rs；crates/astra-credentials/src/lib.rs；crates/astra-runtime-env/src/provider.rs、tool.rs |
| fs2 | 跨进程文件锁（独占/共享） | crates/astra-config/src/config_versions.rs；crates/astra-credentials/src/lib.rs |
| chrono（serde） | 版本索引时间戳（ts_milliseconds） | crates/astra-config/src/config_versions.rs |
| async-trait | 异步 trait（RuntimeEnvironment、WorkspaceProvisioner） | crates/astra-runtime-env/src/runtime_environment.rs、workspace.rs |
| astra-core（workspace 内） | local_state 路径策略、RuntimeLimits/模型窗口、TraceLevel/TraceCategory、tool_offer/tool_schema 规范、agent_warn 宏 | crates/astra-config/src/runtime_config.rs、config_overlay.rs、lock_ext.rs、local_state.rs；crates/astra-runtime-env/src/provider.rs、tool.rs、local_state.rs |
| astra-turn-types（workspace 内） | ObjectiveRelation/UserFeedback（TurnIntent 字段） | crates/astra-config/src/user_profile.rs |

#### 9.3.2 共享内核（core）
| 依赖 | 用途 | 使用文件 |
|---|---|---|
| sqlx（mysql feature，workspace 继承） | MatrixOne(MySQL 协议) 连接池/QueryBuilder/prepared 语句 | src/lib.rs（池与配额）；经 `pub use sqlx` 间接供全 workspace |
| axum | Web 层共享契约：`Json`、`StatusCode`、`HeaderMap`（ErrorResponse/bearer_token） | src/lib.rs |
| tokio | 进程级多线程 runtime 构建 | src/process_runtime.rs |
| reqwest | HTTP 客户端构建/代理策略/URL 解析（net、端点形状判定） | src/net.rs, src/model_wire/thinking.rs, src/error_kind.rs |
| serde + serde_json | 全部配置/证据/观测类型的序列化；canonical JSON | 几乎全部模块（lib.rs, config.rs, observation*.rs, work_unit.rs 等） |
| toml | server.toml 解析（serde 集成） | src/config.rs |
| dotenvy | `.env` 加载（唯一入口 from_env） | src/config.rs |
| chrono | ISO8601 时间戳（数据快照引用等） | src/composite_snapshot.rs（work_unit.rs 仅测试） |
| uuid | 快照/索引 v7 UUID | src/composite_snapshot.rs |
| sha2 | SHA-256（构建 attestation、进程捕获/工件哈希） | src/history_work_baseline.rs, src/bin/*.rs |
| async-trait | `ActiveWorkProvider` 异步 trait | src/work_unit.rs |
| dirs | 跨平台 home 目录（`~/.astra` 根） | src/local_state.rs |
| tracing | 结构化日志（宏族 + 各模块散点） | src/log.rs（宏定义）、lib.rs、config.rs、net.rs、history_work.rs 等 |
| temp-env / tempfile（dev） | 测试用 env 隔离与临时目录 | 仅 #[cfg(test)] 代码，不进生产二进制 |

#### 9.3.3 能力层
### 第三方依赖表（能力层 6 crate 直接使用的非 workspace 依赖）

| 依赖 | 用途 | 使用文件 |
|---|---|---|
| tokio（+tokio-util） | 异步运行时、进程/IO、CancellationToken | 六 crate 几乎全部异步文件（如 astra-tools/executor.rs、astra-sandbox/process_isolation.rs、astra-skills/executor/*.rs） |
| async-trait | trait 中的 async fn | astra-tools/lib.rs、tool_engine.rs、astra-skills/traits.rs、astra-plan/repository.rs 等 |
| serde / serde_json | 序列化与工具参数/结果信封 | 全部 6 crate（schemas.rs、step_protocol.rs、manifest.rs…） |
| serde_yaml_ng | SKILL.md frontmatter 与钩子配置解析 | astra-skills/loader.rs、manifest.rs、hooks.rs |
| toml | 技能 manifest 的 TOML 解析 | astra-skills（Cargo.toml 声明，manifest 相关） |
| regex | 凭据模式/诊断解析/命令分词 | astra-tools/credential_redaction.rs、astra-pipeline/step_recorder.rs、trace_query.rs |
| thiserror | 错误类型派生 | astra-tools/tool_engine.rs、astra-pipeline（step_restore/output_stream）、astra-skills、astra-plan |
| tracing | 结构化日志 | 六 crate 全部（TracingLogger astra-tools/lib.rs:472 为服务端默认） |
| reqwest | HTTP 客户端（GitHub/web_fetch/web_search/memoria） | astra-tools/github.rs、web_fetch.rs、web_search.rs、memoria.rs |
| scraper | web_fetch 的 HTML→文本/markdown 转换 | astra-tools/web_fetch.rs |
| url | URL 解析与 scheme 升级 | astra-tools/web_fetch.rs（Cargo.toml） |
| futures | catch_unwind/FutureExt | astra-tools/tool_engine.rs |
| gix 0.85 | 纯 Rust git 操作（status/blame/revision…） | astra-tools/git_gix.rs |
| tree-sitter（+rust/python/typescript/go/java/cpp/ruby 0.23-0.24） | 代码智能符号提取 | astra-tools/code_intel.rs |
| tree-sitter-bash 0.23 | bash AST 风险分析 | astra-sandbox/bash_ast.rs |
| nix / libc | 进程组信号、prctl、fd 控制、waitpid | astra-tools/detach.rs、rpc_bridge.rs、astra-sandbox/process_isolation.rs、git_safety（cfg(unix)） |
| uuid | 调用 ID/nonce/UUIDv7 事件关联 | astra-tools/executor.rs、astra-sandbox/process_isolation.rs、astra-pipeline/event.rs |
| sha2 + hex | 内容哈希（源快照/patch/幂等键/恢复哈希） | astra-tools/source_preimage.rs、patch_materialization.rs、astra-pipeline/crash_recovery.rs |
| base64 | 编码（用户 ID 路径等） | astra-tools（Cargo.toml；memoria/session 路径） |
| fs2 | 跨进程文件锁（工作区租约/协调） | astra-tools/workspace_observation.rs、astra-pipeline/step_checkpoint.rs |
| chrono | 时间格式化 | astra-tools/executor.rs、astra-plan、astra-prompts/memory_types.rs |
| sqlx | MatrixOne/MySQL 数据库访问 | astra-pipeline（step_protocol 的 DB 后端）、astra-plan/repository.rs |
| walkdir | 技能目录遍历 | astra-skills/loader.rs |
| dirs | home/配置目录发现 | astra-tools（Cargo.toml，SandboxConfig）、astra-skills/loader.rs |
| tempfile | 测试临时目录 | 各 crate dev-dependencies（及 astra-tools 内部缓存路径） |
| which | 可执行文件定位（python3 等） | astra-tools/run_script.rs（Cargo.toml） |
| tar + flate2 | 技能包 tar.gz 打包 | astra-skills/pack.rs |
| axum | 数据库 provider 的 HTTP 错误类型映射 | astra-skills/providers/database.rs |

> workspace 内部依赖（非上表）：astra-tools → astra-core/astra-memoria/astra-prompts/astra-sandbox/astra-services/astra-turn-types；astra-skills → astra-core/astra-services/astra-runtime-env/(可选 astra-pipeline)；astra-pipeline → astra-core/astra-services/astra-text-utils/astra-turn-types；astra-plan → astra-core/astra-services/astra-tools/astra-turn-types；astra-prompts → astra-core；astra-sandbox → astra-skills/astra-core。

#### 9.3.4 协议与集成层
### 第三方依赖表（协议与集成层）

| 依赖 | 用途 | 使用文件 |
| --- | --- | --- |
| serde / serde_json | 全部 wire 契约序列化（大量 deny_unknown_fields / tagged enum） | 本层全部 58 个文件（几乎） |
| chrono | 时间戳/游标/年龄计算/DB DATETIME(6) | server-types/lib.rs、worktree_isolation.rs；messaging/db_transport.rs；memoria/lib.rs；thin-client/protocol.rs、work.rs；mcp/connection.rs(调用日志) |
| uuid | 消息 ID、request_id、订阅 ID、召回令牌（v4/v7） | messaging/types.rs、db_transport.rs、router.rs；memoria/lib.rs |
| tokio（含 sync/time/process/rt/macros） | 异步运行时、mpsc/broadcast/oneshot/RwLock/Notify/watch、子进程、超时 | server-types(edge_connection_pool/conflict_resolver/worktree_isolation/ws_progress_callback)；messaging 全部；thin-client(测试)；mcp(connection) |
| tokio-util | CancellationToken（Edge 工具执行取消） | server-types/edge_connection_pool.rs、team_orchestrator_traits.rs |
| async-trait | trait 异步方法（传输/端口/回调/冲突解决） | messaging/transport.rs、router.rs 等；memoria/lib.rs；server-types 三个文件；mcp 无（rmcp 自带） |
| tracing | 结构化日志与诊断 target（如 astra_runtime::edge_dispatch_diag） | server-types、messaging、thin-client、mcp、harness |
| axum | server feature 下 StatusCode/Json 错误响应类型 | server-types/lib.rs |
| dashmap | 并发连接池/pending 账本/重连 intent（分片锁语义被注释依赖） | server-types/edge_connection_pool.rs |
| thiserror | 错误类型派生 | thin-client/error.rs；mcp/error.rs、classic_sse.rs |
| reqwest | HTTP 客户端（双客户端：常规+SSE 流式禁解压）、MCP StreamableHTTP/经典 SSE 传输、自定义头 | thin-client/client.rs；mcp/classic_sse.rs、connection.rs、manager.rs(间接) |
| futures-util | Stream/Sink 扩展（SSE 字节流、WS 桥） | thin-client/client.rs；mcp/connection.rs、classic_sse.rs |
| async-stream | chat_stream/stream_run 的 stream! 生成器 | thin-client/client.rs |
| base64 (URL_SAFE_NO_PAD) | 设备证明编码 | thin-client/device_proof.rs |
| hex | 结果哈希/签名十六进制 | thin-client/protocol.rs；sync-protocol/lib.rs |
| hmac + sha2 | 请求签名、结果哈希、设备证明 | sync-protocol/lib.rs；thin-client/device_proof.rs、protocol.rs |
| percent-encoding | 模型名等 URL 段编码 | thin-client/paths.rs |
| sqlx (MySql 特性) | MatrixOne/MySQL 消息队列持久化与租约目录 | messaging/db_transport.rs |
| rmcp 1.3 (client/child-process/streamable-http-reqwest/async-rw) | MCP 官方客户端 SDK：serve_client、模型类型、传输 | mcp/connection.rs、manager.rs、tools.rs、error.rs、classic_sse.rs、lib.rs |
| tokio-tungstenite | MCP WebSocket 传输桥 | mcp/connection.rs |
| astra-core（内部） | canonical JSON、ErrorResponse、CompositeSnapshot、worktree 基路径、SubRunState | sync-protocol；server-types(server feature)；（thin-client 传递依赖） |
| astra-services / astra-tools / astra-turn-types / astra-turn-core / astra-runtime-env（内部） | 服务层记录类型、工具回调 trait、推理目的/工具身份/中断类型/新鲜度、运行时能力词汇 | server-types(lib/team_orchestrator/edge_pool/ws_progress_callback)；messaging/types.rs；memoria/lib.rs；thin-client(lib/protocol/edge)；harness/verifiers/completion.rs |
| tempfile（仅 dev） | worktree git 集成测试临时仓库 | server-types（dev-dependencies） |
| wiremock（仅 dev） | thin-client HTTP/SSE 行为测试 | thin-client（dev-dependencies） |

#### 9.3.5 Turn 编排核心
### 9.5 第三方依赖表（astra-turn-core / astra-turn-types）

| 依赖 | 用途 | 使用文件 |
|---|---|---|
| serde / serde_json | 全部契约类型与 wire JSON（Serialize/Deserialize） | 两 crate 几乎所有文件（典型：turn-types 各契约、chat_turn_payload.rs、chat_turn_sse_dispatch.rs） |
| serde_yaml_ng | YAML 配置解析 | orchestration/team_config.rs、stop_hooks/stop_hooks_yaml.rs |
| thiserror | 错误类型派生 | turn-types（session_fork.rs、provider_contract.rs 等）、stall.rs、parallel_tool_exec.rs、provider_resolution.rs 等 |
| sha2 | 内容寻址哈希（规范身份、游标、账本摘要） | turn-types context_identity.rs / session_coordination.rs / session_cursor.rs；tool_ledger_receipt.rs |
| regex | 模式匹配（脱敏、注入模式、XML 回退、记忆校验） | permission/redact.rs、tool/result/sanitize.rs、xml_tool_call_fallback.rs、turn-types memory_structure.rs |
| base64 | SSE 事件信封编码 | sse_events.rs |
| chrono | 时间戳 | trace_event.rs、file_edit_journal.rs、fork/* 等 |
| uuid (v4/v7) | run/事件标识 | trace_event.rs、turn_trace_collector.rs |
| tokio (含 macros/rt/test-util) | 异步运行时、超时、select、信号量、任务 | sse/stream_host.rs、parallel_tool_exec.rs、streaming_tool_exec.rs、conversation_log/file_store.rs、approval/sink.rs |
| tokio-util | CancellationToken 取消传播 | sse/stream_host.rs（consume_sse_stream_cancellable） |
| futures-util | Stream 消费（StreamExt） | sse/stream_host.rs |
| async-trait | 异步 trait（ApprovalSink、SseStreamHost 钩子、TraceEvent、契约） | approval/sink.rs、sse/stream_host.rs、contracts.rs、trace_event.rs、tool/policy/hooks.rs、permission/sync.rs |
| reqwest | Webhook 告警 HTTP 投递 | alert_dispatcher.rs |
| dashmap | 动态工具并发注册表 | concurrency_safety.rs |
| dirs | 平台目录（~/.astra/...） | llm_request_dump.rs、tool/result/storage.rs、tool/health/persistence.rs |
| fastrand | 重试抖动随机 | error_recovery.rs |
| fnv | 快速非加密哈希 | （workspace 引入，注册表键场景） |
| sqlx（optional，feature db-store） | CSL 数据库后端 | conversation_log/db_store.rs |
| axum | （workspace 引入，HTTP 面；turn-core 内仅类型兼容） | lib.rs 依赖表（本 crate 源内少用） |
| tempfile / filetime / proptest / serial_test（dev） | 测试临时目录 / mtime / 属性测试 / 串行测试 | context/budget.rs（proptest）、各 *_store.rs（tempfile） |
| astra-prompts | 记忆协议常量（ABSTRACT_MIN/MAX、LAYER_SEP） | turn-types memory_structure.rs、lib.rs 注释 |
| astra-core | 错误分类（ErrorKind/ClassifiedError）、规范名、RuntimeLimits、history_work 插桩、sync_poison | agentic/turn_ingest.rs、error_recovery.rs、circuit_breaker.rs、context/pipeline.rs |
| astra-turn-types | 契约层（本 crate 的下游反转依赖方） | astra-turn-core 全库（token_accounting.rs、runtime_scaffolding.rs、chat_turn_sse_dispatch.rs 等） |
| astra-pipeline | StepRecorder/StepCheckpoint/step_protocol | agentic/post_tool_policy.rs、chat_turn_step_plan.rs、agentic/turn_ingest.rs |
| astra-sandbox | git 命令校验、命令风险分析、GitSafetyViolation | permission/engine.rs、safety_middleware.rs、permission/memory_profile.rs |
| astra-tools | agent 动作契约、AskUserGate、凭据脱敏 | permission/engine.rs、ws_user_prompt_gate.rs、safety_middleware.rs |
| astra-thin-client | ApprovalKind、ThinClient（reflect 补水、云摘要） | chat_turn_sse_dispatch.rs、hydrate_reflect.rs、cloud/summary.rs |
| astra-messaging | 父子代理权限消息（AgentMessage/AgentAddress） | permission/sync.rs、permission/types.rs |
| astra-services | 会话 journal（ToolCallRecord、JournalDirGuard） | headless/journal.rs、agentic/turn_ingest.rs 测试 |
| astra-text-utils | 工具名规范化、预览截断、分词 | tool_allowlist.rs、headless/status_display.rs、retrieval.rs |
| astra-runtime-env | 运行时环境抽象 | lib.rs 依赖表（环境探测场景） |

#### 9.3.6 持久化服务层
第三方依赖表（来自 crates/services/Cargo.toml:28-69）：

| 依赖 | 用途 | 使用文件 |
|---|---|---|
| astra-config / astra-core | 配置类型、SharedPool、ErrorResponse、connect_matrixone、composite_snapshot 等共享类型 | 几乎全部（storage.rs、lib.rs 等） |
| astra-logging | 日志宏（agent_error! 等） | session_journal.rs |
| astra-runtime-env | 运行时环境探测 | 少量服务 |
| astra-turn-types | ConversationCommitV1/ExecutionGrantClaimsV1/Handoff 等回合协议类型 | session_journal.rs、execution_grant.rs、session_handoff.rs、session_fork_coordinator.rs、runs.rs |
| astra-sync-protocol | 同步协议共享类型 | sync_engine.rs、sync_outbox.rs |
| async-trait | 服务 trait 的 async 方法 | auth/mod.rs、models.rs、runs.rs 等全部 trait |
| axum | HTTP 类型（StatusCode/HeaderMap/Json 错误响应） | auth/、admin.rs、models.rs 等错误签名 |
| base64 | 令牌 claims/签名的 URL-safe 编解码、代理 Basic 认证 | auth/mod.rs、execution_grant.rs、byok_endpoint/proxy.rs |
| bcrypt | 用户密码哈希/校验（cost 由 ASTRA_BCRYPT_COST 控制） | auth/mod.rs |
| chrono (serde) | 时间类型与格式化（NOW(6)、DATE_FORMAT 解析） | auth/、runs.rs、work/ 等广泛 |
| fernet | provider 会话句柄与模型 API key 对称加密 | auth/encryption.rs、models.rs |
| flate2 | journal 压缩（gzip 归档/维护） | session_journal.rs（归档）、runtime_maintenance.rs |
| futures-util | Shared future（边缘吊销检查 in-flight 合并） | auth/mod.rs |
| hmac + sha2 | moi 令牌/HMAC 签名、执行授权、工件签名、canonical hash | auth/mod.rs、execution_grant.rs、artifact_policy.rs、sync_engine.rs |
| jsonwebtoken | HS256/384/512 JWT 签发与校验 | auth/jwt.rs |
| regex | 注册端点 URL 等校验 | registry_payload.rs 等 |
| reqwest | 模型 provider HTTP 客户端（BYOK 钉扎、探测、外部认证） | byok_endpoint.rs、models.rs、auth/external.rs |
| hickory-resolver | 直连 DNS 解析（防 Fake-IP） | byok_endpoint/dns.rs |
| rustls / tokio-rustls / webpki-roots | 出口代理 TLS 与根证书 | byok_endpoint/proxy.rs |
| percent-encoding | 代理 URL 用户名/密码解码 | byok_endpoint/proxy.rs |
| serde / serde_json / serde_yaml_ng | DTO 序列化、JSON 列（CAST AS CHAR）、models.yaml | 全 crate；models.rs（yaml）、byok_endpoint |
| sqlx (mysql, chrono) | 全部数据库访问（query/query_scalar/Transaction/QueryBuilder） | storage.rs、runs.rs、work/*_repository.rs 等全部 Database 服务 |
| thiserror | ServiceError/WorkDomainError 等错误派生 | service_error.rs、work.rs、weighted_admission.rs |
| tokio / tokio-util | 异步运行时、超时、任务（隧道、审计 flusher） | byok_endpoint/proxy.rs、state_sync.rs、runs.rs |
| tracing | 结构化日志（warn!/debug! target astra_services::*） | auth/mod.rs、storage.rs、byok_endpoint/dns.rs 等 |
| uuid | 全部主键/会话/令牌 jti 生成 | auth/、runs.rs、storage.rs |
| unicode-segmentation | 字符计数截断（delegated_findings 等文本限额） | delegated_findings.rs、work/observation.rs |
| dirs | 本地目录解析（~/.astra/sessions） | session_journal.rs、session_artifact_store.rs |
| fastrand | 轻量随机（缓存扰动等） | 少量存储路径 |
| fs2 | 文件锁（journal 排他锁、执行租约、bootstrap 租约） | session_journal.rs |
| libc | 平台 F_FULLSYNC 等 fsync 强化（macOS） | session_journal.rs |
| openssl (optional, vendored for musl) | fernet 的底层加密后端可选静态链接 | 构建（release musl） |

#### 9.3.7 服务器运行时
### 第三方依赖表（crates/runtime/Cargo.toml）

| 依赖 | 用途 | 使用文件 |
|---|---|---|
| axum | HTTP 框架（Router/提取器/SSE/WS 升级） | server/mod.rs、server/router_builder/*、全部 *_handlers |
| tower-http | CORS/中间件层 | server/mod.rs:17,167-184 |
| tokio / tokio-util | 异步运行时、CancellationToken、信号 | 全 crate（serve、lifecycle、后台任务） |
| reqwest | LLM/Memoria 等 HTTP 客户端 | turn/llm/client.rs:639、auth_handlers、memoria 相关 |
| sqlx (mysql) | MatrixOne 数据访问 | data_layer/storage.rs、llm_provider_admission.rs、lifecycle/persistence.rs |
| serde / serde_json | 序列化 | 全 crate |
| serde_yaml_ng | 部署策略/profile YAML | server/deployment_tool_policy.rs、deployment/mod.rs |
| chrono | 时间 | 全 crate（token_usage、session_current_date 等） |
| uuid | ID 生成 | run 生命周期、sweeper_lease |
| sha2 / hmac / base64 | 子钥派生、SigV4、body digest、token 编解码 | state_builder/core.rs:8、turn/bedrock/transport.rs、server/mod.rs:113 |
| crc32fast / flate2 | AWS eventstream CRC 与 gzip | turn/bedrock/eventstream.rs |
| tar | 工作区/补丁打包 | server/work_patch_export_runtime.rs |
| async-stream / futures-util / http-body-util | SSE 流构造与 body 组装 | server/http_helpers.rs:267 |
| async-trait | service trait 异步方法 | provider/traits.rs 等 |
| tracing | 结构化日志 | 全 crate |
| thiserror | 错误类型 | provider/traits.rs 等 |
| regex | 文本匹配（意图/路径判定） | bash_intent.rs、tool_* 守卫 |
| notify | skill 文件热载监听 | skills/watcher.rs |
| dashmap | 并发 map | 运行时热状态（如冷却/缓存） |
| fs2 | 文件锁 | 沙箱/工作区互斥 |
| tempfile | 临时文件/工作区 | 测试与 scratch 工作区 |
| dotenvy | .env 装载 | main/serve 环境准备 |
| percent-encoding / unicode-normalization / dirs | 路径与文本规范化 | 工具路径、prompt 处理 |
| fastrand | 轻量随机 | 退避抖动等 |
| astra-harness (optional, feature harness) | 观测/验证 harness 钩子 | turn/agentic_loop（SessionStart/PostLlmResponse/PreToolBatch/SessionEnd）、server/harness |
| workspace 内部 crate：astra-core/-services/-turn-core/-turn-types/-config/-logging/-memoria/-messaging/-text-utils/-pipeline/-plan/-prompts/-runtime-env/-sandbox/-server-types/-sync-protocol/-mcp/-skills/-tools/-thin-client | 配套层（见 4.7 各节） | 全 crate |

#### 9.3.8 交互层
第三方依赖表（以 astra-cli/Cargo.toml、astra-edge/Cargo.toml 与 workspace `[patch.crates-io]` 为准）：

| 依赖 | 用途 | 使用文件 |
|---|---|---|
| clap 4.5 (+derive)、clap_complete | CLI 参数/子命令解析、shell 补全 | cli/cli_config/cli_args.rs、entrypoint.rs、command_router.rs、admin_cli/cli_args.rs |
| crossterm 0.29（**workspace 本地补丁 `vendor/crossterm`，[patch.crates-io]，见 vendor/crossterm/ASTRA-PATCH.md：SIGINT 先于 raw mode、DA1 启动查询、Esc 隔离**） | 终端原始模式/事件/样式 | tui/*、cli/theme.rs、cli/effects/*、stream_render.rs、entrypoint.rs |
| ratatui 0.30.2（scrolling-regions、unstable-* features） | TUI 框架 | tui/draw.rs、tui/custom_terminal.rs、tui/bottom_pane/*、各 view |
| tokio（rt-multi-thread/macros/net/process/signal）+ tokio-stream + tokio-util | 异步运行时/取消令牌 | 全 crate，event_loop.rs、sse_loop/*、astra-edge/main.rs |
| reqwest（经 astra-thin-client） | HTTP 客户端 | cli/chat_stream/sse_loop/agentic_loop_turn.rs、cli/auth_flow.rs |
| tokio-tungstenite 0.26（rustls-webpki-roots） | Edge WebSocket | astra-edge/src/main.rs |
| rustls + webpki-roots | 代理隧道内 TLS | astra-edge/src/main.rs（connect_via_proxy） |
| serde / serde_json / serde_yaml_ng | 序列化（载荷/journal/config） | 全 crate |
| axum | serve HTTP、测试 mock、mock_llm | cli/command_router.rs（start_http_server）、cli/mock_llm.rs、app_server.rs |
| rmcp 1.3（client+server+多 transport） | MCP 协议客户端/测试服务器 | mcp_client.rs、edge_tools/mcp_dispatch.rs、mock_mcp_server_impl.rs、cli/mcp_config.rs |
| gix 0.85（status/blame/revision） | 纯 Rust git 操作 | edge_tools/git_gix.rs、edge_tools/worktree.rs、tui/worktrees/model.rs、git_branch_cache.rs |
| tree-sitter 0.24 + rust/python/ts/go/java/cpp/ruby 绑定 | 代码解析（code_analysis 工具/高亮） | edge_tools/code_analysis.rs、tui/render/highlight.rs |
| inquire 0.9 / rpassword 7.4 | 交互式提问/密码输入 | command_router.rs（model add）、admin_cli/input.rs、auth_flow.rs |
| rustyline 14（with-file-history） | 行编辑（历史遗留 REPL 输入） | cli（旧 line-mode 路径残留依赖） |
| textwrap 0.16 / unicode-width / unicode-segmentation | 换行与宽度计算 | tui/wrapping.rs、textarea.rs、markdown_render.rs |
| pulldown-cmark 0.12 / termimad 0.23 | markdown 解析与终端渲染 | tui/markdown.rs、cli/stream/streaming_md.rs |
| nucleo-matcher 0.3 | 模糊匹配（slash/mention/session picker） | tui/slash_menu/mod.rs、tui/mod.rs score_slash_token |
| sqlx | MatrixOne SQL（mo_tools） | edge_tools/mo_tools.rs |
| tracing / tracing-subscriber / tracing-appender | 日志 | cli/diagnostic_log.rs、全 crate |
| uuid / chrono / sha2 / base64 / url / urlencoding | 通用工具 | sse_loop（run_id）、token、edge id 哈希等 |
| gix 相邻：similar | diff 算法 | diff_utils.rs、diff_presenter.rs、journal_diff.rs |
| fs2 | 文件锁 | session_recovery/io.rs、astra-edge invocation_journal |
| nix / libc（unix） | 信号/进程底层 | output_sink.rs（SIGPIPE）、tui/terminal_startup.rs、astra-edge |
| hostname / fastrand / md-5 | edge 主机名/抖动/校验 | astra-edge/main.rs |
| dirs 6 / dotenvy / thiserror / futures-util / toml / tempfile / shell-words / supports-color / regex / derive_more / schemars | 目录、.env、错误、future、TOML、临时文件、shell 分词、颜色探测 | 各处（cli_config、config_edit_router、workspace_trust 等） |
| dev-only：insta、wiremock、serial_test、temp-env、pretty_assertions、itertools、http、vt100 | 快照/HTTP mock/串行测试 | tests/*（不在生产清单内） |

#### 9.3.9 前端与 SDK
### 第三方依赖表

| 依赖 | 用途 | 使用文件 |
| --- | --- | --- |
| next ^16.3.4 | App Router 框架、route handlers、server actions、middleware | web/app/**、web/proxy.ts、web/next.config.ts |
| react / react-dom ^19.2.7 | UI 运行时（RSC + hooks） | web/components/**、web/hooks/**、packages/sdk/src/hooks.ts |
| typescript ^5.8.3 | 类型系统（web 与 sdk 共用版本） | 全部 .ts/.tsx |
| @astra/sdk（file:../packages/sdk） | 路径常量、wire 类型、AstraClient、SSEClient、JWT 解码、Work 解码器 | web/lib/runtime-client/*、web/lib/api/*、web/app/api/**、work-turn-composer.tsx |
| tailwindcss ^3.4.17 + postcss + autoprefixer | 原子化样式（CSS 变量主题） | web/tailwind.config.ts、全部组件 |
| clsx | className 条件合并 | web/lib/utils/cn.ts、全组件 |
| @radix-ui/react-dialog/dropdown-menu/popover/scroll-area/slot/tooltip | 无障碍交互原语 | web/components/ui/modal.tsx、menu.tsx、popover.tsx 等 |
| @floating-ui/core/dom/react-dom ^1.8/2.1 | 定位引擎（Radix 底层，锁定版本 overrides） | web/package.json overrides |
| cmdk ^1.1.1 | Cmd+K 命令面板 | web/components/app/search-modal.tsx |
| lucide-react ^1.37 | 图标 | web/components/app/**、ui/** |
| @xyflow/react ^12.11.6 | Work 任务图 DAG 可视化 | web/components/app/work-task-graph.tsx |
| react-markdown ^10 + rehype-highlight ^7 | 助手消息 Markdown 渲染 + 代码高亮 | web/components/app/message-bubble.tsx |
| remark-gfm ^4 / remark-math ^6 + rehype-katex ^7 + katex ^0.18 | GFM 表格、数学公式 | web/components/app/message-bubble.tsx |
| zod ^4.5.4 | 表单/输入校验 | web/components/app/create-project-form.tsx |
| date-fns ^4.4 | 相对时间格式化 | web/lib/utils/time.ts |
| vitest ^4 + @vitejs/plugin-react + jsdom + @testing-library/* | 单元/组件测试 | web/vitest.config.ts、test.setup.ts、packages/sdk/vitest.config.ts |
| @playwright/test ^1.62 | E2E 测试 | web/playwright.config.ts、web/e2e/** |
| tsup ^8.4（sdk devDep） | SDK 双格式构建（ESM/CJS+dts） | packages/sdk/tsup.config.ts |
| tseslint/eslint（eslint ^10 + eslint-config-next） | Lint | web/package.json scripts |


---

## 10. 新人上手路径

### 10.1 建议的文件阅读顺序（由浅入深）

1. **产品与契约**：`README.md` → `docs/design/ARCHITECTURE.md`（权威架构契约）→ 本报告 §0 术语表。
2. **共享内核与基础库**（一切的地基）：
   - `crates/core/src/lib.rs`（SharedPool、MatrixOne 兼容技巧）
   - `crates/core/src/config.rs`（AppSettings::from_env 配置链）
   - `crates/astra-logging/src/lib.rs`、`crates/astra-config/src/runtime_config.rs`、`crates/astra-runtime-env/src/lib.rs`（工具面模型）
3. **工具契约**：`crates/astra-tools/src/lib.rs`（`ToolResult`/`ToolExecutor` trait，L76/L275；四段式执行）→ `crates/astra-sandbox/src/lib.rs`（三层边界）。
4. **Turn 编排核心**（项目灵魂）：
   - `crates/astra-turn-core/src/context/pipeline.rs`（Context Pipeline 主入口 `ContextPipeline::run`:92）
   - `src/agentic/turn_ingest.rs`（终答判定）、`src/permission/engine.rs:407`（权限裁决）
   - `src/parallel_tool_exec.rs`、`src/sse.rs`（事件模型）
5. **持久化层**：`crates/services/src/lib.rs`（模块全景）→ `src/auth/mod.rs` → `src/storage.rs`（~120 张表 DDL，当地图查）→ `src/runs.rs`/`session_journal.rs`。
6. **服务器**：`crates/runtime/src/main.rs` → `src/server/mod.rs:251 serve()` → `src/server/router_builder.rs`（六组路由）→ `src/server/state_builder.rs:20`（AppState 组装）→ `src/turn/agentic_loop/host.rs:4318`（循环宿主）→ `src/turn/llm/client.rs:4682`（模型调用）。
7. **交互层**：`crates/astra-cli/src/entrypoint.rs` → `src/cli/command_router.rs:858` → `src/cli/chat_stream/sse_loop/mod.rs:208` → 挑 1-2 个 TUI 组件（`tui/chat_widget`、`tui/approval`）→ `crates/astra-edge/src/main.rs`。
8. **前端/SDK**：`web/lib/runtime-client/*`（SSE 客户端）→ `web/app/api/chats/[chatId]/stream/route.ts`（代理模式）→ `packages/sdk/src/index.ts`。

### 10.2 常见修改需求的切入点

| 需求 | 入手位置（按改动顺序） |
|---|---|
| **加一个工具** | ① `astra-runtime-env` 内置工具注册表登记；② 按 `astra-tools` 的 `ToolExecutor` 契约实现（注意四段式：准入/互斥/执行/结算）；③ `runtime` 的 `tool_registry`/`ToolExecutionService` 路由（本地 or Edge）；④ 若需 Server 可见性，检查 `server_loop_host` 工具面投影与权限引擎槽位 |
| **加一个 CLI 子命令** | `astra-cli/src/cli/cli_args.rs:152` `Command` 枚举加变体 → `src/cli/command_router.rs:858 execute_cli_command_impl` 加分发分支 |
| **加一个 HTTP API** | `runtime/src/server/router_builder.rs`（六组选一）→ 新 handler → `services` 新域服务（`with_pool` 注入）→ 必要时 `astra-thin-client` 加封装、`web/app/api/**` 加代理 route |
| **加一个 Web 页面** | `web/app/(workspace)/<route>/page.tsx` + `web/components/app/*` + 若需新数据则 `web/app/api/**` 新 route handler（经 `WebRuntimeClient` 转发） |
| **改提示词/系统契约** | `astra-prompts`（模板与记忆协议常量）与 `runtime/src/prompts`；注意 Context Pipeline 对 system 块的 cache 布局约束（§4.5） |
| **加技能** | 技能以 manifest 声明（仓库 `.agent/skills/` 或用户技能目录），由 `astra-skills` providers 加载——通常无需改代码 |
| **加后台/周期任务** | 仿照 `serve()` 内 sweeper 模式：常驻 tokio 任务 + 周期扫描 + 优雅停机登记（`runtime/src/server/mod.rs:251` 起） |
| **加模型提供商** | `.models.yaml` 条目 + `astra admin model load/check`；仅当协议不兼容时才动 `runtime/src/turn/llm/client.rs` 与 `services/models` |

### 10.3 隐性约定与易踩坑点（跨层汇总）

1. **stdout 是协议边界**：astra-cli 全 crate `deny(clippy::print_stdout)`，任何新代码输出必须走 `output_sink` 宏，否则机器可读模式（`--json`）被污染。
2. **Server 路由没有 `/api` 前缀**：`/api/*` 是 Web 代理层的命名空间；thin-client 直连时用根路径（如 `/chat/stream`，而非 `/api/chat/stream`）。
3. **协议 major 头必须带**：`interaction-api-major`（chat 流校验 =="3"）、`x-astra-work-api-major: 1`、Web 的 `x-astra-agent-interaction-api-major=1`；不匹配即拒。
4. **wire 类型 `deny_unknown_fields`**：给响应加字段会破坏旧客户端；演进需走版本化（如 `TurnPhaseReceiptV1`）。
5. **审批/权限 fail-closed**：无审批通道（headless 无 sink）、授权缺失、MCP 工具名冲突一律拒绝；不要试图"降级放行"。
6. **token 估算不替代 provider tokenizer**：估算 u64→u32 饱和防回绕；server 聚合子用量不得覆盖主机单请求校准值（§4.5）。
7. **先落库再投递**：推理台账、Edge dispatch/outbox、journal 三态幂等是正确性支柱；新增异步路径必须延续该模式。
8. **配置"非默认即胜"**：astra-config 合并语义使"改回默认值"不可表达；`0=默认`哨兵遍布；配置进程内 `cached()` 固化，测试需用 temp-env。
9. **MatrixOne 兼容坑**：null-shape 注释位图必须与绑定值逐位对应（无编译期保障）；`IN` 谓词跨 join 用 UNION ALL 绑定集合（`crates/core/src/lib.rs:47-91`）；`NOW(6)` 类型不一致由 `services/src/db_row.rs` 兼容。
10. **配额计数器是进程本地的**：`ASTRA_DB_GLOBAL_MAX_CONNECTIONS`（500）多实例部署需按实例数折算；`connect_matrixone` 忘记 release 即泄漏。
11. **身份域隔离**：MOI 令牌与非 MOI 凭据**绝不互为 fallback**（`astra-credentials`/auth）。
12. **Web 内存 store**：`web` 的 `__astraWebStores` 是进程内存态，重启即失；projectId/归档等仅存内存或 session metadata——不要当作持久层。
13. **部分写即失效缓存**：bash 只读缓存对任何写操作失效；`run_script` 仅 `execution_started=false` 可豁免；且该工具仅 Unix（UDS）。
14. **超大文件是常态**：`server_loop_host.rs`（3.2 万行）、`client.rs`、`runs.rs`（3.5 万行）、`storage.rs` 等改动前先 grep 定位，勿整读。
15. **测试口径**：文件名含 `test` 的模块被生产统计排除（如 `turn_driver.rs` 为 `cfg(test)` harness；`build_test.rs` 名含 test 但**是**生产模块——见 §4.3）。
16. **crossterm 是本地补丁**：`vendor/crossterm/ASTRA-PATCH.md`；升级依赖时不可直接替换为 crates.io 版本。

---

# 附录 A：全报告总目录（章节 ↔ 批次对照）

| 章节 | 内容 | 所在批次 |
|---|---|---|
| §0 术语表、批次计划表 | 全局 | 批次 1 |
| §1 项目概述（用途/技术栈/运行） | 全局 | 批次 1 |
| §2 整体架构（分层/依赖/数据流） | 全局 | 批次 1 |
| §3 目录结构详解 | 全局 | 批次 1 |
| §4.1~4.2 基础库层 + 共享内核 | astra-logging/text-utils/config/runtime-env/credentials、core | 批次 2 |
| §4.3~4.4 能力层 + 协议集成层 | astra-tools/skills/pipeline/plan/prompts/sandbox；server-types/sync-protocol/messaging/memoria/thin-client/mcp/harness | 批次 3 |
| §4.5 Turn 编排核心 | astra-turn-types、astra-turn-core | 批次 4 |
| §4.6 持久化服务层 | services | 批次 5 |
| §4.7 服务器运行时 | runtime | 批次 6 |
| §4.8 交互层 | astra-cli、astra-edge | 批次 7 |
| §4.9~4.10 前端/SDK/评测 | web、packages/sdk、astra-test-harness | 批次 8 |
| §5 文件清单总表 | 全部 1441 个文件 | 批次 1（清单层，随各批次细化职责列） |
| §6 关键函数深度解析 | core/tools/turn-core/services/runtime/cli/web 交付的 16+ 个函数 | 批次 9（素材随批次 2-8 产出） |
| §7 端到端调用链分析 | 三场景 + 时序图 + 各层明细 | 批次 9（素材随批次 3-8 产出） |
| §8 横切机制说明 | 综合 + 各层明细 | 批次 9 |
| §9 外部依赖说明 | workspace 总表 + 各 crate 明细 | 批次 9 |
| §10 新人上手路径 | 阅读顺序/切入点/坑点 | 批次 9 |
| 附录 A/B/C | 总目录/自检/存疑 | 批次 9 |

# 附录 B：完成度自检表

**生产文件覆盖统计**（口径：排除 `tests/`、`src/tests/`、文件名含 `test` 的模块、`benches/`、`fixtures/`、`testdata/`、`snapshots/`、`proptest-regressions/`、`__tests__`、`e2e`、`vendor/`、`docs/`、`node_modules`、构建产物）：

| 分组 | 覆盖文件数 | 清单表行数核对 | 备注 |
|---|---|---|---|
| a1 基础库（5 crate） | 29 | 29 | 全文精读 |
| a2 core | 34 | 34 | 含 `src/bin/` 3 个开发基线工具（列入清单并标注用途） |
| a3 能力层（6 crate） | 101 | 101 | `build_test.rs` 名含 test 但为生产模块，已列入 |
| a4 协议集成（7 crate） | 58 | 58 | — |
| a5 turn-types + turn-core | 250 | 250（与磁盘 .rs 双向核对零遗漏） | 核心模块精读、外围按模块结构归纳 |
| a6 services | 150 | 150 | 已排除 `byok_endpoint/proxy/tests.rs` |
| a7 runtime | 281 | 281 | 超大文件（server_loop_host 等）采用结构定位+关键段精读 |
| a8 astra-cli + astra-edge | 327 | 327（含 `bin/mock_mcp_server.rs`） | TUI 组件按清单级覆盖，代表组件精读 |
| a9 web + sdk + test-harness | 211 | 221 行（含分组标题行/目录说明行） | web 174 与 `_web_files.txt` 逐行核对零缺漏；sdk 15；test-harness 实测 22 个 .rs（初估 21，以实测为准） |
| **合计** | **1441**（Rust 1252 + TS 189） | — | — |

**已知计数边界情形**（不构成遗漏）：
- `crates/astra-cli/src/cli/tests.rs` 等文件名含 `test` 的生产相邻模块按口径排除（其中 `turn_driver.rs` 为 `cfg(test)` 专用 harness，`test_utils.rs` 若为生产工具应属边界，各批次已按文件名口径统一处理并在片段内注明）。
- `scripts/`（开发/CI/部署 shell 与工具脚本）、`deployment/`、`monitoring/` 按分析范围规则（非生产源代码）作目录级说明（§3.4），未逐文件展开。
- `docs/`、`fixtures/`、`.github/`、IDE/AI 协作配置（`.agent/`、`.claude/`、`.cursor/`、`.kiro/`）、锁文件按排除规则不分析。
- 承载运行逻辑的配置文件（`.env.example`、`.models.yaml.example`、`config/server.toml.example`、根 `Cargo.toml`、`Makefile`、`web/package.json` 等）已在 §1.3/§3.1/§9 覆盖。

# 附录 C：存疑与待确认清单

以下为分析过程中标注的推断项与无法完全确认的实现意图（标注"推断"者为基于代码结构的合理推断，未经运行验证）：

1. **astra-pipeline 的命名歧义**（事实澄清）：任务背景中"Context Pipeline 在 astra-pipeline"与代码不符——Plan→Bind→Optimize→Serialize 管线实际在 `astra-turn-core/src/context/pipeline.rs`；`astra-pipeline` 是学习/恢复管线（检查点+崩溃恢复+trace）。报告以代码为准。
2. `astra-turn-core/src/sse/data_lines.rs` 注释引用的 `super::server_loop` 模块在本 crate 内不存在（推断：指 runtime 侧同名宿主物）。
3. 宿主侧（runtime/CLI）真实 while 循环与 `ToolHookRegistry` 触发点的完整行号链在 a5 范围外，由批次 6/7 补齐（已并入 §7）。
4. `services/src/work/` 46 个子模块职责按命名+模块文档归纳（推断），未逐文件深读。
5. `astra-config`：`ToolSelectionConfig` 与 `ToolPolicyConfig` 字段近乎重复（推断为演进遗留）；output-styles 的 `keep_coding_instructions` 解析后未生效；`UserPreferences.config_overrides` 仅 2 个 key 被实现。
6. `core`：HistoryWorkSite 154 个变体未逐一手工核对（有编译期断言保障）；"17 crate 依赖 core、84 文件用 SharedPool"为 grep 统计值。
7. `astra-thin-client/src/client.rs`（3751 行）为选择性精读；`astra-messaging` db_transport 的 SQL 细节基于声明与关键片段（推断）。
8. Memoria 的 HTTP 客户端实现在 services 侧（`astra-memoria` 仅为规范端口），完整调用链未逐行展开（a3/a4 范围交界，见 §4.4/§4.6）。
9. `runtime` 超大文件（`server_loop_host.rs` 约 3.2 万行、`runs.rs` 约 3.5 万行等）采用结构 grep + 关键段精读，未逐行覆盖（文件级职责与关键函数已覆盖）。
10. `astra-cli`：rustyline 仍在依赖清单但行模式 REPL 已删（推断为残留依赖）。
11. Web：`cn()` 未接 tailwind-merge（推断）；SSE 解析器存在三份重复实现（事实，重构候选）；chat-view `handleSubmit` 行号未逐行核对。
12. `web` route handler 的 middleware 只校验 cookie 存在性、真正鉴权在 handler 内 `requireRuntimeUser`（事实）；`projectId` 等状态的持久化边界见 §10.3.12。
13. 本报告所有行号基于 Astra-0.2.4 源码静态阅读；若与后续版本比对请注意漂移。

---

*报告完。生成方式：9 组并行子分析（基础库/内核/能力/协议/Turn核心/服务/运行时/交互/前端）+ 主分析汇编；全部结论以 Astra-0.2.4 仓库实际代码为准。*
