# LangChain 1.3.0 项目串讲 · 讲稿

> 配套演示文稿：`LangChain-1.3.0-项目串讲.pptx`（21 页，讲稿同步内置于每页演讲者备注，演示者视图可见）
> 建议时长：40–50 分钟。讲稿为口语化文本，可直接照读，也可按要点自行展开。
> 四部分节奏：开场与代码结构 约 12 分钟 ｜ 功能组成 约 7 分钟 ｜ 实现方式 约 16 分钟 ｜ 问题与总结 约 12 分钟

---

## 第 01 页 · 封面

大家好，今天我来串讲 langchain-langchain-1.3.0 这个项目——LangChain 框架 Python 主包的 1.3.0 版本。先给一句定位：它不是一个能直接跑起来的应用，而是发布到 PyPI 的框架库，官方说法是「构建 LLM 应用与智能体的标准库」。这次分析对象是仓库里 libs/langchain_v1 目录，31 个生产源文件、约一万四千四百行 Python，我做了逐文件走查，所有结论都带源码行号。今天按四条线走：第一，代码结构——monorepo 怎么组织、分几层；第二，功能组成——这个包到底提供哪些能力；第三是重头戏，具体实现方式——create_agent 怎么把中间件编译成一张图、运行期怎么循环；第四，当前存在的问题——文档与代码不一致的地方、健壮性隐患和安全边界。完整讲稿在每页备注里，大家可以会后对照源码复盘。

---

## 第 02 页 · 今天讲什么

整场分享大约 40 分钟。第一部分 4 页，回答「代码长什么样」：monorepo 布局、五层架构、一张主包代码地图。第二部分 3 页，回答「能干什么」：四大能力、14 个内置中间件、结构化输出三策略。第三部分 7 页，是今天的重点，回答「怎么实现的」：从 create_agent 装配期八步，到编译产物图、运行期路由、洋葱组合器、中间件编程模型、模型工厂，最后两个案例精读。第四部分 5 页，讲问题和总结——这部分对做技术选型、借鉴设计最有参考价值，正反两面都会讲。

---

## 第 03 页 · 它是什么：不是应用，是构建智能体的「框架库」

先看它是什么。LangChain 1.3.0 是个框架库，核心就三件事：第一，create_agent——用户给一个模型、一组工具、一个系统提示，再加中间件和结构化输出 schema，一句调用就组装出「模型-工具循环」的智能体，返回一张可 invoke、可 stream 的 LangGraph 图；第二，中间件体系——agent 的官方扩展点，自带 14 个生产级中间件；第三，init_chat_model 和 init_embeddings——用「openai:gpt-5」这样的统一字符串初始化任意厂商的模型。理解 1.x 设计的关键是与 0.x 对比：旧版大量内置的链、记忆、检索器都移出到 langchain-classic 和 community 了，主包收敛成三件套，执行引擎完全交给 LangGraph。右边几个数字：31 个源文件、一万四千行代码、14 个中间件、26 组可选依赖——这是个非常克制的包。

---

## 第 04 页 · monorepo 布局：一个仓库、七个独立发版的包

仓库布局。LangChain 是个 monorepo，libs 目录下每个子目录都是独立发版的包。本次分析主体是 langchain_v1，发的 PyPI 包名就叫 langchain，版本 1.3.0。旁边的兄弟包：core 是基础抽象层，定义消息、模型、工具这些接口；注意 langchain 目录反而发的是 langchain-classic，就是旧架构兼容包——这是个很容易绕晕的命名陷阱，目录名是历史迁移的痕迹，要看 pyproject 里的包名为准。还有 text-splitters、standard-tests、model-profiles，以及 partners 下 15 个官方集成包，比如 langchain-openai。右边四个要点：独立发版意味着版本节奏互不同步，主包锁死 langgraph 1.2 到 1.3、core 1.4 到 2.0；开发态用 uv 的本地路径源做联调；质量门禁是 ruff 全规则加 mypy strict，跑完整单测还要 docker 起 Postgres 和 Redis——门禁相当严格。

---

## 第 05 页 · 五层架构：静态织入 + 执行引擎外包

这页是全包最重要的架构图，五层自上而下。最上面 L5 是用户 API 层，create_agent、中间件门面、init_chat_model 都在这层。L4 组装层是本包核心：factory.py 负责把模型、工具、中间件、响应格式编排成一张 StateGraph。L3 扩展层是中间件的类型契约 types.py 加 14 个内置实现。注意 L2、L1 是外部依赖：L2 是 LangGraph 图引擎，L1 是 langchain-core 基础抽象。最底 L0 是 partner 集成包，运行时延迟导入。右边三个要点：第一，控制反转——create_agent 只做静态织入，把钩子编译成图的节点和边，自己不实现执行引擎；第二，双重扩展点——before、after 钩子变成图里的独立节点，可以跳转路由；wrap 钩子变成洋葱包装链，可以重试、可以短路。这两条是理解后面所有实现内容的钥匙。

---

## 第 06 页 · 主包代码地图：31 个文件、7 个逻辑模块

把镜头拉近到主包内部，七个逻辑模块，依赖方向严格自上而下。agents 目录是心脏：factory.py 1885 行负责装配，structured_output.py 定义三种结构化输出策略。middleware 目录 19 个文件，其中 types.py 2052 行是契约层，是用户扩展框架唯一必须读懂的文件；14 个中间件实现加 3 个下划线私有支撑模块——中间件不反向依赖 factory，保证了它们可以独立测试。chat_models 的 base.py 一千行，是全包模型获取的唯一咽喉。messages、tools、rate_limiters 三个目录是纯门面，不含任何逻辑。右边条形图是最大的八个文件：types 和 factory 两个文件就占了全包代码的 27%——契约层和工厂，就是理解这个包的两把钥匙。

---

## 第 07 页 · 功能全景：四大能力

进入功能部分，四大能力。第一个 create_agent，签名里 model、tools、system_prompt、middleware、response_format，返回编译好的图，下面这段五行代码就能跑起一个带工具的智能体。第二个中间件体系，agent 的官方扩展点，14 个内置中间件覆盖四类横切关注点，下一页展开。第三个模型初始化，init_chat_model 支持冒号字符串，也可以只给模型名让它按前缀推断，运行时才延迟导入对应的 partner 包；_ConfigurableModel 还支持运行时可配置的模型代理。第四个统一门面，langchain.messages、langchain.tools 这些入口把 core 和 langgraph 的稳定符号转发出来，用户只面对一个包。1.x 的思路非常清晰：主包做窄门面加核心工厂，其余全部分出去。

---

## 第 08 页 · 14 个内置中间件：四类横切关注点

这页是中间件功能矩阵，按四类横切关注点分组。上下文管理组三个：SummarizationMiddleware 在历史超限时自动调摘要模型压缩上下文，触发条件支持按 token 数、按比例、按条数，找切割点用二分搜索，还保证不拆散 AI 和 Tool 消息的配对；ContextEditingMiddleware 把旧的工具结果替换成占位符，只改本次请求不落盘；TodoListMiddleware 给 agent 一个 write_todos 工具做任务计划。可靠性组五个：模型侧的重试、降级、调用上限，工具侧的重试和上限，重试带指数退避和抖动，计数是 thread、run 双轨的。安全与人工介入组四个：PII 检测脱敏、HITL 人工审批、ShellTool 持久 shell 会话、文件搜索工具。效率与测试组两个：LLMToolSelector 每次调用前用小模型从全量工具里选子集省 token，候选名用 Literal 枚举硬约束防幻觉；LLMToolEmulator 用 LLM 生成逼真假结果，工具没实现时也能搭原型。底部三个私有支撑模块是纯函数共享库：重试计算、PII 正则、shell 执行策略。

---

## 第 09 页 · 结构化输出：三种策略 + 图级自纠错

结构化输出是本包特色能力，三种策略。ToolStrategy 把 schema 伪装成一个假工具，配合 tool_choice 等于 any 强制模型调用；支持 Union 类型展开成多个假工具，模型调哪个就按哪个 schema 解析；解析失败时把 pydantic 校验错误包装成 ToolMessage 喂回模型，形成图级自纠错回路——这是它和「一次解析失败就抛异常」做法的本质区别。ProviderStrategy 走厂商原生能力，产出 OpenAI 风格的 response_format JSON Schema 参数，模型直接输出 JSON 文本再解析。AutoStrategy 是自动挡，运行时看模型 profile 档案里有没有声明 structured_output 能力，有就走原生，没有就走假工具；档案缺失时回退一份硬编码的模型名单——这个兜底后面讲问题时还会提到。用户日常只管传一个 Pydantic 模型进去，剩下的自动。

---

## 第 10 页 · create_agent 装配期：八步静态织入

第三部分，实现方式，先看 create_agent 装配期八步。第一步归一化：模型传字符串就调 init_chat_model，系统提示统一转 SystemMessage。第二步响应格式预处理：裸 schema 包成 AutoStrategy，装配期就把假工具建好。第三步收集中间件：展开它们注册的工具，用「类属性是否还是基类方法对象」判断用户覆写了哪些钩子——这个技巧贯穿全包；每个钩子用 langsmith 的 traceable 包一层，可观测性在装配期就织入。第四步构建 ToolNode，函数转 BaseTool，注入 wrap_tool_call 洋葱链。第五步 schema 合并：中间件的 state schema 在前、用户的在后，同名字段后者覆盖。第六步注册节点：model、tools，每个覆写的钩子一个独立节点。第七步连边：before 正序、after 逆序，再挂条件路由。第八步编译，checkpointer 和 store 原样透传，注意 recursion_limit 设成了 9999。强调一句：全部是装配期静态织入，运行期没有任何反射和重装配——这是性能和可预测性的来源；代价是结构化输出工具必须前置声明。

---

## 第 11 页 · 装配产物：中间件钩子编译成图节点

装配的产物就是左边这张图。以两个中间件 m1、m2 为例：从 START 进来，先走 m1、m2 的 before_agent，每个只在运行开始执行一次；然后每轮循环先过 before_model 再进 model 节点；出来后是 after_model，注意顺序反过来了——先 m2 后 m1；然后是条件路由：要么回到 before_model 进下一轮循环，要么把工具调用 Send 给 tools 节点并行执行，要么走向结束。after_agent 也一样是逆序。为什么 after 要逆序？和洋葱模型对称：注册在最前面的中间件「最先进入、最后离开」。没有中间件时，整张图退化成 START、model、tools 三节点循环。再讲 jump_to 机制：中间件钩子可以写一个一次性跳转指令，挂在前缀叫 EphemeralValue 的通道上，只活一个超步，由路由函数消费；但钩子必须用 hook_config 装饰器声明 can_jump_to 目的地，factory 才会为它建条件边——不声明就跳，是跳不动的。

---

## 第 12 页 · 运行期路由：六步决策 + Send 并行扇出

运行期，模型节点出来之后的路由是整个循环的控制中枢，六步决策按优先级排：第一，jump_to 显式指令；第二，找不到 AIMessage——比如历史被摘要清空——直接结束；第三，最后一条 AI 消息没有工具调用，这是经典退出条件；第四，有还没被应答的工具调用，就生成一组 Send 并行扇出，由 ToolNode 做并行执行——同一轮的多个工具调用是真并发；第五，state 里已经有结构化响应，结束；第六，有工具调用但全被人工 ToolMessage 应答过——比如 HITL 拒绝——控制权交回模型。右边还有一个贯穿全包的不变量要记住：每个 tool_call 必须有 ToolMessage 应答，这是 OpenAI API 的硬约束。HITL 拒绝、限流拦截、结构化输出回执，全是靠注入「人工 ToolMessage」实现跳过真实执行、同时保持配对完整的。

---

## 第 13 页 · wrap_model_call 洋葱：右折叠 + 命令累积

wrap_model_call 的洋葱组合是本包最精巧的实现。左边洋葱图：三个中间件 m1、m2、m3，请求从 m1 穿到 m3 再到核心的 model.invoke，响应原路返回。实现是右折叠，右上角代码就两行。三个关键设计：第一，命令累积闭包——中间件可以返回带 Command 的扩展响应，内层返回的命令被拦下来收集到列表里，对外只暴露归一化的 ModelResponse，每一层视角都纯净，不必感知其他层的命令；第二，inner_handler 每次调用先 clear 列表——外层中间件重试时多次调 handler，上一次的残留命令被清空，不会重复应用，重试天然安全；第三，列表第一个中间件是最外层，请求自外向内、响应自内向外。wrap 钩子自由度极高：可以改请求、改响应、可以多次调 handler 实现重试——ModelRetry 就是这么做的；也可以不调 handler 直接短路——ModelFallback 用它换备用模型。

---

## 第 14 页 · 中间件编程模型：12 钩子契约（types.py 2052 行）

中间件编程模型，用户视角的契约。12 个钩子本质是六对：before_agent、before_model、after_model、after_agent 四个是「图节点型」，签名统一收 state 和 runtime、返回状态更新字典；wrap_model_call、wrap_tool_call 两个是「洋葱型」，收 request 和 handler。每个都有 async 版本。基类设计有个细节：before、after 默认空实现，factory 用「类属性是否还是基类方法对象」判断覆写；wrap 默认抛 NotImplementedError，错误信息精确指导「只实现了一半」该怎么办。修改请求的标准姿势是 override——基于 dataclasses.replace 的不可变更新，返回新副本；直接属性赋值已废弃——不可变性是重试安全的前提。state 扩展靠 schema 合并：中间件声明自己的 TypedDict，注解逐字段合并，OmitFromSchema 控制可见性。还有函数式写法：八个装饰器把普通函数直接变成中间件。

---

## 第 15 页 · 模型工厂：注册表 + 声明式操作队列

模型工厂。init_chat_model 的解析链，看左边：拿到「openai:gpt-5」，先看前缀是否在 25 个内置 provider 注册表里——在才拆分，避免把带冒号的模型名误拆；拆不出来再走 12 条前缀推断规则，gpt 开头是 openai、claude 是 anthropic 这类；然后经 lru_cache 缓存的工厂函数延迟导入 partner 包——第一次真正用到才 import langchain_openai。它是全包模型获取的唯一咽喉：factory、降级中间件、摘要中间件、工具选择、工具模拟全都从这儿拿模型。右边的 _ConfigurableModel 更有意思，它是个 Runnable 代理，核心机制叫「声明式操作队列」：对它调 bind_tools 不会绑定到任何具体模型，而是把操作记进队列、返回一个新的代理；真正 invoke 的时候才按当次配置实例化模型，再把队列按序重放。效果是运行时切换 provider 零成本、工具绑定不丢。另外注意 configurable_fields 等于 any 允许运行时改 api_key 和 base_url，docstring 自己都警告了，后面问题部分还会提。

---

## 第 16 页 · 案例精读：HITL 人工审批 与 Shell 持久会话

两个案例精读。第一个，HITL 人工审批，看它怎么用运行时中断。after_model 钩子发现命中的工具调用后，组装一个 HITLRequest，直接调 langgraph 的 interrupt 原语——注意这是运行时中断，不是编译期的 interrupt_before 配置——整图暂停、状态进检查点。人工恢复后按四种决策处理：approve 放行原调用；edit 用编辑后的名字参数重建调用；reject 注入 error ToolMessage；respond 由人类直接代答回复。最妙的是 reject 和 respond 的人工 ToolMessage 恰好「应答」了对应的 tool_call，路由第 4 步发现没有未应答调用，就不 Send，控制权交回模型——工具被跳过，消息配对还完整。代价是它原地改写了 AI 消息的 tool_calls。第二个，ShellTool，882 行，全包最复杂的文件：单进程长驻 bash，每条命令后面跟一行带 uuid 的 marker 来解析退出码，双读线程分别收 stdout 和 stderr；安全靠三档执行策略——Host 宿主直跑、Codex 沙箱、Docker 容器默认断网；会话句柄是 UntrackedValue，不进检查点，中断恢复后还能复用同一个会话。

---

## 第 17 页 · 问题地图：四类问题、15 项

第四部分，存在问题。先给一张问题地图，分四类。A 类是文档与实现的出入，四项——文档说了但代码没做，或者做了但和文档不一致；B 类健壮性隐患，五项，都是真实使用里会踩的坑，头号就是 recursion_limit 等于 9999 带来的死循环风险；C 类安全边界，四项——Shell 默认策略无沙箱、PII 脱敏不可逆还丢字段、运行时配置面过大、输出脱敏不防外泄；D 类架构与工程债——双轨维护成本、目录命名混乱、门面层缺导出完整性检查。下面三页逐类展开。声明一下：所有问题都来自逐文件走查，位置和行号在分析报告的存疑清单里可以复核，不是拍脑袋。

---

## 第 18 页 · 文档与实现出入：docstring 不能当契约用

A 类，文档与实现出入。第一条实锤：PII 模块的 detect_ip，docstring 说支持 IPv6，实现里只有 IPv4 的正则——文档滞后。第二条：文件搜索的 glob_search 工具，文档说结果按修改时间排序，代码里 mtime 收集了，但最后按 glob 匹配顺序原样返回——要么是没写完的排序，要么文档先行。第三条疑似取舍：grep 搜索走 ripgrep 分支时不做文件大小过滤，只有 Python 回退分支有 10MB 上限，注释里没说明为什么。第四条死代码：工具选择模块里的 _render_tool_list 函数定义了但没人调用。这四条单独看都是小事，但合起来说明一个事实：这个包的 docstring 不能当契约用，读代码要以实现为准。下面还有一条关联的设计债务：模型没有 profile 档案时，结构化输出判定回退到一份硬编码的 7 模型前缀名单——名单没覆盖的新模型会被误判走假工具策略，功能不受影响但不是最优路径；另外 wrap 钩子返回的命令只支持 update，goto、resume 都还是 NotImplementedError，官方注释说是先保守开放。

---

## 第 19 页 · 健壮性隐患：五个真实会踩的坑

B 类，健壮性隐患，这一页最重要。第一条也是最重的：create_agent 把 recursion_limit 设成 9999，理由写在注释里——agent 循环由条件边自行终止。但代价是模型如果反复调工具不收敛，引擎不会兜底拦截，会一直烧 token。生产环境必须配 ModelCallLimit 或 ToolCallLimit 中间件，这条要写进使用规范。第二条 sync/async 双轨：只实现异步版钩子却在同步 invoke 里跑，会得到 NotImplementedError——错误信息倒是给了修复指引；内置中间件的异步实现大多是直接委托同步版，意味着阻塞钩子会拖慢整个事件循环。第三条，model.profile 还是 beta，新模型档案可能缺失。第四条，摘要中间件依赖私有 API——model._llm_type 和 _get_ls_params，靠团队约定维持。第五条，摘要模型调用失败会被静默吞成一条错误文本写进历史，而且摘要是整表重建、不可恢复——丢上下文没有任何告警。

---

## 第 20 页 · 安全边界偏激进，架构债在累积

C 类安全边界和 D 类架构债。安全方面三条：第一，ShellTool 默认用 HostExecutionPolicy，宿主直跑、无沙箱、无命令白名单、不解析命令——管道、分号原样交 bash，安全完全取决于使用者选哪档执行策略；docstring 自己也明示：Host 策略下的输出脱敏不能防止秘密外泄，数据已经离开进程了。第二，PII 脱敏是单向不可逆的，没有占位符到原文的还原映射——脱敏后的上下文对模型就是永久失真；而且重建消息只保留关键字段，additional_kwargs 会丢；Windows 下 rlimit 还直接构造报错。第三，init_chat_model 的 configurable_fields 等于 any 允许运行时改 api_key 和 base_url，等于把凭据面开放给调用方。架构债方面：12 个钩子 sync、async 全成对，14 个中间件都要维护两条路径，成本翻倍；目录命名陷阱——langchain_v1 发 langchain、langchain 发 classic——每个新人都要绕一次；CI 只有 check_imports 验证文件可导入，没有导出完整性检查，新增公开符号忘了同步 all 列表不会被发现。

---

## 第 21 页 · 总结：架构值得抄，兜底要自己补

最后总结。值得借鉴五条：一，控制反转——库只做静态织入、执行引擎外包，一万四千行撑起整个标准库，薄得漂亮；二，洋葱中间件加不可变 override，重试安全是架构保证的，不是靠使用者的自觉；三，状态通道语义化——EphemeralValue 表一次性指令、UntrackedValue 表不进检查点的运行时数据，语义即文档；四，结构化输出的图级自纠错回路，错误回喂比抛异常健壮得多；五，声明式操作队列，延迟绑定的思路很优雅。需要警惕四条：生产用必须配调用上限，这是硬要求；安全默认偏激进，Shell 和 PII 的默认值都要按业务重新评估；文档与实现存在出入，以代码为准；双轨维护和私有 API 依赖是长期成本。一句话收尾：LangChain 1.x 用「编译成图」的思路把 agent 框架做薄了，架构值得学；但它把安全与收敛的责任几乎全交给了使用者——用的时候，兜底要自己补。谢谢大家。

---
