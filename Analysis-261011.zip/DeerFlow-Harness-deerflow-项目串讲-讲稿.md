# DeerFlow Harness（deerflow 包）项目串讲 · 讲稿

> 配套幻灯片：DeerFlow-Harness-deerflow-项目串讲.pptx（共 22 页，讲稿与 PPT 备注同源）
> 范围：deer-flow-backend-2.0-m1-rc0/packages/harness/deerflow（195 个生产源文件，约 2.6 万行）
> 依据：Analyze-deer-flow-backend-harness-2.0-m1-rc0.md（逐文件静态分析，195 文件全覆盖）
> 生成：2026-10-11 · 建议时长 40–50 分钟

---

## 第 1 页 · 封面

大家好，今天我串讲的是 deer-flow-backend 2.0-M1-RC0 里的核心包——packages/harness/deerflow。上次分享讲的是外面的网关层，这次我们打开这个包，看它内部是怎么组织的。先给结论：这个包是整个 DeerFlow 2.0 的 Agent 承载框架，不含一行 HTTP 服务代码，但 Agent 运行所需的模型接入、工具、沙箱、记忆、技能、持久化、运行时管理全部实现在这里，规模是 195 个生产源文件、大约两万六千行 Python、17 个模块。今天按四块走：第一部分代码结构，第二部分功能组成，第三部分挑最核心的实现方式拆开讲，第四部分集中讲当前存在的问题。所有结论都出自逐文件静态分析报告，幻灯片上基本都带文件级出处，讲稿里会展开。整个串讲预计 45 分钟左右，欢迎大家随时打断。

> 要点速览：开场定位：deerflow 包是 DeerFlow 2.0 的 Agent 承载框架（harness），195 个生产源文件、约 2.6 万行、17 个模块；不含 HTTP 服务代码。四部分：代码结构、功能组成、实现方式、存在问题。

## 第 2 页 · 项目定位

先定位。这个包自称 harness——背带、承载框架。它承载 Agent 运行所需的全部可复用能力，但不含一行 HTTP 服务代码：FastAPI 网关在仓库的 app/gateway 目录，属于上次分享的范围，它只是这个包的调用方之一。包的定位可以从三个消费入口看：第一，LangGraph Server，langgraph.json 把 deerflow.agents 里的 make_lead_agent 注册成一张 graph，langgraph dev 就能起；第二，FastAPI 网关，调 runtime 里的 run_agent 和 StreamBridge 做 SSE 推流；第三，嵌入式，任何 Python 进程 import DeerFlowClient 就能驱动整套 Agent，连 HTTP 都不需要。右边这张图是它的体量分布：195 个生产文件里，能力层（沙箱、工具、技能这些）占 69 个，接近四成，基础层配置加持久化占 66 个——这是一个能力密度很高的框架包。下面一排术语今天会反复出现，先混个眼熟。

> 要点速览：harness = 承载 Agent 运行所需全部可复用能力、不含 HTTP 代码；三个消费入口：LangGraph Server / FastAPI 网关（app/gateway，范围外）/ 嵌入式 DeerFlowClient；195 文件分层分布：能力层 69、基础层 66、组装层 31、运行时 29。

## 第 3 页 · 分层架构

这是全包的地图，四层结构，依赖方向自上而下。最上面是三种使用方，之前讲过。第一层组装层 agents，31 个文件，职责是把下面所有能力编排成一张可执行的 LangGraph 图：两个工厂——配置驱动的 make_lead_agent 和声明式的 create_deerflow_agent，加上 ThreadState 状态定义、系统提示、记忆子系统和 16 个中间件。第二层能力层，69 个文件、7 个模块，是存在感最强的一层：sandbox 沙箱和 7 个沙箱工具、community 里的容器沙箱和 8 家搜索、tools 工具聚合、skills 技能、subagents 子代理、mcp 接入、guardrails 护栏。第三层运行时层 runtime，29 个文件，管 Run 生命周期、SSE 事件桥、事件落库、LangGraph 持久化工厂和用户上下文——注意它是被网关直接调用的服务化层。最底是基础层：config 一个模块就 25 个文件，models 加 tracing 12 个，persistence 19 个。记住这张四层图，后面所有内容都能挂上去。

> 要点速览：四层：组装层 agents(31) / 能力层 7 模块(69) / 运行时层 runtime(29) / 基础层 6 模块(64)；依赖自上而下；三种使用方在顶端。

## 第 4 页 · 目录地图

这一页是各模块的职责速览，按文件数从大到小排。几个值得点名的：agents 31 个文件管组装；runtime 29 个管服务化；config 25 个文件全是配置——它一个模块就占全包八分之一，后面会单独讲；community 20 个文件一半是容器沙箱、一半是 8 家搜索工具；persistence 是应用数据的 ORM，5 张表；sandbox 13 个文件里有一个全包最大的单文件 tools.py，1583 行，实现了全部 7 个沙箱工具和它们的安全链——这里有个统计口径陷阱，有些工具数出来是 1294 行，差异来自空行和编码处理，引用行号时要小心。右列的 subagents/executor.py 791 行也是大文件，是子代理执行引擎。client.py 单文件 1280 行，是嵌入式客户端的门面。reflection 只有 2 个文件，但它是全包插件化的基石，下一页讲。

> 要点速览：17 模块职责速览：agents 31 / runtime 29 / config 25 / community 20 / persistence 19 / sandbox 13 / models+tracing 12 / tools 11 / skills 9 / subagents 7 / mcp 5 / guardrails·utils 4 / reflection·uploads 2 / client.py。行数陷阱：sandbox/tools.py≈1583、subagents/executor.py≈791。

## 第 5 页 · 三大设计模式

看懂这个包只需要抓住三条设计主线。第一条，一切可插拔：模型用什么类、工具用什么实现、沙箱用哪个 Provider、技能存储和护栏用什么实现，全都是配置里一个 use 字符串，格式是模块冒号类名，由 reflection 模块动态 import 加类型校验——全包有 7 处这样的生产调用点。好处是换实现只改一行 yaml，连安装错误都帮你提示该装哪个包。第二条，横切能力全部以中间件为载体：LangChain 的 AgentMiddleware 提供了一组钩子，这个包把错误处理、护栏、审计、摘要、标题、记忆、循环检测、澄清中断全部做成中间件，主代理链 19 段、SDK 链 14 段，前 8 段基座是共享的——这意味着所有横切逻辑有统一的挂载点和统一的阅读顺序。第三条，读写分离双态：Agent 执行状态走 LangGraph 的 checkpointer，支持内存、SQLite、Postgres 三种后端；而应用数据——run 记录、线程元数据、事件、反馈、用户——走自己的一套 SQLAlchemy 异步 ORM，五张表，和 checkpointer 的表完全分离。这个分离让「回放消息」和「恢复执行」互不干扰。

> 要点速览：①一切可插拔：use: "模块:类" + reflection 动态解析（7 处调用点）；②横切能力全在中间件：lead 19 段 / SDK 14 段、共享 8 段基座；③读写分离：LangGraph checkpointer（图状态）与 SQLAlchemy ORM（5 张应用表）完全分离。

## 第 6 页 · 依赖关系

依赖关系讲三个点。第一，config 是全包地基，六十多个文件引用 get_app_config，任何模块初始化几乎都要碰配置——所以配置加载有热重载和上下文覆盖栈这些细致设计，后面单独讲。第二，看左边这列依赖：client 到 agents，agents 到 tools、models、middlewares，runtime.runs 反过来通过工厂注入使用 agents——运行时层和组装层是反向依赖，靠把 agent 工厂作为参数传进 worker 解开。这种交叉自然产生了循环依赖，而这个包的解法很有个性：不重构，一律函数内延迟 import，代码里有五处以上带注释的 Lazy import。这是团队的明确约定——你新增模块碰到 import 报环，照着 client.py 257 行的写法写就行。好不好另说，第四部分会作为工程债讨论。第三，tool_error_handling_middleware 这个文件名看着不起眼，其实是共享链构建器，lead 和 subagent 的中间件前 8 段都从它构建——改基座只改一处，这是设计得好的地方。

> 要点速览：config 被 60+ 文件依赖；循环依赖统一靠函数内延迟 import（client.py:257 等 5+ 处）；tool_error_handling_middleware.py 是共享链构建器（lead/subagent 共享 8 段前缀）；runtime.runs 经 agent_factory 注入反向使用组装层。

## 第 7 页 · 配置体系

配置是这个包复杂度最高的基础设施，25 个文件。三个来源：第一，config.yaml，AppConfig 聚合根，里面唯一必填的字段是 sandbox.use；它支持 mtime 热重载——文件一改自动重新加载，还支持 ContextVar 覆盖栈做按请求注入，测试的时候很好用；里面的 $VAR 环境变量占位符如果没定义，加载直接抛错，是 fail-loud 风格。第二，extensions_config.json，管 MCP server 和技能开关，注意它没有热重载，改完必须显式调 reload——这和 config.yaml 不一致，是容易踩的坑。第三，环境变量和 .env，import 时就 load_dotenv，tracing 配置完全由环境变量驱动。配置文件本身的查找有四级优先级：显式参数、环境变量、项目根、legacy 候选，都找不到就抛 FileNotFoundError。底部是数据目录约定：所有用户数据在 .deer-flow 目录下按用户和线程分桶；沙箱内看到的是统一的 /mnt 虚拟路径，真实宿主路径绝不暴露给模型。另外配置模块大量使用单例五件套模式——get、load、reload、reset、set 五个函数一套，AppConfig 加载时统一刷新各模块的全局单例，形成双通道。这个双通道在注入 mock 时可能短暂不一致，第四部分会讲。

> 要点速览：三源：config.yaml（mtime 热重载、$VAR 未定义抛错、sandbox.use 唯一必填）、extensions_config.json（无热重载需显式 reload）、.env/环境变量；四级查找优先级；数据目录 .deer-flow 按用户/线程分桶 + /mnt 虚拟路径；单例五件套双通道。

## 第 8 页 · 功能全景

第二部分功能组成。八块能力，上排四个偏 Agent 本体，下排四个偏平台能力。一是对话式超级代理：主代理有 Todo 规划、向用户澄清提问、引用规范、产物呈现这些产品化行为，都是系统提示加中间件共同约束出来的。二是沙箱化执行：Agent 的 bash 和文件操作不直接跑在宿主机上，而是跑在本地映射目录或者 Docker 容器、远程 Pod 里，模型看到的是统一的虚拟路径。三是多源检索，内置 8 家搜索和抓取工具，DuckDuckGo 免费可用，Serper、Tavily 这些配 key 即用，互斥配置选一家。四是长期记忆，对话结束后 LLM 从中抽取事实存成 memory.json，下次会话按 token 预算注入系统提示。五是技能系统，SKILL.md 渐进加载，Agent 能自己创建和修改技能，每次修改都过 LLM 安全审查。六是多代理协作，task 工具委派子代理，还能通过 MCP 接外部工具服务器、通过 ACP 调外部 agent 进程比如 codex。七是可观测，LangSmith、Langfuse 全链路追踪，加 RunJournal 把每次运行的 LLM 和工具事件落库，消息可回放。八是可运营：Run 有完整状态机和多任务策略，支持 SSE 流式、token 统计、点赞反馈、用户数据隔离。这八块接下来分四页展开。

> 要点速览：八大能力：超级代理（Todo/澄清/引用/产物）/ 沙箱执行 / 8 家检索 / 长期记忆 / 技能系统 / 多代理（task+MCP+ACP）/ 可观测（tracing+journal）/ 可运营（Run 状态机+SSE+token+反馈+隔离）。

## 第 9 页 · 模型接入

模型接入层解决两个问题：怎么选模型，和怎么把各家不兼容的后端磨平。选型完全配置驱动：yaml 里每个模型条目有 name、use、model 三个字段，use 指向一个 ChatModel 类，工厂用反射加载，不认识任何具体厂商；因为配置模型 extra 允许任意字段，api_key、base_url 这些直接透传成构造参数。然后是 7 个定制类，每个都是为了解决真实兼容问题：Claude 定制类支持 Claude Code 的 OAuth 登录、自动打 prompt cache 断点、thinking 预算、限流重试；Codex 类最激进，直接自己实现 BaseChatModel，拿 Codex CLI 的 OAuth 凭据去调 ChatGPT 的私有 Responses API；MindIE 和 vLLM 两个是国产和自建后端的兼容——MindIE 带工具调用时干脆放弃流式，全量生成后按 15 字符一块模拟流式输出；三个 Patched 类处理 DeepSeek、MiniMax、Gemini 的思考内容回传问题，共同手法是保留原始消息按位置回注。底部这个细节值得记：关闭 thinking 的四级级联——同一个开关要适配四类后端的禁用方言，显式配置优先，然后依次探测 OpenAI 兼容网关、vLLM 模板参数、Anthropic 原生参数。这是对真实世界后端多样性的工程化妥协。

> 要点速览：create_chat_model 配置驱动反射路由（use 字段 100% 决定 Provider，extra 透传构造参数）；7 个定制类：Claude（OAuth/cache/budget/重试）、Codex（私有 Responses API）、MindIE（XML 工具+模拟流式）、vLLM（reasoning 回传）、Patched×3；thinking 禁用四级级联。

## 第 10 页 · 沙箱与工具

沙箱和工具是 Agent 的手。沙箱是一个七方法抽象——执行命令、读写文件、列目录、glob、grep、局部更新，有两种实现：默认的 LocalSandbox 用路径映射把虚拟路径映射到宿主目录，命令用 subprocess 起、禁 shell、600 秒超时，输出里的宿主路径会双向翻译回虚拟路径；要更强隔离就用 community 里的 AIO 容器沙箱，支持 Docker、苹果容器和远程 Pod 三种后端，容器名用 thread_id 哈希前八位做确定性命名，配合 warm pool 保温复用和孤儿容器对账，冷启动成本压得比较低。工具侧，7 个沙箱工具直接暴露给模型，输出都做了截断策略防止撑爆上下文。最终工具集是四来源聚合：配置工具、内置工具、MCP 工具、ACP 工具，按名字去重先到先得。这里有个很实用的设计叫 deferred tools：MCP 工具多的时候 schema 不进上下文，模型先调 tool_search 检索，命中后晋升，未晋升就调用会被中间件拦截提示——这是对上下文预算的精细管理。

> 要点速览：沙箱七方法抽象双实现：LocalSandbox（PathMapping+subprocess+双向路径翻译）/ AIO 容器（Docker/Apple/远程Pod、sha256 命名、warm pool、idle 600s）；7 个沙箱工具带输出截断；工具四来源聚合去重；deferred tools 经 tool_search 晋升。

## 第 11 页 · 记忆与技能

记忆和技能是两个横跨会话的子系统，都值得整页讲。记忆链路六步：对话结束时 MemoryMiddleware 的 after_agent 钩子把消息过滤——只留人类消息和没有工具调用的 AI 消息，同时用双语正则检测纠错和正强化信号；然后进一个 30 秒滑动防抖队列，同一线程只留最新对话，信号做 OR 合并；Timer 到期后由 MemoryUpdater 调 LLM 做事实抽取，输出结构化 JSON；最后原子写进按用户和 agent 维度隔离的 memory.json。下次会话按置信度降序、2000 token 预算注入。两个细节：一是入库有门槛，置信度低于 0.7 丢弃、大小写不敏感去重、超 100 条按置信度截断；二是摘要中间件删旧消息前有个记忆抢救钩子，先把还没入库的对话立即入队，避免压缩导致记忆丢失。技能系统五点：形态是目录加 SKILL.md；解析双轨，运行时宽松、安装时严格，description 禁尖括号防提示注入；安全扫描 fail-closed，LLM 挂了也拒绝而不是放行；zip 安装全套穿越和炸弹防御；最有趣的是自进化——Agent 可以用 skill_manage 工具自己创建修改技能，但每次写入都要过安全扫描，形成了一个受控的自我扩展回路。

> 要点速览：记忆六步链路（after_agent 过滤/信号检测→30s 防抖→LLM 抽取→原子写→2000 token 注入；0.7 置信度/100 条上限/摘要前抢救）。技能：SKILL.md 双轨校验、LLM 扫描 fail-closed、zip 防御、skill_manage 6 动作自进化。

## 第 12 页 · 多代理与 Run

多代理协作左边是子代理。主代理通过 task 工具委派下级，类型有内置的 general-purpose 和 bash，也可以在配置里自定义，覆盖合并是模仿 Codex 的分层设计。核心设计是上下文隔离而非裁剪：子代理拿全新的状态、自己的系统提示和技能注入，跑完只有最终文本以工具结果的形式回传——中间过程不污染主上下文，但过程中每条新 AI 消息会通过五秒轮询推成 task_running 事件给前端看。防递归的做法很直接：子代理取工具时关掉 subagent 开关，它自己没有 task 工具。并发三层：中间件层截断超额的工具调用、调度线程池三个 worker、九百秒超时。ACP 是另一个维度的扩展，子进程起外部 agent 比如 codex-acp。右边 Run 生命周期：一次执行从 pending 到 running，终态三种——注意状态值是 success、error、interrupted，不是常见的 succeeded 和 failed。多任务策略处理同线程并发新请求：reject 直接 409，interrupt 打断旧的，rollback 打断并回滚——检查和插入放在同一把锁里消除竞态。回滚的实现有讲究：用空 checkpoint 生成新 id 作恢复标记，不复用旧 id，避免破坏 checkpoint 历史链。

> 要点速览：子代理：task 委派（上下文隔离仅回传结果、防递归、5 秒轮询事件、并发三层 ≤3、ACP 子进程）。Run：pending→running→success/error/interrupted；多任务策略同锁消除 TOCTOU；rollback 新 checkpoint id + pending_writes 回放；finally 落库收尾。

## 第 13 页 · 端到端链路

第三部分实现方式，先把端到端链路走通，后面各页拆局部。一次网关对话六步：第一步，前端 POST 创建 run，RunManager 在锁内做策略检查并往 runs 表落一条 pending 记录。第二步双线并行：一条 asyncio 任务跑 run_agent，同时 SSE 端点在 StreamBridge 上订阅等待，带 Last-Event-ID 支持断线重连。第三步准备执行，这里有个深坑：网关不经过 langgraph-cli，直接调 agent.astream，必须手工把 thread_id、run_id、app_config 装进 config context，再构造 Runtime 塞进 configurable，否则中间件和工具拿不到运行时上下文——这是对 langgraph 内部机制的复刻；然后捕获 pre-run checkpoint 快照供回滚。第四步装配 agent，就是 make_lead_agent 五步，下一页展开。第五步流式循环：每个 chunk 先查取消事件，然后序列化、发布到桥；RunJournal 同步把 LLM 和工具事件缓冲落库。第六步收尾：终态三分支，rollback 分支会用第三步的快照恢复，最后 token 统计落库、线程标题同步、发布结束帧。底部这句要记住：每次工具调用都被四层 wrap_tool_call 包裹——审计、护栏、澄清中断、错误兜底，然后才到工具本体。

> 要点速览：六步：创建 Run（锁内策略检查+落库）→ 双线并行（Task + SSE 订阅）→ 准备（手工注入 runtime context + pre-run 快照）→ 装配（make_lead_agent）→ 流式循环（astream→serialize→publish + journal 缓冲）→ 收尾（三分支+flush+统计+end 帧）。工具调用穿四层 wrap。

## 第 14 页 · Agent 装配

主代理的装配工厂五步。第一步合并运行时配置：LangGraph 的 configurable 和 context 两处都要读，合并时 context 优先——模型名、思考开关、计划模式、子代理开关这些都从这里来，所以同一个线程可以按请求切换行为。第二步解析模型，三级回退：请求里指定就用的，否则看这个自定义 agent 的配置，再否则用配置文件第一个模型；如果 thinking 开了但模型不支持，自动降级给警告而不是报错。第三步建模型、第四步取工具，都讲过了。第五步是重头：先套系统提示模板——记忆段、技能段、子代理编排段、延迟工具段、日期段，按开关拼接；再构建 19 段中间件链，下一页专讲；最后 create_agent 编译成图。右边是双路径设计：make_lead_agent 是配置驱动的生产入口；create_deerflow_agent 是给 SDK 用户的声明式工厂，用 RuntimeFeatures 开关加 Next/Prev 锚点装饰器控制中间件位置，14 段。两条链共享 8 段基座，且都有一个硬不变量——Clarification 必须是链尾，插错了会被强制调整回来。一个工厂两种用法，但不变量只有一份代码维护。

> 要点速览：五步：合并运行时配置（context 优先）→ 模型三级回退+能力降级 → create_chat_model → 四来源工具 → 提示+19 段中间件+编译。双路径：make_lead_agent（配置驱动）与 create_deerflow_agent（声明式 @Next/@Prev，14 段）；共享 8 段基座，Clarification 恒链尾不变量。

## 第 15 页 · 19 段中间件链

中间件链是这个包最有含金量的设计，19 段，顺序本身就是语义。上面八段是基座，主代理和子代理共享：线程数据、上传注入、沙箱生命周期、悬空调用修补、LLM 错误处理、护栏、沙箱审计、工具错误兜底。下面十一段是 lead 专属：摘要、Todo、token 统计、标题、记忆、看图、延迟工具过滤、子代理限流、循环检测、自定义，最后澄清中断收尾。带星号的按条件启用。右边是排序理由，每条都是实际约束：ThreadData 必须第一，因为后面所有中间件要 thread_id；悬空修补必须在模型看到历史前完成；摘要要早，让模型看到瘦身后的上下文；澄清必须最后，它是所有工具调用的中断出口。这些约束写在源码 228 到 237 行的注释块里。三个亮点：错误处理中间件做了指数退避加重试优先级加熔断三态，熔断打开后直接降级成一条友好的 AI 消息而不是把异常抛给用户；循环检测两层——哈希层把 read_file 按 200 行分桶做规范化，容忍顺序读大文件又不漏检，频次层兜住每次读不同文件的情况，硬停时剥掉 tool_calls 迫使模型给纯文本终答；摘要中间件有个很妙的技能拯救机制——删旧消息前，先把读技能目录那段消息束救回来，因为技能内容一旦被删，模型就失忆了。

> 要点速览：基座 8 段共享 + lead 专属 11 段；排序理由：ThreadData 先（thread_id 依赖）、Dangling 在模型见历史前、摘要要早、Clarification 恒最后。亮点：LLMErrorHandling（退避+熔断+降级）、LoopDetection（规范化哈希+频次双层）、Summarization（技能拯救+消息拆分克隆）。

## 第 16 页 · 沙箱安全链

安全是这个包做得最扎实的部分，整页讲沙箱六道防线，从里到外。第一道在沙箱实现内部：任何路径命中挂载映射后，拼接、resolve、再验证结果仍在映射根内，逃逸直接抛权限错误。第二道在工具层：模型传进来的路径必须是白名单虚拟路径——user-data 读写、skills 和 acp-workspace 只读——显式拒绝点点。第三道是 bash 命令静态校验：拦 file 协议、分词后拦点点、cd 目标必须在白名单、十六个高危命令拒绝裸根路径参数——注意源码自己承认这是 best-effort，不是安全边界，真正的边界是第四道：本地沙箱默认整体禁用 bash，要显式开 allow_host_bash。第五道是输出方向：工具输出里的宿主真实路径全部反译回虚拟路径，模型永远看不到宿主路径，这也顺带防了提示注入里的路径诱导。第六道是审计：十七条高危正则直接拦、五条中危告警、引号没闭合一律拒绝，全部写 JSON 审计日志。右边同族防护一栏：上传的防符号链接攻击用了打开不跟随加双重 stat 校验加硬链接数检查，消除 TOCTOU；技能、护栏、数据隔离、看图校验各自有全套防御。这一页如果只记一句：纵深防御，每道防线都不信任前一道。

> 要点速览：六道防线由内向外：挂载内 resolve 校验 → 工具层虚拟路径白名单拒.. → bash 命令静态校验（best-effort）→ host-bash 默认禁用 → 输出脱敏回掩零泄漏 → 审计分级 17 高危 block。同族：上传 O_NOFOLLOW、技能 zip 防御、护栏 fail-closed、数据双轨隔离、view_image 魔数校验。

## 第 17 页 · 并发套路

这个包的并发代码有五个反复出现的套路，掌握了基本能读懂所有异步部分。第一，隔离事件循环：子代理执行器起了一条常驻守护线程跑自己的 loop，因为 task 工具是同步函数、却可能在一个正在运行的循环里被调，直接 asyncio.run 会炸；投递到隔离 loop 执行，还用 context.run 把 ContextVar 带过去。第二，同步跑 async 的三态适配：MCP 缓存初始化要判断当前处于哪种循环状态——运行中、未运行、没有——分别用线程池、run_until_complete、直接 run 三种方式，这是同步客户端和异步生态缝合的典型代码。第三，防抖队列：记忆更新不着急，三十秒滑动窗口，同一线程只留最新，信号做 OR 合并保证纠错信号不丢。第四，事件循环感知调度：更新记忆要调 LLM，如果在运行中的循环里直接跑会跨循环复用 httpx 连接导致崩溃——这是真实 issue 2615，解法是提交到专用线程池阻塞等待。第五，协作式取消：没有任何强杀，worker 每个流 chunk 检查中止事件，子代理在迭代边界检查自己的取消事件。底部这个贯穿性陷阱单独强调：ContextVar 不跨线程，所有后台任务要么入队时捕获需要的值，要么显式复制上下文。

> 要点速览：五套路：隔离事件循环（守护线程+context.run）、同步跑 async 三态（mcp/cache）、30s 防抖队列（按 thread 合并）、事件循环感知调度（专用线程池，issue #2615）、协作式取消（chunk/迭代边界检查）。贯穿陷阱：ContextVar 不跨线程。

## 第 18 页 · StreamBridge 与事件落库

StreamBridge 是 Agent worker 和 SSE 端点之间的事件桥，设计很漂亮。核心思路不是每个订阅者一条队列，而是每个 run 一份有界事件日志：生产者 publish 时在锁内 append 并 notify_all 广播，所有订阅者被同时唤醒，各自拿着独立的游标去读，消费者处理帧的时候不持锁，慢消费者不拖累生产。窗口默认 256 条，超过从头裁剪，但偏移量是全局单调的，所以两件事成立：一是 Last-Event-ID 断线重连，客户端带上最后收到的事件 id，服务端从对应偏移续发；二是慢消费者检测——如果你的游标已经被裁剪掉了，就跳到最早保留事件，丢旧保活。心跳只在空闲时发。右边是事件落库的三个实现：db 实现在事务里取最大 seq，有属主过滤和 trace 截断，生产推荐；jsonl 每 run 一个文件，但它是同步 IO 会阻塞事件循环，多进程还会 seq 冲突；memory 是默认，重启即失。RunJournal 负责把 LangChain 回调变成结构化事件，缓冲 20 条批量刷，避免高频写 SQLite。最后右下角这个约束记住：整套机制建立在 asyncio.Condition 上，绑定单个事件循环——单进程专用，redis 桥还是规划，这直接引出第四部分的问题。

> 要点速览：一份有界事件日志（默认 256）+ Condition 广播扇出；独立游标、Last-Event-ID 回放、慢消费者跳窗保活、空闲心跳、锁外 yield。落库三实现：db（事务 seq，推荐）/ jsonl（同步 IO+多进程冲突）/ memory（默认易失）。RunJournal 缓冲 20 批量刷。约束：单进程，redis 未实现。

## 第 19 页 · 问题全景

第四部分问题。先说总体判断：这个包没有致命伤，但有四类明确的工程债。A 类架构与扩展性，最要紧：StreamBridge 和同步 checkpointer 都绑定单个事件循环，redis 桥只有配置没有实现，所以当前整个服务只能单进程跑——单进程内它是健壮的，但水平扩展这条路现在走不通；JSONL 事件存储的同步 IO 和多进程 seq 冲突也是同一类问题。B 类数据层：alembic 的迁移目录是空的，建表全靠 create_all，意味着生产环境改表结构没有迁移工具兜底；thread_meta 的元数据过滤是取一大窗口到 Python 里再过滤，数据量上去会慢，源码里有 TODO 注释承认；users 表的部分唯一索引用了 sqlite_where 语法，只对 SQLite 生效，换 postgres 语义就变了。C 类代码健康：延迟 import 化解循环依赖已经是模式化写法；配置双通道单例在测试注入时可能短暂不一致；还有跨模块调私有函数。D 类一致性：extensions 配置没有热重载，和主配置行为不一致容易让人想当然；注释和实现不符的至少一处；行数统计口径差异；以及 BASIC_MODEL 这种旧机制已删除但旧文档还在的情况。下两页分别过 bug 级明细和隐性约定。

> 要点速览：四类：A 扩展性（单进程绑定、redis 未实现、jsonl 冲突）；B 数据层（alembic 空、thread_meta Python 过滤、sqlite_where 差异）；C 代码健康（延迟 import、双通道单例、私有耦合）；D 一致性（extensions 无热重载、注释不符、行数口径、BASIC_MODEL 已移除）。

## 第 20 页 · 缺陷清单

这页是逐条验证过的缺陷清单，九项，性质分四档。第一项是唯一的潜在真 bug：readability 的 Article 类，url 字段声明了但构造时没赋值，to_message 方法用到它会直接 AttributeError——现在没触发是因为调用方都只调 to_markdown，但这是个埋着的雷。第二项注释与实现不一致，list_by_thread 说好最新的在前，实现没反转。第三到第五是预留未接线：timeout 状态枚举没人赋值、OpenAI 格式转换器没人调、同步 Store 工厂没人用——这些不是错，但读代码时容易以为是活代码。六七是小的死代码和冗余。第八项值得注意：skill_manage_tool 直接 import 了 mcp 模块的私有函数，重构 mcp 时会连带炸掉，这是跨模块私有耦合。第九项 pyproject 里声明了 duckdb 和 kubernetes 两个依赖但全包零 import，装环境时白白多装。底部还有两处语义缺口：桥的 close 不唤醒等待者，清理函数实现了但网关没调。这些单看都不致命，但合起来说明项目处于 M1 快速迭代期，收尾还没做。

> 要点速览：9 项：Article.url 未赋值（潜在 bug）、list_by_thread 注释不符、timeout 死枚举、converters/get_store 预留未接线、worker 冗余赋值、_is_chinese 死代码、私有函数耦合、duckdb/kubernetes 疑似预留依赖；另 bridge.close 不唤醒订阅者、cleanup 未被调用。

## 第 21 页 · 隐性约定

最后一批是隐性约定——不写进文档一定踩坑的那种，我挑了八条最疼的。第一条，澄清中间件必须在链尾，代码里有强制修复，你插错位置它不报错、悄悄帮你挪回去，排查时会莫名其妙。第二条是团队的既有约定：碰到循环依赖写延迟 import，不要自作主张重构，前面讲过。第三条，默认模型就是配置列表第一项，BASIC_MODEL 环境变量已经不存在了。第四条，本地沙箱默认禁 bash，就算开了 allow_host_bash，源码也明说这不是安全边界。第五条 ContextVar 不跨线程，重复强调因为它到处都是。第六条我标了橙色，是最阴的一个：aiosqlite 绑定不了原生 UUID 对象，漏了 str() 转换不会报错，而是事务静默回滚、worker 挂起，表现为请求无响应，极难排查——user_context 里专门写了注释和强转。第七条，多副本部署别用 jsonl 事件存储。第八条，Run 的终态字符串是 success、error、interrupted，对接前端别按 REST 惯例想当然写 succeeded。完整的十三条在分析报告第十章，还有推荐的阅读顺序和常见修改需求的切入点，比如加一个模型、加一个工具、加一个中间件分别该动哪里。

> 要点速览：8 条：Clarification 恒链尾、循环依赖写延迟 import、默认模型 models[0]（BASIC_MODEL 已删）、本地默认禁 host bash、ContextVar 不跨线程、aiosqlite 不绑 UUID（静默回滚挂起）、多副本禁 jsonl、终态是 success/error/interrupted。

## 第 22 页 · 总结

总结三句话。第一，骨架优秀：四层分层、插件化、中间件化这三条主线贯彻得非常一致，双链共享基座让主代理和子代理行为统一，读懂一处就能读懂全局，这对二次开发是极大的红利。第二，安全细节扎实：六道防线、输出零泄漏、fail-closed 的护栏和技能审查、成体系的路径攻击防御，在开源 Agent 框架里是少见的水准。第三，工程债明确：单进程约束、迁移缺失、延迟 import、预留 API，都是 M1 快速迭代的典型代价，不是设计能力问题。改进优先级建议四条：P1 把迁移和事件存储这两件数据层基础补齐，风险最低收益直接；P2 实现 redis 桥解锁水平扩展，是架构上唯一的大动作；P3 下推 thread_meta 过滤；P4 做一轮代码卫生。留几分钟 Q&A，逐文件分析报告和配套讲稿都在项目目录里，欢迎会后翻阅。谢谢大家。

> 要点速览：三句话：骨架优秀（分层/插件化/中间件化一致）、安全细节扎实（六道防线+fail-closed 体系）、工程债明确（单进程/迁移缺失/延迟 import/预留 API）。改进 P1 补迁移+db 事件存储、P2 redis 桥、P3 过滤下推、P4 代码卫生。

