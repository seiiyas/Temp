# Agent Loop 对比分析报告（详细版）：OpenClaw 2026.5.12 vs LangChain 1.3.0

对比对象：
- **OpenClaw 2026.5.12**（`openclaw-2026.5.12/`）：TypeScript 自托管个人 AI 助手（Gateway 常驻进程），agent 循环位于 `src/agents/pi-embedded-runner/`
- **LangChain 1.3.0**（`langchain-langchain-1.3.0/libs/langchain_v1/`）：Python agent 框架库（无进程形态），agent 循环由 `agents/factory.py` 的 `create_agent` 编译为 LangGraph StateGraph

**范围界定**：本文聚焦"agent loop"——"模型调用 ↔ 工具执行"迭代循环的本体、控制流、扩展点、状态模型、工具子系统、上下文管理、失败处理、并发/持久化/流式/终止。OpenClaw 的渠道/网关/插件体系与 LangChain 的 chat_models/embeddings 门面仅在影响循环时提及（完整单侧分析见 `Analyze-openclaw-2026.5.12.md`、`Analyze-langchain-langchain-1.3.0.md`）。

**引用约定**：`文件:行号` 均已在两侧源码中核对。OpenClaw 路径省略前缀 `src/agents/`；LangChain 路径省略前缀 `libs/langchain_v1/langchain/agents/`。

---

## 1. 总览

### 1.1 基本盘对照

| 维度 | OpenClaw 2026.5.12 | LangChain 1.3.0 |
|---|---|---|
| 产品形态 | 常驻服务（Gateway 进程，`~/.openclaw/` 状态目录，OS 服务监督） | 库（`pip install langchain`，无进程、无 IO） |
| 语言/运行时 | TypeScript / Node 22 | Python 3.10+ |
| 循环所有权 | **内层循环外包**：`@earendil-works/pi-coding-agent@0.74.0` + `pi-ai@0.74.0`（package.json 锁版）执行 model↔tool 迭代；OpenClaw 拥有循环外的一切运维层 | **循环自有**：`create_agent` 把循环编译成图节点与条件边；执行引擎是外部依赖 LangGraph，但图拓扑归本包 |
| 循环载体 | 命令式运行时：`runEmbeddedPiAgent`（run.ts，3135 行）→ `runEmbeddedAttempt`（run/attempt.ts，4209 行） | 声明式产物：`create_agent`（factory.py:697-1679，1885 行）返回 `CompiledStateGraph` |
| 入口 | 多入口汇于同一循环：渠道消息（auto-reply）、CLI `agent` 命令、cron 定时作业、commitments 抽取、记忆冲刷、Talk 会话、OpenAI 兼容 HTTP | 单一入口：`graph.invoke/stream/astream`（用户进程内） |
| 扩展模型 | 无统一中间件抽象；四套子系统级拦截点：生命周期 hooks、工具策略管道、上下文引擎注册表、provider stream wrapper（另有 harness 整体替换） | 统一中间件编程模型：`AgentMiddleware` 12 钩子 + 8 个函数装饰器 + 15 个内置中间件 |
| 循环相关代码规模 | 仅 18 个核心循环文件即 20,340 行（§15）；`src/agents/` 全域约 430 文件 | `agents/` 全部 22 文件 10,987 行（含全部中间件与结构化输出） |
| 默认循环上限 | `MAX_RUN_LOOP_ITERATIONS`（按认证档案数解析，run.ts:901）+ 工具全局熔断（30）+ 空闲断路器 + 分级超时 | `recursion_limit=9_999`（factory.py:1665），终止完全由条件边决定；预算治理是可选中间件 |
| 流式语义 | 一等公民：专设 1147 行流式状态机 + 渠道块投递规范 | 引擎透传：节点边界只见完整消息，流式策略归还调用方 |
| 持久化 | 会话 JSONL 转写文件（跨回合、跨进程资产）+ 跨进程写锁 | LangGraph checkpointer（可插拔）+ add_messages reducer |
| 结构化输出 | 无循环内机制（由独立抽取路径承担） | 一等公民：三策略 + 图级自纠错回路 |

### 1.2 一句话总结

这是两种不同物种的 agent loop——LangChain 1.3.0 把循环当作**可组合的静态结构**（编译期织入中间件、图级条件路由、并行工具扇出，追求编程模型的正交与优雅）；OpenClaw 2026.5.12 把循环当作**需要运营的长期资产**（认证档案轮换、失败分类学、行为级重试、上下文压缩管线、跨进程会话锁、块级流式投递，追求 7×24 渠道场景下的存活率与最终可交付）。前者回答"如何定义一个 agent"，后者回答"如何让一个 agent 永远跑得下去"。

---

## 2. 循环本体

### 2.1 LangChain：编译成图的循环

#### 2.1.1 装配产物

`create_agent` 装配期 8 步（factory.py:849-1679：模型归一 → 结构化输出预处理 → 中间件收集/包装链 → ToolNode 构建 → schema 合并 → 节点注册 → 边与路由 → 编译）产出静态图。以两个中间件 m1、m2 为例：

```
START → m1.before_agent → m2.before_agent          （每 run 一次，正向）
      → m1.before_model → m2.before_model          （每轮循环入口，正向）
      → [model 节点]
      → m2.after_model → m1.after_model            （每轮循环出口，逆序）
      ── 条件路由 model_to_tools（六步决策）──
          ├─ END 方向 → m2.after_agent → m1.after_agent → END（逆序）
          ├─ tools → [tools 节点] ── 条件路由 tools_to_model（四步）──
          │        ├─ 回 loop_entry（m1.before_model）
          │        └─ END 方向
          └─ 回 model（结构化重试/人工应答回流）
无中间件时退化为 START → model ⇄ tools → END；
无工具时 START → model → END（或 model→model 结构化重试环 :1553-1564）。
```

#### 2.1.2 model 节点内部（factory.py:1318-1384）

```
model_node(state, runtime):
  request = ModelRequest(
      model=装配期模型, tools=default_tools(装配期基线),     # :1320-1329
      system_message=装配期提示, response_format=初始策略,
      messages=state["messages"], state=state, runtime=runtime)
  if 无 wrap_model_call 中间件:
      return _build_commands(_execute_model_sync(request))  # :1331-1333
  result = wrap_model_call_handler(request, _execute_model_sync)  # 洋葱
  return _build_commands(result.model_response, result.commands) # :1335-1336

_execute_model_sync(request):                              # :1291-1316
  model_, 策略 = _get_bound_model(request)   # 每轮重新绑定：中间件改过的 tools/策略生效
  messages = [system_message?, *request.messages]
  output = model_.invoke(messages)           # 同步核心就这一行
  return ModelResponse(_handle_model_output(output, 策略))
```

三个要点：
1. **每轮重建请求**：`ModelRequest` 每次进入 model 节点重新组装，中间件通过 `request.override()` 在洋葱内改写 tools/system_message/model/response_format，下一轮绑定自动生效——请求是**每轮数据**而非装配期冻结。
2. **绑定发生在调用瞬间**（`_get_bound_model` :1162-1289）：结构化输出策略在此刻自动检测升级/降级（AutoStrategy → Provider/Tool）；无 wrap_tool_call 时未注册工具名直接抛结构化错误（`DYNAMIC_TOOL_ERROR_TEMPLATE` :111-135，给模型两种修复方案）。
3. **同步/异步双轨注册**：`RunnableCallable(model_node, amodel_node)`（:1387），同一张图两种执行模式。

#### 2.1.3 三条路由函数（全文核对）

**model_to_tools（循环出口，factory.py:1724-1769）六步优先级**：
1. `state["jump_to"]` 显式跳转 → `_resolve_jump`（:1728-1733）——中间件的最高优先级控制通道；
2. 找不到 AIMessage（消息被清空）→ end（:1737-1739）；
3. 最后一条 AIMessage 无 tool_calls → end（**:1745 经典退出条件**）；
4. 存在"未被 ToolMessage 应答且非结构化输出工具"的调用 → `[Send("tools", [tc]) for …]` **并行扇出**（:1748-1759；注释明示 ToolRuntime 执行时才水合 state，修复旧实现 O(N²) 的 TASKS 写放大）；
5. state 已有 `structured_response` → end（:1762-1763）；
6. 有 tool_calls 但全被人工 ToolMessage 应答（HITL reject/respond）→ 回 model（:1765-1767）。

**tools_to_model（工具出口，:1806-1830）四步**：
1. 无 AIMessage → 回 model（:1809-1811，与 model_to_tools 第 2 步方向相反——工具后必须让模型说话）；
2. 全部客户端侧工具 `return_direct` → end（:1813-1821）；
3. 结构化输出工具已执行 → end（:1823-1825）；
4. 默认回 model。
注意：此路由**不检查 jump_to**——跳转指令只在 loop_exit 被消费（EphemeralValue 一个超步即失效，types.py:354），工具后的去向是固定的。

**model_to_model（结构化重试环，:1777-1794）**：仅当无工具但有结构化输出工具时挂载；jump_to 优先 → 已有 structured_response → end → 默认回 model 重试。

**_add_middleware_edge（:1856-1880）**：钩子节点默认静态边；声明了 `can_jump_to` 的钩子（装饰器 `hook_config` 写入 `__can_jump_to__`，types.py:856-907）挂**条件边**——jump 优先，落空走 default。目的地图按声明扩容（"end"/"tools"/"model"）。

#### 2.1.4 洋葱组合器（factory.py:221-310）

```python
def compose_two(outer, inner):
    def composed(request, handler):
        accumulated_commands = []                    # :282
        def inner_handler(req):
            accumulated_commands.clear()             # :286 重试安全：重入即清残留
            inner_result = inner(req, handler)
            if 是组合结果: accumulated_commands.extend(内层命令)  # :289
            return 内层的 ModelResponse               # :290 每层视角纯净
        outer_result = outer(request, inner_handler)
        return _to_composed_result(outer_result, extra_commands=…)
    return composed
# 右折叠：[m1,m2,m3] → m1(m2(m3(核心)))
```

两项精巧设计：**命令累积闭包**（内层 ExtendedModelResponse 附带的 Command 被逐层拦下收集，各层中间件互不感知，最终统一 `_build_commands` 归并进图更新，命令顺序保持内层先外层后）；**clear() 防重放**（外层多次调 inner_handler 重试时，上次的命令不会重复应用）。

`_build_commands`（:179-218）拒绝 `goto/resume/graph` 型 Command（抛 NotImplementedError）——中间件能改状态，但不能劫持图游标；路由权保留给 jump_to 通道。

#### 2.1.5 循环不变量

- 退出条件只有一个语义：**模型不再发起未应答的工具调用**。所有其他退出（jump_to、限额、return_direct、结构化完成）都是对这个语义的补充通道。
- 循环深度事实无界（recursion_limit=9999，:1665 注释引 langgraph#7313），防失控完全是可选件。
- AI/Tool 消息配对完整性由路由第 4/6 步与 HITL 的人工 ToolMessage 机制共同保证（OpenAI API 要求每个 tool_call 必须有应答）。

### 2.2 OpenClaw：外包内核 + 三层运维循环

#### 2.2.1 层级总图

```
外层 while (nextIndex < profileCandidates.length)        run.ts:841  认证档案轮换
  ├─ 档案候选序：resolveAuthProfileOrder(:726) + createEmbeddedRunAuthController(:784)
  ├─ thinkLevel 重置回初始值 + attemptedThinking 清空      :853-854
  中层 while (true) 受 MAX_RUN_LOOP_ITERATIONS 约束        run.ts:1153 / :901
  │   ├─ 重试上限判定 → resolveRunFailoverDecision(stage:"retry_limit")  :1163-1167
  │   ├─ 每轮组装 prompt = 原始提示 + 定向重试指令五选 N    :1194-1210
  │   ├─ buildAgentRuntimePlan（harness/档案/thinking/extra-params）:1215-1243
  │   └─ runEmbeddedAttemptWithBackend(:1262)
  │       └─ runEmbeddedAttempt（attempt.ts:784）
  │           ├─ 沙箱解析(:840) + 技能 env/提示
  │           ├─ acquireSessionWriteLock(:1586 跨进程) → repairSessionFile(:1604)
  │           ├─ SessionManager.open 包 guardSessionManager(:1624 工具结果守卫)
  │           ├─ 上下文引擎 bootstrap(:1645-1673)
  │           ├─ 关闭 pi 自动压缩，改用 OpenClaw 策略(:1704)
  │           ├─ createOpenClawCodingTools(:983) + createOpenClawTools
  │           ├─ createAgentSession(:1863 ← pi-coding-agent)
  │           ├─ subscribeEmbeddedPiSession(:2649 订阅事件流)
  │           └─ activeSession.prompt()(:2643/:3532)
  │                 ═══ [pi 内核：LLM SSE ↔ 工具执行循环] ═══
  │                 事件流 → 块切分 → onPartialReply/onBlockReply → 渠道草稿
  │           溢出预检/超大结果截断(:2898)/空闲断路器/压缩续接/steer(:2762)
  └─ 失败分类 classifyFailoverReason → resolveRunFailoverDecision → 五动作
```

#### 2.2.2 外层：认证档案轮换

- 认证档案 = 同一厂商下的多套凭据（auth-profiles：persisted.ts 1251 行存储、store.ts 711 行、oauth-manager.ts 613 行 OAuth 刷新），候选序由 `resolveAuthProfileOrder` 构造；`createEmbeddedRunAuthController` 管理运行时切换。
- **thinking 级别参与重试**：`attemptedThinking: Set<ThinkLevel>` 记录已试过的思考档位（:779），某些失败会升档重试（:832 `thinkLevel = next`）；换档案时整体重置（:853-854）；模型回退时可指定 fallback thinking（:2229/:2283）。**推理预算被当作与凭据同级的重试维度**。
- 提供商特例直接进 prompt 预处理：Anthropic 的拒答魔法串被洗掉（`scrubAnthropicRefusalMagic`，:1196）。

#### 2.2.3 中层：重试预算与上限决策

`MAX_RUN_LOOP_ITERATIONS = resolveMaxRunRetryIterations(profileCandidates.length)`（:901）——预算与档案数联动（档案多则允许更多次同模型重试）。到达上限时走 `stage:"retry_limit"` 决策（:1163-1167）：配置了回退且失败属"实质失败"→ `fallback_model`；否则 `return_error_payload`（带 usage、livenessState:"blocked" 的错误载荷，:1168-1186）。

#### 2.2.4 行为级重试子系统（LangChain 完全没有的层）

API 没失败但**模型行为不对**时，OpenClaw 注入定向纠正指令重试（run.ts:2597-2740，四类检测器 + 各自预算）：

| 行为缺陷 | 检测器 | 纠正指令 | 预算 | 附加动作 |
|---|---|---|---|---|
| **计划未执行**（assistant 输出了计划但没调工具） | `resolvePlanningOnlyRetryInstruction`（:2606） | "act-now steer" | `maxPlanningOnlyRetryAttempts` | 从计划文本提取步骤发 `agent.plan` 事件供 UI 展示（:2642-2665） |
| **仅推理无答案**（只有 reasoning 内容，无可见文本） | `resolveReasoningOnlyRetryInstruction`（:2617） | "visible-answer continuation" | `maxReasoningOnlyRetryAttempts` | — |
| **空回复** | `resolveEmptyResponseRetryInstruction`（:2628） | 可见答案续答 | `maxEmptyResponseRetryAttempts` | — |
| **压缩吞掉最终答案**（本回合发生过压缩、payload 为 0、无副作用、未中止） | 条件组合（:2717-2729 七项全查） | `COMPACTION_CONTINUATION_RETRY_INSTRUCTION`（压缩后转写续接） | **仅 1 次**（:2729） | `postCompactionGuard.armPostCompaction()`（:2737） |

另有第五类 `ackExecutionFastPathInstruction`（:953，确认执行快路径指令）随每轮 prompt 组装（:1198-1210 的五元数组 filter 后拼接）。cron 触发等场景下空回复可按"静默成功"处理（`shouldTreatEmptyAssistantReplyAsSilent` :2597），不触发重试。

**回合中途溢出预检**（attempt.ts:653-701）：溢出时注入带 `MID_TURN_PRECHECK_ERROR_MESSAGE` 的合成 assistant 错误消息；下一轮 attempt 开始前，从活会话 state **和** SessionManager 持久文件双侧移除该合成消息（经 `_rewriteFile` 私有钩子，:690-701），并以 `MID_TURN_PRECHECK_CONTINUATION_PROMPT` 作为下一轮 prompt 覆盖（run.ts:985/:1893）——即"溢出中断后无损续跑"。

#### 2.2.5 failover 决策状态机（failover-policy.ts:113-193，逐行核对）

`classifyFailoverReason` 产出 FailoverReason（timeout / format / model_not_found / session_expired / 过载 / …），`resolveRunFailoverDecision` 按 stage 输出五动作：

| stage | 输入要点 | 决策规则 |
|---|---|---|
| retry_limit | fallbackConfigured、failoverReason | 实质失败（非 timeout/model_not_found/format/session_expired，:70-78）且配置回退 → fallback_model；否则 return_error_payload |
| prompt | externalAbort 优先 surface；未轮换过档案且应轮换（失败且非超时且非终态格式失败，:87-93）→ rotate_profile；配置回退且失败 → fallback_model；否则 surface_error |
| assistant | externalAbort → surface；终态格式失败（format 且不允许格式重试，:80-85）→ surface；应轮换（失败或非压缩/非工具期超时，:95-103）且未轮换 → rotate_profile；应轮换且配置回退 → fallback_model；不应轮换 → continue_normal；其余 surface |

规则里嵌着运营知识：**压缩期间超时不轮换凭据**（大概率是上下文太大而非凭据失效）；**格式失败默认终态**（换凭据也救不了）；**工具执行期超时不轮换**（先让工具收尾）。

### 2.3 生命周期逐步对照

| 阶段 | LangChain | OpenClaw |
|---|---|---|
| T0 触发 | 用户代码 invoke | 消息到达/cron/命令，auto-reply 策略层先行（斜杠命令快路径、媒体/链接理解增强） |
| T1 准入 | 引擎加载 checkpoint | **双 lane 排队**（会话 lane 嵌套全局 lane，run.ts:384-425）+ throwIfAborted 双检 |
| T2 装配 | 装配期已完成（图是静态的） | 每 run 动态解析：hooks（before_agent_reply 可接管 :510）→ harness（:552）→ 模型（:561）→ 认证候选序（:726）→ 上下文引擎（:1062） |
| T3 会话打开 | state 就绪（无 IO） | 跨进程写锁（:1586）→ 转写修复（:1604）→ SessionManager.open + 守卫（:1624）→ 上下文 bootstrap（:1645） |
| T4 每轮预处理 | before_model 钩子链（图节点，可 jump_to） | pi 内核内部 + 外层注入的重试指令（改 prompt） |
| T5 模型调用 | model 节点洋葱核心 `model_.invoke` | pi 内核经 SSRF 防护 fetch 直连厂商 SSE（provider-transport-fetch.ts，527 行）+ 插件 wrapStreamFn |
| T6 输出处理 | after_model 逆序链 + `_handle_model_output`（结构化解析/自纠错） | 订阅状态机：`<think>` 剥离、块切分、usage 累积、liveness 追踪 |
| T7 工具执行 | tools 节点 Send 并行扇出（wrap_tool_call 洋葱） | pi 循环内执行：策略管道 → before_tool_call → 执行 → 循环检测 |
| T8 终止 | 条件边（无 tool_calls）/ jump_to / return_direct | pi 收敛 + 熔断器兜底 + 行为检测（四类缺陷重试） |
| T9 收尾 | after_agent 逆序链 → END → 输出 schema 过滤 | 转写 JSONL 落盘 + usage 计价 + 承诺抽取入队 + 块投递收尾 |

---

## 3. 状态与数据模型

| 维度 | LangChain | OpenClaw |
|---|---|---|
| 循环状态载体 | 图 state（TypedDict，可插拔 checkpointer 持久化） | pi 会话内存态 + 会话 JSONL 转写文件（双份） |
| 消息归并 | `add_messages` reducer 按 id 增/删/改（AgentState.messages，types.py:353） | SessionManager 文件条目（fileEntries/byId/leafId 链表结构，attempt.ts:670-680 可见） |
| 控制通道 | `jump_to`：`EphemeralValue` 通道，只存活一个超步（types.py:354）——一次性路由指令 | AbortController 家族（parent/attempt/postCompaction 多级 relay，run.ts:1251-1261）+ steer 插话 |
| 隐藏字段 | `OmitFromSchema(input/output)` 注解剔除（PrivateStateAttr 双向）；`structured_response` 不进输入 schema | 转写内合成消息（mid-turn 错误）带魔法串标记，可识别可移除 |
| schema 扩展 | 中间件声明 `state_schema`，按注册顺序合并、后声明覆盖（factory.py:1038-1046，用户 schema 最后必胜） | 无 schema 概念；状态是会话文件 + 内存 accumulator（usage、replay、messaging 追踪，subscribe :123-188） |
| 不可序列化对象 | `UntrackedValue`（不进检查点，每 run 清零，如 shell 进程句柄） | 外置注册表（tasks SQLite）、进程注册表 |

一个深刻的差异：**LangChain 的 state 是"图的数据"，OpenClaw 的会话是"产品的数据"**。前者随图生灭、可任意 fork（checkpointer 换 thread_id 即分叉）；后者是用户可见的资产（UI 会话列表读它、CLI 与网关共享它、压缩会改写它、子代理有独立的一份）。

---

## 4. 扩展点体系

### 4.1 LangChain：统一中间件契约

**12 钩子**（types.py:380-798，同步/异步成对）：

| 钩子 | 签名要点 | 编译产物 | 能否改路由 |
|---|---|---|---|
| before_agent / after_agent | `(state, runtime) -> dict\|None` | 独立图节点（after 逆序） | ✅（可声明 can_jump_to） |
| before_model / after_model | 同上 | 循环节点（after 逆序） | ✅ |
| wrap_model_call | `(request, handler) -> ModelCallResult` | 洋葱包装（右折叠） | ❌（可短路/重试/改请求） |
| wrap_tool_call | `(request, handler) -> ToolMessage\|Command` | ToolNode 包装洋葱 | ❌ |

配套机制：
- **覆写检测**：以"类属性是否仍是基类方法对象"判断（factory.py:973-1014），未覆写的槽位不注册节点——图按需瘦身；
- **wrap 钩子基类抛 NotImplementedError 且错误信息精确指导**（只实现 async 版却在同步上下文调用时该怎么办，types.py:561-571）——"实现一半"在错误路径快速失败；
- **8 个函数装饰器**（before_model@/wrap_model_call@/dynamic_prompt@…）把普通函数变成中间件（`type()` 动态造子类实例，types.py:1041-1073），按 `iscoroutinefunction` 自动选同步/异步槽位；
- **可观测包装**：每个钩子经 `langsmith.traceable` 包装 + 输入清洗（factory.py:911-915/:138-147）；
- **15 个内置中间件**覆盖：上下文（Summarization/ContextEditing/Todo）、可靠性（ModelRetry/ModelFallback/ModelCallLimit/ToolRetry/ToolCallLimit）、安全（PII/HITL/Shell）、效率与测试（ToolSelection/ToolEmulator/FileSearch）。中间件只依赖 types 与三个私有支撑模块，**不反向依赖 factory**——可独立测试。

### 4.2 OpenClaw：四套拦截点 + 整体替换

| 拦截点 | 接口位置 | 能力 |
|---|---|---|
| 生命周期 hooks | `before_agent_reply` 等（run.ts:510） | **可完全接管回合**（返回回复则不进 agent 循环） |
| 工具策略管道 | pi-tools.ts:456-501 多级策略；openclaw-tools.ts:454-475 `before_tool_call` 包裹 | 过滤/改写/审批每个工具调用；localModelLean 裁剪（:218） |
| 上下文引擎 | `ContextEngine` 接口：ingest/assemble/compact/bootstrap/子代理准备/转写改写（context-engine/types.ts:190） | **整体替换**上下文管线（registry.ts:527 注册表；契约违规自动回退 legacy :546-558） |
| provider stream wrapper | `wrapStreamFn` 钩子（extra-params.ts:841）注入模型 SDK | 包装/改写厂商 SSE 流（如 anthropic/stream-wrappers.ts:203） |
| harness 替换 | `selectAgentHarness`（run.ts:552） | harness id ≠ "pi" 时**整个会话内核换成插件自管传输** |

### 4.3 同一需求的两侧写法对照

| 需求 | LangChain | OpenClaw |
|---|---|---|
| 动态系统提示 | `@dynamic_prompt` 装饰器（wrap_model_call 内 override system_message） | context-engine assemble 返回 `systemPromptAddition`（+ prompt-cache-stability 保序） |
| 工具执行审批 | HITL 中间件：after_model 检测 → `interrupt()` 暂停整图 → approve/edit/reject/respond 四分支 | before_tool_call 门控 + bash 审批门控 + 确定性审批提示（deterministicApprovalPrompt，subscribe :186-187 追踪） |
| 输出脱敏 | PIIMiddleware（before/after_model 改写消息，block/redact/mask/hash） | 无循环级等价物（渠道出站层处理） |
| 改用备用模型 | ModelFallbackMiddleware（洋葱内 `request.override(model=…)`） | failover 状态机 fallback_model 动作 → model-fallback.ts 回退阶梯 |
| 中途换上下文策略 | ContextEditingMiddleware（deepcopy 后仅改本次请求） | 换 context engine（下一 run 生效） |

---

## 5. 工具子系统

| 维度 | LangChain | OpenClaw |
|---|---|---|
| 执行位置 | 独立图节点（langgraph ToolNode，本包不实现执行） | pi 循环内联执行（本包构建工具，执行归内核） |
| 并行模型 | **图级并行**：每个未应答 tool_call 一个 `Send("tools",[tc])`（:1759），引擎 map-reduce | 内核决定（模型并行 tool_calls 时内核处理）；会话级由 lane 强串行 |
| 包装链 | `wrap_tool_call` 洋葱（首个=最外层，外层可多次 call_inner 重试，:585-630） | 策略管道 + before_tool_call |
| 工具来源 | 参数传入 + 中间件注册（`middleware.tools`）+ provider 原生工具（dict 形态，不进 ToolNode，:939-967） | 三源合并：pi 编码工具（read/write/edit/apply_patch/glob/grep/todos/browser + **懒加载** exec/process，pi-tools.ts:317）+ 产品工具 21 个（message/cron/tts/image_generate/music/video/subagents/sessions_*/web_*…，openclaw-tools.ts:341）+ 插件工具追加（:438-452） |
| 动态工具 | 有 wrap_tool_call 时放行（中间件自行处理），否则未注册名抛带修复建议的错误模板（:111-135） | 工具名允许清单（tool-name-allowlist.ts）+ 未知工具守卫（阈值 10 次熔断，attempt.ts:515） |
| 短路 | `return_direct` → 直达 end（:1813-1821） | 无等价物（消息工具发出的内容由 messaging tool 追踪器单独回收） |
| 结果重试/限额 | ToolRetryMiddleware（指数退避+按名过滤）/ ToolCallLimitMiddleware（thread/run 双轨、三种 exit_behavior、给模型与给用户两套文案） | 工具循环检测熔断（见下）+ lastToolError 追踪 |
| 结果治理 | 错误 ToolMessage 回喂（status="error"） | **超大结果截断**（tool-result-truncation.ts，825 行，按上下文预算截断并落盘线索）、工具结果上下文守卫（tool-result-context-guard.ts，防结果挤爆窗口）、结果格式按渠道 markdown/plain 自适应（run.ts:396-402） |

**工具失控防护**（OpenClaw 内建，tool-loop-detection.ts:29-33）：30 次调用历史窗口内四档阈值——警告 10 / 未知工具 10 / 临界 20 / 全局熔断 30；未知工具守卫不可经 `tools.loopDetection.enabled` 关闭（attempt.ts:527）。LangChain 对应能力是可选中间件 ToolCallLimit（默认不装）。

---

## 6. 上下文管理与压缩

### 6.1 LangChain：SummarizationMiddleware（658 行）

```
before_model（每轮）:
  补消息 id → 计算 token（近似计数，Anthropic 自动调 chars_per_token=3.3）
  → _should_summarize（三型触发器 tokens/fraction/messages 可组合；
     用上次响应 usage_metadata.total_tokens 二次判定，:368-385，带 provider 一致性防混模误判）
  → _determine_cutoff_index（token/fraction 二分搜索后缀预算 :427-474）
  → _find_safe_cutoff_point（不拆散 AI/Tool 配对，落点在 ToolMessage 时前移 :552-586）
  → _create_summary（trim_messages 裁剪 → 角色化格式化 → 摘要模型 invoke；
     摘要 prompt 要求按 SESSION INTENT/SUMMARY/ARTIFACTS/NEXT STEPS 四节输出——"上下文提取"而非摘要）
  → 返回 {messages: [RemoveMessage(REMOVE_ALL), 摘要HumanMessage, *保留消息]}  # :322-328 整表重建
```

失败语义：摘要模型失败被吞为错误文本写入历史（:611-612）；历史清空不可恢复。姊妹件 `ContextEditingMiddleware`（298 行）走轻路线：deepcopy 请求消息 → 旧工具结果换占位符（`[cleared]`，保留最近 3 个）→ **只改本次请求不落盘 state**（幂等标记防重复清理）。

### 6.2 OpenClaw：压缩管线（compact.ts 1426 行 + 支撑文件群）

**触发源**（多路）：回合前预算检查、**回合中途溢出预检**（§2.2.4）、空闲/超时触发、preemptive compaction（preemptive-compaction.ts，112 行，提前压缩防下一轮溢出）。

**压缩执行本身是小型 failover 系统**（compact.ts:408-449）：
- 有显式压缩模型 → 单次执行；否则**进模型回退阶梯**（`runWithModelFallback`，:426-445，与主循环共用 model-fallback.ts）；
- 压缩结果有专属分类器（`classifyCompactionFallbackResult` :375）；
- 自带 attempt/maxAttempts 重试与 thinking 升档（:477-478 attemptedThinking 同款机制）；
- 全程诊断日志（diagId/trigger/reason/durationMs，:485-490）。

**溢出三级响应**（attempt.ts:3444-3492）：`truncate_tool_results_only`（仅截断工具结果）→ `compact_then_truncate`（先压缩再截断）→ mid-turn 合成错误 + 续接提示（§2.2.4）。

**会话文件改写**：压缩成功后转写被改写（transcript-rewrite.ts，850 行；compaction-successor-transcript 维护后继关系）——持久资产被正式替换而非遮盖。

**提示缓存治理**（LangChain 完全不感知）：prompt-cache-stability.ts 确定性排序（AGENTS.md 要求）、cache-ttl.ts、per-family 缓存语义（anthropic-family-cache-semantics、google-prompt-cache 9294 字节）、缓存可观测（prompt-cache-observability.ts）。

### 6.3 对照

| 维度 | LangChain | OpenClaw |
|---|---|---|
| 触发 | 单点（before_model） | 四路（回合前/中途/超时/预防性） |
| 算法 | 二分搜索 + 配对安全切割 | 可插拔（context engine compact 钩子） |
| 应用 | state 整表重建 | 转写文件正式改写 + 后继链 |
| 压缩自身的可靠性 | 摘要失败吞为文本 | 回退阶梯 + 分类器 + 重试 + 诊断 |
| 压缩后连续性 | 无特殊处理 | **压缩续接指令**（答案被吞时重试 1 次）+ postCompactionGuard |
| 缓存友好 | 不感知 | 专门子系统 |

---

## 7. 失败处理与可靠性

### 7.1 LangChain：货架中间件组

| 中间件 | 机制 | 默认 |
|---|---|---|
| ModelRetry | 洋葱内 for 循环 + `should_retry_exception`（类型/回调）+ 指数退避（2.0 系数、±25% jitter、60s 封顶，_retry.py:85-123）；耗尽后三分支：重抛 / 自定义文案 / 注入错误 AIMessage 继续 | max_retries=2 |
| ModelFallback | 构造期 init_chat_model 实例化备用列表；主模型异常依序 `override(model=…)` 重试；全败**重抛最后一个异常**（不吞） | 无备用 |
| ModelCallLimit | before_model 检查"下一次是否超限"；thread（跨 run 持久）/run（UntrackedValue 自动清零）双计数；超限 error 抛异常或注入说明 AIMessage + jump_to end | 无限 |
| ToolRetry / ToolCallLimit | 工具版同构（按工具名过滤；被拦调用注入 error ToolMessage 让模型自行调整） | 无限 |
| HITL | after_model 内 `interrupt(hitl_request)`（human_in_the_loop.py:362）**运行时暂停整图**；四分支：approve 放行 / edit 重建 ToolCall（保留原 id，:277-282）/ reject 注入 error ToolMessage / respond 人类代答；人工 ToolMessage 恰好"应答"对应 tool_call → 工具被跳过且消息配对完整（:396-398 原地改写 tool_calls）；恢复依赖 checkpointer | 不审批 |

### 7.2 OpenClaw：内建于骨架的失败分类学

除 §2.2.5 的五动作状态机与 §2.2.4 的行为重试外：

- **模型回退阶梯**（model-fallback.ts，1274 行）：配置化跨厂商回退链，与凭据轮换正交（先轮凭据再换模型）；
- **过载退避**（run.ts:1041）：过载类失败专门退避节奏；
- **空闲断路器**（llm-idle-timeout.ts 351 行 + idle-timeout-breaker.ts）：流卡死看门狗——SSE 停流但连接未断的场景；
- **incomplete-turn 修复**（incomplete-turn.ts，880 行）：半截回合（有 tool_calls 无结果等）的检测与修复；
- **assistant-failover**（assistant-failover.ts，338 行）：模型给出了回复但回复本身被判失败（harness 结果分类）时的接管；
- **中止语义**：parent → attempt → postCompaction 多级 AbortController relay（run.ts:1251-1261），外部中止（用户取消）与内部失败严格分流——前者 surface_error 直接上抛，后者进分类机。

### 7.3 同类故障路径对照

| 故障 | LangChain 路径 | OpenClaw 路径 |
|---|---|---|
| 401 凭据失效 | ModelRetry 按 matching 重试（若配了）→ 抛给用户 | classify → session_expired → rotate_profile（下一档案，OAuth 自动刷新） |
| 429/529 过载 | ModelRetry 退避重试 → ModelFallback 换模型 | classify → 同模型退避 → rotate_profile → fallback_model |
| 流卡死 | 无内建（看门狗归调用方） | 空闲断路器 abort → timedOut 分支（区分压缩期/工具期） |
| 空回复 | 无内建（循环正常退出，返回空） | 行为检测器 → 可见答案续答指令重试（有预算） |
| 坏格式结构化输出 | `_handle_model_output` 校验错误 ToolMessage 回喂 → 路由第 6 步拉回模型（自纠错回路 :1141-1158/:1765-1767） | classify → format → 默认终态 surface（allowFormatRetry 才重试） |
| 上下文溢出 | Summarization 下轮触发（事后补救） | mid-turn 预检 + 三级响应 + 续接（事中处理） |
| 重试全败 | 重抛最后异常 | return_error_payload（结构化错误载荷 + usage + liveness 标记）或 surface_error |

---

## 8. 并发模型与串行化

| 维度 | LangChain | OpenClaw |
|---|---|---|
| 同轮工具并行 | Send 扇出（引擎级） | 内核级 |
| 同 agent 并发调用 | 同一 graph 实例可并发 invoke（闭包共享装配期对象）；隔离靠 thread_id | **双 lane 强串行**：会话 lane（同会话绝不并发）嵌套全局 lane（进程级背板）；外注入 `params.enqueue` 可接管（测试/嵌入）；lane 超时可配 |
| 活跃 run 时新消息 | 调用方自行处理 | **三动作队列策略**（queue-policy.ts）：`run-now`（空闲）/ `enqueue-followup`（活跃且 queueMode=steer\|queue 或 shouldFollowup）/ `drop`（心跳类）；`reset` 触发可打断为 run-now |
| 插话 | 无内建 | `activeSession.steer(text)`（attempt.ts:2762）注入活流 vs followup 排队下一回合 |
| 多进程 | 不适用（库） | 跨进程会话写锁（session-write-lock.ts，710 行，网关与 CLI 共享会话文件）+ 网关单实例锁（带持有者活性验证与收尸，gateway-lock.ts） |
| 后台执行 | 图组合实现 | 分离任务运行时（detached-task-runtime.ts，请求车道之外）+ tasks 注册表（SQLite 持久，断电可恢复） |

**steer 与 jump_to 是两种物种的缩影**：jump_to 是图路由指令（结构化、一次性、面向编译器）；steer 是活会话上的插话（运行时、面向正在流式输出的模型）。

---

## 9. 子代理与多 Agent

**OpenClaw**：一等能力。`spawnSubagentDirect`（subagent-spawn.ts:675，1336 行）——
- 两种模式：`run`（一次性）与 `session`（持久会话，**必须 thread=true** 绑定渠道线程，:709-716 有专门报错引导）；
- 上下文模式（contextMode：继承/隔离，按请求与配置解析，:737-745）；
- **递归深度守卫**（callerDepth，:761——防子代理套娃）；
- agentId 前置校验门（:691-700，注释引 bug #31311：错误消息被 normalize 成合法 id 后制造幽灵工作区与级联 cron 循环）；
- 配套注册表/清理/恢复/steer（subagent-registry*）与结果回收投递（subagent-announce*）；超时可配（runTimeoutSeconds）。
- 子代理本身跑同一个 `runEmbeddedPiAgent`（独立会话键），插件注册表 LRU 复用 + 子代理模式全局态还原（loader.ts:1530-1558）。

**LangChain 1.3.0**：无内建子代理原语。多 agent 靠图组合（把一个 agent 图作为另一个图的节点）或社区模式（supervisor/swarm 在独立包）。循环内与子代理相关的只有 `ToolCallLimit` 等治理件——委派不是这个循环的设计目标。

---

## 10. 持久化与恢复

| 维度 | LangChain | OpenClaw |
|---|---|---|
| 载体 | checkpointer（内存/Postgres/Redis 可插拔）+ store | 会话 JSONL（`~/.openclaw/agents/<id>/sessions/`）+ SessionStore 元数据 |
| 写入时机 | 每超步后（引擎事务） | 消息级追加（transcript-append.ts）；压缩/修复时整体改写（`_rewriteFile`） |
| 恢复 | checkpoint 重放；interrupt 恢复依赖 checkpointer | 打开前修复（session-file-repair.ts）+ 重放历史（replay-history.ts，850 行——重建内存态以续会话）+ 上下文引擎 bootstrap |
| 一致性 | 引擎保证 | 跨进程写锁 + guardSessionManager 工具结果守卫（来源校验）+ 转写策略（attempt.transcript-policy） |
| 崩溃后 | 由 checkpointer 实现 | 孤儿锁收尸、转写修复、任务注册表收割（task-registry.maintenance） |

---

## 11. 流式输出

**LangChain**：循环不感知流式。模型流经图节点透传，用户拿 `astream/astream_events`；中间件在节点边界工作，天然只见完整消息。HITL 等机制也不需要流意识。（`_ConfigurableModel` 的声明式操作队列保证流式调用按当次 config 实例化模型并重放 bind_tools。）

**OpenClaw**：专设流式状态机 `subscribeEmbeddedPiSession`（pi-embedded-subscribe.ts:117，1147 行）。其状态对象（:123-188）暴露了这个状态机实际管理的东西：
- 文本装配：deltaBuffer/blockBuffer 累积、`<think>…</think>` 推理块剥离（状态跨 chunk 保持，:142-144）、inlineCode 状态机、`EmbeddedBlockChunker` 按块边界切块（blockReplyBreak 默认 text_end）；
- 回调节流：onPartialReply（节流）/ onBlockReply（块边界）/ onReasoningStream（reasoningMode="stream" 且 thinking≠off）；
- **运行时语义追踪**：livenessState（working/…）、compactionInFlight + 压缩重试 promise、usageTotals（input/output/cacheRead/cacheWrite/total 五项）、messaging 工具发送文本/媒体/目标的追踪（供最终回复去重——消息工具已发过的内容不再进最终 payload）、deterministicApprovalPrompt 状态、replayState；
- 产物 getters（assistantTexts/toolMetas/getUsageTotals）供 attempt 收尾装配 `ReplyPayload[]`。

这是产品形态的直接投影：下游是 Telegram 草稿编辑（限流编辑）与 Web UI 打字机，规范明文要求"渠道消息不可发 token 增量"（AGENTS.md:162）——必须块流。**LangChain 的流式是引擎能力，OpenClaw 的流式是业务子系统**。

---

## 12. 终止条件与预算治理

| 治理项 | LangChain | OpenClaw |
|---|---|---|
| 自然终止 | 模型不再调工具（路由第 3 步） | pi 收敛 + 空回复检测 |
| 步数上限 | recursion_limit=9999（事实无界）+ 可选 limit 中间件 | MAX_RUN_LOOP_ITERATIONS（随档案数动态）+ 行为重试各自预算（planning/reasoning/empty 各有 max，压缩续接仅 1 次）+ 工具全局熔断 30 |
| token 预算 | 无内建 | 上下文窗口守卫（按**有效**限额而非原生窗口，compact.ts:647-660）+ 溢出三级响应 |
| 时间预算 | 无内建（超时归调用方/engine） | prompt 超时 / 压缩安全超时（compaction-safety-timeout）/ 工具执行超时 / 空闲断路器，各自独立配置与计时（attempt-stage-timing） |
| 失败预算 | 重试中间件自带（默认 2） | 分类驱动（每类失败独立的升级/终止规则） |
| 输出预算 | 无内建 | 超大工具结果截断 + 转写媒体剥离（history-image-prune） |

---

## 13. 安全

| 面 | LangChain（循环内可选件） | OpenClaw（内建于传输与工具层） |
|---|---|---|
| 数据流 | PIIMiddleware（4 策略、纯正则+Luhn 无 Presidio；重建消息会丢 additional_kwargs 的已知代价） | 无循环级 PII；出站层处理 |
| 命令执行 | ShellToolMiddleware 三档策略：Host（rlimit，Windows 无 resource 即抛）/ Codex CLI 沙箱（Seatbelt/Landlock+seccomp）/ Docker（`--network none`、临时工作区不挂载）；docstring 明示 Host 下输出脱敏**不能**防外泄 | bash 审批门控 + 进程注册表（os.killpg 整树击杀）+ 沙箱体系 + 沙箱工具策略 |
| 网络面 | file_search 路径逃逸防护（拒 `..`/`~`，relative_to 强制根内） | **全部模型流量经 SSRF 防护 fetch**（provider-transport-fetch.ts，注入模型 SDK——连第三方 SDK 的网络都被接管）+ SSE 清洗 |
| 工具面 | 动态工具错误模板 | 工具名允许清单 + 未知工具熔断 + 技能符号链接逃逸防护（skills/workspace.ts:245-423） |
| 凭据 | 归 partner 包 | 声明式密钥管线（secrets/）+ 认证档案存储（凭据永不进装配描述） |

---

## 14. 可观测性

| 面 | LangChain | OpenClaw |
|---|---|---|
| 追踪 | 每钩子 `langsmith.traceable` + `ls_integration` 元数据 + 输入清洗 | 阶段计时（attempt-stage-timing）、startup 阶段标记（run.ts:1244-1249）、执行阶段通知（notifyExecutionPhase） |
| 用量 | 引擎/模型层（usage_metadata 透传） | 全链计价：usageTotals 五项（含 cacheRead/cacheWrite）→ model-pricing-cache 计价 → 重试上限路径保留最近 API total（run.ts:1151-1152 专门提升变量作用域） |
| 事件 | 图事件（astream_events） | 轨迹记录（trajectory/）、agent.plan 事件（行为重试时发计划详情）、模型诊断事件（attempt.model-diagnostic-events.ts）、压缩诊断日志（diagId 全程） |
| 缓存可观测 | 无 | prompt-cache-observability.ts |

---

## 15. 代码规模对照（原始行数，已逐一统计）

**LangChain `agents/`（循环全部代码，22 文件）**：

| 文件 | 行数 | 职责 |
|---|---|---|
| factory.py | 1,885 | 工厂：装配图 |
| middleware/types.py | 2,052 | 12 钩子契约 + 装饰器 |
| structured_output.py | 462 | 三策略 |
| shell_tool.py | 882 | 持久 shell（最大中间件） |
| summarization.py | 658 | 摘要 |
| 其余 12 中间件 + 3 支撑 + 门面 | 4,948 | — |
| **合计** | **10,987** | |

**OpenClaw 循环核心 18 文件（`src/agents/` 约 430 文件中的主干）**：

| 文件 | 行数 | 职责 |
|---|---|---|
| pi-embedded-runner/run/attempt.ts | 4,209 | 单次尝试全生命周期 |
| pi-embedded-runner/run.ts | 3,135 | 三层循环编排 + failover |
| pi-embedded-runner/model.ts | 1,292 | 模型解析链 |
| subagent-spawn.ts | 1,336 | 子代理 |
| model-fallback.ts | 1,274 | 回退阶梯 |
| compact.ts | 1,426 | 压缩主管线 |
| pi-tools.ts | 1,007 | 编码工具 |
| pi-embedded-subscribe.ts | 1,147 | 流式状态机 |
| replay-history.ts | 850 | 会话重放 |
| tool-result-truncation.ts | 825 | 结果截断 |
| incomplete-turn.ts | 880 | 半截回合修复 |
| session-write-lock.ts | 710 | 跨进程锁 |
| tool-loop-detection.ts | 760 | 循环熔断 |
| failover-policy.ts + assistant-failover.ts | 531 | 决策状态机 |
| llm-idle-timeout.ts + preemptive-compaction.ts | 470 | 看门狗/预防压缩 |
| openclaw-tools.ts | 488 | 产品工具 |
| **合计** | **20,340** | （不含 auth-profiles、transport streams、context-engine、工具实现等同等重要外围） |

**密度对比**：OpenClaw 仅这 18 个文件就是 LangChain 全部 agent 代码的 1.85 倍；若计入外围（认证 2500+ 行、传输流 3600+ 行、上下文引擎、21 个工具实现、subagent 注册表族），比例超过 4 倍。而 LangChain 用 10,987 行交付了**循环 + 15 中间件 + 结构化输出 + 工具节点集成**的完整可组合体系——库的代码效率来自"只写一次、用户组合"。

---

## 16. 设计决策对照与结论

### 16.1 哲学总表

| 问题 | LangChain 1.3.0 的答案 | OpenClaw 2026.5.12 的答案 |
|---|---|---|
| 循环是什么 | 一张编译产物（静态图拓扑） | 一个运行中的会话（活的 pi 内核 + 运维外壳） |
| 谁拥有控制流 | 用户与中间件（jump_to/洋葱短路/return_direct/interrupt） | 框架（failover 状态机；模型行为靠指令注入与策略管道治理） |
| 扩展如何做 | 统一钩子契约、洋葱组合、装什么有什么 | 按子系统设点，插件可整体替换（引擎/harness/provider/工具） |
| 可靠性在哪 | 货架中间件（可选） | 循环骨架本身（必选）：分类学 + 轮换 + 回退 + 熔断 + 行为重试 |
| 上下文是什么 | 图 state 通道（add_messages 归并、可 fork） | 持久转写资产（跨回合、跨进程、可改写、有后继链） |
| 模型不可靠时 | 校验错误回喂（结构化自纠错）——**信任模型能改对** | 定向指令重试（act-now/visible-answer）——**假设模型会犯特定病并备好听诊器** |
| 流式是什么 | 引擎透传 | 业务子系统（块切分 + 渠道规范 + 消息去重） |
| 典型故障假设 | 异常抛出 → 用户组装重试链 | 五类失败 × 五种动作 × 三层位置（prompt/assistant/工具期）的分类学 |

### 16.2 值得互相借鉴之处

**LangChain 侧可吸收**：
1. **失败分类学**——OpenClaw 把"401 该换凭据、过载该退避、格式错换凭据也没用"编码成显式状态机；LangChain 的重试中间件只有异常类型匹配，没有升级语义。
2. **内建熔断**——裸 `recursion_limit=9999` + 默认无预算的循环在生产上有失控风险；OpenClake 的 30 次窗口熔断近乎零成本。
3. **行为级重试**——"模型只出计划不执行/只有推理没有答案"是真实高频故障，LangChain 循环对此完全无感知（正常退出，返回空）。
4. **压缩连续性**——Summarization 整表重建后模型"忘了正在说什么"的问题，OpenClaw 用压缩续接指令显式处理。

**OpenClaw 侧可吸收**：
1. **统一扩展契约**——四套拦截点的认知成本远高于一个 AgentMiddleware 基类；before/after/wrap 三正交维度 + 装饰器是更低的入门门槛。
2. **结构化输出自纠错回路**——校验错误回喂是通用模式，OpenClaw 的抽取路径（commitments 等）各自手搓健壮 JSON 解析。
3. **请求对象不可变 override**——OpenClaw 的重试靠拼 prompt 字符串；`ModelRequest.override` 的结构性改写（换模型/换工具/换提示）更可测试。
4. **运行时中断原语**——`interrupt()` + checkpointer 的"暂停整图等人工"在渠道审批场景（OpenClaw 目前只有工具级门控）会更干净。

### 16.3 选型指引

- **构建自己的 agent 应用、需要嵌入业务进程、追求可控可测试** → LangChain 1.3.0：循环是纯函数式的编译产物，15 个中间件覆盖大多数横切需求，失败模式是"抛异常"这种库式契约。
- **运行长期在线的自主助手、多渠道投递、无人值守** → OpenClaw 式架构（或直接部署 OpenClaw）：它为"凌晨三点模型过载、凭据过期、上下文爆了、渠道限流"全部准备了代码路径。
- **两者组合**：完全可以用 LangChain 循环作为 OpenClaw 式 harness 的一种实现（OpenClaw 的 harness 抽象正为此留门）——库提供循环结构，服务提供运营外壳。
