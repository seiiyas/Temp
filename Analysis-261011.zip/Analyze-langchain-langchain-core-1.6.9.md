# 《生产项目代码分析报告》—— langchain-core 1.6.9（Python 版）

> **分析对象**：`langchain-langchain-core-1.6.9/`（LangChain 官方 monorepo 在 `core==1.6.9` tag 下的源码快照）。本报告聚焦其中的分析主体 **`@langchain/core`（Python 包名 `langchain-core`，版本 1.6.9）**，即 `libs/core/langchain_core/` 目录下的全部生产源码；monorepo 中的其他 `libs/`（langchain 主包、partners 集成包、standard-tests 等）是独立发布的包，不属于 langchain-core 的生产代码，仅在项目概述层面说明（见"分析范围界定"）。
>
> **报告性质**：面向从未接触过本项目的开发人员，阅读后应能对代码结构、每个文件、每个函数的功能、作用及实现方式建立深入理解，并具备直接上手参与开发的能力。所有结论基于实际代码，涉及具体实现处引用 `文件路径:行号`；无法确认的意图明确标注「推断」。

---

## 分批输出计划（本文件为批次 1~6 的合并成品）

本项目纳入范围的生产源文件共 **182 个**、模块组 **21 个**，远超单批承载上限，故按下列批次生成，最终合并为本文件：

| 批次 | 覆盖模块/目录 | 覆盖章节 | 涉及文件数 | 状态 |
|------|--------------|----------|-----------|------|
| 1 | 全局总览 | 第 1~3 章 + 术语表 + 本计划 | 全部（清单层） | ✅ 已完成 |
| 2 | runnables（核心+扩展） | 第 4 章（§4.1、§4.2） | 16 | ✅ 已完成 |
| 3 | language_models、messages（含 block_translators） | 第 4 章（§4.3、§4.4） | 30 | ✅ 已完成 |
| 4 | prompts/output_parsers/prompt_values、tools/agents/documents/document_loaders/indexing/example_selectors | 第 4 章（§4.5、§4.6） | 42 | ✅ 已完成 |
| 5 | callbacks/tracers、load、vectorstores/embeddings、根目录杂项、utils/_api/_security | 第 4 章（§4.7~§4.11） | 60 | ✅ 已完成 |
| 6 | 全局收尾 | 第 5~10 章 + 总目录 + 完成度自检 + 存疑清单 | （全量文件清单） | ✅ 已完成 |

批次顺序遵循依赖方向：基础层（runnables 协议 → 模型/消息数据层）→ 业务层（提示词/工具/索引/回调）→ 横切机制与收尾。同一模块的文件未拆批。

---

## 0. 术语表（首次出现前先建立概念）

| 术语 | 解释 |
|------|------|
| **LCEL**（LangChain Expression Language） | LangChain 的链式组合语法：用 `|` 算子把多个组件拼成流水线，本质是把一切组件统一为 `Runnable` 对象（见 §4.1） |
| **Runnable** | 全库统一执行协议：任何实现 `invoke/batch/stream/transform` 的对象，同步/异步/批量/流式/追踪能力由此派生 |
| **RunnableConfig** | 调用时传入的配置 TypedDict（callbacks/tags/metadata/run_name/max_concurrency/recursion_limit/configurable/run_id），经 ContextVar 沿调用树隐式传播 |
| **钩子方法**（hook） | 基类模板方法链中留给子类实现的方法，如 `BaseChatModel._generate`、`BaseRetriever._get_relevant_documents`、`BaseTool._run` |
| **content block / 内容块** | 消息 `content` 中的结构化单元（text/image/audio/video/file/reasoning/tool_call 等），v1 标准块体系定义在 `messages/content.py` |
| **wire format** | 各模型提供商的原生消息格式（OpenAI/Anthropic/Bedrock/Google 各不相同），由 `block_translators` 与标准块互译 |
| **chunk** | 流式输出的增量片段；合并约定为"支持 `+` 运算符，TypeError 时取末块"；dict 型增量用 `AddableDict` |
| **tracing / tracer** | 可观测性机制：回调 handler 的一种，把调用生命周期组装成 `Run`（RunTree）树上报 LangSmith 或供本地消费 |
| **Run**（RunTree） | 一次组件调用的追踪记录节点（含 parent/child、dotted_order 排序键、inputs/outputs），schema 由 langsmith 提供 |
| **partner 包** | 第三方集成包（langchain-openai、langchain-anthropic 等），继承 core 的基类实现钩子以接入特定提供商 |
| **manifest** | `Serializable.to_json()` 产出的 `{"lc":1,"type":"constructor","id":[类路径],"kwargs":{...}}` 序列化格式 |
| **RecordManager** | 索引账本：记录（doc_id → source_id、时间戳）的 KV 存储，支撑增量索引的去重与清理 |
| **MMR**（Maximal Marginal Relevance） | 兼顾与查询相似度、彼此多样性的贪心选择算法（Carbonell & Goldstein 1998） |
| **SSRF** | 服务端请求伪造；LLM 应用中 URL 常来自模型输出，`_security` 包提供 IP 黑名单 + DNS 校验 + IP pinning 防护 |
| **v1/v2/v3 流式** | 三代流式协议：v1 = chunk 流（`_stream` + `on_llm_new_token`）；v2 = 协议事件流（`on_stream_event`，由 `_compat_bridge` 适配）；v3 = 类型化流对象（`ChatModelStream`） |

---

## 1. 项目概述

### 1.1 项目用途与业务背景

langchain-core 是整个 LangChain 生态的**基础抽象层**（`libs/core/langchain_core/__init__.py:1-8` 的模块 docstring 自述："defines the base abstractions for the LangChain ecosystem... The universal invocation protocol (Runnables) along with a syntax for combining components are also defined here. **No third-party integrations are defined here.**"）。

它不是一个直接面向终端用户的应用，而是一个**被上层生态复用的 SDK 库**，业务价值可从代码结构直接归纳：

1. **统一执行协议（LCEL）**：`runnables/` 定义 `Runnable` 抽象基类，使提示词、模型、解析器、检索器、工具都能用 `|` 组合成链，并自动获得同步/异步/批量/流式/追踪能力；
2. **模型接入契约**：`language_models/` 定义 `BaseChatModel`/`BaseLLM`，所有 partner 包（langchain-openai 等）只需实现 `_generate`/`_stream` 钩子即可接入全部生态能力；
3. **跨提供商中立消息层**：`messages/`（含 `block_translators/`）定义统一消息与内容块格式，屏蔽 OpenAI/Anthropic/Bedrock/Google 各家的 wire format 差异；
4. **检索与数据基础设施**：`documents/`、`document_loaders/`、`indexing/`、`vectorstores/`、`embeddings/`、`retrievers.py` 构成 RAG 数据面；
5. **可观测性内建**：`callbacks/` + `tracers/` 把 LangSmith 追踪、流式事件、token 用量统计埋进每一次调用的骨架；
6. **安全与治理**：`load/` 的白名单反序列化、`_security/` 的 SSRF 防护、`_api/` 的弃用/beta 装饰器。

依赖刻意保持极轻（`pyproject.toml:26-37`：langsmith、httpx、tenacity、jsonpatch、PyYAML、typing-extensions、packaging、pydantic≥2.7.4、uuid-utils、langchain-protocol），不含任何模型 SDK。

### 1.2 技术栈清单

| 项 | 内容 | 出处 |
|----|------|------|
| 语言 | Python ≥3.10（支持 3.10~3.14） | `pyproject.toml:25`、classifiers :14-19 |
| 包管理与构建 | uv + hatchling（build-backend） | `pyproject.toml:1-3`、`Makefile`（全部命令走 `uv run`） |
| 版本 | 1.6.9 | `version.py:3`（`VERSION = "1.6.9"`）、`pyproject.toml:24` |
| 核心运行时依赖 | pydantic ≥2.7.4,<3（数据模型基座）、langsmith ≥0.3.45（追踪）、tenacity（重试）、httpx（HTTP）、jsonpatch（astream_log 增量）、PyYAML（图渲染 frontmatter/load_prompt）、uuid-utils（uuid7）、langchain-protocol（v2 协议事件类型）、typing-extensions、packaging | `pyproject.toml:26-37` |
| 测试/静态检查（dev-only） | pytest 9 + pytest-asyncio + syrupy（快照）+ mypy strict + ruff（select ALL） | `pyproject.toml:49-79`、:90-99 |
| Lint 特殊配置 | ruff `ban-relative-imports = "all"`（禁相对导入）；mypy 启用 pydantic 插件 | `pyproject.toml:126-127`、:90-92` |

### 1.3 如何运行 / 构建 / 测试

这是一个库而非应用，没有 main 入口；「运行」= 作为依赖被导入。开发工作流（`libs/core/Makefile`）：

- **安装**：`uv sync`（uv 读取 `pyproject.toml` 的 dependency-groups 安装 dev 环境）；
- **测试**：`make test` → `uv run --group test pytest -n auto --disable-socket ...`（:13-20，测试时强制清空 LANGCHAIN_TRACING_V2/LANGCHAIN_API_KEY 等环境变量防误上报）；
- **Lint/类型**：`make lint`（ruff check + ruff format --diff + mypy，:60-64）；`make type`（mypy）；
- **导入完整性检查**：`make check_imports` → `scripts/check_imports.py` 用随机模块名逐个 `SourceFileLoader().load_module()` 验证每个 .py 可导入（`scripts/check_imports.py:9-24`）——这保障了惰性导入体系不写错映射表；
- **版本一致性**：`make check_version` → `scripts/check_version.py`。
- **环境配置方式**：运行时行为主要由环境变量驱动——LangSmith 追踪（`LANGCHAIN_TRACING_V2`/`LANGSMITH_TRACING`/`LANGCHAIN_API_KEY`/`LANGCHAIN_PROJECT`，在 `callbacks/manager.py` 的 `_configure` 装配线读取）；全局开关另有 `set_debug/set_verbose/set_llm_cache`（`globals.py:18-72`）。

### 1.4 monorepo 其他部分（不在分析范围内，仅说明）

快照根目录还包含：`libs/langchain`（经典主包）、`libs/langchain_v1`（1.x 主包）、`libs/partners/*`（17 个提供商集成包）、`libs/standard-tests`、`libs/text-splitters`、`libs/model-profiles`、`openwiki/`（文档）。它们**独立发布**、依赖 core 但不被 core 依赖，按「排除范围：packages 中的外部库/独立包」原则不纳入逐文件分析。

---

## 2. 整体架构

### 2.1 架构风格与分层

langchain-core 是一个**以"协议 + 模板方法"为核心的分层 SDK 库**，没有运行时服务进程。分层如下（上层依赖下层，箭头为依赖方向）：

```
┌─────────────────────────────────────────────────────────────────────┐
│  L4 组合层（LCEL 语法糖）                                            │
│  runnables/: RunnableSequence(|)、RunnableParallel、RunnableBranch、 │
│  RunnablePassthrough/Assign、Retry/Fallbacks/Configurable/History、   │
│  graph 渲染 (ASCII/Mermaid/PNG)                                      │
├─────────────────────────────────────────────────────────────────────┤
│  L3 业务抽象层（五大 RunnableSerializable 基类）                      │
│  prompts/  → BasePromptTemplate/ChatPromptTemplate                   │
│  language_models/ → BaseChatModel/BaseLLM（模型接入契约）             │
│  output_parsers/ → BaseOutputParser                                  │
│  retrievers.py → BaseRetriever                                       │
│  tools/ → BaseTool/@tool 装饰器                                      │
├─────────────────────────────────────────────────────────────────────┤
│  L2 数据契约层                                                       │
│  messages/（统一消息 + content.py v1 内容块 + block_translators 互译）│
│  prompt_values.py（PromptValue）/ outputs/（Generation/ChatResult）   │
│  documents/（Document/Blob）/ agents.py（AgentAction/Finish）         │
├─────────────────────────────────────────────────────────────────────┤
│  L1 横切基础设施层                                                   │
│  callbacks/+tracers/（可观测性）  load/（序列化）                    │
│  runnables/config.py（RunnableConfig/ContextVar 传播）               │
│  runnables/base.py 的 Runnable 协议本身                              │
├─────────────────────────────────────────────────────────────────────┤
│  L0 通用工具层                                                       │
│  utils/（21 文件：json 修复/mustache/pydantic 兼容/合并算法等）       │
│  _api/（弃用治理） _security/（SSRF 防护） exceptions.py globals.py  │
└─────────────────────────────────────────────────────────────────────┘
        全部 __init__.py 采用 __getattr__ 惰性导入（导入开销最小化）
```

关键架构决策（贯穿全库）：

1. **一切皆 Runnable**：L3 的五大基类全部继承 `RunnableSerializable`（`runnables/base.py:2831`），因此天然可 `|` 组合、可 batch、可 stream、可被追踪。
2. **模板方法 + 钩子**：基类固化"回调包裹 + 配置传播 + 类型推断"骨架，子类只实现 `_generate`/`_run`/`_get_relevant_documents` 等私有钩子（详见 §4.3、§4.6）。
3. **sync/async 双轨制**：每个能力 4 份实现（invoke/ainvoke/stream/astream），async 默认经 `run_in_executor` 委托 sync（`runnables/config.py:678-712`），子类给出原生 async 则直用。
4. **ContextVar 配置传播**：`var_child_runnable_config` + `ensure_config` 三层合并（默认值 → ambient 配置 → 显式 config）+ `patch_config`，配置沿调用树自动继承（`runnables/config.py:174-308`）。
5. **观察者模式可观测性**：`CallbackManager` 把生命周期事件扇出到 handler；tracer 是特殊 handler，把事件组装成 Run 树（§4.7）。

### 2.2 模块依赖关系图

```
                    ┌─────────── utils/ · _api/ · _security/ · exceptions ───────────┐
                    │  （L0，被所有模块引用；_security 目前仅测试引用，供外部包用）      │
                    └───────────────────────────▲─────────────────────────────────────┘
                                                │
   load/serializable ◄────┐                     │
   （Serializable 基类）   │                     │
        ▲                 │                     │
        │                 │                     │
 runnables/base.py（Runnable 协议 + RunnableSerializable）◄── runnables/config.py
        ▲    ▲    ▲    ▲                                              ▲
        │    │    │    │            ┌────────────────────────────────┘
 prompts/ lm/ retrievers tools      │（回调装配）
 output_parsers/                   │
        ▲                          │
        │   messages/ ◄────────────┤
        │   （BaseMessage 家族 +    │
        │    block_translators）    │
        │                          │
        └──────► LCEL 链（用户代码）┴──► callbacks/manager ──► tracers/* ──► LangSmith
                                        （on_* 生命周期）   （Run 树）

 documents/ ──► document_loaders/ ──► indexing/（依赖 vectorstores + RecordManager）
 embeddings/ ──► vectorstores/ ──► retrievers.py（as_retriever 桥接）
 caches.py / rate_limiters.py / stores.py / chat_history.py ──► 被 language_models 与上层引用
```

### 2.3 核心数据流：一次典型调用（chat 模型 + LCEL 链）

```
用户: chain.invoke({"topic": "cats"})
  │  chain = prompt | model | parser（RunnableSequence）
  ▼
RunnableSequence.invoke（runnables/base.py:3434）
  ├─ ensure_config → CallbackManager.configure（装配 tracer/handler，manager.py:2390）
  ├─ on_chain_start ──► tracer 建 Run 节点（core.py:_create_chain_run）
  ├─ step1: ChatPromptTemplate.invoke → format_messages 变量替换 → ChatPromptValue
  ├─ step2: BaseChatModel.invoke（chat_models.py:475）
  │    └─ generate_prompt → generate（批量编排，:1592）
  │         ├─ on_chat_model_start（返回 CallbackManagerForLLMRun）
  │         ├─ _generate_with_cache（:1892）
  │         │    ├─ LLM 缓存查找（caches.py，键=prompt+llm_string）
  │         │    ├─ rate_limiter.acquire（rate_limiters.py 令牌桶）
  │         │    ├─ 分支: v2 协议事件 / v1 流式 / _generate 钩子 ←─【partner 包实现点】
  │         │    ├─ 消息内容块翻译（messages/block_translators 按需）
  │         │    └─ 缓存回写 + usage_metadata 保全
  │         └─ on_llm_end（LLMResult）
  │         → 返回 AIMessage（含 tool_calls/usage_metadata）
  ├─ step3: BaseOutputParser.invoke → parse_result → parse → 结构化输出
  ├─ on_chain_end（最终输出）
  ▼
返回结果；根 Run 结束 → tracer._persist_run → LangSmith 上报（POST/PATCH）
```

流式变体：`chain.stream(input)` → `RunnableSequence._transform` 把各步 `transform` 生成器逐层套接成惰性流水线（`runnables/base.py:3768-3789`），模型逐 chunk 产出 `AIMessageChunk`，`on_llm_new_token` 逐个触发，最终由消费者聚合。

---

## 3. 目录结构详解

以下为 `libs/core/` 下纳入分析范围的目录树（`tests/` 按排除规则省略；`scripts/` 仅含构建辅助脚本）：

```
libs/core/
├── pyproject.toml            → 包定义：依赖、hatchling 构建、ruff/mypy/pytest 配置
├── Makefile                  → 开发工作流：test/lint/format/type/check_imports
├── extended_testing_deps.txt → 扩展测试的可选依赖清单
├── scripts/                  → check_imports.py（可导入性检查）、check_version.py、lint_imports.sh
└── langchain_core/           → ★ 生产源码主体（182 个 .py）
    ├── __init__.py           → 包入口：仅导入 _api 警告浮出 + VERSION，无业务导出
    ├── version.py            → VERSION = "1.6.9"
    ├── env.py                → get_runtime_environment（运行时环境信息，供 LangSmith）
    ├── globals.py            → 全局开关：set/get_debug、set/get_verbose、set/get_llm_cache
    ├── exceptions.py         → 全部公共异常（LangChainException 根 + 8 个 ModelError 子类）
    ├── _import_utils.py      → import_attr：支撑全部子包 __getattr__ 惰性导入
    ├── prompt_values.py      → PromptValue 体系（StringPromptValue/ChatPromptValue/ImagePromptValue）
    ├── agents.py             → 遗留 Agent 循环数据 schema（AgentAction/AgentFinish）
    ├── retrievers.py         → BaseRetriever（RunnableSerializable 模板类）
    ├── caches.py             → BaseCache/InMemoryCache（LLM 响应缓存）
    ├── rate_limiters.py      → BaseRateLimiter/InMemoryRateLimiter（令牌桶限流）
    ├── stores.py             → BaseStore/ByteStore/InMemoryStore（批量 KV 存储）
    ├── chat_history.py       → BaseChatMessageHistory（1.6.4 起整体 deprecated）
    ├── chat_loaders.py       → BaseChatLoader（会话数据加载抽象）
    ├── chat_sessions.py      → ChatSession TypedDict
    ├── cross_encoders.py     → BaseCrossEncoder（重排打分接口）
    ├── structured_query.py   → 结构化查询 IR（Comparator/Operator/Visitor 访问者模式）
    ├── sys_info.py           → print_sys_info（调试环境信息打印）
    ├── _api/                 → API 治理：@deprecated/@beta 装饰器、内部调用者探测、路径工具
    ├── _security/            → SSRF 防护：IP 黑名单策略、DNS 校验、httpx Transport（IP pinning）
    ├── runnables/            → ★ Runnable 协议与全部组合子（16 文件，§4.1/§4.2）
    ├── language_models/      → ★ BaseChatModel/BaseLLM/流式三协议（10 文件，§4.3）
    ├── messages/             → ★ 统一消息 + v1 内容块 + 提供商翻译器（11+9 文件，§4.4）
    ├── outputs/              → Generation/ChatGeneration/ChatResult/LLMResult（6 文件，§4.3）
    ├── prompts/              → 提示词模板体系（12 文件，§4.5）
    ├── output_parsers/       → 输出解析器（11 文件，§4.5）
    ├── tools/                → BaseTool/@tool/StructuredTool（7 文件，§4.6）
    ├── documents/            → Document/Blob/压缩器/变换器（4 文件，§4.6）
    ├── document_loaders/     → BaseLoader/LangSmithLoader（4 文件，§4.6）
    ├── indexing/             → index()/RecordManager 幂等索引（4 文件，§4.6）
    ├── example_selectors/    → 长度/语义相似度示例选择（4 文件，§4.6）
    ├── callbacks/            → ★ 回调 handler + CallbackManager 分发（7 文件，§4.7）
    ├── tracers/              → ★ tracer 家族：LangSmith/事件流/日志流（15 文件，§4.7）
    ├── load/                 → ★ 序列化框架：Serializable/dumps/loads 白名单（6 文件，§4.8）
    ├── vectorstores/         → VectorStore 抽象 + InMemory 实现 + MMR（4 文件，§4.9）
    ├── embeddings/           → Embeddings 抽象 + fake（3 文件，§4.9）
    └── utils/                → ★ 通用工具库（21 文件，§4.11）
```

各目录职责速览：

| 目录 | 职责 | 包含的关键内容 |
|------|------|----------------|
| `runnables/` | 定义并扩展统一执行协议 | `Runnable`/`RunnableSerializable`/`RunnableSequence`/`RunnableParallel`/`RunnableLambda`、配置传播（config.py）、九种组合子、图构建与三种渲染 |
| `language_models/` | 模型接入契约与三套流式管线 | `BaseLanguageModel`→`BaseChatModel`/`BaseLLM`、`ChatModelStream`（v3）、`_compat_bridge`（v1→v2 桥）、fake 测试替身 |
| `messages/` | 提供商中立的消息与内容块 | `BaseMessage`/`AIMessage(Chunk)`/`ToolMessage`、`content.py` v1 块体系、`block_translators/` 7 提供商翻译器 |
| `outputs/` | 模型调用结果数据类 | `Generation`→`ChatGeneration`→`ChatGenerationChunk`、`ChatResult`/`LLMResult` |
| `prompts/` | 提示词模板化 | `PromptTemplate`（f-string/mustache/jinja2）、`ChatPromptTemplate.from_messages`、`MessagesPlaceholder`、few-shot 系列 |
| `output_parsers/` | 模型输出→结构化数据 | `BaseOutputParser` 模板结构、JSON/Pydantic/XML/列表/OpenAI 工具解析器 |
| `tools/` | Agent 工具体系 | `BaseTool` 执行管线、`@tool` 装饰器 + schema 推导、`StructuredTool` |
| `documents/` `document_loaders/` `indexing/` | RAG 数据面 | `Document`/`Blob`、惰性加载接口、`index()` 幂等增量索引 |
| `callbacks/` `tracers/` | 可观测性 | 事件分发（异常隔离）、`CallbackManager` 装配、LangSmith 上报、astream_events 引擎 |
| `load/` | 序列化/反序列化 | `Serializable.to_json` manifest、白名单四层防护、跨版本映射表 |
| `vectorstores/` `embeddings/` | 检索基础设施 | `VectorStore` 全家桶、`InMemoryVectorStore`（numpy 余弦）、MMR |
| `utils/` | 零业务依赖工具箱 | 脏 JSON 修复、mustache 引擎、pydantic v1/v2 兼容、深度合并算法、OpenAI function 转换 |
| `_api/` `_security/` | 治理与安全 | 弃用/beta 装饰器、SSRF 策略与安全 transport |
| 根目录散文件 | 横切接口与全局状态 | 全局开关、异常体系、缓存/限流/存储/检索器抽象 |

---

## 4. 核心模块详解（报告主体）

> 本批（批次 2）覆盖 `runnables/` 全部 16 个文件——LCEL 的协议核心（base/config/utils/schema）与组合子扩展（branch/router/retry/fallbacks/configurable/history/passthrough/graph*）。该模块在整体架构中处于 L1（Runnable 协议）+ L4（组合子）两层，是库内其他所有抽象的公共基座。

### 4.1 runnables/（一）：协议核心（base.py / config.py / utils.py / schema.py）

**模块职责**：定义整个 langchain-core 的执行协议 `Runnable`——一个可被 invoke/batch/stream/transform 并可用 `|` 算子声明式组合的"工作单元"接口，即 LCEL 的类型基座。库内几乎所有核心抽象都以 `RunnableSerializable` 为基类——提示词（`prompts/base.py:38` 的 `BasePromptTemplate`）、语言模型（`language_models/base.py:181` 的 `BaseLanguageModel`、`chat_models.py:284` 的 `BaseChatModel`）、输出解析器（`output_parsers/base.py:140`）、检索器（`retrievers.py:55`）、工具（`tools/base.py:433` 的 `BaseTool`）——因此任何链一旦用 `|` 拼起来就自动获得同步/异步/批量/流式/追踪能力。该模块同时通过 `RunnableConfig` + ContextVar 机制统一配置在调用树中的传播，并通过回调管理器把 tracing、LangSmith、astream_events 等观测能力埋进每一次执行的骨架。

#### 文件组成

| 文件 | 职责 | 关键导出 |
|---|---|---|
| `base.py`（6729 行） | `Runnable` 抽象基类及全部模板方法（invoke/batch/stream/transform 及 async 变体）、回调集成辅助（`_call_with_config` 等 4 件套）、组合原语（`RunnableSequence`/`RunnableParallel`）、适配器（`RunnableLambda`/`RunnableGenerator`）、装饰器（`RunnableBinding` 家族/`RunnableEach`）及 `coerce_to_runnable`/`chain` 入口 | `Runnable`、`RunnableSerializable`、`RunnableSequence`、`RunnableParallel`（=`RunnableMap`）、`RunnableGenerator`、`RunnableLambda`、`RunnableEach`、`RunnableBinding(Base)`、`coerce_to_runnable`、`chain`、`RunnableLike` |
| `config.py`（712 行） | `RunnableConfig` TypedDict 及配置规范化/合并/补丁/上下文传播；回调管理器工厂；线程池执行器与 `run_in_executor` | `RunnableConfig`、`ensure_config`、`patch_config`、`merge_configs`、`get_config_list`、`var_child_runnable_config`、`set_config_context`、`get_callback_manager_for_config`、`get_async_callback_manager_for_config`、`get_executor_for_config`、`run_in_executor`、`call_func_with_variable_args`/`acall_func_with_variable_args`、`ContextThreadPoolExecutor` |
| `utils.py`（799 行） | `Input`/`Output` 协变类型变量；可加和协议（`AddableDict`/`add`/`aadd`）；函数签名探测（`accepts_config` 等）；基于 AST 的 lambda 源码/闭包分析；可配置字段规格（`ConfigurableField` 家族）；async 并发工具 | `Input`、`Output`、`AddableDict`、`add`/`aadd`、`accepts_config`、`accepts_run_manager`、`coro_with_context`、`gather_with_concurrency`、`gated_coro`、`ConfigurableField(SingleOption/MultiOption)`、`ConfigurableFieldSpec`、`get_unique_config_specs`、`is_async_callable`、`is_async_generator`、`get_lambda_source`、`get_function_nonlocals` |
| `schema.py`（188 行） | `astream_events` 产出的流事件 TypedDict 模式定义 | `EventData`、`BaseStreamEvent`、`StandardStreamEvent`、`CustomStreamEvent`、`StreamEvent`（联合类型，schema.py:188） |
| `__init__.py`（136 行） | 包入口：`_dynamic_imports` 映射 + `__getattr__`（:128-132）惰性导入 | `__all__` 中 30 个符号（:63-93） |

#### 关键类/函数解析

**1. `Runnable`（base.py:134）—— 全库统一执行协议**

```python
class Runnable(ABC, Generic[Input, Output]):
```

- **做什么**：纯 ABC（非 Pydantic 模型），唯一抽象方法是 `invoke`（base.py:886-907）；其余方法全部有默认实现，子类按需覆写——典型的**模板方法模式**：基类固化"回调包裹 + 配置传播 + 输入输出类型推断"骨架，子类只填业务。
- **怎么实现**：
  - **Input/Output 泛型推断**（`InputType` base.py:309-342、`OutputType` :344-373）：两段式查找——先沿 `self.__class__.mro()` 找带 `__pydantic_generic_metadata__` 的 Pydantic 父类取其 `args`；再退化查 `__orig_bases__`。`get_input_schema`（:380-419）据此把类型注解经 `create_model_v2`（带 `module_name=self.__class__.__module__` 以正确解析前向注解，:418）转成 Pydantic 模型。
  - **核心模板方法群**（sync/async 成对）：
    - `ainvoke`（:909-930）默认 `await run_in_executor(config, self.invoke, ...)`——任何只实现 `invoke` 的子类自动获得 async 能力；
    - `batch`（:932-980）：空输入短路；单输入直接同步调用绕开线程池（:976-977）；多输入用 `get_executor_for_config` 线程池并行，`return_exceptions=True` 时闭包内捕获异常放进结果；
    - `batch_as_completed`（:1002-1065）：`executor.submit` + `concurrent.futures.wait(FIRST_COMPLETED)` 循环，完成即 yield `(index, output)`；`finally` 取消未完成 futures（:1063-1065）防泄漏；
    - `abatch`（:1067-1113）：`gather_with_concurrency`——Semaphore 门控并发而非裸 gather；
    - `stream`（:1195-1214）默认一次性 `yield self.invoke(...)`（"不支持流式"的退化实现）；`transform`（:1761-1804）为流式核心原语：默认先缓冲整个输入迭代器、用 `+` 聚合 chunk（`TypeError` 则退化为"只保留最后一个 chunk"，:1798-1801）再调 `self.stream(final, ...)`。这个"try `+`、失败取末块"的聚合策略在整个文件反复出现（:2576-2581、5179-5182、5379-5382 等），是流式 chunk 合并的统一约定。
  - **`astream_events`**（:1369-1599 + `_astream_events_v1_v2` :1616-1672）：按 `version` 分发——v3 基类抛 `NotImplementedError`（:1601-1614，仅 `BaseChatModel` 覆写支持）；v2 委托 `tracers.event_stream._astream_events_implementation_v2`；v1 打废弃警告后基于 astream_log。末尾用 `aclosing(event_stream)` 包裹（:1670）确保生成器被正确关闭。
  - **组合算子**：`__or__`（:649-674）/`__ror__`（:698-723）返回 `RunnableSequence(self, coerce_to_runnable(other))`；`pick`（:774）、`assign`（:837，委托 `RunnableAssign(RunnableParallel(kwargs))`）是语法糖。
  - **装饰器家族**（全部返回新对象、不可变风格）：`bind`（:1852→`RunnableBinding`）、`with_config`（:1886）、`with_listeners/with_alisteners`（:1911/1983，经 `config_factories` 注入 `RootListenersTracer`）、`with_types`（:2080）、`with_retry`（:2102→`RunnableRetry`）、`with_fallbacks`（:2192）、`map`（:2169→`RunnableEach`）、`as_tool`（:2711，委托 `tools.convert_runnable_to_tool`）。
- **副作用与注意**：`config.pop("run_id", None)`（如 :2298）会**原地修改**传入 config dict；`transform` 默认实现会无限缓冲输入（内存风险）；`name` 是普通类属性而非 Pydantic 字段（`RunnableSerializable` 在 :2834 补了 `name: str | None = None` 字段）。
- **调用关系**：被 `BasePromptTemplate`/`BaseLanguageModel`/`BaseOutputParser`/`BaseRetriever`/`BaseTool` 继承；调用 `config.py` 的 ensure/patch/merge/get_executor_for_config/run_in_executor、`utils.py` 检测函数、`tracers` 三个流实现、`callbacks.manager` 双管理器。

**2. `_call_with_config` / `_transform_stream_with_config`（base.py:2272 / :2506）—— 子类实现的标准骨架**

- `_call_with_config`：`ensure_config` → `get_callback_manager_for_config` → `on_chain_start` → `set_config_context(child_config)` 内 `context.run(call_func_with_variable_args, func, ...)` → 成功 `on_chain_end` / 失败 `on_chain_error` 后 re-raise。`child_config = patch_config(config, callbacks=run_manager.get_child())`（:2301）保证孙运行挂在子运行下；try/except/else 结构确保异常路径闭环。调用方：`output_parsers/base.py:101`、`prompts/base.py:230`、`RunnableLambda.invoke`（:5327）等。
- `_transform_stream_with_config`（全模块最精巧方法）：① `tee(inputs, 2)` 把输入流分成 tracing 用和 transform 用两份（:2531）；② **先 `next(input_for_tracing, None)` 拉一次**（:2533）保证上游先启动；③ `on_chain_start(None, {"input": ""}, ...)`（真实输入流结束时回填）；④ 若 handler 有 `_StreamingCallbackHandler` 则用 `tap_output_iter` 挂接（:2556-2568，astream_log 拿到 streamed_output 的机制）；⑤ 逐 chunk yield 同时用 `+` 聚合 final_output；⑥ `StopIteration` 后聚合 `final_input` 并 on_chain_end/error。async 版用 `atee`/`coro_with_context(anext(...))`，`finally` 中 `aclose()` 上游迭代器（:2707-2709）防泄漏。

**3. `RunnableSequence`（base.py:3079）—— LCEL 最重要的组合算子**

- 字段刻意拆成 `first/middle/last`（:3166-3171）**纯粹为了类型检查**（输入类型取 first、输出类型取 last）；`steps` property（:3224）重组完整列表。`__init__`（:3173-3212）**嵌套 Sequence 会被拍平**（:3197-3198），至少 2 步否则 ValueError。
- `invoke`（:3434-3467）：责任链 for 循环，每步 `patch_config(config, callbacks=run_manager.get_child(f"seq:step:{i+1}"))` 生成带序号子运行标签；**kwargs 只传给第 0 步**（:3457-3460）。
- `batch`（:3510-3635）：**不逐 input 调 invoke，而是逐步调每个 step 的 batch**（:3605）——让底层原生批量 API 的优化透传；`return_exceptions=True` 时用 `failed_inputs_map` 跟踪失败输入，后续 step 只对存活输入执行。
- **流式**：`_transform`（:3768-3789）把各 step 的 `transform` 生成器逐层套接成管道 `final_pipeline = step.transform(final_pipeline, config)`——**生成器惰性流水线**：不支持流式的步骤在管道中充当缓冲闸，输出流只会在最后一个阻塞步骤之后开始。
- `get_graph`（:3296-3327）：逐 step 取子图、`trim_first_node()/trim_last_node()` 后 `graph.extend` 并连边。
- 注意：RunnableLambda 默认不支持 transform（会缓冲），需流式自定义逻辑应使用 `RunnableGenerator`（docstring :3107-3113 明确警告）。

**4. `RunnableParallel`（base.py:3868，别名 `RunnableMap` :4400）—— 扇出原语**

- `invoke`（:4143-4200）：`CallbackManager.configure` 手动组装管理器 → 每步 `executor.submit`，子运行标签 `map:key:{key}`（:4171），`{key: future.result()}` 收集；执行前浅拷贝防调用中步骤被改（:4183）。async 版用 `asyncio.gather` + `coro_with_context`。
- **流式 `_transform`（:4257-4301）是本类精华**：`safetee(inputs, len(steps), lock=threading.Lock())` 把单一输入流复制成 N 份；每个 step 拿一份建 transform 生成器；`wait(futures, FIRST_COMPLETED)` **竞速循环**——谁先产出就 `yield AddableDict({step_name: chunk})` 并立刻 resubmit 该生成器的下一次 next。即多路输出流被**交错复用**成 `AddableDict` 增量序列，消费端靠 `AddableDict.__add__`（utils.py:473）按 key 累加还原。
- 副作用：最慢的一路会拖住其它路对输入的拉取（safetee 背压全局共享）。

**5. `RunnableLambda`（base.py:4707）与 `RunnableGenerator`（base.py:4403）**

- `RunnableLambda`：把任意 callable 变成 Runnable（`coerce_to_runnable` 的兜底，:6660-6661）。`_invoke`（:5160-5203）经 `call_func_with_variable_args` 自动注入 config/run_manager；**输出本身是 Runnable 时递归 invoke，用 `recursion_limit - 1` 做 patch_config 并在 ≤0 时抛 RecursionError**（:5188-5202）——防动态路由无限递归的安全阀。**Schema 智能**（本类特色）：无注解时用 `get_function_first_arg_dict_keys`（AST 分析函数体 `x["k"]`/`x.get("k")` 的键）反推 dict 输入 schema；`deps` cached_property（:5072-5094）用 `get_function_nonlocals`（AST+闭包分析）找出函数引用的 Runnable 作为"依赖"，`get_graph` 据此并联依赖图。
- `RunnableGenerator`：把 `Iterator[A] -> Iterator[B]` 形态的**生成器函数**包装成流式原生 Runnable——能消费输入流并边收边发；`invoke` 反向建立在流式之上（消费 stream 并 `+` 累加，:4662-4668）。

**6. `RunnableBindingBase` / `RunnableBinding`（base.py:5855 / 6382）—— 装饰器模式标准实现**

- `bind/with_config/with_retry` 等方法的落点。持有 `bound`（被装饰 Runnable）、`kwargs`、`config`、`config_factories`。所有执行方法（invoke :6012、batch :6038、stream :6189、transform :6355 等）都是同一模式：`self.bound.<method>(input, self._merge_configs(config), **{**self.kwargs, **kwargs})`——纯转发 + 配置/参数合并，**不产生自己的 run**（tracing 树中透明）。
- `__getattr__`（:6553-6587）是**签名感知代理**：属性访问转给 `self.bound`，若目标方法带 `config` 参数则自动合并 `self.config`——使 `binding.some_method(...)` 也享受绑定配置。`RunnableRetry`（retry.py）、`_ChatModelBinding`（chat_models.py:2568）是其子类。

**7. `coerce_to_runnable`（base.py:6644-6668）**：分派表——Runnable→原样；生成器函数→`RunnableGenerator`；callable→`RunnableLambda`；dict→`RunnableParallel`；其它 TypeError。这是 `|` 算子能接受裸函数、dict、生成器的机制根源。

**8. config.py 的配置传播机制（横切核心）**

- `RunnableConfig`（:57-128）：TypedDict `total=False`，8 个标准键（tags/metadata/callbacks/run_name/max_concurrency/recursion_limit[默认 25]/configurable/run_id）；`CONFIG_KEYS` 白名单（:131-140）；`COPIABLE_KEYS`（:142-147）标记合并时须 `.copy()` 的键。
- `var_child_runnable_config`（:174-176）+ `set_config_context`（:224-252）：ContextVar 隐式传播核心——父调子不显式传 config 时，`ensure_config` 从 ContextVar 捞 ambient 配置作基底；`copy_context()` 副本中设值后 `context.run(fn)` 使用；同时检测 LangChainTracer 并同步 langsmith 的 tracing context（:199-219，保证 LangSmith 嵌套追踪）。langsmith 延迟导入是为省 ~132ms 启动时间（:191 注释）。
- `ensure_config`（:255-308）**三层合并算法**：① 默认值（recursion_limit=25 等）→ ② ambient ContextVar 配置覆盖（COPIABLE_KEYS 逐键 copy）→ ③ 显式 config 覆盖（只取白名单内键）。特例：非白名单键**降级塞进 `configurable`**（:293-296，向后兼容旧式传参）；`configurable` 里的 `model`/`checkpoint_ns` 镜像进 `metadata`（:297-307，langgraph 检查点命名空间可见性）。
- `patch_config`（:357-396）：生成"子运行 config"的唯一途径；**替换 `callbacks` 时同时删除 `run_name` 和 `run_id`**（:380-387）——换 callbacks 即换 run 边界。
- `merge_configs`（:431-494）：逐键专门语义——metadata 经 `_merge_metadata_dicts`（last-writer-wins，唯独嵌套 `lc_versions` 递归合并）；tags 去重排序；callbacks 处理 **6 种组合**（None/list/manager 两两组合，:459-486）。
- `ContextThreadPoolExecutor`（:607-656）覆写 `submit/map` 把 `copy_context().run` 绑进任务——**让 ContextVar 跨线程传播**；`run_in_executor`（:678-712）：async 里跑 sync 函数的通用桥，`wrapper` 把 `StopIteration` 转 `RuntimeError`（:696-703，asyncio Future 不接受 StopIteration）。全库 async 默认实现的基石。

**9. utils.py 要点**

- `Input`(contravariant)/`Output`(covariant) 类型变量（:45-47）是 Runnable 泛型体系的类型学根基；`AddableDict`（:470-529）覆写 `__add__` 按 key 逐个相加、类型不兼容抛 TypeError——`RunnableParallel` 流式增量的载体。
- AST 分析家族（:162-467）：`IsFunctionArgDict`（推断 dict 输入键）、`NonLocals`（闭包依赖分析）、`GetLambdaSource`（lambda 源码还原）；`get_function_nonlocals` 带 `@lru_cache(256)` 缓存 + `inspect.getclosurevars` 把 AST 名字解析为真实对象。全部对 `SyntaxError` 等静默降级——REPL/动态构造的函数优雅失效。
- `ConfigurableField` 家族（:576-679）：三个 NamedTuple 描述"可配置字段"声明；`get_unique_config_specs`（:681-710）按 `(id, *dependencies)` 去重，同 id 内容冲突抛 ValueError。
- `_RootEventFilter`（:713-765）：astream_events 的 include/exclude×names/types/tags 布尔过滤器。

#### 模块对外接口

`Runnable`/`RunnableSerializable`（被五大基类继承）；`|` 算子与 `coerce_to_runnable`（LCEL 组合入口）；`RunnableConfig` 全家（配置传播标准）；`AddableDict`（流式 dict 增量协议）；`StreamEvent` schema（事件流契约）。

### 4.2 runnables/（二）：组合子扩展（branch/configurable/fallbacks/graph*/history/passthrough/retry/router）

**模块职责**：LCEL 的"组合子层"，提供运行时行为编排原语：条件分支、按 key 路由、失败回退、重试、动态配置替换、消息历史注入、输入透传与键合并。每个组合子均以 `RunnableSerializable`（Pydantic 模型）实现，天然支持序列化、`config_specs` 配置声明，并提供成对 sync+async 实现。graph*.py 子族把任意 Runnable 递归构建成 DAG 并渲染为 ASCII/Mermaid/PNG。

#### 文件组成

| 文件 | 职责 | 关键导出 |
|---|---|---|
| `branch.py` | 条件分支：按 `(condition, runnable)` 顺序短路求值 | `RunnableBranch` |
| `configurable.py` | 动态配置：invoke 时依据 `config["configurable"]` 重建/替换底层 Runnable | `DynamicRunnable`、`RunnableConfigurableFields`、`RunnableConfigurableAlternatives`、`prefix_config_spec`、`make_options_spec` |
| `fallbacks.py` | 容错：主 Runnable 抛指定异常时按序尝试 fallbacks | `RunnableWithFallbacks`、`_returns_runnable` |
| `graph.py` | 运行图数据结构：Node/Edge/Graph 增删、子图嵌入、ID 重写 | `Graph`、`Node`、`Edge`、`Branch`、`CurveStyle`、`NodeStyles`、`MermaidDrawMethod`、`is_uuid` |
| `graph_ascii.py` | 基于 grandalf Sugiyama 布局的 ASCII 渲染 | `draw_ascii`、`AsciiCanvas`、`VertexViewer` |
| `graph_mermaid.py` | Mermaid 文本生成 + Mermaid.INK API/pyppeteer 渲染 PNG | `draw_mermaid`、`draw_mermaid_png`、`_to_safe_id` |
| `graph_png.py` | 基于 pygraphviz 的 PNG 渲染（dot 布局，cluster 子图） | `PngDrawer` |
| `history.py` | "读历史→执行→写回"包装（1.3.3 起 deprecated，推荐 LangGraph persistence） | `RunnableWithMessageHistory`、`GetSessionHistoryCallable` |
| `passthrough.py` | 恒等透传（可挂副作用）、dict 键合并赋值、键挑选 | `RunnablePassthrough`、`RunnableAssign`、`RunnablePick`、`identity`/`aidentity` |
| `retry.py` | 基于 tenacity 的重试绑定：指数抖动退避、batch 级增量重试 | `RunnableRetry`、`ExponentialJitterParams` |
| `router.py` | 按 `input["key"]` 静态查表路由 | `RouterRunnable`、`RouterInput` |
| `__init__.py` | `__getattr__` 惰性导入门面（30 项导出） | — |

#### 关键类/函数解析

**1. `RunnableBranch`（branch.py:43）**：声明式 if/elif/else。条件谓词也经 `coerce_to_runnable` 包装（因此条件可以是一次 LLM 调用）。`invoke`（:184-241）：for 循环逐分支 `condition.invoke(...)` 求值（子运行 tag=`condition:{idx+1}`），为真则执行分支（tag=`branch:{idx+1}`）并 break；**用 Python 的 for-else 语法**（:229-236）实现"循环耗尽才走 default"。流式时 `TypeError` 置 `final_output_supported=False` 优雅降级（:341-349）。

**2. `DynamicRunnable`（configurable.py:50）——动态配置骨架**

核心机制是 **`prepare` 解包循环（:119-133）**：

```python
runnable, config = self, config
while isinstance(runnable, DynamicRunnable):
    runnable, config = runnable._prepare(merge_configs(runnable.config, config))
```

用 **while 循环而非递归**层层剥开嵌套 DynamicRunnable（`configurable_alternatives` 套 `configurable_fields` 时），每层合并 `self.config` 与调用时 config 后交给 `_prepare` 换出真实 Runnable。所有执行方法第一行都是 `runnable, config = self.prepare(config)` 再转发——"每次调用时动态解析，包装器自身零执行逻辑"。`__getattr__` 透明代理（:278-314）：转发属性时若发现"长得像 config 的 dict"参数（含 `configurable` 键）先 `self.prepare(arg)`——保证 `configurable_model.bind_tools(...)` 也能吃到运行时配置。

- **`RunnableConfigurableFields`（:317）——字段级替换**：`_prepare`（:419-458）建立"配置 id→字段名"索引，解析三类字段（`ConfigurableField` 直取原始值 / SingleOption 查 `options` 映射表 / MultiOption 产出 list），然后**重建实例**：`init_params = {k: v for k, v in self.default.__dict__.items() if k in type(self.default).model_fields}; return self.default.__class__(**{**init_params, **configurable})`（:448-457）——不可变更新风格，每次 invoke 构造新底层对象。temperature/model 等 Pydantic 字段被运行时替换的本质。
- **`RunnableConfigurableAlternatives`（:474）——运行时选模型**：`_prepare`（:611-637）读 `config["configurable"][which.id]`；`prefix_keys=True` 时把 `"<which.id>==<chosen>/"` 前缀从键上剥掉（命名空间机制，使选中备选收到自己的字段配置）；备选可存 `Callable[[], Runnable]` 工厂惰性构造（:631-635）。

**3. `RunnableWithFallbacks`（fallbacks.py:37）**：invoke（:164-212）逐 runnable 尝试，`except self.exceptions_to_handle` 继续，全部失败 `raise first_error`（**首个异常优先**，:211-212）；`exception_key` 会把 last_error 写进输入 dict（**原地修改调用者 dict**，:188-189）。batch（:264-358）是**批级部分回退**：维护 `run_again` 待重试索引，每轮只对未成功项重试。stream（:464-526）**只在首 chunk 前可回退**：急切拉取第一个 chunk 判断成功（:500），yield 过数据后不再回退（无法回收已发出 chunk）。`__getattr__`（:592-645）经 `typing.get_type_hints` 检测返回类型为 Runnable 的方法（如 `bind_tools`），对主模型与**每个 fallback** 都调用并重建自身。

**4. `Graph`/`Node`/`Edge`（graph.py:254/95/65）**：Runnable 自省（`get_graph`）的中间表示。**节点 ID 双轨制**：自动 ID = uuid4().hex；语义 ID = 带冒号前缀（`is_uuid` :49-62 区分）。`extend(graph, prefix)`（:386-422）嵌入子图时加 `"{prefix}:{id}"` 前缀——但子图全 UUID 则不加（天然无冲突）；冒号成为"子图层级"编码，Mermaid/PNG 渲染据此建 subgraph/cluster。`reid()`（:424-457）只重写 UUID 节点为可读名。`first_node`（:459）= 唯一入度 0 节点，候选不唯一返回 None；`trim_first_node/trim_last_node`（:483-507）去掉 Runnable 图占位起止节点。渲染入口全部**局部导入**渲染模块以避免循环依赖（:515-516 等）。

**5. `graph_ascii.py`**：grandalf 为可选依赖；`_build_sugiyama_layout`（:201-244）转换后 `SugiyamaLayout.init_all(draw)` 布局、`route_with_lines` 边路由；`AsciiCanvas.line`（:117-147）是 Bresenham 风格插值。

**6. `graph_mermaid.py`**：`draw_mermaid`（:45）按 ID 冒号分组建 subgraph（:116-122）、重复子图名抛 ValueError（:171-180）、`_to_safe_id`（:255-266）把非法字符转义为 `\x<hex>`；`draw_mermaid_png`（:277-331）两条路径——API（base64 拼 mermaid.ink URL，5xx 指数退避重试，:459-496）/ pyppeteer 无头浏览器。

**7. `RunnableWithMessageHistory`（history.py:40）——get_session_history 读取流程**

- 构造（:251-383）先组装内部链：`history_chain = RunnableLambda(self._enter_history, ...)`（:333-335）；有 `history_messages_key` 时再包 `RunnablePassthrough.assign(**{key: history_chain})`；主 runnable 挂 on_end 监听器（`_exit_history`）负责事后写回；最终 `bound = history_chain | check_sync_or_async` 交给 `RunnableBindingBase`。
- **`_merge_configs` 覆写（:582-626）是工厂调用点**：校验 `history_factory_config` 声明的键都在 `config["configurable"]` 里（:588-601），经 `_get_parameter_names`（反射工厂签名，:629-631）判定调用方式（单键按位置 / 零参直接调 / 多键按关键字），把返回的 history 实例**注入 `config["configurable"]["message_history"]`**（:625）——历史对象每次调用创建一次、经 config 隐式传递。
- **读取 `_enter_history`（:522-532）**：`hist.messages.copy()` 拷贝历史 + 归一化当前输入（`_get_input_messages`，:453-489）追加；**写回 `_exit_history`（:548-563）**：从 tracer 的 Run 对象还原输入输出，无 `history_messages_key` 时用 `input_messages[len(historic_messages):]` 切片剥掉历史部分防重复入库（:556-558）。

**8. `RunnablePassthrough`/`RunnableAssign`/`RunnablePick`（passthrough.py:74/352/679）**

- `RunnablePassthrough.assign`（:205-223）：`return RunnableAssign(RunnableParallel(kwargs))`——assign 的并行性来自 RunnableParallel。
- **`RunnableAssign._transform` 流式双流并行（:542-588）**：`safetee(values, 2)` 把输入流 tee 成两份，一份喂 `mapper.transform`，一份留给透传；`executor.submit(next, map_output, None)`（:565-571）**在后台线程立即拉取 map 输出首 chunk 点火整条并行管线**（否则生成器惰性导致 mapper 不启动）；主线程消费透传流时过滤掉 `mapper_keys` 中的键（避免旧值与 mapper 输出相加冲突），透传耗尽后再 yield map 输出剩余部分。
- `RunnablePick._pick`（:752-762）：单键返回值本身，多键返回 `AddableDict` 子集。

**9. `RunnableRetry`（retry.py:50）**：把 tenacity 的 `Retrying/AsyncRetrying` 适配到 Runnable 体系。`_invoke`（:186-202）：`for attempt in self._sync_retrying(reraise=True): with attempt:` 把 super().invoke 置于 tenacity 管理块中，成功后**手动 `attempt.retry_state.set_result(result)`**；每次尝试子回调带 `retry:attempt:N` tag。`_batch`（:234-295）**增量重试**：`results_map` 按原始索引累积成功项，每轮只对 `remaining_indices` 重试。`stream()/transform()` **刻意不重试**（:385-386 注释：流的重试语义不直观）。

**10. `RouterRunnable`（router.py:46）**：输入契约 `RouterInput = TypedDict(key, input)`（:37-43）；invoke（:106-133）取 `input["key"]` 查 `runnables` 映射，未命中抛 ValueError——**静态路由**（key 是数据的一部分，区别于 RunnableBranch 的动态条件求值）。batch（:135-170）不同输入可路由到不同 Runnable 仍整体并行。

#### 模块对外接口

九种组合子类（用户直接构造或经 `Runnable.with_retry/with_fallbacks/configurable_fields/configurable_alternatives/assign/pick/map` 进入）；`Graph` 渲染三入口（`draw_ascii/draw_mermaid/draw_png`）；`RunnableWithMessageHistory`（遗留）。

---

### 4.3 language_models/ + outputs/（模型接入契约与结果数据类）

> 本批（批次 3）上半部分。`language_models` 是生态"模型接入层"的契约定义：所有 partner 包只需实现 `_generate`（必需）和 `_stream`/`_agenerate`/`_astream`（可选）钩子，即可免费获得 invoke/batch/stream/astream、回调追踪、LLM 缓存、限流、重试、bind_tools 等全部横切能力。`outputs` 定义模型调用的返回数据类，是回调与缓存系统交换载荷的通用货币。

#### 文件组成（language_models/，10 文件）

| 文件 | 职责 | 关键导出 |
|---|---|---|
| `base.py`（17KB） | 最顶层抽象 `BaseLanguageModel`：公共字段、`generate_prompt` 抽象接口、LangSmith 追踪参数类型、GPT-2 兜底分词器 | `BaseLanguageModel`、`LangSmithParams`、`LanguageModelInput/Output/Like`、`get_tokenizer` |
| `chat_models.py`（107KB） | **核心**：`BaseChatModel` 完整模板方法链（invoke/generate/stream/batch/stream_events v1-v3）、缓存与限流集成、`bind_tools`/`with_structured_output`、`SimpleChatModel` 简化基类、`_ChatModelBinding` | `BaseChatModel`、`SimpleChatModel`、`generate_from_stream`、`agenerate_from_stream` |
| `chat_model_stream.py`（60KB） | v3 流式聚合对象：`ChatModelStream`（同步，游标+拉取回调背压）/`AsyncChatModelStream`（异步，后台 producer task）+ 投影体系 | `ChatModelStream`、`AsyncChatModelStream`、`SyncProjection`、`AsyncProjection` |
| `llms.py`（55KB） | 传统 string-in/string-out 模型：`BaseLLM`（批级缓存、批量 API 利用）与 `LLM`（只需 `_call`）、save/序列化 | `BaseLLM`、`LLM`、`create_base_retry_decorator`、`get_prompts`/`update_cache` |
| `fake.py` | 传统 LLM 测试替身（按列表循环返回响应） | `FakeListLLM`、`FakeStreamingListLLM` |
| `fake_chat_models.py` | 聊天模型测试替身家族（循环字符串/消息、逐字符流式、鹦鹉回声） | `FakeListChatModel`、`GenericFakeChatModel`、`ParrotFakeChatModel` |
| `model_profile.py` | `ModelProfile` TypedDict：模型能力元数据（上下文窗口、tool_calling 等，数据源自 models.dev） | `ModelProfile`、`ModelProfileRegistry` |
| `_compat_bridge.py`（32KB） | **新旧 API 兼容桥**：把 `_stream` 的 chunk 流适配为 v2 协议事件生命周期；反向把已定稿 AIMessage 重放为合成事件流（缓存命中/检查点恢复） | `chunks_to_events`、`achunks_to_events`、`message_to_events`、`finalize_tool_call_chunk` |
| `_utils.py` | 内部工具：追踪参数过滤、OpenAI 多模态块识别、消息内容块 v0→v1 归一化 | `_normalize_messages`、`_filter_invocation_params_for_tracing`、`_update_message_content_to_blocks` |
| `__init__.py` | 惰性导出门面 | 20 个符号 |

#### 关键类/函数解析

**1. `BaseLanguageModel`（base.py:181）—— 生态根契约**

`class BaseLanguageModel(RunnableSerializable[LanguageModelInput, LanguageModelOutputVar], ABC)`。字段 `cache/verbose/callbacks/tags/metadata/custom_get_token_ids`（:190-215）全部 `exclude=True`（回调、缓存实例不可序列化）。`model_post_init`（:222）向 `metadata["lc_versions"]` 注入 langchain-core 及（若装）langchain 版本——docstring 警告 partner 不要重写此方法而应在自己的 validator 里调 `_add_version`（Pydantic v2 同名 validator 是替换而非链式）。token 统计兜底链：`get_token_ids`（:434）→ 用户注入 → `_get_token_ids_default_method`（:119，惰性加载 `GPT2TokenizerFast`，首次使用发一次性警告）→ `get_num_tokens_from_messages`（:465）对每条消息 `get_buffer_string` 后求和。

**2. `BaseChatModel`（chat_models.py:284）—— 最重要的模板方法链**

**完整同步调用链**：

```
invoke (chat_models.py:475)
  └─ _convert_input (461)               # str/StringPromptValue/序列 → PromptValue
  └─ generate_prompt (1869)             # → list[BaseMessage]
       └─ generate (1592)               # ★ 批量编排层
            ├─ CallbackManager.configure (1653)
            ├─ on_chat_model_start (1668) → 返回 run_managers
            ├─ for 每条消息: _generate_with_cache (1892)  # ★ 单次执行层
            ├─ on_llm_end（1708-1715）
            └─ 组装 LLMResult
  └─ 取 .generations[0][0].message → AIMessage (497)
```

`ainvoke`（:502）→ `agenerate`（:1718）对称，用 `asyncio.gather` 并发且 `return_exceptions=True`：先对所有异常逐个触发 `on_llm_error`、再对成功项补发 `on_llm_end`、最后 `raise exceptions[0]`（:1820-1846）——保证回调生命周期闭环。**batch 不重写**——直接继承 Runnable 的线程池实现（docstring :299-302 明示），与 BaseLLM 形成对比。

**`_generate_with_cache`（:1892）内的三分支执行策略**：

1. **v2 协议事件分支**（:1942-1966）：挂了 `_V2StreamingCallbackHandler` 且模型有事件源时，创建 `ChatModelStream` 累加器抽干事件流再构造 ChatResult——让 invoke 路径也能驱动逐事件回调；
2. **v1 流式分支**（:1969-2020）：循环 `self._stream(...)` 合并 metadata、逐 chunk 触发 `on_llm_new_token`；结束后若末 chunk 未标记则补发空内容的 `chunk_position="last"` 哨兵 chunk（:2003-2019）；`generate_from_stream`（:218，`generation += list(stream)` 用 `ChatGenerationChunk.__add__` 折叠）转完整 AIMessage；
3. **`_generate` 钩子分支**（:2021-2026）：用 `_signature_parameters(self._generate).get("run_manager")` **签名内省**判断子类是否声明 run_manager 参数——兼容旧版第三方实现的渐进式 API 演进手法。

`_generate`（:2208）是唯一 `@abstractmethod`；`_agenerate`（:2228）默认 `run_in_executor` 包装同步版；`_stream`（:2255）默认 `raise NotImplementedError`。

**能力探测（函数同一性）**：`_should_stream`/`_streaming_disabled`（:549/:525）用 `type(self)._stream == BaseChatModel._stream`（:559-560）判断子类是否实现流式——比 `hasattr` 可靠。`disable_streaming == "tool_calling"` 且传了 tools 时自动降级非流式（:337-353）。

**缓存集成**：`llm_cache = self.cache if isinstance(self.cache, BaseCache) else get_llm_cache()`（:1892-1929，全局缓存唯一入口）；缓存键 = `prompt`（`dumps` **去掉 id 的消息副本**，:1907-1915——避免消息 id 抖动导致永远 miss）+ `llm_string`（`_get_llm_string` :1578，可序列化模型走 `dumpd(self)` → `_cleanup_llm_representation`（:2726，递归剔除 not_implemented 与 graph 字段）→ JSON + 排序参数）。命中后 `_convert_cached_generations`（:1405）把遗留 Generation 转 ChatGeneration、**把命中消息的 `usage_metadata.total_cost` 置 0**（:1434-1442）再 `_replay_v2_events_for_cache_hit`（:1446，把缓存消息重放成 on_stream_event——热缓存与冷调用产生相同事件流）。限流器在缓存检查**之后**才 acquire（:1931-1935 注释：缓存查询不限流）。

**tracing 集成**：每次 generate 前 `inheritable_metadata = {**(config/metadata), **self._get_ls_params_with_defaults(...)}`（:1648-1651）——把 `ls_provider/ls_model_name/ls_temperature` 等揉进可继承元数据；`_get_ls_params`（:1502）基类 best-effort 推导（provider 从类名剥 Chat 前后缀小写化），docstring 要求 partner 重写。错误路径 `_generate_response_from_error`（:112）从异常 response 提取 body/headers/status_code 组装空 AIMessage 的 generation，让 `on_llm_error` 携带可观测元数据。消息 id 回填 `f"{LC_ID_PREFIX}-{run_manager.run_id}-{idx}"`（:2038）。

**`with_structured_output`（:2385）——默认的通用结构化输出实现**：① 用 `type(self).bind_tools is BaseChatModel.bind_tools` 探测；未实现抛 NotImplementedError（:2536-2538）；② `llm = self.bind_tools([schema], tool_choice="any", ls_structured_output_format=...)`（:2540-2547）；③ 解析器选择：Pydantic 子类 → `PydanticToolsParser(first_tool_only=True)`，否则 `JsonOutputKeyToolsParser`（:2548-2555）；④ `include_raw=True` 时构造 `RunnableMap(raw=llm) | parser_with_fallback`，解析错误经 `with_fallbacks(exception_key="parsing_error")` 装进结果 dict。

**`bind`（:2355）返回 `_ChatModelBinding`（:2568）**：RunnableBinding 子类，存在意义仅是保住 `stream_events(version="v3")` 的类型化 overload（`lc_id` 仍序列化为 RunnableBinding 保持快照稳定，:2582-2591）。

**3. `chat_model_stream.py` —— v3 流式聚合**

```
协议事件（MessagesData）──dispatch──▶ _ChatModelStreamBase（:556，状态机+累加器）
                                        │
              SyncTextProjection(.text) / (.reasoning) / SyncProjection(.tool_calls)
                                        │
                          _blocks: dict[int, FinalizedContentBlock] ← .output 的唯一真身
                                        │
                          _finish → _assemble_message → AIMessage
```

同步版用**游标+拉取回调（pull-based backpressure）**（对齐 langgraph EventLog 的 `_request_more` 约定）；异步版用**后台 producer task + asyncio.Event 通知**。`dispatch`（:663）按事件分发：message-start/content-block-delta/content-block-finish/message-finish/error。增量合并 `_push_content_block_delta`（:698）三路写入（消息级累加器、按 wire index 的 per-block 累加器、投影）——per-block 累加器防前一同类型块文本"bleed"进后一块。块定稿（:876）做**权威文本和解**：finish 带的 full_text 与累计 delta 不一致时按前缀扩展等情形补偿。`_assemble_message`（:1046）**即使只有一个 text 块也不塌缩成裸字符串**（:1062-1067 注释：保留块级 id/index 供后续轮次序列化往返）。`aclose`（:1413）的取消语义精细：已成功产出消息则改为 await 收尾（不把成功流改成 cancelled，否则丢 on_llm_end 破坏追踪）；等待任务用关联 Future 而非直接 await task（区分"我们取消的"与"调用方取消的"两种 CancelledError）。

**4. `BaseLLM`（llms.py:296）与 BaseChatModel 对比**

| 维度 | BaseChatModel | BaseLLM |
|------|---------------|---------|
| 输入/输出 | 消息列表 → AIMessage | 字符串 prompt → str |
| 钩子 | `_generate(messages)` | `_generate(prompts) -> LLMResult`（:660，**批量签名**） |
| 简化基类 | SimpleChatModel._call（:2679） | LLM._call（:1464） |
| 缓存粒度 | 单条（_generate_with_cache 内逐条） | **批级**：`get_prompts`（:159）分组，只为缺失项建 run（:1036-1047），`update_cache`（:230）回填 |
| batch | 继承 Runnable 线程池 | **重写**（:421/468）：无 max_concurrency 时单次批量调用（:437-445，利用供应商批量 API）；有则按窗口分块递归 |
| 限流 | rate_limiter 字段 + 4 处 acquire | 无 |
| 独有能力 | bind_tools/with_structured_output/profile/v2/v3 协议 | `save()`（:1404，yaml/json 持久化）、`create_base_retry_decorator`（:77，tenacity 指数退避 4-10s） |

**5. `_compat_bridge.py`**：让只实现 v1 `_stream` 的存量模型驱动 v2 事件回调。信任 `AIMessageChunk.content_blocks` 作为唯一协议视图；**每 chunk 的 content_blocks 是增量切片而非累计状态**，直接透传为 content-block-delta，仅为最终 finish 维护 per-index 累计。生命周期 `message-start → content-block-start → content-block-delta* → content-block-finish → message-finish`。`finalize_tool_call_chunk`（:359）把累计 args 字符串 `json.loads` 成 ToolCall，失败降级 InvalidToolCall。`message_to_events`（:776）服务缓存命中重放。块身份解析的脆弱性（无 index 块按 `("__lc_no_index__", type, 位置)` 分桶）在 :165-184 长注释中坦白。

**6. outputs/ 数据类体系（6 文件）**

```
Serializable (load)
  └─ Generation (generation.py:11)                 text + generation_info
       ├─ GenerationChunk (55)                     __add__: text 拼接 + merge_dicts
       └─ ChatGeneration (chat_generation.py:17)   message + set_text 校验器
            └─ ChatGenerationChunk (77)            __add__ 支持 list
BaseModel
  ├─ ChatResult (chat_result.py:10)                generations + llm_output（_generate 钩子返回类型）
  ├─ LLMResult (llm_result.py:15)                  二维 generations + run（回调载荷）
  └─ RunInfo (run_info.py:10)                      run_id（向后兼容保留）
```

`ChatGeneration.set_text`（chat_generation.py:44）每次构造把 `.text` 同步为 `message.text`，处理遗留内容块。`LLMResult.flatten`（llm_result.py:60）**只有第一个保留 token_usage**（:83-86，防 OpenAICallback 把一份用量计 N 次）。

#### 模块对外接口

`BaseChatModel`/`BaseLLM`（partner 包继承点）；`_generate`/`_stream`/`_agenerate`/`_astream` 钩子协议；`bind_tools`/`with_structured_output`（结构化输出标准路径）；`ChatResult`/`LLMResult`（回调与缓存载荷）；fake 测试替身。

### 4.4 messages/（含 block_translators/）—— 提供商中立消息层

**模块职责**：定义与提供商无关的统一消息格式，作为所有聊天模型 I/O 的中立中间层。上层只面对 `BaseMessage` 家族与标准 `ContentBlock` 列表，不必关心各家 wire format。`content.py` 定义 v1 标准内容块体系；`block_translators/` 实现双向翻译；`utils.py`（93KB）提供格式转换、历史管理（filter/merge/trim）、字符串化与近似 token 计数。核心取舍是"**永不丢数据**"——识别不了的块包成 `non_standard` 而不是丢弃。

#### 文件组成（messages/ 11 文件 + block_translators/ 9 文件）

| 文件 | 职责 | 关键导出 |
|---|---|---|
| `base.py`（519 行） | `BaseMessage`（content 多形态、`content_blocks` 解析管线、`text` 属性）、`BaseMessageChunk`、`merge_content` | `BaseMessage`、`BaseMessageChunk`、`merge_content`、`message_to_dict`、`get_msg_title_repr` |
| `ai.py`（854 行） | `AIMessage`（tool_calls/usage_metadata 及向后兼容解析）、`AIMessageChunk`（流式增量合并） | `AIMessage`、`AIMessageChunk`、`UsageMetadata`、`InputTokenDetails`、`OutputTokenDetails`、`add_ai_message_chunks`、`add_usage`、`subtract_usage` |
| `chat.py` | 任意角色 `ChatMessage`（role 字段）及 Chunk | `ChatMessage`、`ChatMessageChunk` |
| `content.py`（1489 行） | v1 标准内容块 TypedDict 体系 + 工厂函数 + 类型判别（纯数据契约层） | `ContentBlock` 联合、各块 TypedDict、`ToolCall`/`ToolCallChunk`/`InvalidToolCall`（块形态）、`KNOWN_BLOCK_TYPES`、`is_data_content_block`、`create_*` 工厂族 |
| `function.py` | 旧版 `FunctionMessage`（legacy function calling） | `FunctionMessage` |
| `human.py` / `system.py` / `modifier.py` | 用户/系统消息；`RemoveMessage`（LangGraph 删历史控制信号） | `HumanMessage`、`SystemMessage`、`RemoveMessage` |
| `tool.py`（419 行） | `ToolMessage`（tool_call_id/artifact/status）、ToolCall TypedDict 及工厂、默认解析器 | `ToolMessage`、`ToolCall`、`ToolCallChunk`、`tool_call`、`default_tool_parser`、`default_tool_chunk_parser` |
| `utils.py`（2443 行） | OpenAI 格式转换、coercion、过滤/合并/裁剪历史、字符串化、近似 token 计数 | `AnyMessage`、`convert_to_messages`、`convert_to_openai_messages`、`filter_messages`、`merge_message_runs`、`trim_messages`、`get_buffer_string`、`message_chunk_to_message`、`count_tokens_approximately` |
| `__init__.py` | 惰性导出（约 60 个符号） | — |
| `block_translators/__init__.py` | 翻译器注册中心：`PROVIDER_TRANSLATORS` 注册表 + register/get（导入时统一注册 7 家） | `PROVIDER_TRANSLATORS`、`register_translator`、`get_translator` |
| `block_translators/openai.py`（1089 行） | 最大翻译器：Chat Completions 与 Responses 两套 API；annotation/reasoning 展开 | `translate_content`、`translate_content_chunk`、`convert_to_openai_data_block` |
| `block_translators/anthropic.py`（534 行） | text/thinking/tool_use/server_tool_use/tool_result/document/image → v1 块；citation→Annotation | `translate_content`、`translate_content_chunk` |
| `block_translators/bedrock.py` | 检测 model_name 含 "claude" 才委托 Anthropic，否则 NotImplementedError 触发回退 | `translate_content` |
| `block_translators/bedrock_converse.py` | Converse API 的无 type 单键块判别 | `translate_content` |
| `block_translators/google_genai.py`（610 行） | function_call/file_data/thinking/executable_code、grounding→Citations | `translate_content`、`translate_grounding_metadata_to_citations` |
| `block_translators/google_vertexai.py` | 纯转发：genai 函数注册到 "google_vertexai" 键 | — |
| `block_translators/groq.py` | reasoning_content→reasoning 块、executed_tools、容错解析未转义 JSON | `translate_content` |
| `block_translators/langchain_v0.py` | v0 旧式多模态块（source_type 形态）→ v1 块，专供兜底管线 | `_convert_v0_multimodal_input_to_v1` |

#### 关键类/函数解析

**1. `BaseMessage`（base.py:93）—— 字段结构与 content 多形态**

Pydantic 模型，`extra="allow"`（:142，允许提供商塞额外字段）。核心字段：`content: str | list[str | dict]`（:103，**多形态核心**：纯文本用 str；多模态用块列表，元素可混存裸 str、v1 标准块、v0 旧块、提供商原生块）；`additional_kwargs`（:106）；`response_metadata`（:114，含 `model_provider`/`output_version` 驱动翻译器分发）；`type`（:117）；`name`/`id`（:125/135）。

**`content_blocks` property（:199-260）—— 最重要的归一化入口**，两遍实现：
1. 第一遍分拣（:223-248）：str 转单 text 块；dict 的 `type` 不在 `KNOWN_BLOCK_TYPES`（content.py:856）或含 `source_type`（v0 特征）→ 包成 `{"type":"non_standard","value":原始块}`；
2. 第二遍**多轮尽力解析**（:252-259）：依次过 5 个解析函数（v0 → openai_input → anthropic_input → genai_input → converse_input），失败保持 non_standard 原样。

**`text` property（:262-292）**：str 直返；list 只拼接 text 块，返回 `TextAccessor`（:47，str 子类，`__call__` 兼容旧 `.text()` 调用并发 deprecation 警告）。`__add__`（:294-307）返回 `ChatPromptTemplate`（`msg1 + msg2` 语法糖）。

**2. `AIMessage`（ai.py:160）与 `AIMessageChunk`（ai.py:418）**

- AIMessage 关键字段：`tool_calls: list[ToolCall]`（:170，字段形态，与 content.py:247 的块形态同名不同构，在 content_blocks 中互转）；`invalid_tool_calls`（:173，args 解析失败的调用多一个 error 字段——"模型也会犯错，别让坏 JSON 炸掉整个消息"）；`usage_metadata`（:176，跨提供商统一 token 计数）。
- `content_blocks`（:242-304）三级策略：`output_version=="v1"` 短路直返 → `get_translator(model_provider)` 精确分发（NotImplementedError 吞掉继续）→ `super().content_blocks` 兜底 + 从 tool_calls 补块 + 从 additional_kwargs 提取 reasoning 插块首。
- `_backwards_compat_tool_calls` 验证器（:307-351，mode="before"）：构造时无显式 tool_calls 但 `additional_kwargs["tool_calls"]` 有 OpenAI 原始数据，用 `default_tool_parser`（tool.py:349）解析回填——兼容旧序列化产物。
- **`AIMessageChunk.__add__` / `add_ai_message_chunks`（ai.py:640/651）—— 流式增量合并的真正实现**：content 走 `merge_content`；两个 kwargs dict 走 `merge_dicts`（深度合并）；tool_call_chunks 走 `merge_lists` 按 `index` 对齐、str 字段拼接（**流式 JSON args `{"a":` + `1}` 拼成完整 JSON 的机制**）；usage_metadata 逐对 `add_usage`（:734，递归整数加法）；**id 择优**（:696-717）：提供商原生 id > `lc_run-*` > 其他 `lc_*`。
- `init_tool_calls` 验证器（:508-601）：有 chunks 时对每个 `parse_partial_json(chunk["args"])`（容忍不完整 JSON）解析成功入 tool_calls 否则入 invalid_tool_calls——**聚合完成的 chunk 自动获得结构化 tool_calls 的机制**；`chunk_position=="last"` 且 v1 输出时**原地改写 content**（:573-599）把 tool_call_chunk 块替换为完整 tool_call 块。

**3. `merge_content`（base.py:366-406）**：四情形状态机——str+str 拼接；str+list 升格 `[累积, *list]`；list+list 走 `merge_lists`；list+str 追加到最后一个 str 元素尾部。**会原地修改传入的 list**（:398-405）。

**4. `messages/utils.py`（93KB）五大函数群**

- **coercion 群**：`_convert_to_message`（:719-796）把 BaseMessage/tuple/str/dict 归一（dict 的 Serializable 构造信封经硬编码白名单 `_LC_CONSTRUCTOR_NAME_TO_TYPE`（:704-716，安全考虑不做动态类加载））；`message_chunk_to_message`（:573-593）利用 chunk 类 MRO 第一父类即非 chunk 类的事实（`chunk.__class__.__mro__[1]`）重建。
- **OpenAI 转换群**：`convert_to_openai_messages`（:1562-1980，overload :1543/1553）把任意格式消息转 OpenAI Chat Completions dict。逐块大分派（:1698-1967）按序匹配：OpenAI 原生块直通 → 标准数据块 `convert_to_openai_data_block` → Anthropic `image`+source → Bedrock bytes base64 → `tool_use`→tool_calls → `tool_result`→递归造 ToolMessage **插到当前消息之后**（一条变多条，:1973-1976）→ 未知块按 `pass_through_unknown_blocks` 直通或抛错。
- **历史管理群**（均经 `@_runnable_support` 装饰，不传 messages 时返回 RunnableLambda 可接入 LCEL）：`filter_messages`（:870-1011，include_*/exclude_*/exclude_tool_calls）；`merge_message_runs`（:1015-1140，相邻同类型合并——两侧 `_msg_to_chunk`、右侧清空 response_metadata、chunk 相加后还原；ToolMessage 因 tool_call_id 唯一永不合并）；`trim_messages`（:1146-1533，按 token 预算裁剪——`_first_max_tokens`（:1983-2096）**二分搜索**（`bit_length()` 次迭代）找最大可容纳消息数，allow_partial 时对文本用 text_splitter 二分找最大前缀；`strategy="last"` 反转后复用 first）。
- **字符串化群**：`get_buffer_string`（:297-525，`"Human: ...\nAI: ..."` 或 XML 模式，多模态块截断到 500 字符）。
- **token 计数群**：`count_tokens_approximately`（:2257-2431，默认 4 字符/token + 每消息 3 token + 每图 85 token；`use_usage_metadata_scaling=True` 用最近 AI 消息真实用量校准，缩放系数夹 [1.0, 1.25]）。

**5. `block_translators` 架构——函数对 + 注册表 + NotImplementedError 回退**

本版本**没有** ProviderSpecificBlockTranslator 抽象基类；每个提供商模块导出 `translate_content(message)`/`translate_content_chunk(chunk)` 函数对并在模块底部执行注册（如 openai.py:1089）。分发两级：

```
AIMessage.content_blocks（ai.py:242）
  ├─ output_version=="v1" 且 content 是 list → 直接返回（短路）
  ├─ model_provider = response_metadata["model_provider"]
  │    └─ get_translator(provider) → translator["translate_content"](self)
  │         └─ 抛 NotImplementedError → 吞掉继续 ↓（bedrock.py:76-77 的回退信号）
  └─ super().content_blocks（base.py:199）→ 5 轮尽力解析管线
       + 从 tool_calls 字段补块 + 从 additional_kwargs 提取 reasoning
```

**写入方向**（标准块→提供商格式）不走注册表：`convert_to_openai_messages`（utils.py:1562）+ `convert_to_openai_data_block`（openai.py:58）直接硬编码。各翻译器关键差异：openai.py 的 `_convert_to_v1_from_responses`（:656-1044）是巨型生成器（`_explode_reasoning` :614-653 把多段 summary 炸成多块、web_search 等产出 server_tool_call + server_tool_result **成对块**）；anthropic.py 的 citation 四种文档定位；bedrock_converse.py 用 `len(block)==1` 判别无 type 单键块；google_genai.py 的 grounding 笛卡尔展开成 Citation 只挂到第一个 text 块；groq.py 的 `_parse_code_json`（:30-48）正则处理未转义引号的 Python 代码 JSON。

#### 模块对外接口

`BaseMessage` 家族（全生态消息货币）；`ContentBlock` v1 体系与 `create_*` 工厂；`convert_to_messages`/`convert_to_openai_messages`（格式互转）；`filter_messages`/`merge_message_runs`/`trim_messages`（历史管理三件套，可作 LCEL 组件）；`register_translator`（partner 扩展点）。

---

### 4.5 prompts/ + output_parsers/ + prompt_values.py（调用链的入口与出口）

> 本批（批次 4）上半部分。prompts 把用户变量（dict）模板化为 `PromptValue`，output_parsers 把模型输出解析为结构化数据；两侧都直接继承 `RunnableSerializable`，本身就是可组合的 Runnable。

#### 文件组成（prompts/ 12 文件、output_parsers/ 11 文件、prompt_values.py）

| 文件 | 职责 | 关键导出 |
|---|---|---|
| `prompts/base.py` | 所有提示词模板的抽象基类：invoke/ainvoke、输入校验、partial 变量合并 | `BasePromptTemplate`、`format_document`/`aformat_document` |
| `prompts/string.py` | 三种 `template_format` 的 formatter/validator 映射、模板变量提取、抽象 `StringPromptTemplate` | `StringPromptTemplate`、`DEFAULT_FORMATTER_MAPPING`、`get_template_variables`、`check_valid_template`、`jinja2_formatter`、`mustache_schema` |
| `prompts/prompt.py` | 具体 `PromptTemplate`：format 变量替换、from_template/from_file/from_examples | `PromptTemplate` |
| `prompts/chat.py`（50.6KB） | 聊天提示词体系：`MessagesPlaceholder`、按角色消息模板、`ChatPromptTemplate` | `ChatPromptTemplate`、`BaseChatPromptTemplate`、`MessagesPlaceholder`、`HumanMessagePromptTemplate` 等 |
| `prompts/dict.py` | dict 模板（多模态 content block），递归替换 f-string/mustache 变量 | `DictPromptTemplate` |
| `prompts/few_shot.py` | 少样本提示词（examples 与 example_selector 二选一） | `FewShotPromptTemplate`、`FewShotChatMessagePromptTemplate` |
| `prompts/few_shot_with_templates.py` | prefix/suffix 是 StringPromptTemplate 对象的变体 | `FewShotPromptWithTemplates` |
| `prompts/image.py` | 图像模板（产出 ImageURL dict） | `ImagePromptTemplate` |
| `prompts/loading.py` | （已弃用）从 JSON/YAML/Hub 加载提示词，含防路径穿越 | `load_prompt` |
| `prompts/message.py` | 消息模板抽象 `BaseMessagePromptTemplate` | 同名 |
| `prompts/structured.py` | （beta）携带 schema 的 ChatPromptTemplate，pipe 到模型时自动调 with_structured_output | `StructuredPrompt` |
| `output_parsers/base.py` | 三层基类：`BaseLLMOutputParser`→`BaseOutputParser`（Runnable 身份） | `BaseOutputParser`、`BaseGenerationOutputParser` |
| `output_parsers/transform.py` | 流式支持：逐 chunk / 累积 chunk 增量解析（diff） | `BaseTransformOutputParser`、`BaseCumulativeTransformOutputParser` |
| `output_parsers/json.py` | 文本→Python 对象，markdown 剥离 + 部分 JSON 容错 | `JsonOutputParser` |
| `output_parsers/pydantic.py` | JSON 解析之上叠加 Pydantic 校验（v1/v2 双兼容） | `PydanticOutputParser` |
| `output_parsers/openai_tools.py` | 解析 AIMessage.tool_calls | `JsonOutputToolsParser`、`JsonOutputKeyToolsParser`、`PydanticToolsParser`、`parse_tool_call(s)` |
| `output_parsers/openai_functions.py` | 解析旧版 function_call（4 层级） | `OutputFunctionsParser` 等 5 个 |
| `output_parsers/list.py` | 逗号分隔/编号/Markdown 三种列表解析 | `CommaSeparatedListOutputParser` 等 |
| `output_parsers/string.py` | 最常用：消息/文本原样转 str（恒等） | `StrOutputParser` |
| `output_parsers/xml.py` | XML→嵌套 dict（AddableDict），XMLPullParser 增量解析 | `XMLOutputParser` |
| `output_parsers/format_instructions.py` | JSON 格式指令模板常量 | `JSON_FORMAT_INSTRUCTIONS` |
| `prompt_values.py` | `PromptValue` 抽象及 String/Chat/Image 三实现 | `PromptValue`、`StringPromptValue`、`ChatPromptValue`、`ImagePromptValue` |

#### 关键类/函数解析

**1. 模板变量替换（三种 template_format）——`PromptTemplate.format`（prompt.py:191-201）**

```python
def format(self, **kwargs: Any) -> str:
    kwargs = self._merge_partial_and_user_variables(**kwargs)
    return DEFAULT_FORMATTER_MAPPING[self.template_format](self.template, **kwargs)
```

两步：合并变量（`_merge_partial_and_user_variables`，base.py:307-314——可调用 partial 惰性求值，用户传入覆盖）→ 按 `template_format` 查 `DEFAULT_FORMATTER_MAPPING`（string.py:210-214）分发：

- **f-string（默认）**：`StrictFormatter`（utils/formatting.py:80）重写 `vformat` **拒绝位置参数**（:23-48，`{}`/`{0}` 直接 ValueError）；变量提取 `validate_f_string_template`（string.py:230-259）拒绝属性访问/索引/纯数字名/嵌套替换字段。
- **mustache**：`mustache.render`（`{{var}}` 语法）；变量提取 `mustache_template_vars`（:125-152）用 `section_depth` 计数只收**顶层**变量；`get_input_schema` 在 mustache 模式调用 `mustache_schema`（:158-194）把 section 结构递归编译成嵌套 Pydantic 模型。
- **jinja2**：`SandboxedEnvironment().from_string(t).render(**kwargs)`（:72）——**best-effort 沙箱**，普通属性访问与方法调用仍可用，不可信模板可致任意代码执行（docstring 明确警告，:33-72）。

统一入口 `get_template_variables`（:298-325）在 `PromptTemplate.pre_init_validation`（prompt.py:89-125）里用提取结果**无条件覆盖**用户传入的 input_variables（"变量表永远以模板推导为准"，:116-123）。

**2. `ChatPromptTemplate.from_messages`（chat.py:1123-1172）与 invoke 链**

`from_messages` 仅一行 `return cls(messages, template_format=...)`（:1172）；真正工作在 `__init__`（:907-1000）三步：

1. **元组→模板对象推导**（:976-979）：`_convert_to_message_template`（:1418-1491）分发——裸 str 视为 `("human", message)`；二元组 `(role, template)` 进 `_create_template_from_message_type`（:1341-1415）：`human/user`→HumanMessagePromptTemplate 等；`("placeholder", "{conversation}")` 剥花括号得变量名并强制 `optional=True`（:1380）；role 也可以是消息类或任意可调用类。
2. **输入变量自动推导**（:981-998）：optional placeholder 的变量移入 `optional_variables` 并预填 `partial_variables[var]=[]`；其余模板的 input_variables 求并集排序。`model_validator(mode="before") validate_input_variables`（:1051-1103）在直接以字段构造时再执行一遍。
3. 父类 `validate_variable_names`（base.py:80-106）兜底：禁变量名 `stop`、禁 input 与 partial 重叠。

**invoke 生成 ChatPromptValue 的完整链**：`BasePromptTemplate.invoke`（base.py:209-236）→ `_call_with_config(self._format_prompt_with_error_handling, ...)`（run_type="prompt"）→ `_validate_input`（:161-195，非 dict 输入且仅一个变量时自动包装 `{var: input}`；缺变量抛 KeyError 并提示 `{{}}` 转义）→ `format_prompt` → `BaseChatPromptTemplate.format_prompt`（chat.py:727-736）`messages = self.format_messages(**kwargs); return ChatPromptValue(messages=messages)`。`format_messages`（:1174-1200）线性扫描：BaseMessage 原样 extend；模板对象调其 format_messages。叶子 `_StringImageMessagePromptTemplate.format`（:588-617）组装多模态 content blocks。

**3. `MessagesPlaceholder.format_messages`（chat.py:164-190）**

四步：取值（optional 缺省 `[]`，非 optional 缺失 KeyError）→ 类型校验（必须 list）→ **宽容转换** `convert_to_messages(value)`（:187，接受 BaseMessage/元组/dict 多形态——history 传元组列表能工作的原因）→ 尾部截断 `value[-self.n_messages:]`（:188-189，1.6 新增保留最近 N 条）。

**4. `BaseOutputParser` 的模板方法结构（output_parsers/base.py）**

四层自顶向下：`invoke`（:203-224，按输入类型二分包装成 `[Generation]`/`[ChatGeneration]`，交 `_call_with_config(..., run_type="parser")`）→ `parse_result`（:249-268，默认 `return self.parse(result[0].text)`——只取第一个 Generation）→ `parse`（:270-279，**抽象方法，子类唯一必选实现点**）→ `parse_with_prompt`（:314-332，prompt 参数显式忽略，给 RetryOutputParser 类子类的旁路钩子）。`BaseOutputParser` 混入 `RunnableSerializable` 因此解析器本身是 Runnable。流式场景由 `BaseTransformOutputParser.transform`（transform.py:55-74）接管；累积式 `BaseCumulativeTransformOutputParser._transform`（:125-148）把 chunk 用 `+` 累积后 `parse_result(partial=True)` 增量解析，diff 模式 yield `jsonpatch` 语义的增量。

**5. 三个代表解析器的实现**

- **`JsonOutputParser.parse_result`（json.py:60-91）**：`parse_json_markdown(text)`（utils/json.py:142，默认 `parse_partial_json`）——先正常 `json.loads`；失败则**逐字符扫描维护括号栈与字符串内/转义状态**（utils/json.py:81-109），给字符串内裸换行补 `\n`、闭合未闭合引号，再从尾部逐步补 `}`/`]` 反复尝试——因此能吃下半截 JSON、markdown 围栏、前后噪声。partial=True 捕获 JSONDecodeError 返回 None（流式中间态不炸）。
- **`PydanticOutputParser._parse_obj`（pydantic.py:25-37）**：按模型版本分发 `model_validate`/`parse_obj`；ValidationError 转成带上下文的 `OutputParserException`（`llm_output=json_string` 供上层重试）。
- **`JsonOutputToolsParser.parse_result`（openai_tools.py:165-210）**：**只接受 ChatGeneration**（数据源在消息上）；双通道取数——首选 `message.tool_calls`，兼容通道 `deepcopy(additional_kwargs["tool_calls"])`（deepcopy 防污染原消息）交模块级 `parse_tool_calls`（:101-136，partial 用 parse_partial_json，失败抛 OutputParserException）。输出键 `type` 由 `name` 改名（:205-206，历史 API 遗留）。

**6. 值得注意的细节**：few_shot 的**双重格式化**——`FewShotPromptTemplate.format`（few_shot.py:180-206）先渲染每个 example，拼接后对整体再执行一次 f-string 格式化——若 example 内容本身含 `{...}` 会被最后一次格式化误伤；`FewShotPromptWithTemplates.template_is_valid`（few_shot_with_templates.py:97-101）存在**运算符优先级疑似缺陷**（`set(suffix) | set(prefix) - set(partials)` 实际是 `suffix | (prefix - partials)`）。

#### 模块对外接口

`PromptTemplate.from_template`/`ChatPromptTemplate.from_messages`（用户最常用入口）；`MessagesPlaceholder`；`get_template_variables`；`StrOutputParser`/`JsonOutputParser`/`PydanticOutputParser` 等解析器；`PromptValue.to_string()/to_messages()`（prompt 与 model 间的中立契约）。

### 4.6 tools/ + agents.py + documents/ + document_loaders/ + indexing/ + example_selectors/（Agent 执行面 + RAG 数据面）

#### 文件组成（tools/ 7 文件 + 5 个模块组）

| 文件 | 职责 | 关键导出 |
|---|---|---|
| `tools/base.py`（1949 行） | 工具体系根基：`BaseTool`（Runnable 继承、输入校验、错误处理、回调）、`create_schema_from_function`、注入参数注解体系 | `BaseTool`、`ToolException`(:371)、`ArgsSchema`、`create_schema_from_function`(:263)、`InjectedToolArg`(:1726)、`InjectedToolCallId`(:1756)、`BaseToolkit`(:1935) |
| `tools/convert.py` | `@tool` 装饰器（4 重载）与 Runnable→Tool 转换 | `tool`(:77)、`convert_runnable_to_tool`(:433) |
| `tools/render.py` | 工具列表渲染为纯文本（ReAct prompt 用） | `render_text_description`、`render_text_description_and_args` |
| `tools/retriever.py` | 把 BaseRetriever 包装成检索工具 | `create_retriever_tool`(:31) |
| `tools/simple.py` | 单输入字符串工具（遗留） | `Tool`(:31) |
| `tools/structured.py` | 多输入结构化工具：func/coroutine 双通道 | `StructuredTool`(:93)、`StructuredTool.from_function`(:187) |
| `agents.py` | 遗留 Agent 循环数据 schema（AgentAction/AgentFinish，仅为向后兼容） | `AgentAction`(:44)、`AgentActionMessageLog`(:107)、`AgentStep`(:133)、`AgentFinish`(:148) |
| `documents/base.py` | 检索数据单元：BaseMedia/Blob/Document | `BaseMedia`(:34)、`Blob`(:59)、`Document`(:288) |
| `documents/compressor.py` `transformers.py` | 检索后处理（查询感知）/文档变换（查询无关）抽象 | `BaseDocumentCompressor`(:19)、`BaseDocumentTransformer`(:16) |
| `document_loaders/base.py` | 加载器接口：**惰性优先**（子类实现 lazy_load） | `BaseLoader`(:26)、`lazy_load`(:91)、`BaseBlobParser`(:117) |
| `document_loaders/blob_loaders.py` | Blob 流加载抽象 | `BlobLoader`(:19) |
| `document_loaders/langsmith.py` | LangSmith Dataset 示例→Document | `LangSmithLoader`(:17) |
| `indexing/api.py`（955 行） | 索引编排：批量分片→哈希定 ID→去重→查账本→写库→回写→清理 | `index`(:296)、`aindex`(:635)、`IndexingResult`(:283) |
| `indexing/base.py`（662 行） | `RecordManager` 抽象（时间戳账本）+ InMemoryRecordManager + `DocumentIndex` | `RecordManager`(:22)、`InMemoryRecordManager`(:240)、`DocumentIndex`(:497) |
| `indexing/in_memory.py` | 字典型 DocumentIndex 参考实现 | `InMemoryDocumentIndex`(:19) |
| `example_selectors/base.py` 等 3 文件 | 示例选择器接口 + 长度/向量相似度实现 | `LengthBasedExampleSelector`、`SemanticSimilarityExampleSelector`、`MaxMarginalRelevanceExampleSelector` |

#### 关键类/函数解析

**1. `BaseTool`（tools/base.py:433）**

`class BaseTool(RunnableSerializable[str | dict | ToolCall, Any])`——工具天然可进 LCEL 链、可被 tracing dump。关键字段：`name`/`description`（下发给 LLM 的工具卡）、`args_schema`（:483，pydantic 模型类**或**原始 JSON Schema dict，`SkipValidation` + 手工校验）、`handle_tool_error`（:527，bool/str/callable 三态）、`handle_validation_error`（:542）、`response_format`（:547，"content_and_artifact" 要求 `_run` 返回二元组）、`extras`（:555，供应商私有字段透传）。

**执行管线 `run()`（:1009-1135）七步**：
1. `CallbackManager.configure` 合并调用点与实例级回调；
2. `_filter_injected_args`（:934-968）把注入型参数（run_manager/callbacks + `InjectedToolArg`/`ToolRuntime` 注解 + args_schema 注入字段）从回调 inputs 剔除，避免泄给 tracer；
3. `on_tool_start`；
4. **解析与校验** `_parse_input`（:778）：字符串+pydantic schema → 取第一个字段名单字段校验（单输入工具收字符串的兼容路径）；dict+pydantic → `model_validate` 后精心重构 `validated_input`（:866-887，只保留显式给出/alias 提供/带默认值的字段）并回填注入参数；
5. `set_config_context(child_config)` 中 `context.run(self._run, ...)`（:1090-1098）——保证 executor 线程内 tracing 链不断；子类签名有 run_manager/RunnableConfig 参数自动注入；
6. **三元错误处理**（:1115-1128）：`ValidationError` → handle_validation_error；`ToolException`（:371，工具主动声明的业务错误）→ `_handle_tool_error`（:1313）可吞噬为观察值回传 Agent；普通 Exception → on_tool_error 后重抛；
7. `_format_output`（:1390）：带 tool_call_id 时把 content 规范化后包成 `ToolMessage(status=...)` 返回。

**性能设计——`tool_call_schema` 记忆化**（:676-722）：给 LLM 的 schema 要剔除注入参数需动态建类，结果缓存在 `_tool_call_schema_memo`（:624），缓存失效点三处联动（`__setattr__` :638 / `model_copy` :645 / `__getstate__` :660）。

**2. `@tool` 装饰器与 schema 推导（convert.py:77-404 + base.py:263-368 + structured.py:187-307）**

`tool(...)` 是巨型闭包，4 个 overload 覆盖裸装饰器/带名装饰器/带参工厂/函数式。`_tool_factory`（:282）三路分流：Runnable 入参（校验输入 schema 是 object 型，生成薄适配 wrapper）→ 协程函数（coroutine=）→ 普通函数（func=）；`infer_schema=True` 走 `StructuredTool.from_function`，False 降级单输入 `Tool`。

**schema 从签名+docstring 推导——`create_schema_from_function`（base.py:263-368）**：① `inspect.signature` + v1/v2 注解混用检测（:221-249）；② 借 pydantic 的 `validate_arguments` 拿其内部构建的模型类 `validated.model`（:318——"用 pydantic 自己的类型解析器生成字段"的取巧实现）；③ 过滤字段（:320-341）：剔除 `FILTERED_ARGS`（run_manager/callbacks）、方法的 self/cls、InjectedToolArg 注解参数；④ 描述推导（:343-347）：`_parse_google_docstring`（:126，Google 风格 docstring 解析，**以首个参数行缩进为基准**处理续行）抽函数/参数描述，未覆盖参数再从 `Annotated[T, "描述"]` 补齐；⑤ `_create_subset_model`（:362，utils/pydantic.py:284）重建只含有效字段的模型类。

`StructuredTool.from_function`（structured.py:187-307）：描述优先级链 显式参数 > 函数 docstring（dedent+strip）> args_schema 的 description > 全空 ValueError。

**3. `index()` 增量索引流程（indexing/api.py:296-603）**

前置校验（:408-458）：sha1 触发进程级弃用告警；cleanup 值合法性；incremental/scoped_full 必须给 `source_id_key`；目标是 VectorStore 时须实现 delete/add_documents。每批循环（`_batch` :91 用 `itertools.islice` 切片）七步：

1. **批内去重**（:474-483）：`_get_document_with_hash`（:175）——预置算法对 `page_content` 与 `json.dumps(metadata, sort_keys=True)` 各做一次哈希再拼合（:213-223）；`_deduplicate_in_order`（:139）按 doc.id 保序去重；
2. **source_id 赋值**（:485-504）；
3. **账本查询** `record_manager.exists(ids)`（:506-508）；
4. **分拣**（:511-529）：不存在→索引；已存在且 force_update→重写；已存在→`uids_to_refresh` 仅刷时间戳（`update(uids, time_at_least=index_start_dt)`）**避免重复向量化**；
5. **先写向量库**（:533-548，注释 :531 点明"悲观假设向量库写可能失败"——**先写数据侧、后写账本侧**：账本没有而库有最多重复写，反过来会误删）；
6. **回写账本**（:553-557）对本批全部哈希文档 update；
7. **incremental 清理**（:560-581）：`while uids_to_delete := record_manager.list_keys(group_ids=..., before=index_start_dt, limit=...)` 分页捞出同 source 下本轮没刷新的旧哈希（内容已变的旧版本），从向量库删再删账本——**每批即时清理**。

`RecordManager` 契约（indexing/base.py:22-232）：`create_schema/get_time/update/exists/list_keys/delete_keys`（各配 async 版）；核心约束写在 docstring（:45-54）：时间戳必须单调；账本与向量库是两个分布式组件，存在一致性缝隙；`update` 的 `time_at_least`（:111-123）对抗时钟漂移。

**4. `SemanticSimilarityExampleSelector`（example_selectors/semantic_similarity.py:101）**：抽象中转层 `_VectorStoreExampleSelector`（:31）持有注入的 VectorStore——**全部向量数学委托给向量库，core 自身零 numpy 依赖**（历史版本的 numpy 实现位于 community 包）。`_example_to_text`（:56-59）按 key 排序取值拼接（排序保证同内容不同插入序产生同向量）；`add_example`（:70-83）以文本为正文、**原始 dict 整体作 metadata** 写入；`select_examples`（:104-120）= `vectorstore.similarity_search(text, k=self.k)`。MMR 变体（:231）改调 `max_marginal_relevance_search`。对照 `LengthBasedExampleSelector.select_examples`（length_based.py:96-117）：O(n) 贪心装填，长度函数可插拔，构造时预计算长度缓存。

**5. 其余要点**：`Tool`（simple.py:31）覆写 `args` 属性硬编码单 string 字段；`_to_args_and_kwargs`（:72-97）展平成恰好一个位置参数否则 ToolException；`create_retriever_tool`（retriever.py:31-94）闭包内 `retriever.invoke(query, config={"callbacks": callbacks})`，`response_format="content_and_artifact"` 时返回 `(拼接文本, docs)` 二元组；`Document.__str__`（documents/base.py:331-347）刻意只输出 page_content 与 metadata（不破坏"Document 直插 prompt"的旧代码）；`Blob.from_path`（:213）是**惰性引用**不读文件；`BaseLoader.lazy_load`（document_loaders/base.py:91-100）在子类只覆写 load 时回退 `iter(self.load())`；`LangSmithLoader`（langsmith.py:17-136）content_key 支持 `.` 分层路径。

#### 模块对外接口

`BaseTool`/`@tool`/`StructuredTool.from_function`（工具创建三入口）；`index()/aindex`（增量索引 API）；`RecordManager`/`DocumentIndex`（索引底座契约）；`Document`/`Blob`/`BaseLoader`（数据面原语）；`BaseExampleSelector` 家族。

---

### 4.7 callbacks/ + tracers/（可观测性横切层）

> 本批（批次 5）第一部分。回调体系贯穿所有 Runnable/ChatModel 调用：执行器在生命周期边界（start/token/end/error）调用 `CallbackManager` 的 `on_*` 方法，由管理器把事件按观察者模式扇出到 handler。tracer 是特殊 handler，把事件组装成 `Run`（RunTree）树，实现 LangSmith 上报、流式事件嗅探、内存收集与评估。

#### 文件组成（callbacks/ 7 文件 + tracers/ 15 文件）

| 文件 | 职责 | 关键导出 |
|---|---|---|
| `callbacks/base.py` | handler 全部虚方法接口（按 6 个 Mixin 分域）与同步/异步基类；`BaseCallbackManager` | `BaseCallbackHandler`(:496)、`AsyncCallbackHandler`(:548)、`BaseCallbackManager`(:1004)、`Callbacks` 类型别名(:1229) |
| `callbacks/manager.py`（89KB） | **核心分发层**：事件分发函数、RunManager 族、CallbackManager 双子、`configure()` 工厂、自定义事件分发、chain-group 上下文管理器 | `handle_event`(:285)、`ahandle_event`(:453)、`CallbackManager`(:1377)、`AsyncCallbackManager`(:1859)、`CallbackManagerForLLMRun`(:705)、`CallbackManagerForChainRun`(:928)、`trace_as_chain_group`(:55)、`dispatch_custom_event`(:2739)、`shielded`(:221) |
| `callbacks/file.py` `stdout.py` `streaming_stdout.py` | 文件/stdout/流式 stdout handler | `FileCallbackHandler`、`StdOutCallbackHandler`、`StreamingStdOutCallbackHandler` |
| `callbacks/usage.py` | token 用量统计（从 usage_metadata 聚合各模型调用次数） | `UsageMetadataCallbackHandler`(:18)、`get_usage_metadata_callback`(:80) |
| `tracers/base.py` | `BaseTracer`/`AsyncBaseTracer`：回调 API→Run 树生命周期翻译 | `BaseTracer`(:33)、`AsyncBaseTracer`(:551) |
| `tracers/core.py` | `_TracerCore`：run 树构建引擎（run_map/order_map/dotted_order） | `_TracerCore`(:66)、`_start_trace`(:150)、`_create_llm_run`(:240)、`_complete_llm_run`(:320) |
| `tracers/context.py` | ContextVar 驱动的全局追踪开关与注入 | `tracing_v2_enabled`(:39)、`collect_runs`(:85)、`register_configure_hook`(:171) |
| `tracers/schemas.py` | Run schema：直接别名 langsmith 的 RunTree | `Run`(:10) |
| `tracers/langchain.py` | 对接 LangSmith：POST/PATCH 单个 run | `LangChainTracer`(:134)、`wait_for_all_tracers`(:69)、`get_client`(:75) |
| `tracers/event_stream.py`（35KB） | astream_events v2 引擎：事件嗅探器 | `_AstreamEventsCallbackHandler`(:101)、`_astream_events_implementation_v2`(:1004) |
| `tracers/log_stream.py` | astream_log 引擎：JSONPatch 增量与全量状态 | `LogStreamCallbackHandler`(:232)、`RunLog`(:168)、`RunLogPatch`(:115) |
| `tracers/memory_stream.py` | 跨事件循环/跨线程内存通道 | `_MemoryStream`(:158)、`_SendStream`(:71)、`_ReceiveStream`(:138) |
| `tracers/root_listeners.py` | 只在根 run 触发用户监听器（with_listeners 底座） | `RootListenersTracer`(:23)、`AsyncRootListenersTracer`(:78) |
| `tracers/run_collector.py` `stdout.py` `evaluation.py` | run 树收集/控制台输出/评估回调 | `RunCollectorCallbackHandler`、`ConsoleCallbackHandler`、`EvaluatorCallbackHandler`(:38) |
| `tracers/_compat.py` `_streaming.py` | Pydantic v1/v2 Run 兼容层；流式 handler 协议 | `run_to_dict`、`_StreamingCallbackHandler`(:11)、`_V2StreamingCallbackHandler`(:32) |

#### 关键类/函数解析

**1. 事件分发核心 `handle_event`（manager.py:285-367）与异步双胞胎（:404-487）**

同步分发器是所有 `on_*` 回调的最终汇聚点（调用方传**事件名字符串**而非方法引用）：
1. 遍历 handlers，先查 ignore 条件（如 `ignore_llm`，:309-311）——**订阅过滤**机制；
2. `getattr(handler, event_name)(*args, **kwargs)` 反射调用（:312）；返回 coroutine 时收集进 `coros`；对 `on_chat_model_start` 特判回退包装（:256-283）；
3. **异常隔离**（:319-348）三层：`NotImplementedError`（仅 on_chat_model_start 有意义——messages 转 prompt 后**递归调用自身**分发 `on_llm_start`，新旧 handler 兼容桥）；一般 Exception 仅 warning，除非 `handler.raise_error`——**默认回调错误绝不污染业务调用**；coroutine 的执行（:349-367）：当前线程有运行中事件循环时（从协程里同步调用），把 coros 提交到全局共享 `ThreadPoolExecutor`（`_executor()` :2813-2826，lru_cache 单例、10 worker）在工作线程的新 loop 里执行（直接提交会死锁）。

异步版 `ahandle_event`（:453-487）：先**顺序 await** 所有 `run_inline=True` 的 handler（保序），再 `asyncio.gather` **并发**非内联 handler；同步函数默认丢 `run_in_executor`（`copy_context().run` 保留 contextvars，:419-422）。

**`shielded` 装饰器**（:221-253）：把异步方法包成 `asyncio.create_task + asyncio.shield`——用于 `on_llm_end/on_llm_error`，**取消消费流时仍能完整发出 end/error 回调**（tracer 才能闭环 run）。

**2. CallbackManager 工厂体系：`on_*_start` 即工厂 + `configure()` 装配线**

- `CallbackManager.on_chat_model_start`（:1431-1483）：逐 batch 维度分配 run_id（显式 run_id 只给第一个，其余 `uuid7()` 时间有序 UUID）→ handle_event 广播 → **构造并返回 `CallbackManagerForLLMRun`**（:1470-1481，捕获 handlers 与 inheritable_handlers）——工厂方法模式。`on_chain_start → CallbackManagerForChainRun`（:1485）、`on_tool_start → CallbackManagerForToolRun`（:1530）等同构。
- **父子链构建**：`ParentRunManager.get_child()`（:602-618）创建 parent_run_id=self.run_id 的新管理器，只继承 `inheritable_*`——tags/metadata/handler 沿 run 树**选择性遗传**（local handler 不遗传）。
- **`_configure`（:2390-2611，由 configure 类方法包装 :1682/:2211）——每次调用初始化回调上下文的总装配线**：① 从 langsmith `get_tracing_context()` 取外部追踪上下文（`@traceable` 嵌套场景）作 parent_run_id；② 合并 inheritable/local callbacks/tags/metadata；③ **环境驱动注入**（:2492-2550）：`verbose` → StdOutCallbackHandler；`get_debug()` → ConsoleCallbackHandler；`_tracing_v2_is_enabled()`（环境变量 `LANGCHAIN_TRACING_V2`/`LANGSMITH_TRACING` 或 ContextVar）→ LangChainTracer（绑定 project/client）；④ 外部 RunTree 预填 order_map 使子 run 挂到 langsmith 父 run 下（:2551-2563）；⑤ 遍历 `register_configure_hook` 注册的第三方扩展点（:2564-2584）。

**3. 事件序列（chat model）**：start（`on_chat_model_start` 返回 run_manager）→ token（流式，`on_llm_new_token(token, chunk=chunk)`，:708-735，token 可为 str 或内容块列表）→ end/error（`on_llm_end(LLMResult)`；异步版 @shielded）。v2 事件粒度新回调 `on_stream_event(MessagesData)`（:785-803）与 v1 共存。

**4. `BaseTracer` 三段式与 run 树构建（tracers/base.py + core.py）**

每个 `on_*_start` 方法固定三段式（以 on_chain_start base.py:261-303 为例）：`_create_chain_run(...)`（纯构造）→ `_start_trace(run)`（挂树）→ `_on_chain_start(run)`（子类钩子如上报）。

**`_TracerCore._start_trace`（core.py:150-175）—— 树的组装算法**：
1. `dotted_order = start_time.strftime("%Y%m%dT%H%M%S%fZ") + str(run.id)`（时间序+id 的排序键）；
2. 有 parent_run_id 且在 order_map 命中：继承 trace_id、`dotted_order = 父.dotted_order + "." + 当前`，append 进父的 child_runs；
3. 父未命中：**降级为根 run**（debug 日志）——保证部分丢失父事件的 trace 仍可用；
4. 登记 `order_map[run.id]` 与 `run_map[str(run.id)]`。

`_end_trace`（base.py:45-59）：**只有根 run 结束才 `_persist_run(run)` 持久化整棵树**（抽象方法，各子类定义语义）；`__deepcopy__/__copy__` 返回 self（:542-548）——tracer 必须是共享单例语义，防止配置拷贝时分裂 run_map。

**5. `_AstreamEventsCallbackHandler`（event_stream.py:101）—— astream_events v2 嗅探器**

设计模式：**纯嗅探观察者 + 有界内存通道**：
- 通道（:142-144）：`_MemoryStream[StreamEvent](_get_or_create_loop(self))` 拆 send/receive——本质是绑定读者事件循环的 asyncio.Queue；写侧 `send_nowait` 用 `reader_loop.call_soon_threadsafe` **跨线程/跨循环投递**（即使回调跑在后台线程的 loop，事件也能安全回到消费者 loop）。
- start 事件（:548-594）：`run_map[run_id] = RunInfo` 且 `parent_map[run_id] = parent_run_id`（parent_map 独立存在因为父 end 可能先到）；`_get_parent_ids`（:146-163）沿 parent_map 回溯构建 parent_ids 列表；经 `_RootEventFilter.include_event` 过滤后 send。
- **stream 事件两条互斥路径**（`is_tapped` 集合保证一个 run 只 tap 一次，:130）：模型侧 `on_llm_new_token`（:425-485）发 on_chat_model_stream；Runnable 输出侧 `tap_output_aiter`（:178-231）包装任意 AsyncIterator 透传同时发事件——覆盖不走 on_llm_new_token 的中间流场景。
- 驱动器 `_astream_events_implementation_v2`（:1004-1101）：handler 注入 config["callbacks"] → `asyncio.create_task(consume_astream())` 后台消费根输出 → 主协程 `async for event in event_streamer` 逐个 yield；finally 取消后台 task。

**6. `LangChainTracer`（langchain.py:134）**：`run_inline = True`（:137，异步分发中内联执行保序）。**POST-then-PATCH 两阶段上报**：每个 run 开始时 `_persist_run_single`（:328-342，设置 runtime 元数据、first-wins 合并 metadata、`run.post()`）；结束时 `_update_run_single`（:344-354）→ `run.patch()`。`_on_llm_end`（:395-406）从 outputs 提取聚合 usage_metadata 塞进 `run.extra`——LangSmith token 统计来源。`_persist_run`（:281-289）不做网络 IO，只重建轻量副本存 `latest_run`（释放整棵子树引用的内存优化）。`get_run_url()`（:291-320）用 tenacity 重试拿 UI 链接。

**7. 其余速览**：`LogStreamCallbackHandler`（log_stream.py:232）以 JSONPatch op 流出增量（`RunLogPatch.__add__` :136-154 实现"补丁叠加"代数）；`UsageMetadataCallbackHandler`（usage.py:18-77）threading.Lock 下按 model_name 累加 usage；`get_usage_metadata_callback`（:80-124）经 `register_configure_hook` 注入；`RootListenersTracer`（root_listeners.py:23）只在根 run 调 on_start/on_end/on_error——`Runnable.with_listeners` 底座；`EvaluatorCallbackHandler`（evaluation.py:38）根 run 完成后线程池并发跑 evaluator 并写回 LangSmith feedback。

### 4.8 load/（序列化框架）

**模块职责**：基于白名单的 JSON 序列化/反序列化框架——任何继承 `Serializable` 的对象可按「类路径 + 构造参数」manifest 格式跨版本持久化与恢复；四层机制防御反序列化任意代码执行（load.py:14-68 的完整威胁模型文档：反序列化会执行构造器，恶意 manifest 可注入 base_url 指向攻击者主机——SSRF 向量）。

#### 文件组成与关键实现

| 文件 | 职责 | 关键导出 |
|---|---|---|
| `serializable.py` | `Serializable` 基类（Pydantic + ABC）：to_json 协议与 lc_id | `Serializable`、`to_json_not_implemented` |
| `dump.py` | 序列化入口 dumps/dumpd | `dumps`、`dumpd`、`default` |
| `_validation.py` | 转义式注入防护（`__lc_escaped__`） | `_serialize_value`、`_unescape_value`（私有） |
| `load.py` | 反序列化入口 + Reviver 白名单 | `loads`、`load`、`Reviver`、`default_init_validator` |
| `mapping.py` | 4 张「序列化路径→导入路径」映射表（约 550 行） | `SERIALIZABLE_MAPPING`、`OLD_CORE_NAMESPACES_MAPPING` |

**1. `Serializable.to_json`（serializable.py:227）—— manifest 生成协议**，四步：
1. **可序列性闸门**：`is_lc_serializable()` 类方法默认 False（:138-149）——继承也不会被意外序列化；不通过走 `to_json_not_implemented()` 降级（:380-406）；
2. **kwargs 生成**（:239-250）：遍历 `for k, v in self`，`_is_field_useful`（:314-356）过滤——**只记录与构造默认值有差异的字段**（`_try_neq_default` :86-103 三级降级比较，专为 Pandas DataFrame 这类 `bool(df)` 抛异常的对象设计）；
3. **MRO 合并 secrets 与 attributes**（:252-287）：沿 mro 遍历合并 `lc_secrets`（构造参数名→环境变量名）；
4. **secret 替换**（:296-303）：`_replace_secrets`（:359-377）支持**点路径**逐层下钻，叶子值替换为 `{"lc":1,"type":"secret","id":[env_var_name]}` 标记（**值本身不落盘**）。

**2. `loads`/`Reviver`（load.py:571/457）—— 白名单四层防护**：
- **第一层 类路径白名单**（核心）：`Reviver.__init__`（:345-455）计算 `allowed_class_paths` 集合——`'all'/'core'/'messages'` 字面量模式以 4 张映射表合并体为唯一事实源（`'core'` 只保留 langchain_core 条目，`'messages'` 进一步限 9 个消息类）；校验点在 `Reviver.__call__`（:506-518）：`tuple(value["id"])` 不在白名单 → ValueError，**在任何 import 发生之前**；
- **第二层 命名空间校验**（:520-546）：namespace[0] 必须在 15 个官方包前缀内；`langchain_community`/`langchain` 被列入 `DISALLOW_LOAD_FROM_PATH`（:152-155）——只允许经映射表重定向，不允许按原路径 import；
- **第三层 init_validator 钩子**（:552-555）：默认 `default_init_validator` → `_block_jinja2_templates`（:220-248，**故意不看 class_path** 保持 future-proof），kwargs 中 `template_format == "jinja2"` 即抛 ValueError（jinja2 可执行任意代码）；
- **第四层 转义防注入**（_validation.py）：序列化侧 `_serialize_value`（:69-102）把含 `'lc'` 键的用户 dict 整体包裹 `{"__lc_escaped__": ...}` 不再递归；反序列化侧 `_load`（load.py:814-826）**在递归之前**先解包返回——被转义的用户数据永远不会流入 Reviver。
- 实例化（:557-566）：`importlib.import_module` → getattr → **必须 issubclass(cls, Serializable)**（即使前几层被绕过的最终防线）→ `cls(**kwargs)`。

**3. `mapping.py` 映射表机制**：主表 `SERIALIZABLE_MAPPING`（:22-575，键=序列化时写的旧路径，值=当前导入路径），如 `("langchain","schema","messages","AIMessage") → ("langchain_core","messages","ai","AIMessage")`；`_JS_SERIALIZABLE_MAPPING`（:986-1097）实现 **LangChain.JS 产物跨语言加载**。两处消费：(a) Reviver 命中键时重定向 import_dir；(b) 白名单把键与值都收进 allowed 集合——旧 manifest 也能过第一层校验。

### 4.9 vectorstores/ + embeddings/（检索基础设施）

| 文件 | 职责 | 关键导出 |
|---|---|---|
| `vectorstores/base.py`（39.9KB） | `VectorStore` 抽象：add/search 全家桶（sync+async）、相关性归一化、MMR 接口、`as_retriever` 桥接 | `VectorStore`、`VectorStoreRetriever`(:964) |
| `vectorstores/in_memory.py`（15.4KB） | 纯内存实现：dict 存储 + numpy 余弦 + dump/load（复用 load 框架） | `InMemoryVectorStore`(:34) |
| `vectorstores/utils.py` | 余弦相似度矩阵（numpy/可选 simsimd）与 MMR | `maximal_marginal_relevance`(:112)、`_cosine_similarity`(:39) |
| `embeddings/embeddings.py` | 嵌入接口（embed_documents 批量 / embed_query 单条，允许非对称） | `Embeddings` |
| `embeddings/fake.py` | 测试假嵌入：随机 / SHA256 确定性种子 | `FakeEmbeddings`、`DeterministicFakeEmbedding`(:70) |

**关键实现**：

- **`as_retriever`（base.py:905）**：`return VectorStoreRetriever(vectorstore=self, tags=...)`（:960-961）——1.6.9 已是**静态适配器类**（历史上曾是动态 lambda 子类）。`VectorStoreRetriever._get_relevant_documents`（:1039-1058）：`kwargs_ = self.search_kwargs | kwargs`，按 `search_type` 三路分发 similarity / similarity_score_threshold / mmr；构造期 `validate_search_type`（:986-1016）校验合法值。
- **`InMemoryVectorStore`**：存储 `self.store: dict[str, dict]`（doc_id → {id, vector, text, metadata}，**刻意不继承 Pydantic**，自带 dump/load）；`_similarity_search_with_score_by_vector`（in_memory.py:291-332）：全库快照 → 一次 `cosine_similarity([query], [vectors])[0]` 算出查询对全部文档相似度 → `argsort()[::-1][:k]` 取 top-k，返回三元组（保留 vector 供 MMR 复用）。**每次搜索全库线性扫描 O(N·d)，无索引结构**——只适用于小规模/测试。`dump/load` 用本包 load 框架且 `allowed_objects=[Document]` 白名单收敛到单类——load 框架安全用法的教学示例。
- **`maximal_marginal_relevance`（utils.py:112-163）**：① 种子选择 `np.argmax`（第一个入选者永远是与查询最相似者）；② 贪心主循环：每轮算候选×已选相似度矩阵，`equation_score = lambda_mult * query_score - (1-lambda_mult) * max(similarity_to_selected[i])` 取最高分入列。lambda_mult=1 退化为纯相似度 top-k，=0 纯最大多样性。
- `DeterministicFakeEmbedding`（embeddings/fake.py:70）：`seed = int(sha256(text).hexdigest(), 16) % 10**8` 驱动 `np.random.default_rng`——同文本恒得同向量。

### 4.10 根目录杂项（stores/caches/rate_limiters/retrievers/chat_*/cross_encoders/structured_query/globals/env）

| 文件 | 职责 | 关键导出与实现要点 |
|---|---|---|
| `stores.py` | 批量 KV 存储抽象 | `BaseStore`（mget/mset/mdelete/yield_keys，**刻意只提供批量接口**减少往返）、`ByteStore = BaseStore[str, bytes]`（缓存序列化标准载体）、`InMemoryStore` |
| `caches.py` | LLM 响应缓存 | `BaseCache`（lookup/update/clear，键为 `(prompt, llm_string)` 二元组）、`InMemoryCache`（:155，`len == maxsize` 时 `del next(iter(self._cache))`——dict 保插入序的 **FIFO** 淘汰，非 LRU） |
| `rate_limiters.py` | 限流抽象 + 令牌桶 | `InMemoryRateLimiter._consume`（:163-193）——**惰性补币式令牌桶**（无后台线程）：`threading.Lock` + `time.monotonic()`；首次调用不补币（`last` 为 None 只记录，防"构造后立即爆发"）；攒满 1 令牌才结算；`min(available, max_bucket_size)` 封顶突发；`acquire(blocking=True)` 是轮询等待 `while not self._consume(): time.sleep(check_every_n_seconds)`（:215-218）。**进程内限流，不跨进程；按请求数不限 token** |
| `retrievers.py` | `BaseRetriever` 模板类 | `invoke`（:178-236）：ensure_config → on_retriever_start → `_get_relevant_documents` 钩子 → on_retriever_end/error。**`__init_subclass__`（:145-165）签名反射适配**：探测子类 `_get_relevant_documents` 是否接受 run_manager/额外参数，四种调用形态切换；旧式子类**类定义时动态合成 `_aget_relevant_documents` 闭包**（:155-160）免费获得异步。注：本版本 BaseRetriever 无 Document 去重（去重在 indexing 侧） |
| `chat_history.py` | 对话历史抽象 | `BaseChatMessageHistory`（**1.6.4 起整体 deprecated，2.0.0 移除**）；亮点：`add_message` 与 `add_messages` **互相自适应委托**（:161-192，用 `type(self).add_messages != Base...` 检测子类重写了哪个） |
| `chat_loaders.py` `chat_sessions.py` `cross_encoders.py` | 会话加载/TypedDict/重排打分接口 | `BaseChatLoader`、`ChatSession`、`BaseCrossEncoder` |
| `structured_query.py` | 结构化查询 IR | `Expr.accept`（:85-96）用 `_to_snake_case` 把类名拼成 `visit_comparison` 方法名**动态派发**（Visitor 访问者模式）；`Visitor._validate_func`（:24-44）按 allowed_operators/comparators 白名单拦截（自译过滤条件的安全阀） |
| `globals.py` `env.py` `sys_info.py` `version.py` `_import_utils.py` | 全局开关/运行时信息/版本 | `set_debug/set_verbose/set_llm_cache`（模块级变量 + getter/setter，globals.py:13-15）；`get_runtime_environment`（env.py:10，@lru_cache）；`import_attr`（_import_utils.py:4，全包 `__getattr__` 惰性导入的统一实现） |

### 4.11 utils/ + _api/ + _security/（工具箱与治理安全层）

#### 文件组成（utils/ 21 文件、_api/ 5 文件、_security/ 5 文件）

| 文件 | 职责 | 关键导出 |
|---|---|---|
| `utils/function_calling.py`（31KB） | 任意可调用/模型/dict → OpenAI function schema 的转换中枢 | `convert_to_openai_function`(:377)、`convert_to_openai_tool`(:515)、`convert_to_json_schema`(:577)、`_parse_google_docstring`(:735) |
| `utils/_merge.py` | 消息 chunk 深度合并算法 | `merge_dicts`(:6)、`merge_lists`(:98)、`merge_obj`(:180) |
| `utils/json.py` | 脏 JSON 修复 | `parse_partial_json`(:58)、`parse_json_markdown`(:142) |
| `utils/json_schema.py` | JSON Schema $ref 解引用（循环打断） | `dereference_refs`(:188) |
| `utils/mustache.py`（22KB） | 完整 Mustache 引擎（改编自 chevron） | `render`(:468)、`tokenize`(:199)、`_get_key`(:345) |
| `utils/pydantic.py`（19.8KB） | pydantic v1/v2 兼容层 + pre_init + 动态建模 | `pre_init`(:130)、`is_basemodel_subclass`(:97)、`get_fields`、`model_validate`、`create_model_v2`(:557)、`_create_subset_model`(:284) |
| `utils/utils.py`（15.8KB） | 大杂烩：互斥校验/版本检查/环境工厂/SecretStr/mock 时间/ID | `xor_args`(:24)、`mock_now`(:73)、`guard_import`(:116)、`check_package_version`(:146)、`from_env`(:368)、`secret_from_env`(:442)、`ensure_id`(:509) |
| `utils/aiter.py` `iter.py` | async/sync 迭代工具（tee 分流、批次切分） | `atee`、`safetee`(:91/:203)、`batch_iterate`、`aclosing`(:280) |
| `utils/env.py` | 环境变量三级回退 | `get_from_env`(:60)、`get_from_dict_or_env`(:26) |
| `utils/formatting.py` | 强制关键字格式化器 | `StrictFormatter`(:8)、`formatter`(:80) |
| `utils/strings.py` `usage.py` `uuid.py` `html.py` `input.py` `image.py` `interactive_env.py` `_gateway.py` `_signature.py` | 字符串化/NUL 清洗/整数 dict 运算/uuid7/链接抽取/ANSI 着色/墓碑模块/gateway 配置/签名检查 | `stringify_value`、`sanitize_for_postgres`、`_dict_int_op`、`uuid7`、`find_all_links`、`GatewayConfig`、`_signature_parameters` |
| `_api/deprecation.py`（22.6KB） | @deprecated 全家桶（改编自 matplotlib） | `deprecated`(:119)、`warn_deprecated`(:479)、`surface_langchain_deprecation_warnings`(:571)、`rename_parameter` |
| `_api/beta_decorator.py` | @beta 装饰器 | `beta`(:32)、`LangChainBetaWarning` |
| `_api/internal.py` `path.py` | 内部调用者栈帧探测；路径↔导入路径 | `is_caller_internal`(:5)、`as_import_path`(:26) |
| `_security/_policy.py`（10.9KB） | SSRF 核心策略 | `SSRFPolicy`(:103，frozen dataclass)、`validate_url`(:250)、`validate_url_sync`(:283)、`DEFAULT_SSRF_POLICY`(:118) |
| `_security/_transport.py`（8.2KB） | httpx Transport 子类（IP pinning） | `SSRFSafeTransport`(:31)、`ssrf_safe_client`(:202) |
| `_security/_ssrf_protection.py` `_exceptions.py` | pydantic 字段适配层；异常 | `validate_safe_url`(:41)、`SSRFBlockedError` |

#### 关键函数解析

**1. `convert_to_openai_function`（function_calling.py:377）—— 多形态输入→OpenAI schema 的分派中枢**。if/elif 分派链（:414-478）顺序即协议猜测规则：Anthropic 格式（name+input_schema）→ Bedrock（toolSpec）→ 已是 OpenAI 格式（白名单过滤四键）→ 裸 JSON Schema（title 弹出为函数名）→ pydantic 模型 → TypedDict → BaseTool → 普通 callable。pydantic 路径经 `dereference_refs` 内联 $defs 后 `_rm_titles`（:87）递归删 title（但保留 properties 内部的——provider 用它对齐参数名）。普通函数延迟导入 `create_schema_from_function` 回到 pydantic 流水。`strict=True` 时 `_recursive_set_additional_properties_false`（:825）递归设 `required=全部属性` + `additionalProperties: False`（并 deepcopy 防污染调用方 dict，:411-412）。

**2. `_merge.py` 深度合并——流式 chunk 聚合的核心**。`merge_dicts`（:6-94）逐键优先级链：填补规则 → **类型门禁**（`type(merged[k]) is not type(right_v)` 立即 TypeError——防脏数据串味的总闸）→ str 拼接（但 `index` 值以 `lc_` 开头、id/output_version/model_provider 相等时不拼接——标识符字段拼接会毁掉）→ dict 递归 → list 转 merge_lists → **bool 检查在 int 之前**（bool 是 int 子类，`True+False` 会静默变 1）→ int 累加（index/created/timestamp 改 last-wins）。`merge_lists`（:98-176）**按 index 对齐合并**是 tool_call 流式聚合的关键：新元素有 `index` 键时找同 index 且 id 不冲突的元素整位替换。**所有 chat model 流式聚合最终都落到这 219 行算法上**（调用点：messages/ai.py:665、base.py:394、_compat_bridge.py:648 等）。副作用：浅拷贝起手但嵌套 dict/list 原地递归修改。

**3. `mustache.py` 模板引擎**。`tokenize`（:199）生成器式单遍扫描（standalone 标签左右检查吞换行——"独立行标签不产生空行"语义；set delimiter 即时切换定界符）；`render`（:468）核心是 **scopes 上下文栈**：falsy 作用域短路抑制整段（:533-536）；section 三分支（callable lambda 节/Sequence 循环压栈递归/普通压栈）。`_get_key`（:345）只允许穿越 Mapping 与 list/tuple（:411-419）——**防模板注入穿越到任意对象的属性/方法**。**注意**：模块级全局 `_CURRENT_LINE` 非线程安全；`g_token_cache` 无上限增长。

**4. `pydantic.py` v1/v2 兼容层**。不做运行时版本探测，而是"同时 import 两套 BaseModel，逐函数双分派"：类型联合 `TypeBaseModel`、判定函数、双分派访问器（get_fields：model_fields / \_\_fields\_\_；model_json_schema：model_json_schema() / schema()；model_validate：model_validate / parse_obj）。`pre_init` 装饰器（:130）保留已弃用的 `@root_validator(pre=True)` 而非 `@model_validator(mode="before")`——**源码注释明示后者会改变验证器执行顺序**（pydantic#7434）。动态建模三防护：保留字重映射（`_RESERVED_NAMES` 运行时采集 + `private_{key}` 别名还原，:526-551）、root model 的 title 强制改写、lru_cache(256) 缓存。

**5. `@deprecated`（deprecation.py:119）**。三层结构，关键机制：**一次性告警**（闭包变量 warned + `is_caller_internal()` 栈帧探测——`inspect.currentframe()` 回退 depth=2 帧读 `__name__` 以 "langchain" 开头即内部调用不告警，:218-246）；**抑制感知**（`_SUPPRESSING_LANGCHAIN_DEPRECATION_WARNING` ContextVar——抑制上下文内不消耗首次告警机会）；**四种形态**（类——包装 \_\_init\_\_ 且 `type(self) is obj` 保证子类不告警；pydantic FieldInfo——重建带弃用说明的新对象；property——每次访问都告警；函数——wraps+async 分支）；PEP 702 `__deprecated__` 供 IDE 标灰。`surface_langchain_deprecation_warnings`（:571）在 **import langchain_core 瞬间全局生效**（\_\_init\_.py:19）——因为 Python 默认在非 \_\_main\_\_ 忽略 DeprecationWarning。

**6. `_security` SSRF 防护**。数据基座：15 个 IPv4 + 8 个 IPv6 保留网段黑名单（含 **IPv4-mapped `::ffff:0:0/96`**、NAT64 前缀）+ 7 个云元数据 IP（:16-51）。校验链：`validate_resolved_ip`（:198）对 IPv6 先 `_extract_embedded_ipv4`（:126，ipv4_mapped 属性/NAT64 packed[-4:]/IPv4-compatible 三路）**用提取出的 IPv4 重新过黑名单**——封死 `http://[::ffff:10.0.0.1]/` 绕过；`validate_url`（:250）异步完整版用 `asyncio.to_thread(getaddrinfo)` 解析 DNS，**对每一个解析结果 IP 逐个校验**。`SSRFSafeTransport`（_transport.py:31）七步流程核心是 **IP pinning**：取第一个合法 IP 重写 `request.url.copy_with(host=pinned_ip)` 但**保留原 headers（Host 头）与 SNI 域名**（TLS 证书仍按域名校验）——封死"校验时解析到公网 IP、建连时 DNS rebinding 到内网"的 TOCTOU 窗口。重定向防护是架构性复用：httpx 每跳重定向都会重新走 transport 的 handle_request，自动完整重走校验。**消费现状**：core 包内无生产代码调用（为 community 包的 document loaders 预留）。

**7. `exceptions.py` 异常体系**：`LangChainException`（:7）根 → `TracerException`（:11）、`OutputParserException`（:15，双继承 ValueError，`send_to_llm=True` 允许纠错上下文回传 agent 自愈）、`ModelError`（:68，类属性 `is_retryable`）及 8 个 HTTP 语义子类（AuthenticationError 401 / PermissionDenied 403 / InvalidRequest 400 / NotFound 404 / **RateLimit 429 与 APIError 5xx 与 Connection/Timeout 均 is_retryable=True**）、`ContextOverflowError`（:123）。

---

## 5. 文件清单总表

覆盖全部 182 个纳入范围的生产源文件（路径相对 `libs/core/langchain_core/`；"依赖"列仅列关键项：内部模块 + 主要第三方库）。逐文件的深度解析见第 4 章对应小节（表内"详解"列）。

### 5.1 runnables/（16 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 | 详解 |
|---|---|---|---|---|---|
| `runnables/base.py` | runnables 核心 | Runnable 协议、模板方法群、四件套回调骨架、Sequence/Parallel/Lambda/Generator/Binding | Runnable, RunnableSerializable, RunnableSequence, RunnableParallel, RunnableLambda, coerce_to_runnable, chain | config.py, utils.py, callbacks.manager, tracers, load.serializable, pydantic | §4.1 |
| `runnables/config.py` | runnables 核心 | RunnableConfig 规范化/合并/补丁/ContextVar 传播、回调工厂、线程池 | ensure_config, patch_config, merge_configs, var_child_runnable_config, run_in_executor, ContextThreadPoolExecutor | callbacks.manager, langsmith(延迟) | §4.1 |
| `runnables/utils.py` | runnables 核心 | 类型变量、AddableDict、签名探测、AST 分析、ConfigurableField 规格 | Input, Output, AddableDict, accepts_config, gather_with_concurrency, get_unique_config_specs, ConfigurableField | _signature.py, stdlib ast/inspect | §4.1 |
| `runnables/schema.py` | runnables 核心 | 流事件 TypedDict 契约 | StreamEvent, StandardStreamEvent, CustomStreamEvent, EventData | typing | §4.1 |
| `runnables/branch.py` | runnables 扩展 | 条件分支组合子 | RunnableBranch | base.py, config.py | §4.2 |
| `runnables/configurable.py` | runnables 扩展 | 运行时字段替换/备选切换 | DynamicRunnable, RunnableConfigurableFields, RunnableConfigurableAlternatives | base.py, utils.py, pydantic | §4.2 |
| `runnables/fallbacks.py` | runnables 扩展 | 失败回退 | RunnableWithFallbacks | base.py, config.py | §4.2 |
| `runnables/graph.py` | runnables 图 | 运行图数据结构（Node/Edge/Graph） | Graph, Node, Edge, is_uuid | load.serializable, pydantic | §4.2 |
| `runnables/graph_ascii.py` | runnables 图 | grandalf Sugiyama 布局 ASCII 渲染 | draw_ascii, AsciiCanvas | graph.py, grandalf(可选) | §4.2 |
| `runnables/graph_mermaid.py` | runnables 图 | Mermaid 语法生成与 PNG 渲染 | draw_mermaid, draw_mermaid_png | graph.py, yaml, httpx, pyppeteer(可选) | §4.2 |
| `runnables/graph_png.py` | runnables 图 | pygraphviz PNG 渲染 | PngDrawer | graph.py, pygraphviz(可选) | §4.2 |
| `runnables/history.py` | runnables 扩展 | 消息历史读写包装（deprecated） | RunnableWithMessageHistory | base.py, passthrough.py, messages, tracers.context, chat_history | §4.2 |
| `runnables/passthrough.py` | runnables 扩展 | 恒等透传/键合并赋值/键挑选 | RunnablePassthrough, RunnableAssign, RunnablePick | base.py, config.py, iter.py | §4.2 |
| `runnables/retry.py` | runnables 扩展 | tenacity 重试绑定 | RunnableRetry, ExponentialJitterParams | base.py, tenacity | §4.2 |
| `runnables/router.py` | runnables 扩展 | 静态查表路由 | RouterRunnable, RouterInput | base.py, config.py | §4.2 |
| `runnables/__init__.py` | runnables | 惰性导出门面（30 符号） | — | _import_utils | §4.1 |

### 5.2 language_models/ + outputs/（16 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 | 详解 |
|---|---|---|---|---|---|
| `language_models/base.py` | 语言模型 | 生态根契约 BaseLanguageModel | BaseLanguageModel, LangSmithParams, get_tokenizer | runnables, load.serializable, env.py, transformers(可选) | §4.3 |
| `language_models/chat_models.py` | 语言模型 | BaseChatModel 完整模板链、缓存/限流/tracing 集成 | BaseChatModel, SimpleChatModel, generate_from_stream | base.py, runnables.config, callbacks.manager, messages, outputs, caches, rate_limiters, _compat_bridge, load.dump | §4.3 |
| `language_models/chat_model_stream.py` | 语言模型 | v3 流式聚合对象与投影 | ChatModelStream, AsyncChatModelStream, SyncProjection | langchain_protocol, messages, callbacks.base | §4.3 |
| `language_models/llms.py` | 语言模型 | 传统 BaseLLM/LLM（批级缓存、批量 API） | BaseLLM, LLM, create_base_retry_decorator | 同 chat_models 大部分 + tenacity | §4.3 |
| `language_models/_compat_bridge.py` | 语言模型 | v1 chunk 流→v2 协议事件桥；消息重放 | chunks_to_events, message_to_events, finalize_tool_call_chunk | messages, langchain_protocol, utils._merge | §4.3 |
| `language_models/_utils.py` | 语言模型 | 追踪参数过滤、内容块 v0→v1 归一化 | _normalize_messages, _filter_invocation_params_for_tracing | messages | §4.3 |
| `language_models/fake.py` | 语言模型 | 传统 LLM 测试替身 | FakeListLLM, FakeStreamingListLLM | llms.py | §4.3 |
| `language_models/fake_chat_models.py` | 语言模型 | 聊天模型测试替身家族 | GenericFakeChatModel, ParrotFakeChatModel, FakeListChatModel | chat_models.py, messages | §4.3 |
| `language_models/model_profile.py` | 语言模型 | 模型能力元数据 TypedDict | ModelProfile, ModelProfileRegistry | typing | §4.3 |
| `language_models/__init__.py` | 语言模型 | 惰性导出（20 符号） | — | _import_utils | §4.3 |
| `outputs/generation.py` | outputs | 文本生成数据类 + 可拼接 Chunk | Generation, GenerationChunk | load.serializable, utils._merge | §4.3 |
| `outputs/chat_generation.py` | outputs | 聊天变体（持 message）+ Chunk 合并 | ChatGeneration, ChatGenerationChunk, merge_chat_generation_chunks | generation.py, messages, utils._merge | §4.3 |
| `outputs/chat_result.py` | outputs | 单次调用结果容器 | ChatResult | pydantic | §4.3 |
| `outputs/llm_result.py` | outputs | 通用结果容器（回调载荷） | LLMResult | pydantic | §4.3 |
| `outputs/run_info.py` | outputs | 运行元信息（向后兼容） | RunInfo | pydantic | §4.3 |
| `outputs/__init__.py` | outputs | 惰性导出 | — | _import_utils | §4.3 |

### 5.3 messages/（20 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 | 详解 |
|---|---|---|---|---|---|
| `messages/base.py` | messages | BaseMessage（content 多形态、content_blocks 管线）、BaseMessageChunk | BaseMessage, BaseMessageChunk, merge_content, message_to_dict | load.serializable, prompts.chat(延迟), block_translators(延迟), utils._merge | §4.4 |
| `messages/ai.py` | messages | AIMessage/AIMessageChunk（tool_calls/usage/增量合并） | AIMessage, AIMessageChunk, UsageMetadata, add_ai_message_chunks, add_usage | base.py, content.py, tool.py, utils(json/_merge/usage) | §4.4 |
| `messages/chat.py` | messages | 任意角色 ChatMessage | ChatMessage, ChatMessageChunk | base.py | §4.4 |
| `messages/content.py` | messages | v1 标准内容块 TypedDict 体系 + 工厂 | ContentBlock 联合, KNOWN_BLOCK_TYPES, create_text_block 等 10 工厂, is_data_content_block | typing, utils.uuid | §4.4 |
| `messages/function.py` | messages | 旧版 FunctionMessage | FunctionMessage, FunctionMessageChunk | base.py | §4.4 |
| `messages/human.py` | messages | 用户消息 | HumanMessage, HumanMessageChunk | base.py | §4.4 |
| `messages/system.py` | messages | 系统消息 | SystemMessage, SystemMessageChunk | base.py | §4.4 |
| `messages/modifier.py` | messages | LangGraph 删历史控制信号 | RemoveMessage | base.py | §4.4 |
| `messages/tool.py` | messages | ToolMessage + ToolCall TypedDict + 默认解析器 | ToolMessage, ToolCall, ToolCallChunk, default_tool_parser | base.py, utils.json | §4.4 |
| `messages/utils.py` | messages | OpenAI 转换/coercion/历史管理三件套/token 计数 | convert_to_messages, convert_to_openai_messages, filter_messages, merge_message_runs, trim_messages, get_buffer_string, count_tokens_approximately | 全 messages + block_translators.openai, runnables.config, text_splitters(可选) | §4.4 |
| `messages/__init__.py` | messages | 惰性导出（约 60 符号） | — | _import_utils | §4.4 |
| `messages/block_translators/__init__.py` | block_translators | 翻译器注册中心 | PROVIDER_TRANSLATORS, register_translator, get_translator | 7 个 provider 模块 | §4.4 |
| `messages/block_translators/openai.py` | block_translators | OpenAI 双 API 内容↔v1 块 | translate_content, convert_to_openai_data_block | messages.content, langchain_protocol | §4.4 |
| `messages/block_translators/anthropic.py` | block_translators | Anthropic 内容↔v1 块 | translate_content, _convert_to_v1_from_anthropic | messages.content | §4.4 |
| `messages/block_translators/bedrock.py` | block_translators | Bedrock 旧 API（claude 委托） | translate_content | anthropic.py | §4.4 |
| `messages/block_translators/bedrock_converse.py` | block_translators | Bedrock Converse API | translate_content, _convert_to_v1_from_converse | messages.content | §4.4 |
| `messages/block_translators/google_genai.py` | block_translators | Google GenAI + grounding→Citations | translate_content, translate_grounding_metadata_to_citations | messages.content | §4.4 |
| `messages/block_translators/google_vertexai.py` | block_translators | 转发注册 | —（复用 genai） | google_genai.py | §4.4 |
| `messages/block_translators/groq.py` | block_translators | Groq（reasoning_content/executed_tools） | translate_content, _convert_to_v1_from_groq | messages.content | §4.4 |
| `messages/block_translators/langchain_v0.py` | block_translators | v0 旧块→v1（兜底管线专用） | _convert_v0_multimodal_input_to_v1 | content.py 工厂 | §4.4 |

### 5.4 prompts/ + output_parsers/ + prompt_values.py（24 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 | 详解 |
|---|---|---|---|---|---|
| `prompts/base.py` | prompts | 提示词抽象基类 | BasePromptTemplate, format_document | runnables.base, load.serializable, documents | §4.5 |
| `prompts/string.py` | prompts | 三种 template_format 基础设施 | StringPromptTemplate, DEFAULT_FORMATTER_MAPPING, get_template_variables | utils.formatting, utils.mustache, jinja2(可选) | §4.5 |
| `prompts/prompt.py` | prompts | 具体 PromptTemplate | PromptTemplate | string.py, base.py, utils.pydantic | §4.5 |
| `prompts/chat.py` | prompts | 聊天提示词体系 | ChatPromptTemplate, MessagesPlaceholder, HumanMessagePromptTemplate 等 | base.py, message.py, prompt.py, messages.utils | §4.5 |
| `prompts/dict.py` | prompts | dict 模板（多模态块） | DictPromptTemplate | runnables.base, string.py | §4.5 |
| `prompts/few_shot.py` | prompts | 少样本提示词 | FewShotPromptTemplate, FewShotChatMessagePromptTemplate | prompt.py, example_selectors | §4.5 |
| `prompts/few_shot_with_templates.py` | prompts | 模板对象版少样本 | FewShotPromptWithTemplates | string.py | §4.5 |
| `prompts/image.py` | prompts | 图像模板 | ImagePromptTemplate | string.py | §4.5 |
| `prompts/loading.py` | prompts | （弃用）配置文件/Hub 加载 | load_prompt | yaml/json, _api | §4.5 |
| `prompts/message.py` | prompts | 消息模板抽象 | BaseMessagePromptTemplate | pydantic | §4.5 |
| `prompts/structured.py` | prompts | （beta）schema 提示词 | StructuredPrompt | chat.py, _api.beta | §4.5 |
| `prompts/__init__.py` | prompts | 惰性导出 | — | _import_utils | §4.5 |
| `output_parsers/base.py` | output_parsers | 三层解析器基类（Runnable 身份） | BaseOutputParser, BaseGenerationOutputParser | runnables, outputs, prompts(prompt_values) | §4.5 |
| `output_parsers/transform.py` | output_parsers | 流式解析支持 | BaseTransformOutputParser, BaseCumulativeTransformOutputParser | base.py, runnables | §4.5 |
| `output_parsers/json.py` | output_parsers | JSON 解析 | JsonOutputParser | transform.py, utils.json, format_instructions | §4.5 |
| `output_parsers/pydantic.py` | output_parsers | JSON+Pydantic 校验 | PydanticOutputParser | json.py, utils.pydantic | §4.5 |
| `output_parsers/openai_tools.py` | output_parsers | tool_calls 解析 | JsonOutputToolsParser, PydanticToolsParser, parse_tool_calls | transform.py, messages, utils.json | §4.5 |
| `output_parsers/openai_functions.py` | output_parsers | 旧 function_call 解析 | OutputFunctionsParser 等 5 个 | base.py, utils | §4.5 |
| `output_parsers/list.py` | output_parsers | 列表解析三实现 | CommaSeparatedListOutputParser 等 | transform.py | §4.5 |
| `output_parsers/string.py` | output_parsers | 恒等 str 解析 | StrOutputParser | base.py | §4.5 |
| `output_parsers/xml.py` | output_parsers | XML→嵌套 dict | XMLOutputParser | transform.py, defusedxml, runnables.utils(AddableDict) | §4.5 |
| `output_parsers/format_instructions.py` | output_parsers | 格式指令常量 | JSON_FORMAT_INSTRUCTIONS | — | §4.5 |
| `output_parsers/__init__.py` | output_parsers | 惰性导出 | — | _import_utils | §4.5 |
| `prompt_values.py` | 根目录 | PromptValue 体系 | PromptValue, StringPromptValue, ChatPromptValue, ImagePromptValue | messages, load.serializable | §4.5 |

### 5.5 tools/ + agents + documents/ + document_loaders/ + indexing/ + example_selectors/（25 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 | 详解 |
|---|---|---|---|---|---|
| `tools/base.py` | tools | BaseTool 执行管线 + schema 推导 | BaseTool, ToolException, create_schema_from_function, InjectedToolArg, BaseToolkit | runnables, callbacks, messages.tool, utils.function_calling, utils.pydantic | §4.6 |
| `tools/convert.py` | tools | @tool 装饰器 | tool, convert_runnable_to_tool | base.py, structured.py, simple.py | §4.6 |
| `tools/structured.py` | tools | 多输入结构化工具 | StructuredTool, StructuredTool.from_function | base.py, utils.pydantic | §4.6 |
| `tools/simple.py` | tools | 单输入遗留工具 | Tool | base.py | §4.6 |
| `tools/render.py` | tools | 工具列表文本渲染 | render_text_description, render_text_description_and_args | tools.base | §4.6 |
| `tools/retriever.py` | tools | 检索器→工具 | create_retriever_tool | retrievers.py, documents, structured.py | §4.6 |
| `tools/__init__.py` | tools | 惰性导出（19 符号） | — | _import_utils | §4.6 |
| `agents.py` | 根目录 | 遗留 Agent 数据 schema | AgentAction, AgentActionMessageLog, AgentStep, AgentFinish | messages, pydantic | §4.6 |
| `documents/base.py` | documents | Document/Blob/BaseMedia | Document, Blob, BaseMedia | pydantic, utils.uuid | §4.6 |
| `documents/compressor.py` | documents | 查询感知后处理抽象 | BaseDocumentCompressor, compress_documents | documents.base, runnables.config | §4.6 |
| `documents/transformers.py` | documents | 查询无关变换抽象 | BaseDocumentTransformer, transform_documents | documents.base | §4.6 |
| `documents/__init__.py` | documents | 惰性导出 | — | _import_utils | §4.6 |
| `document_loaders/base.py` | document_loaders | 惰性优先加载接口 + Blob 解析器 | BaseLoader, lazy_load, BaseBlobParser | documents, text_splitters(可选), runnables.config | §4.6 |
| `document_loaders/blob_loaders.py` | document_loaders | Blob 流加载抽象 | BlobLoader | documents | §4.6 |
| `document_loaders/langsmith.py` | document_loaders | LangSmith Dataset→Document | LangSmithLoader | langsmith, base.py | §4.6 |
| `document_loaders/__init__.py` | document_loaders | 惰性导出 | — | _import_utils | §4.6 |
| `indexing/api.py` | indexing | index()/aindex() 编排 | index, aindex, IndexingResult | base.py, documents, vectorstores, utils | §4.6 |
| `indexing/base.py` | indexing | RecordManager 账本 + DocumentIndex | RecordManager, InMemoryRecordManager, DocumentIndex | retrievers.py, documents | §4.6 |
| `indexing/in_memory.py` | indexing | 字典 DocumentIndex | InMemoryDocumentIndex | base.py, documents | §4.6 |
| `indexing/__init__.py` | indexing | 惰性导出 | — | _import_utils | §4.6 |
| `example_selectors/base.py` | example_selectors | 选择器接口 | BaseExampleSelector | runnables.config | §4.6 |
| `example_selectors/length_based.py` | example_selectors | 按长度贪心装填 | LengthBasedExampleSelector | base.py | §4.6 |
| `example_selectors/semantic_similarity.py` | example_selectors | 向量相似度/MMR 选择 | SemanticSimilarityExampleSelector, MaxMarginalRelevanceExampleSelector | vectorstores.base, base.py | §4.6 |
| `example_selectors/__init__.py` | example_selectors | 惰性导出 | — | _import_utils | §4.6 |
| `py.typed`（标记文件，非代码） | 根目录 | PEP 561 类型标记 | — | — | — |

### 5.6 callbacks/ + tracers/（22 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 | 详解 |
|---|---|---|---|---|---|
| `callbacks/base.py` | callbacks | handler 接口（6 Mixin）+ 管理器基类 | BaseCallbackHandler, AsyncCallbackHandler, BaseCallbackManager | utils.uuid | §4.7 |
| `callbacks/manager.py` | callbacks | 事件分发 + CallbackManager 双子 + configure 装配 | handle_event, CallbackManager, AsyncCallbackManager, trace_as_chain_group, dispatch_custom_event, shielded | base.py, tracers.context/langchain, utils, langsmith | §4.7 |
| `callbacks/file.py` | callbacks | 文件日志 handler | FileCallbackHandler | base.py | §4.7 |
| `callbacks/stdout.py` | callbacks | verbose 打印 handler | StdOutCallbackHandler | base.py | §4.7 |
| `callbacks/streaming_stdout.py` | callbacks | 流式 stdout handler | StreamingStdOutCallbackHandler | base.py | §4.7 |
| `callbacks/usage.py` | callbacks | token 用量聚合 | UsageMetadataCallbackHandler, get_usage_metadata_callback | messages.ai, tracers.context | §4.7 |
| `callbacks/__init__.py` | callbacks | 惰性导出（34 符号） | — | _import_utils | §4.7 |
| `tracers/base.py` | tracers | BaseTracer 三段式 | BaseTracer, AsyncBaseTracer | core.py, schemas | §4.7 |
| `tracers/core.py` | tracers | run 树构建引擎 | _TracerCore, _start_trace, _create_llm_run | schemas, utils | §4.7 |
| `tracers/context.py` | tracers | 全局追踪开关（ContextVar） | tracing_v2_enabled, collect_runs, register_configure_hook | langchain.py | §4.7 |
| `tracers/schemas.py` | tracers | Run 别名 | Run | langsmith.schemas | §4.7 |
| `tracers/langchain.py` | tracers | LangSmith 上报 | LangChainTracer, get_client | base.py, langsmith, tenacity | §4.7 |
| `tracers/event_stream.py` | tracers | astream_events v1/v2 引擎 | _AstreamEventsCallbackHandler, _astream_events_implementation_v2 | memory_stream.py, schema(runnables), langsmith | §4.7 |
| `tracers/log_stream.py` | tracers | astream_log 引擎 | LogStreamCallbackHandler, RunLog, RunLogPatch | base.py, jsonpatch | §4.7 |
| `tracers/memory_stream.py` | tracers | 跨循环内存通道 | _MemoryStream, _SendStream | asyncio, weakref | §4.7 |
| `tracers/root_listeners.py` | tracers | 根 run 监听器 | RootListenersTracer, AsyncRootListenersTracer | base.py | §4.7 |
| `tracers/run_collector.py` | tracers | run 树收集 | RunCollectorCallbackHandler | base.py | §4.7 |
| `tracers/stdout.py` | tracers | 控制台 tracer | ConsoleCallbackHandler, FunctionCallbackHandler | base.py, utils.input | §4.7 |
| `tracers/evaluation.py` | tracers | 评估回调 | EvaluatorCallbackHandler | base.py, langsmith | §4.7 |
| `tracers/_compat.py` | tracers | Run 序列化 v1/v2 兼容 | run_to_dict, run_copy, run_construct | pydantic | §4.7 |
| `tracers/_streaming.py` | tracers | 流式 handler 协议 | _StreamingCallbackHandler, _V2StreamingCallbackHandler | typing | §4.7 |
| `tracers/__init__.py` | tracers | 惰性导出（8 符号） | — | _import_utils | §4.7 |

### 5.7 load/ + vectorstores/ + embeddings/（13 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 | 详解 |
|---|---|---|---|---|---|
| `load/serializable.py` | load | Serializable 基类与 manifest 协议 | Serializable, to_json_not_implemented | pydantic, _api.path | §4.8 |
| `load/dump.py` | load | 序列化入口 | dumps, dumpd, default | _validation.py | §4.8 |
| `load/_validation.py` | load | 转义式注入防护 | _serialize_value, _unescape_value | serializable.py | §4.8 |
| `load/load.py` | load | 反序列化 + Reviver 白名单 | loads, load, Reviver, default_init_validator | mapping.py, _validation.py, utils | §4.8 |
| `load/mapping.py` | load | 4 张路径映射表 | SERIALIZABLE_MAPPING, OLD_CORE_NAMESPACES_MAPPING | — | §4.8 |
| `load/__init__.py` | load | 惰性导出（急切导入 load 函数避名冲突） | — | _import_utils | §4.8 |
| `vectorstores/base.py` | vectorstores | VectorStore 抽象 + as_retriever 桥接 | VectorStore, VectorStoreRetriever | documents, retrievers, embeddings, runnables.config | §4.9 |
| `vectorstores/in_memory.py` | vectorstores | 内存实现（numpy 余弦） | InMemoryVectorStore | base.py, utils.py, load, embeddings | §4.9 |
| `vectorstores/utils.py` | vectorstores | 余弦矩阵 + MMR | maximal_marginal_relevance, _cosine_similarity | numpy, simsimd(可选) | §4.9 |
| `vectorstores/__init__.py` | vectorstores | 惰性导出 | — | _import_utils | §4.9 |
| `embeddings/embeddings.py` | embeddings | 嵌入接口 | Embeddings | runnables.config | §4.9 |
| `embeddings/fake.py` | embeddings | 测试假嵌入 | FakeEmbeddings, DeterministicFakeEmbedding | numpy | §4.9 |
| `embeddings/__init__.py` | embeddings | 惰性导出 | — | _import_utils | §4.9 |

### 5.8 根目录散文件 + utils/ + _api/ + _security/（47 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 | 详解 |
|---|---|---|---|---|---|
| `__init__.py` | 根 | 包入口（版本+警告浮出） | __version__ | _api, version | §1.2 |
| `version.py` | 根 | 版本常量 | VERSION | — | §1.2 |
| `env.py` | 根 | 运行时环境信息 | get_runtime_environment | platform | §4.10 |
| `globals.py` | 根 | 全局开关 | set/get_debug, set/get_verbose, set/get_llm_cache | caches(类型) | §4.10 |
| `exceptions.py` | 根 | 异常体系 | LangChainException, ModelError 及 8 子类, OutputParserException | stdlib | §4.11 |
| `_import_utils.py` | 根 | 惰性导入统一实现 | import_attr | importlib | §4.10 |
| `retrievers.py` | 根 | BaseRetriever 模板类 | BaseRetriever, LangSmithRetrieverParams | runnables, callbacks, documents | §4.10 |
| `caches.py` | 根 | LLM 缓存抽象 | BaseCache, InMemoryCache | messages(类型) | §4.10 |
| `rate_limiters.py` | 根 | 令牌桶限流 | BaseRateLimiter, InMemoryRateLimiter | threading, time | §4.10 |
| `stores.py` | 根 | 批量 KV 存储 | BaseStore, ByteStore, InMemoryStore | runnables.config | §4.10 |
| `chat_history.py` | 根 | 对话历史（deprecated） | BaseChatMessageHistory, InMemoryChatMessageHistory | messages, _api | §4.10 |
| `chat_loaders.py` | 根 | 会话加载抽象 | BaseChatLoader | — | §4.10 |
| `chat_sessions.py` | 根 | 会话 TypedDict | ChatSession | typing | §4.10 |
| `cross_encoders.py` | 根 | 重排打分接口 | BaseCrossEncoder | — | §4.10 |
| `structured_query.py` | 根 | 查询 IR + Visitor | Visitor, Comparison, Operation, Operator, Comparator | enum, dataclass | §4.10 |
| `sys_info.py` | 根 | 调试环境信息打印 | print_sys_info | importlib.metadata | §4.11 |
| `utils/__init__.py` | utils | 惰性导出门面（27 符号） | — | _import_utils | §4.11 |
| `utils/utils.py` | utils | 互斥校验/版本检查/环境工厂/mock/ID | xor_args, mock_now, guard_import, check_package_version, from_env, secret_from_env, ensure_id | packaging, importlib.metadata | §4.11 |
| `utils/function_calling.py` | utils | →OpenAI function schema 转换 | convert_to_openai_function, convert_to_openai_tool | pydantic, json_schema.py, tools.base(延迟) | §4.11 |
| `utils/_merge.py` | utils | 深度合并算法 | merge_dicts, merge_lists, merge_obj | typing | §4.11 |
| `utils/json.py` | utils | 脏 JSON 修复 | parse_partial_json, parse_json_markdown | exceptions, json | §4.11 |
| `utils/json_schema.py` | utils | $ref 解引用 | dereference_refs | typing | §4.11 |
| `utils/mustache.py` | utils | Mustache 引擎 | render, tokenize, _get_key | stdlib | §4.11 |
| `utils/pydantic.py` | utils | v1/v2 兼容层 + 动态建模 | pre_init, is_basemodel_subclass, get_fields, model_json_schema, create_model_v2, _create_subset_model | pydantic, packaging | §4.11 |
| `utils/aiter.py` | utils | async 迭代工具 | atee, abatch_iterate, aclosing | asyncio | §4.11 |
| `utils/iter.py` | utils | sync 迭代工具 | safetee, batch_iterate, tee_peer | itertools, threading | §4.11 |
| `utils/env.py` | utils | 环境变量三级回退 | get_from_env, get_from_dict_or_env | os | §4.11 |
| `utils/formatting.py` | utils | 强制关键字格式化器 | StrictFormatter, formatter | string | §4.5 |
| `utils/strings.py` | utils | 值字符串化/PG 清洗 | stringify_value, stringify_dict, sanitize_for_postgres | — | §4.11 |
| `utils/usage.py` | utils | 整数 dict 递归运算内核 | _dict_int_op | typing | §4.11 |
| `utils/uuid.py` | utils | uuid7 | uuid7 | uuid_utils | §4.11 |
| `utils/html.py` | utils | HTML 链接抽取 | find_all_links, extract_sub_links | re | §4.11 |
| `utils/input.py` | utils | ANSI 着色输出 | get_color_mapping, get_colored_text, print_text | — | §4.11 |
| `utils/image.py` | utils | 墓碑模块（安全移除说明） | —（访问抛 ValueError） | — | §4.11 |
| `utils/interactive_env.py` | utils | IPython 检测 | is_interactive_env | sys | §4.11 |
| `utils/_gateway.py` | utils | LangSmith Gateway 配置解析 | GatewayConfig, _resolve_gateway_config, _parse_gateway_metadata | httpx, pydantic | §4.11 |
| `utils/_signature.py` | utils | 不求值签名检查（PEP 649） | _signature_parameters | inspect | §4.11 |
| `_api/__init__.py` | _api | 惰性导出（13 符号） | — | _import_utils | §4.11 |
| `_api/deprecation.py` | _api | @deprecated 全家桶 | deprecated, warn_deprecated, surface_langchain_deprecation_warnings, rename_parameter | warnings, functools, inspect | §4.11 |
| `_api/beta_decorator.py` | _api | @beta 装饰器 | beta, LangChainBetaWarning, surface_langchain_beta_warnings | internal.py | §4.11 |
| `_api/internal.py` | _api | 内部调用者探测 | is_caller_internal | inspect | §4.11 |
| `_api/path.py` | _api | 路径↔导入路径 | get_relative_path, as_import_path, PACKAGE_DIR | pathlib | §4.11 |
| `_security/__init__.py` | _security | 汇总导出（内部模块） | — | 4 个子模块 | §4.11 |
| `_security/_policy.py` | _security | SSRF 策略（IP 黑名单/DNS 校验） | SSRFPolicy, validate_url, validate_url_sync, DEFAULT_SSRF_POLICY | ipaddress, socket, asyncio | §4.11 |
| `_security/_transport.py` | _security | httpx Transport（IP pinning） | SSRFSafeTransport, SSRFSafeSyncTransport, ssrf_safe_client | httpx, _policy | §4.11 |
| `_security/_ssrf_protection.py` | _security | pydantic 字段适配 | validate_safe_url, is_safe_url, SSRFProtectedUrl 等 4 Annotated 类型 | _policy, pydantic | §4.11 |
| `_security/_exceptions.py` | _security | SSRF 异常 | SSRFBlockedError | — | §4.11 |

（`utils/env.py` 与根 `env.py` 职责不同：前者是环境变量读取工具，后者是运行时环境信息。）

---

## 6. 关键函数深度解析

以下函数覆盖核心业务链路，逐个给出带行号的代码片段（节选自源码）与逐段实现解读。代码已与源文件逐一核对。

### 6.1 `RunnableSequence.invoke`（runnables/base.py:3434-3467）—— LCEL 链执行核心

```python
def invoke(                                            # base.py:3434
    self, input: Input, config: RunnableConfig | None = None, **kwargs: Any
) -> Output:
    # setup callbacks and context
    config = ensure_config(config)                     # :3438  ①
    callback_manager = get_callback_manager_for_config(config)  # :3439
    # start the root run
    run_manager = callback_manager.on_chain_start(     # :3441  ②
        None, input,
        name=config.get("run_name") or self.get_name(),
        run_id=config.pop("run_id", None),
    )
    input_ = input
    # invoke all steps in sequence
    try:
        for i, step in enumerate(self.steps):          # :3451  ③
            # mark each step as a child run
            config = patch_config(                     # :3453  ④
                config, callbacks=run_manager.get_child(f"seq:step:{i + 1}")
            )
            with set_config_context(config) as context:  # :3456  ⑤
                if i == 0:
                    input_ = context.run(step.invoke, input_, config, **kwargs)
                else:
                    input_ = context.run(step.invoke, input_, config)
    # finish the root run
    except BaseException as e:                         # :3462  ⑥
        run_manager.on_chain_error(e)
        raise
    else:
        run_manager.on_chain_end(input_)               # :3466  ⑦
        return cast("Output", input_)
```

**逐段解读**：
- **①** `ensure_config` 是所有执行入口的第一步——三层合并（默认值 → ContextVar ambient → 显式 config）产出全键 config（见 §6.3）；
- **②** 用 `on_chain_start` 开启根 run 并拿到 `run_manager`（追踪树的节点句柄）；`config.pop("run_id", None)` 消费型参数——注意**原地修改**传入的 dict；
- **③** 责任链主循环：`self.steps` 是 first+middle+last 重组的完整列表（见 §4.1），前一步输出 `input_` 即下一步输入；
- **④** `patch_config` 生成子运行 config——`get_child(f"seq:step:{i+1}")` 使追踪树上每步带序号标签（LangSmith 中可见 `seq:step:1/2/3`）；patch 换 callbacks 时会同时清 run_name/run_id（config.py:380-387）；
- **⑤** `set_config_context` 把子 config 塞进 ContextVar 副本，`context.run(...)` 保证 step 内部任何"没显式传 config 的深层调用"都能经 `ensure_config` 继承到正确配置（tracing 链不断的根本原因）；
- **⑥⑦** try/except/else 三段：异常先 `on_chain_error` 再 re-raise，成功才 `on_chain_end`——回调生命周期闭环的标准写法（全库一致）。

### 6.2 `BaseChatModel._generate_with_cache`（chat_models.py:1892-1929 起）—— 单条 prompt 的执行分发器

```python
def _generate_with_cache(self, messages, stop=None, run_manager=None, **kwargs):  # :1892
    llm_cache = self.cache if isinstance(self.cache, BaseCache) else get_llm_cache()  # :1899  ①
    check_cache = self.cache is not False                                        # :1903
    if check_cache:
        if llm_cache is not None:
            llm_string = self._get_llm_string(stop=stop, **kwargs)               # :1906
            normalized_messages = [                                               # :1907
                (msg.model_copy(update={"id": None}) if getattr(msg, "id", None) is not None
                 else msg)
                for msg in messages
            ]
            prompt = dumps(normalized_messages)                                   # :1915  ②
            cache_val = llm_cache.lookup(prompt, llm_string)                      # :1916
            if isinstance(cache_val, list):                                       # :1917
                converted_generations = self._convert_cached_generations(cache_val)
                self._replay_v2_events_for_cache_hit(converted_generations, run_manager=run_manager, **kwargs)
                return ChatResult(generations=converted_generations)              # :1924  ③
        elif self.cache is None:
            pass
        else:
            msg = "Asked to cache, but no cache found at `langchain.cache`."
            raise ValueError(msg)                                                 # :1929

    # Apply the rate limiter after checking the cache, since
    # we usually don't want to rate limit cache lookups, but
    # we do want to rate limit API requests.
    if self.rate_limiter:                                                          # :1934  ④
        self.rate_limiter.acquire(blocking=True)

    if self._should_use_protocol_streaming(async_api=False, run_manager=run_manager, **kwargs):  # :1942  ⑤
        stream_accum = ChatModelStream(message_id=f"{LC_ID_PREFIX}-{run_manager.run_id}" if run_manager else None)
        ...
```

**逐段解读**：
- **①** 缓存选择三级：`self.cache` 为 BaseCache 实例直用；否则取 `globals.get_llm_cache()` 全局缓存（`set_llm_cache()` 设置）；`self.cache is not False` 才检查（None = 全局有则用）；
- **②** 缓存键两件套：`llm_string`（模型参数序列化）+ `prompt`——**先把消息 id 置 None 再 dumps**（:1907-1914），否则消息 id 每次生成不同导致永远 miss；
- **③** 命中即返回：转换遗留格式 → 重放 v2 事件（保证热缓存与冷调用事件流一致）→ 直接构造 ChatResult，**跳过限流与 API 调用**；
- **④** 限流器在缓存检查之后（注释 :1931-1933 明确：缓存查询不限流，API 请求才限流）——`acquire(blocking=True)` 阻塞等待令牌（见 §6.8）；
- **⑤** 起进入三分支执行策略（v2 协议事件 / v1 流式 / `_generate` 钩子），详见 §4.3——这是 partner 包 `_generate` 被调用的唯一入口。

### 6.3 `ensure_config`（runnables/config.py:255-308）—— 配置三层合并

**怎么实现**（关键逻辑节选）：① 构造默认值 `{tags: [], metadata: {}, callbacks: None, recursion_limit: 25, configurable: {}}`（:264-270）；② 若 ContextVar `var_child_runnable_config` 有 ambient 配置，逐键覆盖（**COPIABLE_KEYS 逐键 `.copy()`** 防共享可变状态，:271-281）；③ 显式 config 再覆盖（同样 copy + 过滤，只取 CONFIG_KEYS 白名单内键，:282-292）。两个特例收尾：**非白名单键不丢弃而是降级塞进 `configurable`**（:293-296——向后兼容 `invoke(x, {"foo": 1})` 旧式传参）；`configurable` 里的 `model`/`checkpoint_ns` 若是 str 且 metadata 无同名键则镜像进 `metadata`（:297-307——langgraph 检查点命名空间对 LangSmith 可见）。**副作用**：每次调用新建 dict；**调用方**遍布全库（base.py 所有 invoke/stream 骨架、retrievers、chat_models、prompts、callbacks.manager）。

### 6.4 `add_ai_message_chunks`（messages/ai.py:651-731）—— 流式增量合并

**怎么实现**（五步）：① content 走 `merge_content`（四情形状态机，base.py:366）；② 两个 additional_kwargs/response_metadata 走 `merge_dicts`（深度合并，类型门禁见 §4.11）；③ `tool_call_chunks` 走 `merge_lists` **按 index 对齐、str 字段直接拼接**——流式 JSON args `{"a":` + `1}` 能拼成完整 JSON 的机制（ai.py:673-686）；④ `usage_metadata` 逐对 `add_usage`（`_dict_int_op` 递归整数加法，utils/usage.py:7）；⑤ **id 择优**（ai.py:696-717）：提供商原生 id（不以 `lc_` 开头，rank 2 立即胜出）> `lc_run-*`（rank 1）> 其他 `lc_*`（rank 0）。任一输入 `chunk_position=="last"` 则传播（:719-721）。**副作用**：返回新实例不改输入；被流式聚合器反复调用（`chunk1 + chunk2 + ...`），`merge_message_runs` 间接复用。

### 6.5 `handle_event`（callbacks/manager.py:285-367）—— 回调分发的异常隔离

**怎么实现**（关键逻辑）：① 遍历 handlers 先查 ignore 条件（`getattr(handler, ignore_condition_name, False)`——**订阅过滤**）；② `getattr(handler, event_name)(*args, **kwargs)` 反射调用，返回 coroutine 收集进 `coros`；③ **三层异常处理**：`NotImplementedError` 且事件是 `on_chat_model_start` → 把 messages 经 `get_buffer_string` 转 prompt 后**递归调用自身**分发 `on_llm_start`（新旧 handler 兼容桥）；一般 Exception → `logger.warning` 吞掉，除非 `handler.raise_error`——**默认回调错误绝不污染业务调用**；④ coroutine 执行（:349-367）：探测当前线程是否有运行中事件循环——**有**（从协程里同步调用，直接提交会死锁）→ 把 coros 提交到全局共享 ThreadPoolExecutor（`_executor()` :2813-2826，10 worker + atexit 关闭）在工作线程的新 loop 执行；**无** → 直接逐 coroutine 执行（3.11+ 用 `asyncio.Runner` 排空 pending tasks）。**副作用**：异步 handler 异常无条件吞掉仅记日志（代码注释承认同步/异步不对称，:370-375）。

### 6.6 `Reviver.__call__`（load/load.py:506-566）—— 白名单反序列化

**怎么实现**：① `mapping_key = tuple(value["id"])` 不在 `self.allowed_class_paths` 集合 → `ValueError`，**在任何 import 发生之前**；② 命中映射表键则重定向 `import_dir, name`（旧路径→新路径）；③ 命名空间校验：`namespace[0]` 必须在 15 个官方前缀内，重定向后的 import_dir 首段**再次校验**（:544-546，防映射表把路径引向白名单外）；④ `init_validator(class_path, kwargs)`（默认封禁 `template_format="jinja2"`——jinja2 可执行任意代码，且**故意不看 class_path** 保持 future-proof）；⑤ `importlib.import_module` → getattr → **必须 `issubclass(cls, Serializable)`**（最终防线）→ `cls(**kwargs)`。配合 `_validation.py` 的 `__lc_escaped__` 转义（序列化侧把含 `'lc'` 键的用户 dict 包裹，反序列化侧**在递归之前**解包返回），构成四层纵深防护（完整威胁模型见 load.py:14-68）。

### 6.7 `maximal_marginal_relevance`（vectorstores/utils.py:112-163）—— MMR 算法

**怎么实现**：① 边界处理 + 一维查询向量扩为 `(1, d)`；② **种子选择**：`similarity_to_query = _cosine_similarity(query_embedding, embedding_list)[0]` 一次算出查询对全部候选相似度，`most_similar = int(np.argmax(...))`——第一个入选者永远是与查询最相似者；③ **贪心主循环**：每轮 `similarity_to_selected = _cosine_similarity(embedding_list, selected)` 算候选×已选矩阵，纯 Python 遍历计算 `equation_score = lambda_mult * query_score - (1 - lambda_mult) * redundant_score`，其中 `redundant_score = max(similarity_to_selected[i])`（与最相近已选者的相似度 = 最大冗余度），取最高分者入列并追加进 selected 矩阵。lambda_mult=1 退化为纯相似度 top-k，=0 纯最大多样性。复杂度 k 轮 × (N×|selected|) 矩阵——候选规模是上游 fetch_k（默认 20）而非全库，开销可控。纯函数无副作用。

### 6.8 `InMemoryRateLimiter._consume`（rate_limiters.py:163-193）—— 惰性补币式令牌桶

```python
with self._consume_lock:                                # :163  ①
    now = time.monotonic()                              # :172  ②
    if self.last is None:
        self.last = now                                 # :175  ③
    elapsed = now - self.last
    if elapsed * self.requests_per_second >= 1:         # :180  ④
        self.available_tokens += elapsed * self.requests_per_second
        self.last = now
    self.available_tokens = min(self.available_tokens, self.max_bucket_size)  # :186  ⑤
    if self.available_tokens >= 1:
        self.available_tokens -= 1                      # :189  ⑥
        return True
    return False
```

**逐段解读**：① `threading.Lock` 串行化（无后台线程）；② 单调时钟免受系统时间回拨；③ **首次调用不补币**（last 为 None 只记录时间戳）——防"构造后立即爆发"；④ **攒满 1 个令牌才结算**：小额 elapsed 不足一个令牌时不结算也不推进 last（下次连本带利累积）；⑤ 桶容量封顶突发额度；⑥ 够 1 令牌即扣减放行。`acquire(blocking=True)` 是轮询等待 `while not self._consume(): time.sleep(check_every_n_seconds)`（:215-218）；异步版对称用 `asyncio.sleep`。**局限**（docstring 注明）：进程内不跨进程；按请求数不限 token；每次固定消耗 1 令牌。

---

## 7. 端到端调用链分析

### 7.1 场景 A：同步 RAG 检索问答链（典型业务主链路）

场景定义：`chain = {"context": retriever, "question": RunnablePassthrough()} | prompt | model | StrOutputParser()`，用户执行 `chain.invoke("What is MMR?")`。

```
文件级调用链（→ 为调用，⇒ 为返回）：

[runnables/base.py] RunnableSequence.invoke (:3434)
 ├─ [runnables/config.py] ensure_config (:255) · get_callback_manager_for_config (:563)
 │    └─ [callbacks/manager.py] CallbackManager.configure (:1682) → _configure (:2390)
 │         ├─ 读 LANGCHAIN_TRACING_V2 等 env → 注入 LangChainTracer（:2524-2550）
 │         └─ ⇒ run_manager = on_chain_start(...)  [tracers/core.py:_create_chain_run 挂 Run 节点]
 ├─ step1 [runnables/passthrough.py] RunnableAssign.invoke (:484)
 │    └─ mapper = RunnableParallel{context: retriever, question: RunnablePassthrough}
 │         ├─ [runnables/base.py:4143] executor.submit 并发两路
 │         ├─ context 路：[retrievers.py] BaseRetriever.invoke (:178)
 │         │    ├─ on_retriever_start ⇒ run_manager
 │         │    ├─ [vectorstores/base.py] VectorStoreRetriever._get_relevant_documents (:1039)
 │         │    │    └─ vectorstore.similarity_search(query, k)
 │         │    │         └─ [vectorstores/in_memory.py:291] 余弦 top-k（或 partner 实现）
 │         │    └─ on_retriever_end ⇒ list[Document]
 │         └─ question 路：RunnablePassthrough.invoke 恒等返回
 │         ⇒ {"context": [Document...], "question": "What is MMR?"}
 ├─ step2 [prompts/chat.py] ChatPromptTemplate.invoke（继承 base.py:209）
 │    ├─ _validate_input（base.py:161）→ format_messages (:1174)
 │    │    └─ MessagesPlaceholder.format_messages (:164) → convert_to_messages (:187)
 │    │    └─ PromptTemplate.format (prompt.py:191) → DEFAULT_FORMATTER_MAPPING["f-string"]
 │    ⇒ ChatPromptValue(messages=[SystemMessage, HumanMessage])
 ├─ step3 [language_models/chat_models.py] BaseChatModel.invoke (:475)
 │    └─ generate_prompt (:1869) → generate (:1592)
 │         ├─ on_chat_model_start (:1668) ⇒ CallbackManagerForLLMRun
 │         ├─ _generate_with_cache (:1892)   ← 见 §6.2 逐段解读
 │         │    ├─ 缓存 miss → rate_limiter.acquire
 │         │    └─ ★ self._generate(messages, ...) ←【partner 包钩子，如 langchain-openai】
 │         │         ⇒ ChatResult(generations=[ChatGeneration(message=AIMessage)])
 │         ├─ on_llm_end(LLMResult) (:1708)
 │         └─ ⇒ AIMessage（含 tool_calls/usage_metadata）
 ├─ step4 [output_parsers/string.py] StrOutputParser.parse → message.text
 └─ on_chain_end(final_output) ⇒ "MMR is ..." 字符串
      └─ 根 Run 结束 → [tracers/langchain.py] _persist_run → run.patch() → LangSmith
```

### 7.2 场景 B：流式输出 + 事件流（`astream_events(version="v2")`）

```
用户协程                                后台 task                       回调线程/事件循环
─────────                              ─────────                       ────────────────
chain.astream_events(input, v2)
└─ [runnables/base.py:1616]
   _astream_events_v1_v2
   └─ [tracers/event_stream.py:1004]
      _astream_events_implementation_v2
      ├─ handler = _AstreamEventsCallbackHandler()
      ├─ config["callbacks"] += handler            (:1034-1048)
      ├─ task = create_task(consume_astream)  ────► astream 消费根输出
      │   （生成器流水线：                     │    └─ RunnableSequence._transform
      │    RunnableSequence._transform          │       模型 _stream 逐 chunk
      │    :3768 套接各步生成器）               │          ├─ on_llm_new_token ──► handler
      │                                         │          └─ tap_output_aiter ─► handler
      │                                         │    finally: send_stream.aclose()
      │                                              （投递终止哨兵）
      └─ async for event in receive_stream:  ◄── _MemoryStream（call_soon_threadsafe
          yield event                             跨循环投递，memory_stream.py:158）
          （每个 event: on_chat_model_start /
           on_chat_model_stream / on_chat_model_end /
           on_chain_start / on_chain_stream / on_chain_end，
           含 run_id、parent_ids、tags、metadata）
```

**关键机制**：handler 与消费者经 `_MemoryStream`（绑定读者事件循环的 asyncio.Queue + `call_soon_threadsafe` 写入）解耦——即使回调跑在后台线程的 loop，事件也能安全回到消费者 loop；`parent_map` 独立于 run_map 维护（父 run 的 end 回调可能先于子到达）；`is_tapped` 集合保证 token 路径与 tap 路径不重复发事件。

### 7.3 场景 C：`index()` 增量索引（RAG 数据面写入链路）

见 §4.6 的七步流程（分片 → 哈希定 ID → 批内去重 → RecordManager.exists 分拣 → 写向量库 → 回写账本 → 清理旧版本）。核心时序：**先写数据侧、后写账本侧**（悲观假设向量库写可能失败：账本没有而库有最多重复写，反过来会误删）。

---

## 8. 横切机制说明

### 8.1 错误处理与异常体系

- **位置**：`exceptions.py`（全部公共异常）+ 各模块内嵌错误处理。
- **结构**：`LangChainException`（:7）根 → 三支：`TracerException`、`OutputParserException`（:15，双继承 ValueError，`send_to_llm=True` 时允许纠错上下文回传 agent 自愈）、`ModelError`（:68）及其 8 个 HTTP 语义子类（401/403/400/404/429/5xx/连接/超时），类属性 `is_retryable` 标记同请求重试是否可能成功（RateLimit/API/Connection/Timeout 为 True）——供 `RunnableRetry` 的 `retry_if_exception_type` 消费。`ContextOverflowError`（:123）输入超上下文窗口。`create_message`（:143）给消息追加 `docs.langchain.com/.../errors/{code}` 排查链接。
- **回调异常隔离**：`handle_event` 默认吞掉 handler 异常仅 warning，除非 `handler.raise_error`（manager.py:340-348）——观测系统故障不拖垮业务。
- **工具错误三元处理**：`BaseTool.run` 区分 ValidationError / ToolException（可吞噬为 ToolMessage 观察值）/ 普通 Exception（重抛），见 §4.6。
- **模型错误可观测化**：`_generate_response_from_error`（chat_models.py:112）从异常 response 提取元数据组装进 on_llm_error 载荷。

### 8.2 日志与追踪体系

- **标准 logging**：各模块 `logging.getLogger(__name__)`，无集中配置——库代码只 warning 级（如 `log_error_once` 按异常类型去重）。
- **verbose/debug 全局开关**：`globals.py` 的 `set_debug/set_verbose` → `_configure` 装配线注入 ConsoleCallbackHandler/StdOutCallbackHandler（manager.py:2492-2550）。
- **LangSmith 追踪（核心）**：环境变量（`LANGCHAIN_TRACING_V2`/`LANGSMITH_TRACING`/`LANGCHAIN_API_KEY`/`LANGCHAIN_PROJECT`）或 `tracing_v2_enabled()` ContextVar 开启 → 每次 invoke 的 `configure()` 注入 `LangChainTracer` → 三段式构建 Run 树（dotted_order 排序）→ POST-then-PATCH 上报（§4.7）。**异步收尾保障**：`shielded` 装饰器 + `wait_for_all_tracers()` flush。
- **本地消费**：`collect_runs()`（内存收集）、`get_usage_metadata_callback`（token 统计）、`astream_events`/`astream_log`（事件/日志流）。

### 8.3 配置管理（多环境）

- **调用级**：`RunnableConfig`（8 键）三层合并 + ContextVar 传播（§6.3）——没有"多环境配置文件"，这是 SDK 库不是服务。
- **运行时可配置**：`configurable_fields`（字段替换，每次 invoke 重建实例）/ `configurable_alternatives`（模型切换，工厂惰性构造）——`config_specs` 沿组合子层层上聚供 UI 渲染。
- **环境变量**：`get_from_env`（utils/env.py:60，三级回退）；`from_env`/`secret_from_env`（utils/utils.py:368/442，pydantic default_factory 闭包版，secret 包 SecretStr）。
- **测试环境隔离**：Makefile test 目标强制 `-u` 清空全部 LangSmith 环境变量（Makefile:14-19）。

### 8.4 权限 / 安全控制

- **反序列化安全**（load/，§4.8 四层防护）：白名单 + 命名空间 + jinja2 封禁 + 转义。
- **SSRF 防护**（_security/，§4.11）：15+8 保留网段黑名单、云元数据 IP、IPv6 内嵌 IPv4 提取、DNS 全量 IP 校验、httpx Transport IP pinning、重定向每跳重校验。**当前 core 内无生产调用方**（为 community 包预留），推断为逐步推广的基础设施。
- **模板注入**：jinja2 沙箱 best-effort（明确警告不可信模板风险）；mustache `_get_key` 只许穿越 Mapping/list（防对象属性穿越）；`loads` 封禁 jinja2 template_format。
- **Secret 处理**：`lc_secrets` 协议（to_json 替换为环境变量名标记，值不落盘）；`convert_to_secret_str`；`_filter_invocation_params_for_tracing` 剔除大字段防追踪载荷泄漏。

### 8.5 并发 / 异步处理模式

- **双轨制**：sync/async 成对 API；async 默认 `run_in_executor` 委托 sync（`StopIteration`→`RuntimeError` 转换）；`ContextThreadPoolExecutor` 让 ContextVar 跨线程传播。
- **并发原语**：sync 用 `executor.map`/`wait(FIRST_COMPLETED)` 竞速（RunnableParallel._transform）；async 用 `gather_with_concurrency`（Semaphore 门控 max_concurrency）、`gated_coro`、`asyncio.wait`。
- **流式**：`safetee/atee` 分流（线程/协程锁保护的 tee）、`tap_output_iter/aiter` 输出嗅探、生成器惰性流水线（Sequence._transform 套接）。
- **取消安全**：`shielded`（end/error 回调不被消费流取消打断）；`aclosing`/finally `aclose()`（上游迭代器关闭防泄漏）；`AsyncChatModelStream.aclose` 区分两种 CancelledError。
- **跨循环通信**：`_MemoryStream` 的 `call_soon_threadsafe`。

### 8.6 缓存

- **LLM 响应缓存**：`BaseCache`/`InMemoryCache`（caches.py）+ 全局 `set_llm_cache`；键 = `(dumps(去 id 消息), llm_string)`；命中清零 total_cost、重放 v2 事件（§6.2）。
- **内部微缓存**：`tool_call_schema_memo`（BaseTool）、`_default_class_paths_cache`（loads 白名单）、`lru_cache` 于 `get_function_nonlocals`/`_get_langchain_version`/`ModelProfile`、`_create_root_model_cached`、弱引用枚举缓存 `_enums_for_spec`（configurable.py:466-471）。

### 8.7 定时任务 / 后台任务

- 无定时任务框架。后台任务形态：`_executor()` 全局共享 ThreadPoolExecutor（atexit 关闭）；`create_base_retry_decorator` 的 `_background_tasks` fire-and-forget 集合（llms.py:108-111）；`EvaluatorCallbackHandler` 的 weakref.WeakSet futures；`_get_or_create_loop` 用 `weakref.finalize` 绑定 handler 生命周期关闭事件循环。

## 9. 外部依赖说明

运行时依赖 10 个（pyproject.toml:26-37）：

| 依赖名 | 版本约束 | 用途 | 在哪些文件中使用 | 替代/关键实现 |
|---|---|---|---|---|
| pydantic | ≥2.7.4,<3 | 全部数据模型基座（BaseMessage/BaseTool/RunnableSerializable...） | 几乎所有模块；utils/pydantic.py 是 v1/v2 兼容层 | 自 v1 双轨：`pydantic.v1` 命名空间仍一等公民 |
| langsmith | ≥0.3.45,<1 | Run schema（RunTree）、Client 批量上报、tracing context | tracers/langchain.py、schemas.py、context.py、callbacks/manager.py、runnables/config.py（延迟导入省启动时间） | Run = RunTree 直接别名（schemas.py:10） |
| httpx | ≥0.23,<1 | HTTP 客户端 | graph_mermaid.py（API 渲染）、_security/_transport.py（安全 Transport）、utils/_gateway.py | Transport 子类是 SSRF pinning 的钩子点 |
| tenacity | ≥8.1,≠8.4,<10 | 重试 | runnables/retry.py、language_models/llms.py、tracers/langchain.py | 指数抖动退避 wait_exponential_jitter |
| jsonpatch | ≥1.33,<2 | astream_log 的增量补丁 | tracers/log_stream.py、output_parsers（_diff）、runnables/base.py | RunLogPatch 补丁叠加代数 |
| PyYAML | ≥5.3,<7 | 图渲染 frontmatter、load_prompt | graph_mermaid.py、prompts/loading.py | — |
| typing-extensions | ≥4.7,<5 | 新类型特性 backport | 多处（Override/Self 等） | — |
| packaging | ≥23.2 | 版本比较 | utils/utils.py（check_package_version）、utils/pydantic.py | — |
| uuid-utils | ≥0.12,<1 | uuid7（时间有序，tracing 排序） | utils/uuid.py、callbacks/manager.py | Python stdlib 无 uuid7 |
| langchain-protocol | ≥0.0.17 | v2 协议事件类型（MessagesData 等） | language_models/_compat_bridge.py、chat_model_stream.py、tracers/_streaming.py | v2/v3 流式的共享契约 |
| （可选）numpy / grandalf / pygraphviz / jinja2 / simsimd / defusedxml / filetype | dev-group 或运行时探测 | 向量计算/图渲染/模板/解析加速 | vectorstores/utils.py、graph_*.py、prompts/string.py、output_parsers/xml.py、block_translators/google_genai.py | 全部优雅降级（ImportError 提示安装） |

## 10. 新人上手路径

### 10.1 建议的文件阅读顺序（由浅入深）

1. **入口与横切基础**（半天）：`__init__.py` → `version.py` → `globals.py` → `exceptions.py` → `_import_utils.py`（理解惰性导入模式——全包 `__init__.py` 都用它）；
2. **执行协议**（一天，最重要）：`runnables/config.py`（先懂配置传播）→ `runnables/base.py` 的 `Runnable` 类骨架（invoke/batch/stream/transform 默认实现 + 四件套回调辅助）→ `RunnableSequence`/`RunnableParallel` → `coerce_to_runnable`；
3. **数据契约**（半天）：`messages/content.py`（纯 TypedDict，无逻辑）→ `messages/base.py` → `messages/ai.py`（重点 chunk 合并）→ `outputs/` 全部（小文件）；
4. **模型层**（一天）：`language_models/base.py` → `chat_models.py` 的 generate/_generate_with_cache/_should_stream 三大块 → `fake_chat_models.py`（最简单的实现示例，理解钩子怎么填）；
5. **业务两侧**（半天）：`prompts/string.py` → `prompts/chat.py`（from_messages）→ `output_parsers/base.py` + `json.py`；
6. **可观测性**（半天）：`callbacks/manager.py` 的 handle_event 与 _configure → `tracers/core.py` 的 _start_trace → `tracers/langchain.py`；
7. **其余按需**：tools/indexing/load/vectorstores/utils 在做对应需求时再深入。

### 10.2 常见修改需求的切入点

| 需求 | 切入位置 |
|---|---|
| 接入新模型提供商 | 继承 `BaseChatModel`（chat_models.py:284），实现 `_generate`（必需）+ `_stream`/`_agenerate`/`_astream`（可选）；参考 `fake_chat_models.py`；`_get_ls_params` 记得重写 |
| 加一个自定义链步骤 | 函数 → `RunnableLambda`（自动）；需要流式感知 → `RunnableGenerator`；整体新组件 → 继承 `RunnableSerializable` 并复用 `_call_with_config`/`_transform_stream_with_config` 骨架 |
| 改提示词模板行为 | `prompts/string.py` 的 `DEFAULT_FORMATTER_MAPPING`（新增 template_format）或 `get_template_variables`（变量提取规则） |
| 加输出解析器 | 继承 `BaseOutputParser` 实现 `parse`；需要流式 → 继承 `BaseCumulativeTransformOutputParser` |
| 加一个工具 | `@tool` 装饰器（convert.py:77）；复杂场景继承 `BaseTool` 或 `StructuredTool.from_function` |
| 改消息格式/支持新内容块 | `messages/content.py` 加 TypedDict + `create_*` 工厂 + 更新 `KNOWN_BLOCK_TYPES`；跨提供商互译在 `block_translators/` 注册 |
| 改缓存行为 | 继承 `BaseCache`（caches.py）实现 lookup/update/clear，`set_llm_cache` 全局生效 |
| 加回调/自定义观测 | 继承 `BaseCallbackHandler`（callbacks/base.py:496）；需要流式事件 → `astream_events`；需要 LangSmith 式树 → 继承 `BaseTracer` |
| 改限流策略 | 继承 `BaseRateLimiter`（rate_limiters.py:11），模型构造时传 `rate_limiter=` |
| 加新的可反序列化类 | 继承 `Serializable`，重写 `is_lc_serializable()→True` + `get_lc_namespace()`；路径变化时在 `load/mapping.py` 加映射 |

### 10.3 隐性约定与易踩坑点

1. **chunk 必须可加**：流式输出的类型需支持 `+`（str/list/dict/AddableDict）；`TypeError` 时框架退化为"只保留末块"——**静默丢数据**，自定义类型务必实现 `__add__`；
2. **`transform` 默认缓冲整个输入**：RunnableLambda 会让链式流式退化（上游全部完成才开始输出），需要流式透传用 `RunnableGenerator` 或覆写 transform；
3. **config 是"活"的**：`ensure_config` 会从 ContextVar 捞 ambient 配置——测试中没传 config 却出现了意外回调/tracing，多半是上下文泄漏；`patch_config` 换 callbacks 会清 run_name/run_id；
4. **`__init__.py` 全部惰性**：新文件加入后必须同步更新 `_dynamic_imports` 映射表，否则 import 报 AttributeError（`make check_imports` 会抓）；
5. **禁相对导入**：ruff `ban-relative-imports = "all"`——全库必须绝对导入；
6. **钩子签名兼容**：新钩子加参数时用 `_signature_parameters` 探测（参考 `_generate` 的 run_manager 处理）——第三方子类签名千奇百怪；
7. **能力探测用函数同一性**：判断子类是否实现某方法用 `type(self)._stream is BaseChatModel._stream`，不要用 hasattr（基类方法也"存在"）；
8. **回调里别抛异常**：默认会被吞掉只留日志；确需失败请设 `raise_error = True`；
9. **`chat_history.py` 已整体弃用**（2.0 移除）——新代码不要用，短期记忆走 LangGraph persistence 或 messages 三件套（filter/merge/trim）；
10. **测试禁网**：`--disable-socket`（Makefile:20），写单测不要依赖外网；`blockbuster` 检测事件循环内阻塞调用——**不要在 async 路径做文件 IO/同步网络**；
11. **每个公开方法 sync+async 成对**：只写 sync 也能跑（executor 委托），但性能敏感路径（模型 IO）应提供原生 async；
12. **run_in_executor 的 StopIteration 陷阱**：包装的同步函数抛 StopIteration 会被转成 RuntimeError（config.py:696-703）——生成器要显式收敛。

---

## 收尾：全报告总目录 · 完成度自检 · 存疑清单

### A. 全报告总目录（章节 ↔ 批次对照）

| 章节 | 内容 | 所在批次 |
|---|---|---|
| 分批计划 + 术语表 | 批次表、14 个核心术语 | 批次 1 |
| 第 1 章 | 项目概述（用途/技术栈/运行/范围界定） | 批次 1 |
| 第 2 章 | 整体架构（分层图/依赖图/核心数据流） | 批次 1 |
| 第 3 章 | 目录结构详解 | 批次 1 |
| §4.1~4.2 | runnables 协议核心与组合子扩展（16 文件） | 批次 2 |
| §4.3~4.4 | language_models/outputs、messages/block_translators（36 文件） | 批次 3 |
| §4.5~4.6 | prompts/output_parsers/prompt_values、tools/documents/document_loaders/indexing/example_selectors（48 文件） | 批次 4 |
| §4.7~4.11 | callbacks/tracers、load、vectorstores/embeddings、根目录杂项、utils/_api/_security（82 文件） | 批次 5 |
| 第 5 章 | 文件清单总表（182 文件全覆盖） | 批次 6 |
| 第 6 章 | 关键函数深度解析（8 个，带行号代码+逐段解读） | 批次 6 |
| 第 7 章 | 端到端调用链（3 场景 + ASCII 时序） | 批次 6 |
| 第 8~10 章 | 横切机制/外部依赖/新人上手路径 | 批次 6 |

### B. 完成度自检表

| 检查项 | 结果 |
|---|---|
| 生产 .py 文件总数（排除 tests） | 182（PowerShell 递归统计，与 §5 各分表合计一致：16+16+20+24+24+22+13+47=182） |
| 文件清单总表覆盖 | ✅ 182/182，逐文件列出职责/导出/依赖/详解索引 |
| 函数级深度解析覆盖 | ✅ 21 个模块组全部在 §4 给出关键类/函数解析；§6 对 8 个核心函数给出带代码片段的逐段解读 |
| 行号引用 | ✅ 全文 400+ 处 `文件:行号` 引用；§6 两段代码已与源文件逐行核对 |
| 排除范围遵守 | ✅ tests/、scripts/（仅概述）、partners 等其他 libs、CI/IDE 配置未纳入分析 |
| 构建配置 | ✅ pyproject.toml/Makefile/check_imports.py 已说明（§1.3） |

未逐行精读但已覆盖职责与关键导出的文件：体积较小的桥接/转发类文件（`google_vertexai.py`、`chat_sessions.py`、`cross_encoders.py` 等 10 余个），其职责已在 §4/§5 说明，符合"文件级说明职责"的要求。

### C. 存疑与待确认清单

1. **`_security` 的定位（推断）**：core 包内无生产代码调用该模块（仅测试引用）。推断为预留给 langchain-community 文档加载器等外发 HTTP 场景的基础设施，未来可能被更多集成采用；具体推广计划代码中无说明。
2. **`few_shot_with_templates.py:97-101` 运算符优先级疑似缺陷**：`set(suffix) | set(prefix) - set(partials)` 因 `-` 优先级高于 `|`，实际语义是 `suffix | (prefix - partials)`——suffix 中的 partial 变量会残留在推导的 input_variables 里。是刻意为之还是 bug，代码无注释说明（推断为疏忽）。
3. **`indexing/api.py` 的 sha1 分支不对称**：`_calculate_hash`（:157）的 sha1 分支会做一次 uuid5 包装而其它哈希算法直接 hexdigest。推断与历史版本兼容有关（旧版索引 ID 需保持稳定），无注释确认。
4. **`_compat_bridge.py` 无 index 块的混流风险**：源码 :165-184 长注释自认"无 index 的块按 `("__lc_no_index__", type, 位置)` 分桶，混流可能错并"——已知限制而非缺陷，但使用方需注意。
5. **v3 `stream_events` 的支持范围**：`Runnable.astream_events(version="v3")` 基类抛 NotImplementedError（base.py:1601-1614），仅 `BaseChatModel` 及外部 langgraph 实现支持；报告中 v3 相关描述基于 `chat_model_stream.py` 的实现，未覆盖 langgraph 侧（超出本包范围）。
6. **行号时效性**：本报告全部行号基于 1.6.9 源码快照核对；上游任何补丁都会使行号漂移，引用时请以函数名+文件为准。

---

*报告完 · 生成于 2026-10-11 · 分析范围：langchain-core 1.6.9（libs/core/langchain_core，182 个生产源文件）*
