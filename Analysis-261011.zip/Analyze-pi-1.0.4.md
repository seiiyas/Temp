# pi 1.0.4（pi-mono）生产项目代码分析报告

> 分析对象：`pi-1.0.4/`（npm 发布名 `@earendil-works/pi-coding-agent`，monorepo 名 `pi-monorepo`）
> 报告日期：2026-10-07 ｜ 分析方式：全量源码静态阅读（只读，未执行任何修改）
> 纳入范围：14 个子包 `packages/*/src` 下全部生产源码（约 715 个 TypeScript 文件，详见第 5 章清单与统计口径说明）
> 排除范围：`test/`、`examples/`、`docs/`、`dist/`、`*.test.ts`、锁文件、CI/IDE 配置、生成代码 `packages/ai/src/models.generated.ts`（仅说明来源，不逐行分析）

---

## 交付说明与"批次"对照

本任务触发分批条件（生产源文件 715 个 ≫ 40、模块数 14 个 ＞ 6）。由于用户要求将报告写入单一文件 `Analyze-pi-1.0.4.md`，"分批"以**文件内部分批撰写**的方式执行，全部批次已在本文件内完成交付。原批次划分及最终状态如下（对应正文章节）：

| 批次 | 覆盖模块/目录 | 覆盖章节 | 涉及文件数 | 状态 |
|------|--------------|----------|-----------|------|
| 1 | 全局总览 | 第 1~3 章 + 本计划 | 全部（清单层） | 已完成 |
| 2 | 基础层：tui、codemode、chord、protocol、client、server、env、telemetry、mcp | 第 4 章（4.1~4.9） | ≈150 | 已完成 |
| 3 | 中间层：agent、ai（核心+api+providers+auth）、durable | 第 4 章（4.10~4.12） | ≈290 | 已完成 |
| 4 | 业务层：coding-agent（core/modes/cli/tools/extensions/utils/experimental） | 第 4 章（4.13）、第 5 章 | ≈300 | 已完成 |
| 5 | 入口与横切 | 第 6~10 章 + 总目录 + 自检表 + 存疑清单 | — | 已完成 |

章节编号全局连续；每章内引用其他章内容时使用「见第 X 章」。

---

## 0. 术语表（首次出现概念，全文统一口径）

| 术语 | 解释 |
|------|------|
| **pi** | 本项目：一个极简、可扩展的终端 AI 编程助手（coding agent CLI），类 Claude Code / Codex CLI 的开源实现，由 badlogic（Mario Zechner）主导、earendil-works 维护 |
| **monorepo / 包（package）** | 仓库根 `package.json` 以 npm workspaces 管理 14 个子包；构建顺序按依赖方向串行（根 package.json:15） |
| **Provider（提供商）** | 一个 LLM 服务接入单元（如 anthropic、openai、google），由 `pi-ai` 的工厂函数构造，含目录（getModels）+ 鉴权（auth）+ 流式调用（stream）三要素 |
| **API 方言（dialect）** | 厂商线协议种类，如 `anthropic-messages`、`openai-completions`、`openai-responses`、`google-generative-ai`、`bedrock-converse-stream` 等 10 种 chat + 1 种图像 + 3 种分类（pi-ai/src/types.ts:17-35） |
| **StreamEvent / AssistantMessageEvent** | pi 内部统一的流式事件协议，12 种（start、text_start/delta/end、thinking_start/delta/end、toolcall_start/delta/end、done、error），是所有方言适配器的输出公约（pi-ai/src/types.ts:769-785） |
| **TranscriptContext** | 经 `normalizeContext` 折叠、带 brand symbol 的"正规化上下文"（systemPrompt+tools+messages），唯一合法的请求输入形态（pi-ai/src/types.ts:740-748） |
| **Agent** | `pi-agent-core` 的有状态执行器：持有 transcript（消息树）、工具表，驱动"请求→流式→工具调用→下一轮"循环 |
| **AgentSession** | coding-agent 的会话核心（core/agent-session.ts），在 Agent 之上叠加：持久化、系统提示、压缩、重试、扩展钩子、bash 执行 |
| **AgentSessionRuntime** | 会话宿主（core/agent-session-runtime.ts），持有当前 AgentSession + 服务，实现 new/fork/switch/import 热替换 |
| **SessionManager / JSONL 会话树** | 会话持久化格式：每会话一个 `.jsonl` 文件，首行 SessionHeader，后续条目（消息/模型切换/压缩/分支摘要等）以 `id/parentId` 构成树 |
| **compaction（压缩）** | 上下文超限时把旧对话替换为结构化摘要 checkpoint 的机制，保留尾部近期消息 |
| **steer / followUp** | 流式响应期间插队的新输入（steer，立即打断融合）与排队等待下一轮的输入（followUp） |
| **扩展（extension）** | 运行时加载的 TS/JS 插件（jiti 转译），通过 `pi: ExtensionAPI` 注册工具/命令/事件处理器；内置扩展与第三方扩展同权 |
| **skill** | 遵循 agentskills.io 规范的 `SKILL.md` 目录，作为可发现能力注入系统提示（`/skill:name` 或模型自主调用） |
| **MCP** | Model Context Protocol：接入外部工具服务器的开放协议；pi 自实现客户端（packages/mcp），不含官方 SDK |
| **codemode** | 让模型写 JS 脚本在 QuickJS WASM 沙箱内批量编排调用其他工具的模式（脚本唯一能力是调用注入的工具） |
| **durable** | "崩溃可恢复"运行时（packages/durable）：SQLite/JSONL 落盘的任务图 + 会话 + 文档，崩溃后从检查点续跑；目前用于 experimental 原型 |
| **chord / facet / replicated state** | chord 是应用组合运行时（服务定位 + RPC + 插件打包）；facet 是声明 use/observe/provide 的组合单元；replicated state 是基于 JSON 操作日志（Op）的复制状态 |
| **Radius** | earendil 的托管网关服务（radius.pi.dev）：可作为 LLM Provider（pi-messages 协议）、bug 报告上传端点、远程会话中继 |
| **faux provider** | pi-ai 内置的脚本化假 Provider，测试/评测用（providers/faux.ts） |
| **token / usage** | LLM 用量结构：input/output/cacheRead/cacheWrite/reasoning tokens + 折算成本 cost |

---

# 第 1 章 项目概述

## 1.1 项目用途与业务背景

pi 是一个**终端 AI 编程助手（coding agent）**：用户在项目目录运行 `pi`，进入交互式 TUI，用自然语言下达编程任务；agent 通过内置工具（读/写/编辑文件、bash/grep/find 等）与 LLM 的多轮工具调用循环完成任务。其产品理念（README.md:15-21）是"minimal, extensible agent harness that you can make your own"——刻意**不内置**子代理、计划模式、权限系统等重功能，而提供四种扩展机制（扩展 extensions、技能 skills、提示模板 prompt templates、主题 themes），可打包为 npm/git 分发的 Pi 包。

从代码与接口命名可归纳的完整业务面：

1. **交互式 TUI 编程会话**（默认模式）：流式 Markdown 渲染、思考过程折叠、工具调用卡片、diff 预览、语法高亮、图片支持（Kitty/iTerm2 协议）、会话树导航与分支 fork。
2. **非交互自动化**：`pi -p "..."`（print 模式，stdout 纯文本）、`--mode json`（JSON 事件流）、`--mode rpc`（JSON-Lines RPC，供程序控制，SDK 的 `RpcClient` 即 spawn 此模式）。
3. **多 Provider 统一接入**：42 家内置厂商（Anthropic/OpenAI/Google/Bedrock/Vertex/OpenRouter/xAI/智谱 GLM/月之暗面/MiniMax/阿里 Qwen/小米……），API key 与 OAuth 订阅登录（Claude Pro/Max、ChatGPT、Copilot、Grok 等）皆可。
4. **包管理**：`pi install <npm-or-git-package>` 安装第三方扩展/技能/主题/提示模板包；`pi update` 自更新。
5. **实验性 C/S 架构**（`PI_EXPERIMENTAL=1`）：常驻 server 进程 + 每会话 worker 进程（基于 durable/SQLite）+ 多客户端（含 Radius WebSocket 远程接入）——下一代架构的预演，不进发布产物。
6. **周边**：`pi auth`、`pi config`、`pi mcp`、`pi experimental server|client`、bug 报告打包上传、会话导出 HTML/JSONL、/share 分享。

供应链安全是明确的产品要求（README.md:126-138）：依赖精确锁版、`--ignore-scripts` 安装、install-lock 清单、生命周期脚本白名单。

## 1.2 技术栈清单

| 项 | 内容 | 依据 |
|----|------|------|
| 语言 | TypeScript（strict；**仅可擦除语法**，Node 原生 strip-types 运行，无 enum/namespace/参数属性） | AGENTS.md:24、tsconfig.base.json |
| 运行时 | Node.js ≥ 22.19（依赖 `node:sqlite`、`Promise.withResolvers` 等）；亦可编译为 **Bun 单文件二进制**（`build:binary`） | 根 package.json:66、packages/coding-agent/package.json:43 |
| 包管理 | npm workspaces（14 包）+ 精确锁版策略 | 根 package.json:5-12 |
| 构建 | 各包 `tsc`（dist/）+ coding-agent 额外 esbuild bundle（`dist/bundle/cli.js`）；类型检查 TypeScript 7.0.2 | 根 package.json:15、scripts/build-coding-agent-bundle.mjs |
| 测试 | vitest（大多数包）、node:test（tui）、自研 conformance 套件（durable/telemetry 存储、env） | vitest.base.ts、AGENTS.md:34-36 |
| Lint/格式化 | Biome 2.3.5（biome.json） | 根 package.json:58 |
| 关键运行时依赖 | `undici`（HTTP 调度/代理/WebSocket）、`jiti`（扩展 TS 转译加载）、`typebox`（schema 校验）、`@anthropic-ai/sdk`/`openai`/`@google/genai`/`@aws-sdk/*`（各方言 SDK，全部懒加载）、`quickjs-wasi`（codemode 沙箱）、`proper-lockfile`（跨进程文件锁）、`marked`（Markdown）、`diff`（edit-diff）、`esbuild`（chord 插件打包）、`semver`/`minimatch`/`yaml`/`hosted-git-info`、`@silvia-oddyer/photon-node`（WASM 图像处理）、`cross-spawn` | 各包 package.json |
| 原生模块 | pi-tui `native/`：三平台 NAPI 薄层（剪贴板文本/图像、Windows VT 输入、修饰键状态），随包分发 prebuilds | packages/tui/native、packages/tui/package.json:10-12 |
| 打包特殊处理 | Bun 编译版需要静态入口：`pi-ai/bedrock-provider`、`pi-ai/bun-oauth`（OAuth 流程静态注册）、codemode worker 独立 entry | packages/ai/src/bedrock-provider.ts:1-6、packages/coding-agent/src/bun/runtime-setup.ts:10-12 |

## 1.3 如何运行

**安装（终端用户）**：`curl -fsSL https://pi.dev/install.sh | sh`（Windows：`powershell -c "irm https://pi.dev/install.ps1 | iex"`），或 `npm install -g --ignore-scripts @earendil-works/pi-coding-agent`。

**开发（本仓库）**：

```bash
npm install --ignore-scripts   # 安装依赖（不跑生命周期脚本）
npm run build                  # 刷新模型数据 + 按依赖顺序构建全部 14 包
./pi-test.sh                   # 从源码运行 pi（node --import source-resolver 直跑 TS）
./test.sh                      # 测试（无 API key 时跳过 LLM 相关）
npm run check                  # biome + 依赖锁版检查 + tsc --noEmit + 入口图检查
```

**入口文件**：
- CLI bin：`packages/coding-agent/src/cli.ts` → `main()`（src/main.ts:573）；RPC bin：`src/rpc-entry.ts`。
- 开发态实验入口：`src/experimental/cli.ts`（经 `pi-test.sh` + `PI_EXPERIMENTAL=1` 使用，不进发布产物）。
- SDK 入口：`packages/coding-agent/src/index.ts`（`createAgentSession` 等编程 API）。

**环境配置**：
- 用户目录 `~/.pi/agent/`（`getAgentDir()`，core/config.ts:605）：`settings.json`（全局设置）、`auth.json`（凭据）、`sessions/`（会话 JSONL）、`skills/`、`prompts/`、`themes/`、`extensions/`、`trust.json`、`keybindings.json`、`packages/`（安装的 Pi 包）。
- 项目目录 `<cwd>/.pi/`：`settings.json`（需信任后才读）、`extensions/`、`skills/`、`prompts/`、`mcp.json`、`SYSTEM.md`、`APPEND_SYSTEM.md`。
- 关键环境变量：`PI_OFFLINE`（离线）、`PI_EXPERIMENTAL=1`（实验特性）、`PI_TIMING=1`（启动打点）、`PI_SESSION_ID/PI_MODEL` 等（bash 工具注入给子进程，core/tools/bash.ts:186-212）、各厂商 API key（`ANTHROPIC_API_KEY`、`OPENAI_API_KEY`…，见 pi-ai/src/env-api-keys.ts）。
- API key 三来源优先级（pi-ai/src/auth/resolve.ts:27-31）：**存储凭据（auth.json）独占 provider；环境变量仅在无存储凭据时兜底**；另有 `--api-key` 运行时覆盖层（不落盘，core/runtime-credentials.ts）。

---

# 第 2 章 整体架构

## 2.1 架构风格与分层

整体是**分层单体内核 + 多宿主模式 + （实验中的）多进程演化**架构。自底向上：

```
┌────────────────────────────────────────────────────────────────────────────┐
│ L5 宿主模式层  coding-agent/src/modes                                      │
│   interactive(TUI 全屏/常规) │ print/text │ print/json │ rpc(JSON-Lines)   │
│   + cli/（手写参数解析 + auth/config/mcp/install 子命令）                   │
├────────────────────────────────────────────────────────────────────────────┤
│ L4 会话与应用层 coding-agent/src/core（94 文件）                            │
│   AgentSession(3982 行会话核心) ─ AgentSessionRuntime(会话热替换宿主)        │
│   ├─ SessionManager(JSONL 会话树)  ├─ SettingsManager(双层设置)             │
│   ├─ ModelRuntime(模型/凭据/Provider 组合)  ├─ ResourceLoader(扩展/skills/  │
│   │   prompts/themes/上下文文件)   ├─ ExtensionRunner(事件分发)              │
│   ├─ 系统提示构建/压缩(compaction)/缓存保温(CacheWarmer)/信任(trust)         │
│   └─ tools/(8 内置工具+渲染器)  extensions/(4 内置扩展: mcp/codemode/       │
│       tool-search/llama.cpp)   export-html   utils/(38 横切工具)            │
├────────────────────────────────────────────────────────────────────────────┤
│ L3 Agent 运行时  packages/agent（pi-agent-core，7 文件薄核心）               │
│   Agent(状态机+事件) + runAgentLoop(循环:流式→工具→下一轮) + StreamFn 抽象   │
├────────────────────────────────────────────────────────────────────────────┤
│ L2 LLM 抽象  packages/ai（pi-ai，205 文件）                                  │
│   types(统一类型) + Models 运行时 + 42 Provider 工厂 + 10 API 方言适配器      │
│   + OAuth/凭据存储 + 模型目录(models.dev 生成) + 图像/分类 API               │
├────────────────────────────────────────────────────────────────────────────┤
│ L1 通用库                                                                    │
│   tui(终端 UI 差分渲染)  codemode(QuickJS 沙箱)  chord(服务/RPC/复制状态/    │
│   插件打包)  protocol(CBOR RPC 线协议)  client/server(RPC 两端)             │
│   mcp(MCP 客户端)  env(SSH 远程执行)  telemetry(遥测契约)  durable(持久化    │
│   会话/任务/文档运行时,SQLite)                                                │
└────────────────────────────────────────────────────────────────────────────┘
        辅助: evals(评测框架,private)
        实验层(不进产物): coding-agent/src/experimental —— coordinator/server/
        session-worker 多进程架构(基于 chord+client/server+durable)，及
        durable/vacation 单进程原型
```

关键架构决策（均有代码注释佐证）：
- **agent 包刻意做薄**：不含 provider 目录、凭据、UI，全部经 `StreamFn`/钩子注入（agent/src/agent-loop.ts、index.ts）——这是 coding-agent 能在其上组装完整 CLI 的前提。
- **pi-ai 主入口 side-effect free**（src/index.ts:4-8）：目录数据、Provider 工厂、OAuth 实现全部懒加载/子路径导出，控制包体与启动时间。
- **main.ts 只做"参数→选项"翻译，重量在 SDK**（core/sdk.ts:1-5 注释）：`createAgentSession` 是唯一组装点，CLI 与第三方 SDK 用户共用同一条路径。
- **同一事件源驱动四种宿主模式**：`AgentSession` 的事件流被 interactive/print/json/rpc 分别消费；UI 能力按模式降级（`bindExtensions({mode})`，interactive-mode.ts:1967、rpc-mode.ts:321）。
- **扩展系统统一内外**：内置扩展（mcp 等）与第三方扩展走完全相同的 `ExtensionAPI`，且第三方可顶替内置（`replaceable`，core/resource-loader.ts:120）。
- **experimental 与生产隔离**：tsconfig/files 双重排除 + 生产入口零 import（详见 4.13.7），保证实验架构不影响发布。

## 2.2 模块划分与依赖关系

14 包依赖方向（下游→上游；依据各包 package.json dependencies）：

```
coding-agent ──► agent ──► ai ──► (外部 SDK/无内部依赖)
     │  │  │  │
     │  │  │  └────────► mcp（MCP 客户端，仅被 coding-agent 的 mcp 扩展使用）
     │  │  └───────────► tui（终端 UI，被 coding-agent modes/components 使用）
     │  └──────────────► codemode（QuickJS 沙箱，被 codemode 扩展使用）
     └─────────────────► ai（直接消费 ModelRuntime 类型/OAuth）
durable ──► chord + ai
experimental(coding-agent 内) ──► durable + chord + client + server + protocol + agent
client ──► chord + protocol        server ──► chord + protocol
env ──► durable(/env 接口)        telemetry ──► 无内部依赖
evals ──► coding-agent + vitest-evals（private，不发布）
chord ──► esbuild（bundler 子路径）
```

## 2.3 核心数据流：一次交互式请求的完整路径

以「用户在 TUI 输入一条消息」为例（文件级链路，行号见第 7 章完整时序）：

1. **输入**：`CustomEditor.handleInput`（components/custom-editor.ts:88）处理按键 → Enter 触发 `setupEditorSubmitHandler`（interactive-mode.ts:3179）识别非斜杠/非 bash → 主循环 `run()` 的 `getUserInput()`（:4206）resolve。
2. **会话提交**：`session.prompt(text)`（core/agent-session.ts:1954）：扩展命令检查 → input 事件 → skill/模板展开 → 压缩互斥检查 → 模型/凭据校验 → 预压缩检查 → before_agent_start → 组装 user 消息与系统提示 patch → `_runAgentPrompt`。
3. **Agent 循环**（packages/agent）：`runAgentLoop` 内层 while：prepareNextTurn（阈值压缩可在此触发）→ 消息注入（工具集差量声明）→ prepareRequest（会话投影 + 虚拟模型路由）→ `streamFn` 调 LLM → 消费 12 种 StreamEvent（message_update 流出）→ stopReason=toolUse 时 prepareToolCall（schema 校验 + beforeToolCall 扩展拦截）→ 并行/串行执行工具 → toolResult 回填 → 下一轮请求 → 无工具调用时 finishTurn → turn_end → agent_end。
4. **LLM 流式**（packages/ai）：`ModelRuntime.streamSimple`（core/model-runtime.ts:715）→ `Models.stream` → `applyAuth`（auth.json/env/OAuth 刷新）→ 方言适配器（如 anthropic-messages.ts:571 stream）：transformMessages 净化 → convertMessages/convertTools → SDK/fetch 发请求 → 自实现 SSE 解析 → 增量聚合 partial 消息 → 逐事件 push → done 携带 usage/cost。
5. **持久化**：AgentSession 的 `_handleAgentEvent`（agent-session.ts:1090）把每条消息经 `SessionManager.appendMessage` → `_persist` 追加写 JSONL（首条用户消息出现才建文件，session-manager.ts:1160-1170）。
6. **渲染**：InteractiveMode.handleEvent（interactive-mode.ts:3386）把同一事件流映射为组件操作（AssistantMessageComponent 流式增量、ToolExecutionComponent 状态机、Footer token/成本刷新）→ `ui.requestRender()` → pi-tui 行级 diff（tui-main-screen.ts:247）或全屏双缓冲 diff（tui-alt-screen.ts:1672）写到终端。
7. **出口**：agent_settled → CacheWarmer 保温决策、扩展 flush、延迟 prompt 重放；控制回到主循环 await 下一条输入。

非交互变体：print 模式 await 全部 prompt 后取末条 assistant 文本经 `writeRawStdout` 输出（print-mode.ts:139-155）；rpc 模式每个事件序列化为 JSON-Lines 推给客户端（rpc-mode.ts:355-360）。

---

# 第 3 章 目录结构详解

以下树仅展示纳入范围的部分；`(N)` 为该目录生产 ts 文件数。省略目录以注释标明。

```
pi-1.0.4/
├── package.json / tsconfig*.json / biome.json / vitest.base.ts   # workspace 根与共享配置
├── pi-test.sh / pi-test.ps1 / test.sh                            # 从源码运行/测试脚本
├── scripts/                    # 构建辅助 mjs（bundle/锁版检查/发布）——构建工具，不逐文件分析
├── nix/                        # Nix 打包（model-catalog.json 固定 pin）
├── .pi/                        # 项目自用的扩展/提示/技能（dogfooding 配置，示例性质）
└── packages/
    ├── agent/                  # L3 Agent 运行时 (6)
    │   └── src/ agent.ts agent-loop.ts stream-fn.ts proxy.ts types.ts index.ts
    ├── ai/                     # L2 LLM 统一抽象 (194)
    │   ├── bedrock-provider.js/.d.ts      # Bun 编译静态入口（特殊条目，见 4.12.4）
    │   └── src/
    │       ├── types.ts models.ts compat.ts oauth.ts … (16 根文件)
    │       ├── api/            # 40 文件：10 方言适配器 + 14 .lazy 懒包装 + 共享层
    │       ├── auth/           # 凭据解析/存储 + oauth/ 9 厂商流程 + pkce/回调/设备码
    │       ├── providers/      # 92 文件：42 厂商工厂+42 .models.ts+all/faux/辅助
    │       └── compat/         # 扩展 OAuth 旧类型兼容
    ├── coding-agent/           # L4/L5 主产品 (299)
    │   └── src/
    │       ├── cli.ts main.ts config.ts index.ts migrations.ts package-manager-cli.ts rpc-entry.ts (7)
    │       ├── cli/            # 17：args.ts 参数解析 + auth/config/list-models/startup + experimental/ 命令框架
    │       ├── core/           # 94：会话/设置/模型/信任/压缩/技能/资源加载
    │       │   ├── tools/      # 16+8 renderers：8 内置工具 + diff 引擎 + 截断/累积/互斥队列
    │       │   ├── extensions/ # 8：jiti 加载器 + ExtensionRunner + 虚拟模块表
    │       │   ├── compaction/ # 4：上下文压缩纯函数库
    │       │   └── export-html/# 3：会话导出 HTML（ANSI→HTML）
    │       ├── modes/          # 67：interactive(TUI 主模式+35 components+theme)
    │       │   ├── print-mode.ts json-event.ts
    │       │   └── rpc/        # rpc-mode/rpc-client/rpc-types/jsonl
    │       ├── extensions/     # 25：4 内置扩展 mcp/ codemode/ tool-search/ llama/
    │       ├── utils/          # 37：进程/shell/路径/剪贴板/图像(Photon)/高亮/工具下载等
    │       ├── experimental/   # 46：C/S 多进程架构 + durable/vacation 原型 + services/
    │       ├── bun/            # 5：Bun 二进制启动垫片
    │       └── client/         # 1：pi-client 再导出
    ├── tui/                    # L1 终端 UI 库 (45)：tui.ts 核心 + 两渲染器 + components/ 24 组件
    │   └── native/             # 三平台 NAPI（剪贴板/VT 输入/修饰键）——原生薄层，不逐行分析
    ├── durable/                # L1 持久化运行时 (65)：harness/ session/ storage/(sqlite|jsonl|memory)
    │   │                       #   env/(可移植执行环境) tools/(durable 版工具) testing/
    ├── chord/                  # L1 应用组合运行时 (29)：facets/ services/ delta/ context/ node/(bundler)
    ├── mcp/                    # L1 MCP 客户端 (18)：client + transports/(stdio|http|memory) + oauth/
    ├── protocol/               # L1 RPC 线协议 (8)：信封 schema + CBOR 编解码 + 分帧
    ├── client/                 # L1 RPC 客户端 (8)：Client + Connection + unix 传输
    ├── server/                 # L1 RPC 服务端 (16)：Server + SessionRouter + unix 监听 + testing/
    ├── env/                    # L1 SSH 远程执行 (6)：Connection + RemoteExecutionEnv + ssh 部署
    ├── telemetry/              # L1 遥测契约 (6)：接口 + NOOP/Memory + 类型级 schema + conformance
    └── evals/                  # 评测框架 (5, private)：harness/plan/docker/report/cli
    （省略：各包 test/、docs/、examples/、dist/、CHANGELOG.md、README.md 等非生产内容）
```

各目录职责一句话总览（详细文件级职责见第 4/5 章）：

| 目录路径 | 职责 | 关键内容 |
|----------|------|----------|
| packages/agent/src | Agent 状态机与工具调用循环 | Agent 类、runAgentLoop、StreamFn 抽象、LLM 代理流 |
| packages/ai/src | 统一 LLM API：类型、目录、Provider、方言适配、OAuth | 42 Provider、10 方言、凭据解析链、models.dev 数据管线 |
| packages/ai/src/api | 每方言的请求构造与 SSE→统一事件转换 | anthropic/openai×2/google×2/bedrock/mistral/pi-messages 等 |
| packages/ai/src/providers | 厂商注册表（工厂+模型目录成对） | all.ts 注册表、faux 测试 Provider、cloudflare/opencode 辅助 |
| packages/ai/src/auth | 凭据存储与 9 套 OAuth 流程 | resolve 解析链、pkce、loopback 回调服务器、设备码 RFC8628 |
| packages/coding-agent/src（根） | 入口与配置 | cli/main 两级入口、config 安装检测、migrations、index SDK 面 |
| packages/coding-agent/src/cli | 参数解析与子命令 | 手写 parseArgs、auth 命令、首启向导、experimental 命令框架 |
| packages/coding-agent/src/core | 会话与应用内核 | AgentSession 族、会话/设置/模型/信任四管理器、压缩、skills、扩展加载 |
| packages/coding-agent/src/core/tools | 8 个内置工具与执行设施 | read/write/edit/bash/grep/find/ls + diff 引擎 + 输出治理 |
| packages/coding-agent/src/modes | 四种宿主模式 | interactive(TUI)、print(text/json)、rpc + 35 个 UI 组件 + 主题系统 |
| packages/coding-agent/src/extensions | 4 个内置扩展 | mcp 接入、codemode 沙箱工具、tool-search、llama.cpp 管理 |
| packages/coding-agent/src/utils | 横切工具库（38 文件） | 进程/shell 治理、路径、剪贴板、Photon 图像管线、fd/rg 下载 |
| packages/coding-agent/src/experimental | 下一代 C/S 架构试验场 | coordinator/server/session-worker/客户端 TUI/durable 原型 |
| packages/tui/src | 保留模式组件树 + 差分渲染终端 UI | 双渲染器、24 组件、键盘/颜色/图像协议、native 模块 |
| packages/durable/src | 崩溃可恢复的会话/任务/文档运行时 | Harness、TaskScheduler、SQLite 存储、生成/工具/压缩三内建任务 |
| packages/chord/src | 服务定位 + 复制状态 + RPC + 插件打包 | FacetKernel、ReplicatedState、Op 体系、esbuild bundler |
| packages/mcp/src | MCP 客户端（零 SDK 依赖） | JSON-RPC、stdio/HTTP 传输、OAuth 2.1 全家桶 |
| packages/protocol/src | 传输中立 RPC 线协议 | TypeBox 信封、手写 CBOR（限深限量）、4B 长度分帧 |
| packages/client/src ｜ packages/server/src | RPC 两端实现 | 握手/请求关联/订阅排队 ｜ SessionRouter/Unix 监听 |
| packages/env/src | SSH 部署的远程执行环境（Rust daemon） | 二进制帧协议、Node 语义对齐的 RemoteExecutionEnv |
| packages/telemetry/src | 厂商中立遥测契约 | Context/Span 接口、类型级 schema、conformance 套件 |
| packages/evals/src | 评测框架（private） | 隔离 harness、文档 A/B 变体、Docker 执行、配对报告 |

---

# 第 4 章 核心模块详解

本章按依赖自底向上：4.1~4.9 基础层库 → 4.10~4.12 中间层（agent/ai/durable）→ 4.13 业务层（coding-agent）。每模块按「职责 → 文件组成 → 关键类/函数 → 对外接口」展开；完整文件级清单见第 5 章。

## 4.1 pi-tui —— 终端 UI 库（packages/tui，45 文件）

**模块职责**：保留模式（retained-mode）组件树 + 差分渲染的终端 UI 框架，零重量运行时依赖（仅 marked + get-east-asian-width）。coding-agent 的全部交互界面建立在其上；扩展作者也可经虚拟模块表 import 它获得与宿主同级的 TUI 能力。

**架构三层**：
1. 终端抽象：`Terminal` 接口（terminal.ts:71-113）+ `ProcessTerminal`（:137）——raw mode、UTF-8 stdin、bracketed paste、Kitty 键盘协议协商（`\x1b[>7u`，flags 7，DA1 作哨兵、150ms 装配缓冲，terminal.ts:258-350）、Windows VT 输入、OSC 9;4 进度。
2. 渲染器（两套 diff 算法，见 6.6 深度解析）：`TuiMainScreen`（主屏+scrollback，行级 diff）、`TuiAltScreen`（备用屏全屏应用，布局帧+双缓冲）。
3. 组件层：一切实现 `Component`（tui.ts:117-142：`render(width): string[]` + 可选 handleInput/handleMouse + invalidate）。

**渲染调度**：组件 invalidate → `requestRender()` → nextTick + **16ms 节流**（tui.ts:507,1024-1042）；键盘输入走 `requestImmediateRender()` 绕过节流（Windows 上 setTimeout(0) 也可能耗满 tick，tui.ts:1001-1016 注释）。

**关键实现点**：
- 差分渲染：主屏与 `previousLines` 逐行比较求 first/lastChanged，只重绘区间（单行 spinner 不闪烁，tui-main-screen.ts:489 注释）；纯追加用 `\r\n` 促滚屏（:463-475）；整帧包同步输出 `\x1b[?2026h/l`；超宽行视为组件 bug，写 pi-tui-crash.log 后抛错（:517-544）。全屏屏按布局帧逐行 diff，禁 autowrap 防末列折行（tui-alt-screen.ts:1672-1777）。
- 图像：能力探测（KITTY_WINDOW_ID/ghostty/WeZTERM/iTerm/WT_SESSION 环境变量，tmux 下保守禁用，terminal-image.ts:70-134）；Kitty 图形协议 APC `\x1b_G`（4KiB 分块，:220-264）与 iTerm2 OSC 1337（:287-313）；**不支持 sixel**。主屏按 diff 区间删除失效图像 ID（tui-main-screen.ts:210-245）；全屏屏维护屏外图像 LRU（16 张/32MB 传输/64MB 解码，tui-alt-screen.ts:78-80）。
- 焦点/光标：`Focusable` 组件在渲染输出嵌零宽 `CURSOR_MARKER`（APC `\x1b_pi:c\x07`），TUI 提取后定位硬件光标（IME 候选窗需要，tui.ts:1442）。
- 键位：`KeybindingsManager`（keybindings.ts:231）默认表 + 用户覆盖 + 冲突检测；键解析双世界线（Kitty CSI-u 与 legacy 序列表，keys.ts:368-481）。
- 颜色：`Color = indexed|rgb|oklch`，支持 OKHSL（感知均匀）；OKLCH→RGB 用固定色相色度二分做 gamut mapping（colors.ts:190-216）；输出按终端能力降级 truecolor→256。
- 文本度量：`visibleWidth`（东亚宽字）、`wrapTextWithAnsi`、`sliceByColumn` 等 ANSI 感知列级原语（utils.ts）——是 diff 与合成的地基。
- native 模块：**不是** Kitty 图像模块（勘误：图像协议纯 TS 实现），而是三平台 NAPI 薄层：剪贴板文本/图像、Windows `ENABLE_VIRTUAL_TERMINAL_INPUT`、`GetAsyncKeyState` 修饰键（把 `\r` 重写为 Shift+Enter，terminal.ts:55-66）。prebuilds 随包分发，多候选路径加载兼容打包二进制（native-module-path.ts:14-31）。

**核心组件**：`Editor`（多行编辑器：词感知换行、大粘贴折叠为 `[paste #n]` 原子标记、kill-ring/undo、自动补全三重取消防护，components/editor.ts:296/2261-2500）、`Markdown`（流式友好渲染：StrictStrikethrough、LaTeX token 扩展支持未闭合公式、表格列宽分配算法、WeakRef token 缓存，components/markdown.ts:236）、`ScrollView`（follow-end 状态机，聊天自动跟底）、`SelectList`/`SettingsList`/`Box`/`Text`/`Image`/`Loader` 等 24 个。

**对外接口**（index.ts，约 120 符号）：核心类型（Component/Container/TUI）、两渲染器、键位族、颜色族、图像族（detectCapabilities/renderImage/encodeKitty）、全部组件、工具（fuzzyMatch/renderLatex/visibleWidth/wrapTextWithAnsi）、native 剪贴板。

## 4.2 pi-codemode —— QuickJS 沙箱（packages/codemode，10 文件）

**模块职责**：给 LLM 的「确定性代码执行」工具——在 QuickJS WASM 沙箱运行模型写的 JS，**唯一能力是调用宿主注入的工具**（包描述原文），杜绝提示注入导致的任意命令执行。

**执行模型**：每次 `execute()` 新建 worker 线程 + 全新 QuickJS VM（host.ts:122-124），结束即 terminate——失控脚本（含微任务自旋）可无损清除。wasm 由宿主一次性 `WebAssembly.compile` 后结构化克隆共享（wasm.ts:21、protocol.ts:16）；中断用 `SharedArrayBuffer(4)` + `Atomics.store`（Bun 的 terminate 杀不掉 wasm 自旋线程，靠 VM interruptHandler 轮询退出，host.ts:323）。

**桥协议**：worker 内 `vm.newFunction("bridge",…)` 是唯一出 VM 通道（worker.ts:65-100），仅 4 种原语消息（call/output/done/settle），参数一律 JSON 字符串跨界（protocol.ts:6-8）；宿主侧 BridgeError 防御脚本篡改 `Array.prototype.toJSON` 之类的桥数据畸形（host.ts:49-95）。

**安全边界四层**：① 独立 wasm realm；② prelude 开头 `lockdown()` 冻结全部内建并绕开 override mistake（prelude-source.ts:56-137）；③ 资源上限：timeout 默认 300s、内存上限、输出 16MiB 字符/10 万条、store 单值 256KiB/总量 1MiB（host.ts:22-41）；④ 协议级校验。脚本环境无 timers/fetch/process/require——零隐式出口。

**脚本侧 API**：`tools.<jsName>(args)`（`guard()` Proxy 给出 "Did you mean" 建议）、`text()/image()/exit()/console.*` 输出、`store/load` 持久化建议；`// @options:` 首行指令（source.ts:100-115，附 Lark 文法串供 provider 约束生成）；`renderDeclarations` 把工具 schema 渲染成 TS 声明给模型当 API 提示（declarations.ts:105）。

**对外接口**：`CodemodeSandbox`、类型族、`toCodemodeIdentifier`、`loadQuickJSWasm`、`parseCodemodeSource`、`CODEMODE_SOURCE_GRAMMAR`；子路径 `./declarations`、`./source`、`./worker`（打包独立 entry）。消费方：coding-agent 的 codemode 内置扩展（见 4.13.5）。

## 4.3 chord —— 应用组合运行时（packages/chord，29 文件）

**模块职责**：experimental C/S 架构的骨架：**服务定位（defineService）+ 组合单元（facet）+ 复制状态（ReplicatedState/JSON Op）+ RPC（RemoteService*）+ 插件打包（esbuild bundler）**。

**关键概念与实现**：
- `defineService`（api.ts:73-85）：服务身份 token；`local:true` 宽松契约，否则 `RemoteServiceContract` 做**类型级**校验（成员必须是 `(…Json, Context)=>Promise<Json|void>` 方法或 ReplicatedState，否则编译期塌缩为 never）。
- `FacetKernel`（facets/host.ts:340-906）：五阶段装配（setup→assembling→connecting→activating→active）；facet 间依赖经 Kahn 拓扑排序（环则报错，:858-880）；**本地 facet 间调用也走完整 RPC 语义**（loopback 绑定，:661-666）；`reload()` 支持 shape 不变的热替换（两阶段激活验证后原子切换，:423-511）。
- `ReplicatedState`（services/state.ts）：`change()` 用 tracker 代理产生 Draft → prepare 得 (value, ops) → publish；发布者单调 sequence、重入安全；订阅者串行回调、**100 帧背压溢出自动 reset 全量快照**（state.ts:44-49）；副本 hydrate 要求首 op 为 `[["r",value]]` 且 sequence 连续（:379-397），每个新值过 strict-JSON 校验防注入。
- Op 体系（delta/）：结构化 diff（含字符串 overlap 复用）、代理式 overlay tracker（piece table、数组变异拦截）、自产 op 的快速不可变应用、路径原型污染防护（delta/index.ts:121-131）。
- bundler（node/bundle.ts）：esbuild 打 facet 为**内容寻址 CJS**（sha256 integrity 清单），加载端 `node:vm compileFunction` 编译——插件拿不到宿主 require（bundle-loader.ts）。
- Go 风格 Context（context/）：值链 + 取消传播，所有服务方法尾参注入。

**对外接口**：5 个 entry：`.`（api 工厂+provider/endpoint+类型）、`./context`、`./delta`、`./bundler`、`./node`。

## 4.4 pi-protocol —— RPC 线协议（packages/protocol，8 文件）

**模块职责**：传输中立的 RPC 消息格式：TypeBox 信封（hello/request/cancel/response/service_update/attachment，protocol.ts）+ 自写 CBOR + 4 字节大端长度前缀分帧。`PROTOCOL_VERSION=8`。

**实现要点**：编码 = schema 校验（`isJsonValue` 防 undefined/函数进 CBOR）→ encodeCbor → encodeFrame（codec.ts:56）；解码器增量、失败即永久失败（防半包后续解析）。CBOR 手写编解码器面向**不可信输入**：限额 16MiB/容器 100 万/深度 64（cbor/options.ts:7-10）。

## 4.5 pi-client —— RPC 客户端（packages/client，8 文件）

**模块职责**：基于 protocol 的客户端。`Client`（client.ts:172-236）握手（serverId 匹配防连错端点）、请求-响应关联、服务订阅；**快照到达前的 wire 更新先排队原文**，快照解码后一并处理（:313-331，保证 Op 编解码器配对时序）；`createClientServiceTransport` 适配为 chord 传输（:448）。`Connection` 管理字节传输生命周期与状态机（generation id 防旧 transport 事件污染新连接）。unix.ts 提供 Unix socket 传输与服务器发现。

## 4.6 pi-server —— RPC 服务端（packages/server，16 文件）

**模块职责**：`Server`（server.ts）处理 5s 握手超时、信封分发、请求取消（withAbortSignal 注入 Context）、订阅状态编码；`SessionRouter`（session-router.ts:34）把「演示连接」绑定到持久 Session 的 attachment 并按客户端序列化操作；Unix 监听器原子绑定（临时文件+rename+硬链接）且 mode 0600。两端各有 testing/ 设施（createTestServer/ProtocolTestClient/TestHarness）。

## 4.7 pi-env —— SSH 远程执行环境（packages/env，6 文件）

**模块职责**：把 pi-durable 的 `ExecutionEnv`（FS+Shell 抽象）实现到远程主机：经 SSH 部署并启动一个 **Rust daemon**（daemon/ Cargo 构建，package.json build:daemon），`Connection` 用自定义二进制帧（REQUEST/RESULT/EVENT/CANCEL/PING，13 字节头，connection.ts:4-10）通信；5s PING 保活、30s 静默判死、会话句柄隔离（断线重启后旧句柄失效）、exec 的流式 onOutput 经 EVENT 帧。`RemoteExecutionEnv`（remote-env.ts:371-399）**刻意复刻 Node 本地语义**（`~` 展开、file:// URL、Windows 盘相对路径 `=D:`）；`RemoteWatcher` 断线随连接重启重开并上报 overflow。目前属 experimental 基础设施。

## 4.8 pi-telemetry —— 遥测契约（packages/telemetry，6 文件）

**模块职责**：厂商中立的 `TelemetryContext/Span` 接口 + NOOP/Memory 参考实现 + **纯类型级 schema**（`defineTelemetrySchema`/`createTypedSpanStarter`：span 名/属性/事件参数全部编译期检查，运行时零校验、零开销）+ 适配器 conformance 测试套件。pi 当前发布版遥测面很小（安装遥测开关 core/telemetry.ts），此包为未来接入与第三方适配立契约。

## 4.9 pi-mcp —— MCP 客户端（packages/mcp，18 文件）

**模块职责**：零官方 SDK 依赖的完整 MCP 客户端：JSON-RPC 协议、stdio 与 Streamable HTTP 传输、OAuth 2.1 全家桶（PKCE + 动态客户端注册 + Protected Resource Metadata 发现；部分代码改编自官方 SDK v1.29.0，oauth/flow.ts:1-5 注明）。

**关键实现**：
- `McpClient.connect`（client.ts:202-248）：initialize 版本协商（校验支持版本）→ initialized 通知 → connected；失败自动回滚。请求带每请求超时（默认 30s，超时发 cancelled 通知）；服务端反向请求（roots/list、ping）由 handleRequest 处理；列表方法自动翻页（1000 页上限 + 环检测，:355-374）。
- `StdioTransport`：cross-spawn 启动（Windows .cmd 兼容）；POSIX detached 进程组 + 退出兜底杀组；关闭序列 stdin→500ms→SIGTERM→SIGKILL；Windows `taskkill /T /F`。
- `StreamableHttpTransport`：POST JSON 或 SSE 流响应；`Last-Event-ID` 续传（流断且已有 lastEventId 时 GET 重放，失败合成 error 防悬挂，streamable-http.ts:393-398）；GET SSE 长连接 405 降级 + 指数退避重连；`Mcp-Session-Id` 会话管理；401/insufficient_scope 时经 authProvider 刷新后重试一次。
- OAuth：`authorizeMcp` 包装 invalid_client/invalid_grant 凭据作废重试；`adaptOAuthProvider` 并发 401 共享一次刷新 + refresh token 已被换新则直接重试（旋转安全）；`McpOAuthProvider` 按 serverUrl 隔离状态防凭据跨服务器泄漏（provider.ts:687-689）。

**对外接口**：`.`＝client+协议+传输；`./oauth`＝OAuth 工具链；`./testing`＝内存传输对。消费方：coding-agent 的 mcp 内置扩展（4.13.5）。

---

## 4.10 pi-agent-core —— Agent 运行时（packages/agent，6 文件）

**模块职责**：pi 最核心的通用执行器，与 UI、Provider 目录、凭据完全解耦（仅依赖 pi-ai 类型与 typebox）。三层抽象：`StreamFn`（LLM 调用传输抽象，types.ts:33）、无状态低层循环 `runAgentLoop`（agent-loop.ts:102）、有状态包装 `Agent` 类（agent.ts:188）。**系统提示与工具声明全部由 transcript 中的 system 消息承载**（types.ts:22-25 注释），`convertToLlm` 钩子在 LLM 调用边界把 `AgentMessage[]` 降维为标准 `Message[]`。

### 4.10.1 Agent 类（agent.ts:188-613）
- **状态构造**：`createMutableAgentState`（agent.ts:82-111）用 getter/setter 闭包实现 `tools/messages` 赋值浅拷贝、`systemPrompt` 从消息重放——系统提示只读，只能追加 system 消息改变；首条非 system 时播种初始 system 消息（:85-86）。
- **生命周期**：`prompt()`（:371）→ `runPromptMessages`（:432）→ `runWithLifecycle`（:507-530）：置 isStreaming、执行循环、catch 时 `handleRunFailure`（:532-548）合成 stopReason=error/aborted 的 assistant 消息并走完整事件序列，finally `finishRun`——保证 **agent_end 监听器结算完才 resolve**（waitForIdle 语义）。
- **事件流**：`processEvents`（:565-612）先状态规约（streamingMessage、pendingToolCalls、transcript push），再按订阅顺序 `await listener(event, signal)`；signal 缺失抛错，确保监听器总与当前 run 绑定。
- **steer/followUp 队列**：默认 `one-at-a-time`（:247-248）；`continue()`（:384-411）在末消息为 assistant 时先消费 steering→follow-up，否则报错。
- **嵌套工具调用**：`runToolCall`（agent-loop.ts:810-818）暴露同模型调用路径（prepare→before→execute→after）但不发事件不进 transcript——工具调工具时复用同一套校验与权限检查（:805-808 注释）。

### 4.10.2 agent-loop.ts —— 循环实现（:163-321，核心中的核心，深度解析见 6.1）
双层循环：**外层**（:179）处理 followUp 与显式 continuation；**内层**（:183）`while (hasMoreToolCalls || pendingMessages.length > 0)`：
1. `prepareNextTurn` 钩子（:186-200）：可整体替换 context/model/thinkingLevel（模型热切换）。
2. 消息注入（:211-217）：`declareToolChanges`（:333-363）比较 transcript 已声明工具与 context.tools 差集，必要时插入带 `toolsAdded/toolsRemoved` 的 system 消息。
3. `prepareRequest` 钩子（:219-239）：每次请求前最后替换点。
4. `streamAssistantResponse`（:381-469）：transformContext → convertToLlm → normalizeContext → getApiKey 动态解析（短命 token，:399-401）→ streamFunction；消费 12 种流事件，partial 消息原位替换并 emit message_update；流截断无终态事件时兜底（:460-468）。
5. 硬退出：error/aborted 直接收尾（:245-256）。
6. 工具执行：stopReason=length（输出截断）时**全部工具调用判错不执行**（`failToolCallsFromTruncatedMessage` :478-503，防残缺 JSON 参数通过校验）；否则 `executeToolCalls`（:508-523）——任一 sequential 或全局 sequential 则串行，否则**并行**（preflight 顺序、`Promise.all` 执行、toolResult 按源顺序补发，:649-654）。
7. `prepareToolCall`（:707-776）：找工具 → prepareArguments shim → typebox 校验 → beforeToolCall（block 则合成 error result，可带 terminate）→ 异常转 immediate 错误结果，循环永不因工具失败 reject。
8. turn 边界（:280-298）：finishTurn 钩子 → turn_end → poll steering → decision end 则 agent_end。

### 4.10.3 stream-fn.ts / proxy.ts
- `setDefaultStreamFn`（stream-fn.ts:11）：宿主注入默认模型运行时的全局点。
- `streamProxy`（proxy.ts:120-265）：**LLM 代理客户端**流函数（服务器在别处）：POST `${proxyUrl}/api/stream`，逐行 SSE；`processProxyEvent`（:270-406）在客户端重建 partial 消息（服务器剥掉 partial 省带宽）；EOF 无终态事件合成 error 防悬挂（:232-243）。

**对外接口**（index.ts 全量）：Agent、agentLoop/runAgentLoop(Continue)、runToolCall、streamProxy、setDefaultStreamFn、全部类型（AgentEvent/AgentTool/AgentLoopConfig/Before|AfterToolCallResult 等）。

## 4.11 pi-ai —— 统一多 Provider LLM API（packages/ai，205 文件）

**模块职责**：整个 monorepo 的 LLM 抽象层。向下封装 10 种 chat 方言 + 1 图像 + 3 分类器 API，向上提供统一类型、模型目录、Provider 工厂、OAuth/密钥认证。主入口刻意 side-effect free（index.ts:4-8），旧全局 API 面挪到 `/compat`（compat.ts:1-11）。

### 4.11.1 核心类型体系（types.ts，1076 行）
- `KnownApi` 10 方言 / `KnownProvider` 约 40 厂商（`(string & {})` 保持可扩展，:17-81）。
- 消息四元组：SystemMessage（content/sections/toolsAdded/toolsRemoved **增量式**系统提示）/ UserMessage / AssistantMessage（含 usage/stopReason/deferred/diagnostics）/ ToolResultMessage（泛型 TDetails 经 `IsJsonCompatible` 编译期校验，:457-500）。
- 内容块：TextContent（textSignature 携带 Responses 消息 id）、ThinkingContent（thinkingSignature 为 provider 不透明回放数据）、ImageContent、ToolCall（thoughtSignature 为 Google 专用）。
- 事件协议 12 种（见术语表）；注释明确「partial 是共享 live 视图而非快照」「done/error 前必须有 start」（:754-768）。
- Usage/ModelCost（阶梯计价 tiers；Anthropic 1h cache write 以 2 倍 input 价计费，models.ts:1209-1215）。
- **Compat 矩阵**：OpenAICompletionsCompat 30+ 开关（maxTokensField、11 种 thinkingFormat、cacheControlFormat、sessionAffinityFormat 等，:791-868）——同一方言适配器服务几十家兼容厂商的关键。
- `StreamFunction` 约定（:373-377）：同步抛错仅限鉴权缺失；错误必须以流事件终止。

### 4.11.2 Models 运行时（models.ts）
- `Provider` 接口（:149-238）：id/name/baseUrl + 必填 `auth`（即使无密钥也要有 auth 语义表达「是否已配置」，:156-163 注释）+ getModels（同步不抛）+ 可选 refreshModels/filterModels + stream/streamSimple + 可选 deferred/image/classify。
- `ModelsImpl` 三件事：① **refresh 世代机制**（:485-530）：每次刷新递增 generation，supersede 使旧刷新 abort，持久化写入串成 per-provider promise 链，写前再校验 generation——陈旧刷新永不覆盖新数据；② 两阶段刷新（先 allowNetwork=false 从存储恢复，再联网拉取，:551-611）；③ `applyAuth`（:842-874）：getAuth 解析（OAuth 过期刷新）→ 显式 options > auth 解析结果的字段优先级 → auth.baseUrl 可覆盖模型 baseUrl。
- `stream/complete`（:876-915）：normalizeContext 后用 `lazyStream` 把异步 setup 延入流内——同步签名返回流、失败产出 error 事件而非 throw。
- `calculateCost`（:1198-1218）阶梯费率；`clampThinkingLevel`（:1233-1252）不支持时先上后下找最近档。

### 4.11.3 api/ 方言适配器（40 文件）
每个方言导出 `stream`（方言原生选项）与 `streamSimple`（SimpleStreamOptions 统一入口）；`.lazy.ts`（14 个）把实现包成首次调用才 import 的 ProviderStreams——主入口零 SDK 依赖。

代表性对比（深度解析见 6.3）：
- **anthropic-messages.ts**：自实现 SSE 解析（iterateSseMessages :471-528，TextDecoder 增量 + 手写换行扫描）；content_block 按 index 聚合；OAuth token（`sk-ant-oat`）时伪装 Claude Code 身份头（user-agent=claude-cli/2.1.280，:1025-1027）；beta 头组装（:1080-1122）；cache_control 打点（:1484-1508）；usage 提前取（message_start，保证中断也有输入计数，:680-688）。
- **openai-completions.ts**：`detectCompat`（:1593-1690）按 provider/baseUrl 判定 zai/together/moonshot/openrouter/deepseek/ant-ling 等输出兼容开关；工具调用按 index+id 双 Map 关联；`reasoning_content`/`reasoning`/`reasoning_text` 三字段取第一非空（chutes.ai 会双发，:611-620）；parseChunkUsage 处理三种 cached_tokens 位置（OpenAI details/DeepSeek/Kimi，:1519-1560）；无 finish_reason 的 provider 在流结束按是否有 toolCall 推断（:695-697）。
- **openai-codex-responses.ts**（1534 行）：ChatGPT 后端专适配，WebSocket 优先 + SSE 回退（1009/超限自动降级并按 sessionId 记忆，:296-371）、zstd 压缩请求体（:218-225）、previous_response_id 续链、deferred 响应 fetch/cancel（ProviderStreams 可选成员的唯一实现方之一）。
- **bedrock-converse-stream.ts**：直建 BedrockRuntimeClient（region 解析链、代理换 NodeHttpHandler、bearer token authSchemePreference）；自定义头经 Smithy 中间件纳入 SigV4 签名（:480-494）。
- **google 系**：无显式块边界，适配器自持 currentBlock 状态机在 text/thinking 间切换（google-generative-ai.ts:103-221）；Gemini 3 离散 thinkingLevel 与旧模型 thinkingBudget 分支（google-shared.ts:72-111）。
- **pi-messages.ts**：pi 自有线上协议（Radius 网关）——把 AssistantMessageEvent 协议原样作为线格式。
- 共享层：`transform-messages.ts`（跨模型回放净化：图像降级、thinking 按同模型与否保留/降级/丢弃、孤儿 toolCall 补结果、跳过 error 轮，:64-235）；`simple-options.ts`（maxTokens 上下文钳制 = contextWindow − 估算 − 4096；思考预算默认 minimal 1024→max 16384；:18-108）；`constrained-sampling.ts`（strict JSON Schema 改写：禁 $ref/allOf/oneOf、强制 additionalProperties:false、可选属性包 anyOf null——provider strict 子集；openai_lark 文法工具让模型直写裸文本，:56-298）。

### 4.11.4 providers/ —— 42 家厂商注册表（92 文件）
每厂商 `xxx.ts` 工厂 + `xxx.models.ts` 生成目录成对。最简形态 15 行（google.ts:6-15）；最复杂是 anthropic.ts（:19-90 多级 resolve 链：存储凭据→ANTHROPIC_AUTH_TOKEN Bearer→API key→工作负载身份联合三 env 齐备才走 SDK 自换 token）。`builtinProviders()`（all.ts:136-181）注册全部 42 家；目录数据源自 models.dev（scripts/generate-models.ts 拉取，含 OpenRouter 目录与 Fireworks effort 回退等硬编码补丁），`models.generated.ts` 聚合三个只读 map——构建时再生成，发布 tarball 不含 data/。

分组概览（完整 42 行清单见 5.2 节）：anthropic 系 10 家 / openai-completions 系 19 家 / openai-responses 系 3+azure+codex / google 系 2 / 专有协议 4（bedrock、mistral、radius、typesafe 纯分类器）。地区性设计显著：minimax/moonshotai/xiaomi/qwen/zai 均有 CN/国际/多区域独立 provider。特殊：openrouter 是唯一图像生成 provider；radius 为纯动态目录（从网关 /v1/config 拉取）；github-copilot 按 OAuth 凭据 availableModelIds 过滤模型并对未配置模型自动启用 policy。

### 4.11.5 auth/ —— 凭据与 OAuth（14 文件）
- `resolveProviderAuth`（resolve.ts:46-93）核心原则（:27-31 注释）：**存储凭据独占 provider，env 只在无存储时兜底；刷新失败不静默回退 env**。OAuth 双检锁：余量 <5 分钟才刷新，store 锁内复查防并发双刷；**刷新一旦开始忽略取消信号**（防丢已轮换的唯一 refresh token），仅 15s 超时约束（:119-155）。
- `CredentialStore`（types.ts:65-94）：按 provider id 存单条 Credential（api_key 或 oauth，扩展键承载厂商附加数据如 Copilot 的 availableModelIds）。
- OAuth 流程 9 套（oauth/）：共享 PKCE（Web Crypto SHA-256，pkce.ts:21-34）、loopback 回调服务器（state 校验、单次 claim 防重放、与手工粘贴 code 竞速支持 SSH 无浏览器，callback-server.ts:50-183）、设备码 RFC 8628（device-code.ts:46-98）。代表：github-copilot.ts 设备码 → GitHub token → copilot_internal/v2/token 换短期 Copilot token → 拉 /models 解析 policy → 自动 POST policy 启用（:93-432）；openai-chatgpt.ts **动态客户端注册**（每次登录用占位 client_id，OpenAI 在回调返回真实 clientId 持久化，:59-61/250-263）。
- 安全要点：环回 OAuth 限 127.0.0.1；verification_uri 强制 http(s) 防 `open` 执行任意程序；client_id 轻度混淆（atob）；token 统一提前 1-5 分钟过期裕量。

**对外接口**（index.ts）：types 全量、models.ts 全量（Provider/Models/createModels/createProvider/calculateCost）、14 个方言懒工厂、auth 基础设施（credential-store/helpers/context/faux provider）、utils（AssistantMessageEventStream/parseStreamingJson/normalizeContext/uuidv7 等）。子路径：`/models`、`/compat`、`/providers/*`、`/api/*`、`/oauth`、`/bedrock-provider`、`/bun-oauth`。

## 4.12 pi-durable —— 持久化会话/任务/文档运行时（packages/durable，65 文件）

**模块职责**：崩溃可恢复的 agent 执行内核，解决三件事：① **会话崩溃恢复**——转录/运行状态/用户提交全部落盘为原子提交序列，崩溃重开后从提交点续跑（部分回答以 aborted 条目保留）；② **任务图**——任务是以 checkpoint 状态机持久化的记录（`defineTask({name,version,initial,phases,abort,migrate})`），「每个状态迁移都由 Session 变更线上一个串行化回调决定」（scheduler.ts:169-173），崩溃遗留 running 任务打开时回归 pending；③ **文档复制状态**——chord 支持的 base 快照 + delta Op 链，`checkpointWhen` 谓词决定何时写完整 base。

**核心概念**：Harness（内核入口，harness.ts:410-436）、Conversation（无状态句柄：submit/compact/abort/fork/waitForIdle）、五个内建文档（pi.agent/pi.live/pi.inbox/pi.provider/pi.usage）、三个内建任务（pi.generation/pi.tool/pi.compaction，registry.ts:9-10 不可移除）、defineExtension/defineTool/hook/section/wrap 扩展 DSL。

**存储层**（三实现）：`SqliteStorage`（基于 **Node 内建 `node:sqlite`**，非 better-sqlite3；`BEGIN IMMEDIATE` 事务、WAL + synchronous=NORMAL、关库 checkpoint TRUNCATE，node.ts:140-192）、`JsonlStorage`（主文件+边车）、`MemoryStorage`。schema 8 张 STRICT 表（conversations/entries/tasks/submissions/documents/document_revisions 等，migrations.ts:9-85）；全局 ID 独占检查、文档化身校验、latest-only 文档写 base 时删旧修订回收空间（storage.ts:588-838）。

**Session 内核**（session/session.ts）不变量：只有已提交状态可观察；提交回调、准备、落盘、采纳、发布全在变更线（promise tail 链）串行；**一旦准入，调用方取消不能中断落盘**（:426）；落盘成功但采纳失败则 Session 毒化（必须重开）。`Transaction`（transaction.ts）实现读后写防护（首写后任何表读抛 ReadAfterWrite，:919-927）、挂起操作追踪、文档组装计划（fork 拷贝/退役/checkpoint 升格）。

**TaskScheduler**（scheduler.ts，1338 行，深度解析见 6.5）：open 时把遗留 running 改写 pending 保留 checkpoint（:244-246）并修复崩溃时未落地的级联中止；`#reconcile` 修复循环把持久记录蕴含的意图（被取消 owner 下补 abort 标记、failFast 联动、completing 收尾）应用到不动点；phase handler 线外跑、每个 phase 前的同步 step 决定结束；无持久进展（checkpoint JSON 深比较）判 faulted。

**GenerationTask**（generation.ts）：checkpoint 相位 prepare→request→(retry|poll)→tools；prepare 落 cutoff/system 差量/流选项（恢复后原样重发）；request 阶段 **partial 每 100ms 节流落盘**（单 commit 在飞，copyJson 快照防 provider 原地改写，:364-416）；工具轮次逐个派生 ToolTask 子任务并 waiting；final 边界放置收件箱队列项（steer/followUp），无用户项且钩子给 continuation 则 handOver 交接下一 run。

**ToolTask**（tool.ts）：**两阶段意图**——先提交 `{phase:"execute", arguments, replay}` 意图再执行；崩溃后落在 execute 相位的任务仅当存储与当前定义都 `replay:"safe"` 才重跑，否则 failed（级联中止其拥有的会话，:94-111）。输出经 `OutputBuffer`（head/tail 有界窗口）+ `Progress` 自适应节流提交（间隔 = max(outputIntervalMs, 字节/100KiB/s)）。

**对外接口**（index.ts）：createSession、defineTask/defineDoc/defineEntry、Harness 族、三个内建任务、watchEvents（AgentEvent 流，形状对齐 coding-agent）、子路径 `/env`、`/env/node`、`/tools`、`/storage/{memory,jsonl,sqlite}[/node]`、`/testing`。消费方：coding-agent experimental 的 durable/vacation 原型与 session-worker（见 4.13.7）。

---

## 4.13 pi-coding-agent —— 交互式编码 agent CLI（packages/coding-agent，299 文件）

**包定位**：monorepo 主产品。发布名 `@earendil-works/pi-coding-agent`，bin `pi` → `dist/bundle/cli.js`，SDK 主入口 `dist/index.js`。运行时依赖以内部包为主（pi-agent-core/pi-ai/pi-tui/pi-mcp/pi-codemode），外部仅 undici、proper-lockfile、minimatch/semver/yaml/typebox 等（package.json:49-73）。

### 4.13.1 入口链与 main.ts（src 根 7 文件）

启动链（`pi` 命令 → 交互模式，完整行号链见 7.1）：

1. `src/cli.ts:5-6`：`setupCli()`（崩溃日志/未捕获异常安装）后 `main(argv)`。
2. `src/main.ts:573 main(args)` 编排：auth 子命令（:582）→ Windows 自更新清理（:586-604，成功时故意不 process.exit(0) 规避 Node bug 56645）→ bootstrap SettingsManager + HTTP dispatcher（:591-595）→ install/remove/update/list、config、mcp 子命令短路（:597-618）→ `parseArgs`（:620）→ `runMigrations`（:666）→ 首启向导与主题（:669-681）→ `createSessionManager`（:693，按 --session/--resume/--continue/--fork/--no-session 分派 SessionManager 静态工厂，main.ts:358-449）→ ProjectTrustStore（:717）→ **createRuntime 工厂闭包**（:730-861，捕获进程级固定输入，会话替换时按新 cwd 重建服务；项目信任延迟到扩展加载时解析，未信任不读项目 settings）→ `createAgentSessionRuntime`（:863）→ stdin 管道检测（:892-905，有管道降级 print）→ `resolveAppMode`（:112，TTY+flags 决定 interactive/print/json/rpc）→ 四模式分派（:948-998）。
3. 服务组装：`createAgentSessionServices`（core/agent-session-services.ts:135）= ModelRuntime.create + SettingsManager.create + DefaultResourceLoader.reload + 扩展 Provider/虚拟模型注册 + 扩展 flag 校验；`sdk.createAgentSession`（core/sdk.ts:181）= findInitialModel + CacheWarmer + `new Agent({streamFn: modelRuntime.streamSimple 包装})` + `new AgentSession`（core/agent-session.ts:474）。

**根文件职责**：config.ts（包自描述：APP_NAME="pi"/VERSION、`getAgentDir()`=~/.pi/agent、安装方式检测含 Bun `$bunfs` 特征、`detectInstallChange` 防运行中自更新）；migrations.ts（启动期一次性迁移：auth 迁 auth.json、键位迁移、弃用告警）；package-manager-cli.ts（pi install/remove/update/list/config + 自更新）；rpc-entry.ts（pi-rpc bin：`main(["--mode","rpc",...])`）。

### 4.13.2 core 基础设施（会话/设置/模型/信任/资源，54 文件）

**AgentSession**（agent-session.ts，约 4400 行，会话核心）：
- 构造（:474-514）订阅 agent 事件并安装 6 组钩子：beforeToolCall/afterToolCall（扩展拦截）、prepareNextTurnWithContext（阈值压缩+提示/工具刷新）、prepareRequest（会话投影为规范上下文 + 虚拟模型路由并记录状态条目，:775-829）、finishTurn（turn 边界）、transformContext 两层（隐藏工具声明投影/强制系统提示投影）。
- `prompt(text)`（:1954）顺序：扩展命令 → 压缩互斥 → input 事件 → skill/模板展开 → steering/followUp 中转 → 模型凭据校验 → 预压缩检查 → before_agent_start → 图片归一化 → 组装消息与系统提示 patch（diffSystemPromptSections 增量，利于 prompt cache）→ `_runAgentPrompt`。
- `_runAgentPrompt`（:1808-1837）：agent.prompt 后 while 循环 `_handlePostAgentRun`（可重试错误→指数退避+剔除失败尝试→压缩检查→队列检查）；finally flush 挂起消息并 `_emitAgentSettled`（触发缓存保温、扩展、延迟 prompt 重放）。
- 压缩：手动 `compact()`（:2750，session_before_compact 钩子可取消/替换）与自动 `_checkCompaction`（:2933，区分 overflow-with-retry/overflow-no-retry/threshold 三情形，含压缩后陈旧 usage 防抖）；摘要生成走 compaction 纯函数库（见下）。
- 其他：setModel/cycleModel、setThinkingLevel（clamp+持久化）、executeBash（`!` 命令）、navigateTree（分支摘要+leaf 切换）、exportToHtml/Jsonl、bindExtensions（UI/mode 绑定+session_start+资源发现注入）、reload、dispose。

**AgentSessionRuntime**（agent-session-runtime.ts:74）：会话替换三部曲模板方法——emitBeforeSwitch/Fork（扩展可取消）→ teardownCurrent（abort→session_shutdown→**同步** UI 拆除回调）→ createRuntime 重建 → apply → finishSessionReplacement（UI 重绑+扩展拿新 ctx）。`setBeforeSessionInvalidate` 的同步拆除约束是 TUI 与 core 的关键解耦点（:129）。

**SessionManager**（session-manager.ts:987，JSONL 会话树）：
- 数据模型：首行 SessionHeader{version:3,id,cwd,parentSession}，条目含 id/parentId，类型覆盖 message/model_change/thinking_level_change/usage/compaction/branch_summary/custom/label 等。
- 投影：`buildSessionPath`（leaf→root 回溯）→ `buildContextEntries`（最新 compaction 为检查点+保留尾部）→ `buildSessionProjection`（context_edit 替换/剔除）——保证「模型看到的=持久化的」。
- 持久化：首个用户/助手消息出现前**不落盘**（:1160-1170，#10000）；之后逐条 appendFileSync；加载 1MB 缓冲流式解析；v1→v3 迁移。
- 分支：`createBranchedSession`（:1632）提取路径**重链 label 条目**（label 是真实树节点）并映射 compaction 的 firstKeptEntryId；list/listAll 并发（10/64）构建 SessionInfo。
- 静态工厂 create/open/continueRecent/inMemory/forkFrom（:1755-1866）。

**SettingsManager**（settings-manager.ts:379）：三层来源（全局 ~/.pi/agent/settings.json + 项目 .pi/settings.json（未信任不读）+ 运行时覆盖）；深合并 + defaultTools `+name/-name` 修饰符；**字段级增量写**（只把本会话改过的键合并回磁盘当前内容，proper-lockfile 锁 + 10×20ms ELOCKED 重试 + 串行写队列 + 错误缓存供 UI 拉取）；迁移 queueMode→steeringMode 等；60+ getter/setter；设备 ID 只读全局防项目文件共享。

**ModelRuntime**（model-runtime.ts:171，implements pi-ai Models）：create（RuntimeCredentials 覆盖层→ModelConfig.load(models.json)→FileModelsStore 缓存→内置 Provider 全部经 withRemoteCatalog 包装（pi.dev 目录 overlay，etag/304/4h）→radius 配置）；组合管线（native 扩展 > builtin 为 base，models.json+扩展为 overlay）；快照与可用性（runAvailabilityRefresh 并发 checkAuth 以 seq 防竞态）；请求路径 prepareRequest（getAuth→mergeHeaders→baseUrl/env）；**凭据操作串行化**（per-provider promise 链包裹 login/logout，失败抛 CredentialSynchronizationError 保留已提交状态）；虚拟模型路由 resolveModel（校验路由目标是物理且有凭据的模型）。`ModelRegistry`（model-registry.ts:48）是面向扩展的同步门面。

**信任体系**：`ProjectTrustStore`（trust-manager.ts:210，trust.json，父目录继承，同步锁）；`hasTrustRequiringProjectResources`（:186，探测 .pi/{settings.json,mcp.json,extensions,skills,prompts,themes,SYSTEM.md} 及祖先 .agents/skills）；`resolveProjectTrusted`（project-trust.ts:46）决策链：override→无需信任资源→扩展 project_trust 事件→存储→defaultProjectTrust→UI 弹选。

**资源加载**：`DefaultResourceLoader.reload`（resource-loader.ts）经 DefaultPackageManager 解析 settings.packages（npm:/git:/本地）→ 加载扩展 → skills/prompts/themes/AGENTS.md|CLAUDE.md 上下文文件 → SYSTEM.md/APPEND_SYSTEM.md；`omitReplacedExtensions`（:120）实现第三方扩展按同名工具/命令/旗标**顶替内置扩展**。

**系统提示**（system-prompt.ts）：分节结构（preamble + tools/rules/docs/skills/cwd 等 XML 标签节）；`diffSystemPromptSections`（:217）生成增量 patch——一条 system 消息更新提示而非整段重发（prompt cache 友好）。

**压缩库**（compaction/compaction.ts，998 行，深度解析见 6.4）：estimateTokens（role 分派 chars/4，图片 4800）；findCutPoint 从最新往回累积 keepRecentTokens、只在合法切点落刀（绝不在 toolResult）、支持拆分回合；结构化 checkpoint 摘要（Goal/Constraints/Progress/Key Decisions/Next Steps/Critical Context）+ 迭代更新；maxTokens=min(0.8×reserve, model.maxTokens)。

**其他 core 文件**：auth-storage（auth.json 凭据存储，0600、异步锁 30s stale、`${ENV}`/`!cmd` 展开）；bash-executor（`!` 命令流式执行：滚动缓冲+超限转临时文件+截断）；cache-warmer（prompt 缓存保温：90% TTL、期望收益 `0.15×missCost − warmCost ≥ $0.05` 决策，扩展可改判）；mcp-servers（MCP 配置校验/注册表/暴露四级 codemode|deferred|direct|hidden）；messages（declare merging 注入 4 个自定义消息角色，convertToLlm 降维）；nested-tool-calls（工具内 ctx.executeTool，限额 256 调用/8KB 单参/32KB 总参，顺序化 Promise 链）；skills（发现/校验/`<available_skills>` 格式化）；prompt-templates（$1/$@/${N:-def} 替换）；crash-log（环形 5 条崩溃记录+栈归因扩展）；bug-report（脱敏/打包/上传 Radius）；event-bus、exec、http-dispatcher（undici EnvHttpProxyAgent+allowH2:false）、output-guard（print/json 模式 stdout→stderr 转发，writeRawStdout 保持真输出通道+背压）、keybindings、footer-data-provider（git 分支含 worktree/WSL 轮询）、package-manager（2463 行 npm/git 包解析安装）、virtual-models（api:"pi-virtual" 路由目录合成）、resolve-config-value（`!cmd`/`${ENV}` 模板）、source-info、session-cwd、session-export、usage-totals、provider-attribution/composer、remote-catalog-provider、pi-manifest、defaults/diagnostics/timings/telemetry/experimental/radius。

### 4.13.3 内置工具集（core/tools/，16+8 文件）

每个工具由「定义工厂 `createXxxToolDefinition` + 包装 `createXxxTool`」组成：定义是 `ToolDefinition`（含 name/parameters(typebox)/execute/renderCall/renderResult 等），包装经 `wrapToolDefinition`（tool-definition-wrapper.ts:8）转成 agent-core 的 AgentTool，缺省 ctx 由 ctxFactory 注入（这就是内置工具拿到 runner 上下文/PI_* 环境的通道）。每个工具暴露 `XxxOperations` 接口允许扩展替换执行后端（SSH/容器远程化）——核心扩展点。

**bash.ts**（含 powershell.ts 变体）：
- `createLocalShellOperations`（:97-166）：getShellConfig（WSL 遗留 bash 走 stdin 传输）；spawn detached（非 Windows 进程组，供 killProcessTree 整树击杀）；超时/abort 都杀树；信号致死返回 128+signal。
- `resolveSpawnContext`（:186-212）：注入 PI_SESSION_ID/PI_PROVIDER/PI_MODEL 等给子进程（系统提示告诉模型可检查）；spawnHook 允许扩展改写 command/cwd/env。
- execute：OutputAccumulator + 100ms 节流 onUpdate（流式渲染）；`structuredContent`（BashToolOutput，1MB 上限）面向 codemode 等程序调用方，与模型可见文本（2000 行/50KB 截断）分离。无后台进程支持——长命令靠 timeout/abort。
- powershell.ts：复用引擎，命令前加 UTF-8 OutputEncoding 前缀。

**edit.ts + edit-diff.ts**（diff 引擎，深度解析见 6.2）：prepareArguments 容错（模型把 edits 发成 JSON 字符串/单对象/旧格式——点名 Opus 4.6、GLM-5.1）；执行流程 withFileMutationQueue 串行 → BOM 剥离/还原 + CRLF/LF 保持 → LF 归一化空间做**精确→模糊两级匹配**（NFKC、行尾空白、智能引号→ASCII、Unicode 破折号归一）→ 唯一命中校验+重叠检查 → 倒序替换 → 「被触碰行块」从归一化基底重写、其余行从原文拷回（模糊匹配不污染全文）；产出 diffString（自制渲染，上下文 4 行折叠）+ unifiedPatch。

**read.ts**：图片分支（MIME 判定→processImage 自动缩放，非视觉模型加注记）；文本 offset/limit 分页 + truncateHead + 三种续读提示（含 `sed -n 'Xp'` 建议）。**write.ts**：mkdir -p + 互斥队列。**grep.ts**：spawn `rg --json`，match 上限 100 即 kill；上下文行不用 rg 输出而由 readFile+行缓存自拼（支持远程 Operations）。**find.ts**：spawn fd，git 感知（仓库外 --no-require-git，#5960），Windows 路径分隔符归一。**ls.ts**：排序+限额。**truncate.ts**：四策略（Head 绝不返回半行/Tail 例外允许末行截半/Middle 首尾保留/Line 500 字符），全部 UTF-8 字符边界安全。**output-accumulator.ts**：流式 TextDecoder + tailText 滚动窗口（超 2×50KB 按字符边界裁剪）+ 超限自动落盘临时文件。**file-mutation-queue.ts**：按 realpath 的 per-file promise 链（并发工具调用不交错写同一文件）。**path-utils.ts**：~ 展开 + macOS 截图文件名四级变体回退（窄不换行空格/NFD/弯引号）。**renderers/**（8 文件）：TUI 渲染（执行前 diff 预览、流式输出 5 行预览、增量语法高亮缓存）——独立成目录让「只渲染的进程」免载执行路径 ~17MB（renderers/index.ts:1-7 注释）。

**export-html/**（3 文件）：会话→单文件 HTML；ansi-to-html（SGR 状态机，256 色/真彩精确还原）；tool-renderer 复用 TUI 渲染器走 TUI→ANSI→HTML 管线；主题色按 userMessageBg 亮度 WCAG 派生。

### 4.13.4 扩展系统（core/extensions/ 8 文件 + src/extensions/ 25 文件）

**加载器**（core/extensions/loader.ts）：
- jiti 双模式：Bun/SEA 二进制 → jiti/static（内嵌 Babel）；普通 Node → jiti 惰性 transform。`moduleCache:false` 使扩展模块每次加载重新求值（支撑 /reload），loader 层另有按 cwd+generation 的工厂缓存。
- 发现：`<cwd>/.pi/extensions/` → `<agentDir>/extensions/` → 配置路径；目录内 *.ts/*.js 直载、子目录 index、或 package.json `"pi".extensions` 清单，仅一层深度。
- `createExtensionRuntime`（:157-237）：运行时骨架（动作全为桩），`bindCore` 才换真实现；provider/virtualModel 注册绑定前入 pending 队列；`invalidate` 标记 stale 并退订。
- `createExtensionAPI`（:244-549）：`pi` 对象——注册类写入扩展私有 Map，动作类委托 runtime；**事务语义**：loading 期变更入 pendingRuntimeChanges，工厂成功 commit / 抛错 discard。
- virtual-modules.ts：`VIRTUAL_MODULES` 表把 typebox/pi-agent-core/pi-tui/pi-ai/本包全量以虚拟模块供给扩展（编译二进制里共享同一实例）；`@mariozechner/*` 旧名兼容。

**ExtensionRunner**（runner.ts）：
- `bindCore`（:410-544）把宿主实现搬进 runtime（sendMessage/setActiveTools/createContext…）+ 绑定 5 个会话命令动作（newSession/fork/navigateTree/switchSession/reload）。
- 上下文工厂全 getter 惰性求值 + assertActive 守卫（stale 即抛）；createToolContext 加 tools+executeTool（嵌套调用 id 派生 `<parent>/n`）。
- 事件分发 `emit`（:1089-1118）：按注册顺序串行，单 handler 抛错被捕获不中断其他扩展；专用形态：emitToolCall（block 短路）、emitToolResult（字段级合并 content/details/structuredContent）、emitUserBash（严格 XOR 校验、handler 抛错 rethrow）、emitContext 两阶段（context 事件不见 system 消息+事后重挂保护缓存前缀；context_with_system 见全量）、emitBeforeAgentStart（聚合 message 注入+forceSystemPrompt）、emitBoundary（turn_end 的 entries/continue 聚合）、emitInput（transform 链+handled 短路）。
- 快捷键冲突合并（保留键硬冲突跳过并记诊断）；命令重名 `name:N` 递增；同名工具**首个注册者赢**。

**扩展 API 面**（types.ts:1553 起，也是第三方扩展作者的接口）：
- `pi.on(event)` 约 40 种事件（session_*/context/provider_*/agent/turn/message/tool_*/user_bash/input/resources_discover/project_trust/mcp_servers_change/ui_prompt_*/model_select/cache_warming_decision…）。
- 注册：registerTool(ToolDefinition)/registerCommand/registerShortcut/registerFlag/registerMessageRenderer/registerEntryRenderer/registerMarkdownTransformer/registerToolRenderer/registerProvider/registerMcpServer/registerVirtualModel + pi.events 自定义总线。
- 动作：sendMessage/appendEntry/setActiveTools/exec/setModel/getSettings/getMcpServers 等。
- `ToolDefinition` 关键字段：exposure（direct/model-only/codemode/deferred/hidden）、promptSnippet/promptGuidelines（进系统提示）、prepareArguments（校验前 shim）、outputSchema（→structuredContent）、prepareLoadout（激活时改写模型可见描述）、constrainedSampling（文法约束）、annotations（权限提示）、executionMode。

**4 个内置扩展**（src/extensions/，InlineExtension 与第三方同权）：
1. **mcp**（index.ts:276-1219）：动态注册 `mcp__<server>__<tool>` 工具（同名冲突 hash 后缀稳定命名；撤回的工具以 exposure:"hidden" 重注册软删除）；暴露等级映射 + `ensureDiscoveryActive` 按需激活 codemode/tool_search；tool_call 钩子在脚本调用前阻塞等待相关服务器连接（后台连接、按需阻塞）；before_agent_start 注入 mcp_servers 系统提示段（4096 字符预算）；generation 计数器防陈旧异步连接写新会话；`pi mcp` 子命令可 add/remove/list/login。子模块：runtime.ts（McpServerConnection 状态机：瞬时错误重试一次、会话过期换新重试、stdio 失败保 stderr 尾 2000 字）；oauth.ts（mcp-auth.json 按 server|url 键存、proper-lockfile 跨进程刷新锁防 token 轮换竞态、PKCE+DCR/CIMD、浏览器回调与手工粘贴竞速）；tools.ts（outputSchema 一律 CallToolResult 形状供 codemode 识别；isError 保留 structuredContent；20KB 掐中段存全文；二进制资源落临时文件）；resources.ts（资源三件套工具）。
2. **codemode**（execute.ts:359-479）：解析 `// @options:`；为每个可调用工具生成 sandboxTools（经 ctx.executeTool 走完整 agent 管线：校验/hook/权限）；CodemodeSandbox 256MB 堆限防失控脚本；globals 注入 searchTools/describeNamespace（复用 tool-search 的 Bm25Ranker）与 models.classify/generateImages（4 并发限流、上下文形状校验报错文案直接教模型怎么改、剥 headers 防凭据泄漏）；store 经 appendEntry 持久化到会话分支；超预算输出掐头去尾+全文 spill 临时文件；image() 输出配临时文件路径（脚本不能写文件）。tool.ts 的 `createCodemodeDescription`（:248-298）按命名空间分组轮转排版（OpenCode 目录学），prepareLoadout 实现 on/only 双模式 + openai_lark 文法约束（模型直写裸 JS）。
3. **tool-search**：BM25（k1=1.2,b=0.75）+ camelCase 切分/停用词/朴素词干；只搜 codemode/deferred 且未激活的工具，命中即 setActiveTools（激活记入 transcript，随分支存续）。
4. **llama.cpp**：registerProvider（openai-completions 协议，chat+classify 双目录）+ /llama 全屏管理 TUI（HuggingFace 搜索：500ms 防抖+取消+缓存+fuzzy 本地过滤；40 格进度条；下载取消二次确认）；contextWindowOf 三级回退（运行时 n_ctx→--ctx-size 解析→缓存→128000）；auth 三段式（交互输 URL 验证连通）。

### 4.13.5 模式层（modes/ 67 文件）与 cli/（17 文件）

**四模式**（共享 AgentSessionRuntime + session.subscribe + bindExtensions(mode)）：
- **interactive**（InteractiveMode，interactive-mode.ts:450，7073 行）：init（:936-1119，chatViewport 全屏版式 + 启动键 + ui.start 先于扩展以便 session_start 能用对话框 + fd/rg 后台下载）；run 主循环（:1138-1253）`while(true){ getUserInput() → session.prompt() }`；键盘处理链（CustomEditor.handleInput：扩展快捷键→粘贴→interrupt(Escape)→exit(Ctrl+D)→actionHandlers→兜底编辑；Enter→setupEditorSubmitHandler 匹配约 30 个内置斜杠命令/`!` bash/流式 steer/常规提交）；handleEvent（:3386-3769）把 AgentSessionEvent 全量映射为组件操作（message_update 增量+新 toolCall 建 ToolExecutionComponent、entry_appended 回放、compaction 边界重渲染、重试指示器）；选择器覆盖层 showSelector（临时替换编辑器容器+抢焦点+互斥）；switchTuiMode 主屏↔全屏互切（Proxy 稳定 ui 引用保留 children/focus）；shutdown 区分信号/交互退出，打印 resume 命令。
- **print**（print-mode.ts:33-169）：rebindSession（注册扩展命令动作+json 订阅逐行 writeRawStdout+背压等待）；text 模式取末条 assistant；SIGTERM 处理；finally dispose+flush。
- **rpc**（rpc/rpc-mode.ts:54-819）：JSON-Lines stdin/stdout；约 40 个命令（prompt/steer/follow_up/abort/get_state/set_model/…/bash/get_tree/get_commands，见 4.13.9 接口表）；extension_ui_request 桥接（select/confirm/input/editor 挂起待客户端回复，TUI 专属能力显式 no-op 降级）；`return new Promise(()=>{})` 永久保活。rpc-client.ts（RpcClient）：spawn `--mode rpc` 子进程，类型化方法 + waitForIdle/collectEvents/promptAndWait。
- **json-event.ts**：json/rpc 共用线格式转换（剔除流式 partial 快照）。

**components/**（35 文件）：AssistantMessage（thinking 合并渲染+OSC133 shell 集成标记）、ToolExecution（三态背景、双轨渲染：扩展自定义/退化预览、执行前 diff 预览）、footer（token/缓存命中/费用/上下文%/模型/分支）、各 selector（model/scoped-models/thinking/settings/session/tree/fork/trust/config/theme）、login/oauth 对话框、custom-editor、diff、mermaid 变换、彩蛋（armin/3D）等。**theme/**：theme.ts（Symbol.for 全局 Proxy 保证 node/jiti 双模块图共享单例；自定义主题 watcher 防抖热重载）、system-theme（从终端上报配色按 OKHSL 家族配方生成 system 主题+WCAG 对比度）、theme-json（typebox 校验 ~60 颜色槽位，懒安装避免非交互加载 17MB）、theme-controller（终端颜色查询 100ms 超时+亮暗自动同步）。

**cli/**：args.ts 手写单遍解析（无 commander；`--` 后 positional；`@file` 入 fileArgs；未知长旗标入 unknownFlags 交给扩展旗标；`-p` 特判吸附且允许 `---` 开头提示词）；auth-command/auth-check/credential-print（pi auth）；config-selector/session-picker/startup-ui（启动期 TUI 复用 interactive 组件）；file-processor（@file→文本/图片）；initial-message；list-models；experimental/ 自建类型化 Command 框架（Command 类链式 option/build/action——与 args.ts 并存两套解析体系，推断为未来迁移准备）。

### 4.13.6 utils/ 横切工具（37 文件，9 组能力）

进程与 shell（child-process.ts 的 `waitForChildProcess` :49-137 用「每收到 data 块重臂 100ms 空闲计时器」解决 detach 孙进程持有管道导致 close 永不触发，注释引 #5303；shell.ts 的 getShellConfig 三级解析、killProcessTree Windows 用绝对路径 taskkill 防 PATH 劫持、sanitizeBinaryOutput 剔除会击穿 string-width 的 U+FFF9-FFFB）；路径（normalizePath 管线：Unicode 空格归一→剥 @→MSYS/WSL 路径翻译→~ 展开→file:// URL；getCwdRelativePath；markPathIgnoredByCloudSync 打 xattr 防 Dropbox 同步）；剪贴板（全平台矩阵+OSC52+WSL PowerShell 文件中转绕管道编码坑+远程会话检测）；图像管线（Photon WASM 懒加载+Bun readFileSync 补丁；双约束缩放：Lanczos3 重采样×PNG/JPEG 质量阶梯，全败宽高×0.75 重试；worker 线程优先防阻塞 TUI；EXIF 1-8 方向纠正；魔数嗅探含 APNG 排除）；文本/渲染（syntax-highlight：手写增量解析器遍历 highlight.js HTML 把 span 标签翻译为 scope 栈→主题格式化器，产出主题着色纯文本）；网络与自更新（management-http 幂等重试；version-check pi.dev；tools-manager fd/rg 按需下载——**刻意绕开 api.github.com 60 次/时限额**，改解析 releases/latest 302 Location；每次唯一临时目录解压防并发竞态；windows-self-update 原生依赖隔离换名）；git.ts（扩展安装源 git URL 解析：splitRef 三形态 + hosted-git-info + scp-like 回退 + 双解码防注入）；杂项（zip 纯 zlib 手写、changelog、frontmatter、jsonc、deprecation 去重告警、output-files 统一临时输出 0600+wx 防符号链接攻击）。

### 4.13.7 experimental/、bun/、client/（52 文件）与构建隔离

**experimental/ 是下一代架构试验场**，五块：
1. **C/S 多进程架构**（主体）：coordinator 守护进程（coordinator.ts——稳定 Unix socket 端点，新 server 注册即替换旧的、public 连接全部重置；空转自杀 30s/250ms 宽限；非 Windows socket chmod 0600）；server 进程（server.ts——launcher 锁、SessionWorkerManager、Radius 中继、replaced 回调优雅让位）；session-worker 每会话进程（session-worker.ts——typebox 协议 schema、WorkerLifecycle 存活仲裁 demand 表、proper-lockfile 锁会话目录、harness.resume 活任务保持进程）；client（client-runtime/client-tui——完全由服务端复制状态驱动，不直接持有 Agent）。
2. **services/**（14 文件）：SessionDirectory/SessionManagement/AgentController/Models/Transcript/SlashCommands 等服务切片（defineService 契约 + provider 实现）。
3. **durable/ 原型**（7 文件）：单进程 durable coding agent（直接用 pi-durable Harness + SQLite，崩溃恢复演示，含前台 subagent 工具）。
4. **vacation/**（6 文件）：durable 的复制改造版（coding 工具换成度假规划），演示**后台** subagent 两阶段任务（deliver 阶段提交子会话请求、report 阶段把报告作为 followUp 送回主会话，requestId 幂等）。
5. 杂项：process.ts（内部进程 spawn/角色协议）；source-resolver.ts（tsconfig paths 的 Node module hook，源码模式不落回 stale dist）。

**启用与隔离**：唯一开关 `PI_EXPERIMENTAL === "1"`（core/experimental.ts:1-3）；唯一受支持入口 `pi-test.sh`（node --import source-resolver src/experimental/cli.ts）。**不进发布产物的证据链**：tsconfig.build.json:19 排除 src/client、src/experimental；bundle 脚本只打包 dist/{cli,index,rpc-entry}；package.json files 二次排除；生产入口 src/cli.ts 零 import experimental。

**bun/**（5 文件）：Bun 编译二进制启动垫片——restore-sandbox-env（从 /proc/self/environ 恢复沙箱丢失的 env，Bun #27802 workaround）、runtime-setup（静态注册 Bun OAuth 流程、注入 QuickJS wasm 路径与 Bedrock provider 模块）。**client/**（1 文件）：pi-client 再导出（仅 source 条件子路径，服务 workspace）。

### 4.13.8 SDK 对外接口（src/index.ts，约 500 行再导出）

分层：parseArgs/Args；config 路径常量；AgentSession 全类型 + parseSkillBlock；compaction 全量 API；扩展系统约 140 类型 + 运行时函数；SDK 核心（createAgentSession/createAgentSessionFromServices/Services、createAgentSessionRuntime、工具工厂 createCodingTools/createReadTool/…）；SessionManager 及数据类型；SettingsManager；loadSkills；resolveCliModel/ModelRegistry/ModelRuntime；DefaultPackageManager/ResourceLoader；ProjectTrustStore；虚拟模型类型；内置扩展工厂（codemode/mcp/tool-search）；main/MainOptions；三模式 + RpcClient；TUI 组件与主题工具；剪贴板/图像工具。子路径 `./client`（pi-client 再导出）与 `./experimental/plugin`（插件 API，仅 source 条件）。

---

# 第 5 章 文件清单总表

**统计口径**：覆盖 `packages/*/src` 下全部生产 `.ts` 源文件共 **715 个**（不含 `.d.ts` 类型垫片 4 个：coding-agent utils/highlight-js.d.ts、bun/quickjs-wasm.d.ts、ai providers/data-json.d.ts——它们是第三方类型声明，无运行逻辑；不含生成代码 ai/src/models.generated.ts 的逐行分析，该文件在表中单列）。另有 2 个包根特殊文件（ai/bedrock-provider.js 与 .d.ts，各 1 行 re-export，Bun 编译静态入口）在 5.2 末尾注明。表格按包组织；「关键导出/依赖」列对模式化文件（.lazy.ts/.models.ts 等）从简。

## 5.1 packages/agent（6 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| src/agent.ts | Agent 状态机 | 有状态 Agent：事件流、steer/followUp 队列、生命周期 | Agent、AgentInitialState、QueueMode | pi-ai、agent-loop、stream-fn |
| src/agent-loop.ts | 循环内核 | 低层双层循环与工具执行（prepare→流式→工具→下一轮） | agentLoop、runAgentLoop(Continue)、runToolCall、AgentEventSink | pi-ai、stream-fn |
| src/stream-fn.ts | 传输注入点 | 默认流函数全局注册 | setDefaultStreamFn | — |
| src/proxy.ts | LLM 代理客户端 | POST 代理 SSE 流、客户端重建 partial | streamProxy、ProxyAssistantMessageEvent | pi-ai |
| src/types.ts | 类型契约 | StreamFn、AgentEvent、AgentTool、钩子与状态类型 | 全部类型 | pi-ai、typebox |
| src/index.ts | 门面 | 再导出 | 上述全部 | — |

## 5.2 packages/ai（194 文件）

### 5.2.1 src 根（17 文件，含生成文件 1）

| 文件路径 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|
| src/types.ts | 全部核心类型与方言兼容开关矩阵 | Message 族、AssistantMessageEvent(12 种)、Model 族、ProviderStreams、StreamFunction、Compat 族 | typebox |
| src/models.ts | Provider/Models 双接口 + 运行时容器 + 成本 | Provider、Models、createProvider、createModels、calculateCost、clampThinkingLevel | auth/*、models-store、api/lazy、utils/* |
| src/models.generated.ts | **生成代码**：聚合 42 厂商三个目录只读 map（由 scripts/generate-models.ts 从 models.dev 生成，构建时再生） | MODELS、IMAGE_MODELS、CLASSIFIER_MODELS | providers/*.models.ts |
| src/model-catalog.ts | 目录摊平的编译期类型工具（字面量 id 推导） | flattenChatModelCatalog 等 | types |
| src/models-store.ts | 动态目录持久化接口（按 provider 键） | ModelsStore、InMemoryModelsStore | types |
| src/compat.ts | 旧全局 API 兼容层（api-registry + env key 注入） | stream/complete、registerApiProvider、registerFauxProvider | api/*.lazy、env-api-keys、providers/* |
| src/legacy-api-aliases.ts | 16 个方言 stream 函数 deprecated 别名 | streamAnthropic… | api/*.lazy |
| src/env-api-keys.ts | 环境变量 API key 发现；Vertex ADC/Bedroid 环境探测 | getEnvApiKey、findEnvKeys | node:fs/os/path（动态） |
| src/index.ts | side-effect-free 主入口 | 见 4.11 对外接口 | api/lazy、auth、models、utils |
| src/oauth.ts | 扩展 OAuth 类型转发（type-only） | OAuthAuthInfo 等 8 类型 | compat/extension-oauth-types |
| src/bun-oauth.ts | Bun 二进制静态注册 9 个 OAuth 流程 | registerBunOAuthFlows | auth/oauth/* |
| src/bedrock-provider.ts | Bedrock 模块静态导出（Bun build 用） | bedrockProviderModule | api/bedrock-converse-stream |
| src/images.ts | 图像生成入口（注册表分发，import 即注册内置） | generateImages | images-api-registry |
| src/images-api-registry.ts | ImageApi→generateImages 全局注册表 | registerImagesApiProvider | types |
| src/image-models.ts | deprecated：静态图像模型读取 | getImageModel(s) | models.generated |
| src/session-resources.ts | 会话级资源清理回调（codex WS 缓存） | registerSessionResourceCleanup | — |
| src/cli.ts | pi-ai bin：login/list | main | providers/all |

### 5.2.2 src/api/（40 文件）

| 文件路径 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|
| api/lazy.ts | 懒加载基础设施 | lazyStream、lazyApi | utils/event-stream |
| api/anthropic-messages.ts | Anthropic Messages 方言（OAuth Claude Code 伪装、beta 头、自实现 SSE） | stream、streamSimple、AnthropicOptions | @anthropic-ai/sdk |
| api/openai-completions.ts | Chat Completions 方言（detectCompat 矩阵、11 种 thinkingFormat） | stream、streamSimple、convertMessages | openai SDK |
| api/openai-responses.ts | Responses 方言 | stream、streamSimple | openai、openai-responses-shared |
| api/openai-responses-shared.ts | 三方言共享：消息/工具转换与流处理（textSignature/thinkingSignature 回放） | convertResponsesMessages、processResponsesStream | openai types |
| api/openai-codex-responses.ts | ChatGPT Codex 后端（WS 优先+SSE 回退+zstd+deferred） | stream、streamSimple、fetchDeferred、cancelDeferred | openai、node:zlib、session-resources |
| api/azure-openai-responses.ts + azure-openai-config.ts | Azure Responses（deployment 名解析与注入） | stream、streamSimple；resolveAzureConfig | openai AzureOpenAI |
| api/bedrock-converse-stream.ts | Bedrock ConverseStream（SigV4/代理/bearer/Smithy 中间件） | stream、streamSimple、BedrockOptions | @aws-sdk、@smithy |
| api/google-generative-ai.ts | Gemini API Key 方言 | stream、streamSimple | @google/genai、google-shared |
| api/google-vertex.ts | Vertex（API Key 或 ADC） | stream、streamSimple | @google/genai、google-shared |
| api/google-shared.ts | Google 共享：thinking 配置、消息/工具转换、stopReason 映射、重试 | resolveGoogleThinkingLevel、convertMessages/Tools、retryGoogleRequest | @google/genai |
| api/mistral-conversations.ts | Mistral 方言（自实现 fetch+SSE、promptCacheKey） | stream、streamSimple | utils/* |
| api/pi-messages.ts | pi 自有线协议（Radius 网关，事件原样上链） | stream、streamSimple、PiMessagesEvent | utils/* |
| api/cloudflare.ts | Cloudflare 端点 URL 常量 | 5 个常量 | — |
| api/cloudflare-ai-binding.ts | Workers AI binding 透传 fetch + 预鉴权哨兵 | createAiBindingFetch | types |
| api/cloudflare-workers-ai-system-one.ts | Workers AI REST 分类 transport | classify | system-one-shared |
| api/typesafe-system-one.ts | TypeSafe 原生 System One 分类 | classify | system-one-shared |
| api/system-one-shared.ts | System One 分类协议（noul↔bool、计价） | classifySystemOne | models.calculateCost |
| api/llama-cpp-classify.ts | llama-server 单 token logprob 分类 | classify、LabeledQuestion | utils/* |
| api/openrouter-images.ts | OpenRouter chat 端点图像生成 | generateImages | openai |
| api/constrained-sampling.ts | strict schema 改写 + Lark/regex 文法 + 增量 JSON 缓冲 | makeStrictJsonSchema、resolveGrammarConstrainedSampling、appendGrammarToolInputJsonDelta | types |
| api/transform-messages.ts | 跨模型回放净化（图像降级/thinking 处理/孤儿 toolCall） | transformMessages | types |
| api/simple-options.ts | Simple→方言选项钳制（maxTokens/预算/采样合成） | buildBaseOptions、clampMaxTokensToContext、adjustMaxTokensForThinking | models、utils/estimate |
| api/github-copilot-headers.ts | Copilot 动态头 | buildCopilotDynamicHeaders | types |
| api/openai-prompt-cache.ts | prompt_cache_key 64 字符截断 | clampOpenAIPromptCacheKey | — |
| api/*.lazy.ts（14 个：anthropic-messages、azure-openai-responses、bedrock-converse-stream、cloudflare-workers-ai-system-one、google-generative-ai、google-vertex、llama-cpp-classify、mistral-conversations、openai-codex-responses、openai-completions、openai-responses、openrouter-images、pi-messages、typesafe-system-one） | 各实现的首调 import 懒包装（bedrock 版含变量 specifier+模块覆盖） | xxxApi(): ProviderStreams | ./lazy |

### 5.2.3 src/auth/（14 文件）

| 文件路径 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|
| auth/resolve.ts | 凭据解析链（存储独占/env 兜底/OAuth 双检锁刷新） | resolveProviderAuth、refreshStoredOAuthCredential | types、credential-store |
| auth/credential-store.ts | InMemoryCredentialStore（per-provider promise 链串行写） | InMemoryCredentialStore | types |
| auth/context.ts | 默认 auth 上下文（env+文件存在探测） | defaultProviderAuthContext | node:fs（动态） |
| auth/helpers.ts | envApiKeyAuth/lazyOAuth 标准构造 | envApiKeyAuth、lazyOAuth | types |
| auth/types.ts | Credential/AuthInteraction/CredentialStore 全契约 | 全类型 | — |
| auth/oauth/pkce.ts | PKCE verifier/challenge（Web Crypto） | 生成函数 | node:crypto/webcrypto |
| auth/oauth/callback-server.ts | 环回回调服务器（state 校验/防重放/手工粘贴竞速） | startCallbackServer、waitForCallbackOrManualInput | node:http |
| auth/oauth/device-code.ts | RFC 8628 设备码轮询 | pollDeviceCode | — |
| auth/oauth/load.ts | OAuth 流程懒加载注册表（Bun 静态注册钩子） | bundledLoaders、registerBundledOAuthFlowLoaders | — |
| auth/oauth/anthropic.ts | Claude Pro/Max OAuth | 流程实现 | pkce、callback-server |
| auth/oauth/openai-chatgpt.ts | Sign in with ChatGPT（动态客户端注册） | 流程实现 | pkce、callback-server |
| auth/oauth/openai-codex.ts | ChatGPT Codex（浏览器 1455 端口/设备码双路径） | 流程实现 | device-code、pkce |
| auth/oauth/github-copilot.ts | Copilot 设备码+双层 token+policy 自动启用 | 流程实现 | device-code |
| auth/oauth/{kimi-coding,meta,openrouter,radius,xai}.ts | 其余 5 家厂商流程（Bearer/minted key/永久 key/网关/订阅） | 流程实现 | pkce/device-code |
| src/compat/extension-oauth-types.ts | 旧扩展 OAuth 回调契约（仅为兼容保留） | OAuthLoginCallbacks 等 | auth/types |

### 5.2.4 src/providers/（92 文件：42 工厂 + 42 目录 + 8 辅助）

工厂与目录成对（`xxx.ts` + `xxx.models.ts`，后者均为「import data/xxx.json → flatten」的 10-15 行生成物）。下表为 42 家厂商完整清单（协议/认证/特殊点），`.models.ts` 不再单列：

| Provider ID（对应 xxx.ts/xxx.models.ts） | API 协议 | 认证方式 | 特殊点 |
|---|---|---|---|
| amazon-bedrock | bedrock-converse-stream | bearer/AWS profile/凭据链 | 不复制 AWS 凭据进 pi 存储 |
| ant-ling | openai-completions | env ANTLING_API_KEY | 16 行标准模板 |
| anthropic | anthropic-messages（+image/classifier 目录） | key + 3 env + OAuth + 工作负载联合 | resolve 链最复杂 |
| azure | azure-openai-responses + openai-completions | env AZURE_OPENAI_API_KEY | deployment 名经 onPayload 注入 |
| baseten / cerebras / deepseek / groq / huggingface / nvidia / together / xiaomi | openai-completions | 各自 env key | 标准模板（xiaomi=MiMo） |
| cloudflare-ai-gateway | anthropic-messages + openai-completions + openai-responses | 自定义三元组（account+gateway+key） | baseUrl 占位符流前替换；固定三协议 |
| cloudflare-workers-ai | openai-completions + system-one 分类 | 自定义（无 gateway_id） | 唯一 Workers AI 分类器 |
| fireworks | anthropic-messages + openai-completions | env | effort 元数据回退名单 |
| github-copilot | anthropic-messages + openai-completions + openai-responses | env + OAuth 设备码 | filterModels 按凭据过滤；自动启用 policy |
| google / google-vertex | google-generative-ai / google-vertex | env GEMINI_API_KEY / key·ADC·服务账号 | vertex 探测 gcloud ADC 文件 |
| groq（见上）| — | — | — |
| kimi-coding | anthropic-messages | env + OAuth 设备码（订阅） | Bearer header 而非 apiKey |
| meta | openai-responses | env + OAuth 设备码 | access 是 ~1 天 minted key，refresh=重铸 |
| minimax / minimax-cn | anthropic-messages | 各自 env | .io / .com.cn 域名拆分 |
| mistral | mistral-conversations | env | 唯一 Mistral 专有协议 |
| moonshotai / moonshotai-cn | openai-completions | 共用 env | .ai / .cn 拆分 |
| openai | openai-responses | env + OAuth（动态客户端注册） | — |
| openai-codex | openai-codex-responses | 仅 OAuth（Plus/Pro） | baseUrl chatgpt.com/backend-api，标注 legacy |
| opencode / opencode-go | 多协议聚合（4/3 种）+typesafe 分类（opencode） | env OPENCODE_API_KEY | x-opencode-session 会话路由头 |
| openrouter | anthropic-messages + openai-completions + openrouter-images + typesafe 分类 | env + OAuth（PKCE 换永久 key） | 唯一图像生成 provider |
| qwen-token-plan / -cn / -individual | openai-completions | 各自 env | 阿里 MaaS 三区域 |
| radius | pi-messages | env + OAuth | 纯动态目录（/v1/config） |
| typesafe | typesafe-system-one（仅分类） | env | 无 chat 模型 |
| vercel-ai-gateway | anthropic-messages + typesafe 分类 | env AI_GATEWAY_API_KEY | 聚合网关 |
| xai | openai-responses | env + OAuth（SuperGrok 设备码） | 订阅型 |
| xiaomi-token-plan-ams / -cn / -sgp | openai-completions | 各自 env | 三区域 |
| zai / zai-coding-cn | openai-completions | 各自 env | 智谱国际 / BigModel.cn |

辅助 8 文件：`all.ts`（注册表：builtinProviders/builtinModels/getBuiltinModel 类型化读取）、`faux.ts`（711 行脚本化测试 Provider：可编程响应队列/延迟模拟）、`cloudflare-auth.ts`（网关鉴权头）、`cloudflare-stream.ts`（baseUrl 占位符替换）、`opencode-headers.ts`（会话头注入）、`radius-config.ts`（网关 URL/config 端点）、`data-json.d.ts`（data/*.json 类型声明）、`images/register-builtins.ts`（注册 openrouter-images）。

### 5.2.5 src/utils/（26 文件）

| 文件路径 | 职责 | 主要消费者 |
|---|---|---|
| utils/event-stream.ts | AssistantMessageEventStream：FIFO 队列+等待者队列的异步迭代流、result() Promise | 所有方言适配器 |
| utils/json-parse.ts | parseStreamingJson（增量 JSON）、parseJsonWithRepair（容错修复） | 工具调用参数聚合 |
| utils/transcript.ts | normalizeContext（brand 唯一生产点）、transcript 工具 | models.ts、方言 |
| utils/assistant-message-frame.ts | 流式消息帧辅助（partial 管理） | 方言 |
| utils/provider-retry.ts | retryProviderRequest：指数退避+retry-after 解析 | 方言 |
| utils/retry.ts | 通用重试 | 多处 |
| utils/overflow.ts | 上下文溢出判定工具 | compaction、durable |
| utils/estimate.ts | token 估算 | simple-options |
| utils/validation.ts | 参数/结果校验辅助 | models、方言 |
| utils/typebox-helpers.ts | schema 校验辅助 | 多处 |
| utils/uuid.ts | uuidv7 | 会话/provider 身份 |
| utils/text.ts | contentText/getSystemMessageText/renderSystemMessageUpdate | durable、coding-agent |
| utils/headers.ts | 头合并工具 | models |
| utils/hash.ts | 哈希工具 | 缓存 |
| utils/diagnostics.ts | 请求诊断结构 | AssistantMessage |
| utils/error-body.ts | 错误体解析 | 方言 |
| utils/node-http-proxy.ts | Node HTTP 代理 agent | bedrock 等 |
| utils/oauth-page.ts | OAuth 结果 HTML 页 | callback-server |
| utils/pi-user-agent.ts | UA 字符串 | 方言 |
| utils/provider-env.ts | provider 环境变量解析 | azure 等 |
| utils/sanitize-unicode.ts | Unicode 清洗 | 输出治理 |
| utils/sleep.ts / abort.ts / abort-signals.ts / model-operations.ts / models-error.ts | 小工具（睡眠/中止/中止合并/模型操作断言/ModelsError） | 多处 |

**包根特殊文件**：`bedrock-provider.js` 与 `bedrock-provider.d.ts`（各 1 行 `export * from "./dist/bedrock-provider.js"`）——package.json 子路径指向 dist，为 Bun 单文件构建提供可静态引用的 Bedrock 模块句柄（推断，依据 bedrock-converse-stream.lazy.ts:15-24 的 override 注释）。

## 5.3 packages/chord（29 文件）

| 文件路径 | 职责 | 关键导出 |
|---|---|---|
| src/types.ts | 全部公共契约（Context/Service/ReplicatedState/Facet/传输） | 接口与 JSON 类型 |
| src/api.ts | 公共工厂入口 | createFacetHost、defineService、defineFacet、replicatedState、createRemoteServiceBinding |
| src/index.ts / bundler.ts / node.ts | 门面（./、./bundler、./node）与打包/加载门面 | re-export |
| src/json.ts | strict-JSON 深拷贝与校验 | copyJson、isJsonValue |
| src/context/index.ts | Go 风格 Context（值链+取消） | BACKGROUND_CONTEXT、withCancel、withAbortSignal |
| src/facets/host.ts | FacetKernel 装配/重载/拓扑排序 | FacetKernel（内部） |
| src/facets/loader.ts | loader 释放辅助 | disposeLoadedFacets |
| src/services/state.ts | 复制状态实现（Draft→ops→publish；背压 reset） | MutableReplicatedStateImpl、ReplicatedStateReplica |
| src/services/state-internals.ts | WeakMap 桥接内部接口 | register/getReplicatedStateInternals |
| src/services/state-codec.ts | 每订阅 Op 编解码注册表 | createServiceStateEncoder/Decoder |
| src/services/provider.ts | 服务端注册表与订阅发布（溢出 reset 快照） | RemoteServiceProvider、createRemoteServiceEndpoint |
| src/services/consumer.ts | 消费端绑定（可调用 Proxy facade + 副本） | RemoteServiceBindingImpl |
| src/services/handle.ts | 守卫式服务视图 Proxy | ServiceSlot |
| src/services/instances.ts | keyed 实例目录 + 可取消观察任务 | InstanceDirectory |
| src/services/loopback.ts | 进程内回环传输 | createLoopbackServiceTransport |
| src/services/wire.ts | 控制调用编解码与快照校验 | createService*Call、parseService* |
| src/services/errors.ts | 错误码与错误类 | RemoteServiceError |
| src/delta/index.ts | Op 语法/校验/应用/编解码（含原型污染防护） | Op、apply、encoder/decoder |
| src/delta/diff.ts | 两棵 JSON 树结构化 diff（字符串 overlap 复用） | diffRevisions |
| src/delta/draft.ts / tracker.ts / apply-immutable-trusted.ts / revision-validator.ts | Draft 类型 / 代理式 overlay 跟踪（piece table）/ 自产 op 快速应用 / 副本校验 | track、Tracker、applyImmutableTrusted、JsonRevisionValidator |
| src/node/bundle.ts | esbuild 打 facet 为内容寻址 CJS | bundleFacets |
| src/node/manifest.ts | bundle/artifact 清单常量 | FACET_BUNDLE_* |
| src/node/bundle-loader.ts | 清单校验+node:vm 编译加载 | createFacetBundleLoader |
| src/node/package.ts | 按 package.json 约定打包插件包 | bundleFacetPackage |

## 5.4 packages/codemode（10 文件）

| 文件路径 | 职责 | 关键导出 |
|---|---|---|
| src/index.ts | 公共 API 面 | 见 4.2 |
| src/types.ts | 工具/结果/错误/沙箱选项类型 | CodemodeTool、CodemodeResult、CodemodeError 等 |
| src/wasm.ts | QuickJS wasm 单次编译缓存 | loadQuickJSWasm |
| src/identifier.ts | 工具名→合法 JS 标识符 | toCodemodeIdentifier |
| src/source.ts | `// @options:` 解析 + Lark 文法 | parseCodemodeSource、CODEMODE_SOURCE_GRAMMAR |
| src/declarations.ts | 工具 schema→TS 声明渲染 | renderDeclarations、MCP_TYPESCRIPT_PREAMBLE |
| src/runtime/host.ts | 宿主沙箱（worker 生命周期/超时/工具 RPC/桥校验） | CodemodeSandbox |
| src/runtime/worker.ts | worker 入口（QuickJS VM/bridge/prelude/编译执行/drain） | 模块副作用 |
| src/runtime/protocol.ts | host↔worker 消息类型与守卫 | WorkerData 等 |
| src/runtime/prelude-source.ts | VM 内预置 JS（lockdown/tools/globals/输出与 store 限额/image 校验） | PRELUDE_SOURCE、限额常量 |

## 5.5 packages/mcp（18 文件）

| 文件路径 | 职责 | 关键导出 |
|---|---|---|
| src/client.ts | MCP 客户端（initialize 协商/超时取消/翻页/反向请求） | McpClient |
| src/auth-provider.ts | Bearer 令牌供给接口 | AuthProvider、McpFetch |
| src/index.ts | 门面 | 全部公共 API |
| src/protocol/jsonrpc.ts | JSON-RPC 消息判别/解析/错误 | parseJsonRpcMessage、McpError 族 |
| src/protocol/types.ts | MCP 协议类型与版本 | LATEST_PROTOCOL_VERSION |
| src/protocol/content.ts | 内容块类型与 LLM 转换 | CallToolResult、toLlmContent |
| src/transports/transport.ts | 传输接口+事件基类（消息上限） | McpTransport |
| src/transports/stdio.ts | 子进程 stdio 传输（进程组/taskkill/优雅关闭） | StdioTransport |
| src/transports/streamable-http.ts | HTTP 传输（SSE/Last-Event-ID 续传/重连/会话） | StreamableHttpTransport |
| src/transports/in-memory.ts | 测试内存对传输 | InMemoryTransport |
| src/oauth/flow.ts | 授权码/PKCE/刷新/动态注册/适配 AuthProvider | authorizeMcp、adaptOAuthProvider |
| src/oauth/discovery.ts | PRM/授权服务器元数据发现 | discoverOAuthServerInfo |
| src/oauth/callback.ts | 本地回调 HTTP 服务器 | OAuthCallbackServer |
| src/oauth/provider.ts | 有状态默认 provider（按 server 隔离） | McpOAuthProvider |
| src/oauth/types.ts / errors.ts / index.ts | 类型与结构化校验 / 错误类 / 门面 | — |
| src/testing/index.ts | 测试门面 | re-export in-memory |

## 5.6 packages/protocol（8 文件）

| 文件路径 | 职责 | 关键导出 |
|---|---|---|
| src/protocol.ts | 消息信封 TypeBox schema | ClientMessageSchema、ServerMessageSchema、PROTOCOL_VERSION=8 |
| src/framing.ts | 4B 大端长度前缀分帧 | encodeFrame、FrameDecoder |
| src/codec.ts | 校验+CBOR+帧组合编解码（增量解码） | encode/parseClient(Server)Message、两 Decoder |
| src/cbor/encoder.ts / decoder.ts / index.ts / options.ts | 手写 CBOR（自扩缓冲；限深限量） | encodeCbor、decodeCbor、DEFAULT_MAX_CBOR_* |

## 5.7 packages/client（8 文件）

| 文件路径 | 职责 | 关键导出 |
|---|---|---|
| src/client.ts | RPC 客户端+chord 传输适配（订阅 wire 排队） | Client、createClientServiceTransport |
| src/connection.ts | 连接状态机与握手（serverId 校验/generation 防污染） | Connection |
| src/transport.ts / types.ts / errors.ts / promise.ts | 字节传输抽象 / 选项状态 / 错误类 / withResolvers 兼容 | ByteTransport、ConnectionState 等 |
| src/unix.ts | Unix socket 传输与服务器发现 | discoverUnixServers、createUnixTransportFactory |
| src/index.ts | 门面 | — |

## 5.8 packages/server（16 文件）

| 文件路径 | 职责 | 关键导出 |
|---|---|---|
| src/server.ts | 服务器主体（握手 5s/分发/取消/订阅编码+pending 补发） | Server |
| src/session-router.ts | Session attachment 路由与操作序列化 | SessionRouter |
| src/connection.ts / listener.ts / types.ts / errors.ts / index.ts | 连接与状态 / 监听接口 / ServerHost 契约 / 跨协议错误 / 门面 | ByteConnection、ServerHost 等 |
| src/transports/unix/{listener,address,preset,types,index}.ts | Unix 监听器（原子绑定+0600）与地址/预设 | createUnixListener |
| src/testing/{server,host,client,index}.ts | 测试服务器工厂/Session harness/线协议测试客户端 | createTestServer、ProtocolTestClient |

## 5.9 packages/env（6 文件）

| 文件路径 | 职责 | 关键导出 |
|---|---|---|
| src/connection.ts | daemon 二进制帧客户端（PING 保活/会话/取消） | Connection、RemoteError |
| src/remote-env.ts | 远程 ExecutionEnv（Node 语义对齐） | RemoteExecutionEnv、remotePath |
| src/ssh.ts | SSH 目标/部署/平台探测/主机密钥 | connectSsh、deployDaemon |
| src/watch.ts | daemon 侧文件监视+断线重开 | RemoteWatcher |
| src/errors.ts | RemoteError→FileError 映射 | toFileError |
| src/index.ts | 门面 | — |

## 5.10 packages/telemetry（6 文件）

| 文件路径 | 职责 | 关键导出 |
|---|---|---|
| src/index.ts | 契约+类型级 schema+类型化 starter | TelemetryContext、defineTelemetrySchema、createTypedSpanStarter |
| src/memory.ts / noop.ts | 内存记录 / 空实现 | InMemoryTelemetryContext、NOOP_* |
| src/testing/{conformance,types,index}.ts | 适配器一致性套件/fixture/门面 | createTelemetryAdapterConformance |

## 5.11 packages/evals（5 文件，private）

| 文件路径 | 职责 | 关键导出 |
|---|---|---|
| src/harness.ts | 隔离运行 harness（独立 HOME/凭据拷贝/uid-gid 沙箱/文档变体） | createPiCodingAgentHarness、createPiDocumentationEvalHarness |
| src/plan.ts | 用例发现与任务计划（变体交叉排序对冲位置偏差） | createTaskPlan、DOCUMENTATION_VARIANTS |
| src/docker.ts | Docker 镜像构建/用例发现/容器内执行 | buildImages、runTask |
| src/report.ts | 配对观察汇总与对比报告（lift/flaky/saturated） | summarizeEvalObservations、formatEvalComparisonReport |
| src/cli.ts | eval:docs 命令入口 | main（未导出） |

## 5.12 packages/tui（45 文件）

| 文件路径 | 职责 | 关键导出 |
|---|---|---|
| src/tui.ts | 核心：Component/Container/TuiBase（节流、焦点、overlay 合成、终端颜色查询、鼠标分发） | Component、TUI、CURSOR_MARKER、compositeTuiLine |
| src/tui-main-screen.ts | 主屏渲染器（行级 diff、分块输出、图像 diff 联动、硬件光标） | TuiMainScreen |
| src/tui-alt-screen.ts | 全屏渲染器（布局帧、SGR 鼠标、文本选择、搜索、flash、图像 LRU） | TuiAltScreen |
| src/terminal.ts | 终端抽象（raw mode、Kitty 协议协商、Windows VT、OSC 进度） | Terminal、ProcessTerminal |
| src/terminal-image.ts | 能力探测与图像协议（Kitty/iTerm2 编码、尺寸/裁剪/网格、OSC 8） | detectCapabilities、renderImage、encodeKitty |
| src/keys.ts | 键盘解析（Kitty CSI-u + legacy 表 + 数字键盘归一） | matchesKey、parseKey、Key |
| src/keybindings.ts | 键位注册表（默认表/覆盖/冲突检测） | KeybindingsManager、TUI_KEYBINDINGS |
| src/stdin-buffer.ts | stdin 粘粘缓冲（转义序列拆分、bracketed paste 重组） | StdinBuffer |
| src/colors.ts / oklab.ts / terminal-colors.ts | 颜色模型（OKHSL/gamut/混色/降级）/ OKLab 数学 / OSC 10/11/4 应答解析 | Color 族、parseOscColorResponse |
| src/layout.ts / layout-node.ts | 全屏布局引擎（盒树、渲染缓存、栈分配、命中查询）/ 布局协议 | renderLayoutFrame、LAYOUT_NODE |
| src/utils.ts | 文本度量（visibleWidth/wrapTextWithAnsi/sliceByColumn/grapheme） | 全部工具 |
| src/autocomplete.ts / fuzzy.ts | 自动补全协议与 provider / 子序列模糊匹配打分 | AutocompleteProvider、fuzzyMatch |
| src/word-navigation.ts / kill-ring.ts / undo-stack.ts / wheel-scroll.ts | 词级导航（Intl.Segmenter）/ Emacs kill-yank / 撤销栈 / 滚轮加速度 | 各类 |
| src/latex.ts | LaTeX→Unicode 文本渲染器（1500 行） | renderLatex |
| src/alt-screen-search.ts | transcript 搜索（索引缓存/匹配段/搜索框组件） | AltScreenSearchComponent |
| src/editor-component.ts | 可替换编辑器接口（扩展接 vim/emacs） | EditorComponent |
| src/native-platform.ts / native-module-path.ts / native-modifiers.ts | native 加载（prebuilds 多候选）/ 路径解析 / 修饰键查询 | getNativeClipboard 等 |
| src/components/editor.ts | 多行编辑器（词换行/粘贴标记/history/补全） | Editor |
| src/components/input.ts | 单行输入（水平滚动） | Input |
| src/components/markdown.ts | Markdown 渲染（LaTeX 扩展/表格列宽/WeakRef 缓存） | Markdown |
| src/components/scroll-view.ts | 滚动视口状态机（follow-end/overscroll 链） | ScrollView |
| src/components/stack.ts / h-stack.ts / v-stack.ts | 栈布局基类（grow/shrink 分配）与两方向实现 | Stack、VStack、HStack |
| src/components/{box,text,truncated-text,spacer}.ts | 基础展示组件（内边距/背景/缓存/单行截断/空行） | Box、Text、TruncatedText、Spacer |
| src/components/image.ts | 图像组件（能力分流、Kitty PNG 转码缓存） | Image、setImageTranscoder |
| src/components/{loader,cancellable-loader}.ts | 旋转指示器（80ms 动画）/ 可中止版 | Loader、CancellableLoader |
| src/components/select-list.ts / settings-list.ts | 选择列表（过滤/环绕/双列）/ 设置列表（值循环/子菜单/搜索） | SelectList、SettingsList |
| src/components/mouse-region.ts / alt-screen-flash.ts | 鼠标装饰器 / 全屏瞬时消息栈 | MouseRegion、AltScreenFlashContainer |
| src/index.ts | 公共 API（约 120 符号） | 见 4.1 |

---

## 5.13 packages/durable（65 文件）

| 文件路径 | 职责 | 关键导出 |
|---|---|---|
| src/types.ts | 全部持久化类型契约（Storage/Tx/Session/TaskRecord/Document，约 80 类型） | ROOT_CONVERSATION_ID 等 |
| src/ids.ts | ID/Seq 品牌（brand）类型铸造 | idFromNumber、seqFromNumber |
| src/tasks.ts / entries.ts | defineTask 包装 / 类型化转录条目 kind | defineTask、UserEntry 等 6 个内建 Entry |
| src/documents.ts | 文档定义/地址/迁移/base-delta 物化 | defineDoc、defineDocFamily、materializeDocument* |
| src/errors.ts | 领域错误 | ReadAfterWrite、StorageRejected、ConversationBusy |
| src/truncate.ts | 截断（2000 行/50KB 双限） | truncateHead(Of) |
| src/index.ts | 公共 API 汇出 | 见 4.12 |
| src/session/session.ts | Session 内核（变更线串行提交、文档缓存、毒化语义） | createSession、SessionImpl |
| src/session/transaction.ts | 一次原子提交（读后写检测、文档组装计划、adopt） | Transaction、TransactionHost |
| src/session/forks.ts | fork 的文档复制选择（asOf/current/initial） | prepareForkDocumentCopies |
| src/session/observation.ts | Session→Chord 桥（CommittedWatch 严格串行投递） | CommittedStateSource |
| src/harness/harness.ts | Harness 与 Conversation 句柄 | Harness.open、ConversationImpl |
| src/harness/scheduler.ts | 持久化任务调度器（1338 行核心：预约/决策/修复循环） | TaskScheduler |
| src/harness/generation.ts | 内建生成任务（prepare→request→tools 状态机） | GenerationTask、startRun、handOver |
| src/harness/tool.ts | 内建工具任务（两阶段 execute 意图、OutputBuffer/Progress） | ToolTask |
| src/harness/compaction.ts | 内建压缩任务（selectCut/estimateContext） | CompactionTask |
| src/harness/submissions.ts | 提交准入/等待/撤回（requestId 幂等） | Submissions、admitSubmission |
| src/harness/inbox.ts | pi.inbox 排队与边界放置（steer/followUp） | InboxDoc、prepareBoundary |
| src/harness/live.ts | pi.live 运行态文档（partial/工具 slot/run） | LiveDoc、endRun |
| src/harness/agent.ts | pi.agent 文档与 agent 解析（扩展/工具/段落合成） | AgentDoc、resolveAgent |
| src/harness/registry.ts | 扩展注册表（内建任务不可移除、同步快照） | createRegistry |
| src/harness/define.ts | 定义 DSL | defineExtension、defineTool、hook、section、wrapTool |
| src/harness/context.ts | 模型上下文推导（转录→TranscriptContext） | readContext、deriveContext |
| src/harness/prompt.ts | 位置式 system 提示与工具装载差量 | replaySections、planSystemEntries |
| src/harness/provider.ts / usage.ts | pi.provider 会话身份（UUIDv7）/ pi.usage 花费账本 | ProviderDoc、UsageDoc |
| src/harness/events.ts | AgentEvent 事件流（视图 ops 反译 delta 事件） | watchEvents、AgentEventStream |
| src/harness/view.ts / task-graph.ts | 会话结构视图挂载 / 任务图视图（挂载即建、随观察者消亡） | ConversationView、TaskGraphView |
| src/harness/output.ts | 有界输出缓冲与自适应进度提交 | OutputBuffer、Progress |
| src/harness/json.ts / util.ts | 叶级 JSON 赋值（省 delta）/ 等待器与扫描 | assignJson、Waiters |
| src/harness/types.ts | Harness 层类型（约 60 个） | — |
| src/storage/sqlite/storage.ts | SQLite 存储（BEGIN IMMEDIATE、文档化身校验、分支合并读） | SqliteStorage |
| src/storage/sqlite/node.ts | node:sqlite 适配（SerialOperationQueue、WAL、语句缓存） | openNodeSqliteStorage |
| src/storage/sqlite/database.ts / migrations.ts / index.ts | 可移植 SQL 门面 / 8 张 STRICT 表 schema 与迁移 / 门面 | SQLITE_MIGRATIONS |
| src/storage/memory.ts | 内存存储（全索引、写前深拷贝读后冻结） | MemoryStorage |
| src/storage/jsonl/{storage,node,index}.ts | JSONL 目录存储（主标记+边车、fsync、损坏毒化） | JsonlStorage |
| src/env/index.ts | 可移植执行环境契约（FileSystem+Shell+Result） | ExecutionEnv |
| src/env/node.ts | Node 本地实现（spill/窗口/超时/进程清理，约 600 行） | NodeExecutionEnv |
| src/env/node-watch.ts / decode.ts / line-scan.ts | 文件监视（native/polling）/ 精确流式 UTF-8 解码 / 有界行扫描 | NodeWatchOptions、StreamDecoder |
| src/tools/index.ts | durable 版 coding 工具集 | CodingTools |
| src/tools/{bash,edit,write,read}.ts | 四工具（经 ExecutionEnv 抽象，bash 流式窗口、edit 修理参数） | createBashTool 等 |
| src/tools/edit-diff.ts | diff/模糊匹配/补丁（与 coding-agent 同源，diff@8） | applyEditsToNormalizedContent |
| src/tools/{path-utils,env,file-mutation-queue,image}.ts | 路径归一 / 工具取环境 / 每文件串行化 / 图片 MIME | resolveToolPath 等 |
| src/testing/{storage-conformance,env-conformance,storage-benchmark,runner,assertions,types,index}.ts | 跨实现一致性套件与基准（57KB conformance） | registerStorageConformance 等 |

## 5.14 packages/coding-agent（299 文件）

### 5.14.1 src 根（7 文件）

| 文件路径 | 职责 | 关键导出 |
|---|---|---|
| src/cli.ts | bin 入口（setupCli + main） | —（执行体） |
| src/main.ts | CLI 总编排（子命令短路→运行时工厂→模式分派） | main、createSessionManager、buildSessionOptions |
| src/config.ts | 包自描述/安装检测/资产与用户目录路径 | getAgentDir、APP_NAME、VERSION、detectInstallChange |
| src/index.ts | SDK 公共出口（约 500 行再导出） | 见 4.13.8 |
| src/migrations.ts | 启动期一次性迁移 | runMigrations、migrateAuthToAuthJson |
| src/package-manager-cli.ts | pi install/remove/update/list/config 与自更新 | handlePackageCommand、cleanupManagedInstall |
| src/rpc-entry.ts | pi-rpc bin | —（执行体） |

### 5.14.2 src/core（60 文件）

| 文件路径 | 职责 | 关键导出 |
|---|---|---|
| core/agent-session.ts | 会话核心（约 4400 行，详见 4.13.2） | AgentSession、AgentSessionEvent、parseSkillBlock |
| core/agent-session-runtime.ts | 会话热替换宿主 | AgentSessionRuntime、createAgentSessionRuntime |
| core/agent-session-services.ts | cwd 绑定服务组装 | createAgentSessionServices、createAgentSessionFromServices |
| core/sdk.ts | 编程式会话工厂 | createAgentSession、CreateAgentSessionOptions |
| core/session-manager.ts | JSONL 会话树（1820 行） | SessionManager、buildSessionProjection |
| core/settings-manager.ts | 双层设置（1313 行，字段级增量写） | SettingsManager、Settings |
| core/model-runtime.ts | 模型/凭据/Provider 组合运行时（963 行） | ModelRuntime |
| core/model-resolver.ts | 模型解析/作用域/回退链 | resolveCliModel、resolveModelScope、findInitialModel |
| core/model-registry.ts | 扩展用同步门面 | ModelRegistry |
| core/model-config.ts | models.json 快照（typebox 校验深冻结） | ModelConfig.load |
| core/models-store.ts | 目录缓存存储（共享读缓存） | FileModelsStore |
| core/resource-loader.ts | 资源加载器（1159 行：包/扩展/skills/prompts/themes/上下文） | DefaultResourceLoader |
| core/package-manager.ts | npm/git 包解析安装（2463 行） | DefaultPackageManager |
| core/system-prompt.ts | 分节系统提示/归一化/diff | buildSystemPrompt、diffSystemPromptSections |
| core/skills.ts | Agent Skills 发现/校验/格式化 | loadSkills、formatSkillsForPrompt |
| core/prompt-templates.ts | /prompt 模板与参数替换 | loadPromptTemplates、expandPromptTemplate |
| core/slash-commands.ts | 内置斜杠命令元数据表 | BUILTIN_SLASH_COMMANDS |
| core/trust-manager.ts | trust.json 存取（父目录继承） | ProjectTrustStore |
| core/project-trust.ts | 信任决策流程 | resolveProjectTrusted |
| core/auth-storage.ts | auth.json 凭据存储 | AuthStorage、readStoredCredential |
| core/runtime-credentials.ts | --api-key 运行时覆盖层 | RuntimeCredentials |
| core/provider-composer.ts | 内置+models.json+扩展 Provider 组合 | composeModelProvider |
| core/provider-attribution.ts | 归因头合并 | mergeProviderAttributionHeaders |
| core/remote-catalog-provider.ts | pi.dev 目录 overlay（etag/304/4h） | withRemoteCatalog |
| core/virtual-models.ts | 虚拟模型路由目录 | withVirtualModels、isVirtualModel |
| core/messages.ts | 自定义消息类型+LLM 转换 | convertToLlm、BashExecutionMessage |
| core/mcp-servers.ts | MCP 配置校验/注册表/暴露等级 | validateMcpServerConfig、McpServerRegistry |
| core/compaction/compaction.ts | 压缩纯函数库（998 行） | compact、findCutPoint、estimateTokens |
| core/compaction/branch-summarization.ts | 树导航分支摘要 | generateBranchSummary |
| core/compaction/utils.ts / index.ts | 序列化/摘要提示词 / barrel | serializeConversation、FileOperations |
| core/cache-warmer.ts | prompt 缓存保温决策 | CacheWarmer、getCacheWarmingDelayMs |
| core/cache-stats.ts | 缓存未命中统计与成本估算 | computeCacheWaste、detectCacheMiss |
| core/bash-executor.ts | `!` 命令执行（流式/截断/临时文件） | executeBashWithOperations |
| core/exec.ts | 扩展用通用命令执行 | execCommand |
| core/event-bus.ts | 轻量发布/订阅 | createEventBus |
| core/nested-tool-calls.ts | 工具内嵌套调用（限额+串行） | NestedToolCallRunner |
| core/output-guard.ts | print/json stdout 接管 | takeOverStdout、writeRawStdout |
| core/http-dispatcher.ts | undici 全局 dispatcher/代理 | configureHttpDispatcher |
| core/keybindings.ts | 应用键位定义与迁移 | KEYBINDINGS、KeybindingsManager |
| core/footer-data-provider.ts | 底栏数据（git 分支/扩展状态） | FooterDataProvider |
| core/bug-report.ts / bug-report-upload.ts | bug 报告打包脱敏 / 上传 Radius | writeBugReportArchive、uploadBugReport |
| core/crash-log.ts | 崩溃记录与扩展归因 | recordCrash、findExtensionStackMatches |
| core/diagnostics.ts / settings-diagnostics.ts | 资源诊断类型 / 设置诊断转换 | ResourceDiagnostic、collectSettingsDiagnostics |
| core/pi-manifest.ts / source-info.ts | pi 包资源声明 / 资源来源描述 | readPiManifest、createSourceInfo |
| core/radius.ts / telemetry.ts / timings.ts / experimental.ts / defaults.ts | 网关常量 / 遥测开关 / PI_TIMING 打点 / PI_EXPERIMENTAL / 思考级别常量 | 各常量与函数 |
| core/session-cwd.ts / session-export.ts / usage-totals.ts / resolve-config-value.ts / auth-guidance.ts | 会话 cwd 检测 / JSONL 导出 / usage 累加 / `!cmd`·`${ENV}` 解析 / 认证提示文案 | 各函数 |
| core/index.ts | core 门面（面向 modes） | 见 4.13.8 |

### 5.14.3 src/core/tools（16+8 文件）

| 文件路径 | 职责 | 关键导出 |
|---|---|---|
| tools/bash.ts / powershell.ts | shell 工具（进程组/杀树/PI_* 注入/节流）+ PowerShell 变体 | createBashTool、BashOperations |
| tools/read.ts / write.ts / edit.ts | 读（图片/分页）/ 写（mkdir）/ 编辑（模糊 diff） | createReadTool 等、ReadOperations 等 |
| tools/edit-diff.ts | diff 引擎（精确→模糊匹配、unified patch、预览） | applyEditsToNormalizedContent、generateDiffString |
| tools/grep.ts / find.ts / ls.ts | rg 内容搜索 / fd 文件名搜索（git 感知）/ 目录列表 | createGrepTool 等 |
| tools/truncate.ts | 四策略输出截断（UTF-8 边界安全） | truncateHead/Tail/Middle/Line |
| tools/output-accumulator.ts | bash 流式累积（滚动窗口+溢出落盘） | OutputAccumulator |
| tools/file-mutation-queue.ts | 按 realpath 的同文件写串行化 | withFileMutationQueue |
| tools/path-utils.ts | 路径解析（~/macOS 截图变体回退） | resolveReadPathAsync |
| tools/render-utils.ts / tool-definition-wrapper.ts | 渲染公共件 / ToolDefinition⇄AgentTool 适配 | formatToolCallWithArgs、wrapToolDefinition |
| tools/index.ts | 工具门面与组合工厂 | createCodingTools、createReadOnlyTools |
| tools/renderers/{bash,read,edit,write,grep,find,ls,index}.ts | 各工具 TUI 渲染（执行前 diff 预览/流式预览/增量高亮；index 为门面省 17MB） | xxxRenderers |

### 5.14.4 src/core/extensions（8 文件）与 core/export-html（3 文件）

| 文件路径 | 职责 | 关键导出 |
|---|---|---|
| extensions/loader.ts | jiti 加载/发现/运行时骨架/API 事务 | discoverAndLoadExtensions、createExtensionAPI |
| extensions/jiti-loader.ts / jiti-static-loader.ts | Node 惰性 / Bun·SEA 静态 jiti 入口 | createJiti |
| extensions/runner.ts | ExtensionRunner（事件分发/上下文工厂/绑定宿主） | ExtensionRunner |
| extensions/types.ts | 扩展系统全部类型（ExtensionAPI 约 40 事件、ToolDefinition） | defineTool、isBashToolResult |
| extensions/virtual-modules.ts | 扩展可 import 的宿主虚拟模块表 | VIRTUAL_MODULES |
| extensions/wrapper.ts / index.ts | 扩展工具包装 / 门面 | wrapRegisteredTools |
| export-html/index.ts / ansi-to-html.ts / tool-renderer.ts | 会话→HTML 组装 / SGR→HTML / TUI 渲染器复用出 HTML | exportSessionToHtml、ansiToHtml |

### 5.14.5 src/modes（67 文件）

| 文件路径 | 职责 | 关键导出 |
|---|---|---|
| modes/index.ts / print-mode.ts / json-event.ts | 桶文件 / one-shot 模式 / 事件→JSON 线格式 | runPrintMode、toJsonEvent |
| modes/interactive/interactive-mode.ts | TUI 主模式（7073 行：主循环/30+斜杠命令/事件→组件） | InteractiveMode |
| modes/interactive/tui-renderer.ts / chat-viewport.ts | 渲染器工厂+Proxy 稳定引用 / 全屏版式 | createInteractiveTui、createChatViewport |
| modes/interactive/external-editor.ts / session-share.ts / bug-report.ts / model-search.ts / model-catalog-refresh.ts | $EDITOR 外部编辑 / /share 上传 / /bug 流程 / 搜索文本 / 并发刷新协调 | editInExternalEditor、shareSession |
| modes/rpc/{rpc-mode,rpc-client,rpc-types,jsonl}.ts | RPC 服务端（约 40 命令）/ 客户端 / 协议类型 / 严格 LF JSONL | runRpcMode、RpcClient、RpcCommand |
| modes/interactive/theme/{theme,theme-json,system-theme,theme-controller}.ts | 主题核心（全局单例/watcher）/ typebox 校验 / 终端配色生成 / 控制器 | initTheme、validateThemeJson |
| modes/interactive/components/（35 文件） | UI 组件：assistant-message、user-message、tool-execution、bash-execution、footer、status-indicator、custom-editor、diff、markdown-transform、mermaid、custom-message、custom-entry、compaction/branch-summary/skill-invocation-message、extension-{selector,input,editor}、bordered-loader、auth-url、login-dialog、oauth-selector、radius-login-selector、model-selector、scoped-models-selector、thinking-selector、settings-selector、settings-submenu、session-selector、session-selector-search、tree-selector、user-message-selector、trust-selector、config-selector、first-time-setup、theme-selector、show-images-selector、keybinding-hints、pi-logo、armin、earendil-announcement、easter-egg-3d(.lazy)、countdown-timer、dynamic-border、themed-text、visual-truncate、index | 各组件类（职责详见 4.13.5） |

### 5.14.6 src/cli（17 文件）

| 文件路径 | 职责 | 关键导出 |
|---|---|---|
| cli/args.ts | 手写参数解析+帮助 | parseArgs、Args、printHelp |
| cli/auth-command.ts / auth-check.ts / credential-print.ts | pi auth 子命令/就绪检查/凭据打印 | parseAuthCommand、checkProviderAuth |
| cli/config-selector.ts / session-picker.ts / startup-ui.ts | pi config TUI / --resume 选择器 / 启动期 TUI+首启向导 | selectConfig、selectSession、showFirstTimeSetup |
| cli/file-processor.ts / initial-message.ts / list-models.ts | @file 处理 / 初始 prompt 拼装 / --list-models | processFileArguments、buildInitialMessage |
| cli/project-trust.ts / setup.ts | 信任 UI 上下文 / 进程级初始化 | createProjectTrustContext、setupCli |
| cli/experimental/{cli,command,command-options,commands/client,commands/server}.ts | 实验命令框架（类型化 Command 类）与 server/client 定义 | cli、Command、clientCommand、serverCommand |

### 5.14.7 src/extensions（25 文件，4 内置扩展）

| 文件路径 | 职责 | 关键导出 |
|---|---|---|
| extensions/index.ts | 内置扩展清单（builtin/replaceable 标记） | builtInExtensions |
| extensions/codemode/{index,tool,execute,execute.lazy,renderer,worker}.ts | codemode 扩展：注册工具/描述目录学/沙箱执行器/渲染/打包 worker 入口 | createCodemodeExtension、executeCodemode |
| extensions/tool-search/{index,tool}.ts | tool-search 扩展：BM25 检索+按需激活 | createToolSearchExtension、Bm25Ranker |
| extensions/llama/{index,client,provider,ui,huggingface}.ts | llama.cpp 扩展：编排/REST+SSE 客户端/Provider 适配/全屏 TUI/HF 搜索 | llamaExtension、createLlamaProvider |
| extensions/mcp/{index,config,tools,resources,oauth,runtime,runtime.lazy,log,ui,cli,cli.lazy}.ts | mcp 扩展：编排（工具注册/等待/提示段）/mcp.json/工具适配/资源三件套/OAuth/连接运行时/日志//mcp UI/pi mcp CLI | createMcpExtension、McpServerConnection |

### 5.14.8 src/utils（37 文件）

| 文件路径 | 职责 | 关键导出 |
|---|---|---|
| utils/child-process.ts | 跨平台 spawn+管道尾部安全回收（waitForChildProcess） | spawnProcess、waitForChildProcess |
| utils/shell.ts | shell 发现/进程树击杀/输出消毒/PATH 注入 | getShellConfig、killProcessTree |
| utils/paths.ts | 路径规范化枢纽（~//mnt//file://） | normalizePath、getCwdRelativePath |
| utils/clipboard.ts / clipboard-command.ts / clipboard-image.ts | 剪贴板文本全平台矩阵 / 外部命令执行 / 图像读取 | copyToClipboard、readClipboardImage |
| utils/{photon,image-convert,image-process,image-resize,image-resize-core,image-resize-worker,exif-orientation,mime,tool-result-images}.ts | 图像管线：WASM 加载/转码/组合入口/门面/进程内缩放/worker/MIME 嗅探/结果归一 | processImage、resizeImage、detectSupportedImageMimeType |
| utils/syntax-highlight.ts / highlight-js.d.ts | highlight.js 封装+主题化渲染 / 类型垫片 | highlight、renderHighlightedHtml |
| utils/tools-manager.ts | fd/rg GitHub 按需下载（302 解析避 API 限额） | ensureTool、getToolPath |
| utils/management-http.ts / version-check.ts / pi-user-agent.ts | 幂等管理请求重试 / pi.dev 版本检查 / UA | fetchWithRetry、checkForNewPiVersion |
| utils/windows-self-update.ts / wsl.ts / open-browser.ts | Windows 原生依赖隔离 / WSL 检测 / 浏览器拉起 | quarantineWindowsNativeDependencies、isWSL |
| utils/git.ts | 扩展安装源 git URL 解析与防注入 | parseGitUrl、buildGitSource |
| utils/{output-files,zip,changelog,frontmatter,json,html,ansi,text,fs-watch,abort,sleep,deprecation}.ts | 统一临时输出(0600/wx) / 极简 ZIP / 变更日志 / frontmatter / JSONC / HTML 实体 / ANSI 剥离 / BOM / 容错 watch / Abort 竞速 / 可中止 sleep / 去重告警 | 各函数 |

### 5.14.9 src/experimental（46）+ src/bun（5）+ src/client（1）

| 文件路径 | 职责 | 关键导出 |
|---|---|---|
| experimental/cli.ts / commands.ts | 开发入口 / server·client 分发（PI_EXPERIMENTAL 门禁） | runExperimentalCommand |
| experimental/process.ts / source-resolver.ts | 内部进程 spawn 与角色协议 / tsconfig paths module hook | spawnInternalProcess |
| experimental/coordinator.ts / coordinator-entry.ts | 路由守护进程（可替换 server 的稳定端点） | ensureCoordinator、runCoordinatorProcess |
| experimental/server.ts / session-worker.ts / session-worker-manager.ts | 实验服务器 / 每会话 worker / server 侧记账 | startServer、runSessionWorkerProcess、SessionWorkerManager |
| experimental/session-catalog.ts | 会话目录 meta.json CRUD | listSessions、createSession |
| experimental/radius-auth.ts / radius-relay.ts | 网关凭证 / WebSocket 中继（host 复用/客户端重连） | RadiusRelayHost |
| experimental/client.ts / client-runtime.ts / client-tui.ts / client-tui-chat.ts | 非交互客户端 / 连接层（发现+自动激活）/ TUI 主体 / 会话视图 | runClient、openClientRuntime、runClientTui |
| experimental/plugin.ts | 插件公共 API 桶 | 各服务类型再导出 |
| experimental/plugins/{bundled,package}.ts | facet 双端加载 / esbuild 插件包构建+选择持久化 | createSessionPluginFacetLoader、createServerPluginPackage |
| experimental/services/（14 文件：agent-controller{,-provider}、models{,-provider}、sessions、plugins、presentation-ui、slash-commands{,-provider}、transcript{,-provider}、server、connection、worker） | 服务切片：defineService 契约 + provider 实现（详见 4.13.7） | 各 defineService token |
| experimental/durable/（7 文件：main、runtime、sessions、harness-setup、prompt、subagent、tui） | 单进程 durable 原型（崩溃恢复演示+前台 subagent） | openDurable、Subagent |
| experimental/vacation/（6 文件：main、runtime、sessions、harness-setup、tui、vacation） | durable 复制改造版（后台 subagent 两阶段任务演示） | Vacation、Research(defineTask) |
| bun/{cli,sandbox-env-setup,restore-sandbox-env,runtime-setup,quickjs-wasm.d.ts} | Bun 二进制启动垫片（env 恢复/OAuth 静态注册/wasm 路径） | restoreSandboxEnv |
| client/index.ts | pi-client 再导出 | export * |

**清单合计校验**：agent 6 + ai 194 + chord 29 + client 8 + codemode 10 + coding-agent 299 + durable 65 + env 6 + evals 5 + mcp 18 + protocol 8 + server 16 + telemetry 6 + tui 45 = **715**，与文件系统枚举一致。

---

# 第 6 章 关键函数深度解析

本章选取覆盖核心业务链路的 6 个函数/方法，给出带行号的代码片段与逐段解读（片段为真实源码节选）。

## 6.1 runLoop —— Agent 主循环（packages/agent/src/agent-loop.ts:176-321）

**签名**：内部函数，由 `runAgentLoop`（:102）以 `agentLoop(config)` 启动；config 为 `AgentLoopConfig`（钩子+streamFunction+事件的聚合）。

**代码**（agent-loop.ts:178-217，双层循环骨架）：
```ts
// Outer loop: continues when queued follow-up messages arrive after agent would stop
while (true) {
    let hasMoreToolCalls = true;
    // Inner loop: process tool calls and steering messages
    while (hasMoreToolCalls || pendingMessages.length > 0) {
        let preparedMessages: AgentMessage[] = [];
        if (lastCompletedTurn) {
            const nextTurnSnapshot = await config.prepareNextTurn?.(lastCompletedTurn);
            if (nextTurnSnapshot) {
                currentContext = nextTurnSnapshot.context ?? currentContext;   // 模型热切换点
                preparedMessages = nextTurnSnapshot.messages ?? [];
                config = { ...config, model: nextTurnSnapshot.model ?? config.model,
                    reasoning: ... nextTurnSnapshot.thinkingLevel ... };
            }
            // Preparation can be long-running (for example, compaction). Pick up steering
            // queued while it ran. Only poll again if the earlier poll returned nothing;
            // otherwise one-at-a-time mode would deliver two messages in this turn.
            if (pendingMessages.length === 0) {
                pendingMessages = (await config.getSteeringMessages?.()) || [];
            }
            await emit({ type: "turn_start" });
        }
        // Process prepared and queued messages before the next assistant response.
        for (const message of declareToolChanges(currentContext, [...preparedMessages, ...pendingMessages])) {
            await emit({ type: "message_start", message });
            await emit({ type: "message_end", message });
            currentContext.messages.push(message);
            newMessages.push(message);
        }
        pendingMessages = [];
```

**逐段解读**：
1. **外层 while(true)**：agent 自然停止后轮询 `getFollowUpMessages`（:302），有则作为 pendingMessages 继续内层——「追问队列」的实现。
2. **prepareNextTurn 钩子**（:186-200）：每轮开始前唯一允许整体替换 context/model/thinkingLevel 的位置。coding-agent 在此挂接 `_prepareNextTurnWithContext`（阈值压缩、系统提示与工具装载刷新，agent-session.ts:886）。注释明确说明「prepare 可能长时间运行（例如压缩），期间排入的 steering 要补捞，但仅在前一次 poll 为空时补捞，否则 one-at-a-time 模式会双投递」——这是并发正确性的关键细节。
3. **declareToolChanges**（:211-213，定义于 :333-363）：比较 transcript 已声明的工具集与 `context.tools` 的差集，必要时在首个非 system 消息前插入带 `toolsAdded/toolsRemoved` 的 system 消息——「工具装载以消息差量承载」设计的落点，配合 pi-ai SystemMessage 的增量字段保证 prompt cache 前缀稳定。
4. 内层后半（:219 起，见 4.10.2）：prepareRequest → streamAssistantResponse（消费 12 种流事件、partial 原位替换）→ stopReason 分派（error/aborted 硬退出 :245-256；length 时全部工具判错 :268；toolUse 时 executeToolCalls 并行执行 :270）→ finishTurn → turn_end → steering 轮询。
5. **副作用**：直接 push 到 `currentContext.messages`（调用方传入的快照副本）；真实状态写入延迟到 `Agent.processEvents`（事件规约），保证「循环内崩溃也可由事件流重建」。

## 6.2 applyEditsToNormalizedContent —— edit 工具的模糊匹配引擎（packages/coding-agent/src/core/tools/edit-diff.ts:300-362）

**签名**：`(content: string, edits: Edit[]) → { content: string; matches: ... }`（LF 归一化空间操作）。

**实现方式**（五步，行号见 4.13.3）：
1. 每个 edit 的 oldText/newText LF 归一（:300-310）；
2. `fuzzyFindText`（:207-245）：**先精确 indexOf，失败再进模糊空间**——`normalizeForFuzzyMatch`（:34-55）做 NFKC、行尾去空白、智能引号→ASCII、Unicode 破折号/特殊空格归一；
3. `countOccurrences` 在模糊空间计数，>1 报 duplicate（唯一命中约束）；
4. 按 matchIndex 排序检查**区间重叠**（:341-350）；
5. 命中后按索引**倒序替换**（:111-120，偏移稳定）；若任一 edit 用了模糊匹配，则整体改在归一化空间执行，再用 `applyReplacementsPreservingUnchangedLines`（:132-173）把「被触碰的行块」从归一化基底重写、**其余行从原文逐行拷回**——避免模糊匹配把全文都变成归一化字节（保留用户的原始空白/引号风格）。

**为什么需要**：模型复述 oldText 时常见「智能引号、行尾空白、Unicode 破折号」不一致（:1-30 注释列举真实失败案例）；纯精确匹配会导致无谓失败，纯模糊又会破坏未触碰内容。该两段式策略是编辑成功率与保真度的折中。**副作用**：无 IO（纯函数）；产出与原文相同则抛 no-change 错误。

## 6.3 iterateSseMessages + 主事件循环 —— Anthropic 方言 SSE 解析（packages/ai/src/api/anthropic-messages.ts:416-569, 663-859）

**实现方式**：
1. `iterateSseMessages`（:471-528）：**TextDecoder(stream:true) 增量解码 + 手写换行扫描**——`consumeLine`（:454-469）兼容 `\r`/`\n`/`\r\n` 三种换行；`decodeSseLine`（:416-440）按行累积 `event:`/`data:` 字段，空行触发 `flushSseEvent`。不依赖任何 SSE 库，也绕过 SDK 的流解析器（便于统一错误处理与 onPayload 钩子）。
2. `iterateAnthropicEvents`（:530-569）：过滤 6 种消息事件，`parseJsonWithRepair` 容错解析；校验最终必须有 `message_stop`（:566）。
3. 主循环（:663-859）：`message_start` **先取 usage**（:680-688——保证用户提前中断也有输入 token 计数）；`content_block_start/delta/stop` 以 provider 的 `event.index` 定位块（:739），工具调用参数经 partialJson 累积 + `parseStreamingJson` **增量解析**（:762-774），stop 时最终解析并删除 scratch 字段；`signature_delta` 追加 thinking 签名（:775-782）；`message_delta` 的 usage **仅覆盖非 null 字段**（容忍代理吞字段，:829-853），totalTokens 自行求和、thinking_tokens 记入 reasoning；stopReason 经 mapStopReason（:1613-1639）归一为统一枚举。
4. 中断/异常路径：catch 清理 scratch 字段并产出 stopReason=aborted/error 的完整 AssistantMessage（:887-897）——满足 StreamFunction「错误必须以流事件终止而非 throw」的公约。

## 6.4 estimateTokens 与 findCutPoint —— 压缩切点算法（packages/coding-agent/src/core/compaction/compaction.ts:298-500）

**estimateTokens**（:298，真实代码节选）：
```ts
export function estimateTokens(message: AgentMessage): number {
    let chars = 0;
    switch (message.role) {
        case "system": {
            chars = estimateTextAndImageContentChars(system.content);
            if (system.sections) { for (const section of Object.values(system.sections))
                if (section) chars += section.length; }        // 分节内容也计入
            if (system.toolsAdded) chars += JSON.stringify(system.toolsAdded).length;
            return Math.ceil(chars / 4);                        // 保守（高估）
        }
        // user/assistant 同样按内容块累加字符后 /4
```
算法是 **chars/4 启发式**（注释自述「保守、高估」），图片按 4800 字符常量（:276）；仅在**没有更新的真实 usage** 时使用——`estimateContextTokens`（:196）优先取最后一个有效 assistant 的真实 usage，只有尾部才用估算补齐（`estimateProjectedContextTokens` :227 在 usage 之后有 context_edit/compaction 时退回纯估算，防陈旧 usage）。

**findCutPoint**（:446，真实代码节选）：
```ts
const cutPoints = findValidCutPoints(entries, startIndex, endIndex);   // 合法切点=回合边界，绝不在 toolResult
let accumulatedTokens = 0;
let cutIndex = cutPoints[0]; // Default: keep from first message (not header)
for (let i = endIndex - 1; i >= startIndex; i--) {           // 从最新往回累积
    const messageTokens = sessionEntryToContextMessages(entry).reduce(
        (sum, message) => sum + estimateTokens(message), 0);
    if (messageTokens === 0) continue;
    accumulatedTokens += messageTokens;
    if (accumulatedTokens >= keepRecentTokens) {             // 超出保留预算
        // Prefer the closest valid cut point at or after this entry. If trailing
        // tool results exceed the budget by themselves, keep their preceding
        // assistant tool call instead of falling back to the first message.
        cutIndex = cutPoints.find((candidate) => candidate >= i) ?? cutPoints[cutPoints.length - 1];
        break;
    }
}
```
逐段解读：先算**合法切点集**（回合边界，`isRecoveryOmissionSuffix` :833-856 允许把被剔除的失败尝试包含进摘要区间）；从最新条目向旧累积 token，一旦超过 `keepRecentTokens` 预算，取「≥ 当前位置的最近合法切点」落刀——注释解释了为何不用兜底第一消息：尾部 toolResult 自己超预算时，宁可保留其前面的 assistant toolCall（保证工具调用对完整）。切在 assistant 中间时支持**拆分回合**（对 turn prefix 单独摘要，:942-955 专用提示词）。摘要生成 `generateSummaryWithUsage`（:696）统一走 `retryAssistantCall`、`cacheRetention:"none"`、maxTokens=min(0.8×reserve, model.maxTokens)，拒绝 toolCall/length 响应（:755-761）。

## 6.5 TaskScheduler 的预约-决策-修复三段式（packages/durable/src/harness/scheduler.ts）

**核心不变量**（:159-173）：「每个任务状态迁移都由变更线上一个串行化回调决定」——phase handler 在线外跑，但**预约（#reserve :699-742）、每 phase 前的同步 step（#step :853-959 内）、结局提交（#commitState :965-997）、崩溃修复（#reconcile :441-480）** 全部在 Session 单线程变更线上串行执行。

**三段式**：
1. **#reserve**：单笔提交内遍历 live 任务——跳过已有 invocation/仍在等待/completing 者；`#resolve`（:755-771）做定义版本匹配（同版直跑、新版走 migrate、missing/too_old/migration_failed 阻塞；abort 模式下阻塞任务直接 orphaned 终结）→ 写 `running` 并登记 invocation。
2. **#run→#step→#decide**：每次回到变更线先 `#step` 检查「任务已不是 running（terminal/completing/waiting）或正在关闭」则结束 invocation **不写任何东西**；`#decide` 应用规则：abort 标记→结束；phase 抛错→faulted；**无持久进展**（checkpoint JSON 深比较 `jsonEqual` :1326-1337）→faulted（防空转循环）；有进展且定义换新可接手→回写 pending 交棒。
3. **#reconcile**（崩溃后同样生效）：把持久记录**蕴含的意图**补齐——被取消 owner 之下补 abort 标记（`#belowCancelled` 沿所有权树向上、遇 background 边界停止）、failFast 联动、撤回排队输入、`#finalize` 把无存活被拥有工作的 completing 写成 terminal（循环至不动点 :496-513）。失败恢复标志位，下次提交重试——**磁盘上的崩溃残留由此修复循环收敛**。

**为什么这样设计**：任务代码（phase handler）可以任意崩溃，正确性不依赖它——状态机的每一步都先落盘（checkpoint），恢复时从 checkpoint 重放；「completing（结果保持）」状态让被拥有工作（子会话）不随父任务失败而丢失。

## 6.6 TuiMainScreen.doRender —— 终端行级差分渲染（packages/tui/src/tui-main-screen.ts:247-616）

**算法步骤**：
1. 渲染组件树得 `lines[]`；overlay 合成（tui.ts:1339-1411，按 focusOrder 逐行叠加且防图像行被覆盖）；提取光标标记；`applyLineResets` 给每行追加 `\x1b[0m\x1b]8;;\x07`（防样式/超链接泄漏到 shell，tui.ts:1413-1422）。
2. 全量重绘触发条件（:277-319,338-347,451）：首帧、宽度变化（换行布局失效）、高度变化（Termux 软键盘例外）、`clearOnShrink`、`firstChanged < prevViewportTop`（改动滚出视口无法回写）；否则走增量路径。
3. **行 diff**（:366-383）：与 `previousLines` 逐行字符串全等比较求 firstChanged/lastChanged；**纯追加**时把区间起点推到旧内容末尾（appendedLines，:377-383）。
4. 输出：整帧包同步输出 `\x1b[?2026h/l`；纯追加用 `\r\n`.repeat(scroll) 促终端滚屏（:463-475）；否则相对移动光标（`\x1b[nB/nA + \r + \x1b[2K`）只重写 `[firstChanged, lastChanged]` 区间（:489——单行变化如 spinner 不整屏闪烁）；内容收缩补 `\r\n\x1b[2K` 清旧行（:552-565）。写入经 `BoundedTerminalWriter` 1MiB 分块（:9,18-74，防单帧字符串超 V8 限制并保护代理对）。
5. 防御：行宽超终端宽度视为组件 bug——写 `pi-tui-crash.log` 后抛错（:517-544）；调试开关 PI_TUI_DEBUG_REDRAW 记录全量重绘原因。

**为什么行级 diff 而非字符级**：终端转义序列只能整行重写（`\x1b[2K`），行是最小重写单元；字符串全等比较对 1-2 行变化的常见场景（spinner、流式追加）代价 O(变更行) 而非 O(全屏)。

---

# 第 7 章 端到端调用链分析

## 7.1 链路一：`pi` 交互启动 → 就绪（文件:行号 序列）

```
src/cli.ts:5-6      setupCli(); main(process.argv.slice(2))
src/main.ts:573     main(args)
  :582              runAuthCommand（pi auth 子命令则在此终止）
  :620              parseArgs (cli/args.ts:72)
  :666              runMigrations (migrations.ts:305)
  :693              createSessionManager (main.ts:358 → session-manager.ts:1755+ 静态工厂)
  :717              new ProjectTrustStore (trust-manager.ts:210)
  :730-861          createRuntime 闭包
  :863              createAgentSessionRuntime (agent-session-runtime.ts:420)
     ├─ main.ts:748 SettingsManager.create (settings-manager.ts:417)
     ├─ main.ts:749 createAgentSessionServices (agent-session-services.ts:135)
     │    ├─ ModelRuntime.create (model-runtime.ts:215 → auth-storage.ts:347 + model-config.ts:294)
     │    ├─ DefaultResourceLoader.reload (resource-loader.ts:311 → package-manager.ts:812
     │    │    → extensions/loader.ts:849 发现+加载扩展 → skills.ts:414 → prompt-templates.ts:222)
     │    └─ model-runtime.ts:839 refresh({allowNetwork:false})
     ├─ main.ts:813 resolveModelScope (model-resolver.ts:372)
     ├─ main.ts:819 buildSessionOptions (main.ts:451)
     └─ main.ts:839 → agent-session-services.ts:214 → sdk.ts:181 createAgentSession
          ├─ sdk.ts:226  findInitialModel (model-resolver.ts:622)
          ├─ sdk.ts:316  new CacheWarmer (cache-warmer.ts:162)
          ├─ sdk.ts:393  new Agent({streamFn: → model-runtime.ts:715 streamSimple})
          └─ sdk.ts:443  new AgentSession (agent-session.ts:474；:501 订阅事件；:509 _buildRuntime)
main.ts:952         new InteractiveMode(runtime) → :983 run()
  interactive-mode.ts:1138 run → :936 init()
    :961 createChatViewport；:975 mountInteractiveTui；:991 ui.start()
    :1087 setupKeyHandlers；:1088 setupEditorSubmitHandler；:1092 rebindCurrentSession
  :1244-1252 while(true){ getUserInput():4206 → session.prompt() }   ← 就绪，等待输入
```

## 7.2 链路二：一次交互式消息的完整时序（用户键入 → agent 完成 → 渲染落盘）

```
用户键盘 ──► CustomEditor.handleInput (components/custom-editor.ts:88)
   │  扩展快捷键 → app.* 键位 → super.handleInput 编辑字符
   ▼ Enter（pi-tui Editor 触发 onSubmit）
setupEditorSubmitHandler (interactive-mode.ts:3179)
   │  依次匹配 30+ 内置斜杠命令 → `!`/`!!` bash(:3327) → 流式期间 steer(:3358) → 常规提交
   ▼ onInputCallback(text) (:3369)
getUserInput() resolve (:4206) ◄─ run() 主循环 await (:1247)
   ▼
AgentSession.prompt (agent-session.ts:1954)
   :1963 扩展命令 → :1979 input 事件 → :1994 skill/模板展开 (:2133→prompt-templates.ts:304)
   :2040 _checkCompaction(:2933)（必要时→:2714 compaction.ts:965 compact）
   :2048 before_agent_start（mcp 扩展注入提示段 mcp/index.ts:1062）
   :2091 _preparePromptAndToolLoadout（system-prompt.ts:217 diffSystemPromptSections 增量 patch）
   :2096 _runAgentPrompt(:1808) → Agent.prompt (agent.ts:371)
   ▼
runAgentLoop 内层 (agent-loop.ts:183)
   :186  prepareNextTurn → agent-session.ts:886（阈值压缩/提示刷新）
   :211  declareToolChanges 注入工具差量 system 消息
   :219  prepareRequest → agent-session.ts:775（会话投影 buildSessionProjection
         session-manager.ts:543 + 虚拟模型路由 model-runtime.ts:994）
   :242  streamAssistantResponse → sdk.ts:402 streamFn
   ▼
ModelRuntime.streamSimple (model-runtime.ts:715) → pi-ai ModelsImpl.stream (models.ts:876)
   → applyAuth(:842 → auth/resolve.ts:46 凭据链/OAuth 刷新)
   → 方言适配器 anthropic-messages.ts:571 stream
        transformMessages(api/transform-messages.ts:64) → convertMessages(:1308)
        → client.beta.messages.create(...).asResponse()（retryProviderRequest 重试）
        → iterateSseMessages(:471) → 主循环(:663-859) 逐事件 push
   ◄── AssistantMessageEvent 流（12 种）
agent-loop 消费：partial 原位替换 + emit message_update (:434-440)
   ▼ stopReason=toolUse
executeToolCalls (agent-loop.ts:508)
   prepareToolCall(:707)：prepareArguments → typebox 校验 → beforeToolCall
     → agent-session.ts:646 → ExtensionRunner.emitToolCall (runner.ts:1242)（扩展可 block）
   executePreparedToolCall(:820) → tool.execute（如 core/tools/read.ts:102-217）
   finalizeExecutedToolCall(:853)：afterToolCall 字段级合并 + 图片归一化
   toolResult 消息按源顺序补发 (:649-654) → 下一轮请求
   ▼ stopReason=stop
finishTurn → turn_end → agent_end (:320)
   ▼ 事件双向分叉（同一事件流）
[持久化] agent-session.ts:1090 _handleAgentEvent
   :1149 SessionManager.appendMessage(:1204) → _persist(:1172) appendFileSync JSONL
[渲染]  interactive-mode.ts:3386 handleEvent
   message_start(assistant):3487 → AssistantMessageComponent 流式创建
   message_update:3503 → updateContent 增量；新 toolCall → ToolExecutionComponent(:3510)
   tool_execution_*:3584-3628 → 工具组件状态机
   message_end:3538 → setArgsComplete（edit 工具触发 diff 预览）
   agent_settled:3645 → CacheWarmer 决策/延迟重放检查
   每步 footer.invalidate() + ui.requestRender() → tui-main-screen.ts:247 行级 diff 写终端
   ▼
控制回到 run() 循环，await 下一条输入
```

## 7.3 链路三：RPC 外部控制（SDK/嵌入场景）

```
外部程序 → RpcClient.start (rpc-client.ts:74) spawn `pi --mode rpc`
rpc-entry.ts:13 → main(["--mode","rpc"])
main.ts:950 → runRpcMode (rpc-mode.ts:54)
  attachJsonlLineReader (jsonl.ts:21) 挂 stdin（严格 LF 帧）
客户端写 {"type":"prompt","text":"..."} 
  → handleInputLine(:750) → handleCommand(:386 case "prompt" :394)
    → 立即启动 session.prompt 且 preflight 成功才回 response（不等待完成）
  → 会话事件经 toJsonEvent 逐行推 stdout(:355-360)，背压等待(:113-118)
客户端 onEvent 消费 message_update / tool_execution_* 流
  → RpcClient.waitForIdle(:471) 等 agent_settled → get_last_assistant_text 取结果
扩展 UI 桥：rpc-mode 发 extension_ui_request → 客户端回 extension_ui_response(:767-780)
```

## 7.4 链路四：durable 会话崩溃恢复（experimental 原型，packages/durable）

```
打开：Harness.open (harness/harness.ts:411) → TaskScheduler.open (scheduler.ts:231)
  :244-246 把遗留 running 任务改写 pending（保留 checkpoint）
提交：Conversation.submit → admitSubmission (submissions.ts:148)
  空闲→ appendEntry(UserEntry) + startRun(generation.ts:663) + createTask
  → Session.#runCommit (session/session.ts:404) → SqliteStorage.commit
    (storage/sqlite/storage.ts:162，BEGIN IMMEDIATE 原子落盘推进 seq) → #publish
流式：GenerationTask.request → streamResponse (generation.ts:364)
  partial 每 ≥100ms 节流 runtime.commit → scheduler.#gated(:1190) → 变更线
  → LiveDoc assignJson（delta 落 document_revisions）→ watchEvents 推 AgentEvent
工具：classify→startToolRound(:546) 建 ToolTask（owner=generation）
  → ToolTask.call (tool.ts:55)：先提交 {phase:"execute",arguments,replay} 意图(:85-90)
  → run()(:169) 执行（OutputBuffer/Progress 节流落 slot）→ settle(:372) append pi.tool-result
★ 崩溃：进程消失——磁盘已有条目/partial/slot/checkpoint/placed/run
重启恢复：TaskScheduler.open 把 running 归 pending → #reserve 重新预约
  generation 从 request checkpoint 恢复：convertPartial(:352) 把已提交 partial 转为
  aborted 助手条目再重发（重发用崩溃前固定的 streamOptions/cutoff）
  ToolTask 落在 execute 相位：存储与定义都 replay:"safe" 才重跑，否则 failed(:94-111)
  #reconcile(:441) 补齐未落地的级联中止与 completing 收尾
```

---

# 第 8 章 横切机制说明

## 8.1 错误处理与异常体系
- **StreamFunction 公约**（pi-ai types.ts:373-377）：同步抛错仅限鉴权缺失；流内错误必须以 `stopReason=error/aborted` 的流事件终止——上游 agent-loop 据此合成完整 assistant 消息（agent.ts:532-548），transcript 永不缺终态。
- **工具错误不炸循环**：prepareToolCall 任何异常转 immediate 错误结果（agent-loop.ts:769-775）；扩展 handler 抛错被 emit 捕获、emitError 通知且不中断其他扩展（runner.ts:1089-1118），唯 user_bash handler 抛错 rethrow（有意）。
- **可重试错误**：AgentSession._prepareRetry（:3747）指数退避 + `_omitRecoveryAttempt` 把失败尝试从上下文剔除后重试（配合压缩防上下文中毒）；pi-ai retryProviderRequest 解析 retry-after。
- **领域错误类**：durable 三错误（ReadAfterWrite/StorageRejected/ConversationBusy，StorageRejected 是唯一保证无副作用的可恢复错误）；chord RemoteServiceError 带错误码可跨协议；server 端 ServerError 族显式标注可跨边界。
- **毒化模式**：durable Session 落盘成功但采纳失败即毒化（拒绝后续一切操作，必须重开）；coding-agent SettingsManager 写错误进 errors 队列供 UI 拉取而非抛出。

## 8.2 日志与诊断
- 无传统 logger 门面；诊断输出走 stderr（print/json 模式经 output-guard 把 stdout 写转发 stderr，保证 stdout 纯净）。
- PI_TIMING=1 启动耗时打点（core/timings.ts）；PI_TUI_DEBUG / PI_TUI_DEBUG_REDRAW 渲染调试；pi-tui 崩溃写 pi-tui-crash.log。
- crashes.json 环形 5 条崩溃记录 + 栈归因到扩展文件（core/crash-log.ts:71）；/bug 打包（脱敏 redactUrl/redactJsonValue）上传 Radius；mcp 扩展独立 mcp.log 追加+轮转。
- AssistantMessage.diagnostics 与请求诊断结构（pi-ai utils/diagnostics.ts）把 provider 层异常随消息持久化。

## 8.3 配置管理（多来源合并）
- 三层 Settings（全局/项目(需信任)/运行时覆盖）+ 深合并 + defaultTools 修饰符（settings-manager.ts:225-247）。
- 配置值支持 `!command` 与 `${ENV}` 模板（resolve-config-value.ts，进程级命令缓存）——auth.json 的 api_key 也支持。
- models.json（用户级 Provider/模型覆盖）→ provider-composer 组合；mcp.json（全局+项目，项目可做仅覆盖条目）。
- 环境变量全景：PI_OFFLINE / PI_EXPERIMENTAL / PI_TIMING / PI_OAUTH_CALLBACK_HOST / PI_SESSION_ID 等（bash 工具注入）/ 各厂商 key（env-api-keys.ts）。
- 启动迁移 runMigrations（auth→auth.json、键位、settings 字段改名）保证旧用户目录兼容。

## 8.4 权限与安全控制
- **产品刻意不内置权限系统**（README.md:88-96）：默认以启动用户权限运行；建议容器化（Gondolin/Docker/OpenShell 三模式文档）。
- 但拦截点齐备：`tool_call` 事件可返回 `{block, reason, terminate}`（agent-session.ts:646→runner.ts:1242）；ToolAnnotations（readOnlyHint/destructiveHint）供权限扩展决策（extensions/types.ts:515）；嵌套调用同样过 beforeToolCall（agent-loop.ts:804 注释）。
- **项目信任**：未信任项目不读其 .pi/settings.json、不加载其扩展/skills/prompts（trust-manager.ts + project-trust.ts 决策链）。
- 供应链：依赖精确锁版 + install-lock + 生命周期脚本白名单（README.md:126-138、AGENTS.md:43-50）。
- 凭据安全：auth.json 0600；环回 OAuth 限 127.0.0.1 + state/防重放；verification_uri 强制 http(s)；刷新在 store 锁内且忽略取消（防丢轮换 token）；codemode 沙箱四层隔离；CBOR/JSON-RPC 解码限深限量。

## 8.5 并发与异步模式（项目统一惯例）
- **串行化队列（promise tail 链）**：SettingsManager 写队列、durable Session 变更线、Models 凭据操作 per-provider 链、InMemoryCredentialStore modify、pi-client promise 链——全仓库统一模式。
- **世代/代际号防竞态**：Models refresh generation（陈旧刷新不覆盖）、ExtensionRunner generation（会话替换后旧 ctx stale）、client Connection generation（旧 transport 事件不污染新连接）、mcp 扩展 generation。
- **AbortSignal 全链贯通**：用户中断→Agent AbortController→工具 signal→bash 杀树→pi-ai 请求 signal；AbortSignal.any 合并（management-http）。
- **背压**：pi-ai EventStream 等待者队列；print/rpc 模式 stdout 写等待；chord 订阅 100 帧溢出 reset 快照。
- **并行工具执行**：默认并行（Promise.all，结果按源顺序补发），sequential 工具或全局设置时串行。
- **节流**：bash 输出 100ms、durable partial 100ms + 单 commit 在飞、TUI 渲染 16ms、cache warmer 保温定时。

## 8.6 缓存
- **prompt cache 经营**是显式产品能力：cache_control 打点（anthropic）、prompt_cache_key 截断（openai）、promptCacheKey 复用 sessionId（mistral）、系统提示 diff 更新（保前缀）、CacheWarmer 保温（90% TTL，收益公式 `0.15×missCost − warmCost ≥ $0.05`，cache-warmer.ts:20-26，扩展可改判）、cache-stats 未命中成本估算。
- 文件/数据缓存：models-store.json 目录缓存（mtime+size 指纹）、models.dev 远端 etag/304、jiti 转译缓存（mtime）、组件渲染缓存（text,width）、Markdown WeakRef token 缓存、Kitty 图像转码 LRU、codex WS 会话缓存（session-resources 清理）。

## 8.7 定时任务
- 无 cron 类设施。定时性行为由以下机制承担：CacheWarmer TTL 保温定时、版本检查/包更新（启动后台任务 interactive-mode.ts:1141-1173）、models 目录 4h 刷新间隔（remote-catalog-provider.ts）、coordinator/server 空转自杀宽限（experimental）、durable 调度器的等待/重试计时（runtime.sleep 分段计时器）。

---

# 第 9 章 外部依赖说明

| 依赖 | 用途 | 使用位置 | 替代/关键实现点 |
|---|---|---|---|
| `undici` | HTTP 调度（全局 dispatcher、EnvHttpProxyAgent、WebSocket 中继） | coding-agent core/http-dispatcher、experimental/radius-relay | Node 内建 fetch 的对齐层；install() 规避 Node 26 压缩 bug |
| `jiti`（+jiti/static） | 运行时转译加载用户 TS 扩展 | core/extensions/loader、jiti-*-loader | moduleCache:false 支撑 /reload 重求值 |
| `typebox` | 全仓库 schema 校验（工具参数/设置/协议信封/扩展注册） | 几乎所有包 | 编译期+运行时双用；constrained-sampling 基于它改写 strict schema |
| `@anthropic-ai/sdk` / `openai` / `@google/genai` | 三家官方 SDK（仅取客户端与类型） | pi-ai 对应方言 | 全部经 .lazy.ts 首调 import；Anthropic SSE 自解析不经 SDK 流 |
| `@aws-sdk/client-bedrock-runtime` + `@smithy/*` | Bedrock SigV4/中间件 | bedrock-converse-stream | 自定义头经 Smithy 中间件纳入签名 |
| `proper-lockfile` | 跨进程文件锁（settings/auth/trust/会话目录） | coding-agent 多处、experimental | stale 锁 + ELOCKED 重试惯例 |
| `quickjs-wasi` | QuickJS WASM 沙箱 | codemode | SAB 中断解决 Bun terminate 盲区 |
| `esbuild` | chord 插件打包（内容寻址 CJS） | chord/node | root devDep 亦用于 coding-agent bundle |
| `marked` | Markdown 解析 | tui Markdown、export-html | 自扩展 tokenizer（LaTeX/严格删除线/流式围栏） |
| `diff`（jsdiff） | 行 diff | edit-diff、durable tools、components/diff | 自制渲染层（上下文折叠/行号前缀） |
| `@silvia-odwyer/photon-node` | WASM 图像处理（缩放/转码/EXIF） | coding-agent utils/image-* | Bun readFileSync 补丁 |
| `cross-spawn` | Windows .cmd 兼容 spawn | utils/child-process、mcp stdio | — |
| `semver` / `minimatch` / `yaml` / `hosted-git-info` | 版本/通配/YAML/git URL | package-manager、model-resolver、frontmatter、git.ts | — |
| `chalk` | CLI 颜色（少量） | args/deprecation | TUI 内部用自研颜色系统 |
| `biome` / `typescript 7` / `vitest` / `husky` | 工程链（lint/类型/测试/git hook） | 根 devDeps | 排除范围，不展开 |

内部 workspace 依赖（`@earendil-works/*` 13 个）构成见 2.2 依赖图。

---

# 第 10 章 新人上手路径

## 10.1 建议阅读顺序（由浅入深）

1. `README.md` + `AGENTS.md`（工程规则）+ 根 `package.json`（构建顺序即依赖顺序）。
2. `packages/agent`（6 文件，pi 的心脏）：types.ts → agent-loop.ts → agent.ts。理解「系统提示/工具装载都在消息里」「钩子在循环的哪些位置」。
3. `packages/ai` 骨架：types.ts → models.ts → 一个方言（anthropic-messages.ts）+ transform-messages.ts + simple-options.ts；再浏览 providers/all.ts 与任一 15 行工厂（google.ts）理解 Provider 组装。
4. `packages/coding-agent` 入口：main.ts → sdk.ts → agent-session.ts（大文件，先读 prompt()/_runAgentPrompt/_handleAgentEvent 三段）→ session-manager.ts → settings-manager.ts。
5. 工具层：core/tools/index.ts → read.ts → edit.ts + edit-diff.ts → bash.ts + output-accumulator.ts。
6. 扩展系统：core/extensions/types.ts（API 面）→ loader.ts → runner.ts；再读一个内置扩展（tool-search 最小、mcp 最全）。
7. 模式层：modes/print-mode.ts（最小）→ rpc/rpc-mode.ts → interactive-mode.ts（最大，按 init/run/handleEvent/submitHandler 分块读）。
8. 按需深入：tui（渲染器两文件 + utils.ts）、durable（scheduler.ts + generation.ts）、experimental（services/README.md 起步）。

## 10.2 常见修改需求的切入点

- **加/改一个内置工具**：`core/tools/<tool>.ts` 定义 ToolDefinition → 在 `core/tools/index.ts` 的 ToolName 与 createAllToolDefinitions 注册 → TUI 卡片加 `renderers/<tool>.ts` 并在定义里展开 → （若要默认开启）检查 `settings-manager.ts` DEFAULT_TOOL_NAMES 与 `--tools` 过滤逻辑。
- **加一个斜杠命令**：内置命令在 `interactive-mode.ts` setupEditorSubmitHandler（:3179 起）加匹配 + 实现；若要可被 RPC/SDK 消费则做成**扩展命令**（`pi.registerCommand`），getCommands 自动聚合（agent-session.ts:3347）。
- **加一个 LLM Provider**：pi-ai `providers/<id>.ts` 工厂（参照最简 google.ts；需要 compat 开关则扩展 openai-completions detectCompat）+ `<id>.models.ts`（由 scripts/generate-models.ts 从 models.dev 数据生成，勿手改 models.generated.ts——AGENTS.md:28）。
- **加一个 API 方言**：`api/<dialect>.ts`（实现 stream/streamSimple）+ `.lazy.ts` 工厂 + types.ts KnownApi + 方言注册（注意 compat.ts 的 registerBuiltInApiProviders）。
- **加扩展可拦截点/事件**：core/extensions/types.ts 事件类型 → runner.ts emitXxx → agent-session.ts 挂接点（参考 tool_call 链）。
- **加一个定时/后台任务**：参照 interactive-mode.ts:1141-1173 启动后台任务模式（版本检查/目录刷新），或 CacheWarmer 的 TTL 定时；没有统一调度器。
- **改 TUI 渲染/组件**：pi-tui components/*；coding-agent 侧主题槽位在 modes/interactive/theme/theme-json.ts（~60 颜色槽）。

## 10.3 隐性约定与易踩坑点

1. **仅可擦除 TS 语法**（Node strip-types 运行）：禁 enum/namespace/参数属性/`export =`（AGENTS.md:24）；显式字段+构造器赋值。
2. **禁内联动态 import**（AGENTS.md:21）——但 pi-ai 的 .lazy.ts 是**架构级例外**（首调加载是设计的一部分）；写新代码用顶层 import。
3. `packages/coding-agent` 里解析包资产一律走 `core/config.ts` 的 helpers，不要直接 `__dirname`（源码/npm/独立二进制三种形态）。
4. `models.generated.ts` 永远重新生成而不是手改。
5. 输出治理三件套：模型可见文本默认 2000 行/50KB（truncate.ts 常量）；程序消费走 structuredContent；stdout 在 print/json/rpc 模式是协议线（output-guard），诊断一律 stderr。
6. 会话首条用户消息前不落盘（#10000）；「模型看到的上下文 = 会话投影（buildSessionProjection）」——直接改 transcript 不会反映到模型。
7. 凭据优先级：auth.json 独占 provider，env 只兜底；`--api-key` 是不落盘的运行时覆盖层——测试时三者叠加容易误判。
8. 并发写入同一文件必须走 `withFileMutationQueue`；跨进程文件必须走 proper-lockfile 惯例（stale + 重试）。
9. Windows 细节多：taskkill 绝对路径、PowerShell UTF-8 前缀、cross-spawn、VT 输入、自更新隔离（windows-self-update）——改 shell/进程相关代码要在 Windows 验证。
10. 扩展与宿主同权：第三方可顶替内置扩展（replaceable），改内置扩展行为时先想「会不会被顶替」。
11. experimental 代码不进产物：改它不影响发布版；反之发布版问题别去 experimental 找。
12. 测试：默认 `./test.sh`（自动跳过需 key 的 e2e）；不要直接跑全量 vitest；coding-agent/test/suite 用 faux provider。

---

# 附录 A 全报告总目录（章节 ↔ 交付批次对照）

| 章节 | 内容 | 批次 |
|---|---|---|
| 交付说明与批次计划 | 分批执行记录 | 1 |
| 第 0 章 | 术语表 | 1 |
| 第 1 章 | 项目概述（用途/技术栈/运行方式） | 1 |
| 第 2 章 | 整体架构（分层图/依赖图/核心数据流） | 1 |
| 第 3 章 | 目录结构详解 | 1 |
| 第 4 章 4.1~4.9 | 基础层九包（tui/codemode/chord/protocol/client/server/env/telemetry/mcp） | 2 |
| 第 4 章 4.10~4.12 | 中间层（agent/ai/durable） | 3 |
| 第 4 章 4.13 | 业务层 coding-agent（入口/core/tools/扩展/模式/cli/utils/experimental/SDK） | 4 |
| 第 5 章 5.1~5.14 | 文件清单总表（715 文件全覆盖） | 4 |
| 第 6 章 | 关键函数深度解析（6 个） | 5 |
| 第 7 章 | 端到端调用链（4 条） | 5 |
| 第 8 章 | 横切机制（错误/日志/配置/安全/并发/缓存/定时） | 5 |
| 第 9 章 | 外部依赖说明 | 5 |
| 第 10 章 | 新人上手路径 | 5 |
| 附录 B/C | 完成度自检 / 存疑清单 | 5 |

# 附录 B 完成度自检表

| 检查项 | 状态 | 说明 |
|---|---|---|
| 生产源文件全覆盖（715 个 src ts） | ✅ | 第 5 章逐包表格；合计校验行与文件系统枚举一致 |
| 生成代码处理 | ✅ | ai/src/models.generated.ts 单列说明来源与生成管线，未逐行分析（构建产物性质，AGENTS.md:28 亦禁止手改） |
| .d.ts 类型垫片（4 个） | ✅ | 清单口径中说明：highlight-js.d.ts、quickjs-wasm.d.ts、data-json.d.ts 为第三方类型声明，无运行逻辑 |
| 包根特殊文件 | ✅ | ai/bedrock-provider.js+.d.ts 在 5.2.5 末注明 |
| 排除范围遵守 | ✅ | 未分析 test/examples/docs/dist/锁文件/CI 配置；.pi/ 目录（项目自用扩展/提示）作为 dogfooding 配置在 3 章目录树注释 |
| 行号引用 | ✅ | 全文结论均带 `文件:行号`；4 个深度解析片段为真实源码节选（6.1/6.4 经二次读取原文校验） |
| 事实/推断区分 | ✅ | 推断处均标注，汇总见附录 C |

# 附录 C 存疑与待确认清单

| # | 位置 | 存疑内容 | 性质 |
|---|---|---|---|
| 1 | pi-ai 包根 bedrock-provider.js/.d.ts | 「为 Bun 单文件构建提供静态 Bedrock 模块入口」为推断（依据 lazy.ts 的 setBedrockProviderModule 注释 + package.json exports 子路径） | 推断（高置信） |
| 2 | coding-agent cli/ | args.ts 手写解析与 cli/experimental Command 框架并存，「为未来迁移准备」为推断 | 推断 |
| 3 | core/extensions loader | jiti 转译缓存「由 jiti 内部按 mtime 管理」为推断（代码未见显式配置）；moduleCache:false 支撑 /reload 重新求值为推断 | 推断 |
| 4 | experimental process.ts:86-89 | bundled-Node 分支指向 dist/bundle/coordinator.js，但该文件不在发布 bundle——推断为曾计划接入发布或仓库内试验用途 | 推断 |
| 5 | durable scheduler/generation 注释 | 多处引用 "spec §5.4/§9.x" 等未随包发布的规范文档（推断位于仓库外部文档） | 推断 |
| 6 | pi-ai scripts/generate-models.ts | 数据源（models.dev/OpenRouter）仅核对 import 头部与生成产物，未逐行核对合并逻辑 | 部分验证 |
| 7 | bash 工具 | 「无后台进程常驻支持；后台化由会话持久化承担」为基于代码缺失的推断 | 推断 |
| 8 | pi-ai oauth.ts 旧回调契约 | 「适配层由 coding-agent 侧完成」——pi-ai 包内无调用方，未逐行验证 coding-agent 侧全部适配点 | 推断 |
| 9 | 行号精度 | 个别超大文件（agent-session.ts 约 4400 行、interactive-mode.ts 7073 行）的行号来自分块读取，极少数行号可能存在 ±2 行漂移；结构性结论（函数职责/调用关系）不受影响 | 低风险 |

---

*报告完。基于 pi-1.0.4 全量源码静态分析生成；未执行任何代码修改。*
