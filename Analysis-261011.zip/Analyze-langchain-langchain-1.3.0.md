# 《生产项目代码分析报告：langchain 1.3.0》

> 分析对象：`langchain-langchain-1.3.0/`（GitHub 仓库 langchain-ai/langchain 的 `langchain==1.3.0` 发布标签快照）
> 报告生成日期：2026-10-11
> 目标读者：从未接触过本项目的开发人员
> 约定：文中文件路径一律相对于仓库根目录 `langchain-langchain-1.3.0/`；行号引用格式为 `路径:行号`，均已在源码中核对。

---

## 0. 阅读说明与批次计划

### 0.1 分析范围界定

本仓库是 LangChain 的 **monorepo**，包含多个独立发版的子包。本次发布标签 `langchain==1.3.0` 的**分析主体**是：

- **`libs/langchain_v1/`** —— PyPI 包 `langchain` 1.3.0（v1 新架构），共 **31 个生产源文件、约 1.44 万行 Python**，本报告逐文件、逐函数分析。

仓库内其余目录为**独立发版的兄弟包**，按任务排除规则（外部库/独立交付物）不纳入逐文件分析，仅在第 1、3 章作仓库级说明：

| 目录 | 包名 | 本标签内版本 | 说明 |
|---|---|---|---|
| `libs/core` | langchain-core | 1.4.0 | 基础抽象层（消息/模型/工具），另有独立分析报告 `Analyze-langchain-langchain-core-1.6.9.md`（更新版本） |
| `libs/langchain` | langchain-classic | 1.0.7 | 旧版 0.x 架构的兼容包（导入名 `langchain_classic`） |
| `libs/text-splitters` | langchain-text-splitters | 1.1.2 | 文本切分 |
| `libs/standard-tests` | langchain-tests | 1.1.7 | 测试基建（测试类基础设施） |
| `libs/model-profiles` | langchain-model-profiles | 0.0.5 | 模型能力元数据 |
| `libs/partners/*` | langchain-openai 等 15 个 | 各自独立 | 第三方模型/向量库集成包 |

排除范围（依任务规则）：`tests/`、`scripts/`（CI 辅助脚本 `check_imports.py`/`check_version.py`，不承载运行逻辑）、`.github/`、`.vscode/`、锁文件、纯文档。

### 0.2 分批输出策略说明与批次计划表

本包逻辑模块数为 7（> 6），满足分批触发条件。但由于本报告的交付载体是**单个 Markdown 文件**（非对话逐条输出，无单次长度上限），全部批次已在本次交付中按序完成并写入同一文件。批次划分与状态如下（批次即本报告章节的实际撰写顺序）：

| 批次 | 覆盖模块/目录 | 覆盖章节 | 涉及文件数 | 状态 |
|------|--------------|----------|-----------|------|
| 1 | 全局总览 + 仓库级结构 | 第 1~3 章 + 本计划 | 31（清单层） | 已完成 |
| 2 | agents 核心（factory、structured_output） | 第 4.2 节 + 第 6 章（部分） | 2 | 已完成 |
| 3 | middleware 类型系统（types.py） | 第 4.3 节 | 1 | 已完成 |
| 4 | middleware 内置实现（15 个中间件 + 3 个私有支撑模块） | 第 4.4 节 | 18 | 已完成 |
| 5 | chat_models、embeddings、门面/重导出层 | 第 4.5~4.7 节 + 第 5 章 | 10 | 已完成 |
| 6 | 横切机制、调用链、依赖、上手路径 | 第 6~10 章 + 收尾三件套 | （引用前批结论） | 已完成 |

---

## 0.3 术语表

| 术语 | 解释 |
|---|---|
| **Agent（智能体）** | 以 LLM 为决策核心、在"调模型 → 执行工具 → 再调模型"循环中自主完成任务的程序。本包的 agent 即一个编译后的 LangGraph 图。 |
| **LangGraph / StateGraph** | LangChain 家族的低层图编排框架与运行时（外部依赖）。`StateGraph` 以状态模式（state schema）声明节点与边，`compile()` 后得到可 `invoke/stream` 的 `CompiledStateGraph`。 |
| **Middleware（中间件）** | 本包核心扩展机制：一个 `AgentMiddleware` 子类实例，通过实现钩子（hook）在 agent 循环的各阶段注入逻辑（改消息、限流、重试、审批等）。 |
| **Hook（钩子）** | 中间件可覆写的方法：`before_agent` / `before_model` / `wrap_model_call` / `after_model` / `after_agent` / `wrap_tool_call`（各有 async 版本，前缀 `a`）。 |
| **洋葱模型** | 多个 `wrap_model_call`/`wrap_tool_call` 的组合方式：列表中**第一个为最外层**，请求自外向内穿透，响应自内向外返回；中间件可重试（多次调 handler）、短路（不调 handler）。 |
| **State（状态）** | 图执行期间的可变数据，`AgentState` TypedDict：`messages`（对话消息，`add_messages` 归并）、`jump_to`（一次性跳转指令）、`structured_response`（结构化输出）。 |
| **Reducer（归并器）** | 状态字段的更新策略。`messages` 用 `add_messages`（按 id 增量合并/删除）；`jump_to` 用 `EphemeralValue`（跨超步即失效）；计数类的 run 级字段用 `UntrackedValue`（不写入检查点）。 |
| **Command / Send** | LangGraph 控制原语。`Command(update=...)` 声明状态更新；`Send("tools", [tool_call])` 向节点并行派发任务（map-reduce 式扇出）。 |
| **interrupt()** | LangGraph 人工介入原语：图执行暂停并持久化，等待外部以 `Command(resume=...)` 恢复。 |
| **Checkpointer / Store** | 分别为单线程（会话）状态持久化与跨线程共享存储，`create_agent` 参数透传给 LangGraph。 |
| **Runtime / Context** | `Runtime` 是 LangGraph 注入节点的运行时对象（携带 `context` 用户上下文、`store`、`stream_writer` 等）；`context_schema` 定义其 `context` 的类型。 |
| **ToolNode / ToolCallRequest** | LangGraph 预置的工具执行节点及其请求对象（含 `tool_call`、`tool`、`state`、`runtime`），`wrap_tool_call` 拦截的就是它。 |
| **结构化输出（structured output）** | 让模型按 schema 返回可解析对象的能力。本包三种策略：`ToolStrategy`（伪装成工具调用）、`ProviderStrategy`（厂商原生 JSON Schema）、`AutoStrategy`（按模型能力自动选）。 |
| **Model profile（模型档案）** | langchain-core `BaseChatModel.profile` 字段（数据来自 langchain-model-profiles），声明模型能力（如 `structured_output`、`max_input_tokens`），供自动决策。 |
| **Provider（提供商）** | 模型厂商（openai、anthropic 等）。`init_chat_model` 以 `provider:model` 字符串或显式 `model_provider` 指定，延迟导入对应 partner 包。 |
| **jump_to** | 中间件写入的状态指令（`"tools"|"model"|"end"`），由路由函数消费，实现"跳过工具直达结束"等控制流；需配合 `@hook_config(can_jump_to=[...])` 声明。 |
| **HITL** | Human-In-The-Loop，人工审批环节（`HumanInTheLoopMiddleware`）。 |
| **PII** | Personally Identifiable Information，个人敏感信息（`PIIMiddleware` 检测与脱敏）。 |
| **partner 包** | `libs/partners/` 下的官方集成包（如 `langchain-openai`），运行时按需导入，是可选依赖。 |

---

## 1. 项目概述

### 1.1 项目用途与业务背景

`langchain` 1.3.0 是 LangChain 框架的 **Python 主包**——"构建 LLM 应用与智能体（agent）的标准库"（`libs/langchain_v1/README.md:21`）。它不是可独立运行的应用，而是发布到 PyPI 的**框架库**，业务能力可从公共 API 归纳为四件事：

1. **`create_agent`**（`libs/langchain_v1/langchain/agents/factory.py:697`）：一句调用即可组装一个"模型-工具循环"智能体。用户给模型、工具、系统提示、中间件、结构化输出 schema，返回一个可 `invoke/stream` 的 LangGraph 图。
2. **中间件（middleware）体系**（`libs/langchain_v1/langchain/agents/middleware/`）：agent 的官方扩展点。包内自带 15 个生产级中间件（摘要、人工审批、PII 脱敏、shell 执行、限流、重试、降级、工具选择/模拟、todo 计划等），覆盖上下文管理、可靠性、安全、可观测四类横切关注点。
3. **`init_chat_model` / `init_embeddings`**（`chat_models/base.py:210`、`embeddings/base.py:191`）：以 `"openai:gpt-5"` 这类统一字符串初始化任意厂商的模型，运行时延迟导入 partner 包；支持运行时可配置模型（`_ConfigurableModel`）。
4. **统一门面重导出**：`langchain.messages`、`langchain.tools`、`langchain.rate_limiters` 等从 langchain-core / langgraph 转发稳定符号，让用户只面对单一包。

1.x 架构相对 0.x 的关键变化：旧版大量内置集成（链、记忆、检索器等）已移出到 `langchain-classic` / `langchain-community`，主包收敛为"agent 工厂 + 中间件 + 模型初始化"三件套，运行时底座完全交给 LangGraph（`pyproject.toml:31-34` 声明依赖 `langgraph>=1.2.0,<1.3.0`）。

### 1.2 技术栈清单

| 项 | 内容 | 依据 |
|---|---|---|
| 语言 | Python，支持 3.10–3.14 | `libs/langchain_v1/pyproject.toml:21,22` |
| 包管理/构建 | uv（dev）+ hatchling（build-backend） | `pyproject.toml:1-3`；`Makefile` 全部经 `uv run` |
| 运行时核心依赖 | `langchain-core>=1.4.0,<2.0.0`（本标签内实际为 1.4.0）、`langgraph>=1.2.0,<1.3.0`、`pydantic>=2.7.4,<3.0.0` | `pyproject.toml:30-34` |
| 可观测依赖 | `langsmith`（`traceable` 装饰器用于中间件钩子追踪） | `agents/factory.py:28` |
| 类型体系 | 大量使用 `typing_extensions`（`TypedDict/TypeVar/NotRequired/Required/Unpack/Self`）、PEP 695 前的 `Generic`、`Annotated` 元数据驱动 schema 合并 | `agents/middleware/types.py:37` |
| 可选依赖 | 26 组 extras，每组映射一个 partner 包（`anthropic`、`openai`、`google-genai` 等） | `pyproject.toml:36-56` |
| 质量工具 | ruff（lint select=ALL）、mypy strict、pytest 9 + pytest-asyncio/xdist/syrupy 快照/blockbuster | `pyproject.toml:105-152,62-84` |
| 测试基建 | 单测默认启 docker compose 起 Postgres/Redis（checkpointer/store 测试） | `Makefile:10-14` |

### 1.3 如何运行（库的使用与开发）

**作为库使用**（无进程入口，"入口"即公共 API）：

```bash
pip install langchain langchain-openai        # 或 uv add
```
```python
from langchain.chat_models import init_chat_model
from langchain.agents import create_agent

model = init_chat_model("openai:gpt-5", temperature=0)
graph = create_agent(model, tools=[...], system_prompt="...")
graph.invoke({"messages": [{"role": "user", "content": "hi"}]})
```
（示例来自仓库 `README.md:37-42` 与 `agents/factory.py:829-847`）

**作为开发者**（在 `libs/langchain_v1/` 下，`Makefile:111-129`）：

| 命令 | 作用 |
|---|---|
| `make test_fast` | 快速单测（内存 checkpointer，不起服务） |
| `make test` | 完整单测（docker compose 起 Postgres/Redis，socket 禁用） |
| `make integration_tests` | 集成测试（需真实 API key） |
| `make lint / format / type` | ruff + mypy strict |
| `make check_imports / check_version` | 每个文件可导入 / 版本一致性校验（CI 前置） |
| `make benchmark` | `create_agent` 基准测试 |

**配置方式**：包本身不读环境变量；模型凭证等由 partner 包按各自约定读取（如 `OPENAI_API_KEY`）。`[tool.uv.sources]`（`pyproject.toml:98-103`）把 langchain-core/tests/text-splitters/openai/anthropic 指向 monorepo 本地路径（editable），这是 monorepo 联调的关键配置。

---

## 2. 整体架构

### 2.1 架构风格与分层

本包是典型的**框架库 + 插件（中间件）架构**，无服务端/前端之分。自上而下分五层：

```
┌────────────────────────────────────────────────────────────────────┐
│ L5 用户 API 层                                                      │
│   langchain.agents.create_agent / langchain.agents.middleware.*    │
│   langchain.chat_models.init_chat_model / langchain.messages       │
│   langchain.embeddings.init_embeddings / langchain.tools / ...     │
├────────────────────────────────────────────────────────────────────┤
│ L4 组装层（本包核心）                                                │
│   agents/factory.py：把 model+tools+middleware+response_format      │
│   编排成 StateGraph（节点、条件边、Send 扇出、schema 合并）           │
│   agents/structured_output.py：三种结构化输出策略                    │
├────────────────────────────────────────────────────────────────────┤
│ L3 扩展层                                                           │
│   agents/middleware/types.py：AgentMiddleware 基类 + 请求/响应对象   │
│   agents/middleware/*.py：15 个内置中间件 + 3 个私有支撑模块          │
├────────────────────────────────────────────────────────────────────┤
│ L2 运行时层（外部依赖 langgraph ≥1.2,<1.3）                          │
│   StateGraph/Pregel 执行引擎、ToolNode、interrupt、Command/Send、    │
│   checkpointer/store、RunnableCallable                              │
├────────────────────────────────────────────────────────────────────┤
│ L1 基础抽象层（外部依赖 langchain-core 1.4.0）                       │
│   BaseChatModel/BaseTool/消息类型/add_messages/trim_messages/        │
│   count_tokens_approximately/InMemoryRateLimiter                    │
├────────────────────────────────────────────────────────────────────┤
│ L0 集成层（可选 partner 包，运行时延迟导入）                          │
│   langchain-openai / langchain-anthropic / ... （26 个 extras）      │
└────────────────────────────────────────────────────────────────────┘
```

要点：
- **控制反转**：本包不实现执行引擎，`create_agent` 只做"静态织入"——把中间件钩子编译成图节点/边与包装链（`factory.py:1387-1391`、`1016-1036`），执行交给 LangGraph。
- **双重扩展点**：图结构级（before/after 钩子变成独立节点，可 `jump_to` 改路由）与调用级（wrap 钩子变成洋葱包装链，可重试/短路）。

### 2.2 模块划分与依赖关系

7 个逻辑模块（依赖方向自上而下，不允许反向）：

```
langchain（门面/重导出层, §4.1）
   │  __init__ 只含 __version__
   ├── agents（§4.2）─────────────┐
   │     factory.py ◄─────────────┼── agents/middleware（§4.3/§4.4）
   │     structured_output.py     │     types.py（被 factory 反向引用）
   │        ▲                     │     15 个中间件实现
   │        └── 引用 middleware.types / structured_output             │
   ├── chat_models（§4.5）  base.py: init_chat_model + _ConfigurableModel
   ├── embeddings（§4.6）   base.py: init_embeddings
   └── messages / rate_limiters / tools（§4.7, 纯重导出）
```

- `agents/factory.py` → `agents/middleware/types.py`（AgentMiddleware、ModelRequest/Response 等，`factory.py:31-45`）→ `agents/structured_output.py`（三种策略，`factory.py:46-56`）→ `chat_models`（init_chat_model，`factory.py:57`）。中间件实现只依赖 types 与 `_retry.py`/`_redaction.py`/`_execution.py` 三个私有支撑模块，**不反向依赖 factory**——这保证了中间件可独立测试。
- `model_fallback.py`、`tool_selection.py`、`tool_emulator.py`、`summarization.py` 复用 `chat_models.init_chat_model` 初始化自己的辅助模型。

### 2.3 核心数据流：一次典型 agent 调用

以 `graph.invoke({"messages": [user]})` 为例（同步、带中间件与工具）：

```
用户输入 {"messages":[...]}
   │ (LangGraph 按 add_messages 归并进 state)
   ▼
[entry] m1.before_agent → m2.before_agent          ── 每次运行执行一次
   ▼
[loop_entry] m1.before_model → m2.before_model      ── 每轮循环入口
   ▼
[model 节点]
   ModelRequest 组装 → wrap_model_call 洋葱(m1→m2→核心)
   核心: _get_bound_model(绑定工具/结构化输出) → model.invoke
        → _handle_model_output(解析/结构化) → Command(update)
   ▼ (循环出口 loop_exit = m_first.after_model)
[路由 model_to_tools]（factory.py:1724）
   ├─ 无 tool_calls / 有 structured_response / jump_to=end → 走向结束
   └─ 有未应答 tool_calls → [Send("tools", tc) × N] 并行扇出
   ▼
[tools 节点]（langgraph ToolNode）
   wrap_tool_call 洋葱 → BaseTool.invoke → ToolMessage(s)
   ▼ (路由 tools_to_model, factory.py:1806)
   ├─ 全部 return_direct / 结构化输出工具已执行 → 走向结束
   └─ 默认 → 回到 loop_entry（下一轮循环）
   ▼ …循环直到模型不再调用工具…
[exit] m2.after_agent → m1.after_agent（逆序） → END
   │ (按 output_schema 过滤)
   ▼
返回 {"messages": [...], "structured_response": <对象>|缺省}
```

三个关键编排事实（均在 `factory.py` 核对）：
1. **钩子执行顺序不对称**：before_* 按注册顺序（`factory.py:1580-1619` 用 `itertools.pairwise` 正向连边），after_* 按**逆序**连边（`factory.py:1621-1661`，`model → m[-1].after_model → … → m[0]`）——与洋葱模型对称：注册第一个的中间件"最先进入、最后离开"。
2. **工具并行**：路由函数对每个未应答 tool_call 生成 `Send("tools", [tool_call])`（`factory.py:1759`），由 ToolNode map-reduce 并行执行。
3. **`jump_to` 是一次性指令**：挂在 `EphemeralValue` 通道上（`types.py:354`），写入后只影响下一个超步的路由。

## 3. 目录结构详解

仓库级目录（仅列纳入/相关部分；`…` 为按规则省略的排除目录）：

```
langchain-langchain-1.3.0/
├── README.md / LICENSE / CITATION.cff / AGENTS.md / CLAUDE.md   # 仓库级文档
├── .github/ .vscode/ .devcontainer/ ...（省略：CI/IDE/格式化配置）
└── libs/
    ├── core/            # langchain-core 1.4.0（兄弟包，见 §0.1）
    ├── langchain/       # langchain-classic 1.0.7（兄弟包）
    ├── text-splitters/  # langchain-text-splitters 1.1.2（兄弟包）
    ├── standard-tests/  # langchain-tests 1.1.7（兄弟包）
    ├── model-profiles/  # langchain-model-profiles 0.0.5（兄弟包）
    ├── partners/        # 15 个 partner 集成包（兄弟包）
    └── langchain_v1/    # ★ 分析主体：langchain 1.3.0
        ├── pyproject.toml / Makefile / README.md / uv.lock（锁文件，省略）
        ├── extended_testing_deps.txt
        ├── scripts/     # check_imports.py / check_version.py（CI 辅助，排除）
        ├── tests/       # 单测/基准/集成测试（排除；含 docker compose 文件）
        └── langchain/   # ★ 包源码（31 个 .py，逐目录如下）
```

主包目录职责（`→ 职责 → 关键内容`）：

| 目录路径 | 职责 | 包含关键内容 |
|---|---|---|
| `libs/langchain_v1/langchain/` | 包根，仅版本标识 | `__init__.py`：`__version__ = "1.3.0"`（`__init__.py:3`） |
| `…/langchain/agents/` | agent 工厂与结构化输出 | `factory.py`（`create_agent`，1885 行）、`structured_output.py`（三种输出策略，462 行） |
| `…/langchain/agents/middleware/` | 中间件类型系统 + 内置中间件库 | `types.py`（AgentMiddleware 基类/请求响应对象/装饰器，2052 行）、15 个中间件实现、`_retry.py`/`_redaction.py`/`_execution.py` 三个私有支撑模块 |
| `…/langchain/chat_models/` | 聊天模型工厂 | `base.py`：`init_chat_model`、`_ConfigurableModel`（1033 行） |
| `…/langchain/embeddings/` | 嵌入模型工厂 | `base.py`：`init_embeddings`（275 行） |
| `…/langchain/messages/` | 消息类型门面 | `__init__.py`：从 langchain-core 转发 32 个消息/内容块符号 |
| `…/langchain/tools/` | 工具类型门面 | `__init__.py` + `tool_node.py`：转发 langchain-core/langgraph 的工具符号 |
| `…/langchain/rate_limiters/` | 限流器门面 | `__init__.py`：转发 `BaseRateLimiter`、`InMemoryRateLimiter` |

---

## 4. 核心模块详解（报告主体）

模块编号与批次对应：§4.1 门面层（批 5）、§4.2 agents 核心（批 2）、§4.3 middleware 类型系统（批 3）、§4.4 middleware 内置实现（批 4）、§4.5 chat_models（批 5）、§4.6 embeddings（批 5）、§4.7 其余重导出层（批 5）。

### 4.1 模块：包根与门面/重导出层

**模块职责**：定义包身份（版本号），并为 langchain-core / langgraph 的稳定符号提供统一导入面，让用户 `from langchain.xxx import ...` 无需感知底层包边界。这是 1.x 收敛后的"窄门面"设计。

**文件组成**（8 个文件，均为薄转发，逐一说明）：

| 文件 | 职责与关键内容 |
|---|---|
| `langchain/__init__.py`（3 行） | 仅 `__version__ = "1.3.0"`（`:3`），无其他导出——刻意保持根命名空间干净 |
| `agents/__init__.py`（9 行） | 导出 `create_agent`（来自 factory）与 `AgentState`（来自 middleware.types）（`:3-9`）——用户主入口 |
| `agents/middleware/__init__.py`（84 行） | 中间件库总门面：转发 types 的 13 个符号（`AgentMiddleware`、钩子装饰器 `before_model` 等）、15 个内置中间件的全部公开类，以及 langgraph 的 `Runtime`（`:3,5-44`）；`__all__` 38 项（`:46-84`） |
| `chat_models/__init__.py`（7 行） | 导出 `BaseChatModel`（core）与 `init_chat_model`（`:3-7`） |
| `embeddings/__init__.py`（18 行） | 导出 `Embeddings`（core）与 `init_embeddings`；docstring 提示 1.0 起 `CacheBackedEmbeddings` 等已迁往 langchain-classic（`:3-13`） |
| `messages/__init__.py`（73 行） | 从 langchain_core.messages 转发 32 个符号：五种角色消息（`AIMessage`/`HumanMessage`/`SystemMessage`/`ToolMessage`/`RemoveMessage`）、内容块类型（`TextContentBlock`/`ImageContentBlock`/…）、`ToolCall`/`ToolCallChunk`、`UsageMetadata`、工具函数 `trim_messages`（`:7-39`） |
| `tools/__init__.py`（22 行） | 从 core 转发 `BaseTool`/`tool`/`InjectedToolArg`/`InjectedToolCallId`/`ToolException`，从 langgraph 转发 `InjectedState`/`InjectedStore`/`ToolRuntime`（`:3-11`） |
| `tools/tool_node.py`（20 行） | 向后兼容文件：转发 langgraph.prebuilt 的 `ToolNode`、`ToolCallRequest`、`ToolCallWrapper`、`InjectedState` 等（`:3-11`，docstring 自述 "for backwards compat imports"） |
| `rate_limiters/__init__.py`（13 行） | 转发 core 的 `BaseRateLimiter`/`InMemoryRateLimiter`（`:8`），docstring 说明与 `BaseChatModel` 配合使用 |

**对外接口**：即上述 `__all__` 全集。**注意**：门面层不含任何逻辑，改行为要去对应实现文件（core/langgraph/本包实现层）。

### 4.2 模块：agents 核心（factory + structured_output）

**模块职责**：整个包的心脏。`factory.py` 把"模型 + 工具 + 中间件 + 结构化输出"编译成一张 LangGraph `StateGraph`；`structured_output.py` 定义结构化输出的三种策略与 schema 适配。

#### 4.2.1 `agents/factory.py`（1885 行）

**文件职责一览**（顶层符号全部核对）：

| 符号 | 行号 | 作用 |
|---|---|---|
| `_ComposedExtendedModelResponse` | `:60-73` | 内部 dataclass：组合后的模型调用结果 = `ModelResponse` + 跨层累积的 `Command` 列表 |
| `STRUCTURED_OUTPUT_ERROR_TEMPLATE` | `:109` | 结构化输出失败重试模板 `"Error: {error}\n Please fix your mistakes."` |
| `DYNAMIC_TOOL_ERROR_TEMPLATE` | `:111-135` | 中间件在 `wrap_model_call` 里塞入未注册工具时的详细报错模板（含两种修复方案说明） |
| `_scrub_inputs` | `:138-147` | LangSmith 追踪输入清洗：剔除 `handler` 键、剥离 `request.runtime`（dataclass `fields` 反射） |
| `FALLBACK_MODELS_WITH_STRUCTURED_OUTPUT` | `:150-160` | 无 model profile 时的兜底模型名单（grok/gpt-5/gpt-4.1/gpt-4o/gpt-oss/o3-* 等 7 项），用于判断是否支持原生结构化输出 |
| `_normalize_to_model_response` | `:163-176` | 把钩子返回值（`AIMessage`/`ExtendedModelResponse`）统一归一为 `ModelResponse` |
| `_build_commands` | `:179-218` | 由 `ModelResponse` + 中间件命令构造节点返回值：首条 `Command(update={"messages","structured_response"})` + 追加命令；并**拒绝** `goto/resume/graph` 型命令（`:204-213` 抛 `NotImplementedError`） |
| `_chain_model_call_handlers` / `_chain_async_model_call_handlers` | `:221-310` / `:313-401` | 同步/异步 `wrap_model_call` 洋葱组合器（详见第 6 章） |
| `_get_schema_type_hints` | `:404-407` | `functools.lru_cache(100)` 缓存 `get_type_hints(include_extras=True)` |
| `_resolve_schemas` | `:410-422` | 对 `[中间件 schemas…, base_state]` 依次解析出 state/input/output 三个合并 TypedDict |
| `_resolve_schema` | `:425-457` | 合并算法：按列表顺序收集注解（后声明的同名字段覆盖先前的），按 `omit_flag`（`'input'`/`'output'`）跳过带 `OmitFromSchema` 标记的字段，`TypedDict(name, annotations)` 动态建类 |
| `_extract_metadata` | `:460-472` | 处理 `Required[Annotated[...]]`/`NotRequired[Annotated[...]]`/`Annotated[...]` 三种包装，取出注解元数据列表 |
| `_get_can_jump_to` | `:475-507` | 读取钩子方法上的 `__can_jump_to__` 元数据（仅当方法被用户覆写时，与基类方法对象比对 `is not`） |
| `_supports_provider_strategy` | `:510-552` | 判定模型是否支持原生结构化输出：`model.profile["structured_output"]` 为真（Gemini 3 以下且带工具时例外，`:539-545`）→ True；否则看模型名是否命中兜底名单 |
| `_handle_structured_output_error` | `:555-582` | 按 `ToolStrategy.handle_errors`（`bool/str/异常类型/元组/回调` 五种形态）决定是否把校验错误转成"喂回模型"的 ToolMessage |
| `_chain_tool_call_wrappers` / `_chain_async_tool_call_wrappers` | `:585-630` / `:633-694` | 工具调用包装洋葱（首个=最外层；外层可多次调 `call_inner` 实现重试） |
| `create_agent` | `:697-1679` | **主工厂**（详见第 6 章） |
| `_resolve_jump` | `:1682-1694` | `"model"/"end"/"tools"` → 实际节点名映射（`end` 映射到 exit_node 而非字面 END） |
| `_fetch_last_ai_and_tool_messages` | `:1697-1715` | 倒序找最后一条 `AIMessage` 及其后所有 `ToolMessage`（路由判断的基础） |
| `_make_model_to_tools_edge` | `:1718-1769` | 循环出口路由：jump_to → 无 AI 消息 → 无 tool_calls → 待执行 tool_calls（Send 扇出）→ 已有结构化响应 → 回模型（六步决策） |
| `_make_model_to_model_edge` | `:1772-1796` | 无工具但有结构化输出工具时的 model→model 重试路由 |
| `_make_tools_to_model_edge` | `:1799-1832` | 工具后路由：全部 `return_direct` → end；结构化输出工具已执行 → end；默认回模型 |
| `_add_middleware_edge` | `:1835-1880` | 中间件节点连边：无 `can_jump_to` 直接静态边；有则建条件边（jump 优先，落空走 default） |

**create_agent 的装配产物**（对理解本包最重要）：一张形如下面的图（以两个中间件 m1、m2 为例）：

```
START → m1.before_agent → m2.before_agent → m1.before_model → m2.before_model → model
model → m2.after_model → m1.after_model ──(条件路由)──┬→ m1.before_model（循环）
                                                     ├→ tools（Send）
                                                     └→ m2.after_agent → m1.after_agent → END
tools ──(条件路由)──┬→ m1.before_model
                   └→ m2.after_agent
```

无中间件时退化为 `START → model ⇄ tools → END`；无工具时 `START → model → END`（或 model→model 结构化输出重试环，`:1553-1564`）。

#### 4.2.2 `agents/structured_output.py`（462 行）

**文件职责**：定义"让 agent 返回可解析结构化对象"的策略体系，被 factory 在装配期与模型输出处理期使用。

**文件组成**：

| 符号 | 行号 | 作用 |
|---|---|---|
| `SchemaT` / `SchemaKind` | `:30-32` | schema 类型参数 / 四类 schema 标签（pydantic、dataclass、typeddict、json_schema） |
| `StructuredOutputError` | `:35-38` | 结构化输出异常基类（携带 `ai_message`） |
| `MultipleStructuredOutputsError` | `:41-57` | 模型一次返回多个结构化输出工具调用时抛出 |
| `StructuredOutputValidationError` | `:60-74` | 工具参数/schema 解析失败时抛出（保留 `source` 原始异常） |
| `_parse_with_schema` | `:77-102` | 统一解析入口：`json_schema` 原样返回 dict，其余用 pydantic `TypeAdapter(schema).validate_python(data)`；失败统一转 `ValueError` |
| `_SchemaSpec` | `:105-191` | schema 描述符：自动推导 `name`（类名 / dict 的 title / 随机名）、`description`（docstring）、`schema_kind` 与 `json_schema`（用 `model_json_schema()` 或 `TypeAdapter().json_schema()`），不支持的类型抛 `ValueError`（`:187-191`） |
| `ToolStrategy` | `:194-257` | 工具策略：`schema` 支持 Union/`oneOf`（`_iter_variants` 递归展开为多个 `_SchemaSpec`，`:243-257`）；`tool_message_content` 自定义回执文案；`handle_errors` 五形态错误处理策略 |
| `ProviderStrategy` | `:260-304` | 厂商原生策略：`to_model_kwargs()`（`:285-304`）产出 OpenAI 风格 `response_format={"type":"json_schema","json_schema":{name,schema,strict?}}` 绑定参数 |
| `OutputToolBinding` | `:307-359` | 工具策略的运行时绑定：`from_schema_spec` 用 `StructuredTool(args_schema=json_schema, name, description)` 造一个"假工具"（`:340-344`）；`parse(tool_args)` 按 schema 校验参数（`:347-359`） |
| `ProviderStrategyBinding` | `:362-444` | 原生策略的运行时绑定：`parse(AIMessage)` 抽取文本（`_extract_text_content_from_message` 兼容 str 与内容块列表，`:422-444`）→ `json.loads` → schema 校验 |
| `AutoStrategy` | `:447-458` | 自动策略标记：仅持有 schema，实际策略由 `_get_bound_model` 在运行时判定 |
| `ResponseFormat` | `:461-462` | 三策略联合类型别名 |

**对外接口**：`ToolStrategy` / `ProviderStrategy` / `AutoStrategy` / `ResponseFormat` / 三个异常类 / `OutputToolBinding` / `ProviderStrategyBinding`（factory 导入其中 9 个符号，`factory.py:46-56`）。

**关键实现方式**：
- **Union 展开**：`ToolStrategy(A | B)` 会注册两个"假工具"，模型调哪个就按哪个 schema 解析（`structured_output.py:243-257`）。
- **强制工具**：ToolStrategy 路径下 factory 用 `tool_choice="any"` 强制模型必须调用（含结构化输出工具在内的）工具（`factory.py:1273-1277`）。
- **自纠错回路**：解析失败且 `handle_errors` 允许时，错误信息以 `ToolMessage` 回喂模型，图经 `model_to_tools` 第 6 步回到模型重试（`factory.py:1141-1158` + `:1765-1767`）。

### 4.3 模块：middleware 类型系统（`agents/middleware/types.py`，2052 行）

**模块职责**：定义中间件编程模型的全部契约——请求/响应数据类、`AgentMiddleware` 基类（12 个钩子）、状态 schema 注解工具、以及把普通函数变成中间件的 8 个装饰器。这是"用户扩展本框架"时唯一必须理解的文件。

#### 4.3.1 数据模型（请求/响应/状态）

**`ModelRequest`（`:88-268`）**——模型调用的不可变请求对象（`@dataclass(init=False)`）：

- 字段（`:96-104`）：`model`、`messages`（不含系统消息）、`system_message`、`tool_choice`、`tools`、`response_format`、`state`、`runtime`、`model_settings`（默认 `{}`）。
- `__init__`（`:106-155`）：兼容旧参数 `system_prompt`（自动转 `SystemMessage`，两者同传抛 `ValueError`，`:138-143`）；`state`/`runtime` 缺省分别为 `{"messages": []}` 与 `None`。
- `system_prompt` property（`:157-166`）：从 `system_message.text` 反查。
- `__setattr__`（`:168-200`）：**直接属性赋值已废弃**——发 `DeprecationWarning` 后仍写入（`system_prompt` 特殊处理为转 system_message），引导用户用 `override()`。
- `override(**overrides)`（`:202-268`）：基于 `dataclasses.replace` 的不可变更新（同样处理 system_prompt 兼容）；这是中间件修改请求的**标准姿势**（洋葱内每层拿到新副本，天然支持重试）。

**`ModelResponse`（`:271-286`）**：`result: list[BaseMessage]` + `structured_response: ResponseT | None`。

**`ExtendedModelResponse`（`:289-311`）**：`ModelResponse` + 可选 `Command`——让 `wrap_model_call` 能附带一次额外状态更新（经图 reducer 归并；非 reducer 字段外层覆盖内层）。

**`ModelCallResult`（`:314-316`）**：钩子返回值联合类型别名（`ModelResponse | AIMessage | ExtendedModelResponse`）。

**schema 注解工具（`:329-347`）**：
- `OmitFromSchema(input=True, output=True)`：标记字段从输入/输出 schema 中剔除；
- 预置实例 `OmitFromInput` / `OmitFromOutput` / `PrivateStateAttr`（双向剔除，纯内部字段）。

**`AgentState`（`:350-355`）**——agent 状态 schema（Generic TypedDict）：

```python
class AgentState(TypedDict, Generic[ResponseT]):
    messages: Required[Annotated[list[AnyMessage], add_messages]]          # :353
    jump_to: NotRequired[Annotated[JumpTo | None, EphemeralValue, PrivateStateAttr]]  # :354
    structured_response: NotRequired[Annotated[ResponseT, OmitFromInput]]  # :355
```
- `messages`：`add_messages` 归并（按 id 增/删/改）；
- `jump_to`：`EphemeralValue` 通道——只存活一个超步，路由函数消费后自动消失（中间件跳转指令的载体）；
- `structured_response`：不出现在输入 schema（用户不能直接传入）。

**输入/输出 schema（`:358-368`）**：`_InputAgentState`（只有 messages，允许 dict 形态）与 `_OutputAgentState`（messages + structured_response）——`create_agent` 以它们为图边界。

**TypeVar 家族（`:371-373`）**：`StateT`/`StateT_co`/`StateT_contra`，均 `bound=AgentState[Any]`，用于中间件泛型签名。

#### 4.3.2 `AgentMiddleware` 基类（`:380-798`）

```python
class AgentMiddleware(Generic[StateT, ContextT, ResponseT]):
    state_schema: type[StateT] = _DefaultAgentState   # :392 中间件自定义状态
    tools: Sequence[BaseTool]                          # :395 中间件注册的工具
    @property
    def name(self) -> str: return self.__class__.__name__  # :398-404
```

12 个钩子（签名与语义；"返回 dict"均指状态更新，经 reducer 归并）：

| 钩子 | 行号 | 签名要点 | 语义 |
|---|---|---|---|
| `before_agent` / `abefore_agent` | `:406` / `:417` | `(state, runtime) -> dict \| None` | 运行开始执行一次（图中独立节点，可 jump_to） |
| `before_model` / `abefore_model` | `:430` / `:441` | 同上 | 每轮模型调用前（循环节点，可 jump_to） |
| `after_model` / `aafter_model` | `:454` / `:465` | 同上 | 每轮模型调用后（逆序执行，可 jump_to） |
| `after_agent` / `aafter_agent` | `:625` / `:636` | 同上 | 运行结束前执行一次（逆序） |
| `wrap_model_call` / `awrap_model_call` | `:478` / `:573` | `(request, handler) -> ModelCallResult` | 模型调用洋葱包装；可多次调 handler（重试）、不调（短路）、改 request/response |
| `wrap_tool_call` / `awrap_tool_call` | `:649` / `:731` | `(request: ToolCallRequest, handler) -> ToolMessage \| Command` | 工具调用洋葱包装 |

实现细节：
- 4 个 before/after 钩子基类默认**空实现**（返回 None）——覆写与否通过"类属性是否仍是基类函数对象"判断（factory `:973-1014` 的 `m.__class__.before_model is not AgentMiddleware.before_model`）。
- 4 个 wrap 钩子基类默认**抛 `NotImplementedError`**（`:561-571`、`:613-623`、`:719-729`、`:788-798`），错误信息精确指导：只定义了 async 版本却在同步上下文调用（或反之）时该怎么办——这使"只实现一半"在错误执行路径上快速失败。
- docstring 内置 5 类使用范例（重试/改写/降级/缓存短路/AIMessage 简化返回，`:506-559`）。

#### 4.3.3 装饰器（函数式中间件，8 个）

`hook_config`（`:856-907`）：方法配置装饰器，目前唯一能力 `can_jump_to=[...]`——把跳转目的地写到函数属性 `__can_jump_to__` 上（`:902-905`），供 factory `_get_can_jump_to` 读取并建条件边。

7 个"函数 → 中间件"装饰器，实现模式完全一致（以 `before_model` 为例，`:929-1077`）：

```python
@before_model(can_jump_to=["end"])
def check(state: AgentState, runtime: Runtime) -> dict | None: ...
# 等价于一个覆写了 before_model 的 AgentMiddleware 子类实例
```

| 装饰器 | 实现行号 | 生成的钩子 | 特别之处 |
|---|---|---|---|
| `before_model` | `:929-1077` | `before_model`/`abefore_model` | 按 `iscoroutinefunction` 自动选同步/异步槽位（`:1024-1049`）；用 `type(name, (AgentMiddleware,), {...})()` 动态造实例（`:1041-1073`）；透传 `state_schema`/`tools`/`can_jump_to`/`name` |
| `after_model` | `:1099-1235` | `after_model`/`aafter_model` | 同上模式 |
| `before_agent` | `:1257-1429` | `before_agent`/`abefore_agent` | 同上模式 |
| `after_agent` | `:1450-1588` | `after_agent`/`aafter_agent` | 同上模式 |
| `dynamic_prompt` | `:1605-1733` | `wrap_model_call`/`awrap_model_call` | 专门做动态系统提示：函数返回 `str/SystemMessage`，包装器 `request.override(system_message=…)` 后调 handler（`:1669-1729`）；同步函数会同时生成 async 槽位（`async_wrapped_from_sync`，`:1705-1716`），因此两种执行路径都可用 |
| `wrap_model_call` | `:1755-1893` | `wrap_model_call`/`awrap_model_call` | 把 `(request, handler)` 函数转成模型调用中间件 |
| `wrap_tool_call` | `:1913-2052` | `wrap_tool_call`/`awrap_tool_call` | 把 `(request, handler)` 函数转成工具调用中间件 |

**对外接口**（`__all__`，`:47-67`）：`AgentMiddleware`、`AgentState`、`ModelRequest`、`ModelResponse`、`ExtendedModelResponse`、`ModelCallResult`、`OmitFromSchema`、`ToolCallRequest`、`ToolCallWrapper`、`ContextT`、`ResponseT`、`StateT_co`、8 个装饰器。

**被引用关系**：被 `factory.py`（类型与包装）、全部 15 个中间件实现（基类与请求对象）、`agents/__init__.py`（AgentState）引用；`ModelRequest.override` 是整个中间件生态的修改入口。

### 4.4 模块：middleware 内置实现（18 个文件）

**模块职责**：开箱即用的生产级中间件库，按关注点分四组：上下文管理（摘要/上下文编辑/todo）、可靠性（模型重试/降级/调用上限、工具重试/调用上限）、安全与人工介入（PII、HITL、shell 执行）、效率与测试（工具选择、工具模拟、文件搜索）。另有 3 个下划线私有支撑模块（`_retry`/`_redaction`/`_execution`）。

#### 4.4.0 私有支撑模块（3 个）

**`_retry.py`（123 行）**——模型/工具重试共享库（docstring `:1-5` 自述）：

| 符号 | 行号 | 说明 |
|---|---|---|
| `RetryOn` | `:14` | `tuple[type[Exception],...] | Callable[[Exception], bool]` |
| `OnFailure` | `:22` | `Literal["error","continue"] | Callable[[Exception], str]`（error=重抛；continue=注入错误消息继续） |
| `validate_retry_params` | `:35-63` | 四参数任一为负抛 `ValueError` |
| `should_retry_exception` | `:66-82` | 可调用则调用之；否则 `isinstance(exc, retry_on)` |
| `calculate_delay` | `:85-123` | 指数退避 `initial_delay * backoff_factor**n`（factor=0 退化为常数），`min(delay, max_delay)` 封顶，jitter 为 ±25% 均匀抖动并防负（`:109-121`） |

被 `model_retry.py`（`:11-17` 导入）与 `tool_retry.py`（`:12-18` 导入）复用，是两者的唯一公共依赖。

**`_redaction.py`（454 行）**——PII 检测与脱敏共享库（纯函数/数据类，无中间件）：

| 符号 | 行号 | 说明 |
|---|---|---|
| `PIIMatch`（TypedDict） | `:20-26` | `{type, value, start, end}` |
| `PIIDetectionError` | `:29-43` | block 策略抛出，消息含命中数量与类型 |
| 5 个内置检测器 | `:50-206` | `detect_email`（正则 `:59`）、`detect_credit_card`（正则+Luhn `:80-85`）、`detect_ip`（仅 IPv4 正则+`ipaddress` 校验 `:108-113`；docstring 称支持 IPv6 但实现只有 IPv4，见存疑清单）、`detect_mac_address`（`:137`）、`detect_url`（双模式：带 scheme 走 `urlparse` 校验 `:161-166`；裸域名仅当含 `/` 或 `www.` 前缀才接受，避免散文误报 `:178-192`） |
| `BUILTIN_DETECTORS` | `:209-216` | 5 个检测器注册表 |
| 三个策略函数 | `:239-303` | `redact`→`[REDACTED_{TYPE}]`（按 start 倒序替换防偏移失效 `:241`）；`mask`→按类型定制保留（email 留用户名+TLD、卡号留末 4 位…`256-292`）；`hash`→`sha256(value)[:8]` 确定性假名 `:297-303` |
| `apply_strategy` | `:306-336` | 策略分发；block 抛 `PIIDetectionError`（`:333-334`）；未知策略 `ValueError` |
| `resolve_detector` | `:339-394` | 三路解析：None→内置注册表；str→`re.compile` 包装；Callable→`_normalizing_detector` 归一化（兼容返回 `{"text": ...}` 的第三方检测器如 Presidio 风格输出，`:378-393`） |
| `RedactionRule` / `ResolvedRedactionRule` | `:397-440` | frozen dataclass 配置对象 + `resolve()` 后的 `apply(content) -> (新内容, matches)` |

关键事实：**不使用 Presidio**，纯正则 + 标准库（Luhn/ipaddress/urlparse/sha256）；**脱敏单向不可逆**，无"占位符→原文"还原映射（hash 仅用于跨位置关联同一值）。

**`_execution.py`（385 行）**——shell 执行策略（策略模式，唯一消费者是 `shell_tool.py`）：

| 类 | 行号 | 说明 |
|---|---|---|
| `BaseExecutionPolicy`（ABC） | `:56-88` | 公共限制字段：`command_timeout=30.0`、`startup_timeout=30.0`、`termination_timeout=10.0`、`max_output_lines=100`、`max_output_bytes=None`（`:69-73`）；抽象方法 `spawn(workspace, env, command) -> Popen`（`:80-88`） |
| `HostExecutionPolicy` | `:91-187` | 宿主直接执行，**无沙箱**；可选 rlimit：macOS 走 `preexec_fn`+`setrlimit`（`:148-163`），Linux 走 `prlimit`（`:165-183`），Windows 无 `resource` 模块时构造即抛 `RuntimeError`（`:124-129`） |
| `CodexSandboxExecutionPolicy` | `:190-263` | 经 Codex CLI 沙箱（macOS Seatbelt / Linux Landlock+seccomp）；`_build_command` 拼 `[codex, sandbox, <platform>, (-c k=v)..., --, *command]`（`:226-234`）；CLI 不在 PATH 抛 `RuntimeError` |
| `DockerExecutionPolicy` | `:266-377` | 每会话独立容器强隔离：默认镜像 `python:3.12-alpine3.19`、`--network none`（`:287`）、`--rm`；`_should_mount_workspace`：临时工作区（前缀 `langchain-shell-`）不挂载进容器以减小宿主暴露（`:365-367`）；不支持 `cpu_time_seconds`（给值即 `RuntimeError`，引导用 `--cpus`，`:300-305`） |

私有 `_launch_subprocess`（`:27-48`）统一 `Popen` 封装：三路 PIPE、`text=True`、`bufsize=1`、`start_new_session`（进程组隔离，便于整树 kill）。

#### 4.4.1 上下文管理组（3 个）

**`summarization.py`（658 行）——`SummarizationMiddleware`：上下文超限时自动摘要压缩历史。**

- `__init__`（`:161-290`）：`model`（必填，摘要用模型，str 经 init_chat_model 实例化 `:250-251`）、`trigger`（触发条件，`ContextSize` 三元组：`("tokens", N)` / `("fraction", f)`（按 profile 的 max_input_tokens 比例，`:401-412`）/ `("messages", N)`，可列表多条件）、`keep`（保留量，默认 `("messages", 20)`，`:76,166`）、`token_counter`（默认 `count_tokens_approximately`，Anthropic 模型自动调 `chars_per_token=3.3`，`:142-150`）、`summary_prompt`、`trim_tokens_to_summarize=4000`。
- 钩子：`before_model`/`abefore_model`（`:293-328`/`:331-366`）。
- 核心流程：补消息 id（`:305-306`，`_ensure_message_ids` `:519-524`）→ 计 token → `_should_summarize`（`:387-413`，含"用上次响应 usage_metadata.total_tokens 二次判定"逻辑 `:368-385`，带 provider 一致性防混模误判 `:381-382`）→ `_determine_cutoff_index`（`:415-425`；token/fraction 路径**二分搜索**后缀预算 `:427-474`）→ `_find_safe_cutoff_point`（`:552-586`）保证不拆散 AI/Tool 配对（切割点落在 ToolMessage 时向前找配对 AIMessage）→ `_create_summary`（`:588-612`：`trim_messages(strategy="last", start_on="human", allow_partial=True)` 裁剪 → `get_buffer_string` 格式化 → 摘要模型 invoke）→ 返回 `{"messages": [RemoveMessage(REMOVE_ALL), 摘要HumanMessage, *保留消息]}`（`:322-328`）**整表重建**。
- 摘要 prompt（`DEFAULT_SUMMARY_PROMPT` `:33-74`）：角色"Context Extraction Assistant"，要求按 `SESSION INTENT / SUMMARY / ARTIFACTS / NEXT STEPS` 四节输出——是"上下文提取"而非简单摘要。
- 副作用：摘要模型调用失败被吞为 `"Error generating summary: …"` 文本写入历史（`:611-612`）；历史清空不可恢复；依赖私有 API `model._llm_type`/`_get_ls_params`（`:144,382`）。

**`context_editing.py`（298 行）——`ContextEditingMiddleware`：把旧工具结果替换为占位符腾上下文（对齐 Anthropic context editing）。**

- `__init__`（`:200-218`）：`edits`（默认 `(ClearToolUsesEdit(),)`，`:217`）、`token_count_method`（`"approximate"` 纯近似 / `"model"` 用模型精确计数并把 system+tools 计入，`:238-249`）。
- 钩子：`wrap_model_call`/`awrap_model_call`（`:220-255`/`:257-292`）：`deepcopy` 请求消息副本 → 依次 `edit.apply(messages, count_tokens)` → `handler(request.override(messages=…))`。**只改本次请求，不落盘 state**（与摘要中间件的本质区别）。
- `ClearToolUsesEdit`（dataclass，`:57-184`）：`trigger=100_000`、`keep=3`（最近 3 个工具结果不动）、`clear_tool_inputs=False`、`exclude_tools=()`、`placeholder="[cleared]"`；`apply`（`:79-155`）逐个把旧 `ToolMessage.content` 换成占位符并在 `response_metadata["context_editing"]["cleared"]` 标记幂等（`:129-141`）；可选连 AIMessage 里对应 tool_call 的 args 一并清空（`:143-147`）；`clear_at_least>0` 时每清一条重算 token 达标即停（`:149-153`）。
- 扩展点：实现 `ContextEdit` Protocol（`:44-54`）即可自定义编辑策略。

**`todo.py`（345 行）——`TodoListMiddleware`：给 agent 一个 `write_todos` 工具与 `todos` 状态字段（任务计划）。**

- `Todo` TypedDict：`{content: str, status: "pending"|"in_progress"|"completed"}`（`:25-32`）；`PlanningState` 增加 `todos: NotRequired[list[Todo]]`（带 `OmitFromInput`，`:42`）。
- 注册工具 `write_todos`（`StructuredTool.from_function`，`:208-217`）：实现 `_write_todos`（`:141-152`）返回 `Command(update={"todos": todos, "messages": [ToolMessage(...)]})`——**全量替换**清单。
- 钩子：`wrap_model_call` 把 todo 使用规范追加进 system message（`:219-244`）；`after_model`（`:273-323`）检测同一轮**并行多次** `write_todos` 调用，为每个调用注入 `status="error"` 的 ToolMessage 逼迫模型重试（全量替换语义下并行调用有歧义，`:279-283` 文档说明）。
- 工具描述常量 `WRITE_TODOS_TOOL_DESCRIPTION`（`:52-110`）是行为规范的核心：何时用/何时不用/状态管理细则。

#### 4.4.2 可靠性组（5 个）

**`model_retry.py`（313 行）——`ModelRetryMiddleware`**：`wrap_model_call` 重试循环 `for attempt in range(max_retries+1)`（`:232`），失败按 `should_retry_exception` 过滤、按 `calculate_delay` 退避（`time.sleep`/`asyncio.sleep`，`:254/304`）；耗尽后 `_handle_failure`（`:190-212`）三分支：`"error"` 重抛 / callable 自定义文案 / 默认注入错误 `AIMessage` 继续。默认 `max_retries=2, backoff_factor=2.0, initial_delay=1.0, max_delay=60.0, jitter=True`（`:114-120`）。

**`model_fallback.py`（138 行）——`ModelFallbackMiddleware`**：构造时 `init_chat_model` 实例化备用模型列表（`:63-70`）；`wrap_model_call` 先跑主模型（即原样 handler），异常则依序 `handler(request.override(model=fallback))` 重试，全部失败**重抛最后一个异常**（`:89-104`）。

**`model_call_limit.py`（267 行）——`ModelCallLimitMiddleware`**：`ModelCallLimitState` 增加两个计数字段——`thread_model_call_count`（跨 run 持久）与 `run_model_call_count`（`UntrackedValue` 不进检查点，每 run 自动清零）（`:33-34`）；`before_model` 检查"下一次是否超限"（`:186-210`）：超限且 `exit_behavior="error"` 抛 `ModelCallLimitExceededError`，`="end"` 则注入一条说明性 AIMessage 并 `jump_to="end"`；`after_model` 双计数 +1（`:248-251`）。

**`tool_retry.py`（403 行）——`ToolRetryMiddleware`**：与模型版共享 `_retry.py`，差异点是 `tools` 参数按名过滤适用范围（`_should_retry_tool` `:223-234`）、失败消息是 `ToolMessage(status="error")`（`:281-286`）、废弃值 `"raise"/"return_message"` 映射新语义并发 `DeprecationWarning`（`:196-204`）。

**`tool_call_limit.py`（488 行）——`ToolCallLimitMiddleware`**：`after_model` 钩子（`@hook_config(can_jump_to=["end"])`）拦截超限 tool_calls（`:326-463`）：按 `tool_name` 过滤（`None`=全部，计数键 `"__all__"`，`:364`）；`_separate_tool_calls`（`:292-322`）分流允许/拦截；三种 `exit_behavior`——`"continue"` 为被拦调用注入 error ToolMessage 让模型自行调整（`:412-420`）、`"error"` 抛 `ToolCallLimitExceededError`、`"end"` 注入最终 AIMessage 并跳结束（存在其他工具待执行时抛 `NotImplementedError`，`:430-436`）。两套文案刻意区分受众：给模型的（不含计数细节 `:52-67`）与给用户的（含 `(n/m)` `:70-101`）。计数 state 为 dict（键=工具名），同样 thread/run 双轨（`:48-49`）。

#### 4.4.3 安全与人工介入组（4 个）

**`pii.py`（376 行）——`PIIMiddleware`**：`__init__`（`:100-154`）必填 `pii_type`（内置 5 种或自定义），`strategy ∈ block/redact/mask/hash`，`detector`（None 内置/str 正则/Callable），三个开关 `apply_to_input=True / apply_to_output=False / apply_to_tool_results=False`。钩子 `before_model`（`:169-263`，`can_jump_to=["end"]`）改写最后一条 HumanMessage 与未应答 ToolMessage；`after_model`（`:286-344`）改写最后一条 AIMessage。block 策略命中时 `PIIDetectionError` 直接上抛终止运行。注意：重建消息仅保留 `id/name/tool_calls` 等关键字段（`:216-223,333-338`），`additional_kwargs` 会丢失。

**`human_in_the_loop.py`（412 行）——`HumanInTheLoopMiddleware`**：构造参数 `interrupt_on: dict[str, bool | InterruptOnConfig]`（`True`=四种决策全开；`False`=不注册即自动放行，`:214-223`）。唯一钩子 `after_model`（`:313-398`）：发现命中的 tool_calls 后组装 `HITLRequest` 并调用 langgraph **运行时 `interrupt()`**（`:362`，非编译期 `interrupt_before`）暂停整图；恢复后按 `_process_decision`（`:262-311`）四分支处理——`approve` 放行原调用 / `edit` 用编辑后 name+args 重建 ToolCall（保留原 id，`:277-282`）/ `reject` 注入 error ToolMessage / `respond` 由人类代答注入 success ToolMessage；随后**原地改写** `last_ai_msg.tool_calls` 并返回更新（`:396-398`）——reject/respond 的人工 ToolMessage 已"应答"了对应 tool_call，工具节点因此跳过真实执行，同时保持 AI/Tool 配对完整。配套类型（`ActionRequest`/`ReviewConfig`/四种 Decision/`HITLRequest/Response`，`:19-119`）即中断负载的 wire format。

**`shell_tool.py`（882 行）——`ShellToolMiddleware` + `ShellSession`**：注册一个**持久 shell 会话**工具（默认名 `shell`，`/bin/bash`，`HostExecutionPolicy`）。
- `ShellSession`（`:125-459`）：单进程长驻，stdout/stderr 双守护读线程（`:173-184`）；`execute`（`:217-238`）的核心协议——写入命令后紧跟一行 `printf '__LC_SHELL_DONE__<uuid> %s\n' $?`（`:223-231`），读线程见到该 marker 即知命令结束并从同一行解析退出码（`_collect_output` `:240-325`）；超时记 warning 并**重启会话**（`:300-305`）；输出行数/字节截断（`:281-290`）；stderr 行加 `[stderr] ` 前缀混排。`_kill_process` 优先 `os.killpg` 整树击杀（`:401-410`）。
- 中间件（`:489-873`）：`before_agent` 创建会话资源并写入 state（`:627-641`）；`after_agent` 跑 shutdown 命令并释放（`:657-667`）；会话句柄存 `shell_session_resources` 字段——`UntrackedValue`（Popen 不可序列化，不进检查点）+ `PrivateStateAttr`，配合 `_get_or_create_resources`（`:675-694`）实现 interrupt 后复用同一会话；`weakref.finalize` 兜底清理（`:91-97`）。工具执行 `_run_shell_tool`（`:761-854`）：超时/输出脱敏（复用 `_redaction.py` 的 `RedactionRule`，block 命中转为 error ToolMessage）/退出码非 0 时 `status="error"`。
- **安全模型**：无命令白名单、不做命令解析（原文交 bash 解释，docstring `:63` 明示支持 `&&`/`;`）；安全完全依赖三档执行策略（§4.4.0）+ 输出侧限制；docstring `:538-541` 明确警告 Host 策略下输出脱敏**不能**防止秘密外泄（数据已离开进程）。

**`file_search.py`（387 行）——`FilesystemFileSearchMiddleware`**：不实现任何钩子，纯贡献两个工具（`:231-233`）：`glob_search`（`:133-174`，`pathlib.glob` 文件名匹配）与 `grep_search`（`:176-229`，内容搜索：ripgrep 优先（`rg --json`，30s 超时，`:259-310`），失败回退纯 Python 遍历（`_python_search` `:312-353`，`max_file_size_mb=10` 过滤）；三种 `output_mode`：files_with_matches/content/count）。路径安全：`_validate_and_resolve_path`（`:235-257`）拒绝 `..`/`~` 并以 `relative_to(root_path)` 强制根内。注意 ripgrep 分支不做文件大小过滤（仅 Python 回退分支有，见存疑清单）。

#### 4.4.4 效率与测试组（2 个）

**`tool_selection.py`（358 行）——`LLMToolSelectorMiddleware`**：每次模型调用前，用一个（可独立的）小模型从全量工具中**结构化选出子集**，降低 token、聚焦主模型。`wrap_model_call`（`:274-315`）三阶段：
1. `_prepare_selection_request`（`:158-230`）：剔除 provider 原生工具 dict、剔除 `always_include` 名单、取最后一条 HumanMessage；
2. `_create_tool_selection_response`（`:47-78`）：为每个候选工具动态构造 `Annotated[Literal[tool.name], Field(description=…)]` 的 Union + `ToolSelectionResponse` TypedDict——**候选名以 enum 硬约束**给选择模型，从源头防幻觉；
3. `_process_selection_response`（`:232-272`）：精确名匹配（非正则/通配）去重、`max_tools` 截断、重新附加 always_include（不占名额）与 provider 工具，最后 `request.override(tools=…)`。
代价：每次模型调用前多一次选择 LLM 调用。`_render_tool_list`（`:81-90`）已定义但未被调用（存疑清单）。

**`tool_emulator.py`（209 行）——`LLMToolEmulator`**：用 LLM 生成"逼真假结果"**模拟**指定工具（`tools=None` 模拟全部）；命中则**不调用 handler**（真实工具完全不执行），直接以正常 ToolMessage 返回 LLM 输出（`:109-157`）；默认模拟模型 `anthropic:claude-sonnet-4-5-20250929, temperature=1`（`:103`，提示词要求"Introduce variation"）。用途：工具未实现时搭原型、CI 避免真实副作用。

#### 4.4.5 中间件横向总览

| 中间件 | 钩子 | state 新增 | 注册工具 | 外部副作用 |
|---|---|---|---|---|
| SummarizationMiddleware | before_model | 无 | 无 | 摘要 LLM 调用 |
| ContextEditingMiddleware | wrap_model_call | 无 | 无 | 无（deepcopy 副本） |
| TodoListMiddleware | wrap_model_call + after_model | `todos` | `write_todos` | 无 |
| ModelRetryMiddleware | wrap_model_call | 无 | 无 | sleep 等待 |
| ModelFallbackMiddleware | wrap_model_call | 无 | 无 | 备用模型调用 |
| ModelCallLimitMiddleware | before/after_model | 2 个计数字段 | 无 | 注入 AIMessage |
| ToolRetryMiddleware | wrap_tool_call | 无 | 无 | sleep 等待 |
| ToolCallLimitMiddleware | after_model | 2 个计数字典 | 无 | 注入 ToolMessage/AIMessage |
| PIIMiddleware | before/after_model | 无 | 无 | 无 |
| HumanInTheLoopMiddleware | after_model | 无 | 无 | interrupt 暂停整图 |
| ShellToolMiddleware | before/after_agent | `shell_session_resources` | `shell` | 子进程/容器/任意命令 |
| FilesystemFileSearchMiddleware | 无（纯工具贡献） | 无 | `glob_search`、`grep_search` | rg 子进程、文件读取 |
| LLMToolSelectorMiddleware | wrap_model_call | 无 | 无 | 每轮多一次 LLM 调用 |
| LLMToolEmulator | wrap_tool_call | 无 | 无 | 模拟 LLM 调用 |

**模块对外接口**：经 `agents/middleware/__init__.py` 暴露全部中间件类与支撑类型（38 个符号，`:46-84`）。

### 4.5 模块：chat_models（`chat_models/base.py`，1033 行）

**模块职责**：统一模型初始化入口 `init_chat_model`——以 `"provider:model"` 字符串或显式 provider 延迟导入任意 partner 包并实例化模型；`_ConfigurableModel` 提供运行时可切换的"模型代理"。

**文件组成**：

| 符号 | 行号 | 作用 |
|---|---|---|
| `_call` | `:33-35` | 默认 creator：`cls(**kwargs)` |
| `_BUILTIN_PROVIDERS` | `:38-100` | **provider 注册表**：25 个条目，`名称 → (模块路径, 类名, creator)`。特殊 creator：huggingface 用 `from_model_id`、ibm/bedrock 把 `model` 映射为 `model_id`（`:57-66`）。docstring 明示"不穷尽所有 provider，未列出者需显式传 model_provider"（`:89-99`） |
| `_import_module` | `:103-127` | `importlib.import_module` 封装；失败时从模块路径反推 pip 包名并给出安装提示（`:122-127`） |
| `_get_chat_model_creator` | `:130-171` | `functools.lru_cache(len(_BUILTIN_PROVIDERS))` 缓存的工厂解析：未知 provider 抛 `ValueError`（含支持列表）；ollama 特例回退 langchain-community（`:160-168`）；最终 `functools.partial(creator_func, cls=cls)`（`:171`） |
| `init_chat_model` | `:210-507` | 主入口（三重 overload 区分固定模型/可配置模型返回类型，`:174-204`）。逻辑：模型名必须是 str（传对象直接报 TypeError 引导，`:475-481`）；`model` 与 `configurable_fields` 都缺省时默认 `("model","model_provider")` 可配置（`:482-483`）；无可配置字段 → `_init_chat_model_helper` 直接实例化（`:493-498`）；否则返回 `_ConfigurableModel`（`:499-507`）。docstring 含 12 条前缀推断规则与安全提示（`configurable_fields="any"` 允许运行时改 `api_key`/`base_url`，`:324-331`） |
| `_init_chat_model_helper` | `:510-518` | `_parse_model` → `_get_chat_model_creator` → `creator_func(model=…, **kwargs)` |
| `_attempt_infer_model_provider` | `:521-594` | 前缀推断：`gpt-/o1/o3/chatgpt/text-davinci→openai`、`claude→anthropic`、`gemini→google_vertexai`（发 DeprecationWarning：下个大版本改 google_genai，`:559-568`）、`amazon./anthropic./meta.→bedrock` 等 12 条 |
| `_parse_model` | `:597-625` | 解析 `provider:model` 前缀（仅当前缀在注册表内才拆分，`:600-606`）→ 前缀推断 → 都失败抛含支持列表的 `ValueError`（`:611-621`）→ provider 归一化（`-`→`_`、lower，`:624`） |
| `_DECLARATIVE_METHODS` | `:632` | `("bind_tools", "with_structured_output")`——可延迟应用的声明式方法 |
| `_ConfigurableModel` | `:635-1033` | 运行时可配置模型代理（见下） |

**`_ConfigurableModel`（`Runnable` 子类）——代理 + 声明式操作队列模式**：

- `__init__`（`:636-657`）：`default_config`、`configurable_fields`（"any" 或白名单）、`config_prefix`（自动补 `_`，`:648-652`）、`queued_declarative_operations`（待重放操作队列）。
- `__getattr__`（`:659-687`）：核心机制三分支——
  1. 名称属 `_DECLARATIVE_METHODS`（bind_tools/with_structured_output）：**不入模型对象**，而是返回 `queue` 函数把 `(名, args, kwargs)` 追加进队列并返回新的 `_ConfigurableModel`（不可变风格，`:666-680`）；
  2. 有默认配置且能实例化模型：透传模型属性（`:681-682`）；
  3. 否则 `AttributeError`（`:683-687`）。
- `_model(config)`（`:689-694`）：合并 default_config 与运行时参数后真正实例化，再按序重放声明式队列（`:692-693`）。
- `_model_params`（`:696-705`）：从 `config["configurable"]` 里按前缀过滤出模型参数；非 "any" 时再按白名单过滤（安全边界）。
- `with_config`（`:707-738`）：把配置"固化"进 default_config，剩余配置转 `with_config` 操作入队。
- 执行方法全family（`invoke/ainvoke/stream/astream/batch/abatch/batch_as_completed/abatch_as_completed/transform/atransform/astream_log/astream_events`，`:750-1017`）：一律 `self._model(config).<method>(...)` 委托——**每次调用都可能实例化新模型**，切换 provider 零成本。
- `bind_tools`/`with_structured_output` 显式定义仅为满足下游 linter，内部走 `__getattr__` 队列（`:1020-1033`）。

**对外接口**：`init_chat_model`（+ 内部 `_ConfigurableModel`）。被 `agents/factory.py:850-851`、`model_fallback.py:68`、`summarization.py:250-251`、`tool_selection.py:156`、`tool_emulator.py:103,107` 引用——是全包模型获取的唯一咽喉。

### 4.6 模块：embeddings（`embeddings/base.py`，275 行）

**模块职责**：嵌入模型的对称工厂 `init_embeddings`，结构是 chat_models 的简化版（无可配置代理）。

| 符号 | 行号 | 说明 |
|---|---|---|
| `_BUILTIN_PROVIDERS` | `:15-54` | 10 个 provider（azure_ai/azure_openai/bedrock/cohere/google_genai/google_vertexai/huggingface/mistralai/ollama/openai）；bedrock/huggingface 特殊 creator 映射 `model_id`/`model_name`（`:18-30`） |
| `_get_embeddings_class_creator` | `:57-93` | 与 chat 版同构：lru_cache + `functools.partial(creator_func, cls=cls)` |
| `_parse_model_string` | `:103-155` | 严格要求 `provider:model` 格式（无 provider 推断，缺冒号即 `ValueError`，`:129-139`） |
| `_infer_model_and_provider` | `:158-188` | model 串带冒号则解析，否则必须显式 `provider` |
| `init_embeddings` | `:191-269` | 入口：解析 provider → creator 实例化；0.3.9 版本引入（`:260`） |

与 chat 版的差异：不支持 bare 名推断、无 `_ConfigurableModel`、provider 集合更小。

### 4.7 模块：messages / rate_limiters / tools（纯重导出）

见 §4.1 门面层表格——这三个目录不含任何逻辑，仅从 langchain-core（消息类型、限流器）与 langgraph（ToolNode 系、注入注解）转发符号。`tools/__init__.py` 中 `InjectedState/InjectedStore/ToolRuntime` 来自 `langchain.tools.tool_node`（向后兼容文件，`tools/tool_node.py:3-11`）。

---

## 5. 文件清单总表（全部 31 个生产源文件）

| # | 文件路径（相对仓库根） | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|---|
| 1 | `libs/langchain_v1/langchain/__init__.py` | 包根 | 版本标识 | `__version__` | 无 |
| 2 | `…/langchain/agents/__init__.py` | 门面 | agent 入口导出 | `create_agent`、`AgentState` | factory、middleware.types |
| 3 | `…/langchain/agents/factory.py` | agents 核心 | agent 工厂：装配 StateGraph | `create_agent`（+13 个私有函数） | langchain-core、langgraph、langsmith、middleware.types、structured_output、chat_models |
| 4 | `…/langchain/agents/structured_output.py` | agents 核心 | 结构化输出三策略 | `ToolStrategy`、`ProviderStrategy`、`AutoStrategy`、`ResponseFormat`、`OutputToolBinding`、`ProviderStrategyBinding`、3 个异常 | langchain-core.tools、pydantic |
| 5 | `…/langchain/agents/middleware/__init__.py` | 门面 | 中间件库总门面 | 38 个符号（全部中间件 + 类型 + 装饰器 + Runtime） | 全部实现模块、langgraph |
| 6 | `…/langchain/agents/middleware/types.py` | middleware 类型系统 | 契约层：基类/请求响应/装饰器 | `AgentMiddleware`、`AgentState`、`ModelRequest`、`ModelResponse`、`ExtendedModelResponse`、`OmitFromSchema`、8 装饰器等 | langchain-core、langgraph |
| 7 | `…/middleware/_execution.py` | middleware 支撑 | shell 执行策略三档 | `BaseExecutionPolicy`、`Host/CodexSandbox/DockerExecutionPolicy`、`SHELL_TEMP_PREFIX` | stdlib(subprocess/resource/shutil) |
| 8 | `…/middleware/_redaction.py` | middleware 支撑 | PII 检测/脱敏共享库 | `PIIMatch`、`PIIDetectionError`、`RedactionRule`、`ResolvedRedactionRule`、`apply_strategy`、5 个 detect_* | stdlib(re/ipaddress/hashlib/urllib) |
| 9 | `…/middleware/_retry.py` | middleware 支撑 | 重试共享逻辑 | `RetryOn`、`OnFailure`、`validate_retry_params`、`should_retry_exception`、`calculate_delay` | stdlib(random) |
| 10 | `…/middleware/context_editing.py` | 上下文管理 | 工具结果占位符压缩 | `ContextEditingMiddleware`、`ClearToolUsesEdit`、`ContextEdit`(Protocol) | langchain-core、types |
| 11 | `…/middleware/file_search.py` | 工具贡献 | 文件搜索两工具 | `FilesystemFileSearchMiddleware`（内部 glob_search/grep_search） | langchain-core.tools、stdlib(subprocess/pathlib/re) |
| 12 | `…/middleware/human_in_the_loop.py` | 安全/HITL | 人工审批 | `HumanInTheLoopMiddleware`、`InterruptOnConfig`、`HITLRequest/Response`、4 种 Decision | langgraph(interrupt)、types |
| 13 | `…/middleware/model_call_limit.py` | 可靠性 | 模型调用上限 | `ModelCallLimitMiddleware`、`ModelCallLimitExceededError` | types、langchain-core |
| 14 | `…/middleware/model_fallback.py` | 可靠性 | 模型降级 | `ModelFallbackMiddleware` | types、chat_models |
| 15 | `…/middleware/model_retry.py` | 可靠性 | 模型重试 | `ModelRetryMiddleware` | `_retry`、types |
| 16 | `…/middleware/pii.py` | 安全 | PII 检测脱敏 | `PIIMiddleware`、`PIIDetectionError`（+转发 `_redaction` 7 符号） | `_redaction`、types |
| 17 | `…/middleware/shell_tool.py` | 安全/工具 | 持久 shell 会话 | `ShellToolMiddleware`、`HostExecutionPolicy` 等（转发）、`ShellSession`(内部) | `_execution`、`_redaction`、langgraph、types |
| 18 | `…/middleware/summarization.py` | 上下文管理 | 历史自动摘要 | `SummarizationMiddleware`、`ContextSize` 系列 | langchain-core(trim/count_tokens)、chat_models、types |
| 19 | `…/middleware/todo.py` | 上下文管理 | 任务清单 | `TodoListMiddleware`、`Todo`、`write_todos`(@tool 独立版) | langchain-core.tools、types |
| 20 | `…/middleware/tool_call_limit.py` | 可靠性 | 工具调用上限 | `ToolCallLimitMiddleware`、`ToolCallLimitExceededError` | types、langchain-core |
| 21 | `…/middleware/tool_emulator.py` | 测试 | LLM 模拟工具 | `LLMToolEmulator` | types、chat_models |
| 22 | `…/middleware/tool_retry.py` | 可靠性 | 工具重试 | `ToolRetryMiddleware` | `_retry`、types |
| 23 | `…/middleware/tool_selection.py` | 效率 | LLM 选工具子集 | `LLMToolSelectorMiddleware` | types、chat_models |
| 24 | `…/langchain/chat_models/__init__.py` | 门面 | 导出 | `BaseChatModel`、`init_chat_model` | core、base |
| 25 | `…/langchain/chat_models/base.py` | chat_models | 模型工厂+可配置代理 | `init_chat_model` | langchain-core、importlib |
| 26 | `…/langchain/embeddings/__init__.py` | 门面 | 导出 | `Embeddings`、`init_embeddings` | core、base |
| 27 | `…/langchain/embeddings/base.py` | embeddings | 嵌入工厂 | `init_embeddings` | langchain-core、importlib |
| 28 | `…/langchain/messages/__init__.py` | 门面 | 消息类型转发 | 32 个消息/内容块符号 | langchain-core |
| 29 | `…/langchain/rate_limiters/__init__.py` | 门面 | 限流器转发 | `BaseRateLimiter`、`InMemoryRateLimiter` | langchain-core |
| 30 | `…/langchain/tools/__init__.py` | 门面 | 工具符号转发 | `BaseTool`、`tool`、`Injected*`、`ToolRuntime`、`ToolException` | core、langgraph |
| 31 | `…/langchain/tools/tool_node.py` | 门面 | 向后兼容 | `ToolNode`、`ToolCallRequest`、`ToolCallWrapper` 等 | langgraph.prebuilt |

（`…` = `libs/langchain_v1/langchain`；表中"职责/导出/行号"均已在正文 §4 逐一核对。）

## 6. 关键函数深度解析

以下 8 个函数覆盖本包最核心的业务链路，每个给出带行号的代码片段与逐段解读。

### 6.1 `create_agent`（`agents/factory.py:697-1679`）——主工厂

签名（`:697-716`）：

```python
def create_agent(
    model: str | BaseChatModel,
    tools: Sequence[BaseTool | Callable[..., Any] | dict[str, Any]] | None = None,
    *,
    system_prompt: str | SystemMessage | None = None,
    middleware: Sequence[AgentMiddleware[StateT_co, ContextT]] = (),
    response_format: ResponseFormat[ResponseT] | type[ResponseT] | dict[str, Any] | None = None,
    state_schema: type[AgentState[ResponseT]] | None = None,
    context_schema: type[ContextT] | None = None,
    checkpointer: Checkpointer | None = None,
    store: BaseStore | None = None,
    interrupt_before: list[str] | None = None,
    interrupt_after: list[str] | None = None,
    debug: bool = False,
    name: str | None = None,
    cache: BaseCache[Any] | None = None,
    transformers: Sequence[Callable[[tuple[str, ...]], Any]] | None = None,
) -> CompiledStateGraph[...]:
```

逐段实现逻辑（装配期，共 8 步）：

**① 模型与提示归一（`:849-863`）**：`model` 为 str 则 `init_chat_model(model)`；`system_prompt` 统一转 `SystemMessage`；`tools=None` 归一为 `[]`。

**② 响应格式预处理（`:865-894`）**：裸 schema（Pydantic/dataclass/TypedDict/dict）包成 `AutoStrategy`（`:880`）；AutoStrategy 再转出 `tool_strategy_for_setup` 用于**装配期**就把结构化输出工具建好（`:884-888`）；对每个 schema spec 生成 `OutputToolBinding`（含假工具）存入 `structured_output_tools` dict（`:890-894`）。

**③ 中间件收集与包装链组装（`:895-1036`）**：
- `middleware_tools`：展开所有中间件注册的工具（`:895`）；
- 以"类属性是否仍为基类方法"识别覆写了 `wrap_tool_call`/`awrap_tool_call` 的中间件（`:900-905`——两种版本任一覆写即入选，保证只实现一半时在错误路径上抛 `NotImplementedError`）；
- 每个钩子先用 `langsmith.traceable(name=f"{m.name}.wrap_tool_call", process_inputs=_scrub_inputs)` 包装（可观测，`:911-915`），再经 `_chain_tool_call_wrappers` 合成洋葱（`:916`）；wrap_model_call 同理（`:1016-1036`）；
- 重名中间件直接 `AssertionError`（`:970-972`）。

**④ ToolNode 构建（`:939-967`）**：dict 形态的 tools 是 provider 原生工具（built-in，不进 ToolNode）；其余与中间件工具合并进 `ToolNode(tools=…, wrap_tool_call=…, awrap_tool_call=…)`（`:950-958`）——**即使没有任何工具，只要存在 wrap_tool_call 包装链也建 ToolNode**（处理动态工具场景）。`default_tools`（ModelRequest 的基线工具）取 ToolNode 转换后的实例 + built-ins（`:964-967`）。

**⑤ schema 合并（`:1038-1046`）**：

```python
state_schemas: list[type] = [*(m.state_schema for m in middleware), base_state]  # :1044
resolved_state_schema, input_schema, output_schema = _resolve_schemas(state_schemas)
```
中间件 schema 按注册顺序在前、用户 `state_schema`（或 AgentState）**最后**——同名字段后声明者胜出，用户可用显式 schema 覆盖中间件注解（`:1039-1043` 注释解释了这一设计意图）。

**⑥ 图节点注册（`:1048-1475`）**：`StateGraph(state_schema/input/output/context_schema)`（`:1051-1056`）；`model` 节点以 `RunnableCallable(model_node, amodel_node, trace=False)` 注册（`:1387`）；`tools` 节点（`:1390-1391`）；每个覆写了 before/after 钩子的中间件注册为独立节点 `f"{m.name}.before_agent"` 等（`:1394-1475`，同样用"是否覆写"判断，未覆写的槽位传 None）。

**⑦ 边与路由（`:1477-1661`）**：确定四个关键节点名——`entry_node`（首个 before_agent，否则首个 before_model，否则 model）、`loop_entry_node`（首个 before_model 或 model）、`loop_exit_node`（首个 after_model 或 model）、`exit_node`（最后一个 after_agent 或 END）（`:1477-1503`）；`START→entry`（`:1505`）；有工具时挂两条条件路由（`tools` 出边 `:1517-1529`、`loop_exit` 出边 `:1541-1552`，目的地集合按 return_direct/结构化输出/after_model 动态扩容 `:1510-1539`）；无工具但有结构化输出工具时挂 model→model 重试环（`:1553-1564`）；各钩子链按 §2.3 所述顺序/逆序连边（`:1579-1661`）。

**⑧ 编译与元数据（`:1663-1679`）**：

```python
config: RunnableConfig = {"recursion_limit": 9_999}        # :1665 规避 langgraph#7313
config["metadata"] = {"ls_integration": "langchain_create_agent"}  # :1666
return graph.compile(checkpointer=…, store=…, interrupt_before/after=…,
                     debug=…, name=…, cache=…,
                     transformers=[ToolCallTransformer, *(transformers or ())]).with_config(config)
```
`recursion_limit=9999`：agent 循环由条件边自行终止，图深度由业务决定而非引擎默认 25 步。

**副作用**：`init_chat_model` 触发 partner 包导入；`assert` 校验（`-O` 下跳过）；闭包大量捕获装配期变量（model/default_tools/…），因此**同一 agent 的并发调用共享这些对象**。

### 6.2 `_chain_model_call_handlers`（`agents/factory.py:221-310`）——洋葱组合器

```python
# :271-303（摘）
def compose_two(outer, inner):
    def composed(request, handler):
        accumulated_commands: list[Command[Any]] = []          # :282
        def inner_handler(req):                                 # :284
            accumulated_commands.clear()                        # :286 每次调用清空（重试安全）
            inner_result = inner(req, handler)
            if isinstance(inner_result, _ComposedExtendedModelResponse):
                accumulated_commands.extend(inner_result.commands)  # :289 收集内层命令
                return inner_result.model_response              # :290 内层边界归一化
            ...
        outer_result = outer(request, inner_handler)            # :297
        return _to_composed_result(outer_result, extra_commands=accumulated_commands or None)
    return composed

composed_handler = compose_two(handlers[-2], handlers[-1])      # :306 从最内两个开始
for h in reversed(handlers[:-2]):                               # :307 右折叠
    composed_handler = compose_two(h, composed_handler)
```

解读：**右折叠洋葱**。列表 `[m1, m2, m3]` 组装成 `m1(m2(m3(核心)))`。关键设计有三：
1. **命令累积闭包**：内层返回的 `Command` 被拦下存入 `accumulated_commands`，内层 handler 对外只暴露归一化的 `ModelResponse`——每个中间件视角纯净，不必感知其他层的命令；
2. **`clear()` 保证重试安全**：外层多次调用 `inner_handler`（重试）时，上一次的残留命令被清空，不会重复应用（`:286`）；
3. `_to_composed_result`（`:242-258`）把三种合法返回值（`ModelResponse`/`AIMessage`/`ExtendedModelResponse`）统一成 `_ComposedExtendedModelResponse`，命令顺序保持**内层先、外层后**（`:73` docstring）。
异步版 `_chain_async_model_call_handlers`（`:313-401`）逐行同构，仅加 `await`。

### 6.3 `_get_bound_model`（`agents/factory.py:1162-1289`，create_agent 内嵌）——模型绑定与策略自动检测

三段逻辑：
1. **动态工具校验（`:1181-1209`）**：无 wrap_tool_call 时，request.tools 里出现 ToolNode 不认识的 BaseTool 名即抛 `ValueError`（用 `DYNAMIC_TOOL_ERROR_TEMPLATE`，`:1205-1209`）；有 wrap_tool_call 则跳过（中间件可能自己处理动态工具）。
2. **策略决策（`:1211-1234`）**：raw schema 包 AutoStrategy → `_supports_provider_strategy(model, tools)` 为真则升级 `ProviderStrategy`，否则降级 `ToolStrategy`（尽量复用装配期的 `tool_strategy_for_setup` 以保持工具名稳定，`:1226-1229`）；用户显式指定的策略原样保留。
3. **三种绑定分支（`:1236-1289`）**：ProviderStrategy → `bind_tools(final_tools, strict=True, **response_format kwargs)`（`:1249-1253`）；ToolStrategy → 校验 middleware 改过的 strategy 不得引入未前置声明的结构化工具（`:1263-1270`）→ `bind_tools(final_tools + 结构化假工具, tool_choice="any")`（强制调用，`:1273-1277`）；无结构化输出 → 常规 `bind_tools` 或裸 `bind`（`:1282-1289`）。

### 6.4 `_handle_model_output`（`agents/factory.py:1058-1160`，create_agent 内嵌）——结构化输出解析与自纠错

```python
# ToolStrategy 路径（:1087-1158 摘）
structured_tool_calls = [tc for tc in output.tool_calls
                         if tc["name"] in structured_output_tools]   # :1092-1094
if len(structured_tool_calls) > 1:                                    # 多个→异常
    exception = MultipleStructuredOutputsError(tool_names, output)   # :1101
    should_retry, error_message = _handle_structured_output_error(...)
    if not should_retry: raise exception                              # :1106
    return {"messages": [output, *错误ToolMessage×N]}                 # :1109-1117 回喂重试
tool_call = structured_tool_calls[0]
try:
    structured_response = structured_output_tools[tool_call["name"]].parse(tool_call["args"])  # :1123
    return {"messages": [output, ToolMessage(回执)], "structured_response": structured_response}
except Exception as exc:
    exception = StructuredOutputValidationError(tool_call["name"], exc, output)  # :1142
    should_retry, error_message = _handle_structured_output_error(...)
    if not should_retry: raise validation_error from exc             # :1147
    return {"messages": [output, ToolMessage(错误信息)]}              # :1149-1158 回喂重试
```

解读：结构化输出是**图级自纠错回路**——解析失败不直接失败，而是把 pydantic 校验错误包装成 ToolMessage 喂回模型（`STRUCTURED_OUTPUT_ERROR_TEMPLATE`，`:109`），由 `model_to_tools` 路由第 6 步拉回 model 节点重新生成（`:1765-1767`）。是否重试由 `ToolStrategy.handle_errors` 五形态控制（`:555-582`）。ProviderStrategy 路径（`:1069-1084`）则对无 tool_calls 的输出直接 `ProviderStrategyBinding.parse`（JSON 抽取+校验），失败抛 `StructuredOutputValidationError`（不重试）。

### 6.5 `_make_model_to_tools_edge.model_to_tools`（`agents/factory.py:1724-1769`）——循环出口路由

六步决策（优先级从高到低）：
1. `state["jump_to"]` 显式指令 → `_resolve_jump`（`:1728-1733`）；
2. 找不到 AIMessage（如消息被清空）→ end（`:1737-1739`）；
3. 最后一条 AIMessage 无 tool_calls → end（**经典退出条件**，`:1745-1746`）；
4. 存在"未被 ToolMessage 应答且非结构化输出工具"的调用 → `return [Send("tools", [tool_call]) for …]` **并行扇出**（`:1748-1759`；注释说明 ToolRuntime 在执行时才水合 state，避免旧实现 O(N²) 的 TASKS 写放大）；
5. state 已有 `structured_response` → end（`:1762-1763`）；
6. 有 tool_calls 但全部被人工 ToolMessage 应答（如 HITL reject）→ 回 model（`:1765-1767`）。

### 6.6 `init_chat_model` 及其解析链（`chat_models/base.py:210-507,510-625`）

主流程（`:475-507`）：类型检查（传模型对象直接 TypeError 并引导直接使用，`:475-481`）→ `configurable_fields` 缺省推导（`:482-483`）→ 固定模型走 `_init_chat_model_helper`，可配置走 `_ConfigurableModel`。解析链 `_parse_model`（`:597-625`）：前缀 `provider:model` **仅当前缀在 `_BUILTIN_PROVIDERS` 注册表内才拆**（`:600-606`，避免把含冒号的模型名误拆）→ `_attempt_infer_model_provider` 前缀推断（12 条规则，`:521-594`）→ 失败抛含支持列表的 `ValueError` → provider 归一化。实例化经 `_get_chat_model_creator` 的 lru_cache（`:130-171`）延迟导入 partner 包——**首次** `init_chat_model("openai:…")` 才 import langchain_openai。

### 6.7 `_ConfigurableModel.__getattr__` / `_model`（`chat_models/base.py:659-694`）——声明式操作队列

```python
if name in _DECLARATIVE_METHODS:                       # :660 bind_tools/with_structured_output
    def queue(*args, **kwargs):                        # :666
        queued = list(self._queued_declarative_operations)
        queued.append((name, args, kwargs))            # :670 记录而非执行
        return _ConfigurableModel(..., queued_declarative_operations=queued)  # :671-677
    return queue
if self._default_config and (model := self._model()) and hasattr(model, name):
    return getattr(model, name)                        # :681-682 透传默认模型属性
raise AttributeError(...)                              # :683-687
```

`_model(config)`（`:689-694`）在真正执行时合并 default_config + 运行时 `configurable` 参数（经 `_model_params` 前缀过滤 + 白名单过滤 `:696-705`）实例化模型，然后**按序重放**队列里的声明式操作。效果：`configurable_model.bind_tools([...])` 不绑定任何具体模型，返回仍是可配置代理；invoke 时按当次 config 选定的模型应用 bind_tools——切换 provider 时工具绑定不丢。

### 6.8 `HumanInTheLoopMiddleware.after_model`（`middleware/human_in_the_loop.py:313-398`）——运行时中断

```python
decisions = interrupt(hitl_request)["decisions"]        # :362 图在此暂停
if len(decisions) != len(interruptible_tool_calls): raise ValueError(...)  # :365-370
revised_tool_calls, artificial_tool_messages = [], []
for i, tool_call in enumerate(last_ai_msg.tool_calls):
    if i in hitl_map:                                    # 被审批的调用
        revised, tool_message = self._process_decision(tool_call, decisions[idx], ...)
        revised_tool_calls.append(revised)
        if tool_message: artificial_tool_messages.append(tool_message)
    else:
        revised_tool_calls.append(tool_call)             # 未配置→自动放行 :387-388
last_ai_msg.tool_calls = revised_tool_calls              # :396 原地改写
return {"messages": [last_ai_msg, *artificial_tool_messages]}  # :398
```

解读：这是"**编译期静态图 + 运行期动态中断**"的混合控制流——不在 `create_agent(interrupt_before=["tools"])` 层面配置，而是在 after_model 钩子内直接调 langgraph 的 `interrupt()` 原语。reject/respond 产生的人工 ToolMessage 恰好"应答"了对应 tool_call，`model_to_tools` 第 4 步因无未应答调用而不再 Send，第 6 步把控制权交回模型——工具被跳过且消息配对完整（OpenAI API 要求每个 tool_call 必须有 ToolMessage 应答）。代价：`last_ai_msg.tool_calls` 被**原地变异**（`:396`），且恢复依赖 checkpointer。

## 7. 端到端调用链分析

### 7.1 场景设定

构造一个覆盖面最大的典型场景——带中间件、工具、结构化输出与人工审批：

```python
from langchain.agents import create_agent
from langchain.agents.middleware import SummarizationMiddleware, HumanInTheLoopMiddleware

graph = create_agent(
    model="openai:gpt-5",
    tools=[check_weather],                                    # 普通函数工具
    system_prompt="You are a helpful assistant",
    middleware=[
        SummarizationMiddleware("openai:gpt-5-mini", trigger=("tokens", 8000)),
        HumanInTheLoopMiddleware(interrupt_on={"check_weather": True}),
    ],
    response_format=WeatherReport,                            # Pydantic 模型（裸 schema）
    checkpointer=InMemorySaver(),                             # interrupt 恢复所需
)
result = graph.invoke(
    {"messages": [{"role": "user", "content": "SF 天气如何？整理成报告"}]},
    config={"configurable": {"thread_id": "t1"}},
)
```

### 7.2 装配期调用链（create_agent 一次执行）

| 步 | 文件:函数 | 动作 |
|---|---|---|
| 1 | `factory.py:850-851` → `chat_models/base.py:210 init_chat_model` → `:510 _init_chat_model_helper` → `:597 _parse_model`（前缀 `openai` 拆出）→ `:130 _get_chat_model_creator`（lru_cache，import langchain_openai）| 得到 `ChatOpenAI(model="gpt-5")` |
| 2 | `factory.py:879-880` | `WeatherReport`（裸 schema）→ `AutoStrategy` |
| 3 | `factory.py:885-894` → `structured_output.py:194 ToolStrategy.__init__` → `:105 _SchemaSpec`（推导 name/json_schema）→ `:307 OutputToolBinding.from_schema_spec`（`StructuredTool(args_schema=…)` 假工具，`:340-344`）| 建好 `structured_output_tools={"WeatherReport": binding}` |
| 4 | `factory.py:895-937` | 收集中间件工具（本例无）、wrap_tool_call 链（本例无） |
| 5 | `factory.py:940-958` | `available_tools=[check_weather]` → `ToolNode(tools=[…])`（langgraph 把函数转 `BaseTool`） |
| 6 | `factory.py:973-1036` | 识别钩子：Summarization 覆写 before_model；HITL 覆写 after_model；各自用 `traceable` 包装（可观测），wrap_model_call 链为空 |
| 7 | `factory.py:1038-1046` → `:410 _resolve_schemas` → `:425 _resolve_schema` | state = [Summarization 默认 schema, AgentState] 合并 TypedDict（后声明覆盖） |
| 8 | `factory.py:1049-1056` | `StateGraph(state/input/output/context_schema)` |
| 9 | `factory.py:1387-1391` | 注册 `model` 节点（RunnableCallable 双轨）、`tools` 节点 |
| 10 | `factory.py:1394-1475` | 注册 `SummarizationMiddleware.before_model`、`HumanInTheLoopMiddleware.after_model` 节点 |
| 11 | `factory.py:1477-1503` | entry=`SummarizationMiddleware.before_model`；loop_entry 同；loop_exit=`HumanInTheLoopMiddleware.after_model`；exit=END |
| 12 | `factory.py:1505-1564` | 边：START→entry；model→HITL.after_model（逆序链只有一层）；HITL.after_model 条件路由 → [loop_entry, tools, END]；tools 条件路由 → [loop_entry, END]（有结构化工具，`:1511-1515`） |
| 13 | `factory.py:1670-1679` | `compile(checkpointer=…, transformers=[ToolCallTransformer])` + `with_config({"recursion_limit": 9999, metadata…})` |

装配产物图：

```
START → Summarization.before_model → model → HITL.after_model ─┬→ Summarization.before_model（循环）
                                   ▲                          ├→ tools ──┐
                                   └──────────────────────────┘          ├→ Summarization.before_model
                                                                         └→ END
```

### 7.3 运行期调用链（invoke，含中断与恢复）

```
用户 invoke({"messages":[user]}, thread_id="t1")
  │ ① LangGraph 引擎（外部）：加载 checkpoint、输入经 add_messages 归并
  ▼
② Summarization.before_model（summarization.py:293）
  │   token 计数 < 8000 → 返回 None（首轮不摘要）
  ▼
③ model 节点（factory.py:1318 model_node）
  │   组装 ModelRequest（model/tools=default_tools/system_message/response_format=AutoStrategy/…）
  │   wrap_model_call_handler 为 None → 直接 _execute_model_sync（factory.py:1291）
  │     ├ _get_bound_model（factory.py:1162）
  │     │   AutoStrategy → _supports_provider_strategy（factory.py:510）
  │     │     ChatOpenAI gpt-5 命中 FALLBACK 名单（factory.py:150-160）→ ProviderStrategy
  │     │   → bind_tools([check_weather], strict=True, response_format={json_schema…})
  │     │     （structured_output.py:285 to_model_kwargs 产出 OpenAI 原生格式）
  │     ├ model_.invoke([SystemMessage, *messages])（factory.py:1304）→ AIMessage
  │     └ _handle_model_output（factory.py:1058）：ProviderStrategy 且无 tool_calls
  │         → ProviderStrategyBinding.parse（structured_output.py:394）
  │           抽文本 → json.loads → TypeAdapter 校验 → structured_response
  │   返回 [Command(update={"messages":[ai], "structured_response": obj})]
  ▼
④ HITL.after_model（human_in_the_loop.py:313）
  │   AIMessage.tool_calls = [check_weather(...)] 命中 interrupt_on
  │   组装 HITLRequest → interrupt(...)（:362）═════════╗
  ▼                                                    ║ 图暂停，状态入 checkpoint
（invoke 返回 Interrupt 信息给调用方）                    ║
                                                       ║
人工决策后：graph.invoke(Command(resume={"decisions":
  [ApproveDecision(...)]}), config=同 thread_id) ──────╝
  │ ⑤ after_model 从中断点重放：_process_decision approve → (原 tool_call, None)
  │    返回 {"messages":[ai]}（无人工 ToolMessage）
  ▼
⑥ 路由 model_to_tools（factory.py:1724）
  │   第 4 步：check_weather 未被应答 → [Send("tools", [tool_call])]
  ▼
⑦ tools 节点（langgraph ToolNode，外部）
  │   wrap_tool_call 链为空 → BaseTool.invoke → ToolMessage（天气数据）
  ▼
⑧ 路由 tools_to_model（factory.py:1806）
  │   非 return_direct、非结构化工具 → loop_entry
  ▼
⑨ 循环：Summarization.before_model（可能触发摘要重建历史）→ model（再次
  │   _get_bound_model/_handle_model_output）→ …
  ▼
⑩ 某轮模型返回纯文本 AIMessage（无 tool_calls、无结构化输出）
  │   HITL.after_model：无 tool_calls → None
  │   路由第 3 步 → END
  ▼
⑪ 按 _OutputAgentState 过滤 → result = {"messages":[全部消息],
     "structured_response": WeatherReport(...)}
```

（若模型走的是 ToolStrategy 分支：③ 中 `tool_choice="any"` 强制调用，模型调用 `WeatherReport` 假工具后，`_handle_model_output` 解析 args 并追加回执 ToolMessage；⑥ 路由第 5 步已有 structured_response → 直接 END；⑧ 的对应分支见 `tools_to_model` 第 3 步 `:1824-1825`。）

### 7.4 关键时序小结

- **中断-恢复**只在 ④⑤ 出现一次：`interrupt()` 抛出 → 引擎持久化 → 人工 `Command(resume=…)` → 从 after_model 断点继续。
- **循环控制权**完全由两个路由函数持有（`factory.py:1724/1806`），节点本身无循环逻辑。
- **可观测埋点**在装配期已织入（每个钩子被 `traceable` 包装），运行期自动产出 LangSmith 追踪树。

---

## 8. 横切机制说明

### 8.1 错误处理与异常体系

| 机制 | 位置 | 方式 |
|---|---|---|
| 结构化输出异常族 | `structured_output.py:35-74` | `StructuredOutputError` 基类（携带 `ai_message` 便于排查）→ `MultipleStructuredOutputsError` / `StructuredOutputValidationError`（保留 `source` 链） |
| 自纠错回路 | `factory.py:1102-1158` + 路由 `:1765-1767` | 校验错误 → ToolMessage 回喂 → 回模型重试；由 `ToolStrategy.handle_errors` 五形态控制（bool/str/类型/元组/回调，`:555-582`） |
| 模型重试/降级 | `model_retry.py` / `model_fallback.py` | wrap_model_call 洋葱内捕获：重试（指数退避+jitter，`_retry.py:85-123`）→ 降级（依序换模型）→ 最终按 `on_failure` 重抛或注入错误 AIMessage |
| 工具重试 | `tool_retry.py:288-403` | 同上，产物为 `ToolMessage(status="error")`；工具节点层另有 `handle_tool_errors`（langgraph，外部）兜底 |
| 调用上限 | `model_call_limit.py` / `tool_call_limit.py` | 计数字段 + `jump_to="end"` 优雅退出或抛专用异常 |
| 阻断式安全异常 | `_redaction.py:29-43,333-334` | `PIIDetectionError`（block 策略）直接上抛终止 |
| 装配期校验 | `factory.py:970-972,1203-1209`；各中间件 `__init__` | 重名中间件 AssertionError、动态工具 ValueError、参数负值 ValueError 等，全部 fail-fast |
| 同步/异步错配 | `types.py:561-623,719-798` | wrap 钩子未实现的执行路径抛带修复指引的 `NotImplementedError` |

### 8.2 可观测性（追踪/日志）

- **LangSmith 追踪**：装配期把每个中间件的 `wrap_tool_call`/`awrap_tool_call`/`wrap_model_call`/`awrap_model_call` 用 `langsmith.traceable(name=f"{m.name}.<hook>", process_inputs=_scrub_inputs)` 包装（`factory.py:911,932,1020,1031`）；`_scrub_inputs`（`:138-147`）剔除 `handler`、剥离 `request.runtime`，避免不可序列化对象进入追踪。
- **集成标识**：`config["metadata"]["ls_integration"]="langchain_create_agent"`（`:1666`）、`lc_agent_name`（`:1668`）、摘要消息的 `lc_source: "summarization"`（`summarization.py:510,515`）。
- **日志**：仅 `shell_tool.py:56` 定义 `LOGGER`（超时重启、shutdown 失败等 warning，`:300-305,734-749`）；其余模块零日志、零 print——库代码以异常和追踪表达问题。

### 8.3 配置管理

包本身无多环境配置文件/环境变量读取。运行时"配置面"有三：① `init_chat_model` 的 provider 注册表（`chat_models/base.py:38-100`，新增 provider 的扩展点，`:207-209` 的贡献者注释）；② `_ConfigurableModel` 的 `config["configurable"]` 运行时参数（前缀 + 白名单双重隔离，`:696-705`）；③ 中间件构造参数（每次实例化即配置）。

### 8.4 权限/安全控制

- **人工审批**：HITL 中断（§4.4.3）。
- **PII 治理**：检测→block/redact/mask/hash 四策略（§4.4.3）；`_normalizing_detector` 可外接 Presidio 类检测器（`_redaction.py:378-393`）。
- **代码执行隔离**：三档执行策略（Host rlimit / Codex 系统调用沙箱 / Docker 容器默认断网，`_execution.py`）；进程组整树回收 + `weakref.finalize` 兜底（`shell_tool.py:91-97,401-410`）。
- **文件访问**：根目录约束 + 路径穿越黑名单（`file_search.py:235-257`）。
- **模型侧**：`configurable_fields="any"` 的重定向风险已在 docstring 警告（`chat_models/base.py:324-331`）。

### 8.5 并发/异步处理模式

- **sync/async 双轨全对称**：12 个钩子、两个组合器、两个路由工厂、model 节点（`RunnableCallable(model_node, amodel_node)`）均成对实现；部分中间件 async 版直接委托同步版（如 `model_call_limit.py:233`），shell 会话的 `abefore_agent` 用 `run_in_executor` 包装阻塞启动（`shell_tool.py:643-655`）。
- **工具并行**：路由函数返回 `Send` 列表（`factory.py:1759`），ToolNode map-reduce 并行执行同一 AIMessage 的多个 tool_calls。
- **持久会话串行化**：`ShellSession._lock` 互斥写 stdin（`shell_tool.py:226`）；marker uuid 区分并发输出（`:223`）。
- **检查点友好**：run 级计数用 `UntrackedValue`、shell 句柄用 `UntrackedValue`（不可序列化对象不进 checkpoint，恢复时重建/复用）。

### 8.6 持久化 / 缓存 / 限流 / 定时任务

- **持久化**：`create_agent(checkpointer=…, store=…)` 原样透传 langgraph（`:1671-1672`）；本包不实现任何存储。
- **缓存**：`create_agent(cache=…)`（langgraph `BaseCache` 图执行缓存，`:1677`）；`_get_schema_type_hints`/`_get_chat_model_creator` 的 `functools.lru_cache` 是仅有的进程内缓存。无 HTTP 缓存中间件。
- **限流**：`rate_limiters` 门面转发 core 的 `InMemoryRateLimiter`，经 chat model 的 `rate_limiter` 参数生效；agent 层的"限流"由 `ModelCallLimit/ToolCallLimit` 两个中间件承担（限次数而非速率）。
- **定时任务**：**不存在**（库语义下无后台线程；shell 读线程是 I/O 守护线程而非定时器）。

---

## 9. 外部依赖说明

| 依赖名 | 版本约束 | 用途 | 主要使用文件 | 缺失时的替代/关键实现 |
|---|---|---|---|---|
| langchain-core | ≥1.4.0,<2.0 | 消息/模型/工具基础抽象、`trim_messages`、`count_tokens_approximately`、限流器 | types.py、factory.py、structured_output.py、全部中间件 | 无替代（本包地基）；本标签内版本即 libs/core 1.4.0 |
| langgraph | ≥1.2.0,<1.3.0 | 图引擎、ToolNode、interrupt、Command/Send、checkpointer、Runtime | factory.py、types.py、tools/、human_in_the_loop.py、todo.py、shell_tool.py | 无替代；关键行为（路由/Send/interrupt）依赖其语义 |
| langsmith | （未锁版本） | `traceable` 钩子追踪 | factory.py | 移除则失去中间件级追踪（代码已隔离在包装处） |
| pydantic | ≥2.7.4,<3 | schema 校验、`TypeAdapter`、BaseModel | structured_output.py、todo.py、shell_tool.py（`_ShellToolInput`） | 无替代；`with_structured_output` 生态强依赖 |
| typing_extensions | — | TypedDict/TypeVar(default)/NotRequired/Unpack/Self | types.py、factory.py | 标准库 backport |
| langchain-model-profiles | （经 core 间接） | 模型能力档案（structured_output/max_input_tokens 判定） | 经 `BaseChatModel.profile`（core） | 无档案时回退 `FALLBACK_MODELS_WITH_STRUCTURED_OUTPUT` 硬编码名单（factory.py:150-160） |
| partner 包（langchain-openai 等） | 各 extras | 具体模型实现 | chat_models/base.py、embeddings/base.py（延迟导入） | 按需安装；未列注册表的 provider 需显式 `model_provider` |
| stdlib：subprocess/resource/shutil | — | shell 执行策略 | _execution.py、shell_tool.py | 平台差异：Windows 无 resource → rlimit 抛 RuntimeError |
| stdlib：re/ipaddress/hashlib/urllib | — | PII 检测/脱敏 | _redaction.py | 零第三方依赖；可外接 Presidio（normalizing wrapper） |
| stdlib：random | — | 重试 jitter | _retry.py | 非加密随机（已 noqa S311） |

---

## 10. 新人上手路径

### 10.1 建议阅读顺序（由浅入深）

1. `langchain/__init__.py` + `agents/__init__.py`（9 行）——知道入口只有 `create_agent`/`AgentState`。
2. `agents/middleware/types.py` 的三段：`AgentState`（`:350-355`）→ `ModelRequest/override`（`:88-268`）→ `AgentMiddleware` 钩子签名（`:380-798`）——理解编程模型。
3. `agents/structured_output.py`——四种 schema 如何统一、三种策略差异。
4. `agents/factory.py` 的 `create_agent` 主流程（`:849-1679`），配合第 7 章装配链读。
5. 两个简单中间件找感觉：`model_fallback.py`（138 行）→ `model_retry.py`（313 行，含共享 `_retry.py`）。
6. 按兴趣深入：`human_in_the_loop.py`（中断）、`summarization.py`（状态改写）、`shell_tool.py`+`_execution.py`（进程管理，本包最复杂文件）。
7. `chat_models/base.py` 的注册表 + `_ConfigurableModel`（独立于 agent 体系，可单独理解）。

### 10.2 常见修改需求的切入点

| 需求 | 入口 |
|---|---|
| **写一个自定义中间件** | 继承 `AgentMiddleware`（`middleware/types.py:380`），选钩子实现；参考 `model_fallback.py`（wrap 型）或 `model_call_limit.py`（before/after 型 + state 扩展 + jump_to）。需要新 state 字段时：定义继承 `AgentState` 的 TypedDict + `Annotated[..., PrivateStateAttr]`，挂到 `state_schema`（合并语义见 `factory.py:1038-1046`——用户 state_schema 永远最后、可覆盖你） |
| **加一个新的模型 provider** | `chat_models/base.py:38` `_BUILTIN_PROVIDERS` 加一行（模块路径、类名、creator），并按 `:207-209` 注释同步 docstring 列表；模型实现本身在 partners/ 下建包 |
| **改 agent 循环路由规则** | `factory.py:1718-1832` 三个 `_make_*_edge` 路由工厂（六步决策顺序即优先级） |
| **改结构化输出行为** | 策略选择：`factory.py:510-552`（provider 判定）与 `:1219-1234`；解析/重试：`_handle_model_output`（`:1058-1160`） |
| **加"定时任务"类后台行为** | 本包语义下不存在——应在应用层调度后 `graph.invoke`，或写成 `before_agent` 钩子 |
| **临时换模型调试** | 不改代码：`init_chat_model(configurable_fields=…)` + invoke 时 `config["configurable"]` |

### 10.3 隐性约定与易踩坑点

1. **顺序语义**：中间件列表第一个 = 洋葱最外层、before 钩子最先、after 钩子**最后**（`factory.py:1580-1661`）——与直觉的"先进先出"对称模型一致，但 after 逆序连边容易看错。
2. **改请求必须 `override()`**：`ModelRequest` 直接赋值已废弃（`types.py:168-200`）；`override` 返回新副本，重试时旧 request 不受污染。
3. **AIMessage/ToolMessage 必须配对**：每个 tool_call 都要有应答 ToolMessage，否则模型 API 报错——HITL reject/respond、结构化输出回执、限流拦截都靠"人工 ToolMessage 应答"来跳过真实执行（`human_in_the_loop.py:387-388` 注释即此模式）。
4. **结构化输出工具必须前置声明**：middleware 不能在运行期新增未声明的结构化工具（`factory.py:1263-1270` 抛 ValueError）；同理 `wrap_model_call` 里塞入未注册的普通工具会在无 `wrap_tool_call` 时报 `DYNAMIC_TOOL_ERROR_TEMPLATE`（`:111-135`）。
5. **sync/async 成对**：只实现 `awrap_model_call` 而用 `invoke()` 调用会得到指导性 `NotImplementedError`（`types.py:561-571`）；内置中间件的 async 版多为"委托同步"或 `run_in_executor`，阻塞钩子会拖慢事件循环。
6. **state 合并顺序**：中间件 schema 在前、用户 `state_schema` 在后（后胜出）——想强制覆盖中间件注解（如换 reducer）时用显式 state_schema，别去改中间件。
7. **`jump_to` 是一次性的**（EphemeralValue）：写完必须让它被下一个路由消费，同一超步内多次写只有最后一次生效；且必须用 `@hook_config(can_jump_to=[...])` 声明目的地，否则 factory 不会为该节点建条件边（`factory.py:475-507,1835-1880`）。
8. **`recursion_limit=9999`**（`factory.py:1665`）：agent 死循环（模型反复调工具）不会被引擎兜底拦截，务必配 `ModelCallLimit/ToolCallLimit` 中间件。
9. **`UntrackedValue` vs 普通字段**：run 级计数/shell 句柄若误用普通通道，会被写入 checkpoint（Popen 直接序列化崩溃；计数跨 run 不清零）。
10. **门面即契约**：新增公开符号记得同步 `__init__.__all__` 与 `agents/middleware/__init__.py`，CI 有 `check_imports`（每个文件可导入）但无导出完整性检查。
11. **`model.profile` 是 beta**（core `chat_models.py:364-369`）：profile 缺失时结构化输出判定回退硬编码名单（`factory.py:150-160`）——新模型可能需要等 partner 更新档案。
12. **Windows 差异**：`HostExecutionPolicy` 的 rlimit 在 Windows 构造即抛 `RuntimeError`（`_execution.py:124-129`）；`killpg` 缺失退化为 `process.kill()`（`shell_tool.py:401-410`）。

---

## 11. 收尾：总目录、完成度自检、存疑清单

### 11.1 全报告总目录（章节 ↔ 批次对照）

| 章节 | 标题 | 所在批次 |
|---|---|---|
| 0 | 阅读说明与批次计划 / 术语表 | 批 1 |
| 1 | 项目概述 | 批 1 |
| 2 | 整体架构 | 批 1 |
| 3 | 目录结构详解 | 批 1 |
| 4.1 | 模块：包根与门面/重导出层 | 批 5 |
| 4.2 | 模块：agents 核心（factory/structured_output） | 批 2 |
| 4.3 | 模块：middleware 类型系统（types.py） | 批 3 |
| 4.4 | 模块：middleware 内置实现（18 文件） | 批 4 |
| 4.5 | 模块：chat_models | 批 5 |
| 4.6 | 模块：embeddings | 批 5 |
| 4.7 | 模块：messages/rate_limiters/tools | 批 5 |
| 5 | 文件清单总表（31 文件） | 批 5 |
| 6 | 关键函数深度解析（8 个函数） | 批 2/4/6 |
| 7 | 端到端调用链分析 | 批 6 |
| 8 | 横切机制说明 | 批 6 |
| 9 | 外部依赖说明 | 批 6 |
| 10 | 新人上手路径 | 批 6 |

### 11.2 完成度自检表

| 检查项 | 结果 |
|---|---|
| 生产源文件覆盖 | **31/31**（第 5 章总表逐一列出；§4 逐文件说明） |
| 入口文件 | ✅ `agents/__init__.py`、`chat_models/__init__.py` 等 8 个门面 + `create_agent`/`init_chat_model` 两个功能入口 |
| 配置承载文件 | ✅ `pyproject.toml`（依赖/extras/uv sources/lint）、provider 注册表两个 |
| 数据模型/类型定义 | ✅ `types.py`（AgentState/ModelRequest/…）、`structured_output.py`（schema 体系） |
| 构建脚本影响行为部分 | ✅ `[tool.uv.sources]` 本地路径联调（§1.3）；`Makefile`（§1.3） |
| 排除项未纳入 | ✅ tests/、scripts/（CI 辅助）、.github/ 等；兄弟包仅仓库级说明（§0.1 声明理由） |
| 未覆盖文件 | 无遗漏；说明：`libs/langchain_v1/scripts/check_imports.py` 为 CI 导入冒烟脚本（已读、不承载运行逻辑，故仅在此提及）；`extended_testing_deps.txt` 为测试依赖清单 |
| 交叉验证 | ✅ 装配期链（§7.2）与运行期链（§7.3）沿代码走查；钩子顺序、路由六步、Send 扇出、中断-恢复均与源码行号对照 |

### 11.3 存疑与待确认清单（推断项汇总）

| # | 位置 | 疑点 | 性质 |
|---|---|---|---|
| 1 | `_redaction.py:98-125` | `detect_ip` docstring 称支持 IPv6，实现仅 IPv4 正则 | **事实性出入**（docstring 与实现不符，推断为文档滞后） |
| 2 | `file_search.py:148-150 vs 173-174` | `glob_search` docstring 称"按修改时间排序"，实现收集了 mtime 但最终按 glob 匹配顺序返回 | **事实性出入**（推断为未完成的排序或文档先行） |
| 3 | `file_search.py:259-310` | ripgrep 分支不做 `max_file_size` 过滤，仅 Python 回退分支有 | 推断为有意取舍（rg 自身性能可控），但未在注释说明 |
| 4 | `tool_selection.py:81-90` | `_render_tool_list` 已定义未被本文件调用 | 推断为遗留/供外部复用 |
| 5 | `factory.py:150-160` | `FALLBACK_MODELS_WITH_STRUCTURED_OUTPUT` 硬编码 7 个模型前缀 | 事实；推断为 model-profiles 数据未覆盖全部厂商前的过渡兜底 |
| 6 | `factory.py:202-213` | wrap_model_call 产生的 Command 不支持 `goto/resume/graph` | 事实（NotImplementedError 明示）；设计意图为"先保守开放 update" |
| 7 | `factory.py:1754-1757` 注释 | Send 不再内联全量 state（提 O(N²) 修复） | 事实（注释自述）；具体性能背景需查 langgraph#7313 关联议题 |
| 8 | `types.py:145-146` | `ModelRequest.__init__` 里 `warnings.simplefilter("ignore", DeprecationWarning")` | 推断：屏蔽 dataclass `replace` 链路上的废弃告警噪音，非功能性 |
| 9 | `summarization.py:144,382` | 依赖私有 API `model._llm_type` / `_get_ls_params()` | 事实；推断为 partner 包稳定提供这些内部钩子的团队约定 |
| 10 | `todo.py:127-137` | 模块级独立 `@tool write_todos`（用 InjectedToolCallId）与中间件内 `_write_todos`（用 ToolRuntime）功能重复 | 推断：前者供不使用中间件的用户直接拿工具，后者走 runtime 注入 |
| 11 | `factory.py:1512` | `tool.return_direct` 只统计 ToolNode 内客户端工具（provider 原生工具无此属性） | 事实；provider 原生工具的 return_direct 语义由厂商侧决定，推断为有意如此 |
| 12 | 仓库结构 | `libs/langchain` 包目录叫 `langchain_v1` 但 PyPI 名就是 `langchain`；`libs/langchain` 反而发 `langchain-classic` | 事实（目录名是历史迁移痕迹，构建配置以 pyproject name 为准） |

---

*报告完。所有行号引用基于 `langchain-langchain-1.3.0` 标签快照源码核对；标注"推断"的条目请以官方文档/后续版本为准。*
