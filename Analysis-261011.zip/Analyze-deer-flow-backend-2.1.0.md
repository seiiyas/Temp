# DeerFlow Backend 2.1.0 生产项目代码分析报告

> **分析对象**：`deer-flow-backend-2.1.0`（DeerFlow 后端，版本 2.1.0，`pyproject.toml:3`）
> **排除范围**：`packages/harness/`（任务指定排除）、`tests/`、`docs/`、`extension_test_fixtures/`、`samples/`、`.vscode/`、锁文件与构建产物
> **报告生成日期**：2026-10-07
> **证据约定**：所有结论均基于实际代码，引用格式为 `文件路径:行号`；无法从代码确证的意图标注「推断」。

---

## 术语表（项目特有概念，首次阅读必读）

| 术语 | 解释 |
|------|------|
| **DeerFlow** | 本项目：基于 LangGraph 的 AI 超级智能体（super agent）后端，具备沙箱执行、持久记忆、可扩展工具集成能力（`README.md:5`） |
| **Lead Agent** | 唯一的 LangGraph 主智能体图（graph id 为 `lead_agent`），由 `make_lead_agent(config)` 工厂构造（`langgraph.json:9`）；实现位于排除范围 `packages/harness` 的 `deerflow.agents` |
| **Gateway（网关）** | `app/gateway/` 下的 FastAPI 应用（`app.gateway.app:app`，端口 8001），承载全部 REST API、认证、渠道编排与后台服务 |
| **Channel（渠道）** | IM 平台适配器（Slack/Telegram/飞书/钉钉/企微/微信/Discord/GitHub/Buzz），把外部消息统一为 `InboundMessage` 投入消息总线（`app/channels/base.py:45`） |
| **MessageBus（消息总线）** | 渠道层与分发器之间的异步 pub/sub 枢纽，含界入站队列 + 出站监听器广播（`app/channels/message_bus.py:174`） |
| **ChannelManager（渠道管理器/分发器）** | 消费入站队列、创建/复用 LangGraph thread、经 langgraph-sdk 触发 agent run、把结果回发渠道的核心引擎（`app/channels/manager.py:1182`） |
| **Run（运行）** | 一次 agent 执行，由 `RunManager` 持久化跟踪（durable 行 + checkpointer），HTTP 与内部调用共用 `services.start_run` 准入（`app/gateway/services.py:1459`） |
| **Thread（线程）** | 一次会话容器，对应 LangGraph thread；`threads_meta` 表记录归属，`ThreadStore` 管理生命周期 |
| **StreamBridge（流桥）** | run 事件的多订阅者分发枢纽，SSE 端点与 run 执行体之间通过它解耦（可 Redis 后端跨进程） |
| **SSE** | Server-Sent Events，`/runs/stream` 等端点的流式返回协议，帧格式与 LangGraph Platform 兼容（`format_sse`，`app/gateway/services.py:156`） |
| **Checkpointer** | LangGraph 状态持久化组件（对话 checkpoint），配置指向 `packages/harness/deerflow/runtime/checkpointer/async_provider.py:make_checkpointer`（`langgraph.json:17-19`，排除范围内） |
| **Sandbox（沙箱）** | 每线程隔离执行环境，虚拟路径 `/mnt/user-data/{workspace,uploads,outputs}` 映射到线程物理目录；实现位于 harness（排除范围），网关侧只有路径解析（`app/gateway/path_utils.py`） |
| **PAT** | Personal Access Token，`dfp_` 前缀的 API 令牌，库中仅存 SHA-256 摘要（`app/gateway/auth/pat.py:22,165`） |
| **租约（lease）** | 数据库层的"抢占-过期-回收"机制，scheduler / mcp_tasks / subagent_batches 用它实现多实例防重 |
| **DEER_FLOW_HOME** | 数据根目录环境变量（默认 `.deer-flow/`），所有 JSON 状态、用户库、上传文件都在其下 |
| **harness** | `packages/harness/` 工作区包（`deerflow-harness`），承载 agent 运行时、中间件链、工具、持久化引擎——**本报告的排除范围**，仅作为依赖引用 |
| **extension-api** | `packages/extension-api/`（`deerflow-extension-api`），面向第三方扩展的零依赖公共契约包 |
| **Buzz** | 基于 Nostr 协议的自研 IM 渠道（kind-9 聊天事件 + kind-40003 原地编辑流式） |
| **Idempotency-Key** | run 创建幂等头，服务端哈希为 `http-run:{sha256}` 前缀的持久幂等键（`app/gateway/routers/thread_runs.py:90-103`） |

---

## 分批输出策略（批次计划）

纳入范围生产源文件约 **150+ 个**（app 包 121 个 Python 文件 + extension-api 12 个 + 根配置/脚本 9 个 + benchmark 目录），远超单批 40 个文件阈值，且模块数 > 6，按规则启用分批。本报告以文件为最终交付物，各批内容在单次生成会话内依次完成并合并写入本文件，批次状态如下（全部已完成）：

| 批次 | 覆盖模块/目录 | 覆盖章节 | 涉及文件数 | 状态 |
|------|--------------|----------|-----------|------|
| 1 | 全局总览 | 第 1~3 章 + 第 5 章（清单层）+ 本计划 | 全部（清单层） | 已完成 |
| 2 | 基础层：`packages/extension-api`、`app/gateway` 基础设施（config/utils/path/csrf/trace/health 等 14 个小文件） | 第 4 章（模块 4.1、4.2） | ~26 | 已完成 |
| 3 | 认证授权与 GitHub 集成：`app/gateway/auth/**`、`app/gateway/github/**`、`authz.py`、`auth_middleware.py`、`langgraph_auth.py` | 第 4 章（模块 4.3、4.4） | ~30 | 已完成 |
| 4 | 渠道集成层：`app/channels/**` | 第 4 章（模块 4.5） | 26 | 已完成 |
| 5 | 服务与路由层：`app/gateway/{services,deps,app,langgraph_studio}.py`、`app/gateway/routers/**`、`app/{mcp_tasks,scheduler,subagent_batches}` | 第 4 章（模块 4.6~4.10） | ~70 | 已完成 |
| 6 | 运维脚本与根文件：`scripts/**`、`debug.py`、`sitecustomize.py`、`Dockerfile` | 第 4 章（模块 4.11） | ~50（benchmark 以目录为粒度） | 已完成 |
| 7 | 深度收尾 | 第 6~10 章 + 总目录 + 完成度自检 + 存疑清单 | 引用前批 | 已完成 |

批次顺序遵循依赖方向：公共契约 → 基础设施 → 认证 → 渠道 → 服务/路由 → 运维脚本 → 横切深度分析。章节编号全局连续，跨批不复用。

---

# 第 1 章 项目概述

## 1.1 项目用途与业务背景

DeerFlow 是一个**LangGraph 深度研究/超级智能体系统的后端服务**（`pyproject.toml:4`："LangGraph-based AI agent system with sandbox execution capabilities"）。其业务能力（从路由与代码归纳）：

1. **智能体会话服务**：前端（Next.js，独立仓库）通过 Gateway 的 REST/SSE API 创建 thread、发起 run、流式接收 agent 输出（`app/gateway/routers/thread_runs.py`）。
2. **多 IM 渠道接入**：把 Slack、Telegram、飞书、钉钉、企业微信、微信、Discord、GitHub Webhook、Buzz(Nostr) 九类外部消息源统一接入同一 agent 运行时（`app/channels/service.py:27` 注册表），支持渠道内绑定 DeerFlow 账号（`/connect <code>` 流程）。
3. **资源管理**：模型配置、MCP 服务器、技能（Skills）、自定义 Agent、记忆（Memory）、文件上传、工件（Artifacts）、项目（Projects）与项目文档、回收站等配套 CRUD（`app/gateway/routers/` 32 个路由文件）。
4. **后台任务体系**：定时任务调度（cron/interval/once）、MCP 长任务轮询、子代理批量执行（`app/scheduler`、`app/mcp_tasks`、`app/subagent_batches`）。
5. **多用户与安全**：本地账号密码 + OIDC/SSO + PAT + 会话 Cookie 的完整认证，RBAC 权限，按用户隔离的数据桶（`app/gateway/auth/`、`authz.py`）。
6. **可扩展性**：第三方扩展通过 `deerflow-extension-api` 公共契约包注入中间件、路由、生命周期观察者（`packages/extension-api/deerflow_extension_api/contracts.py`）。

整体形态是**前后端分离架构中的后端单体**：一个 FastAPI 进程内嵌 agent 运行时（也可经 `langgraph.json` 以 LangGraph Server/Studio 模式运行同一套图）。

## 1.2 技术栈清单

| 类别 | 技术 | 证据 |
|------|------|------|
| 语言 | Python ≥ 3.12（`.python-version` 指定 3.12） | `pyproject.toml:6`、`langgraph.json:3` |
| Web 框架 | FastAPI ≥0.115 + Starlette ≥1.3.1,<2（私有 API `get_route_path` 被显式依赖并注释安全语义）+ uvicorn ≥0.34 | `pyproject.toml:16,29-30` |
| Agent 框架 | LangGraph（经工作区包 `deerflow-harness` 引入），SDK：`langgraph-sdk>=0.1.51`（渠道管理器用它回打自身 API） | `pyproject.toml:34` |
| 包管理 | **uv**（workspace 模式：members = `packages/harness`, `packages/extension-api`；`uv.lock` 锁定） | `pyproject.toml:108-113`、`Makefile:6` |
| 数据校验 | Pydantic（BaseModel / ConfigDict，贯穿全项目） | 各模型文件 |
| 数据库 | SQLAlchemy 异步引擎 + Alembic（迁移随启动自动执行，`bootstrap_schema`）；SQLite（默认）/ Postgres 可选 | `Makefile:63-69` 注释、`app/gateway/health.py` |
| 流式 | sse-starlette ≥2.1 + 自研 SSE 帧格式化（`format_sse`） | `pyproject.toml:19` |
| HTTP 客户端 | httpx ≥0.28（OIDC、GitHub API、渠道管理器） | `pyproject.toml:17` |
| 渠道 SDK | slack-sdk、python-telegram-bot ≥21、lark-oapi（飞书）、dingtalk-stream、wecom-aibot-python-sdk、discord.py（可选 extra）、markdown-to-mrkdwn | `pyproject.toml:31-37,47` |
| 加密/认证 | PyJWT ≥2.13（HS256 会话 JWT）、bcrypt ≥4（密码哈希 v2 = bcrypt(sha256 预哈希)）、e2b-code-interpreter ≥2.8（沙箱可选） | `pyproject.toml:38-41` |
| 可选 extras | postgres / redis（StreamBridge）/ discord / buzz（coincurve Nostr 签名）/ monocle（追踪）/ ollama / browser / memory-zh | `pyproject.toml:44-52` |
| 代码质量 | ruff（lint+format）、pytest + pytest-asyncio + hypothesis + blockbuster（阻塞 IO 检测） | `pyproject.toml:59-78` |

**项目类型与构建方式**：Python 库+应用混合工程；无独立构建步骤（解释型部署），生产交付经三阶段 Dockerfile（builder/dev/runtime）；本地开发 `make dev`（uvicorn `--reload`）。

## 1.3 如何运行

| 场景 | 命令 / 入口 | 说明 |
|------|------------|------|
| 本地开发 | `make dev` → `uvicorn app.gateway.app:app --host 0.0.0.0 --port 8001 --reload` | `Makefile:8-17`；需 `PYTHONPATH=.`、`DEER_FLOW_HOME` |
| 生产网关 | `make gateway` 或 Docker CMD `PYTHONPATH=. uv run --no-sync uvicorn app.gateway.app:app --host 0.0.0.0 --port 8001` | `Makefile:19-20`、`Dockerfile:127` |
| LangGraph Studio / Server 模式 | `langgraph.json` 声明：graph=`deerflow.agents:make_lead_agent`、auth=`app/gateway/langgraph_auth.py:auth`、http.app=`app/gateway/langgraph_studio.py:langgraph_app`、checkpointer=harness 的 `make_checkpointer` | `langgraph.json:8-19` |
| Docker | 三阶段构建（builder 编译+Node22+lark-cli → dev 保留工具链 → runtime 纯净镜像）；EXPOSE 8001 | `Dockerfile:11-127` |
| 测试 | `make test`（`-m "not live"`）；分片 `make test-shard SPLITS=4 GROUP=2` | `Makefile:22-45` |
| 迁移 | 启动时自动 `alembic upgrade head`；生成 revision 用 `make migrate-rev MSG=...` → `scripts/_autogen_revision.py` | `Makefile:63-72` |
| 调试 REPL | `PYTHONPATH=. uv run python debug.py` | `debug.py:10` |

**环境配置方式**：
- 进程绑定：环境变量 `GATEWAY_HOST/GATEWAY_PORT/GATEWAY_ENABLE_DOCS`（`app/gateway/config.py:22-24`）。
- 业务配置：`config.yaml`（DEER_FLOW_HOME 下），经 `deerflow.config.app_config.get_app_config()` 读取、mtime 热加载（排除范围 harness 实现；网关侧消费见 `app/gateway/deps.py:345`）；`startup-only:` 前缀字段绑定启动快照（`deps.py:359-368` 注释）。
- 扩展配置：`extensions_config.json`（MCP 服务器、技能启停），读写带进程锁+文件锁（`app/gateway/routers/mcp.py:1174-1236`）。
- `.env`：`langgraph.json:7` 指向 `../.env`，由 `dotenv` 加载（`app/gateway/auth/config.py` 的 `load_dotenv()`）。
- 关键安全环境变量：`AUTH_JWT_SECRET`、`DEER_FLOW_AUTH_DISABLED`（非 prod 才生效，`auth_disabled.py:35`）、`DEER_FLOW_INTERNAL_AUTH_TOKEN`、`GITHUB_WEBHOOK_SECRET`、`DEER_FLOW_ENV/ENVIRONMENT`、`GATEWAY_CORS_ORIGINS`、`GATEWAY_WORKERS`（>1 时强制 Postgres，`deps.py:58`）。

---

# 第 2 章 整体架构

## 2.1 架构风格与分层

DeerFlow 后端是**分层单体**：单一 FastAPI 进程内，从外到内分为「渠道/HTTP 接入层 → 中间件安全层 → 路由层 → 服务层 → agent 运行时（harness，排除范围）→ 持久化层」。横向以 `app/channels`（IM 接入）与 `app/gateway`（HTTP 接入+编排）双入口汇合到同一 run 服务层。

```
                         ┌────────────────────────────────────────────────────┐
   外部流量               │                    接入层                          │
┌───────────┐   HTTP     │  ┌──────────────────────────────────────────────┐  │
│ Next.js   │──────────▶ │  │ FastAPI app (app/gateway/app.py:1020)        │  │
│ 前端/API  │            │  │  Trace→CORS→CSRF→Auth 中间件链                │  │
│ 客户端    │            │  │  32 个路由模块 (app/gateway/routers/*)        │  │
└───────────┘            │  └──────────────────────────────────────────────┘  │
┌───────────┐  WS/轮询/  │  ┌──────────────────────────────────────────────┐  │
│ 9 类 IM   │  webhook   │  │ 渠道层 (app/channels/*)                       │  │
│ 平台      │──────────▶ │  │  Channel 适配器 → MessageBus(有界队列)         │  │
└───────────┘            │  │  → ChannelManager worker 池 → langgraph-sdk   │  │
                         │  │    （回打 Gateway 自身的 LangGraph 兼容 API）  │  │
                         │  └──────────────────────────────────────────────┘  │
                         │                      │                              │
                         │                      ▼  共同汇合点                  │
                         │  ┌──────────────────────────────────────────────┐  │
                         │  │ 服务层 (app/gateway/services.py: start_run /  │  │
                         │  │  sse_consumer; deps.py: langgraph_runtime)   │  │
                         │  │ 后台服务: scheduler / mcp_tasks /             │  │
                         │  │  subagent_batches (DB 租约队列)               │  │
                         │  └──────────────────────────────────────────────┘  │
                         │                      │                              │
                         │                      ▼                              │
                         │  ┌──────────────────────────────────────────────┐  │
                         │  │ agent 运行时: deerflow.* (packages/harness,   │  │
                         │  │  排除范围) — make_lead_agent / run_agent /    │  │
                         │  │  RunManager / StreamBridge / 中间件链 9 层     │  │
                         │  └──────────────────────────────────────────────┘  │
                         │                      │                              │
                         │                      ▼                              │
                         │  ┌──────────────────────────────────────────────┐  │
                         │  │ 持久化: SQLAlchemy 引擎(SQLite/Postgres)       │  │
                         │  │  users / threads_meta / runs / run_events /   │  │
                         │  │  scheduled_tasks / mcp_tasks / subagent_*     │  │
                         │  │  + LangGraph checkpointer + 文件系统(uploads/  │  │
                         │  │  outputs/skills/channels/*.json)              │  │
                         │  └──────────────────────────────────────────────┘  │
                         │        ▲ 扩展契约: packages/extension-api          │
                         │        （零依赖公共面，宿主与扩展共同依赖）          │
                         └────────────────────────────────────────────────────┘
```

要点：
- **双入口、单汇合**：HTTP 路由（`routers/thread_runs.py:941`）与渠道管理器（`manager.py:2523` 的 `runs.wait`/`2503` 的 `runs.create`，经 langgraph-sdk 以内部 token 回打本进程 HTTP）最终都进入同一 run 生命周期管理（RunManager + StreamBridge + checkpointer）。
- **进程内嵌运行时**：`services.py:1715` 直接调用 `deerflow.runtime.run_agent`，agent 执行与 HTTP 服务同进程（多 worker 部署时经 DB 租约/Redis 流桥协调）。
- **Studio 双形态**：同一图既可内嵌运行（Gateway 模式），也可由 `langgraph dev` 以 LangGraph Server 拉起（此时 `langgraph_auth.py`/`langgraph_studio.py` 生效，见 4.2.15/4.2.16）。

## 2.2 模块划分总览与依赖关系

```
packages/extension-api (4.1)      app/gateway 基础设施 (4.2)
  deerflow_extension_api            config/utils/path/csrf/trace/health/...
        ▲ 零依赖公共契约                  ▲
        │                              │
        └──────────┬───────────────────┤
                   │                    │
   app/gateway/auth (4.3.1) ──▶ auth_middleware/authz (4.3.4/4.3.5)
   app/gateway/auth/repositories        │
   app/gateway/github (4.4) ────────────┤
        │ github webhook 渠道化          ▼
        │                    app/gateway 核心服务 (4.6/4.7)
        │                      services.py / deps.py / run_models.py
        │                             ▲
        ▼                             │ start_run / sse_consumer
   app/channels (4.5) ──langgraph-sdk HTTP──▶ routers (4.8)
   MessageBus → ChannelManager ─────────────┤
                                             ▼
   app/scheduler (4.9) ──launch_scheduled_thread_run──▶ services
   app/mcp_tasks (4.10) ──launch_mcp_task_notification_run──▶ services
   app/subagent_batches (4.10.3, shim→harness)
```

依赖方向说明（箭头 = 依赖）：
- `extension-api` 不依赖任何项目内代码（零依赖契约，`packages/extension-api/pyproject.toml:8`）。
- `channels` 依赖 `gateway` 的 csrf/internal_auth/path_utils 等（`manager.py:38-44`），并经 HTTP（langgraph-sdk）而非函数调用触发 run。
- `scheduler`/`mcp_tasks` 直接调用 `services.py` 的内部启动函数（`app.py:403,499` 装配）。
- `routers` 是 `services`/`deps` 的薄 HTTP 壳（`services.py:1-6` 模块 docstring 明示）。
- 所有模块依赖 harness 的 `deerflow.*`（配置、路径、持久化、运行时）——排除范围，仅作为外部依赖描述。

## 2.3 核心数据流：一次典型请求的完整路径

以「前端发起一次流式对话」为例（详细函数级链路见第 7 章场景一）：

1. `POST /api/threads/{tid}/runs/stream` 进入中间件链：TraceMiddleware 绑定 trace id → CORS → CSRFMiddleware 双提交比对 → AuthMiddleware 解 JWT cookie 得 User 并预算权限（`app/gateway/app.py:771-840` 注册序）。
2. 路由 `stream_run`（`routers/thread_runs.py:941`）经 `@require_permission("runs","create",owner_check=True)` 属主校验后调用 `services.start_run`（`services.py:1459`）。
3. `start_run`：模型白名单 → 线程属主复核 → 输入归一化/服务端专属元数据剥离 → run config 构建（thread_id 注入、recursion_limit 钳制）→ 会话引用读取器装配 → 在 goal 线程锁内落 durable run 行（幂等）→ `asyncio.create_task(run_after_metadata)` 后台执行（`services.py:1488-1783`）。
4. HTTP 侧立即返回 `StreamingResponse(sse_consumer(...))`，订阅 StreamBridge 按 `format_sse` 格式逐事件推送；断线经 `Last-Event-ID` 续传（`services.py:1954-2046`）。
5. 后台 `run_after_metadata` → `deerflow.runtime.run_agent` 执行 LangGraph 图（9 层中间件 + 工具 + 子代理），事件同时进 StreamBridge（内存/Redis）与 run_event_store（持久化）。
6. 结束：`END_SENTINEL` → `event: end` 帧；按 `on_disconnect` 策略决定断连是否取消 run。
7. 读路径：`GET /threads/{tid}/messages` 从 run_event_store 扫描可见消息（隐藏被重生成/回放的 run，`conversation_reader.py:21`），前端渲染完整会话。


---

# 第 3 章 目录结构详解

以下树仅展示纳入范围部分；`packages/harness/`（任务排除）、`tests/`、`docs/`、`extension_test_fixtures/`、`samples/`、`.vscode/`、`node_modules` 等被省略。

```
deer-flow-backend-2.1.0/
├── app/                                # 主应用包（生产代码核心）
│   ├── __init__.py                     # 空包标记（PYTHONPATH=. 导入用）
│   ├── channels/                       # 【模块 4.5】IM 渠道集成层（25 py + AGENTS.md）
│   │   ├── base.py                     #   Channel 抽象基类（生命周期/背压/跨线程提交）
│   │   ├── message_bus.py              #   InboundMessage/OutboundMessage + 有界异步总线
│   │   ├── manager.py                  #   ChannelManager：分发器与 agent 触发引擎（2602 行）
│   │   ├── service.py                  #   ChannelService：渠道生命周期编排 + 注册表 + 单例
│   │   ├── store.py                    #   会话↔thread JSON 映射
│   │   ├── run_policy.py               #   每渠道运行策略注册表（策略模式）
│   │   ├── buzz_run_policy.py / feishu_run_policy.py  # 策略注册副作用模块
│   │   ├── commands.py                 #   /connect /new /status 等命令解析
│   │   ├── connection_identity.py      #   渠道连接身份附着
│   │   ├── dedupe_store.py             #   入站去重（内存/Postgres 双实现）
│   │   ├── runtime_config_store.py     #   UI 录入凭据的 JSON 持久化
│   │   ├── sandbox_files.py            #   附件同步进线程沙箱
│   │   ├── buzz*.py                    #   Buzz(Nostr) 渠道三件套（适配器/协议原语/seen 存储）
│   │   ├── slack.py discord.py telegram.py feishu.py dingtalk.py wecom.py wechat.py github.py
│   │   └── __init__.py                 #   重导出 Channel/MessageBus 等
│   ├── gateway/                        # 【模块 4.2/4.6/4.7/4.8】FastAPI 网关
│   │   ├── app.py                      #   ★ 应用工厂 + lifespan（889 行，入口）
│   │   ├── services.py                 #   ★ run 生命周期服务层（1885 行）
│   │   ├── deps.py                     #   ★ 依赖注入：langgraph_runtime + getter 族（763 行）
│   │   ├── authz.py                    #   RBAC 权限模型 + require_permission 装饰器（584 行）
│   │   ├── auth_middleware.py          #   fail-closed 认证安全网
│   │   ├── csrf_middleware.py          #   Double Submit Cookie CSRF
│   │   ├── trace_middleware.py         #   X-Trace-Id 注入
│   │   ├── config.py / utils.py / pagination.py / request_path.py / path_utils.py
│   │   ├── health.py                   #   /health/ready 就绪探针（双后端并发探测）
│   │   ├── internal_auth.py            #   进程内部可信调用 token
│   │   ├── auth_disabled.py            #   本地免认证模式
│   │   ├── run_models.py               #   LangGraph 兼容 run 请求模型（4 个校验器）
│   │   ├── artifact_archive.py         #   outputs ZIP 打包（fail-closed 防逃逸）
│   │   ├── checkpoint_lineage.py       #   checkpoint 祖先链回放基点定位
│   │   ├── conversation_access.py      #   read_conversation 工具授权闭包
│   │   ├── conversation_reader.py      #   可见消息分页扫描原语
│   │   ├── context_usage.py            #   线程 token 用量估算
│   │   ├── browser_capability.py       #   浏览器控制可用性判定
│   │   ├── skill_export.py             #   技能导出槽位与流式响应
│   │   ├── upload_ingestion.py         #   上传摄入管线（staging→唯一名→沙箱同步）
│   │   ├── langgraph_auth.py           #   LangGraph Server 模式认证处理器
│   │   ├── langgraph_studio.py         #   langgraph dev 的 http.app 壳 + 持久化修复
│   │   ├── auth/                       # 【模块 4.3.1】认证子系统（16 文件）
│   │   │   ├── config.py jwt.py password.py models.py providers.py
│   │   │   ├── local_provider.py       #   本地邮箱密码 provider
│   │   │   ├── oidc.py oidc_state.py   #   OIDC 核心服务 + state cookie
│   │   │   ├── pat.py                  #   PAT 生成/校验/路由白名单
│   │   │   ├── session_cookie.py session_cookie_state.py
│   │   │   ├── user_provisioning.py    #   OIDC 用户开通（防账户接管）
│   │   │   ├── credential_file.py reset_admin.py errors.py
│   │   │   └── repositories/           #   UserRepository 抽象 + SQLite 实现（3 文件）
│   │   ├── github/                     # 【模块 4.4】GitHub App 集成（8 文件）
│   │   │   ├── app_auth.py             #   App JWT(RS256) + installation token 缓存
│   │   │   ├── dispatcher.py           #   webhook 扇出到 N 个 agent
│   │   │   ├── registry.py             #   agent↔(repo,event) 索引（签名缓存）
│   │   │   ├── triggers.py             #   触发门控（action/作者/@提及）
│   │   │   ├── prompts.py identity.py run_policy.py
│   │   └── routers/                    # 【模块 4.8】REST 路由层（32 文件，~14000 行）
│   │       ├── threads.py              #   ★ 线程生命周期（1634 行）
│   │       ├── thread_runs.py          #   ★ run 执行/流式/取消/消息（1532 行）
│   │       ├── runs.py                 #   无线程 run 端点
│   │       ├── auth.py                 #   认证/PAT/OIDC 路由（911 行）
│   │       ├── mcp.py skills.py agents.py memory.py uploads.py artifacts.py
│   │       ├── scheduled_tasks.py projects.py project_documents.py trash.py
│   │       ├── channels.py channel_connections.py console.py browser.py
│   │       ├── github_webhooks.py subagents.py subagent_batches.py mcp_tasks.py
│   │       ├── models.py features.py feedback.py suggestions.py input_polish.py
│   │       ├── integrations.py user_preferences.py assistants_compat.py
│   │       └── project_thread_files.py __init__.py
│   ├── mcp_tasks/                      # 【模块 4.10.1】MCP 长任务服务（租约轮询）
│   ├── scheduler/                      # 【模块 4.10.2】定时任务调度器
│   └── subagent_batches/               # 【模块 4.10.3】子代理批量服务（shim→harness）
├── packages/
│   ├── extension-api/                  # 【模块 4.1】公共契约包 deerflow-extension-api
│   │   ├── pyproject.toml              #   零依赖、hatchling 构建
│   │   └── deerflow_extension_api/     #   contracts/assembly/placement/provenance/...（11 py）
│   └── harness/                        # ✗ 任务指定排除（deerflow 运行时）
├── scripts/                            # 【模块 4.11】运维/迁移/录制回放脚本
│   ├── migrate_agents_to_db.py migrate_memory_markdown.py migrate_user_isolation.py
│   ├── record_gateway.py run_replay_gateway.py build_fixture_from_jsonl.py
│   ├── e2e_safety_termination_demo.py manual_task_continuity_check.py
│   ├── _autogen_revision.py
│   └── benchmark/                      #   5 个基准测试子目录（checkpoint/concurrency/...）
├── langgraph.json                      # LangGraph Server 部署声明（graphs/auth/http/checkpointer）
├── pyproject.toml                      # uv workspace 根 + 依赖声明
├── Makefile                            # dev/gateway/test/lint/migrate 目标
├── Dockerfile                          # 三阶段构建（builder→dev→runtime）
├── debug.py                            # 断点调试 lead agent 的 REPL
├── sitecustomize.py                    # Windows asyncio 事件循环策略修正
├── uv.lock                             # ✗ 锁文件（不分析）
├── README.md / README_zh.md / AGENTS.md / CLAUDE.md / CONTRIBUTING.md  # 文档参考
└── ruff.toml / .python-version / .gitignore / .test_durations  # 工程配置（不深析）
```

各目录职责速览（`路径 → 职责 → 关键内容`）：

| 目录 | 职责 | 关键内容 |
|------|------|----------|
| `app/channels/` → IM 消息接入与回发 | 把 9 类外部消息源统一为 `InboundMessage`，管理会话↔线程映射，触发 agent run，回发结果 | `manager.py` 分发引擎、`base.py` 渠道抽象、9 个平台适配器、去重/策略/凭据存储 |
| `app/gateway/` → HTTP 服务与编排 | 应用装配、中间件安全链、run 生命周期、依赖注入、横切工具 | `app.py` 工厂、`services.py`、`deps.py`、`authz.py` |
| `app/gateway/auth/` → 认证子系统 | 本地账号/OIDC/PAT/会话 Cookie/JWT/密码哈希/用户仓储 | `oidc.py` 433 行核心、`pat.py` default-deny 路由白名单 |
| `app/gateway/github/` → GitHub App 集成 | webhook 验签后的 agent 扇出、令牌铸造、触发门控 | `dispatcher.py`、`app_auth.py`、`registry.py` |
| `app/gateway/routers/` → REST API 表面 | 32 个资源域的路由端点，全部经 `@require_permission` 授权 | `threads.py`/`thread_runs.py`/`mcp.py`/`skills.py` 等 |
| `app/scheduler/` → 定时调度 | cron/interval/once 到期扫描、排队、run 启动、完成回写、多实例租约恢复 | `service.py` 630 行状态机 |
| `app/mcp_tasks/` → MCP 长任务 | 提交-轮询-取消-完成通知全托管，租约轮询 + 死信 | `service.py` 676 行 |
| `app/subagent_batches/` → 子代理批处理 | app 层兼容 shim，真实实现在 harness | `service.py` 5 行 re-export |
| `packages/extension-api/` → 扩展契约 | 稳定公共 API：中间件摆放/溯源戳/装配指纹/运行证据只读面 | `contracts.py` 241 行核心 |
| `scripts/` → 运维工具 | 3 个迁移脚本、录制/回放网关、专项验证脚本、5 类基准 | 一次性升级工具为主 |

---

# 第 4 章 核心模块详解（报告主体）

> 本章按批次 2~6 的顺序覆盖全部模块。模块编号贯穿全报告：4.1 extension-api、4.2 网关基础设施、4.3 认证授权、4.4 GitHub 集成、4.5 渠道层、4.6 网关核心服务、4.7 依赖注入、4.8 路由层、4.9 调度器、4.10 MCP 任务与子代理批次、4.11 脚本与根文件。

## 4.1 模块：extension-api（`packages/extension-api/deerflow_extension_api/`）

### 4.1.1 模块职责

为第三方 DeerFlow 扩展提供**稳定的公共契约面**：扩展作者只依赖这个零依赖包即可向宿主贡献中间件、路由、生命周期观察者；宿主（harness/Gateway）通过同一契约注入能力。它存在的意义是把"扩展能看见什么"与"宿主如何实现"解耦——版本 0.2.1（`pyproject.toml:3` 与 `__init__.py:80` 双写），1.0 前 minor 可破坏、patch 只增不改（`__init__.py:78-79` 注释）。在整体架构中，它是扩展系统的地基：Gateway 的 `app.py:782-813` 用它的 `ExtensionPrincipal` 投影认证身份，harness 用它的 `MiddlewarePlacement` 摆放扩展中间件。

### 4.1.2 文件组成（12 文件）

| 文件 | 行数 | 职责 |
|------|------|------|
| `__init__.py` | 133 | 聚合导出 49 个符号（`__all__` :82-133），定义 `API_VERSION="0.2.1"`（:80） |
| `contracts.py` | 241 | 核心契约：HostPolicySnapshot/TaskInfo/观察者协议/ExtensionRegistry/`@extension` 装饰器 |
| `assembly.py` | 124 | AgentAssemblyDescriptor 装配事实 + `fingerprint` 规范哈希 |
| `placement.py` | 70 | 中间件摆放语义（5 个 Placement 枚举 + AgentScope） |
| `provenance.py` | 95 | 消息溯源戳（additional_kwargs 键 + 读写函数） |
| `release.py` | 102 | 行为参数声明 + `canonical_json/canonical_hash` |
| `run_evidence.py` | 93 | 运行证据只读分页契约（RunEvidenceReader 协议） |
| `state.py` | 57 | ExtensionData 类型键控存储（防扩展间键碰撞） |
| `runtime_bridge.py` | 25 | LangGraph runtime context 中取任务级 store 的桥 |
| `auth.py` | 53 | ExtensionPrincipal 身份投影 + fail-closed `require_admin` |
| `compaction.py` | 58 | 上下文压缩事件契约（哈希配方强约定） |
| `pyproject.toml` | 16 | 包定义：零依赖、hatchling、仅打包本包 |

### 4.1.3 关键类/函数解析

**`contracts.py` — 契约核心**
- `HostPolicySnapshot`（frozen dataclass，:31-46）：宿主限额的窄投影（token 预算开/输入/输出/总量/告警与硬限分数/每 run 子代理上限）。刻意不暴露宿主 AppConfig，避免扩展被宿主发布节奏绑死（:33-38）。
- `TaskLifecycleContributor`（Protocol，:71-87）：`on_task_start(app_store, task_store, info)` / `on_task_stop(..., outcome)`；`TaskOutcome` 为 `COMPLETED/ABORTED/FAILED` 三态（:52-55）。
- `SystemModelRequest/Result`（:100-131）：系统级模型调用（GOAL/MEMORY/TITLE/SUMMARIZATION 四类，`SystemOperationKind` :93-97）的不可变快照；`__post_init__`（:108-122）把 messages 归一为 tuple——防止调用方传 str 时观察者按字符迭代，同时真正不可变化。
- `ExtensionRegistry`（`@runtime_checkable` Protocol，:182-217）：写侧注册面，7 个注册方法（middlewares/task_lifecycle/system_model_observer/agent_assembly_observer/context_compaction_observer/service/routers）**全部带默认 `return None` 实现**——这是增量兼容策略的一部分（:3-7 模块头注释明示规则）。
- `extension` 装饰器（:227-241）：给 install 函数打 `__deerflow_api__`/`__deerflow_name__` 属性，版本偏斜时把深层 AttributeError 转成可操作的启动诊断。

**`assembly.py` — 装配指纹**
- `AgentAssemblyDescriptor`（frozen，:46-113）：一次 agent 装配的完整事实（namespace、requested/effective model、thinking、prompt hash、tools、middlewares、skills、build）。
- `fingerprint`（cached_property，:66-113）：用 `canonical_hash` 回答"这个 agent 的行为是否变化"。**刻意排除** `build`（宿主二进制变化，:76-80）与 `requested_model`（只有 effective_model 会到达 provider，:81-83）；tools/skills 排序（顺序无关）而 middlewares 不排序（栈序决定包裹关系，:71）。实现方式：字段规范化 → `canonical_json`（排序键+紧凑分隔符+ensure_ascii=False）→ sha256。
- `AgentAssemblyObserver`（:116-124）：同步调用、必须廉价、不得抛异常（构造期无事件循环）。

**`placement.py` — 摆放语义**：`Placement` 枚举（:20-41）以「轴+端点」而非结构位置声明：`MODEL_LOGICAL`（模型轴外端，逻辑决策一次）/`MODEL_PHYSICAL`（内端，物理调用、重试重入）/`TOOL_VISIBLE`（工具轴外端=模型所见）/`TOOL_RAW`（内端=工具原始返回）/`STANDARD`（无顺序保证）。这样宿主可自由重构中间件栈而不破坏扩展语义（:1-9 注释）。`MiddlewarePlacement`（frozen，:59-70）= middleware(Any) + placement + scope + order。

**`provenance.py` — 溯源戳**：三个 `additional_kwargs` 键常量（:24-26）与 `PROVENANCE_KEYS` frozenset（:30-36，宿主视为 server-owned 并从不可信输入剥离）；`ContentKind` 五类（:39-46）：中间件注入/记忆/持久上下文/技能正文/图像载荷；`read_provenance`（:76-95）把部分/畸形戳视为不存在。值为纯字符串而非枚举成员——新宿主的未知 producer 退化为陌生字符串而非 import 错误（:15-17）。

**`release.py` / `compaction.py` — 哈希纪律**：`canonical_json`（:38-45）不可序列化直接 TypeError 而非 repr（防不同结构哈希碰撞）；`collect_release_policies`（:73-102）按键（类名，重复得 `Name#2`）收集中间件行为参数，声明抛异常记为 `{"error": "<Type>"}` 而非丢弃——「无法自述」与「无可说」是两种事实。`compaction.py:14-28` 详细规定双侧哈希配方（绝不能先 `str()` 再哈希，多模态 dict 会因插入顺序产生不同哈希）。

**`state.py` — ExtensionData**（:10-57）：按 `type` 而非字符串键存取（扩展间零碰撞），`__slots__`+RLock，`get_or_init` 的 init 在锁内执行；宿主每 scope（app/task）建一个实例、scope 结束丢弃，扩展因此无需 stale-handle 检查（:11-17）。

**`run_evidence.py` — 只读证据面**：`RunEvidenceReader` 协议（:62-93）含 `list_changed_runs(cursor, limit)`（消费方应在自身输出持久化后才保存 next_cursor，删除不产生墓碑）、`list_run_events`（不可见 run 返回空页防身份探测）、`get_run_status`。

**`auth.py`**：`EXTENSION_PRINCIPAL_RESOLVER_KEY`（:18）宿主把 resolver 挂 `app.state`；`resolve_principal`（:29-41）鸭子类型读取，身份不可判定返回 None（不视为错误）；`require_admin`（:44-53）非 admin 或无法判定一律 `PermissionError`（fail-closed）。

### 4.1.4 模块对外接口

`__all__` 的 49 个符号即公共面（contracts/assembly/placement/provenance/release/run_evidence/state/runtime_bridge/auth/compaction 全部导出）。宿主侧消费点：`app/gateway/app.py:782-813`（principal resolver）、harness 的扩展加载器与中间件栈装配（排除范围）。设计约束：本包 **MUST NOT import deerflow**（`__init__.py:3-5`），宿主类型一律以 `Any` 传递。

---

## 4.2 模块：网关基础设施（`app/gateway/` 根部 14 个支撑文件 + 入口壳）

> 批次 2 覆盖。`app.py`/`services.py`/`deps.py`/`authz.py`/`auth_middleware.py` 等大文件分别在 4.6/4.7/4.3 详述；本节覆盖支撑性小文件与两个 LangGraph 模式壳。

### 4.2.1 `__init__.py`（13 行）
包入口，PEP 562 模块级 `__getattr__`（:6-12）懒加载 FastAPI `app`，避免 `import app.gateway` 即触发完整应用构造。`__all__` 声明 `app/create_app/GatewayConfig/get_gateway_config`（:3）。

### 4.2.2 `config.py`（26 行）— 进程绑定配置
`GatewayConfig(BaseModel)`（:6）：`host="0.0.0.0"`、`port=8001`、`enable_docs=True`（:9-11）；`get_gateway_config()`（:17）从 `GATEWAY_HOST/GATEWAY_PORT/GATEWAY_ENABLE_DOCS` 一次性加载并缓存模块级单例（:14-26）。
**注意**：这里只管 uvicorn 绑定；业务配置（models/tools/scheduler/memory/database/authorization 等）在 `config.yaml`，经 harness 的 `get_app_config()` 热加载，网关侧用 `deps.get_config()`（`deps.py:345`）按请求获取。

### 4.2.3 `utils.py`（6 行）
`sanitize_log_param(value)`（:4）剔除 `\n \r \x00`，防日志注入；被 `services.py:37`、`routers/threads.py:46`、`routers/thread_runs.py:55` 使用。

### 4.2.4 `pagination.py`（15 行）
`trim_run_message_page(rows, *, limit, after_seq)`（:6）：取 `limit+1` 行探测 has_more；`after_seq` 升序取头部，否则降序取尾部（:12-15）。被 `routers/runs.py:17`、`routers/thread_runs.py:52` 使用。

### 4.2.5 `request_path.py`（9 行）
`get_request_route_path(request)`（:7）转调 `starlette._utils.get_route_path`（:9）。**为什么用私有 API**：`pyproject.toml:20-28` 注释——auth/CSRF 的路径豁免判定必须与 Starlette 路由器匹配的字符串完全一致（含 root_path 部署），私有 import 在 Starlette 升级时 ImportError 大声失败优于静默漂移；因此 Starlette 版本 bump 是安全敏感变更。被 `auth_middleware.py:30`、`csrf_middleware.py:20` 使用。

### 4.2.6 `path_utils.py`（80 行）— 虚拟路径解析
- `OUTPUTS_VIRTUAL_ROOT`（:11）；`resolve_thread_virtual_path(thread_id, virtual_path, user_id=None) -> Path`（:16）：`/mnt/user-data/...` → 宿主真实路径（真实解析委托 harness 的 `get_paths().resolve_virtual_path`，用户取 `get_effective_user_id()`，:34）。
- `normalize_outputs_virtual_path`（:40）与 `resolve_outputs_confined_path`（:58）：**先 `posixpath.normpath` 折叠 `..` 再做前缀检查**（:52-55，防 `outputs/../uploads/x` 绕过），再双重校验 resolved 路径必须在 `sandbox_outputs_dir` 内以捕获符号链接（:77-79）；越界 403/400。
- 被 `routers/artifacts.py:22`、`routers/skills.py:14`、`channels/manager.py:44` 使用。这是「agent 沙箱视图 ↔ 宿主文件系统」的唯一翻译点。

### 4.2.7 `browser_capability.py`（72 行）
`BrowserCapability`（frozen dataclass，:13：configured/available/reason）；`browser_capability(config)`（:37）判定链：browser_navigate 工具是否配置（`_tool_config` :22）→ 多 worker 拒绝（:44-46）→ `cdp_url` 必须显式 `allow_unguarded_cdp`（SSRF 守卫覆盖不了 CDP，:50-55）→ Playwright 是否安装（`importlib.util.find_spec`，:57-62）。`ensure_browser_runtime_available`（:67）在 lifespan 中 fail-fast（`app.py:296` 调用，抛 RuntimeError 中止启动）。被 `routers/browser.py:11`、`routers/features.py:13` 使用。

### 4.2.8 `context_usage.py`（86 行）
`build_context_usage(request, thread_id, run_store)`（:62）：经 `build_thread_checkpoint_state_accessor` 读最新 checkpoint 的 messages（:70-71），用 `langchain_core.count_tokens_approximately` 离线估算并 `asyncio.to_thread` 下放（:77）；模型窗口取「该线程最近一次 run 的 model_name，否则第一个配置模型」（`_resolve_thread_model_name` :35-47）。全链路异常吞掉返回 None（不阻塞 thread 状态主响应）。被 `routers/thread_runs.py:40` 使用。

### 4.2.9 `internal_auth.py`（85 行）— 进程内部信任
- 常量：`INTERNAL_AUTH_HEADER_NAME="X-DeerFlow-Internal-Token"`、`INTERNAL_OWNER_USER_ID_HEADER_NAME`、`INTERNAL_AUTH_ENV_VAR`、`INTERNAL_SYSTEM_ROLE="internal"`（:13-16）。
- token 来源：环境变量或**导入时 `secrets.token_urlsafe(32)` 随机生成**（:19-26）——每 worker 独立，因此内部调用只能打同进程/同部署（渠道 worker、scheduler、mcp 通知都回打本进程）。比较用 `secrets.compare_digest`（:39）。
- `create_internal_auth_headers(*, owner_user_id=None)`（:29）；`get_internal_user(owner_user_id)`（:42）合成 `SimpleNamespace(id=…, system_role="internal")`；owner id 经 `make_safe_user_id` 规范化防 `../` 逃逸 per-user 存储（:53-67）。
- `get_trusted_internal_owner_user_id(request)`（:70）。被 `auth_middleware.py:29`、`services.py:30`、`channels/manager.py:43`、多个 router 使用。

### 4.2.10 `auth_disabled.py`（58 行）— 免认证模式
`is_auth_disabled()`（:34）= `DEER_FLOW_AUTH_DISABLED=1` **且**非 prod（`DEER_FLOW_ENV/ENVIRONMENT=prod|production` 判定 :20-27）——生产显式设置被静默忽略（fail-safe）。`get_auth_disabled_user()`（:49）合成 `id="default", system_role="admin"` 用户。被 auth_middleware/csrf/deps/langgraph_auth/routers/auth 等广泛使用。

### 4.2.11 `trace_middleware.py`（92 行）
纯 ASGI 中间件（非 BaseHTTPMiddleware）`TraceMiddleware`（:11）：读入站 `TRACE_ID_HEADER` 或生成新 id（:50-52）；在 `http.response.start` 注入 `X-Trace-Id` 头（覆盖 SSE 流而不消费 body，:55-60）；未处理异常在响应未开始时发送带 trace 头的裸 500 再 re-raise（:74-92）。刻意不读 AppConfig（ungated），`logging.enhance.enabled` 只控制是否打印（:15-20 注释）。注册于 `app.py:840`（最外层）。

### 4.2.12 `csrf_middleware.py`（287 行）— CSRF 防护
- 常量：`CSRF_COOKIE_NAME/CSRF_HEADER_NAME/CSRF_TOKEN_LENGTH`（:23-25）。
- `should_check_csrf`（:40）：状态变更方法（POST/PUT/DELETE/PATCH）且非 Bearer 请求才比对 cookie/header（`generate_csrf_token` :35；常量时间比较在 `dispatch` :230-252）。豁免：auth-disabled（:49）、`/api/v1/auth/me`（:27）、`/api/webhooks/*`（自带签名，:59）。
- **登录/注册端点改做同源或白名单 Origin 校验**（防 login CSRF，:224-228 + `is_allowed_auth_origin` :180-198）；`get_configured_cors_origins`（:125）解析 `GATEWAY_CORS_ORIGINS`；`_normalize_origin`（:93）拒绝带 userinfo/path/fragment 的值；scheme/host 从 `Forwarded`/`X-Forwarded-*` 解析（:149-177）。
- auth POST 成功后种 `csrf_token` cookie（httponly=False、samesite=strict、max_age 与 access_token 对齐防 PWA 双 cookie 漂移，:260-276）。
- 注册于 `app.py:816`；被 `routers/auth.py:38`、`channels/manager.py:38`、`auth/oidc_state.py:18`、`auth/session_cookie.py:16` 引用常量。

### 4.2.13 `health.py`（282 行）— 就绪探针
`readiness_payload(checkpointer_config=None)`（:240）→ `/health/ready`（`app.py:990-1006`）：并发探测 ORM 引擎与 LangGraph checkpointer/Store 后端，单一 3s 端点级 deadline（`asyncio.gather` 于 `asyncio.timeout(3.0)`，:266-274）。
- checkpointer 配置取 **startup 快照**（`deps.langgraph_runtime` 写入 `app.state`），不读热配置（`READINESS_CHECKPOINTER_CONFIG_ATTR` :60）。
- SQLite 以 `mode=rw` 非创建打开（`_sqlite_disk_uri` :139-159）——防探针复活被删的库；`_probe_sqlite_backend`（:162）/`_probe_postgres_backend`（:194）/`_probe_checkpointer_backend`（:218）；连接型探针经 per-loop WeakKeyDictionary 锁串行化，防公开端点打爆连接池（:68-78,232）；任一 unreachable → 503 degraded。

### 4.2.14 `run_models.py`（178 行）— run 请求模型
`RunCreateRequest(BaseModel)`（:29，`extra="forbid"` :32）：assistant_id/input/command/metadata/config/context/conversation_references/stream_mode/on_disconnect/multitask_strategy 等（:34-58）。四个校验器：
- `lift_context_conversation_references`（:61，before）：SDK 客户端只能把 references 塞进 `context`，服务端提升到顶层并检查冲突（:96）。
- `validate_configurable_thread_id`（:100）。
- `reject_unsupported_run_options`（:123）：webhook/on_completion/after_seconds/feedback_keys 只接受 None 占位；multitask_strategy 仅 reject/rollback/interrupt。
- `reject_resumable_streams`（:149）与 `reject_unsupported_stream_modes`（:163，经 `normalize_stream_modes` 白名单）。
`MAX_CONVERSATION_REFERENCES=3`（:16）与 `ConversationReference`（:21）。被 `services.py:36`、`routers/runs.py:18`、`routers/thread_runs.py:53`、`routers/features.py:16` 使用。

### 4.2.15 `langgraph_auth.py`（140 行）— LangGraph Server 模式认证
`langgraph.json:11-13` 的 `auth.path` 指向本模块 `auth = Auth()`（:26）。`authenticate`（:66，@auth.authenticate）与 Gateway 完全同链：先 CSRF 双提交（`_check_csrf` :37-63）→ cookie → `decode_token` → `get_local_provider().get_user` → token_version 校验（:81-107）；auth-disabled 直接返回合成用户 id（:78-79）。`add_owner_filter`（:110，@auth.on）：写侧强制 `metadata["user_id"]=ctx.user.identity`、assistants 写入 `created_by="user"`（防客户端伪造 system 溯源，:134-138）；读侧返回 `{"user_id": identity}` 过滤（:140）；Studio 专用 `StudioUser` 类型对 assistants 读放宽为 `$or` system/自身（:120-126）。使 LangGraph 原生 threads/assistants API 获得与 Gateway 相同的属主隔离。

### 4.2.16 `langgraph_studio.py`（185 行）— langgraph dev 壳与持久化修复
`langgraph.json:14-16` 的 `http.app` 指向 `langgraph_app = FastAPI(docs_url=None, ...)`（:181，禁文档的空壳，仅让 Studio 走 DeerFlow 的 auth/checkpointer 声明）。核心副作用：**模块导入时**（:179）执行 `repair_local_dev_persistence_before_runtime`（:133）——`langgraph dev` 的 runtime 0.30.0 会在用户 lifespan 之前清除持久化的 `created_by=system` assistants，故必须在导入期修复：读 `LANGSERVE_GRAPHS`（:140）推导注册 assistant 的 uuid5 ID（`configured_system_assistant_ids` :48，:63-68），从 `.langgraph_api/.langgraph_ops.pckl`（PersistentDict）中删除这些行让 graph 注册重建、其余 legacy system 标记降级为 `created_by="user"`（含版本历史，`repair_persisted_assistant_provenance` :83，:96-130），变更才 `store.sync()`（:157-158）。门条件：`LANGSMITH_LANGGRAPH_API_VARIANT=local_dev` 且 `MIGRATIONS_PATH` 含 `__inmem`（:163-166）。`ProvenanceRepair`（:27，frozen）为修复摘要。**只在 langgraph 工具链加载时生效，嵌入式 Gateway 不加载**。

### 4.2.17 其余支撑文件速览

| 文件 | 行数 | 导出 | 职责与实现要点 | 被谁使用 |
|------|------|------|----------------|----------|
| `artifact_archive.py` | 270 | `build_artifact_archive(outputs_dir, virtual_paths, ...)` (:207) | run outputs 打 ZIP。限额：50 文件/50MiB 单文件/100MiB 总量/60s 超时（:24-28）。全同步（线程池调用）；每成员 `_member`(:72) 词法校验（必须 `mnt/user-data/outputs/` 前缀、无 `..` 段、拒绝 Windows 设备名/控制字符/`.artifact-edit-` 临时文件）+ 逐级 `os.lstat` 记录 (dev,inode) 防符号链接替换；`_copy_member`(:145) 用 `O_NOFOLLOW` 打开、写前后比对 inode/size/mtime 并整文件重读 SHA256 比对（:186-194）；ZIP_STORED、TemporaryFile+fchmod 0600；NFC casefold 去重防条目碰撞 | `routers/thread_runs.py:29` |
| `checkpoint_lineage.py` | 183 | `find_checkpoint_before_message` (:104)、`find_checkpoint_before_message_chronologically` (:160) | 在 checkpoint 祖先链上定位「消息之前的回放基点」（编辑/重生成场景）。沿 `parent_config` 单链上溯（区分 regenerate 兄弟分支 :111-117），环检测+身份一致性校验（:139-146）；跳过 duration-only checkpoint（:43,148-150）与仍有 pending tasks 的中逈权（:48-62,152-155）；旧数据无 parent 链时降级时间序扫描 | `routers/threads.py:29`、`routers/thread_runs.py:31` |
| `conversation_access.py` | 291 | `prepare_conversation_reader` (:138)、`conversation_references_enabled` (:117) | 把 run 请求显式声明的跨线程引用变成闭包读取器（capability-based 授权：无引用即无授权，闭包集合是唯一授权来源 :147-152）。引用只接受 thread id 或同源 URL（:46-57），**绝不网络取回**；需已认证+`runs:read`；owned_scan 属主检查且读取后复查防删除竞态（:174-190）；文本经 `_fit_text` 二分前缀适配 ToolOutputBudget（:105-114），输出 JSON `<` 转义防提示注入（:88） | `services.py:1607`、`routers/features.py:14` |
| `conversation_reader.py` | 191 | `read_visible_message_page` (:21)、`scan_visible_thread_messages` (:78)、`default_history_hidden_run_ids` (:58) | 与请求无关的「可见转录分页」原语（鉴权由调用方负责）。隐藏集合=被重生成取代的 run+编辑回放隐藏 run（:58-61）；隐藏规则：`caller` 以 `middleware:` 开头或 `subagent:`+ai 消息（:73-75）；批量拉原始行直至凑满 `limit+1` 可见行，`after_seq` 向上/`before_seq` 向下扫（:95-152）；游标不前进立即 RuntimeError 防死循环（:118-120,145-147） | `conversation_access.py:14`、`routers/thread_runs.py:41-47` |
| `skill_export.py` | 188 | `run_export_work` (:108)、`SkillExportResponse` (:141)、`ExportLease` (:64) | 技能导出的并发槽位（**进程级 2 个**跨所有用户，满则 429，:19,70-71）、文件 IO 线程化、流式响应与清理所有权；`SkillExportResponse.__call__` 用 idle-timeout-on-transport-progress 模式，超时抛 ClientDisconnect 而非在半截 ZIP 后补 JSON（:161-181）；竞速客户端断连（监听 `http.disconnect` :103-105） | `routers/skills.py:15` |
| `upload_ingestion.py` | 314 | `ThreadUploadIngestionService` (:76) | uploads 完整摄入管线：open（seed 现有文件名集合保并发唯一命名 :130-134）→ ingest_chunks（staged `.part` + `os.link` 原子无覆盖提交，碰撞换后缀重试 :152-170,208-213；非挂载 provider 先过 `sandbox:execute` 门再拿 SandboxRequestLease，denied 则跳过同步仍留宿主文件 :136-149）→ 可选转 Markdown（转换产物同样原子提交 :240-271）→ finalize（chmod 加组/其他读位，Docker root→UID1000 场景 :283-293）。低层函数经 `_uploads()`（:51-55）晚绑定自 `routers.uploads`，保住既有测试 monkeypatch（:19-27） | `routers/uploads.py:17`、`routers/project_documents.py:27` |

### 4.2.18 模块对外接口

网关基础设施对外提供：虚拟路径解析（path_utils）、CSRF/Trace 中间件、健康探针、内部信任 token、run 请求模型、就绪探测、LangGraph 模式双壳，以及 artifacts/lineage/conversation/skill/upload 五个领域支撑件。这些被 services、routers、channels 三方共用，是网关的「工具带」。


---

## 4.3 模块：认证授权（批次 3）

> 组成：`app/gateway/auth/`（16 文件）+ `auth/repositories/`（3 文件）+ 网关根部的 `authz.py`、`auth_middleware.py`（`langgraph_auth.py` 已在 4.2.15）。解决「谁在调用」与「能做什么」两个问题。

### 4.3.1 auth/ 子系统（认证）

**`config.py`（86 行）**：`AuthConfig(BaseModel)`（:14）：`jwt_secret`（必填）、`token_expiry_days=7`（1..30）、`oauth_github_client_id/secret`。`get_auth_config()`（:61）先 `load_dotenv()` 再读 `AUTH_JWT_SECRET`，未设置时 `_load_or_create_secret()`（:35）从 `{base_dir}/.jwt_secret` 读取或 `secrets.token_urlsafe(32)` 生成并以 `os.open(...,0o600)` 原子写入（:50-55）——密钥二级来源（env 优先→文件持久化）保证多 worker/重启后签名稳定。生产建议显式设置（自动生成是可用性优先降级）。

**`errors.py`（46 行）**：类型化错误体系。`AuthErrorCode`（StrEnum，:13）9 值：INVALID_CREDENTIALS/TOKEN_EXPIRED/TOKEN_INVALID/USER_NOT_FOUND/EMAIL_ALREADY_EXISTS/PROVIDER_NOT_FOUND/NOT_AUTHENTICATED/SYSTEM_ALREADY_INITIALIZED/REGISTRATION_DISABLED；`TokenError`（:27）三值：EXPIRED/INVALID_SIGNATURE/MALFORMED；`AuthErrorResponse`（:35）`{code,message}` 载荷；`token_error_to_code`（:42）唯一映射源。

**`jwt.py`（55 行）**：`TokenPayload`（:12）四声明 `sub/exp/iat/ver`（ver=token_version）；`create_access_token(user_id, expires_delta=None, token_version=0)`（:21）**HS256** 对称签名（:37）、默认 7 天；`decode_token`（:40）区分过期/签名无效/畸形三类 TokenError。**无角色声明**——角色每次从 DB 现查，避免 JWT 内权限过期；`ver` 与 `User.token_version` 比对实现改密后全量吊销（消费点 `deps.py:857-861`）。

**`password.py`（82 行）**：版本化哈希 `$dfv<N>$<bcrypt_hash>`（:3-9）。v2 = `bcrypt(base64(sha256(password)))`（`hash_password` :32；`_pre_hash_v2` :27）——SHA-256 预哈希解决 bcrypt 72 字节截断；`verify_password`（:38）自动识别 v2/v1/裸 bcrypt，畸形哈希 **fail-closed 返回 False**（:55-58）；`needs_rehash`（:61）非 v2 前缀即需升级；`hash_password_async/verify_password_async`（:66/:75）`asyncio.to_thread` 包装防阻塞事件循环。登录时机会式升级（见 local_provider）。注意：预哈希未加 HMAC pepper（无服务器密钥参与，已知权衡）。

**`models.py`（47 行）**：`User(BaseModel)`（:15，`from_attributes=True`）字段：`id: UUID`、`email: EmailStr`、`password_hash: str|None`（OAuth 用户可空）、`system_role: Literal["admin","user"]`、`created_at`、`oauth_provider/oauth_id`、`needs_setup: bool=False`、`token_version: int=0`；`UserResponse`（:35）API 响应模型（含 permissions）。

**`providers.py`（25 行）**：`AuthProvider(ABC)`（:6）两个抽象方法：`authenticate(credentials: dict) -> User|None`（:10）、`get_user(user_id) -> User|None`（:18）。扩展点：新 provider 实现此接口即可挂入。

**`local_provider.py`（133 行）**：`LocalAuthProvider(AuthProvider)`（:13）唯一实现，封装 UserRepository 并附加业务方法（create_user :65、create_oauth_user :106、get_user_by_oauth :86、count_users/admins :90/:94、update_user :98、get_user_by_email :102）。认证流程（`authenticate` :24-59）：取凭据 → `repo.get_user_by_email` → 用户不存在返回 None（:39-41）→ `password_hash is None`（纯 OAuth 用户）拒绝（:43-45）→ `verify_password_async`（:47）→ `needs_rehash` 则机会式升级哈希，**失败仅告警不阻断登录**（:50-57）。经 `deps.get_local_provider()`（`deps.py:779`）模块级单例化。

**`oidc.py`（433 行，认证子系统最大文件）**：provider 无关的 OIDC 核心服务 `OIDCService`（:71）。
- `discover(issuer)`（:96）：GET `/.well-known/openid-configuration`；**issuer pinning**——发现文档的 issuer 必须与配置一致（:121-126），防伪造文档重定向。
- `build_authorization_url(...)`（:144）：`response_type=code` + 可选 nonce + **PKCE S256**（:167-169）。
- `exchange_code(...)`（:175）：支持 `client_secret_basic`（Basic 头 :197-201）与 `client_secret_post`（:202-203）两种客户端认证。
- `validate_id_token(...)`（:273）：算法白名单 RS256/384/512 + ES256/384/512（:292-294，显式拒绝 HS256 防算法混淆）；kid 未命中强制刷新 JWKS 一次以容密钥轮换（:297-302）；decode 强制 `require: ["exp","iss","sub","aud"]`（:311-315）；nonce 常数时间比较（:327-332）。
- `fetch_userinfo(...)`（:338）：userinfo 的 `sub` 必须与 ID token sub 一致（:357-358，防 userinfo 注入）。
- `authenticate_callback(...)`（:364）：exchange → validate → userinfo（失败降级继续用 ID token claims，:412-413）→ 合并（userinfo 优先 :416）→ `OIDCIdentity`。
- 内部 httpx.AsyncClient 15s 超时（:88）；metadata/JWKS 各 300s 缓存（:79）。

**`oidc_state.py`（123 行）**：无服务器状态的 OIDC state 承载——HS256 签名 HttpOnly cookie。`OIDCStatePayload`（:27：provider/state/nonce/code_verifier/next_path/remember_me/issued_at）；`_verify_state_signed`（:45）复用 jwt_secret + 300s 过期；`compute_code_challenge(verifier)`（:73）S256 base64url 无填充；cookie 名 `df_oidc_state_{provider}`（:20）**path 限定 `/api/v1/auth/callback/{provider}`**（:102）；secure 标志按请求是否 HTTPS 动态决定。

**`user_provisioning.py`（113 行）**：`get_or_provision_oidc_user(...)`（:22）五步：①按 `(provider,subject)` 查已链接用户（:39-41）②`require_verified_email` 未验证→403（:44-48）、无 email→403（:50-54）③`allowed_email_domains` 域名白名单大小写不敏感（:59-65）④**同 email 本地账户已存在→409，绝不自动 link**（:70-76，防 SSO 接管密码账户）⑤`auto_create_users` 关闭→403（:79-83），否则建号、角色由 `admin_emails` 精确匹配决定（`_resolve_role` :109）。竞态处理：唯一索引冲突时重查 `(provider,subject)`（:93-104）。

**`pat.py`（234 行）**：Personal Access Token 体系。
- `dfp_` 前缀（:22）+ 32 字节 CSPRNG → **定宽 base62**（`_base62` :142 左补零，防前导零字节产生短 token）；库中只存 hex SHA-256 摘要（`pat_token_digest` :165）；校验 `hmac.compare_digest`（:170）。
- `_PAT_ROUTE_RULES`（:52-117）：(方法集合, 路径正则) 白名单表，精确枚举 threads/runs/projects/trash 子树——**PAT 仅可访问显式列出的路由，其余一律 403（default-deny）**（注释 #5041 review P1-1）。
- `authenticate_pat(app, authorization)`（:193）：digest 索引查 `get_active_by_digest` → 复核 → 取属主用户（属主被删则 token 死亡 :216-220）→ touch_last_used（300s 节流 :26）；**所有失败统一 401 "Invalid token"**（防枚举 oracle，:196-201），基础设施错误原样传播 fail-closed。
- `extract_bearer_token`（:177）：`None`=无头（回落 cookie）、`""`=有头不可用（视为无效凭证）。
- `validate_scopes`（:225）：未知 scope 拒绝、排序去重。PAT 权限=属主权限∩scopes 只收窄（`auth_middleware.py:188-193`）；PAT 永非 admin（`deps.py:883-886`）。

**`session_cookie.py`（111 行）**：会话 cookie 策略。`resolve_session_cookie_policy`（:65）决策矩阵：不记住→会话 cookie；HTTPS→持久；本地回环→HTTP 持久（`is_local_browser_origin` :45）；显式 env 开关→操作员自担的 HTTP 持久；**公网 HTTP→降级为非持久会话 cookie**（:80-83，防中间人窃取长效凭证）。`set_session_cookie`（:86）双 cookie（access_token + 持久偏好标记）均 httponly/samesite=lax；写 `request.state` 三键供 CSRF 联动（:106-108，键常量在 `session_cookie_state.py:3-6`）。`_request_hostname`（:38）**不信任转发 Host 头**。

**`credential_file.py`（48 行）**：`write_initial_credentials(email, password, *, label)`（:21）把初始/重置的明文密码以 `os.open(O_WRONLY|O_CREAT|O_TRUNC, 0o600)` 单系统调用原子写入（:41-46），消除 write-then-chmod 窗口——规避 CodeQL 明文日志告警的替代交付通道。

**`reset_admin.py`（91 行）**：CLI（`python -m app.gateway.auth.reset_admin`）：`init_engine` → 找首个 admin → `secrets.token_urlsafe(16)` 新密码 → `token_version += 1` 吊销全部旧 JWT（:68）→ `needs_setup=True` → `write_initial_credentials(label="reset")`。

**repositories/**：`base.py`（108 行）`UserRepository(ABC)`（:18）七方法（create_user/get_user_by_id/get_user_by_email/update_user/count_users/count_admin_users/get_user_by_oauth），`UserNotFoundError(LookupError)`（:8）。`sqlite.py`（298 行）`SQLiteUserRepository`（:135）基于共享异步引擎（users 表与 threads_meta/runs 同库）：`_normalize_email`（:116）全小写规范化——修复 `Victor@x.com` 与 OIDC `victor@x.com` 形成两行绕过「本地账户阻断 SSO」不变量的漏洞（:117-131 注释）；`create_user`（:175）先 `func.lower(email)` 预检查，IntegrityError 按约束名归类三种 ValueError（:197-222）；`get_user_by_email`（:230）大小写不敏感+取最旧行（遗留重复行不 500）；`update_user`（:244）email 仅真实变更时才规范化回写（:255-272）。**表结构（由引用推导，模型在 harness）**：users 九列 id/email/password_hash/system_role/created_at/oauth_provider/oauth_id/needs_setup/token_version + 唯一索引 `ix_users_email`、复合唯一 `idx_users_oauth_identity`。

### 4.3.2 auth_middleware.py（199 行）— 全局认证安全网

`AuthMiddleware(BaseHTTPMiddleware)`（:67），注册于 `app.py:771`。`dispatch`（:90）流程：
1. 公开路径放行（`_PUBLIC_PATH_PREFIXES` :34：`/health`、`/docs`、`/api/v1/auth/oauth/*`、`/api/v1/auth/callback/*`、`/api/webhooks/*` 等；`_PUBLIC_EXACT_PATHS` :48：login/register/logout/setup-status/initialize/providers）。
2. 凭证优先级链：①内部 token 头（:95-116）→ ②**Bearer PAT 存在即严格**：无效直接 401 不回落 cookie，还需 `is_pat_allowed_route` 白名单（:117-142）→ ③access_token cookie：严格 JWT 校验失败 401（:143-163）→ ④auth-disabled 合成用户（:164-166）→ ⑤否则 401 NOT_AUTHENTICATED（:167-176）。
3. 成功后 `resolve_route_permissions` 算权限（PAT 时与 scopes 交集只收不放，:184-193），构建 `AuthContext` 存 `request.state.auth`（:194），`set_current_user` ContextVar 包裹 call_next、finally 复位（:195-199）。

### 4.3.3 authz.py（584 行）— RBAC 权限模型

- **权限**：`resource:action` 字符串。全集（`Permissions` :59-74 与 `_ALL_PERMISSIONS` :149-159）9 项：threads:read/write/delete、runs:create/read/cancel、projects:read/write/delete；另有独立的 `sandbox:execute`（:374）与模型路由授权（:320）。
- **主体**：单一 `user.system_role`（admin/user/合成 internal）；internal 不是 RBAC 角色而被 pop 掉、回落 `config.authorization.default_role`（:253-257,360-364）。`build_principal_from_context`（:259-268）构建 principal。
- **策略来源**：`deerflow.config.AuthorizationConfig`（enabled/fail_closed/default_role/provider）经 `resolve_authorization_provider` 得 provider，按 config 对象身份+内容签名双层缓存（:188-226，热加载安全）；disabled→全权限（:238-239）；provider 解析失败→fail_closed 决定 `[]` 或全权限（:247）。**每请求对 9 项权限 asyncio.gather 并行独立评估**（:271-295）。
- **执行点**：中间件层预算权限集写入 AuthContext；路由层 `@require_permission(resource, action, owner_check, require_existing)`（:595）：`has_permission` 检查（:669-673）+ 属主核查（`ThreadMetaStore.check_access` :694-698，他人线程 404 防枚举；`require_existing=True` 让缺行也 404 :613-615）；internal 调用者按 `X-DeerFlow-Owner-User-Id` 复核 owner 而非绕过（:699-714）。`@require_auth`（:545）独立 401 兜底。
- `require_cancel_permission_if`（:127）：`?action=interrupt|rollback` 与 `multitask_strategy` 等隐式取消能力的权限门。
- `SandboxRequestLease`/`try_acquire_sandbox_for_request`（:421/:442）：sandbox 门与租约获取合成单入口；被拒角色返回 `denied=True` 租约（上传继续、无沙箱副本）。

### 4.3.4 认证总体流程（文字流程图）

```
HTTP 请求
 └▶ AuthMiddleware.dispatch (auth_middleware.py:90)
     ├─ 公开路径白名单放行 (:34-64)
     ├─ X-DeerFlow-Internal-Token 有效 → 合成 internal 用户（含 owner 头）(:95-116)
     ├─ Authorization: Bearer 存在 → authenticate_pat (pat.py:193)
     │    ├─ 失败 → 硬 401（绝不回落 cookie）
     │    └─ 成功 → is_pat_allowed_route 门 (pat.py:122)，白名单外 403
     ├─ access_token cookie → deps.get_current_user_from_request (deps.py:814)
     │    ├─ decode_token (jwt.py:40) → TokenError ⇒ 401（区分 expired/invalid）
     │    ├─ LocalAuthProvider.get_user(sub) → 无用户 ⇒ 401
     │    └─ user.token_version != payload.ver ⇒ 401（改密吊销）
     ├─ auth_disabled → 合成 admin 用户
     └─ 无凭证 → 401 NOT_AUTHENTICATED
 └▶ resolve_route_permissions (authz.py:229) → PAT scope 交集收窄
 └▶ request.state.user / request.state.auth(AuthContext) / user_context ContextVar
 └▶ 路由层 @require_permission 细粒度授权（+ThreadMetaStore 属主核查）
```

OIDC 登录编排（路由层，见 4.8.7）：`GET /api/v1/auth/oauth/{provider}` 生成 state/nonce/PKCE 并写签名 cookie → 302 跳 IdP → `GET /api/v1/auth/callback/{provider}` 校验 state（常数时间）→ `OIDCService.authenticate_callback` → `get_or_provision_oidc_user` → 签发 JWT + 种会话/CSRF cookie → 302 回前端。

### 4.3.5 模块对外接口

`app.gateway.auth.__init__`（43 行）门面重导出 AuthConfig/get_auth_config/错误/JWT/LocalAuthProvider/User/密码/AuthProvider/UserRepository；`authz.require_permission/require_auth` 被全部路由使用；`deps.get_current_user*`/`is_admin_user`/`require_admin_user` 为 FastAPI 依赖族。

---

## 4.4 模块：GitHub App 集成（`app/gateway/github/`，8 文件）

### 4.4.1 模块职责

把 GitHub App webhook（PR/issue/评论/review）转化为 agent run：验签在路由（`routers/github_webhooks.py`，见 4.8.20），本模块负责**扇出分发、身份映射、令牌铸造、触发门控、提示词构造**。设计要点：webhook 处理保持轻量（无 langgraph 调用）以保障 GitHub 10 秒投递超时（`dispatcher.py:21-22`）；实际 agent 回帖由 agent 在沙箱内用 `gh` CLI 完成，渠道出站 `send` 仅写日志（`channels/github.py:85-115`）。

### 4.4.2 文件组成与关键实现

**`app_auth.py`（230 行）**：两级令牌。`mint_app_jwt`（:117）RS256 私钥签发（payload `iat=now-60 容时钟偏移, exp=now+9min, iss=app_id`，:127-135；TTL 9 分钟留余量 :37）；`mint_installation_token(installation_id)`（:169）：**无锁快路径读缓存（:208-211）+ 双检锁**（每安装一把锁 :65-71），leeway 提前 5 分钟刷新（:39）；`_request_new_installation_token`（:138）POST `/app/installations/{id}/access_tokens`，过期时间直接墙上时钟+60min 不解析 ISO（:157-160）。`app_id()`（:81）每次调用重读 env 支持免重启轮换；私钥 inline PEM 优先于文件路径（:104-105）。缓存进程内明文、并发冷启动可能重复铸造（注释 :16-18 认为可接受）。

**`registry.py`（149 行）**：扫描全部声明 `github:` 块的自定义 agent（file/db 双后端），按 `(repo, event)` 建索引。`GitHubAgentMatch`（:41，frozen：user_id/agent/trigger——trigger 预解析，dispatcher 无需再匹配 bindings）；`build_github_agent_registry()`（:102）以 `store.signature()` 为缓存键（file 后端=config.yaml mtime，db=内容摘要 :121-126），`threading.Lock`（:72，因经 `asyncio.to_thread` 调用）；`_build_index`（:75）双层循环 bindings×triggers，事件 opt-in（binding 不列即不注册 :87-98）。**用户映射关键**：`user_id` 来自 `store.list_all()` 的 agent 属主——事件不映射到 GitHub 触发者，而映射到绑定该 agent 的 DeerFlow 用户。

**`triggers.py`（209 行）**：纯函数门控。`DEFAULT_TRIGGERS`（:43）：`pull_request: actions=["opened"]`、评论类 `require_mention=True`；`_resolved_trigger`（:97）基于 `model_dump(exclude_unset=True)` 的**字段级合并**（binding 显式设置优先，缺省回落事件默认 :126-128）；`_mentions(body, login)`（:131）边界感知正则 `(?:^|[^A-Za-z0-9-])@{login}(?![A-Za-z0-9-])`——`@deerflow` 不误配 `@deerflow-bot`、`@` 前是登录字符（邮箱）不匹配（:146-147）；`event_should_fire`（:150）三道门：actions 白名单 → allow_authors 大小写不敏感 → require_mention；返回 `(fire, reason)` 供日志。

**`dispatcher.py`（491 行）**：`fanout_event(bus, event, delivery_id, payload, ...)`（:188）流程：①`extract_target`（identity.py:62）提取 (repo, number)，无目标直接返回（:219-225）②`asyncio.to_thread(build_github_agent_registry)`（:234）+ `lookup_agents`（:235）③逐 agent 过闸：`_is_self_event`（:41，剥 `[bot]` 后缀 :79-80；自我身份优先级=github.bot_login→所有 binding 的 mention_login→兜底 agent_name :89-99；**只过滤自己**，Copilot 等其他 bot 放行 :66-69）→ `event_should_fire`（:335）→ `_is_redundant_review_comment`（:104，review 提交的伴随内联评论防扇出噪声 :182-185）→ `build_prompt`（:388）+ `resolve_thread_id`（:389）④构造 `InboundMessage`（:430-473）：`channel_name="github"`、`chat_id=repo`、`topic_id=f"{number}:{agent.name}"`（:400）、**`owner_user_id=match.user_id`**（agent 属主 :439）、metadata 含去重键 `delivery_id:user_id:agent_name`（:429）、`agent_name`（:452）、`github{repo,number,event,delivery_id,installation_id,recursion_limit,thread_id}`（:457-465）、`preferred_thread_id`（:471）⑤`bus.publish_inbound`（:483）。返回 `{matched_agents, fired_agents, skipped}` 供路由响应。

**`identity.py`（92 行）**：`GITHUB_THREAD_NAMESPACE`（:26）全 fleet 固定 UUID 命名空间；`resolve_thread_id(repo, number, agent_name)`（:29）= `uuid5(ns, f"{repo}#{number}:{agent_name}")`（:59）——**同 PR 不同 agent 落不同线程**，避免 `multitask_strategy="reject"` 静默丢 run（:33-39）；`extract_target`（:62）支持五类事件（PR/PR review/PR review comment/issue comment/issues :73-85）。

**`prompts.py`（223 行）**：六个事件 builder（`_EVENT_BUILDERS` 分发表 :201-208）+ `build_prompt`（:211，未知事件通用 stub 不崩溃）。所有模板声明「最终 assistant 消息只写 run log，不会回帖；要回复需自己在 run 中调 `gh`」（如 :54-57）——描述式而非命令式提示词。

**`run_policy.py`（149 行）**：`inject_github_credentials(msg, run_context)`（:25）：从 metadata 取 installation_id → `mint_installation_token` → 写 `run_context["github_token"]`（**必须字符串**，langgraph_sdk HTTP 传输 JSON 编码闭包无法过线 :33-45）；超 1 小时长 run 可能 401（已知延迟修复项 :47-58）；铸造失败向上传播由 `_apply_channel_policy` 记录并让 run 无凭证继续（只读好过无响应 :59-63）。`register_policy()`（:91）注册 `ChannelRunPolicy(is_interactive=False, default_recursion_limit=250, credentials_provider=..., requires_bound_identity=False, fire_and_forget=True, buffer_followups_on_busy=True)`（:103-141）；模块导入即自动注册（:148），`__init__.py:24` 副作用 import 保证任意子模块导入即注册。

### 4.4.3 模块对外接口

`fanout_event`（被 `routers/github_webhooks.py:37` 调用）、`CHANNEL_RUN_POLICY["github"]` 策略（被 channels/manager 消费）、`resolve_thread_id`/`extract_target`（dispatcher 内部）。触发链详见第 7 章场景三。


---

## 4.5 模块：渠道集成层（`app/channels/`，25 个生产 py 文件，批次 4）

### 4.5.1 模块职责

DeerFlow 的 IM 接入层：各平台适配器（Channel）把外部消息包装为 `InboundMessage` 发布到异步 `MessageBus`；`ChannelManager` 消费队列、创建/复用 LangGraph thread、经 langgraph-sdk 调用 Gateway 的 LangGraph 兼容 API 触发 agent 运行，结果以 `OutboundMessage` 回发渠道。在整体架构中是与 HTTP 路由并列的第二入口，位于安全层之上（渠道 worker 以内部 token 身份回打 HTTP）、run 服务层之下。

### 4.5.2 文件组成

| 文件 | 行数 | 一句话职责 |
|------|------|------------|
| `base.py` | 393 | Channel 抽象基类：生命周期、入站背压预约、跨线程提交、出站回调骨架 |
| `message_bus.py` | 359 | Inbound/Outbound 数据模型 + 有界异步总线（预约制背压） |
| `manager.py` | 2602 | ChannelManager：worker 池分发、thread 管理、run 触发、follow-up 缓冲、附件摄取 |
| `service.py` | 510 | ChannelService：生命周期编排、懒加载注册表、进程单例 |
| `store.py` | 157 | IM 会话↔thread JSON 映射（channel:chat[:topic] 键） |
| `run_policy.py` | 118 | ChannelRunPolicy 注册表（策略对象模式） |
| `buzz_run_policy.py` / `feishu_run_policy.py` | 12/15 | 策略注册副作用模块（避免循环依赖） |
| `commands.py` | 90 | 渠道命令单一权威定义（/connect /new /status /models /memory /agent /goal /help /bootstrap） |
| `connection_identity.py` | 44 | 把持久化渠道连接附着到入站消息 |
| `dedupe_store.py` | 276 | 入站重投递去重（Protocol + 内存/Postgres 双实现） |
| `runtime_config_store.py` | 157 | UI 录入凭据 JSON 持久化（原子写+0600） |
| `sandbox_files.py` | 43 | 附件同步进线程沙箱（Feishu/DingTalk 用） |
| `slack.py` | 475 | Slack Socket Mode（WebSocket） |
| `discord.py` | 779 | discord.py 网关（专有线程独立事件循环） |
| `telegram.py` | 896 | python-telegram-bot 长轮询，流式=原地编辑消息 |
| `feishu.py` | 1101 | 飞书/Lark WebSocket 卡片交互 |
| `dingtalk.py` | 988 | 钉钉 Stream Push（WebSocket）+ 可选卡片 |
| `wecom.py` | 648 | 企业微信智能机器人 WebSocket（流式 reply_stream） |
| `wechat.py` | 1461 | 微信 iLink HTTP 长轮询（自带 AES 媒体加解密/CDN） |
| `buzz.py` | 1314 | Buzz(Nostr) 自研 relay WebSocket 客户端 |
| `buzz_nostr.py` | 201 | 纯 Nostr/NIP-01 协议原语（BIP-340 签名） |
| `buzz_seen_events.py` | 385 | Buzz 已处理事件持久化（写合并+有界停机刷盘） |
| `github.py` | 115 | GitHub 渠道适配器（出站 log-only，入站来自 webhook 路由） |
| `__init__.py` | 16 | 重导出 Channel/InboundMessage/MessageBus/OutboundMessage |

### 4.5.3 基础设施详解

**`message_bus.py` — 数据模型与总线**
- 数据类型：`InboundMessageType`（CHAT/COMMAND，:31）；`InboundMessage`（:39：channel_name/chat_id/user_id/text/topic_id/connection_id/owner_user_id/workspace_id/files/metadata 等）；`ResolvedAttachment`（:80）；`OutboundMessage`（:101）；元数据键常量 `PENDING_CLARIFICATION_METADATA_KEY`（:19）、`INBOUND_FILE_CONTENT_KEY`（:23，Telegram 内联字节私有通道）。
- 准入异常（:140-148）：`InboundQueueFullError`/`InboundQueueClosedError`/`InboundReservationExpiredError`；`InboundReservation`（:152）两阶段（commit/release）。
- `MessageBus`（:174，有界队列默认 1000）：`publish_inbound`（:199）先 `sleep(0)` 让批产者给 worker 出队机会，再预约+put_nowait **绝不等待容量**；`reserve_inbound`（:219）SDK 线程安全（`threading.Lock` 统计 queued+reservations 对抗 maxsize，满载限频告警 :227-247）；`_commit_inbound`（:249）/`get_inbound`（:275）/`join_inbound`（:293）/`close_inbound`（:297）/`open_inbound`（:310）/`discard_pending_inbound`（:315）；出站 `subscribe_outbound`（:338）/`publish_outbound`（:346，顺序 await 各监听器并捕获异常）。
- 并发设计：有界队列+预约制背压，避免无界 put 造成任务堆积（内存耗尽防护）。

**`base.py` — Channel 抽象契约**
- 抽象三件套：`start()`（:78）/`stop()`（:82）/`send(OutboundMessage)`（:88）。可覆写：`send_file`（:96，默认 False）、`receive_file`（:375）、`is_running`（:68）、`supports_streaming`（:72）、`_on_outbound`（:352，仅 wecom 覆写）。
- 模板方法模式——子类只实现传输细节，基类负责：
  - **入站背压预约**：`_reserve_inbound`（:310）/`_commit_reserved_inbound`（:326）/`_publish_inbound_or_drop`（:341），满载即丢并记录；
  - **跨线程提交**：`_ThreadsafeSubmission`（:34，协程+事件循环+Future）与 `_submit_threadsafe_coroutine`（:160）——Provider SDK 回调常在专有线程运行，经 `loop.call_soon_threadsafe` 把协程提交回 Gateway 主循环并保留真实 asyncio Task；`_close_and_drain_threadsafe_futures`（:252）stop 时统一 cancel+drain；
  - **connect-code 优先门**：`_pending_connect_code`（:274）——/connect 命令一律先于 allowed_users 门（框架级规则）；
  - `_make_inbound`（:287）入站工厂；`_send_with_retry`（:106）指数退避 2^attempt；`_on_outbound`（:352）按 channel_name 过滤、先发文本再传附件、文本失败跳过附件。

**`run_policy.py` + 两个注册模块 — 每渠道策略**
`ChannelRunPolicy`（frozen dataclass，:23）七开关：`is_interactive`（False 时 manager 设 disable_clarification，:104）、`default_recursion_limit`（:105）、`credentials_provider`（:106）、`requires_bound_identity`（:107）、`fire_and_forget`（用 `runs.create` 替代 `runs.wait` 规避 SDK 300s 超时，:109）、`serialize_thread_runs`（同线程排队而非报 busy，:109）、`buffer_followups_on_busy`（:110）。`CHANNEL_RUN_POLICY`（:118）全局映射，未注册渠道走交互式默认值。buzz（`serialize_thread_runs=True, requires_bound_identity=False`——公钥白名单即身份门）、feishu（`serialize_thread_runs=True`）在 `manager.py:23-24` eager import；github 在 4.4 详述。设计意图：新增 webhook 渠道变成一行注册（`manager.py:1699-1716` 注释明示）。

**`dedupe_store.py` — 重投递去重**
`InboundDedupeStore`（Protocol，:30）：`try_record`（True=重复应丢弃）/`release`。`MemoryInboundDedupeStore`（:43）：进程内 OrderedDict，TTL 10 分钟、上限 4096（:22-23），头部 O(k) 淘汰（:58-75）。`PostgresInboundDedupeStore`（:81）：单条 `INSERT ... ON CONFLICT DO UPDATE ... WHERE first_seen < TTL RETURNING` 原子条件 upsert（:145-162），同事务懒清理（:174-177），**fail-open**（DB 故障时放行 :180-185——宁可重复处理不可丢消息）。工厂 `make_inbound_dedupe_store`（:214）按 `dedupe_storage` 配置与 database.backend 选 memory/postgres/auto，多 worker 且无法共享时告警（:245-276）。

**`store.py` / `runtime_config_store.py` / `buzz_seen_events.py` / `connection_identity.py` / `sandbox_files.py` / `commands.py`**
- `ChannelStore`（:16）：键 `channel:chat_id[:topic_id]`（`_key` :74）；`get_thread_id`（:82）/`set_thread_id`（:88）/`remove`（:110，无 topic 时前缀删除）/`list_entries`（:140）；每次变更全量原子重写（`_save` :56），threading.Lock 保护。
- `ChannelRuntimeConfigStore`（:17）：默认写 `{base_dir}/channels/runtime-config.json`（:25-29）；`_save`（:46）NamedTemporaryFile+replace 原子替换；`set_provider_disconnected`（:84）写 `_runtime_disabled` 标记；模块级 `merge_runtime_channel_configs`（:110）把运行时配置就地并入 channels 配置（跳过已断开 provider :124-126）。
- `BuzzSeenEventStore`（:76）：LRU 式 `channel_id -> deque[ids]`（每频道 512/总频道 512，:70-73）；弥补 manager 去重 10 分钟 TTL 与重启空白（docstring :4-29）；同步 API（seen :338/record :353/flush :319）与事件循环 API（aseen/arecord/aflush，文件 IO 全 `asyncio.to_thread`）；写合并 1 秒窗口落盘（`FLUSH_DELAY_SECONDS` :65、generation 计数防陈旧快照 :164-171）；`aflush`（:259）有界停机终刷+shield；fail-open 双向（读失败=空、写失败=下轮重试，宁可重放不可漏）。
- `attach_connection_identity`（connection_identity.py:10）：按 `(provider, external_account_id, workspace_id)` 查 `connection_repo.find_connection_by_external_identity`（:31），命中回填 connection_id/owner_user_id/workspace_id（:39-42）。
- `sync_file_to_thread_sandbox`（sandbox_files.py:8）：对非 thread-data-mount 的沙箱 provider，持 `acquire_sandbox_client_lease`（release_on_last=False，:28-34）后 `sandbox.update_file` 写入（:40）。
- `commands.py`：`KNOWN_CHANNEL_COMMANDS`（:11）单一权威；`strip_leading_mentions`（:45）剥群聊前导提及；`extract_connect_code`（:67）解析 `/connect <code>`；`is_known_channel_command`（:86）命令必须在位置 0。

### 4.5.4 ChannelManager（`manager.py:1182`，2602 行）— 核心分发器

**模块级基础设施**（类外）：
- `CHANNEL_CAPABILITIES`（:139-149）渠道能力表（是否支持流式）；`INBOUND_FILE_READERS` 注册表（:192）+`register_inbound_file_reader`（:195），默认 HTTP 读取 `_read_http_inbound_file`（:199，流式、拒 Content-Encoding、50MB 上限 :164），wecom/wechat 专用读取器（:337/:364）在 :384-385 自注册；WeCom 媒体主机门 `_is_allowed_wecom_media_url`（:288）。
- follow-up 设施：`_FollowupEntry`（:424）、`_followup_dedupe_key`（:448）、`_format_followup_block`（:484）；`_is_thread_busy_error`（:440）。
- 结果解析族：`_extract_response_text`（:554）、`_extract_artifacts`（:846）、`_has_current_turn_clarification`（:633）、流式累积 `_accumulate_stream_text`（:800）与 **AI 消息类型白名单** `_is_assistant_stream_type`（:771——防隐藏 human/system 上下文泄漏到 IM，:783-784 记载真实事故）。
- 身份/所有权：`_effective_owner_user_id`（:931）、`_owner_headers`（:942）、`_channel_storage_user_id`（:959，run 身份与文件桶单一事实源）；`_resolve_attachments`（:1013，**仅 outputs 目录可外发**）；`_prepare_artifact_delivery`（:1056）；`_ingest_inbound_files`（:1085，INBOUND_FILE_CONTENT_KEY 内联字节优先 :1096-1134，写 uploads 目录 :1160-1168）。

**生命周期**：
- `__init__`（:1190）：`AsyncKeyedLockTable` 防并发重复建线程（:1241）、per-thread 序列化锁表（:1244）、去重存储（:1262）、follow-up 缓冲与 watcher 集合（:1269-1275）。
- `start`（:1809）：`open_inbound` + 固定 worker 池 `deerflow-channel-worker-N`（默认并发 5，:62；:1820-1826）。
- `begin_shutdown`（:1837）/`stop`（:1843）：关闭准入→worker 宽限排空（默认 3s，:63）→超时取消 worker、丢弃未处理消息并汇总告警（:1866-1916）。
- `_worker_loop`（:1922）：固定协程逐条 await，**绝不 per-message 建任务**；每消息 `ensure_trace_context` 作用域（:1939）；去重失败/异常时释放 key（:1958-1981）。

**去重**：`_inbound_dedupe_key`（:1986）四元组 channel/workspace/chat/message_id；无 workspace 则 fail-closed 跳过去重（:2014-2018）；`_is_duplicate_inbound`（:2021）/`_release_inbound_dedupe_key`（:2039）。已知边界：去重 TTL 后的手动重投会重复副作用（:110-119 文档自述）。

**分发与 thread 管理**：
- `_handle_message`（:2060）：身份门 → 命令/聊天分流，异常统一 `_send_error`；`_get_bound_identity_rejection`（:2107）**不信 inbound 自带身份**，重读 connection repo 核对（:2136-2153）。
- `_lookup_thread_id`（:2178）/`_store_thread_id`（:2187）：connection 优先，否则 ChannelStore；`_create_thread`（:2235，支持 preferred_thread_id 确定性线程+ConflictError 竞态恢复 :2265-2310）；`_get_or_create_thread`（:2317，键锁+双检）。

**聊天主路径**（核心链路，第 7 章场景二展开）：
- `_handle_chat`（:2359）：序列化排队提示 → 获取 per-thread 锁 → `_handle_chat_on_thread`（:2419）。
- `_resolve_run_params`（:1610）：session 三层合并、agent 选择、channel_name/user_id 注入 context；自定义 agent 一律走 lead_agent+agent_name（:1676-1692）。
- `_apply_channel_policy`（:1718）：disable_clarification、credentials_provider 容错。
- 三分支执行：流式 `_handle_streaming_chat`（:2576，runs.stream + messages/values 双模式 + 1s/60 字符节流推送 "▉" 前缀进度 :2632-2655，finally 发布 final）；`fire_and_forget` → `runs.create`（:2503，ConflictError 时按策略缓冲 follow-up 或释放 key+busy 提示 :2504-2515）；默认 `runs.wait`（:2523）→ 提取文本/artifact → `_prepare_artifact_delivery` → 发布 OutboundMessage（:2561-2574）。
- follow-up 链：`_buffer_followup`（:1361）、`_maybe_spawn_followup_watcher`（:1426）、`_watch_run_and_drain_followups`（:1462，订阅 StreamBridge 直到 END_SENTINEL）、`_drain_followups_for_thread`（:1503，每批最多 10 条合并为 `<followups-while-busy>` 块，失败重入队 :1566-1591）。
- 命令处理：`_handle_command`（:2714，/new /status /models /memory /agent /goal /help /bootstrap、slash-skill 解析转发聊天）；`_handle_agent_command`（:2814）；`_handle_goal_command`（:2879，httpx 调 Gateway goal API）；`_fetch_gateway`（:2919）。

### 4.5.5 ChannelService（`service.py:113`，510 行）— 生命周期编排

- 注册表 `_CHANNEL_REGISTRY`（:27）：9 渠道名→`module:Class` 导入路径；`_CHANNEL_CREDENTIAL_KEYS`（:40）；`_channel_has_credentials`（:55）。
- `__init__`（:120）组装 bus/store/manager（解析 inbound_queue_maxsize/max_concurrency/shutdown_grace/langgraph 与 gateway URL，:130-156）；`from_app_config`（:162）工厂（合并运行时配置 :185）。
- `start`（:197）先 manager.start 再 `ensure_ready_channels`（:209）；`ensure_channel_ready`（:227）每渠道 asyncio.Lock 串行化就绪检查（:244）+重试上限——**渠道健康检查/重连**分三层：①适配器内建重连（buzz `_run_loop`、wechat `_poll_loop`、各 SDK 自动重连）②`is_running` 覆写为「传输线程存活」（discord.py:282、feishu.py:136）供 ensure_channel_ready 周期重启死渠道 ③就绪轮询由 router 驱动。
- `restart_channel`（:340，配置重载走 `asyncio.to_thread` :355）；`configure_channel`（:368）/`remove_channel`（:378）；**所有权保持清理** `_stop_and_discard_channel`（:394）：stop 成功才丢弃实例，失败保留并拒绝替换（:431-432，防孤儿 outbound 监听器）。
- `_start_channel`（:434）：`resolve_class` 动态导入、注入 channel_store/connection_repo/buzz seen_event_store_path，拒绝覆盖仍被跟踪实例（:447-450）。
- 进程单例：`get_channel_service`（:551）/`start_channel_service`（:556，from_app_config 走 to_thread :576）/`stop_channel_service`（:581）。Gateway lifespan 在 `app.py:436-439` 启动。

### 4.5.6 九个渠道适配器对比

| 渠道 | 传输 | 流式实现 | 身份门 | 文件处理 | 特有机制 |
|------|------|----------|--------|----------|----------|
| slack | Socket Mode WebSocket（`start` :104，后台 executor 连接 :145） | ❌（runs.wait + 完成/失败表情 :171-199） | allowed_users + /connect 绑定（:338-359） | send_file files_upload_v2（:202） | mrkdwn 转换（:23）；thread_ts 作 topic_id（:369-385）；eyes 反应+"Working on it..."（:392-394）；per-connection WebClient 缓存（:241） |
| discord | discord.py 网关，专有线程独立事件循环（`_run_client` :767） | ❌ | mention 判定 | 2000 字符按换行切块（:319） | `is_running`=线程存活（:282）供服务重启；discord_threads.json 独立持久化防空写（:143）；跨循环 `run_coroutine_threadsafe` 清理 typing/ack 任务（:208）；mention_only/thread_mode 三种建线程策略（:605-672） |
| telegram | python-telegram-bot 长轮询（专有线程 `_run_polling` :718） | ✅ 原地 edit_message_text（私聊 1s/群聊 3s 节流 :250） | 私聊直入；/start 深链绑定先于 allowed_users（:853-861） | 图片 10MB/文档 50MB；**下载 URL 含 bot token 绝不外泄**——在 Telegram 循环下载，字节经 INBOUND_FILE_CONTENT_KEY 交给 manager（:505-513） | Rich Message 编辑（:342）；SQLAlchemy 会话绑主循环故必须回主循环执行（:884）；流式目标上限 256（:41） |
| feishu | lark-oapi WebSocket 专有线程（`_run_ws` :223-255，替换 SDK 模块级 loop 兼容 uvloop） | ✅ 卡片「Working on it...→原地 patch→DONE 表情」（`_send_card_message` :669，final 失败降级新回复 :689-698） | connect-code + 白名单 | receive_file 下载替换 `[image]/[file]` 占位（:390-405），20MB 上限，同步进沙箱（:498-506） | 澄清续接 30 分钟 TTL（:763/:794）；**文件消息微批** 0.75s 窗口合并同用户连发附件（:34,:906,:961）；`serialize_thread_runs=True` |
| dingtalk | Stream Push WebSocket（daemon 线程 `_run_stream` :365） | ⚙️ 配置 card_template_id 才有（:164） | connect-code + allowed_users | downloadCode 两步 API 下载（`_download_by_code` :704，50MB 流式上限），claim+write 同锁防覆盖（:652-669） | 卡片流式更新失败降级 sampleMarkdown（:263-268）；markdown 适配（代码块/表格转引用式 :123）；token 双检锁缓存余量 300s（`_get_access_token` :885）；`_DingTalkMessageHandler` 把原始 payload 藏 `_df_raw_data`（:1120） |
| wecom | wecom-aibot SDK WebSocket（`asyncio.create_task(ws.connect())` :191） | ✅ reply_stream 流式回复（`_send_ws` :544-558） | connect-code | 图片 2MB/文件 20MB，init/chunk/finish 三段分片上传+base64（`_upload_media_ws` :589） | 20480 字节/10 条切块（:46-55）；按 chat 加锁防多 worker 交错（:567-587）；`_on_outbound` 覆写清理 per-thread frame 上下文（:286）；入站媒体主机白名单（:127） |
| wechat | iLink HTTP 长轮询（`_poll_loop` :578） | ❌ | connect-code + 白名单 | **AES-128-ECB 媒体加解密** + CDN 上下传：full_url 主机白名单门（`_is_allowed_media_url` :1640，dot 边界匹配）→ AES key 解析（:1370）→ 流式下载密文（:1002）→ 解密落盘（:1277）；出站 getuploadurl→CDN 上传密文→sendmessage（:402/:488） | context_token 双索引缓存（:680-683）；errcode=-14 token 过期停渠道（:597-604）；**整批处理完才推进游标并持久化**（崩溃最多重放一批，:631-639）；鉴权态/游标 0600 原子写（:1511/:1480）；二维码登录（:770） |
| buzz | 自研 websockets 客户端（`_run_loop` :864 指数退避+抖动封顶 60s 永久重连 :919-920） | ✅ 先发占位 kind-9 再 kind-40003 原地编辑（`send` :1377） | **pubkey 白名单默认全拒**（:310-316；relay host=workspace_id :265） | _chunk_text 60KB UTF-8 切块（:183） | NIP-42 机会式鉴权重跑 discovery（`_session` :786,:843-855）；**每 EVENT 入口验签**（:966-968）；seen-id 去重「只重放不跳过」不变量（:1334-1341）；水位拒绝未来时间戳防 DoS（:1223-1238）；隐藏上下文标记直接拒发——Nostr 事件不可撤回（:1425-1430）；订阅上限 256（:83） |
| github | 无监听（入站来自 webhook 路由） | ❌（fire_and_forget） | agent 属主绑定（requires_bound_identity=False） | 无 | `send` 仅记日志（agent 沙箱内自用 gh CLI 回帖，`github.py:85-115`）；策略详见 4.4 |

共性：全部实现 `/connect <code>` 绑定流（telegram 用深链 `/start <token>`）；connect-code 一律先于 allowed_users 门；入站走 `_reserve_inbound` 预约（wechat 例外——轮询本就在主循环，:701-704）。

### 4.5.7 模块对外接口

`ChannelService` 单例三函数（get/start/stop，供 `app.py` lifespan 与 `routers/channels.py`/`routers/github_webhooks.py` 使用）；`MessageBus` 供 `github/dispatcher.py` 发布；`merge_runtime_channel_configs` 供 `ChannelService.from_app_config`；`CHANNEL_RUN_POLICY` 供各渠道注册。状态文件集中在 `{base_dir}/channels/`：store.json、runtime-config.json、buzz_seen_events.json、discord_threads.json、wechat-{auth,getupdates}.json（均原子写，敏感 0600）。


---

## 4.6 模块：网关核心服务（`app/gateway/services.py`，1885 行，批次 5）

### 4.6.1 模块职责

run 生命周期的业务逻辑层。模块 docstring（:1-6）明确定位：`thread_runs`/`runs` 路由只是薄 HTTP 壳，真正执行 agent 的是 harness 的 `deerflow.runtime.run_agent`（:65 导入，:1715 调用）。**无 AgentService/RunService 类——这是函数式服务层**，导出约 25 个模块级函数。

### 4.6.2 关键函数解析

**`start_run(body, thread_id, request, *, idempotency_key=None, require_existing_thread=False) -> RunRecord`（:1459）— 运行 agent 的唯一准入函数**（HTTP 与内部启动共用）：
1. `require_cancel_permission_if`（:1488）：interrupt/rollback 策略视同 cancel 能力（multitask_strategy≠reject 需 runs:cancel）。
2. 校验链：`validate_thread_id`（:1491）→ run metadata 秘密校验（:1498）→ `normalize_stream_modes`（:1503）→ 取 bridge/run_mgr/run_ctx（:1504-1506）→ model 白名单（:1517-1524）→ **`thread_access_allowed` 线程属主核查**（:1541-1563——stateless run 的 thread_id 在 body 中，路由装饰器管不到；非属主 404 防枚举）。
3. 参数构建：`resolve_agent_factory`（:1567，恒为 `assemble_lead_agent`，:751-767）→ `normalize_input`（:1573，dict→消息、剥离服务端专属元数据 :432-494）→ 服务端签发 trace id 覆盖（:1582-1583）→ `build_run_config`（:1585：thread_id 强制注入、`__` 前缀 context 键剥离 :921、**recursion_limit 服务端钳制** :940-954、assistant_id→agent_name :958-976）→ `apply_checkpoint_to_run_config`（:1586）→ `merge_run_context_overrides`（:1592，白名单键 :506-519）→ 非 internal 时 `strip_internal_context_keys`（:1596）→ `inject_authenticated_user_context`（:1598，user_id/role 只信服务端 :671-748）。
4. 会话引用：`prepare_conversation_reader` 装配读取器（:1605-1636，见 4.2.17）；`resolve_project_context` 钉住项目快照（:1642-1649）。
5. **durable 准入**：`goal_thread_lock` 内 `ensure_checkpoint_history_seeded` + 二次属主复查 + `run_mgr.create_or_reject`（:1730-1758，kwargs 存脱敏 config :1753）；幂等冲突 409（:1760-1767）。
6. `asyncio.create_task(run_after_metadata)`（:1769-1783）——**durable 准入与 task 挂载之间零 await**（崩溃窗口最小化）；`run_after_metadata`（:1651）先 5s 有界确保 thread_meta（`_ensure_thread_metadata` :198-233，缺行自动建 threads_meta），再 `run_agent(...)`（:1715-1727）后台执行并把事件发布到 StreamBridge。

**`sse_consumer(bridge, record, request, run_mgr, *, apply_on_disconnect=True, emit_gap_on_missing_stream=False)`（:1954）— SSE 流式返回核心**：
- `bridge.subscribe(run_id, last_event_id)` 逐事件 `format_sse`（:156：`event:`→`data:`→`id:`→空行，兼容 useStream/langgraph-sdk 解码器）yield；
- `Last-Event-ID` 断线续传（:1984）；`StreamGap` → `gap` 帧 + `reload_durable_state` 恢复指引（:2010-2023）；心跳哨兵 → 注释帧 `: heartbeat` 并核查孤儿恢复可合成 end（:2025-2029）；`END_SENTINEL` → `end`（:2032-2034）；
- `finally` 仅创建端点且 `on_disconnect=cancel` 时 `run_mgr.cancel`（:2038-2046）；observer join 不取消。

**`wait_for_run_completion(...)`（:2049）**：非流式 `/wait`——同一 bridge 订阅循环，gap 就地续读尾部（:2099-2105），断连且 cancel 策略时取消（:2114-2117），返回 bool 区分完成/断连，**防半截 checkpoint 冒充正常响应**（issue #3265）。

**内部启动器**：
- `launch_scheduled_thread_run`（:1799）：合成 internal request + `non_interactive` context + `scheduled-task:{run_id}` 幂等键 + 每次启动独立 trace 上下文（:1855）。
- `launch_mcp_task_notification_run`（:1878）：不可变事件快照转提示词、`mcp-task:{task}:{ver}:{attempt}` 幂等键、404→PermanentNotificationError / 409→ConflictError（:1945-1950）。

**checkpoint 状态访问族**（thread 分支/编辑/历史的数据通道）：
- `build_checkpoint_state_accessor`（:1183）/ async 版 `abuild_checkpoint_state_accessor`（:1234，经 run_assembly 线程池防 MCP 阻塞 loop，issue #5172）；
- 线程级入口 `build_thread_checkpoint_state_accessor`（:1287，先 `resolve_thread_assistant_id` :1262 再按 assistant 编图）；写路径 `build_thread_checkpoint_state_mutation_accessor`（:1309）与 `build_checkpoint_state_mutation_accessor`（:995）；
- 编译图缓存（assistant_id, mode, snapshot_frequency) 键 + 工厂/config 身份校验 + KeyedLockTable 防重复构建（:1031-1103）；full 模式下工厂失败降级 `_RawCheckpointReadAccessor`（:1129-1224，`_RawCheckpointSnapshot` :1106）。
- 辅助：`reserve_checkpoint_write`（:97，goal 锁+线程操作预留）、`ensure_checkpoint_history_seeded`（:1397，迁移 shim）、`apply_checkpoint_to_run_config`（:1338）。

**输入/上下文工具**：`normalize_input`（:432）、`strip_server_owned_state_metadata`（:407）、`merge_run_context_overrides`（:611）、`strip_internal_context_keys`（:596）、`inject_authenticated_user_context`（:671）、`resolve_agent_factory`（:751）、`build_run_config`（:866）。

### 4.6.3 模块对外接口

`start_run`（thread_runs/runs/scheduler/mcp_tasks 四方共用）、`sse_consumer`/`wait_for_run_completion`（流式与非流式响应）、`launch_scheduled_thread_run`/`launch_mcp_task_notification_run`（后台服务专用）、checkpoint accessor 族（threads/thread_runs 路由使用）、`format_sse`。

---

## 4.7 模块：依赖注入与运行时装配（`app/gateway/deps.py`，763 行）

**`langgraph_runtime(app, startup_config)`（:381，@asynccontextmanager）**——被 `app.py:378` 的 lifespan 进入，是全部运行时组件的装配点：
1. 多 worker/agent-storage 启动守卫：`_enforce_postgres_for_multi_worker`（:58，GATEWAY_WORKERS>1 必须 Postgres，SQLite 忽略行锁）、`_validate_agent_storage`（:131）。
2. 依序初始化：StreamBridge（可 Redis）→ 持久化引擎 → checkpointer/Store → 各 SQL 仓储（users PAT threads_meta runs run_events feedback projects scheduled_tasks mcp_tasks subagent_batches）→ 扩展服务 → thread_store → **RunManager + 启动孤儿 run 回收**（`_terminalize_recovered_runs` :329、`_mark_latest_startup_recovered_threads_error` :298，deps.py:608-623）+ 心跳。
3. 退出时：`_drain_inflight_runs`（:166，排水在途 run ≤5s shield）再拆 checkpointer。

**引擎 getter 族**（`_require` 工厂 :660-670，缺依赖 503）：`get_stream_bridge`(:673)、`get_run_manager`(:674)、`get_checkpointer`(:675)、`get_run_event_store`(:676)、`get_feedback_repo`(:677)、`get_run_store`(:678)、`get_project_repo`(:679)、`get_project_document_repo`(:680)、`get_store`(:683，唯一允许 None)、`get_thread_store`(:688)、`get_scheduled_task_repo`(:696)、`get_scheduled_task_run_repo`(:703)、`get_scheduled_task_service`(:710)、`get_mcp_task_repo`(:717)、`get_mcp_task_service`(:724)、`get_subagent_batch_repo`(:731)、`get_subagent_batch_service`(:738)。

**组合器与认证族**：`get_run_context(request) -> RunContext`（:745-767，config 热取、event_store/config 冻结 startup 快照）；`get_local_provider`（:779，缓存单例）、`get_pat_repo`（:801，memory 后端 503）、`get_current_user_from_request`（:814：request.state.user 短路否则 cookie→JWT→DB→token_version）、`is_admin_user`（:866，PAT 永非 admin）、`require_admin_user`（:894）、`get_optional_user_from_request`（:905）、`get_current_user`（:916，返回 id 字符串）；`get_config`（:345，异常→503）。

---

## 4.8 模块：路由层（`app/gateway/routers/`，32 文件，~14000 行）

> 路由注册不在 `__init__.py`（它只 import 13 个子模块，:1-15）——真正聚合在 `app.py:882-976` 逐个 `include_router`（顺序：models→features→console→mcp→mcp_tasks→subagent_batches→memory→skills→integrations→artifacts→browser→uploads→threads→scheduled_tasks→agents→projects→project_documents→project_thread_files→trash→subagents→suggestions→input_polish→channel_connections→channels→assistants_compat→auth→user_preferences→feedback→thread_runs→runs），`github_webhooks` 条件挂载（:975-979）。

### 4.8.1 threads.py（1634 行）— 线程生命周期

前缀 `/api/threads`（:80）。端点：DELETE `/{thread_id}`（delete_thread_data :706）、POST ``（create_thread :866）、POST `/{thread_id}/branches`（branch_thread :953）、POST `/search`（:1173）、PATCH `/{thread_id}`（:1216）、POST `/{thread_id}/move`（:1255）、GET `/{thread_id}`（:1276）、GET/PUT/DELETE `/{thread_id}/goal`（:1329/1342/1368）、POST `/{thread_id}/compact`（:1399）、GET/POST `/{thread_id}/state`（:1446/1495）、POST `/{thread_id}/history`（:1699）。

关键实现：
- **删除**（:706-833）：`goal_thread_lock` + `run_manager.reserve_thread_operation(kind=delete)`（在飞任务则 409，:717-728），按序清理六层：线程目录 → checkpoints（best-effort）→ run 行（只删 run 类预约保留保护行 :783-789）→ run events（防删除后 /messages 复活 :791-800）→ feedback → thread_meta 行 → 关闭浏览器会话（防 cookie 复用 :824-831）。
- **创建幂等**（:866-950）：thread_meta + 空 checkpoint（`checkpointer.aput(empty_checkpoint())` :940）；并发重复主键经 `_resolve_existing_thread` 认领回收（:909-923）；`_strip_reserved_metadata`（:110-141）剥离入站 metadata 的 `owner_id/user_id/deerflow_project_id`。
- **分支**（:953-1170）：源线程独占预约下定位目标 assistant turn（`_find_branch_checkpoint` :220）→ lineage 查回放基点（`_find_branch_replay_base` :264）→ 新线程 uuid + branch metadata → reducer 通道值包 `Overwrite` 写两个合成 checkpoint（:1091-1109）→ 排除 `sandbox/thread_data/task_history` 通道（`_BRANCH_EXCLUDED_CHANNELS` :129）→ 快照消息作 seed 事件写入 event store（:1143-1157）→ **仅分支点为最新 turn 时克隆 user-data 工作区**（`_copy_branch_user_data` :327-349）。
- **历史端点**（:1699-1917）：仅首个 checkpoint 携带 messages；AI 消息 run_id 精确归属（event store 反扫）+ `turn_duration` 注入，BackgroundTasks 写时迁移固化到 checkpoint metadata（`_persist_run_history_metadata_background` :1645-1696）。
- `_derive_thread_status`（:647-668）：pending `__error__` 写或 task error→error、有 tasks→interrupted、否则 idle；`redact_metadata_secrets` 应用于所有响应（:426-430）。

### 4.8.2 thread_runs.py（1532 行）— Run API（LangGraph Platform 兼容）

前缀 `/api/threads`（:68）。端点：POST `/{tid}/runs`（create_run :923）、POST `/{tid}/runs/stream`（stream_run :941）、POST `/{tid}/runs/wait`（wait_run :996）、POST `/{tid}/runs/regenerate/prepare`（:901）、`/edit-regenerate/prepare`（:912）、GET `/{tid}/runs[/page]`（:1091/:1101）、GET `/{tid}/runs/{rid}`（:1143）、POST `/cancel`（:1155）、GET `/join`（:1215）、POST+GET `/{rid}/stream`（:1331/:1344）、GET `/{tid}/messages[/page]`（:1361/:1500）、GET `/{tid}/runs/{rid}/messages`（:1528）、GET+POST `/{rid}/artifacts/archive`（:1637/:1652）、GET `/{rid}/events`（:1710）、GET `/{rid}/workspace-changes`（:1747）、GET `/{tid}/token-usage`（:1767）。

关键实现：
- **stream_run**（:941-993）：`start_run` 后返回 `StreamingResponse(sse_consumer(...))`；响应头 `Content-Location: /api/threads/{tid}/runs/{rid}`（LangGraph SDK 贪婪正则提取 run_id，:984-992）+ `X-Accel-Buffering: no`；store-only 且进程本地 bridge 在飞的 run 直接 409（:969-973）。
- **Idempotency-Key**：`_scope_http_run_idempotency_key`（:90-103）哈希为 `http-run:{sha256(owner\0thread\0key)}`；复用时 input 不一致→409。
- **cancel**（:1155-1212）：`run_mgr.cancel(run_id, action)` 返回 CancelOutcome（cancelled/requested/taken_over 成功；`lease_valid_elsewhere`→409+精确 Retry-After，`_raise_lease_valid_elsewhere` :334-356）。
- **join vs stream**：`GET /runs/{rid}/stream` 拒绝 `action` 参数（405+Allow: POST，防 SameSite=Lax GET 导航 CSRF，:1240-1252）；join 一律 `apply_on_disconnect=False`（观察者断开不触发创建者 cancel，:1230,:1318）。
- **regenerate/edit prepare**（:724-893）：定位最新可见 AI 消息→找源 run（`_find_target_run_id` :571）→ 找目标 human 之前的 checkpoint 作回放基点（`_find_base_checkpoint_before_human` :611，lineage 优先+时间扫描兜底）；当前 title 注入 input 防 checkpoint 回滚恢复旧标题（#4457，:793-797）；edit 变体生成替换 human 消息（`_clean_human_message_for_edit` :499）。
- **消息端点**：`/messages` 给每 run 最后一条 AI 消息挂 feedback 与 turn_duration；`/messages/page` 仅向后的 keyset 分页；内部调用者 `_run_scope_user_id` 返回 None 以免按授权身份过滤不到持久行（#5437，:1065-1088）。
- **工件归档**（:1652-1707）：从 run.delivery 事件读 `present_files` 列表，在 `reserve_thread_operation(kind=artifact_archive)` 内构建 ZIP（信号量限 4 并发+`asyncio.shield` 防客户端断开抛弃工作线程 :1571-1607）。

### 4.8.3 runs.py（146 行）— 无状态 Run 端点

前缀 `/api/runs`（:24）。POST `/stream`（:33）、POST `/wait`（:59）、GET `/{run_id}/messages`（:108）、GET `/{run_id}/feedback`（:139）。thread_id 从 `body.config.configurable.thread_id` 解析，缺省自动生成临时线程（`_resolve_thread_id` :27-30）；属主检查下沉到 `start_run` 内的 `thread_access_allowed`（body 携 thread_id 时装饰器无效）。`stateless_wait` 完成后序列化最终 checkpoint 值（:77-91）。

### 4.8.4 mcp.py（1390 行）— MCP 服务器配置管理

前缀 `/api`（:31），全部要求管理员。端点：GET `/mcp/config`（:1110）、PUT `/mcp/config`（:1438）、POST `/mcp/config/servers`（:1498，重名 409）、PUT `/mcp/config/server`（:1521）、DELETE `/mcp/config/servers/{name:path}`（:1547）、PATCH `/mcp/config`（:1569，启停）、POST `/mcp/cache/reset`（:1417）。核心设计：
- **GET 掩码/PUT 回填**：GET 时 `_mask_server_config`（:808-862）把 env/headers/oauth secrets/user_auth.users/敏感 extra 键替换 `***`；PUT 时 `_merge_preserving_secrets`（:865-1107）把已存在键的 `***` 换回磁盘真实密钥，新键给 `***` 则 400；`_ensure_no_masked_secrets`（:574-622）拒绝把掩码占位持久化。
- **stdio 执行策略**：命令必须是单个可执行名（默认 allowlist npx/uvx，env `DEER_FLOW_MCP_STDIO_COMMAND_ALLOWLIST` 扩展，:658-684）；`_arbitrary_exec_arg`（:94-305 的 `_LauncherGrammar` + npm/uv 参数表）在 launcher 选项区筛查 `-c/-e/--eval` 等求值标志；`_CODE_INJECTING_ENV_VARS`（PYTHONPATH/NODE_OPTIONS/LD_PRELOAD 等，:335-349）直接拒绝。
- **写路径**：`asyncio.to_thread` 中持进程锁+文件锁做 raw JSON 读改写（保留 `$VAR` 占位与外层键，:1174-1236），原子写后 `reload_extensions_config()` + `reset_mcp_tools_cache()`。

### 4.8.5 skills.py（641 行）— 技能管理

端点 11 个：GET `/skills`（:271）、POST `/skills/install`（:287，从线程目录装 .skill，虚拟路径经 `resolve_thread_virtual_path` 解析）、POST `/skills/install/upload`（:304，`_BoundedSkillArchiveMultiPartParser` 在 multipart 解析期间即实施 100MiB 上限 :58-75）、POST `/skills/reload`（:356）、GET `/skills/custom`（:378）、`/custom/{name}/export-manifest`（:395）、`/custom/{name}/export`（:415，revision 乐观锁 + `run_export_work`）、GET/PUT/DELETE `/custom/{name}`（:436/:458/:498）、`/custom/{name}/history`（:528）、`/custom/{name}/rollback`（:554）、GET/PUT `/{skill_name}`（:603/:675，启停）。PUT 内容前 markdown 校验+静态扫描+内容扫描（block 即 400），写入后 `append_history`；PUBLIC 技能写共享 extensions_config.json，CUSTOM/LEGACY 写每用户 `_skill_states.json`。

### 4.8.6 auth.py（911 行）— 认证路由

前缀 `/api/v1/auth`（:44）。端点：POST `/login/local`（:402）、`/register`（:457）、`/logout`（:486）、`/change-password`（:497）、GET `/me`（:561）、POST/GET `/pats` + DELETE `/pats/{id}`（:651/:688/:698）、GET `/setup-status`（:721）、POST `/initialize`（:788）、GET `/providers`（:880）、GET `/oauth/{provider}`（:907）、GET `/callback/{provider}`（:986）。关键实现：进程内 IP 限流表 `_login_attempts`（策略热读 `auth.local`，:183-396；`_get_client_ip` 仅当 TCP peer 在 `AUTH_TRUSTED_PROXIES` 时信任 X-Real-IP :233-268；超限 429）；弱口令黑名单 `_COMMON_PASSWORDS`（:61-124）；token 只存 HttpOnly cookie；改密 bump token_version 重发 cookie+CSRF（:543-556）；**PAT 管理与改密都要求 AUTH_SOURCE_SESSION**（PAT 凭据不能自我增殖 :589-599）；`setup-status` 60s TTL 缓存+in-flight 去重（:710-775）；OIDC 流程见 4.3.4；`validate_next_param`（:1112-1129）只允许相对路径防开放重定向。

### 4.8.7 其余 26 个路由文件速览

| 文件 | 前缀/端点要点 | 关键逻辑 |
|------|--------------|----------|
| `agents.py`（523 行） | `/api/agents` CRUD + `/user-profile` | 名称 `^[A-Za-z0-9-]+$` 小写化；模型必须存在于 models:（:123-143）；`preserve_non_managed_fields` 保住手工 github: 绑定（:466-467）；legacy 共享布局 409 提示迁移（:411-415）；删除时取消缓冲记忆提取（:604-617） |
| `artifacts.py`（495 行） | GET/PUT `/api/threads/{tid}/artifacts/{path:path}` | `.skill/` 从 ZIP 内提取成员（16MiB/成员+Range :214-229）；active content（HTML 族）强制下载+nosniff（:283-304）；≤2MiB 算 SHA-256 作 ETag（LRU 缓存 :307-330）；PUT 仅 outputs 内 UTF-8 文本、`expected_sha256` 乐观并发（412）、临时文件+os.replace 原子替换并同步沙箱、失败回滚（:504-571） |
| `uploads.py`（469 行） | POST/GET/DELETE `/api/threads/{tid}/uploads` | `ThreadUploadIngestionService` 薄适配（:386-428）；`_link_staged_no_overwrite` os.link 原子无覆盖（:245-280）；限额 10 文件/50MiB 单/100MiB 总（:184-189）；chmod 组/其他读位（:137-153） |
| `trash.py`（245 行） | `/api/trash` 列出/恢复/清除/清空 | 惰性触发保留期清扫（每用户 900s 节流 :44-54）；restore 同字节合并返回 merged、内容缺失 409 content_missing（:171-205）；purge 先删文件后删行、失败行保留可重试（:208-224） |
| `projects.py`（215 行） | `/api/projects` CRUD+archive/restore | instructions 按 UTF-8 字节数上限 422 拒绝不截断（:103-113）；`/config` 声明在 `/{id}` 前防路径吞并（:131） |
| `project_documents.py`（495 行） | `/api/projects/{pid}/documents` | 内容去重 200 vs 新建 201（:164）；from-thread 把线程 uploads/outputs 快照上架（来源双重 resolve+relative_to 限定 :239-264）；attach-to-thread 行锁下 stage 稳定副本复用上传管线（:335）；下载永远原始字节、markdown 伴生仅预览（:410） |
| `project_thread_files.py`（161 行） | GET `/api/projects/{pid}/thread-files` | 按成员线程分页聚合 uploads+outputs，file_limit 截断 OR 进信封 truncated（:96-99） |
| `scheduled_tasks.py`（511 行） | `/api/scheduled-tasks` CRUD+preview-cron+pause/resume/trigger | assistant_id 归一化校验（:62-89）；once ≥ min_once_delay_seconds（:227-231）；运行中/排队出现时 409（:92-103）；PATCH 推未来自动重置 enabled（:354-359）；pause/delete 连带取消 queued 出现（:393,:467） |
| `subagents.py`（239 行） | `/api/subagents` CRUD | system_prompt 仅管理员可见（:163）；model 须 inherit 或已配置（:77-81）；与 builtin/config 冲突 409 |
| `subagent_batches.py`（131 行） | `/api/threads/{tid}/subagent-batches` | GET 批次/条目、pause/resume/cancel（worker 未跑 503）、retry（仅失败项）、results.jsonl 分页流式 NDJSON 导出（:105） |
| `mcp_tasks.py`（127 行） | `/api/threads/{tid}/mcp-tasks` | GET 列表/单条、cancel（worker 未运行 503 而非记录无人执行的取消 :113-118）；错误文本截 500 字符 |
| `memory.py`（512 行） | `/api/memory` 系列 9 端点 | 属主解析优先可信内部 owner header（make_safe_user_id 归一 :18-37）；最小后端不实现的操作统一 501（:133-149）；max_facts 驱逐时 409（:332-334） |
| `models.py`（206 行） | GET `/api/models[/{name}]` | 授权开启时经 provider.filter_resources/authorize(model:use) 过滤，异常按 fail_closed 决定空列表/403 或放行（:96-113,:174-196） |
| `console.py`（516 行） | GET `/api/console/{stats,runs,usage}` | 直接 SQL 聚合 RunRow/ThreadMetaRow（内存后端 503 :121-128）；从 models[*].pricing 构建价格表估算花费（:153-204） |
| `browser.py`（500 行） | POST navigate + WS `/threads/{tid}/browser/stream` | 工具启用+线程属主精确匹配（NULL 属主不可驱动 :62-71）；**WS 认证自管**（升级绕过 AuthMiddleware：cookie 解码+token_version 或 auth-disabled :117-139）；Origin 校验防 WS-CSRF（:142-177）；关闭码 4401/4403/4404/4429/4409/4501；帧泵独立 loop 跳转、输入事件合并 move/wheel（:376-415）；navigate 复用 agent 工具同款 SSRF 校验（:440-447） |
| `channels.py`（59 行） | GET `/api/channels/`、POST `/{name}/restart`（管理员） | 读 ChannelService 状态 |
| `channel_connections.py`（573 行） | `/api/channels` providers/connections/runtime-config/connect | connect 生成绑定码 TTL 600s、每 provider 5 个 pending 上限原子计数（:327-350）；密码字段 `********` 回填语义（:459-481）；凭据变更即时热重启通道（:694-699 重读-单键改写防并发覆盖） |
| `github_webhooks.py`（387 行） | POST `/api/webhooks/github`（:172） | 免 auth/CSRF（自带签名）；**HMAC-SHA256 常数时间验签**（:101-113），密钥运行时被清且未开 dev 门→503（:222-238）；**verify-then-parse**（先验签后解析 :257-259）；channel 未启用→200+skipped（:300-319）；fan-out 异常显式 503 使 GitHub Recent Deliveries 记录失败供手动 Redeliver（:351-368）；挂载条件 is_route_enabled（:85-98：secret 已设或 DEER_FLOW_ALLOW_UNVERIFIED_GITHUB_WEBHOOKS=1，两者皆无则路由不挂载 404 fail-closed） |
| `assistants_compat.py`（153 行） | `/api/assistants` stub | 为 useStream React hook 提供兼容：返回 lead_agent+自定义 agent（均 graph_id=lead_agent）、空 graph/schemas |
| `features.py`（101 行） | GET `/api/features` | agents_api/browser_control/mcp_tasks/subagent_batches/conversation_references 可用性；读 app.state.* 反映实际启动的运行时（:80-91） |
| `feedback.py`（190 行） | `/api/threads/runs/{rid}/feedback` 系列 | rating 限 ±1；先经 run_store 验证 run 属于该线程（404 防枚举） |
| `suggestions.py`（149 行） | GET config、POST `/threads/{tid}/suggestions` | LLM 生成后续问题 JSON 数组，容错解析（:44-66），异常返回空列表不报错 |
| `input_polish.py`（108 行） | POST `/api/input-polish` | 发送前润草稿，不建 run 不落消息；run_oneshot_llm 单次调用，输出剥 think 块/代码围栏（:28-36） |
| `integrations.py`（405 行） | `/api/integrations/lark/*` | 封装 harness 的 lark_cli 设备码流；非管理员响应隐藏宿主路径（:182-207）；LarkFlowSupersededError→409 |
| `user_preferences.py`（61 行） | GET/PATCH `/api/v1/auth/preferences` | 必须浏览器会话凭据（403 :24-31）+ X-Expected-User-Id 头一致（409 防串号） |

---

## 4.9 模块：定时任务调度器（`app/scheduler/service.py`，630 行）

`ScheduledTaskService`（:28）：interval/cron/once 三类任务的到期扫描、准入、排队、启动 run 与完成回写。

**调度循环（函数级）**：
- `_run_loop`（:616-630）：`while not stop` → `run_once(now=utcnow)` → **异常仅记日志**（SQLite "database is locked" 等瞬态不得杀死 poller，:621-623 注释）→ `asyncio.wait_for(stop.wait(), timeout=poll_interval)`。
- `run_once`（:56-79）五步：①多实例 `_reconcile_active_state`（:58-61，受 skip 标志）/单实例 `recover_expired_launch_claims`（:63-66）——**防重复执行核心：租约属主比对+过期回收**；②`_expire_waiting_runs`（:510，排队超时默认 1h 过期）；③`_drain_queue`（:483，逐条：任务已删→interrupted、paused 且非手动→interrupted、否则 `_attempt_queued_run`）；④`claim_due_tasks(now, lease_owner, lease_seconds, limit=max_concurrent_runs)`（:72-77）**一次原子租约抢占到期任务**（到期 occurrence 即使执行槽满也持久化，全局启动预算在 claim_queued_run 的 DB 锁下施加，:69-71 注释）；⑤逐个 `dispatch_task`（:78-79）。
- `dispatch_task`（:111-211）：scheduled 触发要求 `expected_lease_owner`（:118 再防重）；`fresh_thread_per_run` 或无 thread_id 生成新 uuid（:120-121）；thread_id 校验失败走**正常失败记账**而非抛异常（:124-155，否则轮询循环每轮中断）；活动 run 存在→释放准入租约返回既有结果（:156-160）；乐观锁插排队行（:164-177）+ 两类竞态处理（:178-200）。
- `_attempt_queued_run`（:221）→ `_launch_queued_occurrence`（:239-410）：`claim_queued_run(global_max_concurrent_runs)` 抢全局并发预算（:249-255）→ launch 成功后 `update_status("running", protect_terminal=True)`（:293-306，protect 防 fast-fail run 的完成钩子已终结 once 任务）；**失败三分支**：launch 前冲突→requeue（:315-321）；launch 成功记账失败→行保 running 占住活动槽防重复启动、仍报 launched（:330-387）；launch 失败→fail_launching_run 释放槽（:391-410）。
- **启动恢复（错过任务处理）**（`start` :553-584）：单实例=破坏性清扫 `mark_stale_active_runs`（上一进程遗留活动 run 标 interrupted，:567-569，**只在 lifespan 尚未放行请求前安全**）+ `cancel_stuck_once_tasks`（:577-579）；多实例=租约宽限期非破坏恢复 `reconcile_active_runs(lease_grace_seconds)`（属主仍续租的行不动，:586-607）。失败则 raise（fail-closed，`app.py:416-419`）。
- `handle_run_completion`（:517-551）：由 run metadata 的 scheduled_task_id/scheduled_task_run_id 回写；interrupted 单列（用户取消不算执行失败 :529-533）。
- 防重三层：调度租约（expected_lease_owner）+ 排队行 `coordinate_with_task` 活动槽 + `claim_queued_run` 全局预算 DB 锁。

装配：`app.py:397-419`（launch_run=launch_scheduled_thread_run 闭包 :403；配置全部来自 startup_config.scheduler）；HTTP 面在 `routers/scheduled_tasks.py`。

---

## 4.10 模块：MCP 任务与子代理批次

### 4.10.1 app/mcp_tasks/service.py（635 行）— McpTaskService（:45）

把长运行 MCP 后台任务的「提交-轮询-取消-完成通知」移出 agent 循环，落库持久化+租约轮询。
- `submit`（:89-161）：驱动提交→校验 remote_task_id→`_normalize_snapshot`→`repository.create`。**失败补偿**：`DuplicateMcpRemoteTaskError` 直接上抛（取消会杀掉已存在任务 :139-142）；其他异常走 `_cancel_untracked_task`（:143-161）补偿删除远端任务，最多同步等 5 秒（:36,:196-215），超时后补偿转后台（`_compensation_tasks` 集合 :78）。
- `run_once`（:217-239）三步：`_run_cancellations`（:298，claim 取消请求并发 `_cancel_one` :321）→ `claim_due_tasks` 后 gather 并发 `_poll_one`（:506：驱动缺失→释放记错；`McpTaskProtocolError`→直接 FAILED；一般异常→`_release_after_error`）→ `_run_notifications`（:353）。
- **重试算法**：`_release_after_error`（:581-595）`retry_seconds = min(poll_interval × 2^min(consecutive_errors,16), max_poll_backoff=300)`——指数退避；取消/通知重试同公式（:343-344,:499-504）。
- `_next_poll_at`（:572）：终态不轮询；INPUT_REQUIRED 强制更慢轮询（默认 60s）。
- **通知子状态机** `_notify_one`（:391-497）：尝试 ≥5 次→死信（:35,:395-405）；已 dispatched→`_get_run` 查通知 run（success→delivered；error/timeout/interrupted→失败重排；运行中→延后）；未 dispatch→`launch_notification` 启动通知 run（PermanentNotificationError→死信 :462-471；ConflictError→释放 claim :472-480）。
- 载荷防御 `_normalize_snapshot`（:597-629）：error 截 4000 字符；result_artifact/input_required 超限直接抛协议错（拒绝持久化截断 JSON）；result 超限置 None+2000 字符 preview+`result_truncated=True`。
- `start`（:643）创建 `deerflow-mcp-task-poller` 后台任务；`_run_loop`（:662-676）；`stop`（:649）cancel 等待。装配：`app.py:479-502`（launch_notification=launch_mcp_task_notification_run；enabled 时 set_mcp_task_submitter 注入运行时）。

### 4.10.2 app/mcp_tasks/errors.py（2 行）
`PermanentNotificationError(RuntimeError)`——通知在外部状态改变前永远无法送达，用于区分可重试/永久失败（service.py:462 消费转死信）。

### 4.10.3 app/subagent_batches/（shim，2 文件）
`service.py` 仅 5 行：`from deerflow.subagents.batch_service import SubagentBatchService`（:3，docstring "Compatibility import for the harness-owned subagent batch service"）。**真实实现在排除范围 harness**。app 侧可证据事实：`app.py:513-522` 装配（repo 必须 sqlite/postgres 否则 RuntimeError :510-511；`configure_subagent_execution_capacity` 全局容量 :297）；条目状态含 `leased`（`routers/subagent_batches.py:21`）表明 DB 租约队列模型；asyncio 生命周期（await start()/stop()）。

---

## 4.11 模块：入口、根文件与运维脚本（批次 6）

### 4.11.1 app/gateway/app.py（889 行）— 应用工厂与 lifespan

**`create_app()`（:673）**：
- 中间件注册（:771-840）：AuthMiddleware（:771）→ CSRFMiddleware（:816）→ CORSMiddleware（:827-834，仅 GATEWAY_CORS_ORIGINS 非空）→ TraceMiddleware（:840）。Starlette 后注册者在外层，**实际请求序：Trace→CORS→CSRF→Auth→ExceptionMiddleware→路由**——trace 最外保证异常 500 也有追踪头，CSRF 在 Auth 前仅做 token 比对，身份权限统一由 Auth 收口。
- `_resolve_extension_principal`（:782-813）：把认证上下文投影为扩展可用的中性 `ExtensionPrincipal`（PAT 一律压掉 admin 能力 :798-801），以 `EXTENSION_PRINCIPAL_RESOLVER_KEY` 挂 `app.state`。
- 路由挂载：约 30 个 router 依次 include（:882-961）；GitHub webhook 条件挂载（:975-979）；内联 `/health`（:982）与 `/health/ready`（:990）；**扩展路由刻意最后挂载**（宿主路由优先，:1008-1014）。扩展加载：`get_app_config().plugins` 缺 config.yaml 容忍但解析失败上抛（:861-875），`load_extensions` 后写 `app.state.extensions/extension_diagnostics`（:876-878）。
- `app = create_app()`（:1020）模块级实例，uvicorn 入口。

**`lifespan`（:272）启动序**（要点+行号）：①startup_config 快照、子代理容量（:294）、configure_logging（:295）、浏览器 fail-fast（:296）、auth-disabled 告警（:298）②公共技能投影（线程池 :308）③Monocle 追踪（:317-320，失败不阻断）④记忆检索索引后台预热（:325-340）⑤tiktoken 5s 有界预热（:351-368）⑥清理陈旧上传暂存（:370-375）⑦**`async with langgraph_runtime(app, startup_config)`（:378→deps.py:381）**：引擎→checkpointer→仓储→RunManager+孤儿 run 回收+心跳 ⑧`_ensure_admin_user`（:383：首 boot 提示 /setup，否则迁移无主孤儿线程给 admin :170-184）⑨后台垃圾箱清扫（:393）⑩ScheduledTaskService（:400-413，失败且 enabled 则 lifespan 失败）⑪IM channel 服务（:436-439）⑫McpTaskService（:479-502）⑬SubagentBatchService（:513-522）→ yield。
**停机序**：清扫有界等待（:526）→ OIDC 关闭（:529）→ channel 停止（5s 上限 :534-547）→ scheduler/mcp/subagent-batch 依次停止清 submitter（:549-578）→ 浏览器会话关闭（:580-595）→ 检索预热 1s 有界等待（:619-631）→ 扩展观测挂起（:641）→ 记忆队列 flush+backend close（:645-668）→ 退出 langgraph_runtime（排水在途 run ≤5s shield 再拆 checkpointer）。

### 4.11.2 根文件

- `debug.py`（168 行）：VS Code 断点调试 REPL。`_setup_logging`（:37-60）把 root handler 换成只写 debug.log 的 FileHandler（幂等）；延迟导入 deerflow（:74-77，`deerflow.agents` import 即启动后台 skill-loader 线程）→ 初始化 MCP 工具 → `make_lead_agent`（:106）→ prompt_toolkit 异步 REPL（:120-159），把 artifacts 虚拟路径解析为物理路径展示（:141-155）。
- `sitecustomize.py`（26 行）：backend 在 sys.path 上时解释器自动导入（:1-6）；唯一副作用：Windows 把 asyncio 事件循环策略设为 `WindowsSelectorEventLoopPolicy`（:14-26），解决 ProactorEventLoop 兼容问题。
- `Dockerfile`（127 行）三阶段：**builder**（python:3.12-slim-bookworm + build-essential + Node.js 22 + `@larksuite/cli@1.0.65` + uv:0.11.1；`uv sync --locked --extra redis` + UV_EXTRAS 白名单逐项校验 `[A-Za-z][A-Za-z0-9_-]*` :61-74；APT/UV/NPM 镜像可换源；UTF-8 locale :78-80 防 UnicodeEncodeError）→ **dev**（保留编译链 + docker CLI（DooD 沙箱）；CMD uvicorn）→ **runtime**（干净 slim 省约 200MB :94-95；手工 symlink node/npm/npx/lark-cli + docker CLI + uv + 预建 venv；EXPOSE 8001）。两运行阶段同一 CMD：`PYTHONPATH=. uv run --no-sync uvicorn app.gateway.app:app --host 0.0.0.0 --port 8001`。
- `Makefile`（73 行）：install/dev/gateway/test/test-live/test-shard（时长感知分片 :31-51）/lint/format/detect-blocking-io/migrate-rev（:70-72，无 migrate 目标——启动时自动 `alembic upgrade head`，单一执行路径防运维失误 :63-69 注释）。
- `langgraph.json` / `pyproject.toml`：见 1.2/1.3。

### 4.11.3 scripts/ 运维脚本

| 脚本 | 行数 | 职责与要点 |
|------|------|-----------|
| `migrate_agents_to_db.py` | 124 | file 后端自定义 agent（每用户+legacy 共享双布局）与 managed-subagents 一次性导入 SQL 表；幂等（已存在跳过）、非破坏（源文件不动可回滚）、--dry-run；写前跑与 Gateway 相同的 Alembic bootstrap（:79-83） |
| `migrate_memory_markdown.py` | 137 | legacy 全局 memory.json facts → `__default__` Markdown 桶（DeerMem 本就惰性迁移，此 CLI 供多用户升级审计）；--all-users 自动发现；失败退出码 1 |
| `migrate_user_isolation.py` | 339 | legacy 全局数据迁入 per-user 布局（threads 目录经裸 sqlite3 查 threads_meta 建 thread→user 映射 :247-267、agents、skills、全局 memory.json）；冲突目录移入 migration-conflicts/ 人工审查；--dry-run/--user-id |
| `record_gateway.py` | 127 | "record-through-browser" 录制网关：真模型 + BaseCallbackHandler 记 (caller, conversation_hash, input_hash, output) 到 JSONL（:35-82）；patch create_chat_model 并扫 sys.modules 替换已绑定引用（:83-85）；临时 home 隔离；默认 127.0.0.1:8012 |
| `run_replay_gateway.py` | 73 | 密闭回放网关：临时 config 指向 ReplayChatModel + fixture，无 API key 确定性；DEERFLOW_ENABLE_TEST_SEED=1 挂测试 seed router；CORS 给 :3000；默认 8011 |
| `build_fixture_from_jsonl.py` | 45 | 录制 JSONL + .meta.json sidecar 缝合为回放 fixture JSON，打印摘要 |
| `e2e_safety_termination_demo.py` | 206 | 端到端验证 SafetyFinishReasonMiddleware：fake model 首调返回 content_filter+截断 tool_call，断言 tool_calls 清空、safety_termination 事件、tool node 未调用；退出码 0/1 |
| `manual_task_continuity_check.py` | 116 | 生产中间件+真实私有 endpoint 的受控恢复性检查：summary 刻意省略代号逼恢复走源召回，校验 notes/artifact sha256 |
| `_autogen_revision.py` | 78 | make migrate-rev 底层：临时 SQLite 按迁移历史建库（非 create_all，保证新 ORM 字段仍表现为真实 diff :57-62）再 autogenerate；绕开 alembic.ini 默认 URL 指向不存在路径等坑（:3-16）；产物落 harness migrations 目录 |

### 4.11.4 scripts/benchmark/（开发基准工具，目录粒度）

| 子目录 | 用途 | 主入口 |
|--------|------|--------|
| `checkpoint/` | 检查点存储性能：真实 lead-agent 图+脚本化模型+真 AsyncSqliteSaver+真 Gateway 读路由栈，子进程隔离度量 full/delta 延迟 | `bench_production.py`（605 行）、`bench_channels.py`（723 行） |
| `concurrency/` | 真实多进程并发：subprocess.Popen 起 N 个独立 OS 进程同打一张 users 表，验证「GATEWAY_WORKERS>1 必须 Postgres」 | `run_concurrency_bench.py`、`worker.py` |
| `context_snapshot/` | 合成上下文快照评测（完整隔离交接 vs 可选父快照），8 任务 51 条预声明检查 | `__main__.py`（runner/cases/grading/report 分工） |
| `deermem_eviction/` | DeerMem 容量驱逐评测（PR #4789 修复验证），直接调生产 select_facts_for_capacity() | `__main__.py`（cli/dataset/manifest/policy/qa/report 等 17 模块） |
| `sandbox/` | 沙箱 provider 无关基准：acquire/run/release 延迟跨 provider×并发 | `bench_provider.py`（758 行）、`summarize.py` |
| （根）`skill_export.py` | 技能导出性能基准 | `skill_export.py` |


---

# 第 5 章 文件清单总表

> 覆盖全部纳入范围生产文件。依赖列只列项目内依赖（`deerflow.*`=排除范围 harness，作为外部依赖统一标注）；`__init__.py` 类包标记不重复展开。

## 5.1 app/channels/（25 个生产文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| `app/channels/__init__.py` | 4.5 | 包门面 | Channel, InboundMessage, MessageBus, OutboundMessage | base, message_bus |
| `app/channels/base.py` | 4.5 | 渠道抽象基类（生命周期/背压/跨线程提交/出站骨架） | `Channel`(45), `_ThreadsafeSubmission`(34), `_reserve_inbound`(310), `_submit_threadsafe_coroutine`(160), `_send_with_retry`(106), `_on_outbound`(352) | commands, message_bus |
| `app/channels/message_bus.py` | 4.5 | 数据模型+有界异步总线 | `InboundMessage`(39), `OutboundMessage`(101), `InboundReservation`(152), `MessageBus`(174), `publish_inbound`(199), `reserve_inbound`(219), `publish_outbound`(346) | 无（纯 asyncio） |
| `app/channels/manager.py` | 4.5 | 核心分发器 | `ChannelManager`(1182), `_worker_loop`(1922), `_handle_message`(2060), `_handle_chat`(2359), `_handle_chat_on_thread`(2419), `_resolve_run_params`(1610), `_apply_channel_policy`(1718), `_handle_streaming_chat`(2576), `_handle_command`(2714), `_ingest_inbound_files`(1085), `register_inbound_file_reader`(195) | bus/store/policy/commands/dedupe、gateway.csrf/internal_auth/path_utils、github.run_policy、langgraph_sdk、httpx、deerflow.* |
| `app/channels/service.py` | 4.5 | 生命周期编排+注册表+单例 | `ChannelService`(113), `from_app_config`(162), `ensure_channel_ready`(227), `_start_channel`(434), `get_channel_service`(551), `start_channel_service`(556) | manager, store, runtime_config_store, deerflow.config |
| `app/channels/store.py` | 4.5 | 会话↔thread JSON 映射 | `ChannelStore`(16), `get_thread_id`(82), `set_thread_id`(88), `remove`(110), `list_entries`(140) | deerflow.config.paths |
| `app/channels/run_policy.py` | 4.5 | 每渠道运行策略注册表 | `ChannelRunPolicy`(23), `CHANNEL_RUN_POLICY`(118) | 无 |
| `app/channels/buzz_run_policy.py` | 4.5 | Buzz 策略注册 | `register_policy`(6) | run_policy |
| `app/channels/feishu_run_policy.py` | 4.5 | 飞书策略注册 | `register_policy`(8) | run_policy |
| `app/channels/commands.py` | 4.5 | 渠道命令权威定义 | `KNOWN_CHANNEL_COMMANDS`(11), `strip_leading_mentions`(45), `extract_connect_code`(67), `is_known_channel_command`(86) | 无 |
| `app/channels/connection_identity.py` | 4.5 | 渠道连接身份附着 | `attach_connection_identity`(10) | deerflow.persistence（connection repo） |
| `app/channels/dedupe_store.py` | 4.5 | 入站去重双实现 | `InboundDedupeStore`(30), `MemoryInboundDedupeStore`(43), `PostgresInboundDedupeStore`(81), `make_inbound_dedupe_store`(214) | deerflow.persistence.engine, sqlalchemy |
| `app/channels/runtime_config_store.py` | 4.5 | UI 凭据 JSON 持久化 | `ChannelRuntimeConfigStore`(17), `merge_runtime_channel_configs`(110), `apply_runtime_connection_config`(133) | deerflow.config.paths |
| `app/channels/sandbox_files.py` | 4.5 | 附件同步进沙箱 | `sync_file_to_thread_sandbox`(8) | deerflow.sandbox.lease |
| `app/channels/slack.py` | 4.5 | Slack Socket Mode | `SlackChannel`(82), `_handle_message_event`(325), `_bind_connection_from_connect_code`(436) | base, commands, slack_sdk, markdown_to_mrkdwn, connection repo |
| `app/channels/discord.py` | 4.5 | Discord 网关（专有线程） | `DiscordChannel`(36), `_on_message`(465), `_handle_admitted_message`(538), `_run_client`(767), `_load_active_threads`(143) | base, commands, discord.py(可选) |
| `app/channels/telegram.py` | 4.5 | Telegram 长轮询 | `TelegramChannel`(82), `_send_stream_update`(250), `receive_file`(451), `_on_text`(958), `_cmd_start`(853) | base, commands, telegram 库, INBOUND_FILE_CONTENT_KEY |
| `app/channels/feishu.py` | 4.5 | 飞书 WebSocket 卡片 | `FeishuChannel`(43), `_send_card_message`(669), `receive_file`(375), `_queue_file_inbound_batch`(906), `_on_message`(1056) | base, commands, lark-oapi, sandbox_files, connection repo |
| `app/channels/dingtalk.py` | 4.5 | 钉钉 Stream Push | `DingTalkChannel`(140), `_on_chatbot_message`(383), `receive_file`(566), `_stream_update_card`(1049), `_DingTalkMessageHandler`(1098) | base, commands, dingtalk_stream, sandbox_files |
| `app/channels/wecom.py` | 4.5 | 企微智能机器人 WS | `WeComChannel`(94), `_send_ws`(536), `_upload_media_ws`(589), `_publish_ws_inbound`(426), `_on_outbound`(286 覆写) | base, commands, wecom-aibot-sdk |
| `app/channels/wechat.py` | 4.5 | 微信 iLink 长轮询 | `WechatChannel`(160), `_poll_loop`(578), `_handle_update`(646), `_extract_image_file`(1131), `_bind_via_qrcode`(770), `_is_allowed_media_url`(1640) | base, commands, httpx, cryptography(隐含 AES) |
| `app/channels/buzz.py` | 4.5 | Buzz(Nostr) 自研客户端 | `BuzzChannel`(252), `_run_loop`(864), `handle_relay_frame`(924), `_handle_chat_event`(1260), `_advance_watermark`(1203), `send`(1377), `_session`(786) | base, buzz_nostr, buzz_seen_events, commands, websockets |
| `app/channels/buzz_nostr.py` | 4.5 | Nostr 协议原语 | `NostrKeys`(28), `parse_private_key`(84), `sign_event`(100), `verify_event`(135), `build_chat_event`(123), KIND_* 常量(107-116) | coincurve(可选 extra, 懒加载) |
| `app/channels/buzz_seen_events.py` | 4.5 | Buzz seen-id 持久化 | `BuzzSeenEventStore`(76), `seen/record/flush`(338/353/319), `aseen/arecord/aflush`(345/360/259), `quiesce/resume`(197/204) | 无（asyncio.to_thread 文件 IO） |
| `app/channels/github.py` | 4.5 | GitHub 渠道适配器（出站 log-only） | `GitHubChannel`(42), `start`(62), `send`(85) | base, gateway.github.run_policy |

## 5.2 app/gateway/ 根（27 个生产文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| `app/gateway/__init__.py` | 4.2 | 懒加载门面 | `__getattr__`(6) | config, app |
| `app/gateway/app.py` | 4.11 | 应用工厂+lifespan | `create_app`(673), `lifespan`(272), `app`(1020), `_ensure_admin_user`(78), `_migrate_orphaned_threads`(170), `_resolve_extension_principal`(782) | deps, services, 全部 routers, channels.service, scheduler, mcp_tasks, subagent_batches, health, browser_capability, csrf/auth/trace 中间件, deerflow.* |
| `app/gateway/config.py` | 4.2 | 进程绑定配置 | `GatewayConfig`(6), `get_gateway_config`(17) | pydantic |
| `app/gateway/services.py` | 4.6 | run 生命周期服务层 | `start_run`(1459), `sse_consumer`(1954), `wait_for_run_completion`(2049), `launch_scheduled_thread_run`(1799), `launch_mcp_task_notification_run`(1878), `format_sse`(156), `build_run_config`(866), `normalize_input`(432), `inject_authenticated_user_context`(671), `build_thread_checkpoint_state_accessor`(1287), `reserve_checkpoint_write`(97), `ensure_checkpoint_history_seeded`(1397) | run_models, deps, authz, conversation_access, internal_auth, deerflow.runtime/persistence/config, langchain_core |
| `app/gateway/deps.py` | 4.7 | 依赖注入+运行时装配 | `langgraph_runtime`(381), `get_config`(345), `get_run_context`(745), 16 个引擎 getter(660-742), `get_local_provider`(779), `get_pat_repo`(801), `get_current_user_from_request`(814), `is_admin_user`(866), `require_admin_user`(894), `_terminalize_recovered_runs`(329), `_drain_inflight_runs`(166) | auth.*, services, deerflow.runtime/persistence, fastapi |
| `app/gateway/authz.py` | 4.3 | RBAC 权限模型 | `Permissions`(59), `AuthContext`(77), `resolve_route_permissions`(229), `require_permission`(595), `require_auth`(545), `require_cancel_permission_if`(127), `resolve_model_authorization`(320), `try_acquire_sandbox_for_request`(442), `SandboxRequestLease`(421) | internal_auth, deerflow.config(Authorization), thread_meta store |
| `app/gateway/auth_middleware.py` | 4.3 | fail-closed 认证安全网 | `AuthMiddleware`(67), `dispatch`(90), `_is_public`(60) | internal_auth, auth.pat, auth_disabled, deps, authz, request_path |
| `app/gateway/auth_disabled.py` | 4.2 | 免认证模式 | `is_auth_disabled`(34), `get_auth_disabled_user`(49), `is_explicit_production_environment`(26), AUTH_SOURCE_* 常量 | 无 |
| `app/gateway/csrf_middleware.py` | 4.2 | CSRF+CORS 解析 | `CSRFMiddleware`(215), `should_check_csrf`(40), `is_auth_endpoint`(74), `get_configured_cors_origins`(125), `is_allowed_auth_origin`(180), `generate_csrf_token`(35), `get_csrf_token`(281) | request_path, auth_disabled, auth.session_cookie_state |
| `app/gateway/trace_middleware.py` | 4.2 | X-Trace-Id 注入 | `TraceMiddleware`(11) | deerflow.trace_context |
| `app/gateway/health.py` | 4.2 | 就绪探针 | `readiness_payload`(240), `check_database_health`(87), `_probe_sqlite_backend`(162), `_probe_postgres_backend`(194), `_probe_checkpointer_backend`(218), `resolve_checkpointer_config`(104) | deps, sqlalchemy |
| `app/gateway/internal_auth.py` | 4.2 | 进程内部信任 token | `create_internal_auth_headers`(29), `is_valid_internal_auth_token`(37), `get_internal_user`(42), `get_trusted_internal_owner_user_id`(70), 4 常量(13-16) | deerflow（make_safe_user_id） |
| `app/gateway/utils.py` | 4.2 | 日志参数清洗 | `sanitize_log_param`(4) | 无 |
| `app/gateway/pagination.py` | 4.2 | run 消息分页裁剪 | `trim_run_message_page`(6) | 无 |
| `app/gateway/request_path.py` | 4.2 | 路由视角路径投影 | `get_request_route_path`(7) | starlette._utils(私有) |
| `app/gateway/path_utils.py` | 4.2 | 虚拟路径解析 | `resolve_thread_virtual_path`(16), `normalize_outputs_virtual_path`(40), `resolve_outputs_confined_path`(58), `OUTPUTS_VIRTUAL_ROOT`(11) | deerflow.config.paths, runtime user_context |
| `app/gateway/browser_capability.py` | 4.2 | 浏览器能力判定 | `BrowserCapability`(13), `browser_capability`(37), `ensure_browser_runtime_available`(67) | deerflow.config |
| `app/gateway/context_usage.py` | 4.2 | token 用量估算 | `build_context_usage`(62), `build_context_usage_payload`(50) | services, deps, langchain_core |
| `app/gateway/run_models.py` | 4.2 | run 请求模型 | `RunCreateRequest`(29), `ConversationReference`(21), 4 个校验器(61/100/123/149/163) | pydantic, deerflow(流模式白名单) |
| `app/gateway/artifact_archive.py` | 4.2 | outputs ZIP 打包 | `build_artifact_archive`(207), `ArtifactArchiveError`(32), `ArtifactArchiveResult`(39), 限额常量(24-28) | 无（同步文件 IO） |
| `app/gateway/checkpoint_lineage.py` | 4.2 | checkpoint 祖先链 | `find_checkpoint_before_message`(104), `find_checkpoint_before_message_chronologically`(160), 3 异常类(9-17), `is_duration_only_checkpoint`(43), `has_pending_tasks`(48) | langgraph schemas |
| `app/gateway/conversation_access.py` | 4.2 | read_conversation 授权闭包 | `prepare_conversation_reader`(138), `conversation_references_enabled`(117) | conversation_reader, authz, services, run_models |
| `app/gateway/conversation_reader.py` | 4.2 | 可见消息分页扫描 | `read_visible_message_page`(21), `scan_visible_thread_messages`(78), `default_history_hidden_run_ids`(58) | run_event_store, run_manager |
| `app/gateway/skill_export.py` | 4.2 | 技能导出槽位/流式响应 | `run_export_work`(108), `SkillExportResponse`(141), `ExportLease`(64), `export_http_error`(184), 5 响应模型(27-61) | deerflow（run_file_io） |
| `app/gateway/upload_ingestion.py` | 4.2 | 上传摄入管线 | `ThreadUploadIngestionService`(76), `UnsafeFilenameError`(58), `UnsafeUploadDestinationError`(62) | routers.uploads(晚绑定), authz(SandboxRequestLease), deerflow.uploads |
| `app/gateway/langgraph_auth.py` | 4.2 | LangGraph Server 认证 | `auth`(26), `authenticate`(66), `add_owner_filter`(110), `_check_csrf`(37) | auth.jwt, deps, csrf_middleware, langgraph_sdk.auth |
| `app/gateway/langgraph_studio.py` | 4.2 | langgraph dev 壳+持久化修复 | `langgraph_app`(181), `repair_local_dev_persistence_before_runtime`(133), `repair_persisted_assistant_provenance`(83), `configured_system_assistant_ids`(48), `ProvenanceRepair`(27) | 无外部（标准库） |

## 5.3 app/gateway/auth/（16 文件）与 repositories/（3 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| `auth/__init__.py` | 4.3 | 包门面重导出 | AuthConfig 族/JWT/密码/LocalAuthProvider/UserRepository 等 | 各子模块 |
| `auth/config.py` | 4.3 | 认证配置单例+密钥管理 | `AuthConfig`(14), `get_auth_config`(61), `_load_or_create_secret`(35) | dotenv, deerflow.config.paths |
| `auth/errors.py` | 4.3 | 类型化错误 | `AuthErrorCode`(13), `TokenError`(27), `AuthErrorResponse`(35), `token_error_to_code`(42) | pydantic |
| `auth/jwt.py` | 4.3 | 会话 JWT | `TokenPayload`(12), `create_access_token`(21), `decode_token`(40) | pyjwt, config |
| `auth/password.py` | 4.3 | 版本化密码哈希 | `hash_password`(32), `verify_password`(38), `needs_rehash`(61), `hash_password_async`(66), `verify_password_async`(75) | bcrypt |
| `auth/models.py` | 4.3 | 用户模型 | `User`(15), `UserResponse`(35) | pydantic |
| `auth/providers.py` | 4.3 | AuthProvider 抽象 | `AuthProvider`(6) | 无 |
| `auth/local_provider.py` | 4.3 | 本地认证 provider | `LocalAuthProvider`(13), `authenticate`(24), `create_user`(65), `create_oauth_user`(106), `get_user_by_oauth`(86) | providers, repositories, password |
| `auth/oidc.py` | 4.3 | OIDC 核心服务 | `OIDCService`(71), `discover`(96), `build_authorization_url`(144), `exchange_code`(175), `validate_id_token`(273), `fetch_userinfo`(338), `authenticate_callback`(364), 5 异常类(52-64) | httpx, pyjwt, cryptography |
| `auth/oidc_state.py` | 4.3 | state cookie | `OIDCStatePayload`(27), `set/get/delete_state_cookie`(91/106/114), `generate_oidc_state`(58), `compute_code_challenge`(73) | jwt_secret, csrf_middleware, fastapi |
| `auth/pat.py` | 4.3 | PAT 体系 | `generate_pat_token`(160), `authenticate_pat`(193), `is_pat_allowed_route`(122), `pat_token_digest`(165), `extract_bearer_token`(177), `validate_scopes`(225), `PAT_ALLOWED_SCOPES`(28) | deps(局部), repositories |
| `auth/session_cookie.py` | 4.3 | 会话 cookie 策略 | `resolve_session_cookie_policy`(65), `set_session_cookie`(86), `is_local_browser_origin`(45), `SessionCookiePolicy`(26) | session_cookie_state |
| `auth/session_cookie_state.py` | 4.3 | state 键常量 | 4 常量(3-6) | 无 |
| `auth/user_provisioning.py` | 4.3 | OIDC 用户开通 | `get_or_provision_oidc_user`(22), `_resolve_role`(109) | local_provider, deerflow.config |
| `auth/credential_file.py` | 4.3 | 明文凭证受限落盘 | `write_initial_credentials`(21) | 无 |
| `auth/reset_admin.py` | 4.3 | 管理员重置 CLI | `_run`(27), `main`(81) | repositories 之外的 deerflow.persistence, password, credential_file |
| `auth/repositories/__init__.py` | 4.3 | 包标记 | — | — |
| `auth/repositories/base.py` | 4.3 | 仓储抽象 | `UserRepository`(18), `UserNotFoundError`(8) | 无 |
| `auth/repositories/sqlite.py` | 4.3 | SQL 仓储实现 | `SQLiteUserRepository`(135), `_normalize_email`(116), IntegrityError 判别族(32-101) | base, sqlalchemy, deerflow.persistence(模型/索引名) |

## 5.4 app/gateway/github/（8 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| `github/__init__.py` | 4.4 | 包文档+副作用注册 | （import run_policy）(24) | run_policy |
| `github/app_auth.py` | 4.4 | 两级令牌铸造 | `mint_app_jwt`(117), `mint_installation_token`(169), `app_id`(81), `load_app_private_key`(96), `_request_new_installation_token`(138) | httpx, pyjwt(RS256), cryptography |
| `github/dispatcher.py` | 4.4 | webhook 扇出 | `fanout_event`(188), `_is_self_event`(41), `_is_redundant_review_comment`(104) | registry, triggers, prompts, identity, channels.message_bus |
| `github/identity.py` | 4.4 | 确定性线程 ID/目标提取 | `resolve_thread_id`(29), `extract_target`(62), `GITHUB_THREAD_NAMESPACE`(26) | 无 |
| `github/prompts.py` | 4.4 | 事件→提示词 | `build_prompt`(211), `_EVENT_BUILDERS`(201), 六个 builder | 无 |
| `github/registry.py` | 4.4 | agent↔(repo,event) 索引 | `build_github_agent_registry`(102), `lookup_agents`(137), `GitHubAgentMatch`(41), `_build_index`(75) | deerflow.agents(store), threads |
| `github/run_policy.py` | 4.4 | 渠道策略+凭证注入 | `inject_github_credentials`(25), `register_policy`(91) | app_auth, channels.run_policy |
| `github/triggers.py` | 4.4 | 触发门控 | `event_should_fire`(150), `_mentions`(131), `_resolved_trigger`(97), `DEFAULT_TRIGGERS`(43) | 无 |

## 5.5 app/gateway/routers/（32 文件）

| 文件路径 | 所属模块 | 职责（端点数） | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| `routers/__init__.py` | 4.8 | 导入 13 个子模块 | `__all__`(17) | — |
| `routers/threads.py` | 4.8 | 线程生命周期（15 端点） | `create_thread`(866), `delete_thread_data`(706), `branch_thread`(953), `search_threads`(1173), `compact_thread`(1399), `get_thread_history`(1699), `get/update_thread_state`(1446/1495), goal 三端点(1329-1368), `_derive_thread_status`(647), `_copy_branch_user_data`(327) | deps, services, checkpoint_lineage, authz, deerflow.runtime/persistence |
| `routers/thread_runs.py` | 4.8 | run 执行与读取（18 端点） | `create_run`(923), `stream_run`(941), `wait_run`(996), `cancel_run`(1155), `join_run`(1215), `prepare_regenerate_run`(901), `prepare_edit_regenerate_run`(912), `list_thread_messages`(1361), `create_run_artifact_archive`(1652), `_scope_http_run_idempotency_key`(90) | services, deps, authz, conversation_reader, artifact_archive, context_usage, pagination, run_models |
| `routers/runs.py` | 4.8 | 无状态 run（4 端点） | `stateless_stream`(33), `stateless_wait`(59), `run_messages`(108), `run_feedback`(139) | services, deps, pagination |
| `routers/auth.py` | 4.8 | 认证/PAT/OIDC（12 端点） | `login_local`(402), `register`(457), `change_password`(497), `get_me`(561), `create/list_pats`(651/688), `initialize_admin`(788), `setup_status`(721), `oauth_login`(907), `oauth_callback`(986), `_check_rate_limit`(183 族) | auth.* 全家, deps, csrf, session_cookie |
| `routers/mcp.py` | 4.8 | MCP 配置管理（7 端点，管理员） | `get_mcp_configuration`(1110), `update_mcp_configuration`(1438), `create/update/delete_mcp_server*`(1498/1521/1547), `update_mcp_server_state`(1569), `_mask_server_config`(808), `_merge_preserving_secrets`(865), `_arbitrary_exec_arg`(94) | deps, deerflow.extensions/mcp, 文件锁 |
| `routers/skills.py` | 4.8 | 技能管理（11 端点） | `install_skill`(287), `upload_and_install_skill`(304), `export`族(395/415), `update_custom_skill`(458), `rollback_custom_skill`(554), `_BoundedSkillArchiveMultiPartParser`(58) | deps, skill_export, path_utils, deerflow.skills |
| `routers/agents.py` | 4.8 | 自定义 agent+USER.md（7 端点） | `list_agents`(209), `create_agent_endpoint`(308), `update_agent`(367), `delete_agent`(559), `get/update_user_profile`(506/531) | deps, deerflow.agents/memory |
| `routers/artifacts.py` | 4.8 | 工件读取/编辑（2 端点） | `get_artifact`(333), `update_artifact`(479), `_normalize_editable_artifact_path`(66) | deps, path_utils, authz, run_event_store |
| `routers/uploads.py` | 4.8 | 线程上传（4 端点） | `upload_files`(356), `get_limits`(431), `list_files`(442), `delete_file`(454), `_link_staged_no_overwrite`(245) | upload_ingestion, deps, deerflow.uploads |
| `routers/trash.py` | 4.8 | 回收站（4 端点） | `list_trash_documents`(137), `restore_document`(171), `purge_document`(208), `empty_trash`(226) | deps, deerflow.persistence/projects |
| `routers/projects.py` | 4.8 | 项目 CRUD（8 端点） | `create/list/get/patch/archive/restore/delete`(116-183), `list_project_threads`(190) | deps, authz |
| `routers/project_documents.py` | 4.8 | 项目文档（5 端点） | `list/create`(140/164), `from_thread`(267), `attach_to_thread`(335), `get_content`(410), `delete`(484) | deps, upload_ingestion, deerflow.persistence/projects |
| `routers/project_thread_files.py` | 4.8 | 项目线程文件聚合（1 端点） | `list_project_thread_files`(102) | deps, deerflow.config.paths |
| `routers/scheduled_tasks.py` | 4.8 | 定时任务（10 端点） | `preview_cron`(165), CRUD(176-252), `pause/resume/trigger`(378/409/438), `list_task_runs`(483), `resolve_scheduled_task_assistant_id`(62), `_ensure_task_mutable`(92) | deps, deerflow.persistence.scheduler |
| `routers/subagents.py` | 4.8 | 子代理定义 CRUD（4 端点） | `list_subagents`(163), `create/update/delete`(170/195/231) | deps, deerflow.subagents |
| `routers/subagent_batches.py` | 4.8 | 批次进度/控制（7 端点） | `list/get/items`(39/46/53), `pause/resume/cancel`(69/76/83), `retry_item`(95), `export_results`(105) | deps(get_subagent_batch_service) |
| `routers/mcp_tasks.py` | 4.8 | MCP 任务只读+取消（3 端点） | `list_mcp_tasks`(66), `get_mcp_task`(85), `cancel_mcp_task`(104) | deps |
| `routers/memory.py` | 4.8 | 记忆管理（9 端点） | `get_memory`(204), `reload`(250), `delete`(283), facts CRUD(305-362), `export/import`(395/409), `config/status`(435/484), `_unsupported_501`(133) | deps, deerflow.memory |
| `routers/models.py` | 4.8 | 模型列表（2 端点） | `list_models`(44), `get_model`(132) | deps, authz(resolve_model_authorization) |
| `routers/console.py` | 4.8 | 运营统计（3 端点，管理员） | `console_stats`(278), `console_runs`(349), `console_usage`(420) | deps, sqlalchemy, run 行模型 |
| `routers/browser.py` | 4.8 | 浏览器控制（2 端点） | `navigate_browser`(74), `browser_stream`(206 WS), `_authenticate_ws`(117), `_check_origin`(142) | deps, browser_capability, auth.jwt, deerflow(浏览器会话) |
| `routers/channels.py` | 4.8 | 渠道状态/重启（2 端点） | `get_channels_status`(29), `restart_channel`(41) | channels.service, deps |
| `routers/channel_connections.py` | 4.8 | IM 绑定/凭据（6 端点） | `list_providers`(514), `list/delete_connections`(544/554), `connect`(617), `runtime-config` PUT/DELETE(652/570) | channels.service/runtime_config_store, deps |
| `routers/github_webhooks.py` | 4.8 | GitHub webhook 接收（1 端点） | `receive_github_webhook`(172), `is_route_enabled`(85), `_verify_signature`(101) | github.dispatcher, channels.service, fastapi |
| `routers/assistants_compat.py` | 4.8 | useStream 兼容 stub（4 端点） | `search_assistants`(89), `get_assistant_compat`(109), graph/schemas stub(118/136) | deerflow.agents |
| `routers/features.py` | 4.8 | 特性开关面（1 端点） | `list_features`(67) | deps, browser_capability, conversation_access, run_models |
| `routers/feedback.py` | 4.8 | run 反馈（6 端点） | `upsert/get/delete_feedback`(62-170), `feedback_stats`(158) | deps, run_store |
| `routers/suggestions.py` | 4.8 | 后续问题建议（2 端点） | `suggestions_config`(86), `generate_suggestions`(98), `_parse_json_string_list`(44) | deps, deerflow(oneshot LLM) |
| `routers/input_polish.py` | 4.8 | 输入润色（1 端点） | `polish_input`(58), `_strip_wrappers`(28) | deps, deerflow(oneshot LLM) |
| `routers/integrations.py` | 4.8 | Lark 集成编排（7 端点） | `lark_status`(259), `install`(269), config/auth start/complete(287-382), `_status_to_response`(182) | deerflow.integrations.lark_cli, deps |
| `routers/user_preferences.py` | 4.8 | 用户偏好（2 端点） | `get_preferences`(41), `update_preferences`(56) | deps, deerflow.persistence |

## 5.6 app/ 其余服务模块与根（7 + 6 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| `app/__init__.py` | — | 空包标记 | — | — |
| `app/mcp_tasks/__init__.py` | 4.10 | 包门面 | McpTaskService | service |
| `app/mcp_tasks/service.py` | 4.10 | MCP 长任务服务（635 行） | `McpTaskService`(45), `submit`(89), `run_once`(217), `request_cancel`(256), `_poll_one`(506), `_notify_one`(391), `_release_after_error`(581), `_normalize_snapshot`(597), `_next_poll_at`(572) | deerflow.mcp.tasks/persistence.mcp_tasks/runtime.runs, constants |
| `app/mcp_tasks/errors.py` | 4.10 | 永久通知失败 | `PermanentNotificationError`(1) | 无 |
| `app/scheduler/__init__.py` | 4.9 | 包门面 | ScheduledTaskService | service |
| `app/scheduler/service.py` | 4.9 | 定时调度器（630 行） | `ScheduledTaskService`(28), `run_once`(56), `dispatch_task`(111), `_attempt_queued_run`(221), `_launch_queued_occurrence`(239), `handle_run_completion`(517), `start`(553), `_run_loop`(616), `_reconcile_active_state`(586) | deerflow.persistence.scheduler, runtime.runs, trace_context |
| `app/subagent_batches/__init__.py` | 4.10 | 包门面 | SubagentBatchService | service |
| `app/subagent_batches/service.py` | 4.10 | 兼容 shim（5 行） | re-export `SubagentBatchService`(3) | deerflow.subagents.batch_service（排除范围） |
| `debug.py` | 4.11 | 断点调试 REPL | `main`(63), `_setup_logging`(37) | deerflow.agents/client, prompt_toolkit |
| `sitecustomize.py` | 4.11 | Windows 事件循环策略 | （模块级副作用 :14-26） | asyncio |
| `Dockerfile` | 4.11 | 三阶段镜像构建 | builder(:11)/dev(:85)/runtime(:96) | — |
| `Makefile` | 4.11 | 工程任务入口 | dev/gateway/test/lint/migrate-rev | uv, pytest, ruff |
| `langgraph.json` | 4.11 | LangGraph Server 声明 | graphs/auth/http/checkpointer 四要素 | — |

## 5.7 packages/extension-api/（12 文件）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| `pyproject.toml` | 4.1 | 包定义（0.2.1，零依赖） | — | — |
| `deerflow_extension_api/__init__.py` | 4.1 | 聚合导出 | `__all__` 49 符号(82-133), `API_VERSION`(80) | 全部子模块 |
| `.../contracts.py` | 4.1 | 契约核心 | `HostPolicySnapshot`(31), `TaskOutcome`(52), `TaskInfo`(58), `TaskLifecycleContributor`(71), `SystemModelRequest/Result`(100/125), `MiddlewareContributor`(149), `ExtensionRuntimeDeps`(161), `ExtensionService`(171), `ExtensionRegistry`(182), `ExtensionInstall`(221), `extension`(227) | state |
| `.../assembly.py` | 4.1 | 装配描述符+指纹 | `AgentAssemblyDescriptor`(46), `fingerprint`(66), `ToolDescriptor`(24), `MiddlewareDescriptor`(34), `AgentAssemblyObserver`(116) | release, state |
| `.../placement.py` | 4.1 | 摆放语义 | `Placement`(20), `AgentScope`(43), `AgentBuildContext`(49), `MiddlewarePlacement`(59) | 无 |
| `.../provenance.py` | 4.1 | 消息溯源戳 | `ContentKind`(39), `MessageProvenance`(49), `provenance_kwargs`(56), `read_provenance`(76), `PROVENANCE_KEYS`(30) | 无 |
| `.../release.py` | 4.1 | 行为参数+规范哈希 | `canonical_json`(38), `canonical_hash`(48), `collect_release_policies`(73), `ReleasePolicyProvider`(27) | 无 |
| `.../run_evidence.py` | 4.1 | 运行证据只读面 | `RunEvidenceReader`(62), `RunStatusView`(13), `RunEventView`(26), `RunPage/RunEventPage`(44), `InvalidRunEvidenceCursor`(9) | 无 |
| `.../state.py` | 4.1 | 类型键控存储 | `ExtensionData`(10), get/get_or_init/set/remove(32-57) | 无 |
| `.../runtime_bridge.py` | 4.1 | runtime context 桥 | `EXTENSION_TASK_STORE_KEY`(16), `task_store_from_runtime`(19) | 无 |
| `.../auth.py` | 4.1 | 扩展身份 | `EXTENSION_PRINCIPAL_RESOLVER_KEY`(18), `ExtensionPrincipal`(21), `resolve_principal`(29), `require_admin`(44) | 无 |
| `.../compaction.py` | 4.1 | 压缩事件契约 | `CompactionEvent`(39), `ContextCompactionObserver`(51) | 无 |

## 5.8 scripts/（9 个根脚本 + benchmark 目录）

| 文件路径 | 所属模块 | 职责 | 关键导出 | 主要依赖 |
|---|---|---|---|---|
| `scripts/migrate_agents_to_db.py` | 4.11 | agent 文件→DB 一次性迁移 | `main`（argparse --dry-run） | deerflow.agents/persistence |
| `scripts/migrate_memory_markdown.py` | 4.11 | memory.json→Markdown 桶迁移 | `_inspect_legacy_global_json`(35), `migrate_users`(48) | deerflow.memory |
| `scripts/migrate_user_isolation.py` | 4.11 | 全局→per-user 布局迁移 | `_build_owner_map_from_db`(247) 等 | sqlite3, deerflow.config.paths |
| `scripts/record_gateway.py` | 4.11 | 浏览器录制网关 | `_RecordingHandler`(35 族), `main` | deerflow.models.factory(patch), uvicorn |
| `scripts/run_replay_gateway.py` | 4.11 | 密闭回放网关 | `main` | ReplayChatModel(tests), uvicorn |
| `scripts/build_fixture_from_jsonl.py` | 4.11 | 录制→fixture 缝合 | `main`（--jsonl --meta --out） | 无 |
| `scripts/e2e_safety_termination_demo.py` | 4.11 | 安全终止中间件验证 | `_ContentFilteredFakeModel`(32), `main`(85) | deerflow.client/middleware(patch) |
| `scripts/manual_task_continuity_check.py` | 4.11 | 任务连续性受控检查 | `run`(35) | deerflow 中间件/工具 |
| `scripts/_autogen_revision.py` | 4.11 | Alembic autogen 底层 | `main`(78) | alembic, sqlalchemy |
| `scripts/benchmark/checkpoint/`（6 文件） | 4.11 | 检查点性能基准 | bench_production/bench_channels/公共基建/汇总 | harness 运行时 |
| `scripts/benchmark/concurrency/`（2 文件） | 4.11 | 多进程并发基准 | run_concurrency_bench/worker | sqlalchemy |
| `scripts/benchmark/context_snapshot/`（7 py+config） | 4.11 | 上下文快照评测 | runner/cases/grading/report/__main__ | harness |
| `scripts/benchmark/deermem_eviction/`（17 py+配置） | 4.11 | 记忆驱逐评测 | cli/dataset/policy/qa/report 等 | deerflow.memory |
| `scripts/benchmark/sandbox/`（2 文件） | 4.11 | 沙箱基准 | bench_provider/summarize | deerflow.sandbox |
| `scripts/benchmark/skill_export.py` | 4.11 | 技能导出基准 | main | deerflow.skills |

**清单统计**：app 包 121 个生产 py + extension-api 11 个 py（+pyproject/py.typed）+ 根 4 个（debug/sitecustomize + Dockerfile/Makefile/langgraph.json/pyproject.toml）+ scripts 9 个根脚本 + benchmark 36 个文件（目录粒度概述）。**未纳入**（依排除规则）：`packages/harness/**`（任务指定）、`tests/**`、`docs/**`、`extension_test_fixtures/**`（测试夹具）、`samples/**`（示例）、`app/channels/AGENTS.md`、`app/gateway/AGENTS.md`、`app/gateway/auth/AGENTS.md`（纯文档）、`uv.lock`、`.vscode/`、`ruff.toml`、`.python-version`、`.test_durations`、`.gitignore`。


---

# 第 6 章 关键函数深度解析

> 覆盖核心业务链路的 8 个关键函数，每个给出带行号的代码片段与逐段解读。

## 6.1 `services.start_run` — run 的唯一准入函数（`app/gateway/services.py:1459`）

```python
# services.py:1481-1488
# Cancel-capability gate. interrupt/rollback strategies terminate an already
# active run — runs:cancel capability, not runs:create — so a create-only
# PAT must not reach them. Enforced here, the single choke point every
# run-creation path flows through (HTTP routes and internal launchers
# alike), so no entry point can bypass it; ...
require_cancel_permission_if(request, body.multitask_strategy != "reject")
```
**解读**：第一道闸是「取消能力门」。`multitask_strategy` 为 interrupt/rollback（即非 reject）意味着新 run 可以打断已有 run——这属于 `runs:cancel` 能力而非 `runs:create`，因此只持有 create 权限的 PAT 不能到达。注释强调这里是**所有 run 创建路径（HTTP 路由与内部启动器）的唯一咽喉点**，任何入口都无法绕过；regenerate 走 reject 策略故不受影响。

```python
# services.py:1516-1524
if model_name:
    app_config = get_app_config()
    resolved = app_config.get_model_config(model_name)
    if resolved is None:
        raise HTTPException(status_code=400,
            detail=f"Model {model_name!r} is not in the configured model allowlist")
```
**解读**：模型白名单。客户端传入的 `context.model_name` 必须存在于 config.yaml 的 `models:` 配置，防止任意模型 ID 透传到 provider（计费与越权防护）。

```python
# services.py:1526-1538（节选注释）
owner_user_id = get_trusted_internal_owner_user_id(request)
# Stateless run endpoints carry thread_id in the request *body*, so the
# @require_permission(owner_check=True) decorator -- which resolves ownership
# from the path param -- cannot protect them. Enforce thread ownership here,
# before any run is created, ... only a thread already owned by another user
# is rejected with 404, matching thread_runs.py's anti-enumeration behaviour.
# Internal channel runs act on behalf of the connection owner carried in
# X-DeerFlow-Owner-User-Id, so they are scoped to that owner instead of
# bypassing the check -- a leaked internal token must not grant cross-user
# thread access.
```
**解读**：属主核查下沉的原因——无状态端点（`/api/runs/*`）的 thread_id 在 body 中，装饰器无法从路径参数解析属主。设计细节：他人线程返回 404（防枚举，与 thread_runs 一致）；内部渠道 run 以 `X-DeerFlow-Owner-User-Id` 携带的连接属主为作用域**而非绕过检查**——泄漏的内部 token 不得授予跨用户线程访问。

```python
# services.py:1729-1758
try:
    async with goal_thread_lock(thread_id):
        await ensure_checkpoint_history_seeded(
            request, thread_id=thread_id, assistant_id=body.assistant_id)
        # ...（删除竞态复查注释：delete 路由持有 durable 预约，
        #  此点之后 run 与 delete 只能其一成功，跨 worker 成立）
        if require_existing_thread and not await thread_access_allowed():
            raise HTTPException(status_code=404, detail=f"Thread {thread_id} not found")
        record = await run_mgr.create_or_reject(
            thread_id, body.assistant_id,
            on_disconnect=disconnect, metadata=run_metadata,
            # Persist a secret-redacted copy of the config: the run record is
            # written to runs.kwargs_json and echoed by the run API, so a
            # request-scoped secret (#3861) must not ride along. ...
            kwargs={"input": body.input,
                    "config": redact_config_secrets(body.config), ...},
            multitask_strategy=body.multitask_strategy,
            model_name=model_name, user_id=owner_user_id,
            idempotency_key=idempotency_key)
```
**解读**：durable 准入段。①`goal_thread_lock`（进程内 goal 级互斥）包裹 checkpoint 播种与 run 落库；②二次属主复查防「检查后线程被并发删除」竞态——删除路由持有 `reserve_thread_operation(kind=delete)` 的 durable 预约，因此跨 worker 场景下 run 与 delete 也只能其一成功；③`create_or_reject` 是持久化准入（幂等键冲突/活动 run 冲突在此拒绝）；④落库的 config 是**脱敏副本**（`redact_config_secrets`，issue #3861：run 记录会经 API 回显，请求级秘密不得随行），真正执行用的 live config 保留秘密。

```python
# services.py:1769-1783
worker = run_after_metadata(record)
try:
    # No await is allowed between durable admission and task
    # attachment. Metadata setup runs inside the attached
    # worker so a pending cancellation can bypass stalled
    # thread-store IO and still reach run_agent's startup
    # barrier / stream finalization.
    record.task = asyncio.create_task(worker)
except Exception as exc:
    worker.close()
    await run_mgr.fail_start_if_pending(record.run_id,
        error=f"Failed to attach run worker: {exc}")
    raise
```
**解读**：**「durable 准入与 task 挂载之间零 await」**是本函数最关键的工程约束——若两者之间进程崩溃，run 行已存在但 task 未挂载，启动时的孤儿回收（`deps._terminalize_recovered_runs` :329）会把它终结为错误；若反过来先挂载后落库，则可能出现无记录的幽灵 run。元数据准备（`_ensure_thread_metadata`）被移进 worker 内部执行，使 pending 取消能绕过可能卡住的 thread-store IO 直达 `run_agent` 的启动屏障。create_task 失败时同步把 run 标记失败，不留 pending 悬挂行。

## 6.2 `services.format_sse` 与 `sse_consumer` — SSE 帧与流消费（`services.py:156/1954`）

```python
# services.py:156-169
def format_sse(event: str, data: Any, *, event_id: str | None = None) -> str:
    """Format a single SSE frame.
    Field order: ``event:`` -> ``data:`` -> ``id:`` (optional) -> blank line.
    This matches the LangGraph Platform wire format consumed by the
    ``useStream`` React hook and the Python ``langgraph-sdk`` SSE decoder.
    """
    payload = json.dumps(data, default=str, ensure_ascii=False)
    parts = [f"event: {event}", f"data: {payload}"]
    if event_id:
        parts.append(f"id: {event_id}")
    parts.append("")
    parts.append("")
    return "\n".join(parts)
```
**解读**：帧格式与 LangGraph Platform 完全一致（`event:`→`data:`→可选 `id:`→空行），这是前端 useStream / langgraph-sdk 解码器的契约。`ensure_ascii=False` 保证中文原样传输；`default=str` 容忍不可序列化对象降级为字符串而非 500。

`sse_consumer`（:1954）核心逻辑（依据源码结构归纳）：订阅 `bridge.subscribe(run_id, last_event_id)` → 循环 `format_sse` yield；`Last-Event-ID` 请求头实现断线续传（:1984）；`StreamGap`（内存桥丢失事件，如跨进程切换）转 `event: gap` 帧并附 `reload_durable_state` 指引（:2010-2023）——客户端据此重载持久状态而不是拿到残缺流；心跳哨兵输出注释帧 `: heartbeat` 保持连接并检查孤儿 run 是否可合成 end（:2025-2029）；`END_SENTINEL` → `event: end`（:2032-2034）；`finally` 块仅在「创建者流 + on_disconnect=cancel」时调用 `run_mgr.cancel`（:2038-2046）——join/观察流传入 `apply_on_disconnect=False`，断开不取消创建者的 run。

## 6.3 `ChannelManager._handle_chat_on_thread` — 渠道消息→agent run（`app/channels/manager.py:2419`）

```python
# manager.py:2431-2438
assistant_id, run_config, run_context = self._resolve_run_params(msg, thread_id)
# Apply per-channel policy: credentials provider (e.g. GitHub
# installation-token mint) and the non-interactive flag for
# webhook channels. Driven by CHANNEL_RUN_POLICY so each new
# webhook channel is a one-row registration, not a fresh
# if-branch here.
policy = await self._apply_channel_policy(msg, run_context)
```
**解读**：策略模式的落点——新增 webhook 渠道只需在 `CHANNEL_RUN_POLICY` 注册一行（如 github 的 fire_and_forget + credentials_provider），不需要在本函数加 if 分支。`_apply_channel_policy` 内部执行凭证注入（GitHub installation token 写入 `run_context["github_token"]`）与 `disable_clarification`（非交互渠道关闭澄清中断，否则 ask_clarification 会永久挂起）。

```python
# manager.py:2444-2456
if msg.files:
    from .service import get_channel_service
    service = get_channel_service()
    channel = service.get_channel(msg.channel_name) if service else None
    logger.info("[Manager] preparing receive file context for %d attachments", len(msg.files))
    msg = await channel.receive_file(msg, thread_id, user_id=storage_user_id) if channel else msg
...
original_text = msg.text
uploaded = await _ingest_inbound_files(thread_id, msg, user_id=storage_user_id)
human_message = _human_input_message(msg.text, original_content=original_text, files=uploaded or None)
```
**解读**：附件两段式摄取。第一段 `receive_file` 由**渠道自己**下载附件（各渠道 API 不同：飞书 file_key、钉钉 downloadCode、Telegram 内联字节）并把沙箱路径写回 `msg.text`；第二段 `_ingest_inbound_files`（:1085）由 manager 统一把文件写入线程 uploads 目录（Telegram 的 `INBOUND_FILE_CONTENT_KEY` 内联字节优先，:1096-1134）。延迟导入 `get_channel_service` 规避循环依赖。

```python
# manager.py:2458-2476（节选）
if self._channel_supports_streaming(msg.channel_name):
    await self._handle_streaming_chat(client, msg, thread_id, assistant_id,
        run_config, run_context, human_message, storage_user_id=storage_user_id)
    return
run_kwargs: dict[str, Any] = {
    "input": {"messages": [human_message]},
    "config": run_config, "context": run_context,
    "multitask_strategy": "reject",
}
if owner_headers := _owner_headers(msg):
    run_kwargs["headers"] = owner_headers
```
**解读**：执行三分支的前两支——流式渠道走 `_handle_streaming_chat`（runs.stream，1s/60 字符节流推送进度），否则构造 run kwargs。注意 `multitask_strategy: "reject"`：IM 渠道不抢已有 run，忙时走 follow-up 缓冲或 busy 提示；`_owner_headers`（:942）把连接属主作为内部信任头传给 Gateway，使 run 以正确用户身份落资源桶。

```python
# manager.py:2480-2493（fire_and_forget 注释节选）
# Fire-and-forget path: the channel does its own outbound
# during the run (GitHub agents post to the issue/PR via the
# ``gh`` CLI from inside the sandbox), so there is nothing
# for the manager to ferry back. Use ``runs.create`` — a
# short POST that returns once the run is ``pending`` — to
# avoid the SDK's 300s ``httpx.ReadTimeout`` on legitimately
# long autonomous runs, and the false "internal error"
# outbound that follows when it fires.
```
**解读**：第三分支 fire_and_forget（GitHub 专用）。`runs.wait` 会让 SDK 长连接等待完成，超 300 秒触发 httpx.ReadTimeout 并误报 internal error；`runs.create` 是短 POST，run 落 pending 即返回，GitHub agent 在沙箱内自行用 `gh` CLI 回帖。ConflictError 仍会同步抛出（忙线程路径保留，配合 `buffer_followups_on_busy` 缓冲后续投递）。

## 6.4 `ScheduledTaskService.run_once` — 调度循环单轮（`app/scheduler/service.py:56`）

```python
# scheduler/service.py:56-79
async def run_once(self, *, now: datetime) -> None:
    if self._multi_instance:
        if self._skip_next_lease_reconciliation:
            self._skip_next_lease_reconciliation = False
        else:
            await self._reconcile_active_state(now=now)
    else:
        await self._task_run_repo.recover_expired_launch_claims(
            error=_LEASE_RECOVERY_ERROR, now=now)
    await self._expire_waiting_runs(now=now)
    await self._drain_queue(now=now)
    # Admission and execution capacity are separate. Due occurrences are
    # persisted even when all execution slots are busy; claim_queued_run()
    # applies the global launch budget under the database lock.
    claimed = await self._task_repo.claim_due_tasks(
        now=now, lease_owner=self._lease_owner,
        lease_seconds=self._lease_seconds,
        limit=self._max_concurrent_runs)
    for task in claimed:
        await self.dispatch_task(task, now=now, trigger="scheduled")
```
**解读**：五步结构逐段——①恢复步分两型：多实例走租约宽限期对账（`_reconcile_active_state`，属主仍续租的行不动；首轮被 skip 标志跳过避免与启动恢复重复），单实例走过期 launch claim 回收（上一进程崩溃遗留的"已认领未启动"行标错释放）；②排队超时过期（默认 1h）；③排空队列（queued 行逐条尝试启动）；④**到期扫描与原子租约抢占**——`claim_due_tasks` 一次 UPDATE 抢占（lease_owner+lease_seconds），返回本批任务；注释阐明核心设计「**准入与执行容量分离**」：到期 occurrence 即使执行槽满也持久化为 queued 行（不丢失），全局启动预算延后在 `claim_queued_run()` 的 DB 锁下施加；⑤逐个 dispatch。配合 `_run_loop`（:616）的「异常只记日志不退出」（SQLite 偶发 database is locked 不杀死 poller），构成可自愈的调度循环。

## 6.5 `McpTaskService._release_after_error` — 指数退避释放（`app/mcp_tasks/service.py:581`）

```python
# mcp_tasks/service.py:581-595
async def _release_after_error(self, record: dict, *, now: datetime, error: str) -> None:
    consecutive_errors = max(0, int(record.get("consecutive_poll_error_count") or 0))
    retry_seconds = min(
        self._poll_interval_seconds * (2 ** min(consecutive_errors, 16)),
        self._max_poll_backoff_seconds,
    )
    bounded_error = _bound_error(error)
    assert bounded_error is not None
    await self._repository.release_claim(
        record["id"],
        lease_owner=self._lease_owner,
        next_poll_at=now + timedelta(seconds=retry_seconds),
        error=bounded_error,
        tracking_degraded_after_errors=self._tracking_degraded_after_errors,
    )
```
**解读**：标准指数退避 `interval × 2^min(errors,16)`（2^16 已是 65536 倍，封顶防溢出）再被 `max_poll_backoff_seconds=300` 钳制。`release_claim` 以 `lease_owner` 为条件释放（只释放自己持有的租约，防误放他实例的租约）并把 `next_poll_at` 写到退避时刻——失败不是重试队列而是「推迟下一轮到期」。错误文本经 `_bound_error` 截 4000 字符防 DB 膨胀。同一公式被取消重试（:343-344）与通知重试（:499-504）复用，是全服务的统一重试纪律。

## 6.6 `AuthMiddleware.dispatch` — 认证优先级链（`app/gateway/auth_middleware.py:90`）

依据源码结构（:90-199）：公开路径放行（:60-64 + :34-48 两张表）→ ①内部 token 头：`is_valid_internal_auth_token` 常数时间比对（:95-116，合成 internal 用户并携带 owner 头）→ ②**Bearer PAT 存在即严格**：`extract_bearer_token` 返回 None（无头，继续走 cookie）或字符串（有头则 `authenticate_pat`；**任何失败直接 401，绝不回落 cookie**——:117-142，防止用 PAT 探测 + CSRF 中间件的 Bearer 旁路交互）；成功后还要过 `is_pat_allowed_route`（default-deny 路由白名单，白名单外 403）→ ③access_token cookie：`get_current_user_from_request`（JWT 解码→DB 查用户→token_version 比对，任一失败 401 且错误码区分 expired/invalid 供前端引导重新登录）→ ④auth-disabled 合成用户 → ⑤无凭证 401。成功路径：`resolve_route_permissions` 预算 9 项权限（PAT 时与 scopes 交集**只收窄**，:184-193），构建 `AuthContext` 写 `request.state.auth`，`set_current_user` ContextVar 包裹 `call_next` 并 finally 复位（:195-199）——ContextVar 保证后台任务/日志能取到当前用户，finally 保证请求结束不泄漏。

## 6.7 `github_webhooks._verify_signature` + `fanout_event` — webhook 验签与扇出

验签（`routers/github_webhooks.py:101-113`）：`hmac.new(secret, body, sha256).hexdigest()` 与 `X-Hub-Signature-256` 头（`sha256=<hex>`）经 `hmac.compare_digest` 常数时间比较——防时序侧信道逐字节猜测签名。流程铁律 **verify-then-parse**（:257-259）：先对原始字节验签再 json.loads，防未签名大载荷 DoS 解析。运行期 secret 被清空且未开 dev 逃生门 → 503 拒收（:222-238）；channel 未启用 → 200+skipped（永久状态，重投无意义，:300-319）；fan-out 瞬时异常 → 显式 503（:351-368）——让 GitHub Recent Deliveries 标记失败供手动 Redeliver，这是对 webhook 语义的精确区分（暂时性失败要重投、永久性失败不要）。

`fanout_event`（`github/dispatcher.py:188`）五步（详见 4.4.2）：目标提取 → 注册表索引查找（`asyncio.to_thread` + 签名缓存）→ 逐 agent 三道门（self-event/触发门控/冗余评论）→ 构造 InboundMessage（owner_user_id=agent 属主、确定性 preferred_thread_id=uuid5、metadata.github 携带 installation_id）→ `bus.publish_inbound`。**身份设计**：GitHub 触发者只记为消息 user_id，资源归属取 agent 属主——webhook 渠道不走交互渠道的 per-sender 绑定表（`run_policy.py:120` requires_bound_identity=False）。

## 6.8 `MessageBus.reserve_inbound` — 预约制背压（`app/channels/message_bus.py:219`）

依据源码结构（:219-247）：SDK 回调线程调用时以 `threading.Lock` 保护统计（queued + reservations）对抗 maxsize；满载返回 None（调用方 `_reserve_inbound` 立即丢弃并记日志，**绝不等待**——IM 消息宁可丢不可阻塞 SDK 回调线程，渠道侧用「Working on it...」已回但不处理的用户体验换取系统稳定）；限频告警防日志风暴。两阶段提交：`reserve`（占位）→ 渠道完成身份附着等异步准备后 `commit`（真正入队）或超时 `release`。这解决了「SDK 线程回调 → 主循环协程」跨线程窗口内的容量精确记账问题。


---

# 第 7 章 端到端调用链分析

## 7.1 场景一：前端流式对话（POST /api/threads/{tid}/runs/stream）

```
浏览器 (useStream hook)
  │  POST /api/threads/{tid}/runs/stream  (Cookie: access_token, csrf_token; Header: x-csrf-token)
  ▼
TraceMiddleware.__call__ (trace_middleware.py:45)          ── 绑定 trace ContextVar
  ▼
CORSMiddleware (app.py:827)                                ── GATEWAY_CORS_ORIGINS 非空时
  ▼
CSRFMiddleware.dispatch (csrf_middleware.py:221)
  └─ should_check_csrf(:40)=True → cookie/header 常数时间比对(:230-252)；失败 403
  ▼
AuthMiddleware.dispatch (auth_middleware.py:90)
  ├─ get_current_user_from_request (deps.py:814)
  │    ├─ decode_token (auth/jwt.py:40)        ── HS256 解码，区分 EXPIRED/INVALID
  │    ├─ LocalAuthProvider.get_user (auth/local_provider.py:61)  ── 查 users 表
  │    └─ token_version 比对 (deps.py:857-861) ── 改密吊销旧 token
  └─ resolve_route_permissions (authz.py:229)  ── 9 项权限并行评估 → AuthContext
  ▼
stream_run (routers/thread_runs.py:941)
  └─ @require_permission("runs","create",owner_check=True) (authz.py:595)
       └─ ThreadMetaStore.check_access (authz.py:694)      ── 他人线程 404 防枚举
  ▼
services.start_run (services.py:1459)                      ── 详见 6.1
  ├─ require_cancel_permission_if (:1488)
  ├─ thread_access_allowed (:1541-1563)
  ├─ normalize_input (:1573) / build_run_config (:1585)
  ├─ inject_authenticated_user_context (:1598)
  ├─ prepare_conversation_reader (:1605, conversation_access.py:138)
  ├─ goal_thread_lock → ensure_checkpoint_history_seeded (:1731)
  ├─ run_mgr.create_or_reject (:1744)                      ── durable 落库（幂等）
  └─ record.task = asyncio.create_task(run_after_metadata) (:1776)  ── 零 await 挂载
       └─ (后台) run_after_metadata (:1651)
            ├─ _ensure_thread_metadata (:198)              ── 5s 有界
            └─ deerflow.runtime.run_agent (:1715)          ── LangGraph 图执行
                 ├─ 9 层中间件链（harness，排除范围）
                 ├─ 工具调用（沙箱/MCP/技能）
                 └─ 事件 → StreamBridge + run_event_store 持久化
  ▼（HTTP 侧同步返回）
StreamingResponse(sse_consumer(...)) (thread_runs.py:941 → services.py:1954)
  ├─ Content-Location: /api/threads/{tid}/runs/{rid} (thread_runs.py:984-992)
  ├─ bridge.subscribe(run_id, last_event_id)
  │    事件 → format_sse (:156) yield
  │    StreamGap → event:gap + reload_durable_state 指引 (:2010-2023)
  │    心跳哨兵 → ": heartbeat" 注释帧 (:2025-2029)
  │    END_SENTINEL → event:end (:2032-2034)
  └─ finally: on_disconnect=cancel 时 run_mgr.cancel (:2038-2046)
  ▼
读取历史：GET /api/threads/{tid}/messages (thread_runs.py:1361)
  └─ read_visible_message_page (conversation_reader.py:21) ── 隐藏被重生成/回放的 run
```

时序要点：**durable 落库（第 5 步 create_or_reject）先于 SSE 响应开始**——客户端收到首字节时 run 已持久化，断线重连（Last-Event-ID）或换端 join（GET /runs/{rid}/stream）都有据可依。

## 7.2 场景二：Slack DM 触发 agent（渠道链路）

```
Slack 服务器 ──WebSocket──▶ SocketModeClient（SDK 专有线程）
  ▼
SlackChannel._on_socket_event (slack.py:293)     ── ACK envelope、解析 events_api
  ▼
_handle_message_event (slack.py:325)
  ├─ 过滤 bot 消息 → 剥离提及 (_strip_leading_slack_bot_mention :68)
  ├─ /connect 先于 allowed_users 门 (base.py:274-285 框架规则)
  ├─ thread_ts → topic_id (:369-385)
  └─ eyes 反应 + "Working on it..." (:392-394)
  ▼
_reserve_inbound (base.py:310) → MessageBus.reserve_inbound (message_bus.py:219)   ── 预约制背压
  ▼
_submit_threadsafe_coroutine (base.py:160)       ── SDK 线程 → Gateway 主事件循环
  └─ _publish_inbound_with_connection (slack.py:414)
       ├─ attach_connection_identity (connection_identity.py:10)  ── 查连接库回填 owner
       └─ _commit_reserved_inbound (base.py:326) → bus 入队
  ▼
ChannelManager._worker_loop (manager.py:1922)    ── 固定 worker 池（并发 5）
  ├─ _is_duplicate_inbound (:2021)               ── 四元组去重（TTL 10min）
  └─ _handle_message (:2060)
       ├─ _get_bound_identity_rejection (:2107)  ── 重读 connection repo 核对身份
       └─ _handle_chat (:2359)                   ── per-thread 锁 → 排队提示
            ▼
_handle_chat_on_thread (:2419)                   ── 详见 6.3
  ├─ _get_or_create_thread (:2317)               ── ChannelStore 查/建 LangGraph thread
  ├─ _resolve_run_params (:1610) + _apply_channel_policy (:1718)
  └─ langgraph_sdk client.runs.wait/stream/create (:2523/:2608/:2503)
       │   （HTTP 回打本进程，携带 X-DeerFlow-Internal-Token + owner 头）
       ▼
     services.start_run（同场景一第 5 步起）──▶ run_agent ──▶ StreamBridge
  ▼
bus.publish_outbound (message_bus.py:346)
  ▼
Channel._on_outbound (base.py:352)               ── 按 channel_name 过滤
  ▼
SlackChannel.send (slack.py:157)                 ── mrkdwn 转换 + ✅ 反应
  └─ send_file (:202)                            ── files_upload_v2 依次上传附件
```

## 7.3 场景三：GitHub PR 评论触发 agent（webhook 链路）

```
GitHub ──POST /api/webhooks/github──▶ receive_github_webhook (routers/github_webhooks.py:172)
  ├─ _verify_signature (:101)                    ── HMAC-SHA256 常数时间（verify-then-parse）
  ├─ is_channel_enabled("github") (:300)         ── 未启用 200+skipped
  └─ fanout_event (github/dispatcher.py:188)
       ├─ extract_target (identity.py:62)        ── (repo, number)
       ├─ asyncio.to_thread(build_github_agent_registry) (registry.py:102)  ── 签名缓存索引
       ├─ lookup_agents (:137)                   ── (repo, event) → agent 列表
       └─ 逐 agent：
            ├─ _is_self_event (:41)              ── 过滤自己的 bot 消息
            ├─ event_should_fire (triggers.py:150)  ── actions/作者/@提及 三道门
            ├─ build_prompt (prompts.py:211)     ── 描述式提示词
            ├─ resolve_thread_id (identity.py:29)   ── uuid5 确定性线程
            └─ bus.publish_inbound(InboundMessage{owner_user_id=agent属主,
                 metadata{agent_name, github{installation_id}, preferred_thread_id}})
  ▼（异步，非 webhook 请求内——保障 GitHub 10s 投递超时）
ChannelManager worker（同场景二 worker 以下）
  ├─ _resolve_run_params：agent_name ← metadata；recursion_limit=250
  └─ _apply_channel_policy → inject_github_credentials (github/run_policy.py:25)
       └─ mint_installation_token (app_auth.py:169)
            ├─ 缓存命中（双检锁，leeway 提前 5min 刷新）
            └─ miss → mint_app_jwt(RS256, :117) → POST /app/installations/{id}/access_tokens (:138)
  ▼
runs.create（fire_and_forget, manager.py:2503）──▶ services.start_run ──▶ run_agent
  └─ agent 在沙箱内用 gh CLI + github_token 回帖；GitHubChannel.send 仅记日志（github.py:85）
```

## 7.4 场景四：定时任务触发（scheduler 链路）

```
ScheduledTaskService._run_loop (scheduler/service.py:616)   ── 每 poll_interval 秒
  ▼ run_once (:56)                                            ── 详见 6.4
  ├─ claim_due_tasks（DB 原子租约抢占）
  ▼ dispatch_task (:111)
  ├─ expected_lease_owner 复核 → 生成/复用 thread_id
  ├─ task_run_repo.create(coordinate_with_task=True)          ── 乐观锁插 queued 行
  ▼ _attempt_queued_run (:221) → _launch_queued_occurrence (:239)
  ├─ claim_queued_run(global_max_concurrent_runs)             ── 全局并发预算（DB 锁下）
  ├─ launch_run = launch_scheduled_thread_run (services.py:1799)
  │    ├─ 合成 internal request + non_interactive context
  │    ├─ 幂等键 scheduled-task:{run_id}
  │    └─ services.start_run（require_existing_thread=True）──▶ run_agent
  └─ update_status("running", protect_terminal=True) (:293-306)
  ▼（run 结束）
handle_run_completion (:517)                                  ── run metadata 回写 success/failed/interrupted
```

---

# 第 8 章 横切机制说明

## 8.1 错误处理与异常体系

- **HTTP 层**：类型化错误模型贯穿——auth 用 `AuthErrorCode/TokenError` 枚举 + `AuthErrorResponse`（`auth/errors.py:13-46`）；业务异常映射为 FastAPI HTTPException，语义化状态码纪律：404 防枚举（他人资源）、409 冲突/幂等不一致、412 乐观并发失败、429 限流、501 后端不支持、503 依赖不可用/可重试 webhook 失败。
- **渠道层**：`_send_error` 统一回复用户可见错误（`manager.py:2060` 内）；`_send_with_retry` 指数退避（`base.py:106`）；去重存储 fail-open（`dedupe_store.py:180-185`）vs 身份核查 fail-closed（`manager.py:2014-2018`）——按「丢消息 vs 重复处理」的代价分别取舍。
- **后台服务**：`scheduler._run_loop` 异常只记日志不退出（:621-623）；`mcp_tasks` 区分 `McpTaskProtocolError`（永久→FAILED）与一般异常（退避重试），通知失败 5 次进死信（`PermanentNotificationError`）。
- **run 层**：孤儿 run 启动回收（`deps._terminalize_recovered_runs` :329）；`run_after_metadata` 的元数据失败有界中止但仍推进到 `run_agent` 启动屏障（`services.py:1706-1714` 注释——pending 取消的单一路径）。

## 8.2 日志体系

`configure_logging` 在 lifespan 启动（`app.py:295`，实现于 harness）；网关层的纪律：`sanitize_log_param`（`utils.py:4`）防日志注入；**秘密不进日志**——下载 URL 含 token 绝不外泄（`telegram.py:489-513`）、CDN URL 防泄漏（`wechat.py:131`）、run 落库 config 脱敏（`services.py:1753`）。trace：`TraceMiddleware` 每请求生成/传播 trace id 并写回 `X-Trace-Id`（`trace_middleware.py:45-60`）；渠道消息与 scheduled 启动各自 `ensure_trace_context` 独立作用域（`manager.py:1939`、`scheduler/service.py:230-235`、`services.py:1855`）。Monocle 追踪可选启用（`app.py:317-320`，失败不阻断）。

## 8.3 配置管理（多环境）

四层配置：①进程绑定 env（`gateway/config.py`）；②业务 `config.yaml`（mtime 热加载，`startup-only:` 字段绑启动快照，`deps.py:359-368`）；③`extensions_config.json`（MCP/技能，双锁读改写+热重载，`mcp.py:1174-1236`）；④环境变量安全开关（AUTH_JWT_SECRET、DEER_FLOW_AUTH_DISABLED、GATEWAY_WORKERS 等）。环境判定：`DEER_FLOW_ENV/ENVIRONMENT=prod|production`（`auth_disabled.py:20-27`）；多 worker 强制 Postgres（`deps.py:58`）；`.env` 经 dotenv 加载（`auth/config.py`）。

## 8.4 权限/安全控制

集中机制（详见 4.3）：认证优先级链（internal>PAT>cookie>auth-disabled）+ RBAC 9 权限 + 属主核查（404 防枚举）+ PAT 路由 default-deny + scope 交集收窄；CSRF 双提交 + 登录端点 Origin 校验 + WS Origin 校验 + GET-action 拒绝；密码 bcrypt v2（sha256 预哈希）；改密 token_version 全量吊销；OIDC issuer pinning/算法白名单/nonce 常数时间/不自动接管本地账户；webhook HMAC 验签 + 路由 fail-closed 挂载；上传/工件路径逃逸防护（normpath 前缀检查+lstat+resolved 双重校验）；stdio MCP 命令 allowlist + 代码注入 env 黑名单；出站 artifact 仅 outputs 目录；入站媒体主机白名单与大小上限；AI 消息类型白名单防隐藏上下文泄漏到 IM（`manager.py:771-784`）。

## 8.5 并发/异步处理模式

- **事件循环纪律**：阻塞文件/DB IO 一律 `asyncio.to_thread`/`run_file_io` 下放（artifacts 哈希、skills 安装、上传、registry 构建）；bcrypt 验证也走 to_thread（`auth/password.py:66-82`）；测试用 blockbuster 强制检测阻塞 IO（`pyproject.toml:60` dev 组）。
- **跨线程桥接**：渠道 SDK 专有线程 → 主循环的 `_submit_threadsafe_coroutine`（`base.py:160`）；Discord/Telegram 独立事件循环经 `run_coroutine_threadsafe` 桥接（`discord.py:296`、`telegram.py:556`）。
- **锁体系**（按粒度）：进程内 `goal_thread_lock`（run 准入）、`AsyncKeyedLockTable`（thread 创建去重）、per-thread 序列化锁（渠道聊天）、`reserve_thread_operation`（durable 线程操作互斥：delete/branch/artifact_write/artifact_archive）、`reserve_checkpoint_write`（goal/compact/state 写）、DB 租约（scheduler/mcp_tasks/subagent_batches 跨实例）、文件锁（extensions_config.json 跨进程）、信号量（技能导出 2、工件归档 4）。
- **后台任务**：channel worker 固定协程池（不 per-message 建任务，`manager.py:1922`）；follow-up watcher、buzz 重连循环、feishu 卡片任务集等全部强引用跟踪 + stop() 有界取消。
- **零 await 窗口**：run durable 准入与 task 挂载之间（`services.py:1770-1776`）。

## 8.6 缓存

热配置 mtime 缓存（harness）；GitHub 注册表签名缓存（`registry.py:121-126`）；installation token 进程内缓存+双检锁（`app_auth.py:208-219`）；JWKS/metadata 300s（`oidc.py:79`）；artifacts SHA-256 ETag LRU（`artifacts.py:307-330`）；setup-status 60s TTL+in-flight 去重（`routers/auth.py:710-775`）；MCP 工具缓存（写后 reset，`mcp.py:1417`）；agent 图编译缓存（`services.py:1031-1103`）；技能提示词缓存（按用户刷新）；tiktoken 启动预热（`app.py:351-368`）。

## 8.7 定时任务

`ScheduledTaskService`（详见 4.9）：interval/cron/once；三层防重（调度租约/活动槽/全局预算 DB 锁）；单实例破坏性恢复 vs 多实例租约宽限恢复；排队超时 1h 过期；手动触发不受 paused 抑制。MCP 任务轮询与通知子状态机见 4.10.1。无独立 cron 框架——全部自研 asyncio 轮询循环 + DB 租约。

## 8.8 持久化与迁移

SQLAlchemy 异步引擎 + Alembic；启动自动 `alembic upgrade head`（`Makefile:63-69` 注释：单一执行路径防运维失误）；users/threads_meta/runs/run_events/feedback/projects/scheduled_tasks/mcp_tasks/subagent_batches 同库；LangGraph checkpointer 由 harness 提供（`langgraph.json:17-19`）；文件系统状态：`{DEER_FLOW_HOME}/channels/*.json`（渠道）、uploads/outputs（线程）、skills、`.jwt_secret`。

---

# 第 9 章 外部依赖说明

> 仅列直接依赖（`pyproject.toml:7-42`）；`deerflow-harness` 为工作区包（排除范围），此处按外部依赖对待。

| 依赖 | 用途 | 在哪些文件中使用 | 替代/关键实现 |
|---|---|---|---|
| `fastapi` / `starlette` / `uvicorn` | Web 框架与服务器 | app.py、全部 routers、中间件 | starlette 被钉 `<2`：`request_path.py:9` 用私有 `get_route_path`，升级是安全敏感变更（pyproject:20-28） |
| `langgraph-sdk` | 渠道管理器以客户端身份回打自身 API | channels/manager.py（runs.wait/stream/create、ConflictError）、langgraph_auth.py | 服务自身即 LangGraph 兼容 API，SDK 是「回环客户端」 |
| `deerflow-harness`（workspace） | agent 运行时全部：run_agent/RunManager/StreamBridge/checkpointer/配置/路径/持久化引擎/中间件链/工具 | services、deps、channels、routers 广泛 import deerflow.* | 排除范围；langgraph.json 的 graphs/checkpointer 也指向它 |
| `deerflow-extension-api`（workspace） | 扩展公共契约 | app.py（principal resolver）+ harness | 见 4.1 |
| `httpx` | OIDC 发现/交换、GitHub API、渠道管理器网关调用、goal 命令 | auth/oidc.py、github/app_auth.py、channels/manager.py | — |
| `pydantic` | 全部请求/响应/配置模型 | 贯穿 | BaseModel + ConfigDict + strict 模式（run_models extra=forbid） |
| `pyjwt` | HS256 会话 JWT、RS256 GitHub App JWT、OIDC ID token 验签 | auth/jwt.py、github/app_auth.py、auth/oidc.py | — |
| `bcrypt` | 密码哈希（v2 = bcrypt(sha256 预哈希)） | auth/password.py、local_provider.py | — |
| `slack-sdk` | Slack Socket Mode（WS）+ Web API | channels/slack.py | — |
| `python-telegram-bot` | Telegram 长轮询 | channels/telegram.py | — |
| `lark-oapi` | 飞书 WS 长连接 + 媒体 API | channels/feishu.py | SDK 模块级 loop 被替换以兼容 uvloop（feishu.py:223-255） |
| `dingtalk-stream` | 钉钉 Stream Push | channels/dingtalk.py | — |
| `wecom-aibot-python-sdk` | 企微智能机器人 WS | channels/wecom.py | SDK 1.0.2 同步 disconnect 需手工关停（wecom.py:216-246） |
| `discord.py`（可选 extra） | Discord 网关 | channels/discord.py | — |
| `coincurve`（可选 buzz extra） | BIP-340 Schnorr 签名 | channels/buzz_nostr.py（懒加载 :20-25） | — |
| `markdown-to-mrkdwn` | Slack 富文本转换 | channels/slack.py | — |
| `sse-starlette` | SSE 响应支持 | routers/thread_runs.py 等 | 帧格式化自研 format_sse（services.py:156） |
| `python-multipart` | multipart 解析（上传/技能安装） | routers/uploads.py、skills.py | — |
| `sqlalchemy`（经 harness）+ `alembic` | ORM/迁移 | auth/repositories/sqlite.py、channels/dedupe_store.py、routers/console.py | — |
| `email-validator` | EmailStr 校验 | auth/models.py | — |
| `e2b-code-interpreter` | E2B 沙箱（可选） | harness（排除范围） | — |
| `websockets==16.0`（override） | Buzz relay 客户端 + IM SDK 传递依赖 | channels/buzz.py；pyproject:91-106 override 注释 | langgraph-sdk 0.4.2 曾钉 <16，DeerFlow 显式 override 回 16.0 并记录理由 |

---

# 第 10 章 新人上手路径

## 10.1 建议阅读顺序（由浅入深）

1. **全局认知**：`README.md` → `langgraph.json` → `pyproject.toml`（依赖注释很有信息量）→ `Makefile`。
2. **应用装配**：`app/gateway/config.py`（26 行）→ `app/gateway/app.py` 的 `create_app`（:673-1016）与 `lifespan`（:272-670）——先看懂「启动了哪些服务、停机顺序是什么」。
3. **一次请求**：`trace_middleware.py` → `csrf_middleware.py` → `auth_middleware.py` → `authz.py`（require_permission）→ `routers/thread_runs.py:stream_run`。
4. **run 生命周期**（核心）：`run_models.py` → `services.py` 的 `start_run`/`sse_consumer`/`format_sse` → `deps.py` 的 `langgraph_runtime`。
5. **数据面**：`conversation_reader.py` → `checkpoint_lineage.py` → `path_utils.py` → `routers/threads.py`（删除/分支）。
6. **渠道层**：`channels/message_bus.py` → `channels/base.py` → `channels/manager.py`（先读 `_worker_loop`→`_handle_message`→`_handle_chat_on_thread` 主线）→ `channels/service.py` → 挑一个简单渠道（slack.py）与一个复杂渠道（buzz.py）对照。
7. **后台服务**：`scheduler/service.py`（租约范式代表）→ `mcp_tasks/service.py`（同范式+通知状态机）。
8. **认证细节**（按需）：`auth/jwt.py`/`password.py` → `local_provider.py` → `oidc.py` → `pat.py`。
9. **扩展系统**：`packages/extension-api/deerflow_extension_api/contracts.py` → `placement.py` → `assembly.py`。

## 10.2 常见需求的修改切入点

| 需求 | 入手位置 |
|---|---|
| **改一个接口（响应字段/校验）** | `app/gateway/routers/<域>.py` 找端点 → 追到 services/ deps → 模型多为文件内 Pydantic 或 `run_models.py`；注意响应体是否要过 `redact_metadata_secrets` |
| **加一个 REST 端点** | 新建 `routers/xxx.py`（router = APIRouter）→ `app.py:882-961` 注册（宿主路由先于扩展路由）→ 权限用 `@require_permission` → 依赖用 `deps.get_*` |
| **加一个 IM 渠道** | 实现 `channels/base.py:Channel` 三件套 → 在 `channels/service.py:_CHANNEL_REGISTRY`（:27）注册 → 需要特殊策略则在 `CHANNEL_RUN_POLICY` 注册一行 → 需要凭证字段则加 `_CHANNEL_CREDENTIAL_KEYS` 与 `routers/channel_connections.py` |
| **加一个 webhook 触发渠道（非交互）** | 同上 + run_policy 参考 `github/run_policy.py:register_policy`（fire_and_forget/buffer_followups_on_busy）+ webhook 路由参考 `github_webhooks.py`（验签 fail-closed） |
| **加一个定时任务类型/改调度行为** | `app/scheduler/service.py`（调度策略）+ `routers/scheduled_tasks.py`（API/校验）；持久层在 harness 的 persistence.scheduler |
| **改 run 准入/流式行为** | `services.py:start_run`/`sse_consumer`——注意保持「durable 准入与 task 挂载零 await」与帧格式契约 |
| **改权限模型** | `authz.py`（Permissions/_ALL_PERMISSIONS/装饰器）+ 中间件预算逻辑；PAT scope 同步改 `auth/pat.py:PAT_ALLOWED_SCOPES` 与路由白名单 |
| **加 MCP 服务器安全规则** | `routers/mcp.py`（stdio allowlist `_arbitrary_exec_arg` / env 黑名单 `_CODE_INJECTING_ENV_VARS`） |
| **加数据迁移** | `make migrate-rev MSG=...`（底层 `scripts/_autogen_revision.py`）；一次性数据搬迁参考 scripts/migrate_*.py 三件套 |

## 10.3 隐性约定与易踩坑点

1. **harness/app 边界**：`deerflow.*` 全在 `packages/harness`——改 run 执行、中间件链、checkpointer、持久化引擎要去那边；本仓库 app 层只做 HTTP/渠道/编排。`langgraph.json` 的 graphs/checkpointer 路径也指向 harness。
2. **身份三元组**：认证 User（HTTP）/ internal user（后台回打）/ connection owner（渠道绑定）——文件桶与资源归属最终都经 `make_safe_user_id` 归一（`internal_auth.py:53-67`）；内部 token **每 worker 独立随机**，跨 worker 回打会 401（只能同进程）。
3. **404 而非 403**：资源属主不符一律 404（防枚举）——`authz.py:694-698`、`services.py:1562-1563`；新端点要遵守同一语义。
4. **零 await 窗口与 durable 语义**：`start_run` 的准入/挂载顺序、`wechat` 的「整批处理完才推进游标」、buzz 的「publish 成功才记录 seen」都是崩溃一致性设计，重构时不能插入 await 或调换顺序。
5. **多 worker 限制**：SQLite + GATEWAY_WORKERS>1 直接拒绝启动（`deps.py:58`）；登录限流/setup-status 缓存/技能导出槽是进程内的，多 worker 下各自独立（`routers/auth.py:162-169` 明示局限）。
6. **热重载边界**：config.yaml 热加载，但 `startup-only:` 字段（数据库后端、scheduler 开关等）绑启动快照；健康探针读 startup 快照不读热配置（`health.py:60`）。
7. **秘密纪律**：新端点回显 run/thread 数据前过脱敏（`redact_metadata_secrets`、`redact_config_secrets`）；日志不得出现 token/下载 URL；extensions_config.json 的掩码 `***` 回填语义（GET 掩码/PUT 回填/新键给掩码报 400）。
8. **SSE 帧契约**：`format_sse` 的字段顺序、Content-Location 头、gap/end/heartbeat 语义是前端 useStream 的硬契约，改动需同步前端。
9. **Windows 开发**：`sitecustomize.py` 强制 SelectorEventLoop；Makefile 目标多为 bash 语法，Windows 下建议 WSL/Git Bash 或直接手敲 uvicorn 命令。
10. **测试跑法**：`make test` 排除 live；blocking IO 检测是独立套件（`tests/blocking_io`）；`.test_durations` 支撑分片——新增大量测试后记得 `make test-shard-durations` 刷新。
11. **webhook 路由 fail-closed**：`github_webhooks` 无 secret 时**路由不挂载**（404）而非空验签；本地调试需 `DEER_FLOW_ALLOW_UNVERIFIED_GITHUB_WEBHOOKS=1` 显式开启。
12. **fail-open vs fail-closed 按代价取舍**：去重存储 fail-open（宁重复不丢消息）、身份核查 fail-closed（无 workspace 跳过去重）、auth provider 解析失败按配置 `fail_closed` 决定——新代码要明确自己属于哪一类并写注释。

---

# 收尾：全报告总目录

| 章节 | 内容 | 所在批次 |
|---|---|---|
| 术语表 | 项目特有概念 | 批次 1 |
| 批次计划 | 分批输出策略与状态 | 批次 1 |
| 第 1 章 | 项目概述（用途/技术栈/运行方式） | 批次 1 |
| 第 2 章 | 整体架构（分层/模块依赖/核心数据流） | 批次 1 |
| 第 3 章 | 目录结构详解 | 批次 1 |
| 第 4 章 4.1 | extension-api 公共契约包 | 批次 2 |
| 第 4 章 4.2 | 网关基础设施（16 文件） | 批次 2 |
| 第 4 章 4.3 | 认证授权（auth/ + authz + auth_middleware） | 批次 3 |
| 第 4 章 4.4 | GitHub App 集成 | 批次 3 |
| 第 4 章 4.5 | 渠道集成层（25 文件） | 批次 4 |
| 第 4 章 4.6-4.8 | 网关核心服务/依赖注入/路由层 | 批次 5 |
| 第 4 章 4.9-4.10 | 调度器/MCP 任务/子代理批次 | 批次 5 |
| 第 4 章 4.11 | 入口 app.py/根文件/Dockerfile/scripts | 批次 6 |
| 第 5 章 | 文件清单总表（全部生产文件） | 批次 1（表）+ 全批（内容） |
| 第 6 章 | 关键函数深度解析（8 个函数带代码） | 批次 7 |
| 第 7 章 | 端到端调用链（4 场景） | 批次 7 |
| 第 8 章 | 横切机制说明 | 批次 7 |
| 第 9 章 | 外部依赖说明 | 批次 7 |
| 第 10 章 | 新人上手路径 | 批次 7 |

# 完成度自检表

| 检查项 | 结果 |
|---|---|
| app/channels 25 个生产 py | ✅ 全部覆盖（4.5 + 5.1） |
| app/gateway 根 27 个生产 py | ✅ 全部覆盖（4.2/4.3/4.6/4.7/4.11 + 5.2） |
| app/gateway/auth 16 + repositories 3 | ✅ 全部覆盖（4.3.1 + 5.3） |
| app/gateway/github 8 | ✅ 全部覆盖（4.4 + 5.4） |
| app/gateway/routers 32 | ✅ 全部覆盖（4.8 + 5.5；threads/thread_runs/runs/mcp/skills/auth 七个大文件逐端点，其余 26 个以表格逐文件） |
| app/mcp_tasks 3 / app/scheduler 2 / app/subagent_batches 2 / app/__init__ | ✅ 全部覆盖（4.9/4.10 + 5.6） |
| packages/extension-api 11 py + pyproject | ✅ 全部覆盖（4.1 + 5.7） |
| 根文件 debug.py / sitecustomize.py / Dockerfile / Makefile / langgraph.json / pyproject.toml | ✅ 覆盖（4.11 + 1.2/1.3） |
| scripts 根 9 脚本 | ✅ 逐文件（4.11.3 + 5.8） |
| scripts/benchmark 36 文件 | ✅ 目录粒度概述（4.11.4 + 5.8）——属开发基准工具，未逐文件函数级分析（说明：非运行时生产代码） |
| 排除范围未分析 | ✅ packages/harness（任务指定）、tests/、docs/、extension_test_fixtures/（测试夹具）、samples/（示例配置）、uv.lock、.vscode/、ruff.toml、AGENTS.md×3（纯文档） |

# 存疑与待确认清单

1. **（推断）wechat.py AES 密钥来源**：`_resolve_media_aes_key`（wechat.py:1370）多格式解析 CDN 响应中的密钥，但 iLink 协议本身无公开文档，密钥格式的权威描述只能从代码归纳。
2. **（推断）users 表模型定义**：表结构（九列+两索引）由 `auth/repositories/sqlite.py:24,53-54` 的索引名引用反推，ORM 模型 `UserRow` 在排除范围 harness。
3. **（推断）`_RESTART_RECOVERY_ERROR`/`_LEASE_RECOVERY_ERROR` 的展示语义**：错误字符串在 scheduler 恢复路径写入 run 行，前端如何呈现未见 app 层证据。
4. **subagent_batches 并发原语**：app 层为 shim，线程池/asyncio 与最大并发的最终实现在 harness 的 `batch_service.py`（排除范围）；本报告仅陈述 app 侧可证据事实（DB 租约队列、全局容量配置）。
5. **行号版本漂移风险**：本报告行号基于 2.1.0 源码精确核对（关键函数经工具二次验证），后续提交可能使行号偏移；结构性结论（调用关系、设计意图）相对稳定。
6. **benchmark 各子目录**仅做目录级用途概述，未验证其内部与生产代码的每个 import 对应关系。

